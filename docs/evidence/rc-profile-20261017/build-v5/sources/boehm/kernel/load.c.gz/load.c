#include "rc_phase_profile.h"
/* Generated always-AOT kernel module (KL defuns -> NativeFunctions).
 * Install after tree-walker boot overwrites UserFunctions.
 * Toplevel declare/set stay on the walker. Not overlay-after-load.
 * Sidecar tests stay on the tree-walker. Not a second main. Source: load.kl
 */
#include "abi.h"

void shen_kernel_aot_install_load (shen_context* ctx);

static KLObject* lambda_0 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t49 = objects[0];
  KLObject* t52;
  {
    KLObject* a52[] = {t49};
    t52 = sp_boehm_phase_1(ctx, "shen.shen->kl", 1, a52);
  }
  KLObject* t54 = shen_eval_kl(ctx, t52);
  KLObject* t55 = shen_string(ctx, "\n");
  KLObject* t56 = shen_intern(ctx, "shen.s");
  KLObject* t51;
  {
    KLObject* a51[] = {t54, t55, t56};
    t51 = shen_apply_direct(ctx, "shen.app", 3, a51);
  }
  KLObject* t57 = shen_apply_direct(ctx, "stoutput", 0, NULL);
  KLObject* t50;
  {
    KLObject* a50[] = {t51, t57};
    t50 = shen_tail_apply_direct(ctx, "pr", 2, a50);
  }
    return t50;
  }
}

static KLObject* lambda_1 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t62 = objects[0];
  KLObject* t63;
  {
    KLObject* a63[] = {t62};
    t63 = shen_tail_apply_direct(ctx, "shen.typetable", 1, a63);
  }
    return t63;
  }
}

static KLObject* trap_body_0 (void* data)
{
  shen_context* ctx = &shen_root_context;
  Vector* env = (Vector*)data;
  KLObject* t67 = shen_vector_get(ctx, env, 0);
  KLObject* t68 = shen_vector_get(ctx, env, 1);
  KLObject* t69;
  {
    KLObject* a69[] = {t68};
    t69 = shen_apply_direct(ctx, "shen.assumetypes", 1, a69);
  }
  return t69;
}

static KLObject* lambda_2 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  KLObject* t74 = shen_vector_get(ctx, caps, 0);
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t75 = objects[0];
  KLObject* t76;
  {
    KLObject* a76[] = {t75, t74};
    t76 = shen_tail_apply_direct(ctx, "shen.unwind-types", 2, a76);
  }
    return t76;
  }
}

static KLObject* trap_handler_0 (KLObject* exception, void* data)
{
  shen_context* ctx = &shen_root_context;
  Vector* env = (Vector*)data;
  Vector* args;
  KLObject* t71 = shen_vector_get(ctx, env, 0);
  KLObject* t72 = shen_vector_get(ctx, env, 1);
  KLObject* t73;
  {
    Vector* caps_2 = shen_vector(ctx, 1);
    shen_vector_set(ctx, caps_2, 0, t72);
    t73 = shen_native_closure(ctx, 1, &lambda_2, caps_2);
  }
  args = shen_vector(ctx, 1);
  shen_vector_set(ctx, args, 0, exception);
  {
    KLObject* t79 = shen_apply(ctx, t73, args);
    return t79;
  }
}

static KLObject* trap_body_1 (void* data)
{
  shen_context* ctx = &shen_root_context;
  Vector* env = (Vector*)data;
  KLObject* t81 = shen_vector_get(ctx, env, 0);
  KLObject* t82 = shen_vector_get(ctx, env, 1);
  KLObject* t83 = shen_vector_get(ctx, env, 2);
  KLObject* t84;
  {
    KLObject* a84[] = {t81};
    t84 = shen_apply_direct(ctx, "shen.work-through", 1, a84);
  }
  return t84;
}

static KLObject* lambda_3 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  KLObject* t90 = shen_vector_get(ctx, caps, 0);
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t91 = objects[0];
  KLObject* t92;
  {
    KLObject* a92[] = {t91, t90};
    t92 = shen_tail_apply_direct(ctx, "shen.unwind-types", 2, a92);
  }
    return t92;
  }
}

static KLObject* trap_handler_1 (KLObject* exception, void* data)
{
  shen_context* ctx = &shen_root_context;
  Vector* env = (Vector*)data;
  Vector* args;
  KLObject* t86 = shen_vector_get(ctx, env, 0);
  KLObject* t87 = shen_vector_get(ctx, env, 1);
  KLObject* t88 = shen_vector_get(ctx, env, 2);
  KLObject* t89;
  {
    Vector* caps_3 = shen_vector(ctx, 1);
    shen_vector_set(ctx, caps_3, 0, t87);
    t89 = shen_native_closure(ctx, 1, &lambda_3, caps_3);
  }
  args = shen_vector(ctx, 1);
  shen_vector_set(ctx, args, 0, exception);
  {
    KLObject* t95 = shen_apply(ctx, t89, args);
    return t95;
  }
}

static KLObject* lambda_4 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t463 = objects[0];
  KLObject* t464;
  {
    KLObject* a464[] = {t463};
    t464 = shen_tail_apply_direct(ctx, "shen.pretty-type", 1, a464);
  }
    return t464;
  }
}

static KLObject* lambda_5 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t481 = objects[0];
  KLObject* t483;
  {
    KLObject* a483[] = {t481};
    t483 = shen_apply_direct(ctx, "shen.shen->kl-h", 1, a483);
  }
  KLObject* t482;
  {
    KLObject* a482[] = {t483};
    t482 = shen_tail_apply_direct(ctx, "shen.partial", 1, a482);
  }
    return t482;
  }
}

static KLObject* lambda_6 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t523 = objects[0];
  KLObject* t524;
  {
    KLObject* a524[] = {t523};
    t524 = shen_tail_apply_direct(ctx, "shen.partial", 1, a524);
  }
    return t524;
  }
}

static KLObject* native_kl_load_0_profile_impl (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t0 = objects[0];
  tail_start_kl_load_0: ;
  KLObject* t2 = shen_intern(ctx, "shen.*tc*");
  KLObject* t1;
  {
    KLObject* a1[] = {t2};
    t1 = shen_apply_direct(ctx, "value", 1, a1);
  }
  KLObject* t4 = shen_intern(ctx, "run");
  KLObject* t3;
  {
    KLObject* a3[] = {t4};
    t3 = shen_apply_direct(ctx, "get-time", 1, a3);
  }
  KLObject* t7;
  {
    KLObject* a7[] = {t0};
    t7 = sp_boehm_phase_0(ctx, "read-file", 1, a7);
  }
  KLObject* t5;
  {
    KLObject* a5[] = {t1, t7};
    t5 = shen_apply_direct(ctx, "shen.load-help", 2, a5);
  }
  KLObject* t10 = shen_intern(ctx, "run");
  KLObject* t9;
  {
    KLObject* a9[] = {t10};
    t9 = shen_apply_direct(ctx, "get-time", 1, a9);
  }
  KLObject* t13 = shen_sub(ctx, t9, t3);
  KLObject* t16 = shen_string(ctx, "\nrun time: ");
  KLObject* t18;
  {
    KLObject* a18[] = {t13};
    t18 = shen_apply_direct(ctx, "str", 1, a18);
  }
  KLObject* t20 = shen_string(ctx, " secs\n");
  KLObject* t17;
  {
    KLObject* a17[] = {t18, t20};
    t17 = shen_apply_direct(ctx, "cn", 2, a17);
  }
  KLObject* t15;
  {
    KLObject* a15[] = {t16, t17};
    t15 = shen_apply_direct(ctx, "cn", 2, a15);
  }
  KLObject* t21 = shen_apply_direct(ctx, "stoutput", 0, NULL);
  KLObject* t14;
  {
    KLObject* a14[] = {t15, t21};
    t14 = shen_apply_direct(ctx, "pr", 2, a14);
  }
  KLObject* t23;
  if (!shen_is_boolean(ctx, t1))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1)) {
  KLObject* t27 = shen_string(ctx, "\ntypechecked in ");
  KLObject* t29 = shen_apply_direct(ctx, "inferences", 0, NULL);
  KLObject* t30 = shen_string(ctx, " inferences\n");
  KLObject* t31 = shen_intern(ctx, "shen.a");
  KLObject* t28;
  {
    KLObject* a28[] = {t29, t30, t31};
    t28 = shen_apply_direct(ctx, "shen.app", 3, a28);
  }
  KLObject* t26;
  {
    KLObject* a26[] = {t27, t28};
    t26 = shen_apply_direct(ctx, "cn", 2, a26);
  }
  KLObject* t32 = shen_apply_direct(ctx, "stoutput", 0, NULL);
  KLObject* t25;
  {
    KLObject* a25[] = {t26, t32};
    t25 = shen_apply_direct(ctx, "pr", 2, a25);
  }
    t23 = t25;
  } else {
  KLObject* t33 = shen_intern(ctx, "shen.skip");
    t23 = t33;
  }
  KLObject* t34 = shen_intern(ctx, "loaded");
    return t34;
  }
}
static KLObject* native_kl_load_0 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment) {
sp_enter("other",arguments->objects[0]->value.string);
KLObject* sp_result=native_kl_load_0_profile_impl(function_object,arguments,function_environment,variable_environment);
sp_leave();
return sp_result;
}


static KLObject* native_kl_shen_2eload_2dhelp_1 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t35 = objects[0];
    KLObject* t36 = objects[1];
  tail_start_kl_shen_2eload_2dhelp_1: ;
  KLObject* t37;
  {
  KLObject* t38 = shen_false(ctx);
  KLObject* t40 = shen_eq(ctx, t38, t35);
    if (!shen_is_boolean(ctx, t40))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t40)) {
  KLObject* t41;
  {
    KLObject* a41[] = {t36};
    t41 = shen_tail_apply_direct(ctx, "shen.eval-and-print", 1, a41);
  }
      t37 = t41;
    } else {
  KLObject* t43 = shen_true(ctx);
    if (!shen_is_boolean(ctx, t43))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t43)) {
  KLObject* t44;
  {
    KLObject* a44[] = {t36};
    t44 = shen_tail_apply_direct(ctx, "shen.check-eval-and-print", 1, a44);
  }
      t37 = t44;
    } else {
      shen_simple_error(ctx, "No true case found for cond");
      t37 = shen_empty_list(ctx);
    }
    }
  }
    return t37;
  }
}

static KLObject* native_kl_shen_2eeval_2dand_2dprint_2 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t46 = objects[0];
  tail_start_kl_shen_2eeval_2dand_2dprint_2: ;
  KLObject* t48;
  {
    Vector* caps_0 = shen_vector(ctx, 0);
    t48 = shen_native_closure(ctx, 1, &lambda_0, caps_0);
  }
  KLObject* t47;
  {
    KLObject* a47[] = {t48, t46};
    t47 = shen_tail_apply_direct(ctx, "map", 2, a47);
  }
    return t47;
  }
}

static KLObject* native_kl_shen_2echeck_2deval_2dand_2dprint_3 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t59 = objects[0];
  tail_start_kl_shen_2echeck_2deval_2dand_2dprint_3: ;
  KLObject* t61;
  {
    Vector* caps_1 = shen_vector(ctx, 0);
    t61 = shen_native_closure(ctx, 1, &lambda_1, caps_1);
  }
  KLObject* t60;
  {
    KLObject* a60[] = {t61, t59};
    t60 = shen_apply_direct(ctx, "mapcan", 2, a60);
  }
  KLObject* t66;
  {
    Vector* tenv_0 = shen_vector(ctx, 2);
    shen_vector_set(ctx, tenv_0, 0, t59);
    shen_vector_set(ctx, tenv_0, 1, t60);
    t66 = shen_trap_error(ctx, trap_body_0, trap_handler_0, tenv_0);
  }
  KLObject* t80;
  {
    Vector* tenv_1 = shen_vector(ctx, 3);
    shen_vector_set(ctx, tenv_1, 0, t59);
    shen_vector_set(ctx, tenv_1, 1, t60);
    shen_vector_set(ctx, tenv_1, 2, t66);
    t80 = shen_trap_error(ctx, trap_body_1, trap_handler_1, tenv_1);
  }
    return t80;
  }
}

static KLObject* native_kl_shen_2etypetable_4 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t96 = objects[0];
  tail_start_kl_shen_2etypetable_4: ;
  KLObject* t97;
  {
  KLObject* t100 = shen_cons_p(ctx, t96);
  KLObject* t98;
  if (!shen_is_boolean(ctx, t100))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t100)) {
    t98 = t100;
  } else {
  KLObject* t102 = shen_intern(ctx, "define");
  KLObject* t104 = shen_hd(ctx, t96);
  KLObject* t105 = shen_eq(ctx, t102, t104);
  KLObject* t101;
  if (!shen_is_boolean(ctx, t105))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t105)) {
    t101 = t105;
  } else {
  KLObject* t108 = shen_tl(ctx, t96);
  KLObject* t109 = shen_cons_p(ctx, t108);
  KLObject* t106;
  if (!shen_is_boolean(ctx, t109))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t109)) {
    t106 = t109;
  } else {
  KLObject* t112 = shen_tl(ctx, t96);
  KLObject* t113 = shen_tl(ctx, t112);
  KLObject* t114 = shen_cons_p(ctx, t113);
  KLObject* t110;
  if (!shen_is_boolean(ctx, t114))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t114)) {
    t110 = t114;
  } else {
  KLObject* t115 = shen_intern(ctx, "{");
  KLObject* t117 = shen_tl(ctx, t96);
  KLObject* t118 = shen_tl(ctx, t117);
  KLObject* t119 = shen_hd(ctx, t118);
  KLObject* t120 = shen_eq(ctx, t115, t119);
    if (!shen_is_boolean(ctx, t120))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t110 = t120;
  }
    if (!shen_is_boolean(ctx, t110))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t106 = t110;
  }
    if (!shen_is_boolean(ctx, t106))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t101 = t106;
  }
    if (!shen_is_boolean(ctx, t101))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t98 = t101;
  }
    if (!shen_is_boolean(ctx, t98))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t98)) {
  KLObject* t122 = shen_tl(ctx, t96);
  KLObject* t123 = shen_hd(ctx, t122);
  KLObject* t127 = shen_tl(ctx, t96);
  KLObject* t128 = shen_hd(ctx, t127);
  KLObject* t130 = shen_tl(ctx, t96);
  KLObject* t131 = shen_tl(ctx, t130);
  KLObject* t132 = shen_tl(ctx, t131);
  KLObject* t125;
  {
    KLObject* a125[] = {t128, t132};
    t125 = shen_apply_direct(ctx, "shen.type-F", 2, a125);
  }
  KLObject* t124;
  {
    KLObject* a124[] = {t125};
    t124 = shen_apply_direct(ctx, "shen.rectify-type", 1, a124);
  }
  KLObject* t133 = shen_empty_list(ctx);
  KLObject* t134 = shen_cons(ctx, t124, t133);
  KLObject* t135 = shen_cons(ctx, t123, t134);
      t97 = t135;
    } else {
  KLObject* t138 = shen_cons_p(ctx, t96);
  KLObject* t136;
  if (!shen_is_boolean(ctx, t138))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t138)) {
    t136 = t138;
  } else {
  KLObject* t140 = shen_intern(ctx, "define");
  KLObject* t142 = shen_hd(ctx, t96);
  KLObject* t143 = shen_eq(ctx, t140, t142);
  KLObject* t139;
  if (!shen_is_boolean(ctx, t143))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t143)) {
    t139 = t143;
  } else {
  KLObject* t145 = shen_tl(ctx, t96);
  KLObject* t146 = shen_cons_p(ctx, t145);
    if (!shen_is_boolean(ctx, t146))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t139 = t146;
  }
    if (!shen_is_boolean(ctx, t139))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t136 = t139;
  }
    if (!shen_is_boolean(ctx, t136))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t136)) {
  KLObject* t149 = shen_string(ctx, "missing { in ");
  KLObject* t152 = shen_tl(ctx, t96);
  KLObject* t153 = shen_hd(ctx, t152);
  KLObject* t154 = shen_string(ctx, "\n");
  KLObject* t155 = shen_intern(ctx, "shen.a");
  KLObject* t150;
  {
    KLObject* a150[] = {t153, t154, t155};
    t150 = shen_apply_direct(ctx, "shen.app", 3, a150);
  }
  KLObject* t148;
  {
    KLObject* a148[] = {t149, t150};
    t148 = shen_apply_direct(ctx, "cn", 2, a148);
  }
  KLObject* t147;
  {
    KLObject* a147[] = {t148};
    t147 = shen_tail_apply_direct(ctx, "simple-error", 1, a147);
  }
      t97 = t147;
    } else {
  KLObject* t156 = shen_true(ctx);
    if (!shen_is_boolean(ctx, t156))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t156)) {
  KLObject* t157 = shen_empty_list(ctx);
      t97 = t157;
    } else {
      shen_simple_error(ctx, "No true case found for cond");
      t97 = shen_empty_list(ctx);
    }
    }
    }
  }
    return t97;
  }
}

static KLObject* native_kl_shen_2etype_2dF_5 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t158 = objects[0];
    KLObject* t159 = objects[1];
  tail_start_kl_shen_2etype_2dF_5: ;
  KLObject* t160;
  {
  KLObject* t163 = shen_cons_p(ctx, t159);
  KLObject* t161;
  if (!shen_is_boolean(ctx, t163))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t163)) {
    t161 = t163;
  } else {
  KLObject* t164 = shen_intern(ctx, "}");
  KLObject* t166 = shen_hd(ctx, t159);
  KLObject* t167 = shen_eq(ctx, t164, t166);
    if (!shen_is_boolean(ctx, t167))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t161 = t167;
  }
    if (!shen_is_boolean(ctx, t161))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t161)) {
  KLObject* t168 = shen_empty_list(ctx);
      t160 = t168;
    } else {
  KLObject* t170 = shen_cons_p(ctx, t159);
    if (!shen_is_boolean(ctx, t170))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t170)) {
  KLObject* t172 = shen_hd(ctx, t159);
  KLObject* t176 = shen_tl(ctx, t159);
  KLObject* t173;
  {
    KLObject* a173[] = {t158, t176};
    t173 = shen_apply_direct(ctx, "shen.type-F", 2, a173);
  }
  KLObject* t177 = shen_cons(ctx, t172, t173);
      t160 = t177;
    } else {
  KLObject* t178 = shen_true(ctx);
    if (!shen_is_boolean(ctx, t178))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t178)) {
  KLObject* t181 = shen_string(ctx, "missing } in ");
  KLObject* t184 = shen_string(ctx, "\n");
  KLObject* t185 = shen_intern(ctx, "shen.a");
  KLObject* t182;
  {
    KLObject* a182[] = {t158, t184, t185};
    t182 = shen_apply_direct(ctx, "shen.app", 3, a182);
  }
  KLObject* t180;
  {
    KLObject* a180[] = {t181, t182};
    t180 = shen_apply_direct(ctx, "cn", 2, a180);
  }
  KLObject* t179;
  {
    KLObject* a179[] = {t180};
    t179 = shen_tail_apply_direct(ctx, "simple-error", 1, a179);
  }
      t160 = t179;
    } else {
      shen_simple_error(ctx, "No true case found for cond");
      t160 = shen_empty_list(ctx);
    }
    }
    }
  }
    return t160;
  }
}

static KLObject* native_kl_shen_2eassumetypes_6 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t186 = objects[0];
  tail_start_kl_shen_2eassumetypes_6: ;
  KLObject* t187;
  {
  KLObject* t188 = shen_empty_list(ctx);
  KLObject* t190 = shen_eq(ctx, t188, t186);
    if (!shen_is_boolean(ctx, t190))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t190)) {
  KLObject* t191 = shen_empty_list(ctx);
      t187 = t191;
    } else {
  KLObject* t194 = shen_cons_p(ctx, t186);
  KLObject* t192;
  if (!shen_is_boolean(ctx, t194))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t194)) {
    t192 = t194;
  } else {
  KLObject* t196 = shen_tl(ctx, t186);
  KLObject* t197 = shen_cons_p(ctx, t196);
    if (!shen_is_boolean(ctx, t197))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t192 = t197;
  }
    if (!shen_is_boolean(ctx, t192))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t192)) {
  KLObject* t200 = shen_hd(ctx, t186);
  KLObject* t202 = shen_tl(ctx, t186);
  KLObject* t203 = shen_hd(ctx, t202);
  KLObject* t198;
  {
    KLObject* a198[] = {t200, t203};
    t198 = shen_apply_direct(ctx, "declare", 2, a198);
  }
  KLObject* t205 = shen_tl(ctx, t186);
  KLObject* t206 = shen_tl(ctx, t205);
  {
    KLObject* n207_0 = t206;
    t186 = n207_0;
    goto tail_start_kl_shen_2eassumetypes_6;
  }
  KLObject* t207 = NULL;
      t187 = t207;
    } else {
  KLObject* t208 = shen_true(ctx);
    if (!shen_is_boolean(ctx, t208))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t208)) {
  KLObject* t210 = shen_string(ctx, "implementation error in shen.assumetype");
  KLObject* t209;
  {
    KLObject* a209[] = {t210};
    t209 = shen_tail_apply_direct(ctx, "simple-error", 1, a209);
  }
      t187 = t209;
    } else {
      shen_simple_error(ctx, "No true case found for cond");
      t187 = shen_empty_list(ctx);
    }
    }
    }
  }
    return t187;
  }
}

static KLObject* native_kl_shen_2eunwind_2dtypes_7 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t211 = objects[0];
    KLObject* t212 = objects[1];
  tail_start_kl_shen_2eunwind_2dtypes_7: ;
  KLObject* t213;
  {
  KLObject* t216 = shen_cons_p(ctx, t212);
  KLObject* t214;
  if (!shen_is_boolean(ctx, t216))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t216)) {
    t214 = t216;
  } else {
  KLObject* t218 = shen_tl(ctx, t212);
  KLObject* t219 = shen_cons_p(ctx, t218);
    if (!shen_is_boolean(ctx, t219))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t214 = t219;
  }
    if (!shen_is_boolean(ctx, t214))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t214)) {
  KLObject* t222 = shen_hd(ctx, t212);
  KLObject* t220;
  {
    KLObject* a220[] = {t222};
    t220 = shen_apply_direct(ctx, "destroy", 1, a220);
  }
  KLObject* t225 = shen_tl(ctx, t212);
  KLObject* t226 = shen_tl(ctx, t225);
  {
    KLObject* n227_0 = t211;
    KLObject* n227_1 = t226;
    t211 = n227_0;
    t212 = n227_1;
    goto tail_start_kl_shen_2eunwind_2dtypes_7;
  }
  KLObject* t227 = NULL;
      t213 = t227;
    } else {
  KLObject* t228 = shen_true(ctx);
    if (!shen_is_boolean(ctx, t228))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t228)) {
  KLObject* t230;
  {
    KLObject* a230[] = {t211};
    t230 = shen_apply_direct(ctx, "error-to-string", 1, a230);
  }
  KLObject* t229;
  {
    KLObject* a229[] = {t230};
    t229 = shen_tail_apply_direct(ctx, "simple-error", 1, a229);
  }
      t213 = t229;
    } else {
      shen_simple_error(ctx, "No true case found for cond");
      t213 = shen_empty_list(ctx);
    }
    }
  }
    return t213;
  }
}

static KLObject* native_kl_shen_2ework_2dthrough_8 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t232 = objects[0];
  tail_start_kl_shen_2ework_2dthrough_8: ;
  KLObject* t233;
  {
  KLObject* t234 = shen_empty_list(ctx);
  KLObject* t236 = shen_eq(ctx, t234, t232);
    if (!shen_is_boolean(ctx, t236))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t236)) {
  KLObject* t237 = shen_empty_list(ctx);
      t233 = t237;
    } else {
  KLObject* t240 = shen_cons_p(ctx, t232);
  KLObject* t238;
  if (!shen_is_boolean(ctx, t240))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t240)) {
    t238 = t240;
  } else {
  KLObject* t243 = shen_tl(ctx, t232);
  KLObject* t244 = shen_cons_p(ctx, t243);
  KLObject* t241;
  if (!shen_is_boolean(ctx, t244))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t244)) {
    t241 = t244;
  } else {
  KLObject* t247 = shen_tl(ctx, t232);
  KLObject* t248 = shen_tl(ctx, t247);
  KLObject* t249 = shen_cons_p(ctx, t248);
  KLObject* t245;
  if (!shen_is_boolean(ctx, t249))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t249)) {
    t245 = t249;
  } else {
  KLObject* t251 = shen_tl(ctx, t232);
  KLObject* t252 = shen_hd(ctx, t251);
  KLObject* t254 = shen_string(ctx, ":");
  KLObject* t253;
  {
    KLObject* a253[] = {t254};
    t253 = shen_apply_direct(ctx, "intern", 1, a253);
  }
  KLObject* t255 = shen_eq(ctx, t252, t253);
    if (!shen_is_boolean(ctx, t255))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t245 = t255;
  }
    if (!shen_is_boolean(ctx, t245))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t241 = t245;
  }
    if (!shen_is_boolean(ctx, t241))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t238 = t241;
  }
    if (!shen_is_boolean(ctx, t238))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t238)) {
  KLObject* t258 = shen_hd(ctx, t232);
  KLObject* t260 = shen_tl(ctx, t232);
  KLObject* t261 = shen_tl(ctx, t260);
  KLObject* t262 = shen_hd(ctx, t261);
  KLObject* t256;
  {
    KLObject* a256[] = {t258, t262};
    t256 = sp_boehm_phase_2(ctx, "shen.typecheck", 2, a256);
  }
  KLObject* t265 = shen_false(ctx);
  KLObject* t266 = shen_eq(ctx, t256, t265);
  KLObject* t263;
  if (!shen_is_boolean(ctx, t266))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t266)) {
  KLObject* t267 = shen_tail_apply_direct(ctx, "shen.type-error", 0, NULL);
    t263 = t267;
  } else {
  KLObject* t270 = shen_hd(ctx, t232);
  KLObject* t268;
  {
    KLObject* a268[] = {t270};
    t268 = sp_boehm_phase_1(ctx, "shen.shen->kl", 1, a268);
  }
  KLObject* t271 = shen_eval_kl(ctx, t268);
  KLObject* t276 = shen_string(ctx, " : ");
  KLObject* t278;
  {
    KLObject* a278[] = {t256};
    t278 = shen_apply_direct(ctx, "shen.pretty-type", 1, a278);
  }
  KLObject* t280 = shen_string(ctx, "\n");
  KLObject* t281 = shen_intern(ctx, "shen.r");
  KLObject* t277;
  {
    KLObject* a277[] = {t278, t280, t281};
    t277 = shen_apply_direct(ctx, "shen.app", 3, a277);
  }
  KLObject* t275;
  {
    KLObject* a275[] = {t276, t277};
    t275 = shen_apply_direct(ctx, "cn", 2, a275);
  }
  KLObject* t282 = shen_intern(ctx, "shen.s");
  KLObject* t273;
  {
    KLObject* a273[] = {t271, t275, t282};
    t273 = shen_apply_direct(ctx, "shen.app", 3, a273);
  }
  KLObject* t283 = shen_apply_direct(ctx, "stoutput", 0, NULL);
  KLObject* t272;
  {
    KLObject* a272[] = {t273, t283};
    t272 = shen_apply_direct(ctx, "pr", 2, a272);
  }
  KLObject* t285 = shen_tl(ctx, t232);
  KLObject* t286 = shen_tl(ctx, t285);
  KLObject* t287 = shen_tl(ctx, t286);
  {
    KLObject* n288_0 = t287;
    t232 = n288_0;
    goto tail_start_kl_shen_2ework_2dthrough_8;
  }
  KLObject* t288 = NULL;
    t263 = t288;
  }
      t233 = t263;
    } else {
  KLObject* t290 = shen_cons_p(ctx, t232);
    if (!shen_is_boolean(ctx, t290))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t290)) {
  KLObject* t292 = shen_hd(ctx, t232);
  KLObject* t294 = shen_string(ctx, ":");
  KLObject* t293;
  {
    KLObject* a293[] = {t294};
    t293 = shen_apply_direct(ctx, "intern", 1, a293);
  }
  KLObject* t295 = shen_intern(ctx, "A");
  KLObject* t297 = shen_tl(ctx, t232);
  KLObject* t298 = shen_cons(ctx, t295, t297);
  KLObject* t299 = shen_cons(ctx, t293, t298);
  KLObject* t300 = shen_cons(ctx, t292, t299);
  {
    KLObject* n301_0 = t300;
    t232 = n301_0;
    goto tail_start_kl_shen_2ework_2dthrough_8;
  }
  KLObject* t301 = NULL;
      t233 = t301;
    } else {
  KLObject* t302 = shen_true(ctx);
    if (!shen_is_boolean(ctx, t302))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t302)) {
  KLObject* t304 = shen_string(ctx, "implementation error in shen.work-through");
  KLObject* t303;
  {
    KLObject* a303[] = {t304};
    t303 = shen_tail_apply_direct(ctx, "simple-error", 1, a303);
  }
      t233 = t303;
    } else {
      shen_simple_error(ctx, "No true case found for cond");
      t233 = shen_empty_list(ctx);
    }
    }
    }
    }
  }
    return t233;
  }
}

static KLObject* native_kl_shen_2epretty_2dtype_9 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t305 = objects[0];
  tail_start_kl_shen_2epretty_2dtype_9: ;
  KLObject* t306;
  {
  KLObject* t309 = shen_cons_p(ctx, t305);
  KLObject* t307;
  if (!shen_is_boolean(ctx, t309))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t309)) {
    t307 = t309;
  } else {
  KLObject* t312 = shen_hd(ctx, t305);
  KLObject* t313 = shen_cons_p(ctx, t312);
  KLObject* t310;
  if (!shen_is_boolean(ctx, t313))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t313)) {
    t310 = t313;
  } else {
  KLObject* t315 = shen_intern(ctx, "list");
  KLObject* t317 = shen_hd(ctx, t305);
  KLObject* t318 = shen_hd(ctx, t317);
  KLObject* t319 = shen_eq(ctx, t315, t318);
  KLObject* t314;
  if (!shen_is_boolean(ctx, t319))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t319)) {
    t314 = t319;
  } else {
  KLObject* t322 = shen_hd(ctx, t305);
  KLObject* t323 = shen_tl(ctx, t322);
  KLObject* t324 = shen_cons_p(ctx, t323);
  KLObject* t320;
  if (!shen_is_boolean(ctx, t324))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t324)) {
    t320 = t324;
  } else {
  KLObject* t326 = shen_empty_list(ctx);
  KLObject* t328 = shen_hd(ctx, t305);
  KLObject* t329 = shen_tl(ctx, t328);
  KLObject* t330 = shen_tl(ctx, t329);
  KLObject* t331 = shen_eq(ctx, t326, t330);
  KLObject* t325;
  if (!shen_is_boolean(ctx, t331))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t331)) {
    t325 = t331;
  } else {
  KLObject* t334 = shen_tl(ctx, t305);
  KLObject* t335 = shen_cons_p(ctx, t334);
  KLObject* t332;
  if (!shen_is_boolean(ctx, t335))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t335)) {
    t332 = t335;
  } else {
  KLObject* t337 = shen_intern(ctx, "-->");
  KLObject* t339 = shen_tl(ctx, t305);
  KLObject* t340 = shen_hd(ctx, t339);
  KLObject* t341 = shen_eq(ctx, t337, t340);
  KLObject* t336;
  if (!shen_is_boolean(ctx, t341))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t341)) {
    t336 = t341;
  } else {
  KLObject* t344 = shen_tl(ctx, t305);
  KLObject* t345 = shen_tl(ctx, t344);
  KLObject* t346 = shen_cons_p(ctx, t345);
  KLObject* t342;
  if (!shen_is_boolean(ctx, t346))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t346)) {
    t342 = t346;
  } else {
  KLObject* t349 = shen_tl(ctx, t305);
  KLObject* t350 = shen_tl(ctx, t349);
  KLObject* t351 = shen_hd(ctx, t350);
  KLObject* t352 = shen_cons_p(ctx, t351);
  KLObject* t347;
  if (!shen_is_boolean(ctx, t352))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t352)) {
    t347 = t352;
  } else {
  KLObject* t354 = shen_intern(ctx, "str");
  KLObject* t356 = shen_tl(ctx, t305);
  KLObject* t357 = shen_tl(ctx, t356);
  KLObject* t358 = shen_hd(ctx, t357);
  KLObject* t359 = shen_hd(ctx, t358);
  KLObject* t360 = shen_eq(ctx, t354, t359);
  KLObject* t353;
  if (!shen_is_boolean(ctx, t360))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t360)) {
    t353 = t360;
  } else {
  KLObject* t363 = shen_tl(ctx, t305);
  KLObject* t364 = shen_tl(ctx, t363);
  KLObject* t365 = shen_hd(ctx, t364);
  KLObject* t366 = shen_tl(ctx, t365);
  KLObject* t367 = shen_cons_p(ctx, t366);
  KLObject* t361;
  if (!shen_is_boolean(ctx, t367))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t367)) {
    t361 = t367;
  } else {
  KLObject* t370 = shen_tl(ctx, t305);
  KLObject* t371 = shen_tl(ctx, t370);
  KLObject* t372 = shen_hd(ctx, t371);
  KLObject* t373 = shen_tl(ctx, t372);
  KLObject* t374 = shen_hd(ctx, t373);
  KLObject* t375 = shen_cons_p(ctx, t374);
  KLObject* t368;
  if (!shen_is_boolean(ctx, t375))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t375)) {
    t368 = t375;
  } else {
  KLObject* t377 = shen_intern(ctx, "list");
  KLObject* t379 = shen_tl(ctx, t305);
  KLObject* t380 = shen_tl(ctx, t379);
  KLObject* t381 = shen_hd(ctx, t380);
  KLObject* t382 = shen_tl(ctx, t381);
  KLObject* t383 = shen_hd(ctx, t382);
  KLObject* t384 = shen_hd(ctx, t383);
  KLObject* t385 = shen_eq(ctx, t377, t384);
  KLObject* t376;
  if (!shen_is_boolean(ctx, t385))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t385)) {
    t376 = t385;
  } else {
  KLObject* t388 = shen_tl(ctx, t305);
  KLObject* t389 = shen_tl(ctx, t388);
  KLObject* t390 = shen_hd(ctx, t389);
  KLObject* t391 = shen_tl(ctx, t390);
  KLObject* t392 = shen_hd(ctx, t391);
  KLObject* t393 = shen_tl(ctx, t392);
  KLObject* t394 = shen_cons_p(ctx, t393);
  KLObject* t386;
  if (!shen_is_boolean(ctx, t394))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t394)) {
    t386 = t394;
  } else {
  KLObject* t396 = shen_empty_list(ctx);
  KLObject* t398 = shen_tl(ctx, t305);
  KLObject* t399 = shen_tl(ctx, t398);
  KLObject* t400 = shen_hd(ctx, t399);
  KLObject* t401 = shen_tl(ctx, t400);
  KLObject* t402 = shen_hd(ctx, t401);
  KLObject* t403 = shen_tl(ctx, t402);
  KLObject* t404 = shen_tl(ctx, t403);
  KLObject* t405 = shen_eq(ctx, t396, t404);
  KLObject* t395;
  if (!shen_is_boolean(ctx, t405))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t405)) {
    t395 = t405;
  } else {
  KLObject* t408 = shen_tl(ctx, t305);
  KLObject* t409 = shen_tl(ctx, t408);
  KLObject* t410 = shen_hd(ctx, t409);
  KLObject* t411 = shen_tl(ctx, t410);
  KLObject* t412 = shen_tl(ctx, t411);
  KLObject* t413 = shen_cons_p(ctx, t412);
  KLObject* t406;
  if (!shen_is_boolean(ctx, t413))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t413)) {
    t406 = t413;
  } else {
  KLObject* t415 = shen_empty_list(ctx);
  KLObject* t417 = shen_tl(ctx, t305);
  KLObject* t418 = shen_tl(ctx, t417);
  KLObject* t419 = shen_hd(ctx, t418);
  KLObject* t420 = shen_tl(ctx, t419);
  KLObject* t421 = shen_tl(ctx, t420);
  KLObject* t422 = shen_tl(ctx, t421);
  KLObject* t423 = shen_eq(ctx, t415, t422);
  KLObject* t414;
  if (!shen_is_boolean(ctx, t423))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t423)) {
    t414 = t423;
  } else {
  KLObject* t425 = shen_empty_list(ctx);
  KLObject* t427 = shen_tl(ctx, t305);
  KLObject* t428 = shen_tl(ctx, t427);
  KLObject* t429 = shen_tl(ctx, t428);
  KLObject* t430 = shen_eq(ctx, t425, t429);
  KLObject* t424;
  if (!shen_is_boolean(ctx, t430))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t430)) {
    t424 = t430;
  } else {
  KLObject* t432 = shen_hd(ctx, t305);
  KLObject* t433 = shen_tl(ctx, t432);
  KLObject* t434 = shen_hd(ctx, t433);
  KLObject* t436 = shen_tl(ctx, t305);
  KLObject* t437 = shen_tl(ctx, t436);
  KLObject* t438 = shen_hd(ctx, t437);
  KLObject* t439 = shen_tl(ctx, t438);
  KLObject* t440 = shen_hd(ctx, t439);
  KLObject* t441 = shen_tl(ctx, t440);
  KLObject* t442 = shen_hd(ctx, t441);
  KLObject* t443 = shen_eq(ctx, t434, t442);
    if (!shen_is_boolean(ctx, t443))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t424 = t443;
  }
    if (!shen_is_boolean(ctx, t424))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t414 = t424;
  }
    if (!shen_is_boolean(ctx, t414))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t406 = t414;
  }
    if (!shen_is_boolean(ctx, t406))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t395 = t406;
  }
    if (!shen_is_boolean(ctx, t395))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t386 = t395;
  }
    if (!shen_is_boolean(ctx, t386))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t376 = t386;
  }
    if (!shen_is_boolean(ctx, t376))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t368 = t376;
  }
    if (!shen_is_boolean(ctx, t368))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t361 = t368;
  }
    if (!shen_is_boolean(ctx, t361))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t353 = t361;
  }
    if (!shen_is_boolean(ctx, t353))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t347 = t353;
  }
    if (!shen_is_boolean(ctx, t347))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t342 = t347;
  }
    if (!shen_is_boolean(ctx, t342))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t336 = t342;
  }
    if (!shen_is_boolean(ctx, t336))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t332 = t336;
  }
    if (!shen_is_boolean(ctx, t332))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t325 = t332;
  }
    if (!shen_is_boolean(ctx, t325))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t320 = t325;
  }
    if (!shen_is_boolean(ctx, t320))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t314 = t320;
  }
    if (!shen_is_boolean(ctx, t314))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t310 = t314;
  }
    if (!shen_is_boolean(ctx, t310))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t307 = t310;
  }
    if (!shen_is_boolean(ctx, t307))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t307)) {
  KLObject* t445 = shen_tl(ctx, t305);
  KLObject* t446 = shen_tl(ctx, t445);
  KLObject* t447 = shen_hd(ctx, t446);
  KLObject* t448 = shen_tl(ctx, t447);
  KLObject* t449 = shen_hd(ctx, t448);
  KLObject* t450 = shen_intern(ctx, "==>");
  KLObject* t452 = shen_tl(ctx, t305);
  KLObject* t453 = shen_tl(ctx, t452);
  KLObject* t454 = shen_hd(ctx, t453);
  KLObject* t455 = shen_tl(ctx, t454);
  KLObject* t456 = shen_tl(ctx, t455);
  KLObject* t457 = shen_cons(ctx, t450, t456);
  KLObject* t458 = shen_cons(ctx, t449, t457);
      t306 = t458;
    } else {
  KLObject* t460 = shen_cons_p(ctx, t305);
    if (!shen_is_boolean(ctx, t460))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t460)) {
  KLObject* t462;
  {
    Vector* caps_4 = shen_vector(ctx, 0);
    t462 = shen_native_closure(ctx, 1, &lambda_4, caps_4);
  }
  KLObject* t461;
  {
    KLObject* a461[] = {t462, t305};
    t461 = shen_tail_apply_direct(ctx, "map", 2, a461);
  }
      t306 = t461;
    } else {
  KLObject* t467 = shen_true(ctx);
    if (!shen_is_boolean(ctx, t467))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t467)) {
      t306 = t305;
    } else {
      shen_simple_error(ctx, "No true case found for cond");
      t306 = shen_empty_list(ctx);
    }
    }
    }
  }
    return t306;
  }
}

static KLObject* native_kl_shen_2etype_2derror_10 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  (void)function_object;
  (void)arguments;
  {
  tail_start_kl_shen_2etype_2derror_10: ;
  KLObject* t470 = shen_string(ctx, "type error\n");
  KLObject* t469;
  {
    KLObject* a469[] = {t470};
    t469 = shen_tail_apply_direct(ctx, "simple-error", 1, a469);
  }
    return t469;
  }
}

static KLObject* native_kl_bootstrap_11 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t471 = objects[0];
  tail_start_kl_bootstrap_11: ;
  KLObject* t472;
  {
    KLObject* a472[] = {t471};
    t472 = shen_apply_direct(ctx, "shen.klfile", 1, a472);
  }
  KLObject* t474;
  {
    KLObject* a474[] = {t471};
    t474 = sp_boehm_phase_0(ctx, "read-file", 1, a474);
  }
  KLObject* t478 = shen_intern(ctx, "out");
  KLObject* t476;
  {
    KLObject* a476[] = {t472, t478};
    t476 = shen_apply_direct(ctx, "open", 2, a476);
  }
  KLObject* t480;
  {
    Vector* caps_5 = shen_vector(ctx, 0);
    t480 = shen_native_closure(ctx, 1, &lambda_5, caps_5);
  }
  KLObject* t479;
  {
    KLObject* a479[] = {t480, t474};
    t479 = shen_apply_direct(ctx, "map", 2, a479);
  }
  KLObject* t486;
  {
    KLObject* a486[] = {t479, t476};
    t486 = shen_apply_direct(ctx, "shen.write-kl", 2, a486);
  }
    return t472;
  }
}

static KLObject* native_kl_shen_2epartial_12 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t490 = objects[0];
  tail_start_kl_shen_2epartial_12: ;
  KLObject* t491;
  {
  KLObject* t494 = shen_cons_p(ctx, t490);
  KLObject* t492;
  if (!shen_is_boolean(ctx, t494))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t494)) {
    t492 = t494;
  } else {
  KLObject* t496 = shen_intern(ctx, "shen.f-error");
  KLObject* t498 = shen_hd(ctx, t490);
  KLObject* t499 = shen_eq(ctx, t496, t498);
  KLObject* t495;
  if (!shen_is_boolean(ctx, t499))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t499)) {
    t495 = t499;
  } else {
  KLObject* t502 = shen_tl(ctx, t490);
  KLObject* t503 = shen_cons_p(ctx, t502);
  KLObject* t500;
  if (!shen_is_boolean(ctx, t503))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t503)) {
    t500 = t503;
  } else {
  KLObject* t504 = shen_empty_list(ctx);
  KLObject* t506 = shen_tl(ctx, t490);
  KLObject* t507 = shen_tl(ctx, t506);
  KLObject* t508 = shen_eq(ctx, t504, t507);
    if (!shen_is_boolean(ctx, t508))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t500 = t508;
  }
    if (!shen_is_boolean(ctx, t500))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t495 = t500;
  }
    if (!shen_is_boolean(ctx, t495))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t492 = t495;
  }
    if (!shen_is_boolean(ctx, t492))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t492)) {
  KLObject* t509 = shen_intern(ctx, "simple-error");
  KLObject* t511 = shen_string(ctx, "partial function ");
  KLObject* t514 = shen_tl(ctx, t490);
  KLObject* t515 = shen_hd(ctx, t514);
  KLObject* t512;
  {
    KLObject* a512[] = {t515};
    t512 = shen_apply_direct(ctx, "str", 1, a512);
  }
  KLObject* t510;
  {
    KLObject* a510[] = {t511, t512};
    t510 = shen_apply_direct(ctx, "cn", 2, a510);
  }
  KLObject* t516 = shen_empty_list(ctx);
  KLObject* t517 = shen_cons(ctx, t510, t516);
  KLObject* t518 = shen_cons(ctx, t509, t517);
      t491 = t518;
    } else {
  KLObject* t520 = shen_cons_p(ctx, t490);
    if (!shen_is_boolean(ctx, t520))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t520)) {
  KLObject* t522;
  {
    Vector* caps_6 = shen_vector(ctx, 0);
    t522 = shen_native_closure(ctx, 1, &lambda_6, caps_6);
  }
  KLObject* t521;
  {
    KLObject* a521[] = {t522, t490};
    t521 = shen_tail_apply_direct(ctx, "map", 2, a521);
  }
      t491 = t521;
    } else {
  KLObject* t527 = shen_true(ctx);
    if (!shen_is_boolean(ctx, t527))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t527)) {
      t491 = t490;
    } else {
      shen_simple_error(ctx, "No true case found for cond");
      t491 = shen_empty_list(ctx);
    }
    }
    }
  }
    return t491;
  }
}

static KLObject* native_kl_shen_2ewrite_2dkl_13 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t529 = objects[0];
    KLObject* t530 = objects[1];
  tail_start_kl_shen_2ewrite_2dkl_13: ;
  KLObject* t531;
  {
  KLObject* t532 = shen_empty_list(ctx);
  KLObject* t534 = shen_eq(ctx, t532, t529);
    if (!shen_is_boolean(ctx, t534))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t534)) {
  KLObject* t535;
  {
    KLObject* a535[] = {t530};
    t535 = shen_tail_apply_direct(ctx, "close", 1, a535);
  }
      t531 = t535;
    } else {
  KLObject* t539 = shen_cons_p(ctx, t529);
  KLObject* t537;
  if (!shen_is_boolean(ctx, t539))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t539)) {
    t537 = t539;
  } else {
  KLObject* t541 = shen_hd(ctx, t529);
  KLObject* t542 = shen_cons_p(ctx, t541);
    if (!shen_is_boolean(ctx, t542))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t537 = t542;
  }
    if (!shen_is_boolean(ctx, t537))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t537)) {
  KLObject* t544 = shen_tl(ctx, t529);
  KLObject* t547 = shen_hd(ctx, t529);
  KLObject* t545;
  {
    KLObject* a545[] = {t547, t530};
    t545 = shen_apply_direct(ctx, "shen.write-kl-h", 2, a545);
  }
  {
    KLObject* n550_0 = t544;
    KLObject* n550_1 = t530;
    t529 = n550_0;
    t530 = n550_1;
    goto tail_start_kl_shen_2ewrite_2dkl_13;
  }
  KLObject* t550 = NULL;
      t531 = t550;
    } else {
  KLObject* t552 = shen_cons_p(ctx, t529);
    if (!shen_is_boolean(ctx, t552))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t552)) {
  KLObject* t554 = shen_tl(ctx, t529);
  {
    KLObject* n556_0 = t554;
    KLObject* n556_1 = t530;
    t529 = n556_0;
    t530 = n556_1;
    goto tail_start_kl_shen_2ewrite_2dkl_13;
  }
  KLObject* t556 = NULL;
      t531 = t556;
    } else {
  KLObject* t557 = shen_true(ctx);
    if (!shen_is_boolean(ctx, t557))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t557)) {
  KLObject* t559 = shen_string(ctx, "partial function shen.write-kl");
  KLObject* t558;
  {
    KLObject* a558[] = {t559};
    t558 = shen_tail_apply_direct(ctx, "simple-error", 1, a558);
  }
      t531 = t558;
    } else {
      shen_simple_error(ctx, "No true case found for cond");
      t531 = shen_empty_list(ctx);
    }
    }
    }
    }
  }
    return t531;
  }
}

static KLObject* native_kl_shen_2ewrite_2dkl_2dh_14 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t560 = objects[0];
    KLObject* t561 = objects[1];
  tail_start_kl_shen_2ewrite_2dkl_2dh_14: ;
  KLObject* t562;
  {
  KLObject* t565 = shen_cons_p(ctx, t560);
  KLObject* t563;
  if (!shen_is_boolean(ctx, t565))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t565)) {
    t563 = t565;
  } else {
  KLObject* t567 = shen_intern(ctx, "defun");
  KLObject* t569 = shen_hd(ctx, t560);
  KLObject* t570 = shen_eq(ctx, t567, t569);
  KLObject* t566;
  if (!shen_is_boolean(ctx, t570))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t570)) {
    t566 = t570;
  } else {
  KLObject* t573 = shen_tl(ctx, t560);
  KLObject* t574 = shen_cons_p(ctx, t573);
  KLObject* t571;
  if (!shen_is_boolean(ctx, t574))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t574)) {
    t571 = t574;
  } else {
  KLObject* t576 = shen_intern(ctx, "fail");
  KLObject* t578 = shen_tl(ctx, t560);
  KLObject* t579 = shen_hd(ctx, t578);
  KLObject* t580 = shen_eq(ctx, t576, t579);
  KLObject* t575;
  if (!shen_is_boolean(ctx, t580))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t580)) {
    t575 = t580;
  } else {
  KLObject* t583 = shen_tl(ctx, t560);
  KLObject* t584 = shen_tl(ctx, t583);
  KLObject* t585 = shen_cons_p(ctx, t584);
  KLObject* t581;
  if (!shen_is_boolean(ctx, t585))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t585)) {
    t581 = t585;
  } else {
  KLObject* t587 = shen_empty_list(ctx);
  KLObject* t589 = shen_tl(ctx, t560);
  KLObject* t590 = shen_tl(ctx, t589);
  KLObject* t591 = shen_hd(ctx, t590);
  KLObject* t592 = shen_eq(ctx, t587, t591);
  KLObject* t586;
  if (!shen_is_boolean(ctx, t592))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t592)) {
    t586 = t592;
  } else {
  KLObject* t595 = shen_tl(ctx, t560);
  KLObject* t596 = shen_tl(ctx, t595);
  KLObject* t597 = shen_tl(ctx, t596);
  KLObject* t598 = shen_cons_p(ctx, t597);
  KLObject* t593;
  if (!shen_is_boolean(ctx, t598))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t598)) {
    t593 = t598;
  } else {
  KLObject* t599 = shen_empty_list(ctx);
  KLObject* t601 = shen_tl(ctx, t560);
  KLObject* t602 = shen_tl(ctx, t601);
  KLObject* t603 = shen_tl(ctx, t602);
  KLObject* t604 = shen_tl(ctx, t603);
  KLObject* t605 = shen_eq(ctx, t599, t604);
    if (!shen_is_boolean(ctx, t605))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t593 = t605;
  }
    if (!shen_is_boolean(ctx, t593))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t586 = t593;
  }
    if (!shen_is_boolean(ctx, t586))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t581 = t586;
  }
    if (!shen_is_boolean(ctx, t581))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t575 = t581;
  }
    if (!shen_is_boolean(ctx, t575))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t571 = t575;
  }
    if (!shen_is_boolean(ctx, t571))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t566 = t571;
  }
    if (!shen_is_boolean(ctx, t566))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t563 = t566;
  }
    if (!shen_is_boolean(ctx, t563))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t563)) {
  KLObject* t607 = shen_string(ctx, "(defun fail () shen.fail!)");
  KLObject* t606;
  {
    KLObject* a606[] = {t607, t561};
    t606 = shen_tail_apply_direct(ctx, "pr", 2, a606);
  }
      t562 = t606;
    } else {
  KLObject* t609 = shen_true(ctx);
    if (!shen_is_boolean(ctx, t609))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t609)) {
  KLObject* t613 = shen_string(ctx, "\n\n");
  KLObject* t614 = shen_intern(ctx, "shen.r");
  KLObject* t611;
  {
    KLObject* a611[] = {t560, t613, t614};
    t611 = shen_apply_direct(ctx, "shen.app", 3, a611);
  }
  KLObject* t610;
  {
    KLObject* a610[] = {t611, t561};
    t610 = shen_tail_apply_direct(ctx, "pr", 2, a610);
  }
      t562 = t610;
    } else {
      shen_simple_error(ctx, "No true case found for cond");
      t562 = shen_empty_list(ctx);
    }
    }
  }
    return t562;
  }
}

static KLObject* native_kl_shen_2eklfile_15 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t616 = objects[0];
  tail_start_kl_shen_2eklfile_15: ;
  KLObject* t617;
  {
  KLObject* t618 = shen_string(ctx, "");
  KLObject* t620 = shen_eq(ctx, t618, t616);
    if (!shen_is_boolean(ctx, t620))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t620)) {
  KLObject* t621 = shen_string(ctx, ".kl");
      t617 = t621;
    } else {
  KLObject* t622 = shen_string(ctx, ".shen");
  KLObject* t624 = shen_eq(ctx, t622, t616);
    if (!shen_is_boolean(ctx, t624))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t624)) {
  KLObject* t625 = shen_string(ctx, ".kl");
      t617 = t625;
    } else {
  KLObject* t626;
  {
    KLObject* a626[] = {t616};
    t626 = shen_apply_direct(ctx, "shen.+string?", 1, a626);
  }
    if (!shen_is_boolean(ctx, t626))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t626)) {
  KLObject* t629;
  {
    KLObject* a629[] = {t616};
    t629 = shen_apply_direct(ctx, "hdstr", 1, a629);
  }
  KLObject* t632;
  {
    KLObject* a632[] = {t616};
    t632 = shen_apply_direct(ctx, "tlstr", 1, a632);
  }
  KLObject* t631;
  {
    KLObject* a631[] = {t632};
    t631 = shen_apply_direct(ctx, "shen.klfile", 1, a631);
  }
  KLObject* t628;
  {
    KLObject* a628[] = {t629, t631};
    t628 = shen_tail_apply_direct(ctx, "@s", 2, a628);
  }
      t617 = t628;
    } else {
  KLObject* t634 = shen_true(ctx);
    if (!shen_is_boolean(ctx, t634))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t634)) {
  KLObject* t636 = shen_string(ctx, "partial function shen.klfile");
  KLObject* t635;
  {
    KLObject* a635[] = {t636};
    t635 = shen_tail_apply_direct(ctx, "simple-error", 1, a635);
  }
      t617 = t635;
    } else {
      shen_simple_error(ctx, "No true case found for cond");
      t617 = shen_empty_list(ctx);
    }
    }
    }
    }
  }
    return t617;
  }
}

void shen_kernel_aot_install_load (shen_context* ctx)
{
  shen_register_defun(ctx, "load", 1, &native_kl_load_0);
  shen_register_defun(ctx, "shen.load-help", 2, &native_kl_shen_2eload_2dhelp_1);
  shen_register_defun(ctx, "shen.eval-and-print", 1, &native_kl_shen_2eeval_2dand_2dprint_2);
  shen_register_defun(ctx, "shen.check-eval-and-print", 1, &native_kl_shen_2echeck_2deval_2dand_2dprint_3);
  shen_register_defun(ctx, "shen.typetable", 1, &native_kl_shen_2etypetable_4);
  shen_register_defun(ctx, "shen.type-F", 2, &native_kl_shen_2etype_2dF_5);
  shen_register_defun(ctx, "shen.assumetypes", 1, &native_kl_shen_2eassumetypes_6);
  shen_register_defun(ctx, "shen.unwind-types", 2, &native_kl_shen_2eunwind_2dtypes_7);
  shen_register_defun(ctx, "shen.work-through", 1, &native_kl_shen_2ework_2dthrough_8);
  shen_register_defun(ctx, "shen.pretty-type", 1, &native_kl_shen_2epretty_2dtype_9);
  shen_register_defun(ctx, "shen.type-error", 0, &native_kl_shen_2etype_2derror_10);
  shen_register_defun(ctx, "bootstrap", 1, &native_kl_bootstrap_11);
  shen_register_defun(ctx, "shen.partial", 1, &native_kl_shen_2epartial_12);
  shen_register_defun(ctx, "shen.write-kl", 2, &native_kl_shen_2ewrite_2dkl_13);
  shen_register_defun(ctx, "shen.write-kl-h", 2, &native_kl_shen_2ewrite_2dkl_2dh_14);
  shen_register_defun(ctx, "shen.klfile", 1, &native_kl_shen_2eklfile_15);
}
