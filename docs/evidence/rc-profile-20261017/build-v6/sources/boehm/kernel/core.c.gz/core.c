#include "rc_phase_profile.h"
/* Generated always-AOT kernel module (KL defuns -> NativeFunctions).
 * Install after tree-walker boot overwrites UserFunctions.
 * Toplevel declare/set stay on the walker. Not overlay-after-load.
 * Sidecar tests stay on the tree-walker. Not a second main. Source: core.kl
 */
#include "abi.h"

void shen_kernel_aot_install_core (shen_context* ctx);

static KLObject* lambda_0 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t196 = objects[0];
  KLObject* t197;
  {
    KLObject* a197[] = {t196};
    t197 = shen_tail_apply_direct(ctx, "shen.shen->kl-h", 1, a197);
  }
    return t197;
  }
}

static KLObject* lambda_1 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t206 = objects[0];
  KLObject* t207;
  {
    KLObject* a207[] = {t206};
    t207 = shen_tail_apply_direct(ctx, "shen.<define>", 1, a207);
  }
    return t207;
  }
}

static KLObject* lambda_2 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t298 = objects[0];
  KLObject* t299;
  {
    KLObject* a299[] = {t298};
    t299 = shen_tail_apply_direct(ctx, "fst", 1, a299);
  }
    return t299;
  }
}

static KLObject* lambda_3 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  KLObject* t307 = shen_vector_get(ctx, caps, 0);
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t308 = objects[0];
  KLObject* t309;
  {
    KLObject* a309[] = {t307, t308};
    t309 = shen_tail_apply_direct(ctx, "shen.free-var-chk", 2, a309);
  }
    return t309;
  }
}

static KLObject* lambda_4 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t357 = objects[0];
  KLObject* t358;
  {
    KLObject* a358[] = {t357};
    t358 = shen_tail_apply_direct(ctx, "shen.unprotect", 1, a358);
  }
    return t358;
  }
}

static KLObject* lambda_5 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t1199 = objects[0];
  KLObject* t1202 = shen_string(ctx, " ");
  KLObject* t1205 = shen_string(ctx, "");
  KLObject* t1206 = shen_intern(ctx, "shen.a");
  KLObject* t1203;
  {
    KLObject* a1203[] = {t1199, t1205, t1206};
    t1203 = shen_apply_direct(ctx, "shen.app", 3, a1203);
  }
  KLObject* t1201;
  {
    KLObject* a1201[] = {t1202, t1203};
    t1201 = shen_apply_direct(ctx, "cn", 2, a1201);
  }
  KLObject* t1207 = shen_apply_direct(ctx, "stoutput", 0, NULL);
  KLObject* t1200;
  {
    KLObject* a1200[] = {t1201, t1207};
    t1200 = shen_tail_apply_direct(ctx, "pr", 2, a1200);
  }
    return t1200;
  }
}

static KLObject* lambda_6 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  KLObject* t1869 = shen_vector_get(ctx, caps, 0);
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t1870 = objects[0];
  KLObject* t1872 = shen_empty_list(ctx);
  KLObject* t1873;
  {
    KLObject* a1873[] = {t1870};
    t1873 = shen_apply_direct(ctx, "fst", 1, a1873);
  }
  KLObject* t1877;
  {
    KLObject* a1877[] = {t1870};
    t1877 = shen_apply_direct(ctx, "snd", 1, a1877);
  }
  KLObject* t1876;
  {
    KLObject* a1876[] = {t1877};
    t1876 = shen_apply_direct(ctx, "shen.alpha-convert", 1, a1876);
  }
  KLObject* t1871;
  {
    KLObject* a1871[] = {t1872, t1873, t1869, t1876};
    t1871 = shen_tail_apply_direct(ctx, "shen.triple-stack", 4, a1871);
  }
    return t1871;
  }
}

static KLObject* lambda_7 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t1924 = objects[0];
  KLObject* t1925;
  {
    KLObject* a1925[] = {t1924};
    t1925 = shen_tail_apply_direct(ctx, "shen.alpha-convert", 1, a1925);
  }
    return t1925;
  }
}

static KLObject* lambda_8 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t1983 = objects[0];
  KLObject* t1984;
  {
    KLObject* a1984[] = {t1983};
    t1984 = shen_tail_apply_direct(ctx, "shen.alpha-convert", 1, a1984);
  }
    return t1984;
  }
}

static KLObject* lambda_9 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t1991 = objects[0];
  KLObject* t1992;
  {
    KLObject* a1992[] = {t1991};
    t1992 = shen_tail_apply_direct(ctx, "shen.alpha-convert", 1, a1992);
  }
    return t1992;
  }
}

static KLObject* lambda_10 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  KLObject* t2318 = shen_vector_get(ctx, caps, 0);
  KLObject* t2319 = shen_vector_get(ctx, caps, 1);
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t2320 = objects[0];
  KLObject* t2321;
  {
    KLObject* a2321[] = {t2318, t2319, t2320};
    t2321 = shen_tail_apply_direct(ctx, "shen.beta", 3, a2321);
  }
    return t2321;
  }
}

static KLObject* native_kl_shen_2eshen_2d_3ekl_0 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t0 = objects[0];
  tail_start_kl_shen_2eshen_2d_3ekl_0: ;
  KLObject* t1;
  {
    KLObject* a1[] = {t0};
    t1 = shen_apply_direct(ctx, "shen.shen->kl-h", 1, a1);
  }
  KLObject* t3;
  {
    KLObject* a3[] = {t1};
    t3 = shen_tail_apply_direct(ctx, "shen.record-and-evaluate", 1, a3);
  }
    return t3;
  }
}

static KLObject* native_kl_shen_2erecord_2dand_2devaluate_1 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t5 = objects[0];
  tail_start_kl_shen_2erecord_2dand_2devaluate_1: ;
  KLObject* t6;
  {
  KLObject* t9 = shen_cons_p(ctx, t5);
  KLObject* t7;
  if (!shen_is_boolean(ctx, t9))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t9)) {
    t7 = t9;
  } else {
  KLObject* t11 = shen_intern(ctx, "defun");
  KLObject* t13 = shen_hd(ctx, t5);
  KLObject* t14 = shen_eq(ctx, t11, t13);
  KLObject* t10;
  if (!shen_is_boolean(ctx, t14))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t14)) {
    t10 = t14;
  } else {
  KLObject* t17 = shen_tl(ctx, t5);
  KLObject* t18 = shen_cons_p(ctx, t17);
  KLObject* t15;
  if (!shen_is_boolean(ctx, t18))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t18)) {
    t15 = t18;
  } else {
  KLObject* t21 = shen_tl(ctx, t5);
  KLObject* t22 = shen_tl(ctx, t21);
  KLObject* t23 = shen_cons_p(ctx, t22);
  KLObject* t19;
  if (!shen_is_boolean(ctx, t23))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t23)) {
    t19 = t23;
  } else {
  KLObject* t26 = shen_tl(ctx, t5);
  KLObject* t27 = shen_tl(ctx, t26);
  KLObject* t28 = shen_tl(ctx, t27);
  KLObject* t29 = shen_cons_p(ctx, t28);
  KLObject* t24;
  if (!shen_is_boolean(ctx, t29))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t29)) {
    t24 = t29;
  } else {
  KLObject* t30 = shen_empty_list(ctx);
  KLObject* t32 = shen_tl(ctx, t5);
  KLObject* t33 = shen_tl(ctx, t32);
  KLObject* t34 = shen_tl(ctx, t33);
  KLObject* t35 = shen_tl(ctx, t34);
  KLObject* t36 = shen_eq(ctx, t30, t35);
    if (!shen_is_boolean(ctx, t36))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t24 = t36;
  }
    if (!shen_is_boolean(ctx, t24))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t19 = t24;
  }
    if (!shen_is_boolean(ctx, t19))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t15 = t19;
  }
    if (!shen_is_boolean(ctx, t15))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t10 = t15;
  }
    if (!shen_is_boolean(ctx, t10))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t7 = t10;
  }
    if (!shen_is_boolean(ctx, t7))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t7)) {
  KLObject* t40 = shen_tl(ctx, t5);
  KLObject* t41 = shen_hd(ctx, t40);
  KLObject* t38;
  {
    KLObject* a38[] = {t41};
    t38 = shen_apply_direct(ctx, "shen.sysfunc?", 1, a38);
  }
  KLObject* t37;
  if (!shen_is_boolean(ctx, t38))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t38)) {
  KLObject* t45 = shen_tl(ctx, t5);
  KLObject* t46 = shen_hd(ctx, t45);
  KLObject* t47 = shen_string(ctx, " is not a legitimate function name\n");
  KLObject* t48 = shen_intern(ctx, "shen.a");
  KLObject* t43;
  {
    KLObject* a43[] = {t46, t47, t48};
    t43 = shen_apply_direct(ctx, "shen.app", 3, a43);
  }
  KLObject* t42;
  {
    KLObject* a42[] = {t43};
    t42 = shen_apply_direct(ctx, "simple-error", 1, a42);
  }
    t37 = t42;
  } else {
  KLObject* t49 = shen_intern(ctx, "shen.skip");
    t37 = t49;
  }
  KLObject* t52 = shen_tl(ctx, t5);
  KLObject* t53 = shen_hd(ctx, t52);
  KLObject* t56 = shen_tl(ctx, t5);
  KLObject* t57 = shen_tl(ctx, t56);
  KLObject* t58 = shen_hd(ctx, t57);
  KLObject* t54;
  {
    KLObject* a54[] = {t58};
    t54 = shen_apply_direct(ctx, "length", 1, a54);
  }
  KLObject* t50;
  {
    KLObject* a50[] = {t53, t54};
    t50 = shen_apply_direct(ctx, "shen.store-arity", 2, a50);
  }
  KLObject* t61 = shen_tl(ctx, t5);
  KLObject* t62 = shen_hd(ctx, t61);
  KLObject* t59;
  {
    KLObject* a59[] = {t62, t5};
    t59 = shen_apply_direct(ctx, "shen.record-kl", 2, a59);
  }
  KLObject* t65 = shen_eval_kl(ctx, t5);
  KLObject* t68 = shen_tl(ctx, t5);
  KLObject* t69 = shen_hd(ctx, t68);
  KLObject* t66;
  {
    KLObject* a66[] = {t69};
    t66 = shen_tail_apply_direct(ctx, "shen.fn-print", 1, a66);
  }
      t6 = t66;
    } else {
  KLObject* t70 = shen_true(ctx);
    if (!shen_is_boolean(ctx, t70))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t70)) {
      t6 = t5;
    } else {
      shen_simple_error(ctx, "No true case found for cond");
      t6 = shen_empty_list(ctx);
    }
    }
  }
    return t6;
  }
}

static KLObject* native_kl_shen_2eshen_2d_3ekl_2dh_2 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t72 = objects[0];
  tail_start_kl_shen_2eshen_2d_3ekl_2dh_2: ;
  KLObject* t73;
  {
  KLObject* t76 = shen_cons_p(ctx, t72);
  KLObject* t74;
  if (!shen_is_boolean(ctx, t76))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t76)) {
    t74 = t76;
  } else {
  KLObject* t78 = shen_intern(ctx, "define");
  KLObject* t80 = shen_hd(ctx, t72);
  KLObject* t81 = shen_eq(ctx, t78, t80);
  KLObject* t77;
  if (!shen_is_boolean(ctx, t81))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t81)) {
    t77 = t81;
  } else {
  KLObject* t83 = shen_tl(ctx, t72);
  KLObject* t84 = shen_cons_p(ctx, t83);
    if (!shen_is_boolean(ctx, t84))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t77 = t84;
  }
    if (!shen_is_boolean(ctx, t77))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t74 = t77;
  }
    if (!shen_is_boolean(ctx, t74))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t74)) {
  KLObject* t87 = shen_tl(ctx, t72);
  KLObject* t88 = shen_hd(ctx, t87);
  KLObject* t90 = shen_tl(ctx, t72);
  KLObject* t91 = shen_tl(ctx, t90);
  KLObject* t85;
  {
    KLObject* a85[] = {t88, t91};
    t85 = shen_tail_apply_direct(ctx, "shen.shendef->kldef", 2, a85);
  }
      t73 = t85;
    } else {
  KLObject* t94 = shen_cons_p(ctx, t72);
  KLObject* t92;
  if (!shen_is_boolean(ctx, t94))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t94)) {
    t92 = t94;
  } else {
  KLObject* t96 = shen_intern(ctx, "defun");
  KLObject* t98 = shen_hd(ctx, t72);
  KLObject* t99 = shen_eq(ctx, t96, t98);
  KLObject* t95;
  if (!shen_is_boolean(ctx, t99))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t99)) {
    t95 = t99;
  } else {
  KLObject* t102 = shen_tl(ctx, t72);
  KLObject* t103 = shen_cons_p(ctx, t102);
  KLObject* t100;
  if (!shen_is_boolean(ctx, t103))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t103)) {
    t100 = t103;
  } else {
  KLObject* t106 = shen_tl(ctx, t72);
  KLObject* t107 = shen_tl(ctx, t106);
  KLObject* t108 = shen_cons_p(ctx, t107);
  KLObject* t104;
  if (!shen_is_boolean(ctx, t108))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t108)) {
    t104 = t108;
  } else {
  KLObject* t111 = shen_tl(ctx, t72);
  KLObject* t112 = shen_tl(ctx, t111);
  KLObject* t113 = shen_tl(ctx, t112);
  KLObject* t114 = shen_cons_p(ctx, t113);
  KLObject* t109;
  if (!shen_is_boolean(ctx, t114))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t114)) {
    t109 = t114;
  } else {
  KLObject* t115 = shen_empty_list(ctx);
  KLObject* t117 = shen_tl(ctx, t72);
  KLObject* t118 = shen_tl(ctx, t117);
  KLObject* t119 = shen_tl(ctx, t118);
  KLObject* t120 = shen_tl(ctx, t119);
  KLObject* t121 = shen_eq(ctx, t115, t120);
    if (!shen_is_boolean(ctx, t121))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t109 = t121;
  }
    if (!shen_is_boolean(ctx, t109))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t104 = t109;
  }
    if (!shen_is_boolean(ctx, t104))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t100 = t104;
  }
    if (!shen_is_boolean(ctx, t100))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t95 = t100;
  }
    if (!shen_is_boolean(ctx, t95))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t92 = t95;
  }
    if (!shen_is_boolean(ctx, t92))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t92)) {
      t73 = t72;
    } else {
  KLObject* t125 = shen_cons_p(ctx, t72);
  KLObject* t123;
  if (!shen_is_boolean(ctx, t125))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t125)) {
    t123 = t125;
  } else {
  KLObject* t127 = shen_intern(ctx, "type");
  KLObject* t129 = shen_hd(ctx, t72);
  KLObject* t130 = shen_eq(ctx, t127, t129);
  KLObject* t126;
  if (!shen_is_boolean(ctx, t130))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t130)) {
    t126 = t130;
  } else {
  KLObject* t133 = shen_tl(ctx, t72);
  KLObject* t134 = shen_cons_p(ctx, t133);
  KLObject* t131;
  if (!shen_is_boolean(ctx, t134))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t134)) {
    t131 = t134;
  } else {
  KLObject* t137 = shen_tl(ctx, t72);
  KLObject* t138 = shen_tl(ctx, t137);
  KLObject* t139 = shen_cons_p(ctx, t138);
  KLObject* t135;
  if (!shen_is_boolean(ctx, t139))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t139)) {
    t135 = t139;
  } else {
  KLObject* t140 = shen_empty_list(ctx);
  KLObject* t142 = shen_tl(ctx, t72);
  KLObject* t143 = shen_tl(ctx, t142);
  KLObject* t144 = shen_tl(ctx, t143);
  KLObject* t145 = shen_eq(ctx, t140, t144);
    if (!shen_is_boolean(ctx, t145))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t135 = t145;
  }
    if (!shen_is_boolean(ctx, t135))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t131 = t135;
  }
    if (!shen_is_boolean(ctx, t131))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t126 = t131;
  }
    if (!shen_is_boolean(ctx, t126))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t123 = t126;
  }
    if (!shen_is_boolean(ctx, t123))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t123)) {
  KLObject* t146 = shen_intern(ctx, "type");
  KLObject* t148 = shen_tl(ctx, t72);
  KLObject* t149 = shen_hd(ctx, t148);
  KLObject* t152 = shen_tl(ctx, t72);
  KLObject* t153 = shen_tl(ctx, t152);
  KLObject* t154 = shen_hd(ctx, t153);
  KLObject* t150;
  {
    KLObject* a150[] = {t154};
    t150 = shen_apply_direct(ctx, "shen.rcons_form", 1, a150);
  }
  KLObject* t155 = shen_empty_list(ctx);
  KLObject* t156 = shen_cons(ctx, t150, t155);
  KLObject* t157 = shen_cons(ctx, t149, t156);
  KLObject* t158 = shen_cons(ctx, t146, t157);
      t73 = t158;
    } else {
  KLObject* t161 = shen_cons_p(ctx, t72);
  KLObject* t159;
  if (!shen_is_boolean(ctx, t161))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t161)) {
    t159 = t161;
  } else {
  KLObject* t163 = shen_intern(ctx, "input+");
  KLObject* t165 = shen_hd(ctx, t72);
  KLObject* t166 = shen_eq(ctx, t163, t165);
  KLObject* t162;
  if (!shen_is_boolean(ctx, t166))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t166)) {
    t162 = t166;
  } else {
  KLObject* t169 = shen_tl(ctx, t72);
  KLObject* t170 = shen_cons_p(ctx, t169);
  KLObject* t167;
  if (!shen_is_boolean(ctx, t170))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t170)) {
    t167 = t170;
  } else {
  KLObject* t173 = shen_tl(ctx, t72);
  KLObject* t174 = shen_tl(ctx, t173);
  KLObject* t175 = shen_cons_p(ctx, t174);
  KLObject* t171;
  if (!shen_is_boolean(ctx, t175))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t175)) {
    t171 = t175;
  } else {
  KLObject* t176 = shen_empty_list(ctx);
  KLObject* t178 = shen_tl(ctx, t72);
  KLObject* t179 = shen_tl(ctx, t178);
  KLObject* t180 = shen_tl(ctx, t179);
  KLObject* t181 = shen_eq(ctx, t176, t180);
    if (!shen_is_boolean(ctx, t181))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t171 = t181;
  }
    if (!shen_is_boolean(ctx, t171))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t167 = t171;
  }
    if (!shen_is_boolean(ctx, t167))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t162 = t167;
  }
    if (!shen_is_boolean(ctx, t162))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t159 = t162;
  }
    if (!shen_is_boolean(ctx, t159))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t159)) {
  KLObject* t182 = shen_intern(ctx, "input+");
  KLObject* t185 = shen_tl(ctx, t72);
  KLObject* t186 = shen_hd(ctx, t185);
  KLObject* t183;
  {
    KLObject* a183[] = {t186};
    t183 = shen_apply_direct(ctx, "shen.rcons_form", 1, a183);
  }
  KLObject* t188 = shen_tl(ctx, t72);
  KLObject* t189 = shen_tl(ctx, t188);
  KLObject* t190 = shen_cons(ctx, t183, t189);
  KLObject* t191 = shen_cons(ctx, t182, t190);
      t73 = t191;
    } else {
  KLObject* t193 = shen_cons_p(ctx, t72);
    if (!shen_is_boolean(ctx, t193))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t193)) {
  KLObject* t195;
  {
    Vector* caps_0 = shen_vector(ctx, 0);
    t195 = shen_native_closure(ctx, 1, &lambda_0, caps_0);
  }
  KLObject* t194;
  {
    KLObject* a194[] = {t195, t72};
    t194 = shen_tail_apply_direct(ctx, "map", 2, a194);
  }
      t73 = t194;
    } else {
  KLObject* t200 = shen_true(ctx);
    if (!shen_is_boolean(ctx, t200))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t200)) {
      t73 = t72;
    } else {
      shen_simple_error(ctx, "No true case found for cond");
      t73 = shen_empty_list(ctx);
    }
    }
    }
    }
    }
    }
  }
    return t73;
  }
}

static KLObject* native_kl_shen_2eshendef_2d_3ekldef_3 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t202 = objects[0];
    KLObject* t203 = objects[1];
  tail_start_kl_shen_2eshendef_2d_3ekldef_3: ;
  KLObject* t205;
  {
    Vector* caps_1 = shen_vector(ctx, 0);
    t205 = shen_native_closure(ctx, 1, &lambda_1, caps_1);
  }
  KLObject* t211 = shen_cons(ctx, t202, t203);
  KLObject* t204;
  {
    KLObject* a204[] = {t205, t211};
    t204 = shen_tail_apply_direct(ctx, "compile", 2, a204);
  }
    return t204;
  }
}

static KLObject* native_kl_shen_2e_3cdefine_3e_4 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t212 = objects[0];
  tail_start_kl_shen_2e_3cdefine_3e_4: ;
  KLObject* t213;
  {
    KLObject* a213[] = {t212};
    t213 = shen_apply_direct(ctx, "shen.<name>", 1, a213);
  }
  KLObject* t216;
  {
    KLObject* a216[] = {t213};
    t216 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a216);
  }
  KLObject* t215;
  if (!shen_is_boolean(ctx, t216))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t216)) {
  KLObject* t218 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t215 = t218;
  } else {
  KLObject* t219;
  {
    KLObject* a219[] = {t213};
    t219 = shen_apply_direct(ctx, "shen.<-out", 1, a219);
  }
  KLObject* t221;
  {
    KLObject* a221[] = {t213};
    t221 = shen_apply_direct(ctx, "shen.in->", 1, a221);
  }
  KLObject* t226 = shen_intern(ctx, "{");
  KLObject* t224;
  {
    KLObject* a224[] = {t221, t226};
    t224 = shen_apply_direct(ctx, "shen.hds=?", 2, a224);
  }
  KLObject* t223;
  if (!shen_is_boolean(ctx, t224))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t224)) {
  KLObject* t227;
  {
    KLObject* a227[] = {t221};
    t227 = shen_apply_direct(ctx, "tail", 1, a227);
  }
  KLObject* t229;
  {
    KLObject* a229[] = {t227};
    t229 = shen_apply_direct(ctx, "shen.<signature>", 1, a229);
  }
  KLObject* t232;
  {
    KLObject* a232[] = {t229};
    t232 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a232);
  }
  KLObject* t231;
  if (!shen_is_boolean(ctx, t232))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t232)) {
  KLObject* t234 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t231 = t234;
  } else {
  KLObject* t235;
  {
    KLObject* a235[] = {t229};
    t235 = shen_apply_direct(ctx, "shen.in->", 1, a235);
  }
  KLObject* t240 = shen_intern(ctx, "}");
  KLObject* t238;
  {
    KLObject* a238[] = {t235, t240};
    t238 = shen_apply_direct(ctx, "shen.hds=?", 2, a238);
  }
  KLObject* t237;
  if (!shen_is_boolean(ctx, t238))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t238)) {
  KLObject* t241;
  {
    KLObject* a241[] = {t235};
    t241 = shen_apply_direct(ctx, "tail", 1, a241);
  }
  KLObject* t243;
  {
    KLObject* a243[] = {t241};
    t243 = shen_apply_direct(ctx, "shen.<rules>", 1, a243);
  }
  KLObject* t246;
  {
    KLObject* a246[] = {t243};
    t246 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a246);
  }
  KLObject* t245;
  if (!shen_is_boolean(ctx, t246))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t246)) {
  KLObject* t248 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t245 = t248;
  } else {
  KLObject* t249;
  {
    KLObject* a249[] = {t243};
    t249 = shen_apply_direct(ctx, "shen.<-out", 1, a249);
  }
  KLObject* t251;
  {
    KLObject* a251[] = {t243};
    t251 = shen_apply_direct(ctx, "shen.in->", 1, a251);
  }
  KLObject* t255;
  {
    KLObject* a255[] = {t219, t249};
    t255 = shen_apply_direct(ctx, "shen.shendef->kldef-h", 2, a255);
  }
  KLObject* t253;
  {
    KLObject* a253[] = {t251, t255};
    t253 = shen_apply_direct(ctx, "shen.comb", 2, a253);
  }
    t245 = t253;
  }
    t237 = t245;
  } else {
  KLObject* t258 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t237 = t258;
  }
    t231 = t237;
  }
    t223 = t231;
  } else {
  KLObject* t259 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t223 = t259;
  }
    t215 = t223;
  }
  KLObject* t261;
  {
    KLObject* a261[] = {t215};
    t261 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a261);
  }
  KLObject* t260;
  if (!shen_is_boolean(ctx, t261))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t261)) {
  KLObject* t263;
  {
    KLObject* a263[] = {t212};
    t263 = shen_apply_direct(ctx, "shen.<name>", 1, a263);
  }
  KLObject* t266;
  {
    KLObject* a266[] = {t263};
    t266 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a266);
  }
  KLObject* t265;
  if (!shen_is_boolean(ctx, t266))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t266)) {
  KLObject* t268 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t265 = t268;
  } else {
  KLObject* t269;
  {
    KLObject* a269[] = {t263};
    t269 = shen_apply_direct(ctx, "shen.<-out", 1, a269);
  }
  KLObject* t271;
  {
    KLObject* a271[] = {t263};
    t271 = shen_apply_direct(ctx, "shen.in->", 1, a271);
  }
  KLObject* t273;
  {
    KLObject* a273[] = {t271};
    t273 = shen_apply_direct(ctx, "shen.<rules>", 1, a273);
  }
  KLObject* t276;
  {
    KLObject* a276[] = {t273};
    t276 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a276);
  }
  KLObject* t275;
  if (!shen_is_boolean(ctx, t276))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t276)) {
  KLObject* t278 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t275 = t278;
  } else {
  KLObject* t279;
  {
    KLObject* a279[] = {t273};
    t279 = shen_apply_direct(ctx, "shen.<-out", 1, a279);
  }
  KLObject* t281;
  {
    KLObject* a281[] = {t273};
    t281 = shen_apply_direct(ctx, "shen.in->", 1, a281);
  }
  KLObject* t285;
  {
    KLObject* a285[] = {t269, t279};
    t285 = shen_apply_direct(ctx, "shen.shendef->kldef-h", 2, a285);
  }
  KLObject* t283;
  {
    KLObject* a283[] = {t281, t285};
    t283 = shen_apply_direct(ctx, "shen.comb", 2, a283);
  }
    t275 = t283;
  }
    t265 = t275;
  }
  KLObject* t289;
  {
    KLObject* a289[] = {t265};
    t289 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a289);
  }
  KLObject* t288;
  if (!shen_is_boolean(ctx, t289))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t289)) {
  KLObject* t291 = shen_tail_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t288 = t291;
  } else {
    t288 = t265;
  }
    t260 = t288;
  } else {
    t260 = t215;
  }
    return t260;
  }
}

static KLObject* native_kl_shen_2eshendef_2d_3ekldef_2dh_5 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t294 = objects[0];
    KLObject* t295 = objects[1];
  tail_start_kl_shen_2eshendef_2d_3ekldef_2dh_5: ;
  KLObject* t297;
  {
    Vector* caps_2 = shen_vector(ctx, 0);
    t297 = shen_native_closure(ctx, 1, &lambda_2, caps_2);
  }
  KLObject* t296;
  {
    KLObject* a296[] = {t297, t295};
    t296 = shen_apply_direct(ctx, "map", 2, a296);
  }
  KLObject* t302;
  {
    KLObject* a302[] = {t294, t296};
    t302 = shen_apply_direct(ctx, "shen.arity-chk", 2, a302);
  }
  KLObject* t306;
  {
    Vector* caps_3 = shen_vector(ctx, 1);
    shen_vector_set(ctx, caps_3, 0, t294);
    t306 = shen_native_closure(ctx, 1, &lambda_3, caps_3);
  }
  KLObject* t305;
  {
    KLObject* a305[] = {t306, t295};
    t305 = shen_apply_direct(ctx, "map", 2, a305);
  }
  KLObject* t313;
  {
    KLObject* a313[] = {t295};
    t313 = shen_apply_direct(ctx, "shen.unprotect", 1, a313);
  }
  KLObject* t316;
  {
    KLObject* a316[] = {t294, t313, t302};
    t316 = shen_apply_direct(ctx, "shen.compile-to-kl", 3, a316);
  }
  KLObject* t315;
  {
    KLObject* a315[] = {t316};
    t315 = shen_apply_direct(ctx, "shen.factorise-code", 1, a315);
  }
    return t315;
  }
}

static KLObject* native_kl_shen_2eunprotect_6 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t321 = objects[0];
  tail_start_kl_shen_2eunprotect_6: ;
  KLObject* t322;
  {
  KLObject* t323;
  {
    KLObject* a323[] = {t321};
    t323 = shen_apply_direct(ctx, "tuple?", 1, a323);
  }
    if (!shen_is_boolean(ctx, t323))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t323)) {
  KLObject* t327;
  {
    KLObject* a327[] = {t321};
    t327 = shen_apply_direct(ctx, "fst", 1, a327);
  }
  KLObject* t326;
  {
    KLObject* a326[] = {t327};
    t326 = shen_apply_direct(ctx, "shen.unprotect", 1, a326);
  }
  KLObject* t330;
  {
    KLObject* a330[] = {t321};
    t330 = shen_apply_direct(ctx, "snd", 1, a330);
  }
  KLObject* t329;
  {
    KLObject* a329[] = {t330};
    t329 = shen_apply_direct(ctx, "shen.unprotect", 1, a329);
  }
  KLObject* t325;
  {
    KLObject* a325[] = {t326, t329};
    t325 = shen_tail_apply_direct(ctx, "@p", 2, a325);
  }
      t322 = t325;
    } else {
  KLObject* t334 = shen_cons_p(ctx, t321);
  KLObject* t332;
  if (!shen_is_boolean(ctx, t334))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t334)) {
    t332 = t334;
  } else {
  KLObject* t336 = shen_intern(ctx, "protect");
  KLObject* t338 = shen_hd(ctx, t321);
  KLObject* t339 = shen_eq(ctx, t336, t338);
  KLObject* t335;
  if (!shen_is_boolean(ctx, t339))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t339)) {
    t335 = t339;
  } else {
  KLObject* t342 = shen_tl(ctx, t321);
  KLObject* t343 = shen_cons_p(ctx, t342);
  KLObject* t340;
  if (!shen_is_boolean(ctx, t343))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t343)) {
    t340 = t343;
  } else {
  KLObject* t344 = shen_empty_list(ctx);
  KLObject* t346 = shen_tl(ctx, t321);
  KLObject* t347 = shen_tl(ctx, t346);
  KLObject* t348 = shen_eq(ctx, t344, t347);
    if (!shen_is_boolean(ctx, t348))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t340 = t348;
  }
    if (!shen_is_boolean(ctx, t340))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t335 = t340;
  }
    if (!shen_is_boolean(ctx, t335))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t332 = t335;
  }
    if (!shen_is_boolean(ctx, t332))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t332)) {
  KLObject* t350 = shen_tl(ctx, t321);
  KLObject* t351 = shen_hd(ctx, t350);
  {
    KLObject* n352_0 = t351;
    t321 = n352_0;
    goto tail_start_kl_shen_2eunprotect_6;
  }
  KLObject* t352 = NULL;
      t322 = t352;
    } else {
  KLObject* t354 = shen_cons_p(ctx, t321);
    if (!shen_is_boolean(ctx, t354))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t354)) {
  KLObject* t356;
  {
    Vector* caps_4 = shen_vector(ctx, 0);
    t356 = shen_native_closure(ctx, 1, &lambda_4, caps_4);
  }
  KLObject* t355;
  {
    KLObject* a355[] = {t356, t321};
    t355 = shen_tail_apply_direct(ctx, "map", 2, a355);
  }
      t322 = t355;
    } else {
  KLObject* t361 = shen_true(ctx);
    if (!shen_is_boolean(ctx, t361))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t361)) {
      t322 = t321;
    } else {
      shen_simple_error(ctx, "No true case found for cond");
      t322 = shen_empty_list(ctx);
    }
    }
    }
    }
  }
    return t322;
  }
}

static KLObject* native_kl_shen_2e_3cname_3e_7 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t363 = objects[0];
  tail_start_kl_shen_2e_3cname_3e_7: ;
  KLObject* t366 = shen_cons_p(ctx, t363);
  KLObject* t364;
  if (!shen_is_boolean(ctx, t366))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t366)) {
  KLObject* t367;
  {
    KLObject* a367[] = {t363};
    t367 = shen_apply_direct(ctx, "head", 1, a367);
  }
  KLObject* t369;
  {
    KLObject* a369[] = {t363};
    t369 = shen_apply_direct(ctx, "tail", 1, a369);
  }
  KLObject* t376 = shen_symbol_p(ctx, t367);
  KLObject* t374;
  if (!shen_is_boolean(ctx, t376))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t376)) {
    t374 = t376;
  } else {
  KLObject* t378;
  {
    KLObject* a378[] = {t367};
    t378 = shen_apply_direct(ctx, "variable?", 1, a378);
  }
  KLObject* t377;
  {
    KLObject* a377[] = {t378};
    t377 = shen_apply_direct(ctx, "not", 1, a377);
  }
    if (!shen_is_boolean(ctx, t377))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t374 = t377;
  }
  KLObject* t373;
  if (!shen_is_boolean(ctx, t374))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t374)) {
    t373 = t367;
  } else {
  KLObject* t384 = shen_string(ctx, " is not a legitimate function name.\n");
  KLObject* t385 = shen_intern(ctx, "shen.a");
  KLObject* t382;
  {
    KLObject* a382[] = {t367, t384, t385};
    t382 = shen_apply_direct(ctx, "shen.app", 3, a382);
  }
  KLObject* t381;
  {
    KLObject* a381[] = {t382};
    t381 = shen_apply_direct(ctx, "simple-error", 1, a381);
  }
    t373 = t381;
  }
  KLObject* t371;
  {
    KLObject* a371[] = {t369, t373};
    t371 = shen_apply_direct(ctx, "shen.comb", 2, a371);
  }
    t364 = t371;
  } else {
  KLObject* t386 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t364 = t386;
  }
  KLObject* t388;
  {
    KLObject* a388[] = {t364};
    t388 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a388);
  }
  KLObject* t387;
  if (!shen_is_boolean(ctx, t388))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t388)) {
  KLObject* t390 = shen_tail_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t387 = t390;
  } else {
    t387 = t364;
  }
    return t387;
  }
}

static KLObject* native_kl_shen_2e_3csignature_3e_8 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t392 = objects[0];
  tail_start_kl_shen_2e_3csignature_3e_8: ;
  KLObject* t395 = shen_cons_p(ctx, t392);
  KLObject* t393;
  if (!shen_is_boolean(ctx, t395))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t395)) {
  KLObject* t396;
  {
    KLObject* a396[] = {t392};
    t396 = shen_apply_direct(ctx, "head", 1, a396);
  }
  KLObject* t398;
  {
    KLObject* a398[] = {t392};
    t398 = shen_apply_direct(ctx, "tail", 1, a398);
  }
  KLObject* t400;
  {
    KLObject* a400[] = {t398};
    t400 = shen_apply_direct(ctx, "shen.<signature>", 1, a400);
  }
  KLObject* t403;
  {
    KLObject* a403[] = {t400};
    t403 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a403);
  }
  KLObject* t402;
  if (!shen_is_boolean(ctx, t403))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t403)) {
  KLObject* t405 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t402 = t405;
  } else {
  KLObject* t406;
  {
    KLObject* a406[] = {t400};
    t406 = shen_apply_direct(ctx, "shen.<-out", 1, a406);
  }
  KLObject* t408;
  {
    KLObject* a408[] = {t400};
    t408 = shen_apply_direct(ctx, "shen.in->", 1, a408);
  }
  KLObject* t414 = shen_intern(ctx, "{");
  KLObject* t415 = shen_intern(ctx, "}");
  KLObject* t416 = shen_empty_list(ctx);
  KLObject* t417 = shen_cons(ctx, t415, t416);
  KLObject* t418 = shen_cons(ctx, t414, t417);
  KLObject* t412;
  {
    KLObject* a412[] = {t396, t418};
    t412 = shen_apply_direct(ctx, "element?", 2, a412);
  }
  KLObject* t411;
  {
    KLObject* a411[] = {t412};
    t411 = shen_apply_direct(ctx, "not", 1, a411);
  }
  KLObject* t410;
  if (!shen_is_boolean(ctx, t411))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t411)) {
  KLObject* t423 = shen_cons(ctx, t396, t406);
  KLObject* t419;
  {
    KLObject* a419[] = {t408, t423};
    t419 = shen_apply_direct(ctx, "shen.comb", 2, a419);
  }
    t410 = t419;
  } else {
  KLObject* t424 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t410 = t424;
  }
    t402 = t410;
  }
    t393 = t402;
  } else {
  KLObject* t425 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t393 = t425;
  }
  KLObject* t427;
  {
    KLObject* a427[] = {t393};
    t427 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a427);
  }
  KLObject* t426;
  if (!shen_is_boolean(ctx, t427))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t427)) {
  KLObject* t429;
  {
    KLObject* a429[] = {t392};
    t429 = shen_apply_direct(ctx, "<e>", 1, a429);
  }
  KLObject* t432;
  {
    KLObject* a432[] = {t429};
    t432 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a432);
  }
  KLObject* t431;
  if (!shen_is_boolean(ctx, t432))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t432)) {
  KLObject* t434 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t431 = t434;
  } else {
  KLObject* t435;
  {
    KLObject* a435[] = {t429};
    t435 = shen_apply_direct(ctx, "shen.in->", 1, a435);
  }
  KLObject* t439 = shen_empty_list(ctx);
  KLObject* t437;
  {
    KLObject* a437[] = {t435, t439};
    t437 = shen_apply_direct(ctx, "shen.comb", 2, a437);
  }
    t431 = t437;
  }
  KLObject* t441;
  {
    KLObject* a441[] = {t431};
    t441 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a441);
  }
  KLObject* t440;
  if (!shen_is_boolean(ctx, t441))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t441)) {
  KLObject* t443 = shen_tail_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t440 = t443;
  } else {
    t440 = t431;
  }
    t426 = t440;
  } else {
    t426 = t393;
  }
    return t426;
  }
}

static KLObject* native_kl_shen_2e_3crules_3e_9 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t446 = objects[0];
  tail_start_kl_shen_2e_3crules_3e_9: ;
  KLObject* t447;
  {
    KLObject* a447[] = {t446};
    t447 = shen_apply_direct(ctx, "shen.<rule>", 1, a447);
  }
  KLObject* t450;
  {
    KLObject* a450[] = {t447};
    t450 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a450);
  }
  KLObject* t449;
  if (!shen_is_boolean(ctx, t450))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t450)) {
  KLObject* t452 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t449 = t452;
  } else {
  KLObject* t453;
  {
    KLObject* a453[] = {t447};
    t453 = shen_apply_direct(ctx, "shen.<-out", 1, a453);
  }
  KLObject* t455;
  {
    KLObject* a455[] = {t447};
    t455 = shen_apply_direct(ctx, "shen.in->", 1, a455);
  }
  KLObject* t457;
  {
    KLObject* a457[] = {t455};
    t457 = shen_apply_direct(ctx, "shen.<rules>", 1, a457);
  }
  KLObject* t460;
  {
    KLObject* a460[] = {t457};
    t460 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a460);
  }
  KLObject* t459;
  if (!shen_is_boolean(ctx, t460))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t460)) {
  KLObject* t462 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t459 = t462;
  } else {
  KLObject* t463;
  {
    KLObject* a463[] = {t457};
    t463 = shen_apply_direct(ctx, "shen.<-out", 1, a463);
  }
  KLObject* t465;
  {
    KLObject* a465[] = {t457};
    t465 = shen_apply_direct(ctx, "shen.in->", 1, a465);
  }
  KLObject* t469;
  {
    KLObject* a469[] = {t453};
    t469 = shen_apply_direct(ctx, "shen.linearise", 1, a469);
  }
  KLObject* t472 = shen_cons(ctx, t469, t463);
  KLObject* t467;
  {
    KLObject* a467[] = {t465, t472};
    t467 = shen_apply_direct(ctx, "shen.comb", 2, a467);
  }
    t459 = t467;
  }
    t449 = t459;
  }
  KLObject* t474;
  {
    KLObject* a474[] = {t449};
    t474 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a474);
  }
  KLObject* t473;
  if (!shen_is_boolean(ctx, t474))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t474)) {
  KLObject* t476;
  {
    KLObject* a476[] = {t446};
    t476 = shen_apply_direct(ctx, "<!>", 1, a476);
  }
  KLObject* t479;
  {
    KLObject* a479[] = {t476};
    t479 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a479);
  }
  KLObject* t478;
  if (!shen_is_boolean(ctx, t479))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t479)) {
  KLObject* t481 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t478 = t481;
  } else {
  KLObject* t482;
  {
    KLObject* a482[] = {t476};
    t482 = shen_apply_direct(ctx, "shen.<-out", 1, a482);
  }
  KLObject* t484;
  {
    KLObject* a484[] = {t476};
    t484 = shen_apply_direct(ctx, "shen.in->", 1, a484);
  }
  KLObject* t489;
  {
    KLObject* a489[] = {t482};
    t489 = shen_apply_direct(ctx, "empty?", 1, a489);
  }
  KLObject* t488;
  if (!shen_is_boolean(ctx, t489))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t489)) {
  KLObject* t491 = shen_empty_list(ctx);
    t488 = t491;
  } else {
  KLObject* t494 = shen_string(ctx, "Shen syntax error here:\n ");
  KLObject* t497 = shen_string(ctx, "\n ...");
  KLObject* t498 = shen_intern(ctx, "shen.r");
  KLObject* t495;
  {
    KLObject* a495[] = {t482, t497, t498};
    t495 = shen_apply_direct(ctx, "shen.app", 3, a495);
  }
  KLObject* t493;
  {
    KLObject* a493[] = {t494, t495};
    t493 = shen_apply_direct(ctx, "cn", 2, a493);
  }
  KLObject* t492;
  {
    KLObject* a492[] = {t493};
    t492 = shen_apply_direct(ctx, "simple-error", 1, a492);
  }
    t488 = t492;
  }
  KLObject* t486;
  {
    KLObject* a486[] = {t484, t488};
    t486 = shen_apply_direct(ctx, "shen.comb", 2, a486);
  }
    t478 = t486;
  }
  KLObject* t500;
  {
    KLObject* a500[] = {t478};
    t500 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a500);
  }
  KLObject* t499;
  if (!shen_is_boolean(ctx, t500))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t500)) {
  KLObject* t502 = shen_tail_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t499 = t502;
  } else {
    t499 = t478;
  }
    t473 = t499;
  } else {
    t473 = t449;
  }
    return t473;
  }
}

static KLObject* native_kl_shen_2elinearise_10 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t505 = objects[0];
  tail_start_kl_shen_2elinearise_10: ;
  KLObject* t506;
  {
  KLObject* t507;
  {
    KLObject* a507[] = {t505};
    t507 = shen_apply_direct(ctx, "tuple?", 1, a507);
  }
    if (!shen_is_boolean(ctx, t507))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t507)) {
  KLObject* t510;
  {
    KLObject* a510[] = {t505};
    t510 = shen_apply_direct(ctx, "fst", 1, a510);
  }
  KLObject* t512;
  {
    KLObject* a512[] = {t505};
    t512 = shen_apply_direct(ctx, "fst", 1, a512);
  }
  KLObject* t514 = shen_empty_list(ctx);
  KLObject* t515;
  {
    KLObject* a515[] = {t505};
    t515 = shen_apply_direct(ctx, "snd", 1, a515);
  }
  KLObject* t509;
  {
    KLObject* a509[] = {t510, t512, t514, t515};
    t509 = shen_tail_apply_direct(ctx, "shen.linearise-h", 4, a509);
  }
      t506 = t509;
    } else {
  KLObject* t517 = shen_true(ctx);
    if (!shen_is_boolean(ctx, t517))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t517)) {
  KLObject* t519 = shen_string(ctx, "implementation error in shen.linearise");
  KLObject* t518;
  {
    KLObject* a518[] = {t519};
    t518 = shen_tail_apply_direct(ctx, "simple-error", 1, a518);
  }
      t506 = t518;
    } else {
      shen_simple_error(ctx, "No true case found for cond");
      t506 = shen_empty_list(ctx);
    }
    }
  }
    return t506;
  }
}

static KLObject* native_kl_shen_2elinearise_2dh_11 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t520 = objects[0];
    KLObject* t521 = objects[1];
    KLObject* t522 = objects[2];
    KLObject* t523 = objects[3];
  tail_start_kl_shen_2elinearise_2dh_11: ;
  KLObject* t524;
  {
  KLObject* t525 = shen_empty_list(ctx);
  KLObject* t527 = shen_eq(ctx, t525, t520);
    if (!shen_is_boolean(ctx, t527))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t527)) {
  KLObject* t528;
  {
    KLObject* a528[] = {t521, t523};
    t528 = shen_tail_apply_direct(ctx, "@p", 2, a528);
  }
      t524 = t528;
    } else {
  KLObject* t533 = shen_cons_p(ctx, t520);
  KLObject* t531;
  if (!shen_is_boolean(ctx, t533))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t533)) {
    t531 = t533;
  } else {
  KLObject* t535 = shen_hd(ctx, t520);
  KLObject* t536 = shen_cons_p(ctx, t535);
    if (!shen_is_boolean(ctx, t536))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t531 = t536;
  }
    if (!shen_is_boolean(ctx, t531))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t531)) {
  KLObject* t539 = shen_hd(ctx, t520);
  KLObject* t541 = shen_tl(ctx, t520);
  KLObject* t537;
  {
    KLObject* a537[] = {t539, t541};
    t537 = shen_apply_direct(ctx, "append", 2, a537);
  }
  {
    KLObject* n545_0 = t537;
    KLObject* n545_1 = t521;
    KLObject* n545_2 = t522;
    KLObject* n545_3 = t523;
    t520 = n545_0;
    t521 = n545_1;
    t522 = n545_2;
    t523 = n545_3;
    goto tail_start_kl_shen_2elinearise_2dh_11;
  }
  KLObject* t545 = NULL;
      t524 = t545;
    } else {
  KLObject* t548 = shen_cons_p(ctx, t520);
  KLObject* t546;
  if (!shen_is_boolean(ctx, t548))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t548)) {
    t546 = t548;
  } else {
  KLObject* t551 = shen_hd(ctx, t520);
  KLObject* t549;
  {
    KLObject* a549[] = {t551};
    t549 = shen_apply_direct(ctx, "variable?", 1, a549);
  }
    if (!shen_is_boolean(ctx, t549))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t546 = t549;
  }
    if (!shen_is_boolean(ctx, t546))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t546)) {
  KLObject* t555 = shen_hd(ctx, t520);
  KLObject* t553;
  {
    KLObject* a553[] = {t555, t522};
    t553 = shen_apply_direct(ctx, "element?", 2, a553);
  }
  KLObject* t552;
  if (!shen_is_boolean(ctx, t553))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t553)) {
  KLObject* t558 = shen_intern(ctx, "V");
  KLObject* t557;
  {
    KLObject* a557[] = {t558};
    t557 = shen_apply_direct(ctx, "gensym", 1, a557);
  }
  KLObject* t560 = shen_tl(ctx, t520);
  KLObject* t563 = shen_hd(ctx, t520);
  KLObject* t561;
  {
    KLObject* a561[] = {t563, t557, t521};
    t561 = shen_apply_direct(ctx, "shen.rep-X", 3, a561);
  }
  KLObject* t567 = shen_intern(ctx, "where");
  KLObject* t568 = shen_intern(ctx, "=");
  KLObject* t571 = shen_hd(ctx, t520);
  KLObject* t572 = shen_empty_list(ctx);
  KLObject* t573 = shen_cons(ctx, t571, t572);
  KLObject* t574 = shen_cons(ctx, t557, t573);
  KLObject* t575 = shen_cons(ctx, t568, t574);
  KLObject* t577 = shen_empty_list(ctx);
  KLObject* t578 = shen_cons(ctx, t523, t577);
  KLObject* t579 = shen_cons(ctx, t575, t578);
  KLObject* t580 = shen_cons(ctx, t567, t579);
  {
    KLObject* n581_0 = t560;
    KLObject* n581_1 = t561;
    KLObject* n581_2 = t522;
    KLObject* n581_3 = t580;
    t520 = n581_0;
    t521 = n581_1;
    t522 = n581_2;
    t523 = n581_3;
    goto tail_start_kl_shen_2elinearise_2dh_11;
  }
  KLObject* t581 = NULL;
    t552 = t581;
  } else {
  KLObject* t583 = shen_tl(ctx, t520);
  KLObject* t586 = shen_hd(ctx, t520);
  KLObject* t588 = shen_cons(ctx, t586, t522);
  {
    KLObject* n590_0 = t583;
    KLObject* n590_1 = t521;
    KLObject* n590_2 = t588;
    KLObject* n590_3 = t523;
    t520 = n590_0;
    t521 = n590_1;
    t522 = n590_2;
    t523 = n590_3;
    goto tail_start_kl_shen_2elinearise_2dh_11;
  }
  KLObject* t590 = NULL;
    t552 = t590;
  }
      t524 = t552;
    } else {
  KLObject* t592 = shen_cons_p(ctx, t520);
    if (!shen_is_boolean(ctx, t592))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t592)) {
  KLObject* t594 = shen_tl(ctx, t520);
  {
    KLObject* n598_0 = t594;
    KLObject* n598_1 = t521;
    KLObject* n598_2 = t522;
    KLObject* n598_3 = t523;
    t520 = n598_0;
    t521 = n598_1;
    t522 = n598_2;
    t523 = n598_3;
    goto tail_start_kl_shen_2elinearise_2dh_11;
  }
  KLObject* t598 = NULL;
      t524 = t598;
    } else {
  KLObject* t599 = shen_true(ctx);
    if (!shen_is_boolean(ctx, t599))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t599)) {
  KLObject* t601 = shen_string(ctx, "implementation error in shen.linearise-h");
  KLObject* t600;
  {
    KLObject* a600[] = {t601};
    t600 = shen_tail_apply_direct(ctx, "simple-error", 1, a600);
  }
      t524 = t600;
    } else {
      shen_simple_error(ctx, "No true case found for cond");
      t524 = shen_empty_list(ctx);
    }
    }
    }
    }
    }
  }
    return t524;
  }
}

static KLObject* native_kl_shen_2e_3crule_3e_12 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t602 = objects[0];
  tail_start_kl_shen_2e_3crule_3e_12: ;
  KLObject* t603;
  {
    KLObject* a603[] = {t602};
    t603 = shen_apply_direct(ctx, "shen.<patterns>", 1, a603);
  }
  KLObject* t606;
  {
    KLObject* a606[] = {t603};
    t606 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a606);
  }
  KLObject* t605;
  if (!shen_is_boolean(ctx, t606))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t606)) {
  KLObject* t608 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t605 = t608;
  } else {
  KLObject* t609;
  {
    KLObject* a609[] = {t603};
    t609 = shen_apply_direct(ctx, "shen.<-out", 1, a609);
  }
  KLObject* t611;
  {
    KLObject* a611[] = {t603};
    t611 = shen_apply_direct(ctx, "shen.in->", 1, a611);
  }
  KLObject* t616 = shen_intern(ctx, "->");
  KLObject* t614;
  {
    KLObject* a614[] = {t611, t616};
    t614 = shen_apply_direct(ctx, "shen.hds=?", 2, a614);
  }
  KLObject* t613;
  if (!shen_is_boolean(ctx, t614))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t614)) {
  KLObject* t617;
  {
    KLObject* a617[] = {t611};
    t617 = shen_apply_direct(ctx, "tail", 1, a617);
  }
  KLObject* t621 = shen_cons_p(ctx, t617);
  KLObject* t619;
  if (!shen_is_boolean(ctx, t621))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t621)) {
  KLObject* t622;
  {
    KLObject* a622[] = {t617};
    t622 = shen_apply_direct(ctx, "head", 1, a622);
  }
  KLObject* t624;
  {
    KLObject* a624[] = {t617};
    t624 = shen_apply_direct(ctx, "tail", 1, a624);
  }
  KLObject* t629 = shen_intern(ctx, "where");
  KLObject* t627;
  {
    KLObject* a627[] = {t624, t629};
    t627 = shen_apply_direct(ctx, "shen.hds=?", 2, a627);
  }
  KLObject* t626;
  if (!shen_is_boolean(ctx, t627))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t627)) {
  KLObject* t630;
  {
    KLObject* a630[] = {t624};
    t630 = shen_apply_direct(ctx, "tail", 1, a630);
  }
  KLObject* t634 = shen_cons_p(ctx, t630);
  KLObject* t632;
  if (!shen_is_boolean(ctx, t634))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t634)) {
  KLObject* t635;
  {
    KLObject* a635[] = {t630};
    t635 = shen_apply_direct(ctx, "head", 1, a635);
  }
  KLObject* t637;
  {
    KLObject* a637[] = {t630};
    t637 = shen_apply_direct(ctx, "tail", 1, a637);
  }
  KLObject* t643 = shen_intern(ctx, "where");
  KLObject* t646 = shen_empty_list(ctx);
  KLObject* t647 = shen_cons(ctx, t622, t646);
  KLObject* t648 = shen_cons(ctx, t635, t647);
  KLObject* t649 = shen_cons(ctx, t643, t648);
  KLObject* t641;
  {
    KLObject* a641[] = {t609, t649};
    t641 = shen_apply_direct(ctx, "@p", 2, a641);
  }
  KLObject* t639;
  {
    KLObject* a639[] = {t637, t641};
    t639 = shen_apply_direct(ctx, "shen.comb", 2, a639);
  }
    t632 = t639;
  } else {
  KLObject* t650 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t632 = t650;
  }
    t626 = t632;
  } else {
  KLObject* t651 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t626 = t651;
  }
    t619 = t626;
  } else {
  KLObject* t652 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t619 = t652;
  }
    t613 = t619;
  } else {
  KLObject* t653 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t613 = t653;
  }
    t605 = t613;
  }
  KLObject* t655;
  {
    KLObject* a655[] = {t605};
    t655 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a655);
  }
  KLObject* t654;
  if (!shen_is_boolean(ctx, t655))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t655)) {
  KLObject* t657;
  {
    KLObject* a657[] = {t602};
    t657 = shen_apply_direct(ctx, "shen.<patterns>", 1, a657);
  }
  KLObject* t660;
  {
    KLObject* a660[] = {t657};
    t660 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a660);
  }
  KLObject* t659;
  if (!shen_is_boolean(ctx, t660))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t660)) {
  KLObject* t662 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t659 = t662;
  } else {
  KLObject* t663;
  {
    KLObject* a663[] = {t657};
    t663 = shen_apply_direct(ctx, "shen.<-out", 1, a663);
  }
  KLObject* t665;
  {
    KLObject* a665[] = {t657};
    t665 = shen_apply_direct(ctx, "shen.in->", 1, a665);
  }
  KLObject* t670 = shen_intern(ctx, "->");
  KLObject* t668;
  {
    KLObject* a668[] = {t665, t670};
    t668 = shen_apply_direct(ctx, "shen.hds=?", 2, a668);
  }
  KLObject* t667;
  if (!shen_is_boolean(ctx, t668))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t668)) {
  KLObject* t671;
  {
    KLObject* a671[] = {t665};
    t671 = shen_apply_direct(ctx, "tail", 1, a671);
  }
  KLObject* t675 = shen_cons_p(ctx, t671);
  KLObject* t673;
  if (!shen_is_boolean(ctx, t675))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t675)) {
  KLObject* t676;
  {
    KLObject* a676[] = {t671};
    t676 = shen_apply_direct(ctx, "head", 1, a676);
  }
  KLObject* t678;
  {
    KLObject* a678[] = {t671};
    t678 = shen_apply_direct(ctx, "tail", 1, a678);
  }
  KLObject* t682;
  {
    KLObject* a682[] = {t663, t676};
    t682 = shen_apply_direct(ctx, "@p", 2, a682);
  }
  KLObject* t680;
  {
    KLObject* a680[] = {t678, t682};
    t680 = shen_apply_direct(ctx, "shen.comb", 2, a680);
  }
    t673 = t680;
  } else {
  KLObject* t685 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t673 = t685;
  }
    t667 = t673;
  } else {
  KLObject* t686 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t667 = t686;
  }
    t659 = t667;
  }
  KLObject* t688;
  {
    KLObject* a688[] = {t659};
    t688 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a688);
  }
  KLObject* t687;
  if (!shen_is_boolean(ctx, t688))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t688)) {
  KLObject* t690;
  {
    KLObject* a690[] = {t602};
    t690 = shen_apply_direct(ctx, "shen.<patterns>", 1, a690);
  }
  KLObject* t693;
  {
    KLObject* a693[] = {t690};
    t693 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a693);
  }
  KLObject* t692;
  if (!shen_is_boolean(ctx, t693))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t693)) {
  KLObject* t695 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t692 = t695;
  } else {
  KLObject* t696;
  {
    KLObject* a696[] = {t690};
    t696 = shen_apply_direct(ctx, "shen.<-out", 1, a696);
  }
  KLObject* t698;
  {
    KLObject* a698[] = {t690};
    t698 = shen_apply_direct(ctx, "shen.in->", 1, a698);
  }
  KLObject* t703 = shen_intern(ctx, "<-");
  KLObject* t701;
  {
    KLObject* a701[] = {t698, t703};
    t701 = shen_apply_direct(ctx, "shen.hds=?", 2, a701);
  }
  KLObject* t700;
  if (!shen_is_boolean(ctx, t701))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t701)) {
  KLObject* t704;
  {
    KLObject* a704[] = {t698};
    t704 = shen_apply_direct(ctx, "tail", 1, a704);
  }
  KLObject* t708 = shen_cons_p(ctx, t704);
  KLObject* t706;
  if (!shen_is_boolean(ctx, t708))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t708)) {
  KLObject* t709;
  {
    KLObject* a709[] = {t704};
    t709 = shen_apply_direct(ctx, "head", 1, a709);
  }
  KLObject* t711;
  {
    KLObject* a711[] = {t704};
    t711 = shen_apply_direct(ctx, "tail", 1, a711);
  }
  KLObject* t716 = shen_intern(ctx, "where");
  KLObject* t714;
  {
    KLObject* a714[] = {t711, t716};
    t714 = shen_apply_direct(ctx, "shen.hds=?", 2, a714);
  }
  KLObject* t713;
  if (!shen_is_boolean(ctx, t714))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t714)) {
  KLObject* t717;
  {
    KLObject* a717[] = {t711};
    t717 = shen_apply_direct(ctx, "tail", 1, a717);
  }
  KLObject* t721 = shen_cons_p(ctx, t717);
  KLObject* t719;
  if (!shen_is_boolean(ctx, t721))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t721)) {
  KLObject* t722;
  {
    KLObject* a722[] = {t717};
    t722 = shen_apply_direct(ctx, "head", 1, a722);
  }
  KLObject* t724;
  {
    KLObject* a724[] = {t717};
    t724 = shen_apply_direct(ctx, "tail", 1, a724);
  }
  KLObject* t730 = shen_intern(ctx, "where");
  KLObject* t732 = shen_intern(ctx, "shen.choicepoint!");
  KLObject* t734 = shen_empty_list(ctx);
  KLObject* t735 = shen_cons(ctx, t709, t734);
  KLObject* t736 = shen_cons(ctx, t732, t735);
  KLObject* t737 = shen_empty_list(ctx);
  KLObject* t738 = shen_cons(ctx, t736, t737);
  KLObject* t739 = shen_cons(ctx, t722, t738);
  KLObject* t740 = shen_cons(ctx, t730, t739);
  KLObject* t728;
  {
    KLObject* a728[] = {t696, t740};
    t728 = shen_apply_direct(ctx, "@p", 2, a728);
  }
  KLObject* t726;
  {
    KLObject* a726[] = {t724, t728};
    t726 = shen_apply_direct(ctx, "shen.comb", 2, a726);
  }
    t719 = t726;
  } else {
  KLObject* t741 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t719 = t741;
  }
    t713 = t719;
  } else {
  KLObject* t742 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t713 = t742;
  }
    t706 = t713;
  } else {
  KLObject* t743 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t706 = t743;
  }
    t700 = t706;
  } else {
  KLObject* t744 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t700 = t744;
  }
    t692 = t700;
  }
  KLObject* t746;
  {
    KLObject* a746[] = {t692};
    t746 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a746);
  }
  KLObject* t745;
  if (!shen_is_boolean(ctx, t746))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t746)) {
  KLObject* t748;
  {
    KLObject* a748[] = {t602};
    t748 = shen_apply_direct(ctx, "shen.<patterns>", 1, a748);
  }
  KLObject* t751;
  {
    KLObject* a751[] = {t748};
    t751 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a751);
  }
  KLObject* t750;
  if (!shen_is_boolean(ctx, t751))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t751)) {
  KLObject* t753 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t750 = t753;
  } else {
  KLObject* t754;
  {
    KLObject* a754[] = {t748};
    t754 = shen_apply_direct(ctx, "shen.<-out", 1, a754);
  }
  KLObject* t756;
  {
    KLObject* a756[] = {t748};
    t756 = shen_apply_direct(ctx, "shen.in->", 1, a756);
  }
  KLObject* t761 = shen_intern(ctx, "<-");
  KLObject* t759;
  {
    KLObject* a759[] = {t756, t761};
    t759 = shen_apply_direct(ctx, "shen.hds=?", 2, a759);
  }
  KLObject* t758;
  if (!shen_is_boolean(ctx, t759))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t759)) {
  KLObject* t762;
  {
    KLObject* a762[] = {t756};
    t762 = shen_apply_direct(ctx, "tail", 1, a762);
  }
  KLObject* t766 = shen_cons_p(ctx, t762);
  KLObject* t764;
  if (!shen_is_boolean(ctx, t766))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t766)) {
  KLObject* t767;
  {
    KLObject* a767[] = {t762};
    t767 = shen_apply_direct(ctx, "head", 1, a767);
  }
  KLObject* t769;
  {
    KLObject* a769[] = {t762};
    t769 = shen_apply_direct(ctx, "tail", 1, a769);
  }
  KLObject* t775 = shen_intern(ctx, "shen.choicepoint!");
  KLObject* t777 = shen_empty_list(ctx);
  KLObject* t778 = shen_cons(ctx, t767, t777);
  KLObject* t779 = shen_cons(ctx, t775, t778);
  KLObject* t773;
  {
    KLObject* a773[] = {t754, t779};
    t773 = shen_apply_direct(ctx, "@p", 2, a773);
  }
  KLObject* t771;
  {
    KLObject* a771[] = {t769, t773};
    t771 = shen_apply_direct(ctx, "shen.comb", 2, a771);
  }
    t764 = t771;
  } else {
  KLObject* t780 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t764 = t780;
  }
    t758 = t764;
  } else {
  KLObject* t781 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t758 = t781;
  }
    t750 = t758;
  }
  KLObject* t783;
  {
    KLObject* a783[] = {t750};
    t783 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a783);
  }
  KLObject* t782;
  if (!shen_is_boolean(ctx, t783))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t783)) {
  KLObject* t785 = shen_tail_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t782 = t785;
  } else {
    t782 = t750;
  }
    t745 = t782;
  } else {
    t745 = t692;
  }
    t687 = t745;
  } else {
    t687 = t659;
  }
    t654 = t687;
  } else {
    t654 = t605;
  }
    return t654;
  }
}

static KLObject* native_kl_shen_2e_3cpatterns_3e_13 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t790 = objects[0];
  tail_start_kl_shen_2e_3cpatterns_3e_13: ;
  KLObject* t791;
  {
    KLObject* a791[] = {t790};
    t791 = shen_apply_direct(ctx, "shen.<pattern>", 1, a791);
  }
  KLObject* t794;
  {
    KLObject* a794[] = {t791};
    t794 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a794);
  }
  KLObject* t793;
  if (!shen_is_boolean(ctx, t794))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t794)) {
  KLObject* t796 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t793 = t796;
  } else {
  KLObject* t797;
  {
    KLObject* a797[] = {t791};
    t797 = shen_apply_direct(ctx, "shen.<-out", 1, a797);
  }
  KLObject* t799;
  {
    KLObject* a799[] = {t791};
    t799 = shen_apply_direct(ctx, "shen.in->", 1, a799);
  }
  KLObject* t801;
  {
    KLObject* a801[] = {t799};
    t801 = shen_apply_direct(ctx, "shen.<patterns>", 1, a801);
  }
  KLObject* t804;
  {
    KLObject* a804[] = {t801};
    t804 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a804);
  }
  KLObject* t803;
  if (!shen_is_boolean(ctx, t804))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t804)) {
  KLObject* t806 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t803 = t806;
  } else {
  KLObject* t807;
  {
    KLObject* a807[] = {t801};
    t807 = shen_apply_direct(ctx, "shen.<-out", 1, a807);
  }
  KLObject* t809;
  {
    KLObject* a809[] = {t801};
    t809 = shen_apply_direct(ctx, "shen.in->", 1, a809);
  }
  KLObject* t815 = shen_cons(ctx, t797, t807);
  KLObject* t811;
  {
    KLObject* a811[] = {t809, t815};
    t811 = shen_apply_direct(ctx, "shen.comb", 2, a811);
  }
    t803 = t811;
  }
    t793 = t803;
  }
  KLObject* t817;
  {
    KLObject* a817[] = {t793};
    t817 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a817);
  }
  KLObject* t816;
  if (!shen_is_boolean(ctx, t817))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t817)) {
  KLObject* t819;
  {
    KLObject* a819[] = {t790};
    t819 = shen_apply_direct(ctx, "<e>", 1, a819);
  }
  KLObject* t822;
  {
    KLObject* a822[] = {t819};
    t822 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a822);
  }
  KLObject* t821;
  if (!shen_is_boolean(ctx, t822))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t822)) {
  KLObject* t824 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t821 = t824;
  } else {
  KLObject* t825;
  {
    KLObject* a825[] = {t819};
    t825 = shen_apply_direct(ctx, "shen.in->", 1, a825);
  }
  KLObject* t829 = shen_empty_list(ctx);
  KLObject* t827;
  {
    KLObject* a827[] = {t825, t829};
    t827 = shen_apply_direct(ctx, "shen.comb", 2, a827);
  }
    t821 = t827;
  }
  KLObject* t831;
  {
    KLObject* a831[] = {t821};
    t831 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a831);
  }
  KLObject* t830;
  if (!shen_is_boolean(ctx, t831))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t831)) {
  KLObject* t833 = shen_tail_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t830 = t833;
  } else {
    t830 = t821;
  }
    t816 = t830;
  } else {
    t816 = t793;
  }
    return t816;
  }
}

static KLObject* native_kl_shen_2e_3cpattern_3e_14 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t836 = objects[0];
  tail_start_kl_shen_2e_3cpattern_3e_14: ;
  KLObject* t838;
  {
    KLObject* a838[] = {t836};
    t838 = shen_apply_direct(ctx, "shen.ccons?", 1, a838);
  }
  KLObject* t837;
  if (!shen_is_boolean(ctx, t838))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t838)) {
  KLObject* t840;
  {
    KLObject* a840[] = {t836};
    t840 = shen_apply_direct(ctx, "head", 1, a840);
  }
  KLObject* t842;
  {
    KLObject* a842[] = {t836};
    t842 = shen_apply_direct(ctx, "tail", 1, a842);
  }
  KLObject* t844;
  {
    KLObject* a844[] = {t840};
    t844 = shen_apply_direct(ctx, "shen.<constructor>", 1, a844);
  }
  KLObject* t847;
  {
    KLObject* a847[] = {t844};
    t847 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a847);
  }
  KLObject* t846;
  if (!shen_is_boolean(ctx, t847))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t847)) {
  KLObject* t849 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t846 = t849;
  } else {
  KLObject* t850;
  {
    KLObject* a850[] = {t844};
    t850 = shen_apply_direct(ctx, "shen.<-out", 1, a850);
  }
  KLObject* t852;
  {
    KLObject* a852[] = {t844};
    t852 = shen_apply_direct(ctx, "shen.in->", 1, a852);
  }
  KLObject* t854;
  {
    KLObject* a854[] = {t852};
    t854 = shen_apply_direct(ctx, "shen.<pattern1>", 1, a854);
  }
  KLObject* t857;
  {
    KLObject* a857[] = {t854};
    t857 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a857);
  }
  KLObject* t856;
  if (!shen_is_boolean(ctx, t857))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t857)) {
  KLObject* t859 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t856 = t859;
  } else {
  KLObject* t860;
  {
    KLObject* a860[] = {t854};
    t860 = shen_apply_direct(ctx, "shen.<-out", 1, a860);
  }
  KLObject* t862;
  {
    KLObject* a862[] = {t854};
    t862 = shen_apply_direct(ctx, "shen.in->", 1, a862);
  }
  KLObject* t864;
  {
    KLObject* a864[] = {t862};
    t864 = shen_apply_direct(ctx, "shen.<pattern2>", 1, a864);
  }
  KLObject* t867;
  {
    KLObject* a867[] = {t864};
    t867 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a867);
  }
  KLObject* t866;
  if (!shen_is_boolean(ctx, t867))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t867)) {
  KLObject* t869 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t866 = t869;
  } else {
  KLObject* t870;
  {
    KLObject* a870[] = {t864};
    t870 = shen_apply_direct(ctx, "shen.<-out", 1, a870);
  }
  KLObject* t872;
  {
    KLObject* a872[] = {t864};
    t872 = shen_apply_direct(ctx, "shen.in->", 1, a872);
  }
  KLObject* t874;
  {
    KLObject* a874[] = {t872};
    t874 = shen_apply_direct(ctx, "<end>", 1, a874);
  }
  KLObject* t877;
  {
    KLObject* a877[] = {t874};
    t877 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a877);
  }
  KLObject* t876;
  if (!shen_is_boolean(ctx, t877))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t877)) {
  KLObject* t879 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t876 = t879;
  } else {
  KLObject* t880;
  {
    KLObject* a880[] = {t874};
    t880 = shen_apply_direct(ctx, "shen.in->", 1, a880);
  }
  KLObject* t887 = shen_empty_list(ctx);
  KLObject* t888 = shen_cons(ctx, t870, t887);
  KLObject* t889 = shen_cons(ctx, t860, t888);
  KLObject* t890 = shen_cons(ctx, t850, t889);
  KLObject* t882;
  {
    KLObject* a882[] = {t842, t890};
    t882 = shen_apply_direct(ctx, "shen.comb", 2, a882);
  }
    t876 = t882;
  }
    t866 = t876;
  }
    t856 = t866;
  }
    t846 = t856;
  }
    t837 = t846;
  } else {
  KLObject* t891 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t837 = t891;
  }
  KLObject* t893;
  {
    KLObject* a893[] = {t837};
    t893 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a893);
  }
  KLObject* t892;
  if (!shen_is_boolean(ctx, t893))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t893)) {
  KLObject* t896;
  {
    KLObject* a896[] = {t836};
    t896 = shen_apply_direct(ctx, "shen.ccons?", 1, a896);
  }
  KLObject* t895;
  if (!shen_is_boolean(ctx, t896))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t896)) {
  KLObject* t898;
  {
    KLObject* a898[] = {t836};
    t898 = shen_apply_direct(ctx, "head", 1, a898);
  }
  KLObject* t900;
  {
    KLObject* a900[] = {t836};
    t900 = shen_apply_direct(ctx, "tail", 1, a900);
  }
  KLObject* t905 = shen_intern(ctx, "vector");
  KLObject* t903;
  {
    KLObject* a903[] = {t898, t905};
    t903 = shen_apply_direct(ctx, "shen.hds=?", 2, a903);
  }
  KLObject* t902;
  if (!shen_is_boolean(ctx, t903))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t903)) {
  KLObject* t906;
  {
    KLObject* a906[] = {t898};
    t906 = shen_apply_direct(ctx, "tail", 1, a906);
  }
  KLObject* t911 = shen_number_l(ctx, 0);
  KLObject* t909;
  {
    KLObject* a909[] = {t906, t911};
    t909 = shen_apply_direct(ctx, "shen.hds=?", 2, a909);
  }
  KLObject* t908;
  if (!shen_is_boolean(ctx, t909))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t909)) {
  KLObject* t912;
  {
    KLObject* a912[] = {t906};
    t912 = shen_apply_direct(ctx, "tail", 1, a912);
  }
  KLObject* t914;
  {
    KLObject* a914[] = {t912};
    t914 = shen_apply_direct(ctx, "<end>", 1, a914);
  }
  KLObject* t917;
  {
    KLObject* a917[] = {t914};
    t917 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a917);
  }
  KLObject* t916;
  if (!shen_is_boolean(ctx, t917))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t917)) {
  KLObject* t919 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t916 = t919;
  } else {
  KLObject* t920;
  {
    KLObject* a920[] = {t914};
    t920 = shen_apply_direct(ctx, "shen.in->", 1, a920);
  }
  KLObject* t924 = shen_intern(ctx, "vector");
  KLObject* t925 = shen_number_l(ctx, 0);
  KLObject* t926 = shen_empty_list(ctx);
  KLObject* t927 = shen_cons(ctx, t925, t926);
  KLObject* t928 = shen_cons(ctx, t924, t927);
  KLObject* t922;
  {
    KLObject* a922[] = {t900, t928};
    t922 = shen_apply_direct(ctx, "shen.comb", 2, a922);
  }
    t916 = t922;
  }
    t908 = t916;
  } else {
  KLObject* t929 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t908 = t929;
  }
    t902 = t908;
  } else {
  KLObject* t930 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t902 = t930;
  }
    t895 = t902;
  } else {
  KLObject* t931 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t895 = t931;
  }
  KLObject* t933;
  {
    KLObject* a933[] = {t895};
    t933 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a933);
  }
  KLObject* t932;
  if (!shen_is_boolean(ctx, t933))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t933)) {
  KLObject* t937 = shen_cons_p(ctx, t836);
  KLObject* t935;
  if (!shen_is_boolean(ctx, t937))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t937)) {
  KLObject* t938;
  {
    KLObject* a938[] = {t836};
    t938 = shen_apply_direct(ctx, "head", 1, a938);
  }
  KLObject* t940;
  {
    KLObject* a940[] = {t836};
    t940 = shen_apply_direct(ctx, "tail", 1, a940);
  }
  KLObject* t944 = shen_cons_p(ctx, t938);
  KLObject* t942;
  if (!shen_is_boolean(ctx, t944))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t944)) {
  KLObject* t947;
  {
    KLObject* a947[] = {t938};
    t947 = shen_apply_direct(ctx, "shen.constructor-error", 1, a947);
  }
  KLObject* t945;
  {
    KLObject* a945[] = {t940, t947};
    t945 = shen_apply_direct(ctx, "shen.comb", 2, a945);
  }
    t942 = t945;
  } else {
  KLObject* t949 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t942 = t949;
  }
    t935 = t942;
  } else {
  KLObject* t950 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t935 = t950;
  }
  KLObject* t952;
  {
    KLObject* a952[] = {t935};
    t952 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a952);
  }
  KLObject* t951;
  if (!shen_is_boolean(ctx, t952))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t952)) {
  KLObject* t954;
  {
    KLObject* a954[] = {t836};
    t954 = shen_apply_direct(ctx, "shen.<simple-pattern>", 1, a954);
  }
  KLObject* t957;
  {
    KLObject* a957[] = {t954};
    t957 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a957);
  }
  KLObject* t956;
  if (!shen_is_boolean(ctx, t957))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t957)) {
  KLObject* t959 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t956 = t959;
  } else {
  KLObject* t960;
  {
    KLObject* a960[] = {t954};
    t960 = shen_apply_direct(ctx, "shen.<-out", 1, a960);
  }
  KLObject* t962;
  {
    KLObject* a962[] = {t954};
    t962 = shen_apply_direct(ctx, "shen.in->", 1, a962);
  }
  KLObject* t964;
  {
    KLObject* a964[] = {t962, t960};
    t964 = shen_apply_direct(ctx, "shen.comb", 2, a964);
  }
    t956 = t964;
  }
  KLObject* t968;
  {
    KLObject* a968[] = {t956};
    t968 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a968);
  }
  KLObject* t967;
  if (!shen_is_boolean(ctx, t968))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t968)) {
  KLObject* t970 = shen_tail_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t967 = t970;
  } else {
    t967 = t956;
  }
    t951 = t967;
  } else {
    t951 = t935;
  }
    t932 = t951;
  } else {
    t932 = t895;
  }
    t892 = t932;
  } else {
    t892 = t837;
  }
    return t892;
  }
}

static KLObject* native_kl_shen_2e_3cconstructor_3e_15 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t975 = objects[0];
  tail_start_kl_shen_2e_3cconstructor_3e_15: ;
  KLObject* t978 = shen_cons_p(ctx, t975);
  KLObject* t976;
  if (!shen_is_boolean(ctx, t978))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t978)) {
  KLObject* t979;
  {
    KLObject* a979[] = {t975};
    t979 = shen_apply_direct(ctx, "head", 1, a979);
  }
  KLObject* t981;
  {
    KLObject* a981[] = {t975};
    t981 = shen_apply_direct(ctx, "tail", 1, a981);
  }
  KLObject* t984;
  {
    KLObject* a984[] = {t979};
    t984 = shen_apply_direct(ctx, "shen.constructor?", 1, a984);
  }
  KLObject* t983;
  if (!shen_is_boolean(ctx, t984))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t984)) {
  KLObject* t986;
  {
    KLObject* a986[] = {t981, t979};
    t986 = shen_apply_direct(ctx, "shen.comb", 2, a986);
  }
    t983 = t986;
  } else {
  KLObject* t989 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t983 = t989;
  }
    t976 = t983;
  } else {
  KLObject* t990 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t976 = t990;
  }
  KLObject* t992;
  {
    KLObject* a992[] = {t976};
    t992 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a992);
  }
  KLObject* t991;
  if (!shen_is_boolean(ctx, t992))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t992)) {
  KLObject* t994 = shen_tail_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t991 = t994;
  } else {
    t991 = t976;
  }
    return t991;
  }
}

static KLObject* native_kl_shen_2econstructor_3f_16 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t996 = objects[0];
  tail_start_kl_shen_2econstructor_3f_16: ;
  KLObject* t999 = shen_intern(ctx, "cons");
  KLObject* t1000 = shen_intern(ctx, "@p");
  KLObject* t1001 = shen_intern(ctx, "@s");
  KLObject* t1002 = shen_intern(ctx, "@v");
  KLObject* t1003 = shen_empty_list(ctx);
  KLObject* t1004 = shen_cons(ctx, t1002, t1003);
  KLObject* t1005 = shen_cons(ctx, t1001, t1004);
  KLObject* t1006 = shen_cons(ctx, t1000, t1005);
  KLObject* t1007 = shen_cons(ctx, t999, t1006);
  KLObject* t997;
  {
    KLObject* a997[] = {t996, t1007};
    t997 = shen_tail_apply_direct(ctx, "element?", 2, a997);
  }
    return t997;
  }
}

static KLObject* native_kl_shen_2econstructor_2derror_17 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t1008 = objects[0];
  tail_start_kl_shen_2econstructor_2derror_17: ;
  KLObject* t1012 = shen_string(ctx, " is not a legitimate constructor\n");
  KLObject* t1013 = shen_intern(ctx, "shen.r");
  KLObject* t1010;
  {
    KLObject* a1010[] = {t1008, t1012, t1013};
    t1010 = shen_apply_direct(ctx, "shen.app", 3, a1010);
  }
  KLObject* t1009;
  {
    KLObject* a1009[] = {t1010};
    t1009 = shen_tail_apply_direct(ctx, "simple-error", 1, a1009);
  }
    return t1009;
  }
}

static KLObject* native_kl_shen_2e_3csimple_2dpattern_3e_18 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t1014 = objects[0];
  tail_start_kl_shen_2e_3csimple_2dpattern_3e_18: ;
  KLObject* t1017 = shen_cons_p(ctx, t1014);
  KLObject* t1015;
  if (!shen_is_boolean(ctx, t1017))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1017)) {
  KLObject* t1018;
  {
    KLObject* a1018[] = {t1014};
    t1018 = shen_apply_direct(ctx, "head", 1, a1018);
  }
  KLObject* t1020;
  {
    KLObject* a1020[] = {t1014};
    t1020 = shen_apply_direct(ctx, "tail", 1, a1020);
  }
  KLObject* t1024 = shen_intern(ctx, "_");
  KLObject* t1025 = shen_eq(ctx, t1018, t1024);
  KLObject* t1022;
  if (!shen_is_boolean(ctx, t1025))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1025)) {
  KLObject* t1029 = shen_intern(ctx, "Y");
  KLObject* t1028;
  {
    KLObject* a1028[] = {t1029};
    t1028 = shen_apply_direct(ctx, "gensym", 1, a1028);
  }
  KLObject* t1026;
  {
    KLObject* a1026[] = {t1020, t1028};
    t1026 = shen_apply_direct(ctx, "shen.comb", 2, a1026);
  }
    t1022 = t1026;
  } else {
  KLObject* t1030 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t1022 = t1030;
  }
    t1015 = t1022;
  } else {
  KLObject* t1031 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t1015 = t1031;
  }
  KLObject* t1033;
  {
    KLObject* a1033[] = {t1015};
    t1033 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a1033);
  }
  KLObject* t1032;
  if (!shen_is_boolean(ctx, t1033))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1033)) {
  KLObject* t1037 = shen_cons_p(ctx, t1014);
  KLObject* t1035;
  if (!shen_is_boolean(ctx, t1037))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1037)) {
  KLObject* t1038;
  {
    KLObject* a1038[] = {t1014};
    t1038 = shen_apply_direct(ctx, "head", 1, a1038);
  }
  KLObject* t1040;
  {
    KLObject* a1040[] = {t1014};
    t1040 = shen_apply_direct(ctx, "tail", 1, a1040);
  }
  KLObject* t1046 = shen_intern(ctx, "->");
  KLObject* t1047 = shen_intern(ctx, "<-");
  KLObject* t1048 = shen_empty_list(ctx);
  KLObject* t1049 = shen_cons(ctx, t1047, t1048);
  KLObject* t1050 = shen_cons(ctx, t1046, t1049);
  KLObject* t1044;
  {
    KLObject* a1044[] = {t1038, t1050};
    t1044 = shen_apply_direct(ctx, "element?", 2, a1044);
  }
  KLObject* t1043;
  {
    KLObject* a1043[] = {t1044};
    t1043 = shen_apply_direct(ctx, "not", 1, a1043);
  }
  KLObject* t1042;
  if (!shen_is_boolean(ctx, t1043))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1043)) {
  KLObject* t1051;
  {
    KLObject* a1051[] = {t1040, t1038};
    t1051 = shen_apply_direct(ctx, "shen.comb", 2, a1051);
  }
    t1042 = t1051;
  } else {
  KLObject* t1054 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t1042 = t1054;
  }
    t1035 = t1042;
  } else {
  KLObject* t1055 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t1035 = t1055;
  }
  KLObject* t1057;
  {
    KLObject* a1057[] = {t1035};
    t1057 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a1057);
  }
  KLObject* t1056;
  if (!shen_is_boolean(ctx, t1057))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1057)) {
  KLObject* t1059 = shen_tail_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t1056 = t1059;
  } else {
    t1056 = t1035;
  }
    t1032 = t1056;
  } else {
    t1032 = t1015;
  }
    return t1032;
  }
}

static KLObject* native_kl_shen_2e_3cpattern1_3e_19 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t1062 = objects[0];
  tail_start_kl_shen_2e_3cpattern1_3e_19: ;
  KLObject* t1063;
  {
    KLObject* a1063[] = {t1062};
    t1063 = shen_apply_direct(ctx, "shen.<pattern>", 1, a1063);
  }
  KLObject* t1066;
  {
    KLObject* a1066[] = {t1063};
    t1066 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a1066);
  }
  KLObject* t1065;
  if (!shen_is_boolean(ctx, t1066))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1066)) {
  KLObject* t1068 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t1065 = t1068;
  } else {
  KLObject* t1069;
  {
    KLObject* a1069[] = {t1063};
    t1069 = shen_apply_direct(ctx, "shen.<-out", 1, a1069);
  }
  KLObject* t1071;
  {
    KLObject* a1071[] = {t1063};
    t1071 = shen_apply_direct(ctx, "shen.in->", 1, a1071);
  }
  KLObject* t1073;
  {
    KLObject* a1073[] = {t1071, t1069};
    t1073 = shen_apply_direct(ctx, "shen.comb", 2, a1073);
  }
    t1065 = t1073;
  }
  KLObject* t1077;
  {
    KLObject* a1077[] = {t1065};
    t1077 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a1077);
  }
  KLObject* t1076;
  if (!shen_is_boolean(ctx, t1077))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1077)) {
  KLObject* t1079 = shen_tail_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t1076 = t1079;
  } else {
    t1076 = t1065;
  }
    return t1076;
  }
}

static KLObject* native_kl_shen_2e_3cpattern2_3e_20 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t1081 = objects[0];
  tail_start_kl_shen_2e_3cpattern2_3e_20: ;
  KLObject* t1082;
  {
    KLObject* a1082[] = {t1081};
    t1082 = shen_apply_direct(ctx, "shen.<pattern>", 1, a1082);
  }
  KLObject* t1085;
  {
    KLObject* a1085[] = {t1082};
    t1085 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a1085);
  }
  KLObject* t1084;
  if (!shen_is_boolean(ctx, t1085))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1085)) {
  KLObject* t1087 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t1084 = t1087;
  } else {
  KLObject* t1088;
  {
    KLObject* a1088[] = {t1082};
    t1088 = shen_apply_direct(ctx, "shen.<-out", 1, a1088);
  }
  KLObject* t1090;
  {
    KLObject* a1090[] = {t1082};
    t1090 = shen_apply_direct(ctx, "shen.in->", 1, a1090);
  }
  KLObject* t1092;
  {
    KLObject* a1092[] = {t1090, t1088};
    t1092 = shen_apply_direct(ctx, "shen.comb", 2, a1092);
  }
    t1084 = t1092;
  }
  KLObject* t1096;
  {
    KLObject* a1096[] = {t1084};
    t1096 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a1096);
  }
  KLObject* t1095;
  if (!shen_is_boolean(ctx, t1096))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1096)) {
  KLObject* t1098 = shen_tail_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t1095 = t1098;
  } else {
    t1095 = t1084;
  }
    return t1095;
  }
}

static KLObject* native_kl_shen_2efn_2dprint_21 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t1100 = objects[0];
  tail_start_kl_shen_2efn_2dprint_21: ;
  KLObject* t1102 = shen_number_l(ctx, 2);
  KLObject* t1101;
  {
    KLObject* a1101[] = {t1102};
    t1101 = shen_apply_direct(ctx, "absvector", 1, a1101);
  }
  KLObject* t1105 = shen_number_l(ctx, 0);
  KLObject* t1106 = shen_intern(ctx, "shen.printF");
  KLObject* t1103;
  {
    KLObject* a1103[] = {t1101, t1105, t1106};
    t1103 = shen_apply_direct(ctx, "address->", 3, a1103);
  }
  KLObject* t1109 = shen_number_l(ctx, 1);
  KLObject* t1111 = shen_string(ctx, "(");
  KLObject* t1113 = shen_string(ctx, "f");
  KLObject* t1115 = shen_string(ctx, "n");
  KLObject* t1117 = shen_string(ctx, " ");
  KLObject* t1119;
  {
    KLObject* a1119[] = {t1100};
    t1119 = shen_apply_direct(ctx, "str", 1, a1119);
  }
  KLObject* t1121 = shen_string(ctx, ")");
  KLObject* t1118;
  {
    KLObject* a1118[] = {t1119, t1121};
    t1118 = shen_apply_direct(ctx, "@s", 2, a1118);
  }
  KLObject* t1116;
  {
    KLObject* a1116[] = {t1117, t1118};
    t1116 = shen_apply_direct(ctx, "@s", 2, a1116);
  }
  KLObject* t1114;
  {
    KLObject* a1114[] = {t1115, t1116};
    t1114 = shen_apply_direct(ctx, "@s", 2, a1114);
  }
  KLObject* t1112;
  {
    KLObject* a1112[] = {t1113, t1114};
    t1112 = shen_apply_direct(ctx, "@s", 2, a1112);
  }
  KLObject* t1110;
  {
    KLObject* a1110[] = {t1111, t1112};
    t1110 = shen_apply_direct(ctx, "@s", 2, a1110);
  }
  KLObject* t1107;
  {
    KLObject* a1107[] = {t1103, t1109, t1110};
    t1107 = shen_apply_direct(ctx, "address->", 3, a1107);
  }
    return t1107;
  }
}

static KLObject* native_kl_shen_2eprintF_22 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t1123 = objects[0];
  tail_start_kl_shen_2eprintF_22: ;
  KLObject* t1126 = shen_number_l(ctx, 1);
  KLObject* t1124;
  {
    KLObject* a1124[] = {t1123, t1126};
    t1124 = shen_tail_apply_direct(ctx, "<-address", 2, a1124);
  }
    return t1124;
  }
}

static KLObject* native_kl_shen_2earity_2dchk_23 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t1127 = objects[0];
    KLObject* t1128 = objects[1];
  tail_start_kl_shen_2earity_2dchk_23: ;
  KLObject* t1129;
  {
  KLObject* t1132 = shen_cons_p(ctx, t1128);
  KLObject* t1130;
  if (!shen_is_boolean(ctx, t1132))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t1132)) {
    t1130 = t1132;
  } else {
  KLObject* t1133 = shen_empty_list(ctx);
  KLObject* t1135 = shen_tl(ctx, t1128);
  KLObject* t1136 = shen_eq(ctx, t1133, t1135);
    if (!shen_is_boolean(ctx, t1136))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t1130 = t1136;
  }
    if (!shen_is_boolean(ctx, t1130))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t1130)) {
  KLObject* t1139 = shen_hd(ctx, t1128);
  KLObject* t1137;
  {
    KLObject* a1137[] = {t1139};
    t1137 = shen_tail_apply_direct(ctx, "length", 1, a1137);
  }
      t1129 = t1137;
    } else {
  KLObject* t1142 = shen_cons_p(ctx, t1128);
  KLObject* t1140;
  if (!shen_is_boolean(ctx, t1142))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t1142)) {
    t1140 = t1142;
  } else {
  KLObject* t1145 = shen_tl(ctx, t1128);
  KLObject* t1146 = shen_cons_p(ctx, t1145);
  KLObject* t1143;
  if (!shen_is_boolean(ctx, t1146))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t1146)) {
    t1143 = t1146;
  } else {
  KLObject* t1149 = shen_hd(ctx, t1128);
  KLObject* t1147;
  {
    KLObject* a1147[] = {t1149};
    t1147 = shen_apply_direct(ctx, "length", 1, a1147);
  }
  KLObject* t1152 = shen_tl(ctx, t1128);
  KLObject* t1153 = shen_hd(ctx, t1152);
  KLObject* t1150;
  {
    KLObject* a1150[] = {t1153};
    t1150 = shen_apply_direct(ctx, "length", 1, a1150);
  }
  KLObject* t1154 = shen_eq(ctx, t1147, t1150);
    if (!shen_is_boolean(ctx, t1154))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t1143 = t1154;
  }
    if (!shen_is_boolean(ctx, t1143))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t1140 = t1143;
  }
    if (!shen_is_boolean(ctx, t1140))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t1140)) {
  KLObject* t1157 = shen_tl(ctx, t1128);
  {
    KLObject* n1158_0 = t1127;
    KLObject* n1158_1 = t1157;
    t1127 = n1158_0;
    t1128 = n1158_1;
    goto tail_start_kl_shen_2earity_2dchk_23;
  }
  KLObject* t1158 = NULL;
      t1129 = t1158;
    } else {
  KLObject* t1159 = shen_true(ctx);
    if (!shen_is_boolean(ctx, t1159))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t1159)) {
  KLObject* t1162 = shen_string(ctx, "arity error in ");
  KLObject* t1165 = shen_string(ctx, "\n");
  KLObject* t1166 = shen_intern(ctx, "shen.a");
  KLObject* t1163;
  {
    KLObject* a1163[] = {t1127, t1165, t1166};
    t1163 = shen_apply_direct(ctx, "shen.app", 3, a1163);
  }
  KLObject* t1161;
  {
    KLObject* a1161[] = {t1162, t1163};
    t1161 = shen_apply_direct(ctx, "cn", 2, a1161);
  }
  KLObject* t1160;
  {
    KLObject* a1160[] = {t1161};
    t1160 = shen_tail_apply_direct(ctx, "simple-error", 1, a1160);
  }
      t1129 = t1160;
    } else {
      shen_simple_error(ctx, "No true case found for cond");
      t1129 = shen_empty_list(ctx);
    }
    }
    }
  }
    return t1129;
  }
}

static KLObject* native_kl_shen_2efree_2dvar_2dchk_24 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t1167 = objects[0];
    KLObject* t1168 = objects[1];
  tail_start_kl_shen_2efree_2dvar_2dchk_24: ;
  KLObject* t1169;
  {
  KLObject* t1170;
  {
    KLObject* a1170[] = {t1168};
    t1170 = shen_apply_direct(ctx, "tuple?", 1, a1170);
  }
    if (!shen_is_boolean(ctx, t1170))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t1170)) {
  KLObject* t1176;
  {
    KLObject* a1176[] = {t1168};
    t1176 = shen_apply_direct(ctx, "fst", 1, a1176);
  }
  KLObject* t1175;
  {
    KLObject* a1175[] = {t1176};
    t1175 = shen_apply_direct(ctx, "shen.extract-vars", 1, a1175);
  }
  KLObject* t1178;
  {
    KLObject* a1178[] = {t1168};
    t1178 = shen_apply_direct(ctx, "snd", 1, a1178);
  }
  KLObject* t1174;
  {
    KLObject* a1174[] = {t1175, t1178};
    t1174 = shen_apply_direct(ctx, "shen.find-free-vars", 2, a1174);
  }
  KLObject* t1172;
  {
    KLObject* a1172[] = {t1167, t1174};
    t1172 = shen_tail_apply_direct(ctx, "shen.free-variable-error-message", 2, a1172);
  }
      t1169 = t1172;
    } else {
  KLObject* t1180 = shen_true(ctx);
    if (!shen_is_boolean(ctx, t1180))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t1180)) {
  KLObject* t1182 = shen_string(ctx, "partial function shen.free-var-chk");
  KLObject* t1181;
  {
    KLObject* a1181[] = {t1182};
    t1181 = shen_tail_apply_direct(ctx, "simple-error", 1, a1181);
  }
      t1169 = t1181;
    } else {
      shen_simple_error(ctx, "No true case found for cond");
      t1169 = shen_empty_list(ctx);
    }
    }
  }
    return t1169;
  }
}

static KLObject* native_kl_shen_2efree_2dvariable_2derror_2dmessage_25 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t1183 = objects[0];
    KLObject* t1184 = objects[1];
  tail_start_kl_shen_2efree_2dvariable_2derror_2dmessage_25: ;
  KLObject* t1186;
  {
    KLObject* a1186[] = {t1184};
    t1186 = shen_apply_direct(ctx, "empty?", 1, a1186);
  }
  KLObject* t1185;
  if (!shen_is_boolean(ctx, t1186))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1186)) {
  KLObject* t1188 = shen_intern(ctx, "shen.skip");
    t1185 = t1188;
  } else {
  KLObject* t1191 = shen_string(ctx, "free variables in ");
  KLObject* t1194 = shen_string(ctx, ":");
  KLObject* t1195 = shen_intern(ctx, "shen.a");
  KLObject* t1192;
  {
    KLObject* a1192[] = {t1183, t1194, t1195};
    t1192 = shen_apply_direct(ctx, "shen.app", 3, a1192);
  }
  KLObject* t1190;
  {
    KLObject* a1190[] = {t1191, t1192};
    t1190 = shen_apply_direct(ctx, "cn", 2, a1190);
  }
  KLObject* t1196 = shen_apply_direct(ctx, "stoutput", 0, NULL);
  KLObject* t1189;
  {
    KLObject* a1189[] = {t1190, t1196};
    t1189 = shen_apply_direct(ctx, "pr", 2, a1189);
  }
  KLObject* t1198;
  {
    Vector* caps_5 = shen_vector(ctx, 0);
    t1198 = shen_native_closure(ctx, 1, &lambda_5, caps_5);
  }
  KLObject* t1197;
  {
    KLObject* a1197[] = {t1198, t1184};
    t1197 = shen_apply_direct(ctx, "map", 2, a1197);
  }
  KLObject* t1210 = shen_number_l(ctx, 1);
  KLObject* t1209;
  {
    KLObject* a1209[] = {t1210};
    t1209 = shen_apply_direct(ctx, "nl", 1, a1209);
  }
  KLObject* t1211 = shen_tail_apply_direct(ctx, "abort", 0, NULL);
    t1185 = t1211;
  }
    return t1185;
  }
}

static KLObject* native_kl_shen_2eextract_2dvars_26 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t1212 = objects[0];
  tail_start_kl_shen_2eextract_2dvars_26: ;
  KLObject* t1213;
  {
  KLObject* t1214;
  {
    KLObject* a1214[] = {t1212};
    t1214 = shen_apply_direct(ctx, "variable?", 1, a1214);
  }
    if (!shen_is_boolean(ctx, t1214))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t1214)) {
  KLObject* t1217 = shen_empty_list(ctx);
  KLObject* t1218 = shen_cons(ctx, t1212, t1217);
      t1213 = t1218;
    } else {
  KLObject* t1220 = shen_cons_p(ctx, t1212);
    if (!shen_is_boolean(ctx, t1220))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t1220)) {
  KLObject* t1224 = shen_hd(ctx, t1212);
  KLObject* t1222;
  {
    KLObject* a1222[] = {t1224};
    t1222 = shen_apply_direct(ctx, "shen.extract-vars", 1, a1222);
  }
  KLObject* t1227 = shen_tl(ctx, t1212);
  KLObject* t1225;
  {
    KLObject* a1225[] = {t1227};
    t1225 = shen_apply_direct(ctx, "shen.extract-vars", 1, a1225);
  }
  KLObject* t1221;
  {
    KLObject* a1221[] = {t1222, t1225};
    t1221 = shen_tail_apply_direct(ctx, "union", 2, a1221);
  }
      t1213 = t1221;
    } else {
  KLObject* t1228 = shen_true(ctx);
    if (!shen_is_boolean(ctx, t1228))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t1228)) {
  KLObject* t1229 = shen_empty_list(ctx);
      t1213 = t1229;
    } else {
      shen_simple_error(ctx, "No true case found for cond");
      t1213 = shen_empty_list(ctx);
    }
    }
    }
  }
    return t1213;
  }
}

static KLObject* native_kl_shen_2efind_2dfree_2dvars_27 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t1230 = objects[0];
    KLObject* t1231 = objects[1];
  tail_start_kl_shen_2efind_2dfree_2dvars_27: ;
  KLObject* t1232;
  {
  KLObject* t1235 = shen_cons_p(ctx, t1231);
  KLObject* t1233;
  if (!shen_is_boolean(ctx, t1235))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t1235)) {
    t1233 = t1235;
  } else {
  KLObject* t1237 = shen_intern(ctx, "protect");
  KLObject* t1239 = shen_hd(ctx, t1231);
  KLObject* t1240 = shen_eq(ctx, t1237, t1239);
  KLObject* t1236;
  if (!shen_is_boolean(ctx, t1240))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t1240)) {
    t1236 = t1240;
  } else {
  KLObject* t1243 = shen_tl(ctx, t1231);
  KLObject* t1244 = shen_cons_p(ctx, t1243);
  KLObject* t1241;
  if (!shen_is_boolean(ctx, t1244))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t1244)) {
    t1241 = t1244;
  } else {
  KLObject* t1245 = shen_empty_list(ctx);
  KLObject* t1247 = shen_tl(ctx, t1231);
  KLObject* t1248 = shen_tl(ctx, t1247);
  KLObject* t1249 = shen_eq(ctx, t1245, t1248);
    if (!shen_is_boolean(ctx, t1249))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t1241 = t1249;
  }
    if (!shen_is_boolean(ctx, t1241))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t1236 = t1241;
  }
    if (!shen_is_boolean(ctx, t1236))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t1233 = t1236;
  }
    if (!shen_is_boolean(ctx, t1233))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t1233)) {
  KLObject* t1250 = shen_empty_list(ctx);
      t1232 = t1250;
    } else {
  KLObject* t1253 = shen_cons_p(ctx, t1231);
  KLObject* t1251;
  if (!shen_is_boolean(ctx, t1253))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t1253)) {
    t1251 = t1253;
  } else {
  KLObject* t1255 = shen_intern(ctx, "let");
  KLObject* t1257 = shen_hd(ctx, t1231);
  KLObject* t1258 = shen_eq(ctx, t1255, t1257);
  KLObject* t1254;
  if (!shen_is_boolean(ctx, t1258))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t1258)) {
    t1254 = t1258;
  } else {
  KLObject* t1261 = shen_tl(ctx, t1231);
  KLObject* t1262 = shen_cons_p(ctx, t1261);
  KLObject* t1259;
  if (!shen_is_boolean(ctx, t1262))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t1262)) {
    t1259 = t1262;
  } else {
  KLObject* t1265 = shen_tl(ctx, t1231);
  KLObject* t1266 = shen_tl(ctx, t1265);
  KLObject* t1267 = shen_cons_p(ctx, t1266);
  KLObject* t1263;
  if (!shen_is_boolean(ctx, t1267))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t1267)) {
    t1263 = t1267;
  } else {
  KLObject* t1270 = shen_tl(ctx, t1231);
  KLObject* t1271 = shen_tl(ctx, t1270);
  KLObject* t1272 = shen_tl(ctx, t1271);
  KLObject* t1273 = shen_cons_p(ctx, t1272);
  KLObject* t1268;
  if (!shen_is_boolean(ctx, t1273))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t1273)) {
    t1268 = t1273;
  } else {
  KLObject* t1274 = shen_empty_list(ctx);
  KLObject* t1276 = shen_tl(ctx, t1231);
  KLObject* t1277 = shen_tl(ctx, t1276);
  KLObject* t1278 = shen_tl(ctx, t1277);
  KLObject* t1279 = shen_tl(ctx, t1278);
  KLObject* t1280 = shen_eq(ctx, t1274, t1279);
    if (!shen_is_boolean(ctx, t1280))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t1268 = t1280;
  }
    if (!shen_is_boolean(ctx, t1268))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t1263 = t1268;
  }
    if (!shen_is_boolean(ctx, t1263))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t1259 = t1263;
  }
    if (!shen_is_boolean(ctx, t1259))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t1254 = t1259;
  }
    if (!shen_is_boolean(ctx, t1254))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t1251 = t1254;
  }
    if (!shen_is_boolean(ctx, t1251))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t1251)) {
  KLObject* t1285 = shen_tl(ctx, t1231);
  KLObject* t1286 = shen_tl(ctx, t1285);
  KLObject* t1287 = shen_hd(ctx, t1286);
  KLObject* t1282;
  {
    KLObject* a1282[] = {t1230, t1287};
    t1282 = shen_apply_direct(ctx, "shen.find-free-vars", 2, a1282);
  }
  KLObject* t1290 = shen_tl(ctx, t1231);
  KLObject* t1291 = shen_hd(ctx, t1290);
  KLObject* t1293 = shen_cons(ctx, t1291, t1230);
  KLObject* t1295 = shen_tl(ctx, t1231);
  KLObject* t1296 = shen_tl(ctx, t1295);
  KLObject* t1297 = shen_tl(ctx, t1296);
  KLObject* t1298 = shen_hd(ctx, t1297);
  KLObject* t1288;
  {
    KLObject* a1288[] = {t1293, t1298};
    t1288 = shen_apply_direct(ctx, "shen.find-free-vars", 2, a1288);
  }
  KLObject* t1281;
  {
    KLObject* a1281[] = {t1282, t1288};
    t1281 = shen_tail_apply_direct(ctx, "union", 2, a1281);
  }
      t1232 = t1281;
    } else {
  KLObject* t1301 = shen_cons_p(ctx, t1231);
  KLObject* t1299;
  if (!shen_is_boolean(ctx, t1301))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t1301)) {
    t1299 = t1301;
  } else {
  KLObject* t1303 = shen_intern(ctx, "lambda");
  KLObject* t1305 = shen_hd(ctx, t1231);
  KLObject* t1306 = shen_eq(ctx, t1303, t1305);
  KLObject* t1302;
  if (!shen_is_boolean(ctx, t1306))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t1306)) {
    t1302 = t1306;
  } else {
  KLObject* t1309 = shen_tl(ctx, t1231);
  KLObject* t1310 = shen_cons_p(ctx, t1309);
  KLObject* t1307;
  if (!shen_is_boolean(ctx, t1310))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t1310)) {
    t1307 = t1310;
  } else {
  KLObject* t1313 = shen_tl(ctx, t1231);
  KLObject* t1314 = shen_tl(ctx, t1313);
  KLObject* t1315 = shen_cons_p(ctx, t1314);
  KLObject* t1311;
  if (!shen_is_boolean(ctx, t1315))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t1315)) {
    t1311 = t1315;
  } else {
  KLObject* t1316 = shen_empty_list(ctx);
  KLObject* t1318 = shen_tl(ctx, t1231);
  KLObject* t1319 = shen_tl(ctx, t1318);
  KLObject* t1320 = shen_tl(ctx, t1319);
  KLObject* t1321 = shen_eq(ctx, t1316, t1320);
    if (!shen_is_boolean(ctx, t1321))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t1311 = t1321;
  }
    if (!shen_is_boolean(ctx, t1311))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t1307 = t1311;
  }
    if (!shen_is_boolean(ctx, t1307))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t1302 = t1307;
  }
    if (!shen_is_boolean(ctx, t1302))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t1299 = t1302;
  }
    if (!shen_is_boolean(ctx, t1299))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t1299)) {
  KLObject* t1323 = shen_tl(ctx, t1231);
  KLObject* t1324 = shen_hd(ctx, t1323);
  KLObject* t1326 = shen_cons(ctx, t1324, t1230);
  KLObject* t1328 = shen_tl(ctx, t1231);
  KLObject* t1329 = shen_tl(ctx, t1328);
  KLObject* t1330 = shen_hd(ctx, t1329);
  {
    KLObject* n1331_0 = t1326;
    KLObject* n1331_1 = t1330;
    t1230 = n1331_0;
    t1231 = n1331_1;
    goto tail_start_kl_shen_2efind_2dfree_2dvars_27;
  }
  KLObject* t1331 = NULL;
      t1232 = t1331;
    } else {
  KLObject* t1333 = shen_cons_p(ctx, t1231);
    if (!shen_is_boolean(ctx, t1333))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t1333)) {
  KLObject* t1338 = shen_hd(ctx, t1231);
  KLObject* t1335;
  {
    KLObject* a1335[] = {t1230, t1338};
    t1335 = shen_apply_direct(ctx, "shen.find-free-vars", 2, a1335);
  }
  KLObject* t1342 = shen_tl(ctx, t1231);
  KLObject* t1339;
  {
    KLObject* a1339[] = {t1230, t1342};
    t1339 = shen_apply_direct(ctx, "shen.find-free-vars", 2, a1339);
  }
  KLObject* t1334;
  {
    KLObject* a1334[] = {t1335, t1339};
    t1334 = shen_tail_apply_direct(ctx, "union", 2, a1334);
  }
      t1232 = t1334;
    } else {
  KLObject* t1343;
  {
    KLObject* a1343[] = {t1231, t1230};
    t1343 = shen_apply_direct(ctx, "shen.free-variable?", 2, a1343);
  }
    if (!shen_is_boolean(ctx, t1343))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t1343)) {
  KLObject* t1347 = shen_empty_list(ctx);
  KLObject* t1348 = shen_cons(ctx, t1231, t1347);
      t1232 = t1348;
    } else {
  KLObject* t1349 = shen_true(ctx);
    if (!shen_is_boolean(ctx, t1349))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t1349)) {
  KLObject* t1350 = shen_empty_list(ctx);
      t1232 = t1350;
    } else {
      shen_simple_error(ctx, "No true case found for cond");
      t1232 = shen_empty_list(ctx);
    }
    }
    }
    }
    }
    }
  }
    return t1232;
  }
}

static KLObject* native_kl_shen_2efree_2dvariable_3f_28 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t1351 = objects[0];
    KLObject* t1352 = objects[1];
  tail_start_kl_shen_2efree_2dvariable_3f_28: ;
  KLObject* t1354;
  {
    KLObject* a1354[] = {t1351};
    t1354 = shen_apply_direct(ctx, "variable?", 1, a1354);
  }
  KLObject* t1353;
  if (!shen_is_boolean(ctx, t1354))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t1354)) {
    t1353 = t1354;
  } else {
  KLObject* t1357;
  {
    KLObject* a1357[] = {t1351, t1352};
    t1357 = shen_apply_direct(ctx, "element?", 2, a1357);
  }
  KLObject* t1356;
  {
    KLObject* a1356[] = {t1357};
    t1356 = shen_apply_direct(ctx, "not", 1, a1356);
  }
    if (!shen_is_boolean(ctx, t1356))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t1353 = t1356;
  }
    return t1353;
  }
}

static KLObject* native_kl_shen_2erecord_2dkl_29 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t1360 = objects[0];
    KLObject* t1361 = objects[1];
  tail_start_kl_shen_2erecord_2dkl_29: ;
  KLObject* t1363 = shen_intern(ctx, "shen.*userdefs*");
  KLObject* t1367 = shen_intern(ctx, "shen.*userdefs*");
  KLObject* t1366;
  {
    KLObject* a1366[] = {t1367};
    t1366 = shen_apply_direct(ctx, "value", 1, a1366);
  }
  KLObject* t1364;
  {
    KLObject* a1364[] = {t1360, t1366};
    t1364 = shen_apply_direct(ctx, "adjoin", 2, a1364);
  }
  KLObject* t1362;
  {
    KLObject* a1362[] = {t1363, t1364};
    t1362 = shen_apply_direct(ctx, "set", 2, a1362);
  }
  KLObject* t1370 = shen_intern(ctx, "shen.source");
  KLObject* t1373 = shen_intern(ctx, "*property-vector*");
  KLObject* t1372;
  {
    KLObject* a1372[] = {t1373};
    t1372 = shen_apply_direct(ctx, "value", 1, a1372);
  }
  KLObject* t1368;
  {
    KLObject* a1368[] = {t1360, t1370, t1361, t1372};
    t1368 = shen_tail_apply_direct(ctx, "put", 4, a1368);
  }
    return t1368;
  }
}

static KLObject* native_kl_shen_2ecompile_2dto_2dkl_30 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t1374 = objects[0];
    KLObject* t1375 = objects[1];
    KLObject* t1376 = objects[2];
  tail_start_kl_shen_2ecompile_2dto_2dkl_30: ;
  KLObject* t1377;
  {
    KLObject* a1377[] = {t1376};
    t1377 = shen_apply_direct(ctx, "shen.parameters", 1, a1377);
  }
  KLObject* t1381;
  {
    KLObject* a1381[] = {t1375, t1377};
    t1381 = shen_apply_direct(ctx, "shen.kl-body", 2, a1381);
  }
  KLObject* t1379;
  {
    KLObject* a1379[] = {t1374, t1381};
    t1379 = shen_apply_direct(ctx, "shen.scan-body", 2, a1379);
  }
  KLObject* t1384 = shen_intern(ctx, "defun");
  KLObject* t1387;
  {
    KLObject* a1387[] = {t1379};
    t1387 = shen_apply_direct(ctx, "shen.cond-form", 1, a1387);
  }
  KLObject* t1389 = shen_empty_list(ctx);
  KLObject* t1390 = shen_cons(ctx, t1387, t1389);
  KLObject* t1391 = shen_cons(ctx, t1377, t1390);
  KLObject* t1392 = shen_cons(ctx, t1374, t1391);
  KLObject* t1393 = shen_cons(ctx, t1384, t1392);
    return t1393;
  }
}

static KLObject* native_kl_shen_2eparameters_31 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t1395 = objects[0];
  tail_start_kl_shen_2eparameters_31: ;
  KLObject* t1396;
  {
  KLObject* t1397 = shen_number_l(ctx, 0);
  KLObject* t1399 = shen_eq(ctx, t1397, t1395);
    if (!shen_is_boolean(ctx, t1399))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t1399)) {
  KLObject* t1400 = shen_empty_list(ctx);
      t1396 = t1400;
    } else {
  KLObject* t1401 = shen_true(ctx);
    if (!shen_is_boolean(ctx, t1401))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t1401)) {
  KLObject* t1403 = shen_intern(ctx, "V");
  KLObject* t1402;
  {
    KLObject* a1402[] = {t1403};
    t1402 = shen_apply_direct(ctx, "gensym", 1, a1402);
  }
  KLObject* t1406 = shen_number_l(ctx, 1);
  KLObject* t1407 = shen_sub(ctx, t1395, t1406);
  KLObject* t1404;
  {
    KLObject* a1404[] = {t1407};
    t1404 = shen_apply_direct(ctx, "shen.parameters", 1, a1404);
  }
  KLObject* t1408 = shen_cons(ctx, t1402, t1404);
      t1396 = t1408;
    } else {
      shen_simple_error(ctx, "No true case found for cond");
      t1396 = shen_empty_list(ctx);
    }
    }
  }
    return t1396;
  }
}

static KLObject* native_kl_shen_2econd_2dform_32 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t1409 = objects[0];
  tail_start_kl_shen_2econd_2dform_32: ;
  KLObject* t1410;
  {
  KLObject* t1413 = shen_cons_p(ctx, t1409);
  KLObject* t1411;
  if (!shen_is_boolean(ctx, t1413))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t1413)) {
    t1411 = t1413;
  } else {
  KLObject* t1416 = shen_hd(ctx, t1409);
  KLObject* t1417 = shen_cons_p(ctx, t1416);
  KLObject* t1414;
  if (!shen_is_boolean(ctx, t1417))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t1417)) {
    t1414 = t1417;
  } else {
  KLObject* t1419 = shen_true(ctx);
  KLObject* t1421 = shen_hd(ctx, t1409);
  KLObject* t1422 = shen_hd(ctx, t1421);
  KLObject* t1423 = shen_eq(ctx, t1419, t1422);
  KLObject* t1418;
  if (!shen_is_boolean(ctx, t1423))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t1423)) {
    t1418 = t1423;
  } else {
  KLObject* t1426 = shen_hd(ctx, t1409);
  KLObject* t1427 = shen_tl(ctx, t1426);
  KLObject* t1428 = shen_cons_p(ctx, t1427);
  KLObject* t1424;
  if (!shen_is_boolean(ctx, t1428))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t1428)) {
    t1424 = t1428;
  } else {
  KLObject* t1429 = shen_empty_list(ctx);
  KLObject* t1431 = shen_hd(ctx, t1409);
  KLObject* t1432 = shen_tl(ctx, t1431);
  KLObject* t1433 = shen_tl(ctx, t1432);
  KLObject* t1434 = shen_eq(ctx, t1429, t1433);
    if (!shen_is_boolean(ctx, t1434))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t1424 = t1434;
  }
    if (!shen_is_boolean(ctx, t1424))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t1418 = t1424;
  }
    if (!shen_is_boolean(ctx, t1418))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t1414 = t1418;
  }
    if (!shen_is_boolean(ctx, t1414))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t1411 = t1414;
  }
    if (!shen_is_boolean(ctx, t1411))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t1411)) {
  KLObject* t1436 = shen_hd(ctx, t1409);
  KLObject* t1437 = shen_tl(ctx, t1436);
  KLObject* t1438 = shen_hd(ctx, t1437);
      t1410 = t1438;
    } else {
  KLObject* t1439 = shen_true(ctx);
    if (!shen_is_boolean(ctx, t1439))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t1439)) {
  KLObject* t1440 = shen_intern(ctx, "cond");
  KLObject* t1442 = shen_cons(ctx, t1440, t1409);
      t1410 = t1442;
    } else {
      shen_simple_error(ctx, "No true case found for cond");
      t1410 = shen_empty_list(ctx);
    }
    }
  }
    return t1410;
  }
}

static KLObject* native_kl_shen_2escan_2dbody_33 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t1443 = objects[0];
    KLObject* t1444 = objects[1];
  tail_start_kl_shen_2escan_2dbody_33: ;
  KLObject* t1445;
  {
  KLObject* t1446 = shen_empty_list(ctx);
  KLObject* t1448 = shen_eq(ctx, t1446, t1444);
    if (!shen_is_boolean(ctx, t1448))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t1448)) {
  KLObject* t1449 = shen_true(ctx);
  KLObject* t1450 = shen_intern(ctx, "shen.f-error");
  KLObject* t1452 = shen_empty_list(ctx);
  KLObject* t1453 = shen_cons(ctx, t1443, t1452);
  KLObject* t1454 = shen_cons(ctx, t1450, t1453);
  KLObject* t1455 = shen_empty_list(ctx);
  KLObject* t1456 = shen_cons(ctx, t1454, t1455);
  KLObject* t1457 = shen_cons(ctx, t1449, t1456);
  KLObject* t1458 = shen_empty_list(ctx);
  KLObject* t1459 = shen_cons(ctx, t1457, t1458);
      t1445 = t1459;
    } else {
  KLObject* t1462 = shen_cons_p(ctx, t1444);
  KLObject* t1460;
  if (!shen_is_boolean(ctx, t1462))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t1462)) {
    t1460 = t1462;
  } else {
  KLObject* t1465 = shen_hd(ctx, t1444);
  KLObject* t1463;
  {
    KLObject* a1463[] = {t1465};
    t1463 = shen_apply_direct(ctx, "shen.choicepoint?", 1, a1463);
  }
    if (!shen_is_boolean(ctx, t1463))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t1460 = t1463;
  }
    if (!shen_is_boolean(ctx, t1460))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t1460)) {
  KLObject* t1469 = shen_intern(ctx, "Freeze");
  KLObject* t1468;
  {
    KLObject* a1468[] = {t1469};
    t1468 = shen_apply_direct(ctx, "gensym", 1, a1468);
  }
  KLObject* t1471 = shen_intern(ctx, "Result");
  KLObject* t1470;
  {
    KLObject* a1470[] = {t1471};
    t1470 = shen_apply_direct(ctx, "gensym", 1, a1470);
  }
  KLObject* t1473 = shen_hd(ctx, t1444);
  KLObject* t1475 = shen_tl(ctx, t1444);
  KLObject* t1466;
  {
    KLObject* a1466[] = {t1443, t1468, t1470, t1473, t1475};
    t1466 = shen_tail_apply_direct(ctx, "shen.choicepoint", 5, a1466);
  }
      t1445 = t1466;
    } else {
  KLObject* t1478 = shen_cons_p(ctx, t1444);
  KLObject* t1476;
  if (!shen_is_boolean(ctx, t1478))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t1478)) {
    t1476 = t1478;
  } else {
  KLObject* t1481 = shen_hd(ctx, t1444);
  KLObject* t1482 = shen_cons_p(ctx, t1481);
  KLObject* t1479;
  if (!shen_is_boolean(ctx, t1482))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t1482)) {
    t1479 = t1482;
  } else {
  KLObject* t1484 = shen_true(ctx);
  KLObject* t1486 = shen_hd(ctx, t1444);
  KLObject* t1487 = shen_hd(ctx, t1486);
  KLObject* t1488 = shen_eq(ctx, t1484, t1487);
  KLObject* t1483;
  if (!shen_is_boolean(ctx, t1488))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t1488)) {
    t1483 = t1488;
  } else {
  KLObject* t1491 = shen_hd(ctx, t1444);
  KLObject* t1492 = shen_tl(ctx, t1491);
  KLObject* t1493 = shen_cons_p(ctx, t1492);
  KLObject* t1489;
  if (!shen_is_boolean(ctx, t1493))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t1493)) {
    t1489 = t1493;
  } else {
  KLObject* t1494 = shen_empty_list(ctx);
  KLObject* t1496 = shen_hd(ctx, t1444);
  KLObject* t1497 = shen_tl(ctx, t1496);
  KLObject* t1498 = shen_tl(ctx, t1497);
  KLObject* t1499 = shen_eq(ctx, t1494, t1498);
    if (!shen_is_boolean(ctx, t1499))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t1489 = t1499;
  }
    if (!shen_is_boolean(ctx, t1489))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t1483 = t1489;
  }
    if (!shen_is_boolean(ctx, t1483))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t1479 = t1483;
  }
    if (!shen_is_boolean(ctx, t1479))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t1476 = t1479;
  }
    if (!shen_is_boolean(ctx, t1476))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t1476)) {
  KLObject* t1501 = shen_hd(ctx, t1444);
  KLObject* t1502 = shen_empty_list(ctx);
  KLObject* t1503 = shen_cons(ctx, t1501, t1502);
      t1445 = t1503;
    } else {
  KLObject* t1505 = shen_cons_p(ctx, t1444);
    if (!shen_is_boolean(ctx, t1505))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t1505)) {
  KLObject* t1507 = shen_hd(ctx, t1444);
  KLObject* t1511 = shen_tl(ctx, t1444);
  KLObject* t1508;
  {
    KLObject* a1508[] = {t1443, t1511};
    t1508 = shen_apply_direct(ctx, "shen.scan-body", 2, a1508);
  }
  KLObject* t1512 = shen_cons(ctx, t1507, t1508);
      t1445 = t1512;
    } else {
  KLObject* t1513 = shen_true(ctx);
    if (!shen_is_boolean(ctx, t1513))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t1513)) {
  KLObject* t1515 = shen_string(ctx, "implementation error in shen.scan-body");
  KLObject* t1514;
  {
    KLObject* a1514[] = {t1515};
    t1514 = shen_tail_apply_direct(ctx, "simple-error", 1, a1514);
  }
      t1445 = t1514;
    } else {
      shen_simple_error(ctx, "No true case found for cond");
      t1445 = shen_empty_list(ctx);
    }
    }
    }
    }
    }
  }
    return t1445;
  }
}

static KLObject* native_kl_shen_2echoicepoint_3f_34 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t1516 = objects[0];
  tail_start_kl_shen_2echoicepoint_3f_34: ;
  KLObject* t1517;
  {
  KLObject* t1520 = shen_cons_p(ctx, t1516);
  KLObject* t1518;
  if (!shen_is_boolean(ctx, t1520))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t1520)) {
    t1518 = t1520;
  } else {
  KLObject* t1523 = shen_tl(ctx, t1516);
  KLObject* t1524 = shen_cons_p(ctx, t1523);
  KLObject* t1521;
  if (!shen_is_boolean(ctx, t1524))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t1524)) {
    t1521 = t1524;
  } else {
  KLObject* t1527 = shen_tl(ctx, t1516);
  KLObject* t1528 = shen_hd(ctx, t1527);
  KLObject* t1529 = shen_cons_p(ctx, t1528);
  KLObject* t1525;
  if (!shen_is_boolean(ctx, t1529))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t1529)) {
    t1525 = t1529;
  } else {
  KLObject* t1531 = shen_intern(ctx, "shen.choicepoint!");
  KLObject* t1533 = shen_tl(ctx, t1516);
  KLObject* t1534 = shen_hd(ctx, t1533);
  KLObject* t1535 = shen_hd(ctx, t1534);
  KLObject* t1536 = shen_eq(ctx, t1531, t1535);
  KLObject* t1530;
  if (!shen_is_boolean(ctx, t1536))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t1536)) {
    t1530 = t1536;
  } else {
  KLObject* t1539 = shen_tl(ctx, t1516);
  KLObject* t1540 = shen_hd(ctx, t1539);
  KLObject* t1541 = shen_tl(ctx, t1540);
  KLObject* t1542 = shen_cons_p(ctx, t1541);
  KLObject* t1537;
  if (!shen_is_boolean(ctx, t1542))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t1542)) {
    t1537 = t1542;
  } else {
  KLObject* t1544 = shen_empty_list(ctx);
  KLObject* t1546 = shen_tl(ctx, t1516);
  KLObject* t1547 = shen_hd(ctx, t1546);
  KLObject* t1548 = shen_tl(ctx, t1547);
  KLObject* t1549 = shen_tl(ctx, t1548);
  KLObject* t1550 = shen_eq(ctx, t1544, t1549);
  KLObject* t1543;
  if (!shen_is_boolean(ctx, t1550))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t1550)) {
    t1543 = t1550;
  } else {
  KLObject* t1551 = shen_empty_list(ctx);
  KLObject* t1553 = shen_tl(ctx, t1516);
  KLObject* t1554 = shen_tl(ctx, t1553);
  KLObject* t1555 = shen_eq(ctx, t1551, t1554);
    if (!shen_is_boolean(ctx, t1555))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t1543 = t1555;
  }
    if (!shen_is_boolean(ctx, t1543))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t1537 = t1543;
  }
    if (!shen_is_boolean(ctx, t1537))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t1530 = t1537;
  }
    if (!shen_is_boolean(ctx, t1530))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t1525 = t1530;
  }
    if (!shen_is_boolean(ctx, t1525))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t1521 = t1525;
  }
    if (!shen_is_boolean(ctx, t1521))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t1518 = t1521;
  }
    if (!shen_is_boolean(ctx, t1518))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t1518)) {
  KLObject* t1556 = shen_true(ctx);
      t1517 = t1556;
    } else {
  KLObject* t1557 = shen_true(ctx);
    if (!shen_is_boolean(ctx, t1557))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t1557)) {
  KLObject* t1558 = shen_false(ctx);
      t1517 = t1558;
    } else {
      shen_simple_error(ctx, "No true case found for cond");
      t1517 = shen_empty_list(ctx);
    }
    }
  }
    return t1517;
  }
}

static KLObject* native_kl_shen_2echoicepoint_35 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t1559 = objects[0];
    KLObject* t1560 = objects[1];
    KLObject* t1561 = objects[2];
    KLObject* t1562 = objects[3];
    KLObject* t1563 = objects[4];
  tail_start_kl_shen_2echoicepoint_35: ;
  KLObject* t1564;
  {
  KLObject* t1567 = shen_cons_p(ctx, t1562);
  KLObject* t1565;
  if (!shen_is_boolean(ctx, t1567))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t1567)) {
    t1565 = t1567;
  } else {
  KLObject* t1570 = shen_tl(ctx, t1562);
  KLObject* t1571 = shen_cons_p(ctx, t1570);
  KLObject* t1568;
  if (!shen_is_boolean(ctx, t1571))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t1571)) {
    t1568 = t1571;
  } else {
  KLObject* t1574 = shen_tl(ctx, t1562);
  KLObject* t1575 = shen_hd(ctx, t1574);
  KLObject* t1576 = shen_cons_p(ctx, t1575);
  KLObject* t1572;
  if (!shen_is_boolean(ctx, t1576))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t1576)) {
    t1572 = t1576;
  } else {
  KLObject* t1579 = shen_tl(ctx, t1562);
  KLObject* t1580 = shen_hd(ctx, t1579);
  KLObject* t1581 = shen_tl(ctx, t1580);
  KLObject* t1582 = shen_cons_p(ctx, t1581);
  KLObject* t1577;
  if (!shen_is_boolean(ctx, t1582))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t1582)) {
    t1577 = t1582;
  } else {
  KLObject* t1585 = shen_tl(ctx, t1562);
  KLObject* t1586 = shen_hd(ctx, t1585);
  KLObject* t1587 = shen_tl(ctx, t1586);
  KLObject* t1588 = shen_hd(ctx, t1587);
  KLObject* t1589 = shen_cons_p(ctx, t1588);
  KLObject* t1583;
  if (!shen_is_boolean(ctx, t1589))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t1589)) {
    t1583 = t1589;
  } else {
  KLObject* t1591 = shen_intern(ctx, "fail-if");
  KLObject* t1593 = shen_tl(ctx, t1562);
  KLObject* t1594 = shen_hd(ctx, t1593);
  KLObject* t1595 = shen_tl(ctx, t1594);
  KLObject* t1596 = shen_hd(ctx, t1595);
  KLObject* t1597 = shen_hd(ctx, t1596);
  KLObject* t1598 = shen_eq(ctx, t1591, t1597);
  KLObject* t1590;
  if (!shen_is_boolean(ctx, t1598))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t1598)) {
    t1590 = t1598;
  } else {
  KLObject* t1601 = shen_tl(ctx, t1562);
  KLObject* t1602 = shen_hd(ctx, t1601);
  KLObject* t1603 = shen_tl(ctx, t1602);
  KLObject* t1604 = shen_hd(ctx, t1603);
  KLObject* t1605 = shen_tl(ctx, t1604);
  KLObject* t1606 = shen_cons_p(ctx, t1605);
  KLObject* t1599;
  if (!shen_is_boolean(ctx, t1606))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t1606)) {
    t1599 = t1606;
  } else {
  KLObject* t1609 = shen_tl(ctx, t1562);
  KLObject* t1610 = shen_hd(ctx, t1609);
  KLObject* t1611 = shen_tl(ctx, t1610);
  KLObject* t1612 = shen_hd(ctx, t1611);
  KLObject* t1613 = shen_tl(ctx, t1612);
  KLObject* t1614 = shen_tl(ctx, t1613);
  KLObject* t1615 = shen_cons_p(ctx, t1614);
  KLObject* t1607;
  if (!shen_is_boolean(ctx, t1615))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t1615)) {
    t1607 = t1615;
  } else {
  KLObject* t1617 = shen_empty_list(ctx);
  KLObject* t1619 = shen_tl(ctx, t1562);
  KLObject* t1620 = shen_hd(ctx, t1619);
  KLObject* t1621 = shen_tl(ctx, t1620);
  KLObject* t1622 = shen_hd(ctx, t1621);
  KLObject* t1623 = shen_tl(ctx, t1622);
  KLObject* t1624 = shen_tl(ctx, t1623);
  KLObject* t1625 = shen_tl(ctx, t1624);
  KLObject* t1626 = shen_eq(ctx, t1617, t1625);
  KLObject* t1616;
  if (!shen_is_boolean(ctx, t1626))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t1626)) {
    t1616 = t1626;
  } else {
  KLObject* t1628 = shen_empty_list(ctx);
  KLObject* t1630 = shen_tl(ctx, t1562);
  KLObject* t1631 = shen_hd(ctx, t1630);
  KLObject* t1632 = shen_tl(ctx, t1631);
  KLObject* t1633 = shen_tl(ctx, t1632);
  KLObject* t1634 = shen_eq(ctx, t1628, t1633);
  KLObject* t1627;
  if (!shen_is_boolean(ctx, t1634))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t1634)) {
    t1627 = t1634;
  } else {
  KLObject* t1636 = shen_empty_list(ctx);
  KLObject* t1638 = shen_tl(ctx, t1562);
  KLObject* t1639 = shen_tl(ctx, t1638);
  KLObject* t1640 = shen_eq(ctx, t1636, t1639);
  KLObject* t1635;
  if (!shen_is_boolean(ctx, t1640))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t1640)) {
    t1635 = t1640;
  } else {
  KLObject* t1643 = shen_tl(ctx, t1562);
  KLObject* t1644 = shen_hd(ctx, t1643);
  KLObject* t1645 = shen_tl(ctx, t1644);
  KLObject* t1646 = shen_hd(ctx, t1645);
  KLObject* t1647 = shen_tl(ctx, t1646);
  KLObject* t1648 = shen_hd(ctx, t1647);
  KLObject* t1649 = shen_eq(ctx, t1559, t1648);
    if (!shen_is_boolean(ctx, t1649))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t1635 = t1649;
  }
    if (!shen_is_boolean(ctx, t1635))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t1627 = t1635;
  }
    if (!shen_is_boolean(ctx, t1627))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t1616 = t1627;
  }
    if (!shen_is_boolean(ctx, t1616))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t1607 = t1616;
  }
    if (!shen_is_boolean(ctx, t1607))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t1599 = t1607;
  }
    if (!shen_is_boolean(ctx, t1599))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t1590 = t1599;
  }
    if (!shen_is_boolean(ctx, t1590))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t1583 = t1590;
  }
    if (!shen_is_boolean(ctx, t1583))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t1577 = t1583;
  }
    if (!shen_is_boolean(ctx, t1577))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t1572 = t1577;
  }
    if (!shen_is_boolean(ctx, t1572))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t1568 = t1572;
  }
    if (!shen_is_boolean(ctx, t1568))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t1565 = t1568;
  }
    if (!shen_is_boolean(ctx, t1565))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t1565)) {
  KLObject* t1650 = shen_true(ctx);
  KLObject* t1651 = shen_intern(ctx, "let");
  KLObject* t1653 = shen_intern(ctx, "freeze");
  KLObject* t1654 = shen_intern(ctx, "cond");
  KLObject* t1657 = shen_tl(ctx, t1562);
  KLObject* t1658 = shen_hd(ctx, t1657);
  KLObject* t1659 = shen_tl(ctx, t1658);
  KLObject* t1660 = shen_hd(ctx, t1659);
  KLObject* t1661 = shen_tl(ctx, t1660);
  KLObject* t1662 = shen_hd(ctx, t1661);
  KLObject* t1655;
  {
    KLObject* a1655[] = {t1662, t1563};
    t1655 = shen_apply_direct(ctx, "shen.scan-body", 2, a1655);
  }
  KLObject* t1664 = shen_cons(ctx, t1654, t1655);
  KLObject* t1665 = shen_empty_list(ctx);
  KLObject* t1666 = shen_cons(ctx, t1664, t1665);
  KLObject* t1667 = shen_cons(ctx, t1653, t1666);
  KLObject* t1668 = shen_intern(ctx, "if");
  KLObject* t1670 = shen_hd(ctx, t1562);
  KLObject* t1671 = shen_intern(ctx, "let");
  KLObject* t1674 = shen_tl(ctx, t1562);
  KLObject* t1675 = shen_hd(ctx, t1674);
  KLObject* t1676 = shen_tl(ctx, t1675);
  KLObject* t1677 = shen_hd(ctx, t1676);
  KLObject* t1678 = shen_tl(ctx, t1677);
  KLObject* t1679 = shen_tl(ctx, t1678);
  KLObject* t1680 = shen_hd(ctx, t1679);
  KLObject* t1681 = shen_intern(ctx, "if");
  KLObject* t1683 = shen_tl(ctx, t1562);
  KLObject* t1684 = shen_hd(ctx, t1683);
  KLObject* t1685 = shen_tl(ctx, t1684);
  KLObject* t1686 = shen_hd(ctx, t1685);
  KLObject* t1687 = shen_tl(ctx, t1686);
  KLObject* t1688 = shen_hd(ctx, t1687);
  KLObject* t1690 = shen_empty_list(ctx);
  KLObject* t1691 = shen_cons(ctx, t1561, t1690);
  KLObject* t1692 = shen_cons(ctx, t1688, t1691);
  KLObject* t1693 = shen_intern(ctx, "thaw");
  KLObject* t1695 = shen_empty_list(ctx);
  KLObject* t1696 = shen_cons(ctx, t1560, t1695);
  KLObject* t1697 = shen_cons(ctx, t1693, t1696);
  KLObject* t1699 = shen_empty_list(ctx);
  KLObject* t1700 = shen_cons(ctx, t1561, t1699);
  KLObject* t1701 = shen_cons(ctx, t1697, t1700);
  KLObject* t1702 = shen_cons(ctx, t1692, t1701);
  KLObject* t1703 = shen_cons(ctx, t1681, t1702);
  KLObject* t1704 = shen_empty_list(ctx);
  KLObject* t1705 = shen_cons(ctx, t1703, t1704);
  KLObject* t1706 = shen_cons(ctx, t1680, t1705);
  KLObject* t1707 = shen_cons(ctx, t1561, t1706);
  KLObject* t1708 = shen_cons(ctx, t1671, t1707);
  KLObject* t1709 = shen_intern(ctx, "thaw");
  KLObject* t1711 = shen_empty_list(ctx);
  KLObject* t1712 = shen_cons(ctx, t1560, t1711);
  KLObject* t1713 = shen_cons(ctx, t1709, t1712);
  KLObject* t1714 = shen_empty_list(ctx);
  KLObject* t1715 = shen_cons(ctx, t1713, t1714);
  KLObject* t1716 = shen_cons(ctx, t1708, t1715);
  KLObject* t1717 = shen_cons(ctx, t1670, t1716);
  KLObject* t1718 = shen_cons(ctx, t1668, t1717);
  KLObject* t1719 = shen_empty_list(ctx);
  KLObject* t1720 = shen_cons(ctx, t1718, t1719);
  KLObject* t1721 = shen_cons(ctx, t1667, t1720);
  KLObject* t1722 = shen_cons(ctx, t1560, t1721);
  KLObject* t1723 = shen_cons(ctx, t1651, t1722);
  KLObject* t1724 = shen_empty_list(ctx);
  KLObject* t1725 = shen_cons(ctx, t1723, t1724);
  KLObject* t1726 = shen_cons(ctx, t1650, t1725);
  KLObject* t1727 = shen_empty_list(ctx);
  KLObject* t1728 = shen_cons(ctx, t1726, t1727);
      t1564 = t1728;
    } else {
  KLObject* t1731 = shen_cons_p(ctx, t1562);
  KLObject* t1729;
  if (!shen_is_boolean(ctx, t1731))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t1731)) {
    t1729 = t1731;
  } else {
  KLObject* t1734 = shen_tl(ctx, t1562);
  KLObject* t1735 = shen_cons_p(ctx, t1734);
  KLObject* t1732;
  if (!shen_is_boolean(ctx, t1735))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t1735)) {
    t1732 = t1735;
  } else {
  KLObject* t1738 = shen_tl(ctx, t1562);
  KLObject* t1739 = shen_hd(ctx, t1738);
  KLObject* t1740 = shen_cons_p(ctx, t1739);
  KLObject* t1736;
  if (!shen_is_boolean(ctx, t1740))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t1740)) {
    t1736 = t1740;
  } else {
  KLObject* t1743 = shen_tl(ctx, t1562);
  KLObject* t1744 = shen_hd(ctx, t1743);
  KLObject* t1745 = shen_tl(ctx, t1744);
  KLObject* t1746 = shen_cons_p(ctx, t1745);
  KLObject* t1741;
  if (!shen_is_boolean(ctx, t1746))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t1746)) {
    t1741 = t1746;
  } else {
  KLObject* t1748 = shen_empty_list(ctx);
  KLObject* t1750 = shen_tl(ctx, t1562);
  KLObject* t1751 = shen_hd(ctx, t1750);
  KLObject* t1752 = shen_tl(ctx, t1751);
  KLObject* t1753 = shen_tl(ctx, t1752);
  KLObject* t1754 = shen_eq(ctx, t1748, t1753);
  KLObject* t1747;
  if (!shen_is_boolean(ctx, t1754))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t1754)) {
    t1747 = t1754;
  } else {
  KLObject* t1755 = shen_empty_list(ctx);
  KLObject* t1757 = shen_tl(ctx, t1562);
  KLObject* t1758 = shen_tl(ctx, t1757);
  KLObject* t1759 = shen_eq(ctx, t1755, t1758);
    if (!shen_is_boolean(ctx, t1759))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t1747 = t1759;
  }
    if (!shen_is_boolean(ctx, t1747))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t1741 = t1747;
  }
    if (!shen_is_boolean(ctx, t1741))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t1736 = t1741;
  }
    if (!shen_is_boolean(ctx, t1736))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t1732 = t1736;
  }
    if (!shen_is_boolean(ctx, t1732))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t1729 = t1732;
  }
    if (!shen_is_boolean(ctx, t1729))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t1729)) {
  KLObject* t1760 = shen_true(ctx);
  KLObject* t1761 = shen_intern(ctx, "let");
  KLObject* t1763 = shen_intern(ctx, "freeze");
  KLObject* t1764 = shen_intern(ctx, "cond");
  KLObject* t1765;
  {
    KLObject* a1765[] = {t1559, t1563};
    t1765 = shen_apply_direct(ctx, "shen.scan-body", 2, a1765);
  }
  KLObject* t1768 = shen_cons(ctx, t1764, t1765);
  KLObject* t1769 = shen_empty_list(ctx);
  KLObject* t1770 = shen_cons(ctx, t1768, t1769);
  KLObject* t1771 = shen_cons(ctx, t1763, t1770);
  KLObject* t1772 = shen_intern(ctx, "if");
  KLObject* t1774 = shen_hd(ctx, t1562);
  KLObject* t1775 = shen_intern(ctx, "let");
  KLObject* t1778 = shen_tl(ctx, t1562);
  KLObject* t1779 = shen_hd(ctx, t1778);
  KLObject* t1780 = shen_tl(ctx, t1779);
  KLObject* t1781 = shen_hd(ctx, t1780);
  KLObject* t1782 = shen_intern(ctx, "if");
  KLObject* t1783 = shen_intern(ctx, "=");
  KLObject* t1785 = shen_intern(ctx, "fail");
  KLObject* t1786 = shen_empty_list(ctx);
  KLObject* t1787 = shen_cons(ctx, t1785, t1786);
  KLObject* t1788 = shen_empty_list(ctx);
  KLObject* t1789 = shen_cons(ctx, t1787, t1788);
  KLObject* t1790 = shen_cons(ctx, t1561, t1789);
  KLObject* t1791 = shen_cons(ctx, t1783, t1790);
  KLObject* t1792 = shen_intern(ctx, "thaw");
  KLObject* t1794 = shen_empty_list(ctx);
  KLObject* t1795 = shen_cons(ctx, t1560, t1794);
  KLObject* t1796 = shen_cons(ctx, t1792, t1795);
  KLObject* t1798 = shen_empty_list(ctx);
  KLObject* t1799 = shen_cons(ctx, t1561, t1798);
  KLObject* t1800 = shen_cons(ctx, t1796, t1799);
  KLObject* t1801 = shen_cons(ctx, t1791, t1800);
  KLObject* t1802 = shen_cons(ctx, t1782, t1801);
  KLObject* t1803 = shen_empty_list(ctx);
  KLObject* t1804 = shen_cons(ctx, t1802, t1803);
  KLObject* t1805 = shen_cons(ctx, t1781, t1804);
  KLObject* t1806 = shen_cons(ctx, t1561, t1805);
  KLObject* t1807 = shen_cons(ctx, t1775, t1806);
  KLObject* t1808 = shen_intern(ctx, "thaw");
  KLObject* t1810 = shen_empty_list(ctx);
  KLObject* t1811 = shen_cons(ctx, t1560, t1810);
  KLObject* t1812 = shen_cons(ctx, t1808, t1811);
  KLObject* t1813 = shen_empty_list(ctx);
  KLObject* t1814 = shen_cons(ctx, t1812, t1813);
  KLObject* t1815 = shen_cons(ctx, t1807, t1814);
  KLObject* t1816 = shen_cons(ctx, t1774, t1815);
  KLObject* t1817 = shen_cons(ctx, t1772, t1816);
  KLObject* t1818 = shen_empty_list(ctx);
  KLObject* t1819 = shen_cons(ctx, t1817, t1818);
  KLObject* t1820 = shen_cons(ctx, t1771, t1819);
  KLObject* t1821 = shen_cons(ctx, t1560, t1820);
  KLObject* t1822 = shen_cons(ctx, t1761, t1821);
  KLObject* t1823 = shen_empty_list(ctx);
  KLObject* t1824 = shen_cons(ctx, t1822, t1823);
  KLObject* t1825 = shen_cons(ctx, t1760, t1824);
  KLObject* t1826 = shen_empty_list(ctx);
  KLObject* t1827 = shen_cons(ctx, t1825, t1826);
      t1564 = t1827;
    } else {
  KLObject* t1828 = shen_true(ctx);
    if (!shen_is_boolean(ctx, t1828))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t1828)) {
  KLObject* t1830 = shen_string(ctx, "implementation error in shen.choicepoint");
  KLObject* t1829;
  {
    KLObject* a1829[] = {t1830};
    t1829 = shen_tail_apply_direct(ctx, "simple-error", 1, a1829);
  }
      t1564 = t1829;
    } else {
      shen_simple_error(ctx, "No true case found for cond");
      t1564 = shen_empty_list(ctx);
    }
    }
    }
  }
    return t1564;
  }
}

static KLObject* native_kl_shen_2erep_2dX_36 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t1831 = objects[0];
    KLObject* t1832 = objects[1];
    KLObject* t1833 = objects[2];
  tail_start_kl_shen_2erep_2dX_36: ;
  KLObject* t1834;
  {
  KLObject* t1837 = shen_eq(ctx, t1831, t1833);
    if (!shen_is_boolean(ctx, t1837))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t1837)) {
      t1834 = t1832;
    } else {
  KLObject* t1840 = shen_cons_p(ctx, t1833);
    if (!shen_is_boolean(ctx, t1840))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t1840)) {
  KLObject* t1845 = shen_hd(ctx, t1833);
  KLObject* t1841;
  {
    KLObject* a1841[] = {t1831, t1832, t1845};
    t1841 = shen_apply_direct(ctx, "shen.rep-X", 3, a1841);
  }
  KLObject* t1849 = shen_hd(ctx, t1833);
  KLObject* t1850 = shen_eq(ctx, t1841, t1849);
  KLObject* t1846;
  if (!shen_is_boolean(ctx, t1850))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1850)) {
  KLObject* t1852 = shen_hd(ctx, t1833);
  KLObject* t1857 = shen_tl(ctx, t1833);
  KLObject* t1853;
  {
    KLObject* a1853[] = {t1831, t1832, t1857};
    t1853 = shen_apply_direct(ctx, "shen.rep-X", 3, a1853);
  }
  KLObject* t1858 = shen_cons(ctx, t1852, t1853);
    t1846 = t1858;
  } else {
  KLObject* t1861 = shen_tl(ctx, t1833);
  KLObject* t1862 = shen_cons(ctx, t1841, t1861);
    t1846 = t1862;
  }
      t1834 = t1846;
    } else {
  KLObject* t1863 = shen_true(ctx);
    if (!shen_is_boolean(ctx, t1863))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t1863)) {
      t1834 = t1833;
    } else {
      shen_simple_error(ctx, "No true case found for cond");
      t1834 = shen_empty_list(ctx);
    }
    }
    }
  }
    return t1834;
  }
}

static KLObject* native_kl_shen_2ekl_2dbody_37 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t1865 = objects[0];
    KLObject* t1866 = objects[1];
  tail_start_kl_shen_2ekl_2dbody_37: ;
  KLObject* t1868;
  {
    Vector* caps_6 = shen_vector(ctx, 1);
    shen_vector_set(ctx, caps_6, 0, t1866);
    t1868 = shen_native_closure(ctx, 1, &lambda_6, caps_6);
  }
  KLObject* t1867;
  {
    KLObject* a1867[] = {t1868, t1865};
    t1867 = shen_tail_apply_direct(ctx, "map", 2, a1867);
  }
    return t1867;
  }
}

static KLObject* native_kl_shen_2ealpha_2dconvert_38 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t1880 = objects[0];
  tail_start_kl_shen_2ealpha_2dconvert_38: ;
  KLObject* t1881;
  {
  KLObject* t1884 = shen_cons_p(ctx, t1880);
  KLObject* t1882;
  if (!shen_is_boolean(ctx, t1884))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t1884)) {
    t1882 = t1884;
  } else {
  KLObject* t1886 = shen_intern(ctx, "lambda");
  KLObject* t1888 = shen_hd(ctx, t1880);
  KLObject* t1889 = shen_eq(ctx, t1886, t1888);
  KLObject* t1885;
  if (!shen_is_boolean(ctx, t1889))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t1889)) {
    t1885 = t1889;
  } else {
  KLObject* t1892 = shen_tl(ctx, t1880);
  KLObject* t1893 = shen_cons_p(ctx, t1892);
  KLObject* t1890;
  if (!shen_is_boolean(ctx, t1893))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t1893)) {
    t1890 = t1893;
  } else {
  KLObject* t1896 = shen_tl(ctx, t1880);
  KLObject* t1897 = shen_tl(ctx, t1896);
  KLObject* t1898 = shen_cons_p(ctx, t1897);
  KLObject* t1894;
  if (!shen_is_boolean(ctx, t1898))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t1898)) {
    t1894 = t1898;
  } else {
  KLObject* t1899 = shen_empty_list(ctx);
  KLObject* t1901 = shen_tl(ctx, t1880);
  KLObject* t1902 = shen_tl(ctx, t1901);
  KLObject* t1903 = shen_tl(ctx, t1902);
  KLObject* t1904 = shen_eq(ctx, t1899, t1903);
    if (!shen_is_boolean(ctx, t1904))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t1894 = t1904;
  }
    if (!shen_is_boolean(ctx, t1894))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t1890 = t1894;
  }
    if (!shen_is_boolean(ctx, t1890))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t1885 = t1890;
  }
    if (!shen_is_boolean(ctx, t1885))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t1882 = t1885;
  }
    if (!shen_is_boolean(ctx, t1882))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t1882)) {
  KLObject* t1906 = shen_intern(ctx, "Z");
  KLObject* t1905;
  {
    KLObject* a1905[] = {t1906};
    t1905 = shen_apply_direct(ctx, "gensym", 1, a1905);
  }
  KLObject* t1907 = shen_intern(ctx, "lambda");
  KLObject* t1911 = shen_tl(ctx, t1880);
  KLObject* t1912 = shen_hd(ctx, t1911);
  KLObject* t1915 = shen_tl(ctx, t1880);
  KLObject* t1916 = shen_tl(ctx, t1915);
  KLObject* t1917 = shen_hd(ctx, t1916);
  KLObject* t1909;
  {
    KLObject* a1909[] = {t1912, t1905, t1917};
    t1909 = shen_apply_direct(ctx, "shen.beta", 3, a1909);
  }
  KLObject* t1918 = shen_empty_list(ctx);
  KLObject* t1919 = shen_cons(ctx, t1909, t1918);
  KLObject* t1920 = shen_cons(ctx, t1905, t1919);
  KLObject* t1921 = shen_cons(ctx, t1907, t1920);
  KLObject* t1923;
  {
    Vector* caps_7 = shen_vector(ctx, 0);
    t1923 = shen_native_closure(ctx, 1, &lambda_7, caps_7);
  }
  KLObject* t1922;
  {
    KLObject* a1922[] = {t1923, t1921};
    t1922 = shen_tail_apply_direct(ctx, "map", 2, a1922);
  }
      t1881 = t1922;
    } else {
  KLObject* t1930 = shen_cons_p(ctx, t1880);
  KLObject* t1928;
  if (!shen_is_boolean(ctx, t1930))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t1930)) {
    t1928 = t1930;
  } else {
  KLObject* t1932 = shen_intern(ctx, "let");
  KLObject* t1934 = shen_hd(ctx, t1880);
  KLObject* t1935 = shen_eq(ctx, t1932, t1934);
  KLObject* t1931;
  if (!shen_is_boolean(ctx, t1935))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t1935)) {
    t1931 = t1935;
  } else {
  KLObject* t1938 = shen_tl(ctx, t1880);
  KLObject* t1939 = shen_cons_p(ctx, t1938);
  KLObject* t1936;
  if (!shen_is_boolean(ctx, t1939))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t1939)) {
    t1936 = t1939;
  } else {
  KLObject* t1942 = shen_tl(ctx, t1880);
  KLObject* t1943 = shen_tl(ctx, t1942);
  KLObject* t1944 = shen_cons_p(ctx, t1943);
  KLObject* t1940;
  if (!shen_is_boolean(ctx, t1944))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t1944)) {
    t1940 = t1944;
  } else {
  KLObject* t1947 = shen_tl(ctx, t1880);
  KLObject* t1948 = shen_tl(ctx, t1947);
  KLObject* t1949 = shen_tl(ctx, t1948);
  KLObject* t1950 = shen_cons_p(ctx, t1949);
  KLObject* t1945;
  if (!shen_is_boolean(ctx, t1950))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t1950)) {
    t1945 = t1950;
  } else {
  KLObject* t1951 = shen_empty_list(ctx);
  KLObject* t1953 = shen_tl(ctx, t1880);
  KLObject* t1954 = shen_tl(ctx, t1953);
  KLObject* t1955 = shen_tl(ctx, t1954);
  KLObject* t1956 = shen_tl(ctx, t1955);
  KLObject* t1957 = shen_eq(ctx, t1951, t1956);
    if (!shen_is_boolean(ctx, t1957))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t1945 = t1957;
  }
    if (!shen_is_boolean(ctx, t1945))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t1940 = t1945;
  }
    if (!shen_is_boolean(ctx, t1940))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t1936 = t1940;
  }
    if (!shen_is_boolean(ctx, t1936))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t1931 = t1936;
  }
    if (!shen_is_boolean(ctx, t1931))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t1928 = t1931;
  }
    if (!shen_is_boolean(ctx, t1928))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t1928)) {
  KLObject* t1959 = shen_intern(ctx, "W");
  KLObject* t1958;
  {
    KLObject* a1958[] = {t1959};
    t1958 = shen_apply_direct(ctx, "gensym", 1, a1958);
  }
  KLObject* t1960 = shen_intern(ctx, "let");
  KLObject* t1963 = shen_tl(ctx, t1880);
  KLObject* t1964 = shen_tl(ctx, t1963);
  KLObject* t1965 = shen_hd(ctx, t1964);
  KLObject* t1968 = shen_tl(ctx, t1880);
  KLObject* t1969 = shen_hd(ctx, t1968);
  KLObject* t1972 = shen_tl(ctx, t1880);
  KLObject* t1973 = shen_tl(ctx, t1972);
  KLObject* t1974 = shen_tl(ctx, t1973);
  KLObject* t1975 = shen_hd(ctx, t1974);
  KLObject* t1966;
  {
    KLObject* a1966[] = {t1969, t1958, t1975};
    t1966 = shen_apply_direct(ctx, "shen.beta", 3, a1966);
  }
  KLObject* t1976 = shen_empty_list(ctx);
  KLObject* t1977 = shen_cons(ctx, t1966, t1976);
  KLObject* t1978 = shen_cons(ctx, t1965, t1977);
  KLObject* t1979 = shen_cons(ctx, t1958, t1978);
  KLObject* t1980 = shen_cons(ctx, t1960, t1979);
  KLObject* t1982;
  {
    Vector* caps_8 = shen_vector(ctx, 0);
    t1982 = shen_native_closure(ctx, 1, &lambda_8, caps_8);
  }
  KLObject* t1981;
  {
    KLObject* a1981[] = {t1982, t1980};
    t1981 = shen_tail_apply_direct(ctx, "map", 2, a1981);
  }
      t1881 = t1981;
    } else {
  KLObject* t1988 = shen_cons_p(ctx, t1880);
    if (!shen_is_boolean(ctx, t1988))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t1988)) {
  KLObject* t1990;
  {
    Vector* caps_9 = shen_vector(ctx, 0);
    t1990 = shen_native_closure(ctx, 1, &lambda_9, caps_9);
  }
  KLObject* t1989;
  {
    KLObject* a1989[] = {t1990, t1880};
    t1989 = shen_tail_apply_direct(ctx, "map", 2, a1989);
  }
      t1881 = t1989;
    } else {
  KLObject* t1995 = shen_true(ctx);
    if (!shen_is_boolean(ctx, t1995))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t1995)) {
      t1881 = t1880;
    } else {
      shen_simple_error(ctx, "No true case found for cond");
      t1881 = shen_empty_list(ctx);
    }
    }
    }
    }
  }
    return t1881;
  }
}

static KLObject* native_kl_shen_2etriple_2dstack_39 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t1997 = objects[0];
    KLObject* t1998 = objects[1];
    KLObject* t1999 = objects[2];
    KLObject* t2000 = objects[3];
  tail_start_kl_shen_2etriple_2dstack_39: ;
  KLObject* t2001;
  {
  KLObject* t2003 = shen_empty_list(ctx);
  KLObject* t2005 = shen_eq(ctx, t2003, t1998);
  KLObject* t2002;
  if (!shen_is_boolean(ctx, t2005))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t2005)) {
    t2002 = t2005;
  } else {
  KLObject* t2007 = shen_empty_list(ctx);
  KLObject* t2009 = shen_eq(ctx, t2007, t1999);
  KLObject* t2006;
  if (!shen_is_boolean(ctx, t2009))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t2009)) {
    t2006 = t2009;
  } else {
  KLObject* t2012 = shen_cons_p(ctx, t2000);
  KLObject* t2010;
  if (!shen_is_boolean(ctx, t2012))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t2012)) {
    t2010 = t2012;
  } else {
  KLObject* t2014 = shen_intern(ctx, "where");
  KLObject* t2016 = shen_hd(ctx, t2000);
  KLObject* t2017 = shen_eq(ctx, t2014, t2016);
  KLObject* t2013;
  if (!shen_is_boolean(ctx, t2017))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t2017)) {
    t2013 = t2017;
  } else {
  KLObject* t2020 = shen_tl(ctx, t2000);
  KLObject* t2021 = shen_cons_p(ctx, t2020);
  KLObject* t2018;
  if (!shen_is_boolean(ctx, t2021))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t2021)) {
    t2018 = t2021;
  } else {
  KLObject* t2024 = shen_tl(ctx, t2000);
  KLObject* t2025 = shen_tl(ctx, t2024);
  KLObject* t2026 = shen_cons_p(ctx, t2025);
  KLObject* t2022;
  if (!shen_is_boolean(ctx, t2026))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t2026)) {
    t2022 = t2026;
  } else {
  KLObject* t2027 = shen_empty_list(ctx);
  KLObject* t2029 = shen_tl(ctx, t2000);
  KLObject* t2030 = shen_tl(ctx, t2029);
  KLObject* t2031 = shen_tl(ctx, t2030);
  KLObject* t2032 = shen_eq(ctx, t2027, t2031);
    if (!shen_is_boolean(ctx, t2032))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t2022 = t2032;
  }
    if (!shen_is_boolean(ctx, t2022))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t2018 = t2022;
  }
    if (!shen_is_boolean(ctx, t2018))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t2013 = t2018;
  }
    if (!shen_is_boolean(ctx, t2013))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t2010 = t2013;
  }
    if (!shen_is_boolean(ctx, t2010))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t2006 = t2010;
  }
    if (!shen_is_boolean(ctx, t2006))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t2002 = t2006;
  }
    if (!shen_is_boolean(ctx, t2002))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t2002)) {
  KLObject* t2034 = shen_tl(ctx, t2000);
  KLObject* t2035 = shen_hd(ctx, t2034);
  KLObject* t2037 = shen_cons(ctx, t2035, t1997);
  KLObject* t2038 = shen_empty_list(ctx);
  KLObject* t2039 = shen_empty_list(ctx);
  KLObject* t2041 = shen_tl(ctx, t2000);
  KLObject* t2042 = shen_tl(ctx, t2041);
  KLObject* t2043 = shen_hd(ctx, t2042);
  {
    KLObject* n2044_0 = t2037;
    KLObject* n2044_1 = t2038;
    KLObject* n2044_2 = t2039;
    KLObject* n2044_3 = t2043;
    t1997 = n2044_0;
    t1998 = n2044_1;
    t1999 = n2044_2;
    t2000 = n2044_3;
    goto tail_start_kl_shen_2etriple_2dstack_39;
  }
  KLObject* t2044 = NULL;
      t2001 = t2044;
    } else {
  KLObject* t2046 = shen_empty_list(ctx);
  KLObject* t2048 = shen_eq(ctx, t2046, t1998);
  KLObject* t2045;
  if (!shen_is_boolean(ctx, t2048))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t2048)) {
    t2045 = t2048;
  } else {
  KLObject* t2049 = shen_empty_list(ctx);
  KLObject* t2051 = shen_eq(ctx, t2049, t1999);
    if (!shen_is_boolean(ctx, t2051))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t2045 = t2051;
  }
    if (!shen_is_boolean(ctx, t2045))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t2045)) {
  KLObject* t2053;
  {
    KLObject* a2053[] = {t1997};
    t2053 = shen_apply_direct(ctx, "reverse", 1, a2053);
  }
  KLObject* t2052;
  {
    KLObject* a2052[] = {t2053};
    t2052 = shen_apply_direct(ctx, "shen.rectify-test", 1, a2052);
  }
  KLObject* t2056 = shen_empty_list(ctx);
  KLObject* t2057 = shen_cons(ctx, t2000, t2056);
  KLObject* t2058 = shen_cons(ctx, t2052, t2057);
      t2001 = t2058;
    } else {
  KLObject* t2061 = shen_cons_p(ctx, t1998);
  KLObject* t2059;
  if (!shen_is_boolean(ctx, t2061))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t2061)) {
    t2059 = t2061;
  } else {
  KLObject* t2064 = shen_cons_p(ctx, t1999);
  KLObject* t2062;
  if (!shen_is_boolean(ctx, t2064))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t2064)) {
    t2062 = t2064;
  } else {
  KLObject* t2067 = shen_hd(ctx, t1998);
  KLObject* t2065;
  {
    KLObject* a2065[] = {t2067};
    t2065 = shen_apply_direct(ctx, "variable?", 1, a2065);
  }
    if (!shen_is_boolean(ctx, t2065))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t2062 = t2065;
  }
    if (!shen_is_boolean(ctx, t2062))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t2059 = t2062;
  }
    if (!shen_is_boolean(ctx, t2059))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t2059)) {
  KLObject* t2070 = shen_tl(ctx, t1998);
  KLObject* t2072 = shen_tl(ctx, t1999);
  KLObject* t2075 = shen_hd(ctx, t1998);
  KLObject* t2077 = shen_hd(ctx, t1999);
  KLObject* t2073;
  {
    KLObject* a2073[] = {t2075, t2077, t2000};
    t2073 = shen_apply_direct(ctx, "shen.beta", 3, a2073);
  }
  {
    KLObject* n2079_0 = t1997;
    KLObject* n2079_1 = t2070;
    KLObject* n2079_2 = t2072;
    KLObject* n2079_3 = t2073;
    t1997 = n2079_0;
    t1998 = n2079_1;
    t1999 = n2079_2;
    t2000 = n2079_3;
    goto tail_start_kl_shen_2etriple_2dstack_39;
  }
  KLObject* t2079 = NULL;
      t2001 = t2079;
    } else {
  KLObject* t2082 = shen_cons_p(ctx, t1998);
  KLObject* t2080;
  if (!shen_is_boolean(ctx, t2082))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t2082)) {
    t2080 = t2082;
  } else {
  KLObject* t2085 = shen_hd(ctx, t1998);
  KLObject* t2086 = shen_cons_p(ctx, t2085);
  KLObject* t2083;
  if (!shen_is_boolean(ctx, t2086))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t2086)) {
    t2083 = t2086;
  } else {
  KLObject* t2089 = shen_hd(ctx, t1998);
  KLObject* t2090 = shen_tl(ctx, t2089);
  KLObject* t2091 = shen_cons_p(ctx, t2090);
  KLObject* t2087;
  if (!shen_is_boolean(ctx, t2091))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t2091)) {
    t2087 = t2091;
  } else {
  KLObject* t2094 = shen_hd(ctx, t1998);
  KLObject* t2095 = shen_tl(ctx, t2094);
  KLObject* t2096 = shen_tl(ctx, t2095);
  KLObject* t2097 = shen_cons_p(ctx, t2096);
  KLObject* t2092;
  if (!shen_is_boolean(ctx, t2097))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t2097)) {
    t2092 = t2097;
  } else {
  KLObject* t2099 = shen_empty_list(ctx);
  KLObject* t2101 = shen_hd(ctx, t1998);
  KLObject* t2102 = shen_tl(ctx, t2101);
  KLObject* t2103 = shen_tl(ctx, t2102);
  KLObject* t2104 = shen_tl(ctx, t2103);
  KLObject* t2105 = shen_eq(ctx, t2099, t2104);
  KLObject* t2098;
  if (!shen_is_boolean(ctx, t2105))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t2105)) {
    t2098 = t2105;
  } else {
  KLObject* t2107 = shen_cons_p(ctx, t1999);
    if (!shen_is_boolean(ctx, t2107))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t2098 = t2107;
  }
    if (!shen_is_boolean(ctx, t2098))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t2092 = t2098;
  }
    if (!shen_is_boolean(ctx, t2092))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t2087 = t2092;
  }
    if (!shen_is_boolean(ctx, t2087))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t2083 = t2087;
  }
    if (!shen_is_boolean(ctx, t2083))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t2080 = t2083;
  }
    if (!shen_is_boolean(ctx, t2080))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t2080)) {
  KLObject* t2110 = shen_hd(ctx, t1998);
  KLObject* t2111 = shen_hd(ctx, t2110);
  KLObject* t2108;
  {
    KLObject* a2108[] = {t2111};
    t2108 = shen_apply_direct(ctx, "shen.op-test", 1, a2108);
  }
  KLObject* t2113 = shen_hd(ctx, t1999);
  KLObject* t2114 = shen_empty_list(ctx);
  KLObject* t2115 = shen_cons(ctx, t2113, t2114);
  KLObject* t2116 = shen_cons(ctx, t2108, t2115);
  KLObject* t2118 = shen_cons(ctx, t2116, t1997);
  KLObject* t2120 = shen_hd(ctx, t1998);
  KLObject* t2121 = shen_tl(ctx, t2120);
  KLObject* t2122 = shen_hd(ctx, t2121);
  KLObject* t2124 = shen_hd(ctx, t1998);
  KLObject* t2125 = shen_tl(ctx, t2124);
  KLObject* t2126 = shen_tl(ctx, t2125);
  KLObject* t2127 = shen_hd(ctx, t2126);
  KLObject* t2129 = shen_tl(ctx, t1998);
  KLObject* t2130 = shen_cons(ctx, t2127, t2129);
  KLObject* t2131 = shen_cons(ctx, t2122, t2130);
  KLObject* t2134 = shen_hd(ctx, t1998);
  KLObject* t2135 = shen_hd(ctx, t2134);
  KLObject* t2132;
  {
    KLObject* a2132[] = {t2135};
    t2132 = shen_apply_direct(ctx, "shen.op1", 1, a2132);
  }
  KLObject* t2137 = shen_hd(ctx, t1999);
  KLObject* t2138 = shen_empty_list(ctx);
  KLObject* t2139 = shen_cons(ctx, t2137, t2138);
  KLObject* t2140 = shen_cons(ctx, t2132, t2139);
  KLObject* t2143 = shen_hd(ctx, t1998);
  KLObject* t2144 = shen_hd(ctx, t2143);
  KLObject* t2141;
  {
    KLObject* a2141[] = {t2144};
    t2141 = shen_apply_direct(ctx, "shen.op2", 1, a2141);
  }
  KLObject* t2146 = shen_hd(ctx, t1999);
  KLObject* t2147 = shen_empty_list(ctx);
  KLObject* t2148 = shen_cons(ctx, t2146, t2147);
  KLObject* t2149 = shen_cons(ctx, t2141, t2148);
  KLObject* t2151 = shen_tl(ctx, t1999);
  KLObject* t2152 = shen_cons(ctx, t2149, t2151);
  KLObject* t2153 = shen_cons(ctx, t2140, t2152);
  KLObject* t2156 = shen_hd(ctx, t1998);
  KLObject* t2158 = shen_hd(ctx, t1999);
  KLObject* t2154;
  {
    KLObject* a2154[] = {t2156, t2158, t2000};
    t2154 = shen_apply_direct(ctx, "shen.beta", 3, a2154);
  }
  {
    KLObject* n2160_0 = t2118;
    KLObject* n2160_1 = t2131;
    KLObject* n2160_2 = t2153;
    KLObject* n2160_3 = t2154;
    t1997 = n2160_0;
    t1998 = n2160_1;
    t1999 = n2160_2;
    t2000 = n2160_3;
    goto tail_start_kl_shen_2etriple_2dstack_39;
  }
  KLObject* t2160 = NULL;
      t2001 = t2160;
    } else {
  KLObject* t2163 = shen_cons_p(ctx, t1998);
  KLObject* t2161;
  if (!shen_is_boolean(ctx, t2163))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t2163)) {
    t2161 = t2163;
  } else {
  KLObject* t2165 = shen_cons_p(ctx, t1999);
    if (!shen_is_boolean(ctx, t2165))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t2161 = t2165;
  }
    if (!shen_is_boolean(ctx, t2161))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t2161)) {
  KLObject* t2166 = shen_intern(ctx, "=");
  KLObject* t2168 = shen_hd(ctx, t1998);
  KLObject* t2170 = shen_hd(ctx, t1999);
  KLObject* t2171 = shen_empty_list(ctx);
  KLObject* t2172 = shen_cons(ctx, t2170, t2171);
  KLObject* t2173 = shen_cons(ctx, t2168, t2172);
  KLObject* t2174 = shen_cons(ctx, t2166, t2173);
  KLObject* t2176 = shen_cons(ctx, t2174, t1997);
  KLObject* t2178 = shen_tl(ctx, t1998);
  KLObject* t2180 = shen_tl(ctx, t1999);
  {
    KLObject* n2182_0 = t2176;
    KLObject* n2182_1 = t2178;
    KLObject* n2182_2 = t2180;
    KLObject* n2182_3 = t2000;
    t1997 = n2182_0;
    t1998 = n2182_1;
    t1999 = n2182_2;
    t2000 = n2182_3;
    goto tail_start_kl_shen_2etriple_2dstack_39;
  }
  KLObject* t2182 = NULL;
      t2001 = t2182;
    } else {
  KLObject* t2183 = shen_true(ctx);
    if (!shen_is_boolean(ctx, t2183))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t2183)) {
  KLObject* t2185 = shen_string(ctx, "implementation error in shen.triple-stack");
  KLObject* t2184;
  {
    KLObject* a2184[] = {t2185};
    t2184 = shen_tail_apply_direct(ctx, "simple-error", 1, a2184);
  }
      t2001 = t2184;
    } else {
      shen_simple_error(ctx, "No true case found for cond");
      t2001 = shen_empty_list(ctx);
    }
    }
    }
    }
    }
    }
  }
    return t2001;
  }
}

static KLObject* native_kl_shen_2erectify_2dtest_40 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t2186 = objects[0];
  tail_start_kl_shen_2erectify_2dtest_40: ;
  KLObject* t2187;
  {
  KLObject* t2188 = shen_empty_list(ctx);
  KLObject* t2190 = shen_eq(ctx, t2188, t2186);
    if (!shen_is_boolean(ctx, t2190))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t2190)) {
  KLObject* t2191 = shen_true(ctx);
      t2187 = t2191;
    } else {
  KLObject* t2194 = shen_cons_p(ctx, t2186);
  KLObject* t2192;
  if (!shen_is_boolean(ctx, t2194))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t2194)) {
    t2192 = t2194;
  } else {
  KLObject* t2195 = shen_empty_list(ctx);
  KLObject* t2197 = shen_tl(ctx, t2186);
  KLObject* t2198 = shen_eq(ctx, t2195, t2197);
    if (!shen_is_boolean(ctx, t2198))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t2192 = t2198;
  }
    if (!shen_is_boolean(ctx, t2192))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t2192)) {
  KLObject* t2200 = shen_hd(ctx, t2186);
      t2187 = t2200;
    } else {
  KLObject* t2203 = shen_cons_p(ctx, t2186);
  KLObject* t2201;
  if (!shen_is_boolean(ctx, t2203))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t2203)) {
    t2201 = t2203;
  } else {
  KLObject* t2205 = shen_tl(ctx, t2186);
  KLObject* t2206 = shen_cons_p(ctx, t2205);
    if (!shen_is_boolean(ctx, t2206))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t2201 = t2206;
  }
    if (!shen_is_boolean(ctx, t2201))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t2201)) {
  KLObject* t2207 = shen_intern(ctx, "and");
  KLObject* t2209 = shen_hd(ctx, t2186);
  KLObject* t2212 = shen_tl(ctx, t2186);
  KLObject* t2210;
  {
    KLObject* a2210[] = {t2212};
    t2210 = shen_apply_direct(ctx, "shen.rectify-test", 1, a2210);
  }
  KLObject* t2213 = shen_empty_list(ctx);
  KLObject* t2214 = shen_cons(ctx, t2210, t2213);
  KLObject* t2215 = shen_cons(ctx, t2209, t2214);
  KLObject* t2216 = shen_cons(ctx, t2207, t2215);
      t2187 = t2216;
    } else {
  KLObject* t2217 = shen_true(ctx);
    if (!shen_is_boolean(ctx, t2217))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t2217)) {
  KLObject* t2219 = shen_string(ctx, "implementation error in shen.rectify-test");
  KLObject* t2218;
  {
    KLObject* a2218[] = {t2219};
    t2218 = shen_tail_apply_direct(ctx, "simple-error", 1, a2218);
  }
      t2187 = t2218;
    } else {
      shen_simple_error(ctx, "No true case found for cond");
      t2187 = shen_empty_list(ctx);
    }
    }
    }
    }
  }
    return t2187;
  }
}

static KLObject* native_kl_shen_2ebeta_41 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t2220 = objects[0];
    KLObject* t2221 = objects[1];
    KLObject* t2222 = objects[2];
  tail_start_kl_shen_2ebeta_41: ;
  KLObject* t2223;
  {
  KLObject* t2226 = shen_eq(ctx, t2220, t2222);
    if (!shen_is_boolean(ctx, t2226))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t2226)) {
      t2223 = t2221;
    } else {
  KLObject* t2230 = shen_cons_p(ctx, t2222);
  KLObject* t2228;
  if (!shen_is_boolean(ctx, t2230))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t2230)) {
    t2228 = t2230;
  } else {
  KLObject* t2232 = shen_intern(ctx, "lambda");
  KLObject* t2234 = shen_hd(ctx, t2222);
  KLObject* t2235 = shen_eq(ctx, t2232, t2234);
  KLObject* t2231;
  if (!shen_is_boolean(ctx, t2235))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t2235)) {
    t2231 = t2235;
  } else {
  KLObject* t2238 = shen_tl(ctx, t2222);
  KLObject* t2239 = shen_cons_p(ctx, t2238);
  KLObject* t2236;
  if (!shen_is_boolean(ctx, t2239))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t2239)) {
    t2236 = t2239;
  } else {
  KLObject* t2242 = shen_tl(ctx, t2222);
  KLObject* t2243 = shen_tl(ctx, t2242);
  KLObject* t2244 = shen_cons_p(ctx, t2243);
  KLObject* t2240;
  if (!shen_is_boolean(ctx, t2244))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t2244)) {
    t2240 = t2244;
  } else {
  KLObject* t2246 = shen_empty_list(ctx);
  KLObject* t2248 = shen_tl(ctx, t2222);
  KLObject* t2249 = shen_tl(ctx, t2248);
  KLObject* t2250 = shen_tl(ctx, t2249);
  KLObject* t2251 = shen_eq(ctx, t2246, t2250);
  KLObject* t2245;
  if (!shen_is_boolean(ctx, t2251))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t2251)) {
    t2245 = t2251;
  } else {
  KLObject* t2254 = shen_tl(ctx, t2222);
  KLObject* t2255 = shen_hd(ctx, t2254);
  KLObject* t2256 = shen_eq(ctx, t2220, t2255);
    if (!shen_is_boolean(ctx, t2256))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t2245 = t2256;
  }
    if (!shen_is_boolean(ctx, t2245))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t2240 = t2245;
  }
    if (!shen_is_boolean(ctx, t2240))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t2236 = t2240;
  }
    if (!shen_is_boolean(ctx, t2236))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t2231 = t2236;
  }
    if (!shen_is_boolean(ctx, t2231))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t2228 = t2231;
  }
    if (!shen_is_boolean(ctx, t2228))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t2228)) {
      t2223 = t2222;
    } else {
  KLObject* t2260 = shen_cons_p(ctx, t2222);
  KLObject* t2258;
  if (!shen_is_boolean(ctx, t2260))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t2260)) {
    t2258 = t2260;
  } else {
  KLObject* t2262 = shen_intern(ctx, "let");
  KLObject* t2264 = shen_hd(ctx, t2222);
  KLObject* t2265 = shen_eq(ctx, t2262, t2264);
  KLObject* t2261;
  if (!shen_is_boolean(ctx, t2265))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t2265)) {
    t2261 = t2265;
  } else {
  KLObject* t2268 = shen_tl(ctx, t2222);
  KLObject* t2269 = shen_cons_p(ctx, t2268);
  KLObject* t2266;
  if (!shen_is_boolean(ctx, t2269))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t2269)) {
    t2266 = t2269;
  } else {
  KLObject* t2272 = shen_tl(ctx, t2222);
  KLObject* t2273 = shen_tl(ctx, t2272);
  KLObject* t2274 = shen_cons_p(ctx, t2273);
  KLObject* t2270;
  if (!shen_is_boolean(ctx, t2274))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t2274)) {
    t2270 = t2274;
  } else {
  KLObject* t2277 = shen_tl(ctx, t2222);
  KLObject* t2278 = shen_tl(ctx, t2277);
  KLObject* t2279 = shen_tl(ctx, t2278);
  KLObject* t2280 = shen_cons_p(ctx, t2279);
  KLObject* t2275;
  if (!shen_is_boolean(ctx, t2280))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t2280)) {
    t2275 = t2280;
  } else {
  KLObject* t2282 = shen_empty_list(ctx);
  KLObject* t2284 = shen_tl(ctx, t2222);
  KLObject* t2285 = shen_tl(ctx, t2284);
  KLObject* t2286 = shen_tl(ctx, t2285);
  KLObject* t2287 = shen_tl(ctx, t2286);
  KLObject* t2288 = shen_eq(ctx, t2282, t2287);
  KLObject* t2281;
  if (!shen_is_boolean(ctx, t2288))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t2288)) {
    t2281 = t2288;
  } else {
  KLObject* t2291 = shen_tl(ctx, t2222);
  KLObject* t2292 = shen_hd(ctx, t2291);
  KLObject* t2293 = shen_eq(ctx, t2220, t2292);
    if (!shen_is_boolean(ctx, t2293))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t2281 = t2293;
  }
    if (!shen_is_boolean(ctx, t2281))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t2275 = t2281;
  }
    if (!shen_is_boolean(ctx, t2275))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t2270 = t2275;
  }
    if (!shen_is_boolean(ctx, t2270))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t2266 = t2270;
  }
    if (!shen_is_boolean(ctx, t2266))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t2261 = t2266;
  }
    if (!shen_is_boolean(ctx, t2261))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t2258 = t2261;
  }
    if (!shen_is_boolean(ctx, t2258))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t2258)) {
  KLObject* t2294 = shen_intern(ctx, "let");
  KLObject* t2296 = shen_tl(ctx, t2222);
  KLObject* t2297 = shen_hd(ctx, t2296);
  KLObject* t2300 = shen_tl(ctx, t2222);
  KLObject* t2301 = shen_hd(ctx, t2300);
  KLObject* t2304 = shen_tl(ctx, t2222);
  KLObject* t2305 = shen_tl(ctx, t2304);
  KLObject* t2306 = shen_hd(ctx, t2305);
  KLObject* t2298;
  {
    KLObject* a2298[] = {t2301, t2221, t2306};
    t2298 = shen_apply_direct(ctx, "shen.beta", 3, a2298);
  }
  KLObject* t2308 = shen_tl(ctx, t2222);
  KLObject* t2309 = shen_tl(ctx, t2308);
  KLObject* t2310 = shen_tl(ctx, t2309);
  KLObject* t2311 = shen_cons(ctx, t2298, t2310);
  KLObject* t2312 = shen_cons(ctx, t2297, t2311);
  KLObject* t2313 = shen_cons(ctx, t2294, t2312);
      t2223 = t2313;
    } else {
  KLObject* t2315 = shen_cons_p(ctx, t2222);
    if (!shen_is_boolean(ctx, t2315))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t2315)) {
  KLObject* t2317;
  {
    Vector* caps_10 = shen_vector(ctx, 2);
    shen_vector_set(ctx, caps_10, 0, t2220);
    shen_vector_set(ctx, caps_10, 1, t2221);
    t2317 = shen_native_closure(ctx, 1, &lambda_10, caps_10);
  }
  KLObject* t2316;
  {
    KLObject* a2316[] = {t2317, t2222};
    t2316 = shen_tail_apply_direct(ctx, "map", 2, a2316);
  }
      t2223 = t2316;
    } else {
  KLObject* t2326 = shen_true(ctx);
    if (!shen_is_boolean(ctx, t2326))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t2326)) {
      t2223 = t2222;
    } else {
      shen_simple_error(ctx, "No true case found for cond");
      t2223 = shen_empty_list(ctx);
    }
    }
    }
    }
    }
  }
    return t2223;
  }
}

static KLObject* native_kl_shen_2eop1_42 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t2328 = objects[0];
  tail_start_kl_shen_2eop1_42: ;
  KLObject* t2329;
  {
  KLObject* t2330 = shen_intern(ctx, "cons");
  KLObject* t2332 = shen_eq(ctx, t2330, t2328);
    if (!shen_is_boolean(ctx, t2332))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t2332)) {
  KLObject* t2333 = shen_intern(ctx, "hd");
      t2329 = t2333;
    } else {
  KLObject* t2334 = shen_intern(ctx, "@s");
  KLObject* t2336 = shen_eq(ctx, t2334, t2328);
    if (!shen_is_boolean(ctx, t2336))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t2336)) {
  KLObject* t2337 = shen_intern(ctx, "hdstr");
      t2329 = t2337;
    } else {
  KLObject* t2338 = shen_intern(ctx, "@p");
  KLObject* t2340 = shen_eq(ctx, t2338, t2328);
    if (!shen_is_boolean(ctx, t2340))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t2340)) {
  KLObject* t2341 = shen_intern(ctx, "fst");
      t2329 = t2341;
    } else {
  KLObject* t2342 = shen_intern(ctx, "@v");
  KLObject* t2344 = shen_eq(ctx, t2342, t2328);
    if (!shen_is_boolean(ctx, t2344))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t2344)) {
  KLObject* t2345 = shen_intern(ctx, "hdv");
      t2329 = t2345;
    } else {
  KLObject* t2346 = shen_true(ctx);
    if (!shen_is_boolean(ctx, t2346))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t2346)) {
  KLObject* t2348 = shen_string(ctx, "implementation error in shen.op1");
  KLObject* t2347;
  {
    KLObject* a2347[] = {t2348};
    t2347 = shen_tail_apply_direct(ctx, "simple-error", 1, a2347);
  }
      t2329 = t2347;
    } else {
      shen_simple_error(ctx, "No true case found for cond");
      t2329 = shen_empty_list(ctx);
    }
    }
    }
    }
    }
  }
    return t2329;
  }
}

static KLObject* native_kl_shen_2eop2_43 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t2349 = objects[0];
  tail_start_kl_shen_2eop2_43: ;
  KLObject* t2350;
  {
  KLObject* t2351 = shen_intern(ctx, "cons");
  KLObject* t2353 = shen_eq(ctx, t2351, t2349);
    if (!shen_is_boolean(ctx, t2353))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t2353)) {
  KLObject* t2354 = shen_intern(ctx, "tl");
      t2350 = t2354;
    } else {
  KLObject* t2355 = shen_intern(ctx, "@s");
  KLObject* t2357 = shen_eq(ctx, t2355, t2349);
    if (!shen_is_boolean(ctx, t2357))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t2357)) {
  KLObject* t2358 = shen_intern(ctx, "tlstr");
      t2350 = t2358;
    } else {
  KLObject* t2359 = shen_intern(ctx, "@p");
  KLObject* t2361 = shen_eq(ctx, t2359, t2349);
    if (!shen_is_boolean(ctx, t2361))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t2361)) {
  KLObject* t2362 = shen_intern(ctx, "snd");
      t2350 = t2362;
    } else {
  KLObject* t2363 = shen_intern(ctx, "@v");
  KLObject* t2365 = shen_eq(ctx, t2363, t2349);
    if (!shen_is_boolean(ctx, t2365))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t2365)) {
  KLObject* t2366 = shen_intern(ctx, "tlv");
      t2350 = t2366;
    } else {
  KLObject* t2367 = shen_true(ctx);
    if (!shen_is_boolean(ctx, t2367))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t2367)) {
  KLObject* t2369 = shen_string(ctx, "implementation error in shen.op2");
  KLObject* t2368;
  {
    KLObject* a2368[] = {t2369};
    t2368 = shen_tail_apply_direct(ctx, "simple-error", 1, a2368);
  }
      t2350 = t2368;
    } else {
      shen_simple_error(ctx, "No true case found for cond");
      t2350 = shen_empty_list(ctx);
    }
    }
    }
    }
    }
  }
    return t2350;
  }
}

static KLObject* native_kl_shen_2eop_2dtest_44 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t2370 = objects[0];
  tail_start_kl_shen_2eop_2dtest_44: ;
  KLObject* t2371;
  {
  KLObject* t2372 = shen_intern(ctx, "cons");
  KLObject* t2374 = shen_eq(ctx, t2372, t2370);
    if (!shen_is_boolean(ctx, t2374))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t2374)) {
  KLObject* t2375 = shen_intern(ctx, "cons?");
      t2371 = t2375;
    } else {
  KLObject* t2376 = shen_intern(ctx, "@s");
  KLObject* t2378 = shen_eq(ctx, t2376, t2370);
    if (!shen_is_boolean(ctx, t2378))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t2378)) {
  KLObject* t2379 = shen_intern(ctx, "shen.+string?");
      t2371 = t2379;
    } else {
  KLObject* t2380 = shen_intern(ctx, "@p");
  KLObject* t2382 = shen_eq(ctx, t2380, t2370);
    if (!shen_is_boolean(ctx, t2382))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t2382)) {
  KLObject* t2383 = shen_intern(ctx, "tuple?");
      t2371 = t2383;
    } else {
  KLObject* t2384 = shen_intern(ctx, "@v");
  KLObject* t2386 = shen_eq(ctx, t2384, t2370);
    if (!shen_is_boolean(ctx, t2386))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t2386)) {
  KLObject* t2387 = shen_intern(ctx, "shen.+vector?");
      t2371 = t2387;
    } else {
  KLObject* t2388 = shen_true(ctx);
    if (!shen_is_boolean(ctx, t2388))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t2388)) {
  KLObject* t2390 = shen_string(ctx, "implementation error in shen.op-test");
  KLObject* t2389;
  {
    KLObject* a2389[] = {t2390};
    t2389 = shen_tail_apply_direct(ctx, "simple-error", 1, a2389);
  }
      t2371 = t2389;
    } else {
      shen_simple_error(ctx, "No true case found for cond");
      t2371 = shen_empty_list(ctx);
    }
    }
    }
    }
    }
  }
    return t2371;
  }
}

static KLObject* native_kl_shen_2e_2bstring_3f_45 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t2391 = objects[0];
  tail_start_kl_shen_2e_2bstring_3f_45: ;
  KLObject* t2392;
  {
  KLObject* t2393 = shen_string(ctx, "");
  KLObject* t2395 = shen_eq(ctx, t2393, t2391);
    if (!shen_is_boolean(ctx, t2395))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t2395)) {
  KLObject* t2396 = shen_false(ctx);
      t2392 = t2396;
    } else {
  KLObject* t2397 = shen_true(ctx);
    if (!shen_is_boolean(ctx, t2397))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t2397)) {
  KLObject* t2399 = shen_string_p(ctx, t2391);
      t2392 = t2399;
    } else {
      shen_simple_error(ctx, "No true case found for cond");
      t2392 = shen_empty_list(ctx);
    }
    }
  }
    return t2392;
  }
}

static KLObject* native_kl_shen_2e_2bvector_3f_46 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t2400 = objects[0];
  tail_start_kl_shen_2e_2bvector_3f_46: ;
  KLObject* t2401;
  {
  KLObject* t2404 = shen_number_l(ctx, 0);
  KLObject* t2403;
  {
    KLObject* a2403[] = {t2404};
    t2403 = shen_apply_direct(ctx, "vector", 1, a2403);
  }
  KLObject* t2405 = shen_eq(ctx, t2400, t2403);
    if (!shen_is_boolean(ctx, t2405))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t2405)) {
  KLObject* t2406 = shen_false(ctx);
      t2401 = t2406;
    } else {
  KLObject* t2407 = shen_true(ctx);
    if (!shen_is_boolean(ctx, t2407))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t2407)) {
  KLObject* t2408;
  {
    KLObject* a2408[] = {t2400};
    t2408 = shen_tail_apply_direct(ctx, "vector?", 1, a2408);
  }
      t2401 = t2408;
    } else {
      shen_simple_error(ctx, "No true case found for cond");
      t2401 = shen_empty_list(ctx);
    }
    }
  }
    return t2401;
  }
}

static KLObject* native_kl_factorise_47 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t2410 = objects[0];
  tail_start_kl_factorise_47: ;
  KLObject* t2411;
  {
  KLObject* t2412 = shen_intern(ctx, "+");
  KLObject* t2414 = shen_eq(ctx, t2412, t2410);
    if (!shen_is_boolean(ctx, t2414))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t2414)) {
  KLObject* t2416 = shen_intern(ctx, "shen.*factorise?*");
  KLObject* t2417 = shen_true(ctx);
  KLObject* t2415;
  {
    KLObject* a2415[] = {t2416, t2417};
    t2415 = shen_tail_apply_direct(ctx, "set", 2, a2415);
  }
      t2411 = t2415;
    } else {
  KLObject* t2418 = shen_intern(ctx, "-");
  KLObject* t2420 = shen_eq(ctx, t2418, t2410);
    if (!shen_is_boolean(ctx, t2420))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t2420)) {
  KLObject* t2422 = shen_intern(ctx, "shen.*factorise?*");
  KLObject* t2423 = shen_false(ctx);
  KLObject* t2421;
  {
    KLObject* a2421[] = {t2422, t2423};
    t2421 = shen_tail_apply_direct(ctx, "set", 2, a2421);
  }
      t2411 = t2421;
    } else {
  KLObject* t2424 = shen_true(ctx);
    if (!shen_is_boolean(ctx, t2424))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t2424)) {
  KLObject* t2426 = shen_string(ctx, "factorise expects a + or a -\n");
  KLObject* t2425;
  {
    KLObject* a2425[] = {t2426};
    t2425 = shen_tail_apply_direct(ctx, "simple-error", 1, a2425);
  }
      t2411 = t2425;
    } else {
      shen_simple_error(ctx, "No true case found for cond");
      t2411 = shen_empty_list(ctx);
    }
    }
    }
  }
    return t2411;
  }
}

static KLObject* native_kl_shen_2efactorise_2dcode_48 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t2427 = objects[0];
  tail_start_kl_shen_2efactorise_2dcode_48: ;
  KLObject* t2428;
  {
  KLObject* t2430 = shen_intern(ctx, "shen.*factorise?*");
  KLObject* t2429;
  {
    KLObject* a2429[] = {t2430};
    t2429 = shen_apply_direct(ctx, "value", 1, a2429);
  }
    if (!shen_is_boolean(ctx, t2429))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t2429)) {
  KLObject* t2431;
  {
    KLObject* a2431[] = {t2427};
    t2431 = shen_tail_apply_direct(ctx, "shen.factor", 1, a2431);
  }
      t2428 = t2431;
    } else {
  KLObject* t2433 = shen_true(ctx);
    if (!shen_is_boolean(ctx, t2433))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t2433)) {
      t2428 = t2427;
    } else {
      shen_simple_error(ctx, "No true case found for cond");
      t2428 = shen_empty_list(ctx);
    }
    }
  }
    return t2428;
  }
}

static KLObject* native_kl_shen_2efactor_49 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t2435 = objects[0];
  tail_start_kl_shen_2efactor_49: ;
  KLObject* t2436;
  {
  KLObject* t2439 = shen_cons_p(ctx, t2435);
  KLObject* t2437;
  if (!shen_is_boolean(ctx, t2439))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t2439)) {
    t2437 = t2439;
  } else {
  KLObject* t2441 = shen_intern(ctx, "defun");
  KLObject* t2443 = shen_hd(ctx, t2435);
  KLObject* t2444 = shen_eq(ctx, t2441, t2443);
  KLObject* t2440;
  if (!shen_is_boolean(ctx, t2444))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t2444)) {
    t2440 = t2444;
  } else {
  KLObject* t2447 = shen_tl(ctx, t2435);
  KLObject* t2448 = shen_cons_p(ctx, t2447);
  KLObject* t2445;
  if (!shen_is_boolean(ctx, t2448))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t2448)) {
    t2445 = t2448;
  } else {
  KLObject* t2451 = shen_tl(ctx, t2435);
  KLObject* t2452 = shen_tl(ctx, t2451);
  KLObject* t2453 = shen_cons_p(ctx, t2452);
  KLObject* t2449;
  if (!shen_is_boolean(ctx, t2453))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t2453)) {
    t2449 = t2453;
  } else {
  KLObject* t2456 = shen_tl(ctx, t2435);
  KLObject* t2457 = shen_tl(ctx, t2456);
  KLObject* t2458 = shen_tl(ctx, t2457);
  KLObject* t2459 = shen_cons_p(ctx, t2458);
  KLObject* t2454;
  if (!shen_is_boolean(ctx, t2459))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t2459)) {
    t2454 = t2459;
  } else {
  KLObject* t2462 = shen_tl(ctx, t2435);
  KLObject* t2463 = shen_tl(ctx, t2462);
  KLObject* t2464 = shen_tl(ctx, t2463);
  KLObject* t2465 = shen_hd(ctx, t2464);
  KLObject* t2466 = shen_cons_p(ctx, t2465);
  KLObject* t2460;
  if (!shen_is_boolean(ctx, t2466))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t2466)) {
    t2460 = t2466;
  } else {
  KLObject* t2468 = shen_intern(ctx, "cond");
  KLObject* t2470 = shen_tl(ctx, t2435);
  KLObject* t2471 = shen_tl(ctx, t2470);
  KLObject* t2472 = shen_tl(ctx, t2471);
  KLObject* t2473 = shen_hd(ctx, t2472);
  KLObject* t2474 = shen_hd(ctx, t2473);
  KLObject* t2475 = shen_eq(ctx, t2468, t2474);
  KLObject* t2467;
  if (!shen_is_boolean(ctx, t2475))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t2475)) {
    t2467 = t2475;
  } else {
  KLObject* t2476 = shen_empty_list(ctx);
  KLObject* t2478 = shen_tl(ctx, t2435);
  KLObject* t2479 = shen_tl(ctx, t2478);
  KLObject* t2480 = shen_tl(ctx, t2479);
  KLObject* t2481 = shen_tl(ctx, t2480);
  KLObject* t2482 = shen_eq(ctx, t2476, t2481);
    if (!shen_is_boolean(ctx, t2482))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t2467 = t2482;
  }
    if (!shen_is_boolean(ctx, t2467))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t2460 = t2467;
  }
    if (!shen_is_boolean(ctx, t2460))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t2454 = t2460;
  }
    if (!shen_is_boolean(ctx, t2454))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t2449 = t2454;
  }
    if (!shen_is_boolean(ctx, t2449))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t2445 = t2449;
  }
    if (!shen_is_boolean(ctx, t2445))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t2440 = t2445;
  }
    if (!shen_is_boolean(ctx, t2440))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t2437 = t2440;
  }
    if (!shen_is_boolean(ctx, t2437))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t2437)) {
  KLObject* t2483 = shen_intern(ctx, "defun");
  KLObject* t2485 = shen_tl(ctx, t2435);
  KLObject* t2486 = shen_hd(ctx, t2485);
  KLObject* t2488 = shen_tl(ctx, t2435);
  KLObject* t2489 = shen_tl(ctx, t2488);
  KLObject* t2490 = shen_hd(ctx, t2489);
  KLObject* t2493 = shen_tl(ctx, t2435);
  KLObject* t2494 = shen_tl(ctx, t2493);
  KLObject* t2495 = shen_tl(ctx, t2494);
  KLObject* t2496 = shen_hd(ctx, t2495);
  KLObject* t2497 = shen_tl(ctx, t2496);
  KLObject* t2491;
  {
    KLObject* a2491[] = {t2497};
    t2491 = shen_apply_direct(ctx, "shen.factor-recognisors", 1, a2491);
  }
  KLObject* t2498 = shen_empty_list(ctx);
  KLObject* t2499 = shen_cons(ctx, t2491, t2498);
  KLObject* t2500 = shen_cons(ctx, t2490, t2499);
  KLObject* t2501 = shen_cons(ctx, t2486, t2500);
  KLObject* t2502 = shen_cons(ctx, t2483, t2501);
      t2436 = t2502;
    } else {
  KLObject* t2503 = shen_true(ctx);
    if (!shen_is_boolean(ctx, t2503))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t2503)) {
      t2436 = t2435;
    } else {
      shen_simple_error(ctx, "No true case found for cond");
      t2436 = shen_empty_list(ctx);
    }
    }
  }
    return t2436;
  }
}

static KLObject* native_kl_shen_2efactor_2drecognisors_50 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t2505 = objects[0];
  tail_start_kl_shen_2efactor_2drecognisors_50: ;
  KLObject* t2506;
  {
  KLObject* t2509 = shen_cons_p(ctx, t2505);
  KLObject* t2507;
  if (!shen_is_boolean(ctx, t2509))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t2509)) {
    t2507 = t2509;
  } else {
  KLObject* t2512 = shen_hd(ctx, t2505);
  KLObject* t2513 = shen_cons_p(ctx, t2512);
  KLObject* t2510;
  if (!shen_is_boolean(ctx, t2513))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t2513)) {
    t2510 = t2513;
  } else {
  KLObject* t2515 = shen_true(ctx);
  KLObject* t2517 = shen_hd(ctx, t2505);
  KLObject* t2518 = shen_hd(ctx, t2517);
  KLObject* t2519 = shen_eq(ctx, t2515, t2518);
  KLObject* t2514;
  if (!shen_is_boolean(ctx, t2519))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t2519)) {
    t2514 = t2519;
  } else {
  KLObject* t2522 = shen_hd(ctx, t2505);
  KLObject* t2523 = shen_tl(ctx, t2522);
  KLObject* t2524 = shen_cons_p(ctx, t2523);
  KLObject* t2520;
  if (!shen_is_boolean(ctx, t2524))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t2524)) {
    t2520 = t2524;
  } else {
  KLObject* t2525 = shen_empty_list(ctx);
  KLObject* t2527 = shen_hd(ctx, t2505);
  KLObject* t2528 = shen_tl(ctx, t2527);
  KLObject* t2529 = shen_tl(ctx, t2528);
  KLObject* t2530 = shen_eq(ctx, t2525, t2529);
    if (!shen_is_boolean(ctx, t2530))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t2520 = t2530;
  }
    if (!shen_is_boolean(ctx, t2520))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t2514 = t2520;
  }
    if (!shen_is_boolean(ctx, t2514))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t2510 = t2514;
  }
    if (!shen_is_boolean(ctx, t2510))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t2507 = t2510;
  }
    if (!shen_is_boolean(ctx, t2507))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t2507)) {
  KLObject* t2532 = shen_hd(ctx, t2505);
  KLObject* t2533 = shen_tl(ctx, t2532);
  KLObject* t2534 = shen_hd(ctx, t2533);
      t2506 = t2534;
    } else {
  KLObject* t2537 = shen_cons_p(ctx, t2505);
  KLObject* t2535;
  if (!shen_is_boolean(ctx, t2537))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t2537)) {
    t2535 = t2537;
  } else {
  KLObject* t2540 = shen_hd(ctx, t2505);
  KLObject* t2541 = shen_cons_p(ctx, t2540);
  KLObject* t2538;
  if (!shen_is_boolean(ctx, t2541))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t2541)) {
    t2538 = t2541;
  } else {
  KLObject* t2544 = shen_hd(ctx, t2505);
  KLObject* t2545 = shen_hd(ctx, t2544);
  KLObject* t2546 = shen_cons_p(ctx, t2545);
  KLObject* t2542;
  if (!shen_is_boolean(ctx, t2546))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t2546)) {
    t2542 = t2546;
  } else {
  KLObject* t2548 = shen_intern(ctx, "and");
  KLObject* t2550 = shen_hd(ctx, t2505);
  KLObject* t2551 = shen_hd(ctx, t2550);
  KLObject* t2552 = shen_hd(ctx, t2551);
  KLObject* t2553 = shen_eq(ctx, t2548, t2552);
  KLObject* t2547;
  if (!shen_is_boolean(ctx, t2553))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t2553)) {
    t2547 = t2553;
  } else {
  KLObject* t2556 = shen_hd(ctx, t2505);
  KLObject* t2557 = shen_hd(ctx, t2556);
  KLObject* t2558 = shen_tl(ctx, t2557);
  KLObject* t2559 = shen_cons_p(ctx, t2558);
  KLObject* t2554;
  if (!shen_is_boolean(ctx, t2559))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t2559)) {
    t2554 = t2559;
  } else {
  KLObject* t2562 = shen_hd(ctx, t2505);
  KLObject* t2563 = shen_hd(ctx, t2562);
  KLObject* t2564 = shen_tl(ctx, t2563);
  KLObject* t2565 = shen_tl(ctx, t2564);
  KLObject* t2566 = shen_cons_p(ctx, t2565);
  KLObject* t2560;
  if (!shen_is_boolean(ctx, t2566))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t2566)) {
    t2560 = t2566;
  } else {
  KLObject* t2568 = shen_empty_list(ctx);
  KLObject* t2570 = shen_hd(ctx, t2505);
  KLObject* t2571 = shen_hd(ctx, t2570);
  KLObject* t2572 = shen_tl(ctx, t2571);
  KLObject* t2573 = shen_tl(ctx, t2572);
  KLObject* t2574 = shen_tl(ctx, t2573);
  KLObject* t2575 = shen_eq(ctx, t2568, t2574);
  KLObject* t2567;
  if (!shen_is_boolean(ctx, t2575))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t2575)) {
    t2567 = t2575;
  } else {
  KLObject* t2578 = shen_hd(ctx, t2505);
  KLObject* t2579 = shen_tl(ctx, t2578);
  KLObject* t2580 = shen_cons_p(ctx, t2579);
  KLObject* t2576;
  if (!shen_is_boolean(ctx, t2580))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t2580)) {
    t2576 = t2580;
  } else {
  KLObject* t2581 = shen_empty_list(ctx);
  KLObject* t2583 = shen_hd(ctx, t2505);
  KLObject* t2584 = shen_tl(ctx, t2583);
  KLObject* t2585 = shen_tl(ctx, t2584);
  KLObject* t2586 = shen_eq(ctx, t2581, t2585);
    if (!shen_is_boolean(ctx, t2586))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t2576 = t2586;
  }
    if (!shen_is_boolean(ctx, t2576))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t2567 = t2576;
  }
    if (!shen_is_boolean(ctx, t2567))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t2560 = t2567;
  }
    if (!shen_is_boolean(ctx, t2560))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t2554 = t2560;
  }
    if (!shen_is_boolean(ctx, t2554))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t2547 = t2554;
  }
    if (!shen_is_boolean(ctx, t2547))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t2542 = t2547;
  }
    if (!shen_is_boolean(ctx, t2542))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t2538 = t2542;
  }
    if (!shen_is_boolean(ctx, t2538))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t2535 = t2538;
  }
    if (!shen_is_boolean(ctx, t2535))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t2535)) {
  KLObject* t2589 = shen_hd(ctx, t2505);
  KLObject* t2590 = shen_hd(ctx, t2589);
  KLObject* t2591 = shen_tl(ctx, t2590);
  KLObject* t2592 = shen_hd(ctx, t2591);
  KLObject* t2594 = shen_empty_list(ctx);
  KLObject* t2587;
  {
    KLObject* a2587[] = {t2592, t2505, t2594};
    t2587 = shen_apply_direct(ctx, "shen.pivot-on", 3, a2587);
  }
  KLObject* t2595;
  {
    KLObject* a2595[] = {t2587};
    t2595 = shen_apply_direct(ctx, "fst", 1, a2595);
  }
  KLObject* t2598;
  {
    KLObject* a2598[] = {t2595};
    t2598 = shen_apply_direct(ctx, "shen.bad-pivot?", 1, a2598);
  }
  KLObject* t2597;
  if (!shen_is_boolean(ctx, t2598))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t2598)) {
  KLObject* t2601 = shen_intern(ctx, "if");
  KLObject* t2602 = shen_empty_list(ctx);
  KLObject* t2603 = shen_cons(ctx, t2601, t2602);
  KLObject* t2607 = shen_hd(ctx, t2505);
  KLObject* t2608 = shen_hd(ctx, t2607);
  KLObject* t2610 = shen_hd(ctx, t2505);
  KLObject* t2611 = shen_tl(ctx, t2610);
  KLObject* t2612 = shen_hd(ctx, t2611);
  KLObject* t2605;
  {
    KLObject* a2605[] = {t2608, t2612};
    t2605 = shen_apply_direct(ctx, "shen.recursively-factor-selectors", 2, a2605);
  }
  KLObject* t2615 = shen_tl(ctx, t2505);
  KLObject* t2613;
  {
    KLObject* a2613[] = {t2615};
    t2613 = shen_apply_direct(ctx, "shen.factor-recognisors", 1, a2613);
  }
  KLObject* t2616 = shen_empty_list(ctx);
  KLObject* t2617 = shen_cons(ctx, t2613, t2616);
  KLObject* t2604;
  {
    KLObject* a2604[] = {t2605, t2617};
    t2604 = shen_apply_direct(ctx, "append", 2, a2604);
  }
  KLObject* t2600;
  {
    KLObject* a2600[] = {t2603, t2604};
    t2600 = shen_tail_apply_direct(ctx, "append", 2, a2600);
  }
    t2597 = t2600;
  } else {
  KLObject* t2618;
  {
    KLObject* a2618[] = {t2587};
    t2618 = shen_apply_direct(ctx, "snd", 1, a2618);
  }
  KLObject* t2620;
  {
    KLObject* a2620[] = {t2618};
    t2620 = shen_apply_direct(ctx, "shen.factor-recognisors", 1, a2620);
  }
  KLObject* t2623 = shen_intern(ctx, "GoTo");
  KLObject* t2622;
  {
    KLObject* a2622[] = {t2623};
    t2622 = shen_apply_direct(ctx, "gensym", 1, a2622);
  }
  KLObject* t2625 = shen_true(ctx);
  KLObject* t2626 = shen_intern(ctx, "thaw");
  KLObject* t2628 = shen_empty_list(ctx);
  KLObject* t2629 = shen_cons(ctx, t2622, t2628);
  KLObject* t2630 = shen_cons(ctx, t2626, t2629);
  KLObject* t2631 = shen_empty_list(ctx);
  KLObject* t2632 = shen_cons(ctx, t2630, t2631);
  KLObject* t2633 = shen_cons(ctx, t2625, t2632);
  KLObject* t2635 = shen_cons(ctx, t2633, t2595);
  KLObject* t2624;
  {
    KLObject* a2624[] = {t2635};
    t2624 = shen_apply_direct(ctx, "reverse", 1, a2624);
  }
  KLObject* t2636 = shen_intern(ctx, "let");
  KLObject* t2638 = shen_intern(ctx, "freeze");
  KLObject* t2640 = shen_empty_list(ctx);
  KLObject* t2641 = shen_cons(ctx, t2620, t2640);
  KLObject* t2642 = shen_cons(ctx, t2638, t2641);
  KLObject* t2643 = shen_intern(ctx, "if");
  KLObject* t2645 = shen_hd(ctx, t2505);
  KLObject* t2646 = shen_hd(ctx, t2645);
  KLObject* t2647 = shen_tl(ctx, t2646);
  KLObject* t2648 = shen_hd(ctx, t2647);
  KLObject* t2651 = shen_hd(ctx, t2505);
  KLObject* t2652 = shen_hd(ctx, t2651);
  KLObject* t2653 = shen_tl(ctx, t2652);
  KLObject* t2654 = shen_hd(ctx, t2653);
  KLObject* t2655;
  {
    KLObject* a2655[] = {t2624};
    t2655 = shen_apply_direct(ctx, "shen.factor-recognisors", 1, a2655);
  }
  KLObject* t2649;
  {
    KLObject* a2649[] = {t2654, t2655};
    t2649 = shen_apply_direct(ctx, "shen.factor-selectors", 2, a2649);
  }
  KLObject* t2657 = shen_intern(ctx, "thaw");
  KLObject* t2659 = shen_empty_list(ctx);
  KLObject* t2660 = shen_cons(ctx, t2622, t2659);
  KLObject* t2661 = shen_cons(ctx, t2657, t2660);
  KLObject* t2662 = shen_empty_list(ctx);
  KLObject* t2663 = shen_cons(ctx, t2661, t2662);
  KLObject* t2664 = shen_cons(ctx, t2649, t2663);
  KLObject* t2665 = shen_cons(ctx, t2648, t2664);
  KLObject* t2666 = shen_cons(ctx, t2643, t2665);
  KLObject* t2667 = shen_empty_list(ctx);
  KLObject* t2668 = shen_cons(ctx, t2666, t2667);
  KLObject* t2669 = shen_cons(ctx, t2642, t2668);
  KLObject* t2670 = shen_cons(ctx, t2622, t2669);
  KLObject* t2671 = shen_cons(ctx, t2636, t2670);
  KLObject* t2672;
  {
    KLObject* a2672[] = {t2671};
    t2672 = shen_tail_apply_direct(ctx, "shen.remove-indirection", 1, a2672);
  }
    t2597 = t2672;
  }
      t2506 = t2597;
    } else {
  KLObject* t2676 = shen_cons_p(ctx, t2505);
  KLObject* t2674;
  if (!shen_is_boolean(ctx, t2676))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t2676)) {
    t2674 = t2676;
  } else {
  KLObject* t2679 = shen_hd(ctx, t2505);
  KLObject* t2680 = shen_cons_p(ctx, t2679);
  KLObject* t2677;
  if (!shen_is_boolean(ctx, t2680))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t2680)) {
    t2677 = t2680;
  } else {
  KLObject* t2683 = shen_hd(ctx, t2505);
  KLObject* t2684 = shen_tl(ctx, t2683);
  KLObject* t2685 = shen_cons_p(ctx, t2684);
  KLObject* t2681;
  if (!shen_is_boolean(ctx, t2685))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t2685)) {
    t2681 = t2685;
  } else {
  KLObject* t2686 = shen_empty_list(ctx);
  KLObject* t2688 = shen_hd(ctx, t2505);
  KLObject* t2689 = shen_tl(ctx, t2688);
  KLObject* t2690 = shen_tl(ctx, t2689);
  KLObject* t2691 = shen_eq(ctx, t2686, t2690);
    if (!shen_is_boolean(ctx, t2691))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t2681 = t2691;
  }
    if (!shen_is_boolean(ctx, t2681))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t2677 = t2681;
  }
    if (!shen_is_boolean(ctx, t2677))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t2674 = t2677;
  }
    if (!shen_is_boolean(ctx, t2674))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t2674)) {
  KLObject* t2692 = shen_intern(ctx, "if");
  KLObject* t2694 = shen_hd(ctx, t2505);
  KLObject* t2695 = shen_hd(ctx, t2694);
  KLObject* t2697 = shen_hd(ctx, t2505);
  KLObject* t2698 = shen_tl(ctx, t2697);
  KLObject* t2699 = shen_hd(ctx, t2698);
  KLObject* t2702 = shen_tl(ctx, t2505);
  KLObject* t2700;
  {
    KLObject* a2700[] = {t2702};
    t2700 = shen_apply_direct(ctx, "shen.factor-recognisors", 1, a2700);
  }
  KLObject* t2703 = shen_empty_list(ctx);
  KLObject* t2704 = shen_cons(ctx, t2700, t2703);
  KLObject* t2705 = shen_cons(ctx, t2699, t2704);
  KLObject* t2706 = shen_cons(ctx, t2695, t2705);
  KLObject* t2707 = shen_cons(ctx, t2692, t2706);
      t2506 = t2707;
    } else {
  KLObject* t2708 = shen_true(ctx);
    if (!shen_is_boolean(ctx, t2708))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t2708)) {
  KLObject* t2710 = shen_string(ctx, "partial function shen.factor-recognisors");
  KLObject* t2709;
  {
    KLObject* a2709[] = {t2710};
    t2709 = shen_tail_apply_direct(ctx, "simple-error", 1, a2709);
  }
      t2506 = t2709;
    } else {
      shen_simple_error(ctx, "No true case found for cond");
      t2506 = shen_empty_list(ctx);
    }
    }
    }
    }
  }
    return t2506;
  }
}

static KLObject* native_kl_shen_2erecursively_2dfactor_2dselectors_51 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t2711 = objects[0];
    KLObject* t2712 = objects[1];
  tail_start_kl_shen_2erecursively_2dfactor_2dselectors_51: ;
  KLObject* t2713;
  {
  KLObject* t2716 = shen_cons_p(ctx, t2711);
  KLObject* t2714;
  if (!shen_is_boolean(ctx, t2716))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t2716)) {
    t2714 = t2716;
  } else {
  KLObject* t2718 = shen_intern(ctx, "let");
  KLObject* t2720 = shen_hd(ctx, t2711);
  KLObject* t2721 = shen_eq(ctx, t2718, t2720);
  KLObject* t2717;
  if (!shen_is_boolean(ctx, t2721))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t2721)) {
    t2717 = t2721;
  } else {
  KLObject* t2724 = shen_tl(ctx, t2711);
  KLObject* t2725 = shen_cons_p(ctx, t2724);
  KLObject* t2722;
  if (!shen_is_boolean(ctx, t2725))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t2725)) {
    t2722 = t2725;
  } else {
  KLObject* t2728 = shen_tl(ctx, t2711);
  KLObject* t2729 = shen_tl(ctx, t2728);
  KLObject* t2730 = shen_cons_p(ctx, t2729);
  KLObject* t2726;
  if (!shen_is_boolean(ctx, t2730))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t2730)) {
    t2726 = t2730;
  } else {
  KLObject* t2733 = shen_tl(ctx, t2711);
  KLObject* t2734 = shen_tl(ctx, t2733);
  KLObject* t2735 = shen_tl(ctx, t2734);
  KLObject* t2736 = shen_cons_p(ctx, t2735);
  KLObject* t2731;
  if (!shen_is_boolean(ctx, t2736))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t2736)) {
    t2731 = t2736;
  } else {
  KLObject* t2737 = shen_empty_list(ctx);
  KLObject* t2739 = shen_tl(ctx, t2711);
  KLObject* t2740 = shen_tl(ctx, t2739);
  KLObject* t2741 = shen_tl(ctx, t2740);
  KLObject* t2742 = shen_tl(ctx, t2741);
  KLObject* t2743 = shen_eq(ctx, t2737, t2742);
    if (!shen_is_boolean(ctx, t2743))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t2731 = t2743;
  }
    if (!shen_is_boolean(ctx, t2731))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t2726 = t2731;
  }
    if (!shen_is_boolean(ctx, t2726))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t2722 = t2726;
  }
    if (!shen_is_boolean(ctx, t2722))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t2717 = t2722;
  }
    if (!shen_is_boolean(ctx, t2717))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t2714 = t2717;
  }
    if (!shen_is_boolean(ctx, t2714))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t2714)) {
  KLObject* t2746 = shen_tl(ctx, t2711);
  KLObject* t2747 = shen_hd(ctx, t2746);
  KLObject* t2749 = shen_tl(ctx, t2711);
  KLObject* t2750 = shen_tl(ctx, t2749);
  KLObject* t2751 = shen_hd(ctx, t2750);
  KLObject* t2754 = shen_tl(ctx, t2711);
  KLObject* t2755 = shen_tl(ctx, t2754);
  KLObject* t2756 = shen_tl(ctx, t2755);
  KLObject* t2757 = shen_hd(ctx, t2756);
  KLObject* t2752;
  {
    KLObject* a2752[] = {t2757, t2712};
    t2752 = shen_apply_direct(ctx, "shen.recursively-factor-selectors", 2, a2752);
  }
  KLObject* t2744;
  {
    KLObject* a2744[] = {t2747, t2751, t2752};
    t2744 = shen_tail_apply_direct(ctx, "shen.restore-local", 3, a2744);
  }
      t2713 = t2744;
    } else {
  KLObject* t2761 = shen_cons_p(ctx, t2711);
  KLObject* t2759;
  if (!shen_is_boolean(ctx, t2761))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t2761)) {
    t2759 = t2761;
  } else {
  KLObject* t2763 = shen_intern(ctx, "and");
  KLObject* t2765 = shen_hd(ctx, t2711);
  KLObject* t2766 = shen_eq(ctx, t2763, t2765);
  KLObject* t2762;
  if (!shen_is_boolean(ctx, t2766))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t2766)) {
    t2762 = t2766;
  } else {
  KLObject* t2769 = shen_tl(ctx, t2711);
  KLObject* t2770 = shen_cons_p(ctx, t2769);
  KLObject* t2767;
  if (!shen_is_boolean(ctx, t2770))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t2770)) {
    t2767 = t2770;
  } else {
  KLObject* t2773 = shen_tl(ctx, t2711);
  KLObject* t2774 = shen_tl(ctx, t2773);
  KLObject* t2775 = shen_cons_p(ctx, t2774);
  KLObject* t2771;
  if (!shen_is_boolean(ctx, t2775))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t2775)) {
    t2771 = t2775;
  } else {
  KLObject* t2776 = shen_empty_list(ctx);
  KLObject* t2778 = shen_tl(ctx, t2711);
  KLObject* t2779 = shen_tl(ctx, t2778);
  KLObject* t2780 = shen_tl(ctx, t2779);
  KLObject* t2781 = shen_eq(ctx, t2776, t2780);
    if (!shen_is_boolean(ctx, t2781))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t2771 = t2781;
  }
    if (!shen_is_boolean(ctx, t2771))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t2767 = t2771;
  }
    if (!shen_is_boolean(ctx, t2767))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t2762 = t2767;
  }
    if (!shen_is_boolean(ctx, t2762))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t2759 = t2762;
  }
    if (!shen_is_boolean(ctx, t2759))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t2759)) {
  KLObject* t2784 = shen_tl(ctx, t2711);
  KLObject* t2785 = shen_hd(ctx, t2784);
  KLObject* t2789 = shen_tl(ctx, t2711);
  KLObject* t2790 = shen_hd(ctx, t2789);
  KLObject* t2792 = shen_tl(ctx, t2711);
  KLObject* t2793 = shen_tl(ctx, t2792);
  KLObject* t2794 = shen_hd(ctx, t2793);
  KLObject* t2787;
  {
    KLObject* a2787[] = {t2790, t2794};
    t2787 = shen_apply_direct(ctx, "shen.factor-selectors", 2, a2787);
  }
  KLObject* t2797 = shen_tl(ctx, t2711);
  KLObject* t2798 = shen_hd(ctx, t2797);
  KLObject* t2795;
  {
    KLObject* a2795[] = {t2798, t2712};
    t2795 = shen_apply_direct(ctx, "shen.factor-selectors", 2, a2795);
  }
  KLObject* t2786;
  {
    KLObject* a2786[] = {t2787, t2795};
    t2786 = shen_apply_direct(ctx, "shen.recursively-factor-selectors", 2, a2786);
  }
  KLObject* t2782;
  {
    KLObject* a2782[] = {t2785, t2786};
    t2782 = shen_tail_apply_direct(ctx, "shen.restore-P", 2, a2782);
  }
      t2713 = t2782;
    } else {
  KLObject* t2800 = shen_true(ctx);
    if (!shen_is_boolean(ctx, t2800))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t2800)) {
  KLObject* t2803 = shen_empty_list(ctx);
  KLObject* t2804 = shen_cons(ctx, t2712, t2803);
  KLObject* t2805 = shen_cons(ctx, t2711, t2804);
      t2713 = t2805;
    } else {
      shen_simple_error(ctx, "No true case found for cond");
      t2713 = shen_empty_list(ctx);
    }
    }
    }
  }
    return t2713;
  }
}

static KLObject* native_kl_shen_2erestore_2dP_52 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t2806 = objects[0];
    KLObject* t2807 = objects[1];
  tail_start_kl_shen_2erestore_2dP_52: ;
  KLObject* t2808;
  {
  KLObject* t2811 = shen_cons_p(ctx, t2807);
  KLObject* t2809;
  if (!shen_is_boolean(ctx, t2811))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t2811)) {
    t2809 = t2811;
  } else {
  KLObject* t2814 = shen_tl(ctx, t2807);
  KLObject* t2815 = shen_cons_p(ctx, t2814);
  KLObject* t2812;
  if (!shen_is_boolean(ctx, t2815))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t2815)) {
    t2812 = t2815;
  } else {
  KLObject* t2816 = shen_empty_list(ctx);
  KLObject* t2818 = shen_tl(ctx, t2807);
  KLObject* t2819 = shen_tl(ctx, t2818);
  KLObject* t2820 = shen_eq(ctx, t2816, t2819);
    if (!shen_is_boolean(ctx, t2820))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t2812 = t2820;
  }
    if (!shen_is_boolean(ctx, t2812))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t2809 = t2812;
  }
    if (!shen_is_boolean(ctx, t2809))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t2809)) {
  KLObject* t2821 = shen_intern(ctx, "and");
  KLObject* t2824 = shen_hd(ctx, t2807);
  KLObject* t2825 = shen_empty_list(ctx);
  KLObject* t2826 = shen_cons(ctx, t2824, t2825);
  KLObject* t2827 = shen_cons(ctx, t2806, t2826);
  KLObject* t2828 = shen_cons(ctx, t2821, t2827);
  KLObject* t2830 = shen_tl(ctx, t2807);
  KLObject* t2831 = shen_cons(ctx, t2828, t2830);
      t2808 = t2831;
    } else {
  KLObject* t2832 = shen_true(ctx);
    if (!shen_is_boolean(ctx, t2832))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t2832)) {
  KLObject* t2834 = shen_string(ctx, "partial function shen.restore-P");
  KLObject* t2833;
  {
    KLObject* a2833[] = {t2834};
    t2833 = shen_tail_apply_direct(ctx, "simple-error", 1, a2833);
  }
      t2808 = t2833;
    } else {
      shen_simple_error(ctx, "No true case found for cond");
      t2808 = shen_empty_list(ctx);
    }
    }
  }
    return t2808;
  }
}

static KLObject* native_kl_shen_2erestore_2dlocal_53 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t2835 = objects[0];
    KLObject* t2836 = objects[1];
    KLObject* t2837 = objects[2];
  tail_start_kl_shen_2erestore_2dlocal_53: ;
  KLObject* t2838;
  {
  KLObject* t2841 = shen_cons_p(ctx, t2837);
  KLObject* t2839;
  if (!shen_is_boolean(ctx, t2841))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t2841)) {
    t2839 = t2841;
  } else {
  KLObject* t2844 = shen_tl(ctx, t2837);
  KLObject* t2845 = shen_cons_p(ctx, t2844);
  KLObject* t2842;
  if (!shen_is_boolean(ctx, t2845))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t2845)) {
    t2842 = t2845;
  } else {
  KLObject* t2846 = shen_empty_list(ctx);
  KLObject* t2848 = shen_tl(ctx, t2837);
  KLObject* t2849 = shen_tl(ctx, t2848);
  KLObject* t2850 = shen_eq(ctx, t2846, t2849);
    if (!shen_is_boolean(ctx, t2850))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t2842 = t2850;
  }
    if (!shen_is_boolean(ctx, t2842))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t2839 = t2842;
  }
    if (!shen_is_boolean(ctx, t2839))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t2839)) {
  KLObject* t2851 = shen_intern(ctx, "let");
  KLObject* t2855 = shen_hd(ctx, t2837);
  KLObject* t2856 = shen_empty_list(ctx);
  KLObject* t2857 = shen_cons(ctx, t2855, t2856);
  KLObject* t2858 = shen_cons(ctx, t2836, t2857);
  KLObject* t2859 = shen_cons(ctx, t2835, t2858);
  KLObject* t2860 = shen_cons(ctx, t2851, t2859);
  KLObject* t2862 = shen_tl(ctx, t2837);
  KLObject* t2863 = shen_cons(ctx, t2860, t2862);
      t2838 = t2863;
    } else {
  KLObject* t2864 = shen_true(ctx);
    if (!shen_is_boolean(ctx, t2864))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t2864)) {
  KLObject* t2866 = shen_string(ctx, "partial function shen.restore-local");
  KLObject* t2865;
  {
    KLObject* a2865[] = {t2866};
    t2865 = shen_tail_apply_direct(ctx, "simple-error", 1, a2865);
  }
      t2838 = t2865;
    } else {
      shen_simple_error(ctx, "No true case found for cond");
      t2838 = shen_empty_list(ctx);
    }
    }
  }
    return t2838;
  }
}

static KLObject* native_kl_shen_2ebad_2dpivot_3f_54 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t2867 = objects[0];
  tail_start_kl_shen_2ebad_2dpivot_3f_54: ;
  KLObject* t2868;
  {
  KLObject* t2871 = shen_cons_p(ctx, t2867);
  KLObject* t2869;
  if (!shen_is_boolean(ctx, t2871))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t2871)) {
    t2869 = t2871;
  } else {
  KLObject* t2872 = shen_empty_list(ctx);
  KLObject* t2874 = shen_tl(ctx, t2867);
  KLObject* t2875 = shen_eq(ctx, t2872, t2874);
    if (!shen_is_boolean(ctx, t2875))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t2869 = t2875;
  }
    if (!shen_is_boolean(ctx, t2869))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t2869)) {
  KLObject* t2876 = shen_true(ctx);
      t2868 = t2876;
    } else {
  KLObject* t2877 = shen_true(ctx);
    if (!shen_is_boolean(ctx, t2877))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t2877)) {
  KLObject* t2878 = shen_false(ctx);
      t2868 = t2878;
    } else {
      shen_simple_error(ctx, "No true case found for cond");
      t2868 = shen_empty_list(ctx);
    }
    }
  }
    return t2868;
  }
}

static KLObject* native_kl_shen_2eremove_2dindirection_55 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t2879 = objects[0];
  tail_start_kl_shen_2eremove_2dindirection_55: ;
  KLObject* t2880;
  {
  KLObject* t2883 = shen_cons_p(ctx, t2879);
  KLObject* t2881;
  if (!shen_is_boolean(ctx, t2883))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t2883)) {
    t2881 = t2883;
  } else {
  KLObject* t2885 = shen_intern(ctx, "let");
  KLObject* t2887 = shen_hd(ctx, t2879);
  KLObject* t2888 = shen_eq(ctx, t2885, t2887);
  KLObject* t2884;
  if (!shen_is_boolean(ctx, t2888))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t2888)) {
    t2884 = t2888;
  } else {
  KLObject* t2891 = shen_tl(ctx, t2879);
  KLObject* t2892 = shen_cons_p(ctx, t2891);
  KLObject* t2889;
  if (!shen_is_boolean(ctx, t2892))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t2892)) {
    t2889 = t2892;
  } else {
  KLObject* t2895 = shen_tl(ctx, t2879);
  KLObject* t2896 = shen_tl(ctx, t2895);
  KLObject* t2897 = shen_cons_p(ctx, t2896);
  KLObject* t2893;
  if (!shen_is_boolean(ctx, t2897))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t2897)) {
    t2893 = t2897;
  } else {
  KLObject* t2900 = shen_tl(ctx, t2879);
  KLObject* t2901 = shen_tl(ctx, t2900);
  KLObject* t2902 = shen_hd(ctx, t2901);
  KLObject* t2903 = shen_cons_p(ctx, t2902);
  KLObject* t2898;
  if (!shen_is_boolean(ctx, t2903))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t2903)) {
    t2898 = t2903;
  } else {
  KLObject* t2905 = shen_intern(ctx, "freeze");
  KLObject* t2907 = shen_tl(ctx, t2879);
  KLObject* t2908 = shen_tl(ctx, t2907);
  KLObject* t2909 = shen_hd(ctx, t2908);
  KLObject* t2910 = shen_hd(ctx, t2909);
  KLObject* t2911 = shen_eq(ctx, t2905, t2910);
  KLObject* t2904;
  if (!shen_is_boolean(ctx, t2911))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t2911)) {
    t2904 = t2911;
  } else {
  KLObject* t2914 = shen_tl(ctx, t2879);
  KLObject* t2915 = shen_tl(ctx, t2914);
  KLObject* t2916 = shen_hd(ctx, t2915);
  KLObject* t2917 = shen_tl(ctx, t2916);
  KLObject* t2918 = shen_cons_p(ctx, t2917);
  KLObject* t2912;
  if (!shen_is_boolean(ctx, t2918))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t2918)) {
    t2912 = t2918;
  } else {
  KLObject* t2921 = shen_tl(ctx, t2879);
  KLObject* t2922 = shen_tl(ctx, t2921);
  KLObject* t2923 = shen_hd(ctx, t2922);
  KLObject* t2924 = shen_tl(ctx, t2923);
  KLObject* t2925 = shen_hd(ctx, t2924);
  KLObject* t2926 = shen_cons_p(ctx, t2925);
  KLObject* t2919;
  if (!shen_is_boolean(ctx, t2926))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t2926)) {
    t2919 = t2926;
  } else {
  KLObject* t2928 = shen_intern(ctx, "thaw");
  KLObject* t2930 = shen_tl(ctx, t2879);
  KLObject* t2931 = shen_tl(ctx, t2930);
  KLObject* t2932 = shen_hd(ctx, t2931);
  KLObject* t2933 = shen_tl(ctx, t2932);
  KLObject* t2934 = shen_hd(ctx, t2933);
  KLObject* t2935 = shen_hd(ctx, t2934);
  KLObject* t2936 = shen_eq(ctx, t2928, t2935);
  KLObject* t2927;
  if (!shen_is_boolean(ctx, t2936))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t2936)) {
    t2927 = t2936;
  } else {
  KLObject* t2939 = shen_tl(ctx, t2879);
  KLObject* t2940 = shen_tl(ctx, t2939);
  KLObject* t2941 = shen_hd(ctx, t2940);
  KLObject* t2942 = shen_tl(ctx, t2941);
  KLObject* t2943 = shen_hd(ctx, t2942);
  KLObject* t2944 = shen_tl(ctx, t2943);
  KLObject* t2945 = shen_cons_p(ctx, t2944);
  KLObject* t2937;
  if (!shen_is_boolean(ctx, t2945))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t2945)) {
    t2937 = t2945;
  } else {
  KLObject* t2947 = shen_empty_list(ctx);
  KLObject* t2949 = shen_tl(ctx, t2879);
  KLObject* t2950 = shen_tl(ctx, t2949);
  KLObject* t2951 = shen_hd(ctx, t2950);
  KLObject* t2952 = shen_tl(ctx, t2951);
  KLObject* t2953 = shen_hd(ctx, t2952);
  KLObject* t2954 = shen_tl(ctx, t2953);
  KLObject* t2955 = shen_tl(ctx, t2954);
  KLObject* t2956 = shen_eq(ctx, t2947, t2955);
  KLObject* t2946;
  if (!shen_is_boolean(ctx, t2956))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t2956)) {
    t2946 = t2956;
  } else {
  KLObject* t2958 = shen_empty_list(ctx);
  KLObject* t2960 = shen_tl(ctx, t2879);
  KLObject* t2961 = shen_tl(ctx, t2960);
  KLObject* t2962 = shen_hd(ctx, t2961);
  KLObject* t2963 = shen_tl(ctx, t2962);
  KLObject* t2964 = shen_tl(ctx, t2963);
  KLObject* t2965 = shen_eq(ctx, t2958, t2964);
  KLObject* t2957;
  if (!shen_is_boolean(ctx, t2965))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t2965)) {
    t2957 = t2965;
  } else {
  KLObject* t2968 = shen_tl(ctx, t2879);
  KLObject* t2969 = shen_tl(ctx, t2968);
  KLObject* t2970 = shen_tl(ctx, t2969);
  KLObject* t2971 = shen_cons_p(ctx, t2970);
  KLObject* t2966;
  if (!shen_is_boolean(ctx, t2971))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t2971)) {
    t2966 = t2971;
  } else {
  KLObject* t2973 = shen_empty_list(ctx);
  KLObject* t2975 = shen_tl(ctx, t2879);
  KLObject* t2976 = shen_tl(ctx, t2975);
  KLObject* t2977 = shen_tl(ctx, t2976);
  KLObject* t2978 = shen_tl(ctx, t2977);
  KLObject* t2979 = shen_eq(ctx, t2973, t2978);
  KLObject* t2972;
  if (!shen_is_boolean(ctx, t2979))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t2979)) {
    t2972 = t2979;
  } else {
  KLObject* t2981 = shen_tl(ctx, t2879);
  KLObject* t2982 = shen_tl(ctx, t2981);
  KLObject* t2983 = shen_hd(ctx, t2982);
  KLObject* t2984 = shen_tl(ctx, t2983);
  KLObject* t2985 = shen_hd(ctx, t2984);
  KLObject* t2986 = shen_tl(ctx, t2985);
  KLObject* t2987 = shen_hd(ctx, t2986);
  KLObject* t2988 = shen_symbol_p(ctx, t2987);
    if (!shen_is_boolean(ctx, t2988))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t2972 = t2988;
  }
    if (!shen_is_boolean(ctx, t2972))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t2966 = t2972;
  }
    if (!shen_is_boolean(ctx, t2966))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t2957 = t2966;
  }
    if (!shen_is_boolean(ctx, t2957))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t2946 = t2957;
  }
    if (!shen_is_boolean(ctx, t2946))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t2937 = t2946;
  }
    if (!shen_is_boolean(ctx, t2937))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t2927 = t2937;
  }
    if (!shen_is_boolean(ctx, t2927))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t2919 = t2927;
  }
    if (!shen_is_boolean(ctx, t2919))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t2912 = t2919;
  }
    if (!shen_is_boolean(ctx, t2912))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t2904 = t2912;
  }
    if (!shen_is_boolean(ctx, t2904))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t2898 = t2904;
  }
    if (!shen_is_boolean(ctx, t2898))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t2893 = t2898;
  }
    if (!shen_is_boolean(ctx, t2893))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t2889 = t2893;
  }
    if (!shen_is_boolean(ctx, t2889))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t2884 = t2889;
  }
    if (!shen_is_boolean(ctx, t2884))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t2881 = t2884;
  }
    if (!shen_is_boolean(ctx, t2881))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t2881)) {
  KLObject* t2991 = shen_tl(ctx, t2879);
  KLObject* t2992 = shen_tl(ctx, t2991);
  KLObject* t2993 = shen_hd(ctx, t2992);
  KLObject* t2994 = shen_tl(ctx, t2993);
  KLObject* t2995 = shen_hd(ctx, t2994);
  KLObject* t2996 = shen_tl(ctx, t2995);
  KLObject* t2997 = shen_hd(ctx, t2996);
  KLObject* t2999 = shen_tl(ctx, t2879);
  KLObject* t3000 = shen_hd(ctx, t2999);
  KLObject* t3002 = shen_tl(ctx, t2879);
  KLObject* t3003 = shen_tl(ctx, t3002);
  KLObject* t3004 = shen_tl(ctx, t3003);
  KLObject* t3005 = shen_hd(ctx, t3004);
  KLObject* t2989;
  {
    KLObject* a2989[] = {t2997, t3000, t3005};
    t2989 = shen_tail_apply_direct(ctx, "subst", 3, a2989);
  }
      t2880 = t2989;
    } else {
  KLObject* t3006 = shen_true(ctx);
    if (!shen_is_boolean(ctx, t3006))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t3006)) {
      t2880 = t2879;
    } else {
      shen_simple_error(ctx, "No true case found for cond");
      t2880 = shen_empty_list(ctx);
    }
    }
  }
    return t2880;
  }
}

static KLObject* native_kl_shen_2epivot_2don_56 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t3008 = objects[0];
    KLObject* t3009 = objects[1];
    KLObject* t3010 = objects[2];
  tail_start_kl_shen_2epivot_2don_56: ;
  KLObject* t3011;
  {
  KLObject* t3014 = shen_cons_p(ctx, t3009);
  KLObject* t3012;
  if (!shen_is_boolean(ctx, t3014))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t3014)) {
    t3012 = t3014;
  } else {
  KLObject* t3017 = shen_hd(ctx, t3009);
  KLObject* t3018 = shen_cons_p(ctx, t3017);
  KLObject* t3015;
  if (!shen_is_boolean(ctx, t3018))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t3018)) {
    t3015 = t3018;
  } else {
  KLObject* t3021 = shen_hd(ctx, t3009);
  KLObject* t3022 = shen_hd(ctx, t3021);
  KLObject* t3023 = shen_cons_p(ctx, t3022);
  KLObject* t3019;
  if (!shen_is_boolean(ctx, t3023))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t3023)) {
    t3019 = t3023;
  } else {
  KLObject* t3025 = shen_intern(ctx, "and");
  KLObject* t3027 = shen_hd(ctx, t3009);
  KLObject* t3028 = shen_hd(ctx, t3027);
  KLObject* t3029 = shen_hd(ctx, t3028);
  KLObject* t3030 = shen_eq(ctx, t3025, t3029);
  KLObject* t3024;
  if (!shen_is_boolean(ctx, t3030))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t3030)) {
    t3024 = t3030;
  } else {
  KLObject* t3033 = shen_hd(ctx, t3009);
  KLObject* t3034 = shen_hd(ctx, t3033);
  KLObject* t3035 = shen_tl(ctx, t3034);
  KLObject* t3036 = shen_cons_p(ctx, t3035);
  KLObject* t3031;
  if (!shen_is_boolean(ctx, t3036))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t3036)) {
    t3031 = t3036;
  } else {
  KLObject* t3039 = shen_hd(ctx, t3009);
  KLObject* t3040 = shen_hd(ctx, t3039);
  KLObject* t3041 = shen_tl(ctx, t3040);
  KLObject* t3042 = shen_tl(ctx, t3041);
  KLObject* t3043 = shen_cons_p(ctx, t3042);
  KLObject* t3037;
  if (!shen_is_boolean(ctx, t3043))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t3043)) {
    t3037 = t3043;
  } else {
  KLObject* t3045 = shen_empty_list(ctx);
  KLObject* t3047 = shen_hd(ctx, t3009);
  KLObject* t3048 = shen_hd(ctx, t3047);
  KLObject* t3049 = shen_tl(ctx, t3048);
  KLObject* t3050 = shen_tl(ctx, t3049);
  KLObject* t3051 = shen_tl(ctx, t3050);
  KLObject* t3052 = shen_eq(ctx, t3045, t3051);
  KLObject* t3044;
  if (!shen_is_boolean(ctx, t3052))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t3052)) {
    t3044 = t3052;
  } else {
  KLObject* t3055 = shen_hd(ctx, t3009);
  KLObject* t3056 = shen_tl(ctx, t3055);
  KLObject* t3057 = shen_cons_p(ctx, t3056);
  KLObject* t3053;
  if (!shen_is_boolean(ctx, t3057))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t3057)) {
    t3053 = t3057;
  } else {
  KLObject* t3059 = shen_empty_list(ctx);
  KLObject* t3061 = shen_hd(ctx, t3009);
  KLObject* t3062 = shen_tl(ctx, t3061);
  KLObject* t3063 = shen_tl(ctx, t3062);
  KLObject* t3064 = shen_eq(ctx, t3059, t3063);
  KLObject* t3058;
  if (!shen_is_boolean(ctx, t3064))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t3064)) {
    t3058 = t3064;
  } else {
  KLObject* t3067 = shen_hd(ctx, t3009);
  KLObject* t3068 = shen_hd(ctx, t3067);
  KLObject* t3069 = shen_tl(ctx, t3068);
  KLObject* t3070 = shen_hd(ctx, t3069);
  KLObject* t3071 = shen_eq(ctx, t3008, t3070);
    if (!shen_is_boolean(ctx, t3071))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t3058 = t3071;
  }
    if (!shen_is_boolean(ctx, t3058))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t3053 = t3058;
  }
    if (!shen_is_boolean(ctx, t3053))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t3044 = t3053;
  }
    if (!shen_is_boolean(ctx, t3044))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t3037 = t3044;
  }
    if (!shen_is_boolean(ctx, t3037))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t3031 = t3037;
  }
    if (!shen_is_boolean(ctx, t3031))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t3024 = t3031;
  }
    if (!shen_is_boolean(ctx, t3024))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t3019 = t3024;
  }
    if (!shen_is_boolean(ctx, t3019))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t3015 = t3019;
  }
    if (!shen_is_boolean(ctx, t3015))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t3012 = t3015;
  }
    if (!shen_is_boolean(ctx, t3012))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t3012)) {
  KLObject* t3073 = shen_hd(ctx, t3009);
  KLObject* t3074 = shen_hd(ctx, t3073);
  KLObject* t3075 = shen_tl(ctx, t3074);
  KLObject* t3076 = shen_hd(ctx, t3075);
  KLObject* t3078 = shen_tl(ctx, t3009);
  KLObject* t3080 = shen_hd(ctx, t3009);
  KLObject* t3081 = shen_hd(ctx, t3080);
  KLObject* t3082 = shen_tl(ctx, t3081);
  KLObject* t3083 = shen_tl(ctx, t3082);
  KLObject* t3084 = shen_hd(ctx, t3083);
  KLObject* t3086 = shen_hd(ctx, t3009);
  KLObject* t3087 = shen_tl(ctx, t3086);
  KLObject* t3088 = shen_cons(ctx, t3084, t3087);
  KLObject* t3090 = shen_cons(ctx, t3088, t3010);
  {
    KLObject* n3091_0 = t3076;
    KLObject* n3091_1 = t3078;
    KLObject* n3091_2 = t3090;
    t3008 = n3091_0;
    t3009 = n3091_1;
    t3010 = n3091_2;
    goto tail_start_kl_shen_2epivot_2don_56;
  }
  KLObject* t3091 = NULL;
      t3011 = t3091;
    } else {
  KLObject* t3094 = shen_cons_p(ctx, t3009);
  KLObject* t3092;
  if (!shen_is_boolean(ctx, t3094))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t3094)) {
    t3092 = t3094;
  } else {
  KLObject* t3097 = shen_hd(ctx, t3009);
  KLObject* t3098 = shen_cons_p(ctx, t3097);
  KLObject* t3095;
  if (!shen_is_boolean(ctx, t3098))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t3098)) {
    t3095 = t3098;
  } else {
  KLObject* t3101 = shen_hd(ctx, t3009);
  KLObject* t3102 = shen_tl(ctx, t3101);
  KLObject* t3103 = shen_cons_p(ctx, t3102);
  KLObject* t3099;
  if (!shen_is_boolean(ctx, t3103))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t3103)) {
    t3099 = t3103;
  } else {
  KLObject* t3105 = shen_empty_list(ctx);
  KLObject* t3107 = shen_hd(ctx, t3009);
  KLObject* t3108 = shen_tl(ctx, t3107);
  KLObject* t3109 = shen_tl(ctx, t3108);
  KLObject* t3110 = shen_eq(ctx, t3105, t3109);
  KLObject* t3104;
  if (!shen_is_boolean(ctx, t3110))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t3110)) {
    t3104 = t3110;
  } else {
  KLObject* t3113 = shen_hd(ctx, t3009);
  KLObject* t3114 = shen_hd(ctx, t3113);
  KLObject* t3115 = shen_eq(ctx, t3008, t3114);
    if (!shen_is_boolean(ctx, t3115))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t3104 = t3115;
  }
    if (!shen_is_boolean(ctx, t3104))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t3099 = t3104;
  }
    if (!shen_is_boolean(ctx, t3099))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t3095 = t3099;
  }
    if (!shen_is_boolean(ctx, t3095))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t3092 = t3095;
  }
    if (!shen_is_boolean(ctx, t3092))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t3092)) {
  KLObject* t3117 = shen_hd(ctx, t3009);
  KLObject* t3118 = shen_hd(ctx, t3117);
  KLObject* t3120 = shen_tl(ctx, t3009);
  KLObject* t3121 = shen_true(ctx);
  KLObject* t3123 = shen_hd(ctx, t3009);
  KLObject* t3124 = shen_tl(ctx, t3123);
  KLObject* t3125 = shen_cons(ctx, t3121, t3124);
  KLObject* t3127 = shen_cons(ctx, t3125, t3010);
  {
    KLObject* n3128_0 = t3118;
    KLObject* n3128_1 = t3120;
    KLObject* n3128_2 = t3127;
    t3008 = n3128_0;
    t3009 = n3128_1;
    t3010 = n3128_2;
    goto tail_start_kl_shen_2epivot_2don_56;
  }
  KLObject* t3128 = NULL;
      t3011 = t3128;
    } else {
  KLObject* t3129 = shen_true(ctx);
    if (!shen_is_boolean(ctx, t3129))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t3129)) {
  KLObject* t3130;
  {
    KLObject* a3130[] = {t3010, t3009};
    t3130 = shen_tail_apply_direct(ctx, "@p", 2, a3130);
  }
      t3011 = t3130;
    } else {
      shen_simple_error(ctx, "No true case found for cond");
      t3011 = shen_empty_list(ctx);
    }
    }
    }
  }
    return t3011;
  }
}

static KLObject* native_kl_shen_2efactor_2dselectors_57 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t3133 = objects[0];
    KLObject* t3134 = objects[1];
  tail_start_kl_shen_2efactor_2dselectors_57: ;
  KLObject* t3135;
  {
  KLObject* t3138 = shen_cons_p(ctx, t3133);
  KLObject* t3136;
  if (!shen_is_boolean(ctx, t3138))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t3138)) {
    t3136 = t3138;
  } else {
  KLObject* t3141 = shen_tl(ctx, t3133);
  KLObject* t3142 = shen_cons_p(ctx, t3141);
  KLObject* t3139;
  if (!shen_is_boolean(ctx, t3142))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t3142)) {
    t3139 = t3142;
  } else {
  KLObject* t3143 = shen_empty_list(ctx);
  KLObject* t3145 = shen_tl(ctx, t3133);
  KLObject* t3146 = shen_tl(ctx, t3145);
  KLObject* t3147 = shen_eq(ctx, t3143, t3146);
    if (!shen_is_boolean(ctx, t3147))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t3139 = t3147;
  }
    if (!shen_is_boolean(ctx, t3139))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t3136 = t3139;
  }
    if (!shen_is_boolean(ctx, t3136))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t3136)) {
  KLObject* t3150 = shen_hd(ctx, t3133);
  KLObject* t3148;
  {
    KLObject* a3148[] = {t3150};
    t3148 = shen_apply_direct(ctx, "shen.op", 1, a3148);
  }
  KLObject* t3152 = shen_intern(ctx, "shen.skip");
  KLObject* t3154 = shen_eq(ctx, t3152, t3148);
  KLObject* t3151;
  if (!shen_is_boolean(ctx, t3154))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t3154)) {
    t3151 = t3134;
  } else {
  KLObject* t3157;
  {
    KLObject* a3157[] = {t3148};
    t3157 = shen_apply_direct(ctx, "shen.op1", 1, a3157);
  }
  KLObject* t3160 = shen_tl(ctx, t3133);
  KLObject* t3161 = shen_cons(ctx, t3157, t3160);
  KLObject* t3162;
  {
    KLObject* a3162[] = {t3148};
    t3162 = shen_apply_direct(ctx, "shen.op2", 1, a3162);
  }
  KLObject* t3165 = shen_tl(ctx, t3133);
  KLObject* t3166 = shen_cons(ctx, t3162, t3165);
  KLObject* t3167 = shen_empty_list(ctx);
  KLObject* t3168 = shen_cons(ctx, t3166, t3167);
  KLObject* t3169 = shen_cons(ctx, t3161, t3168);
  KLObject* t3156;
  {
    KLObject* a3156[] = {t3169, t3134};
    t3156 = shen_tail_apply_direct(ctx, "shen.factor-selectors-h", 2, a3156);
  }
    t3151 = t3156;
  }
      t3135 = t3151;
    } else {
  KLObject* t3171 = shen_true(ctx);
    if (!shen_is_boolean(ctx, t3171))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t3171)) {
      t3135 = t3134;
    } else {
      shen_simple_error(ctx, "No true case found for cond");
      t3135 = shen_empty_list(ctx);
    }
    }
  }
    return t3135;
  }
}

static KLObject* native_kl_shen_2eop_58 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t3173 = objects[0];
  tail_start_kl_shen_2eop_58: ;
  KLObject* t3174;
  {
  KLObject* t3175 = shen_intern(ctx, "cons?");
  KLObject* t3177 = shen_eq(ctx, t3175, t3173);
    if (!shen_is_boolean(ctx, t3177))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t3177)) {
  KLObject* t3178 = shen_intern(ctx, "cons");
      t3174 = t3178;
    } else {
  KLObject* t3179 = shen_intern(ctx, "shen.+string?");
  KLObject* t3181 = shen_eq(ctx, t3179, t3173);
    if (!shen_is_boolean(ctx, t3181))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t3181)) {
  KLObject* t3182 = shen_intern(ctx, "@s");
      t3174 = t3182;
    } else {
  KLObject* t3183 = shen_intern(ctx, "shen.+vector?");
  KLObject* t3185 = shen_eq(ctx, t3183, t3173);
    if (!shen_is_boolean(ctx, t3185))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t3185)) {
  KLObject* t3186 = shen_intern(ctx, "@v");
      t3174 = t3186;
    } else {
  KLObject* t3187 = shen_intern(ctx, "tuple?");
  KLObject* t3189 = shen_eq(ctx, t3187, t3173);
    if (!shen_is_boolean(ctx, t3189))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t3189)) {
  KLObject* t3190 = shen_intern(ctx, "@p");
      t3174 = t3190;
    } else {
  KLObject* t3191 = shen_true(ctx);
    if (!shen_is_boolean(ctx, t3191))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t3191)) {
  KLObject* t3192 = shen_intern(ctx, "shen.skip");
      t3174 = t3192;
    } else {
      shen_simple_error(ctx, "No true case found for cond");
      t3174 = shen_empty_list(ctx);
    }
    }
    }
    }
    }
  }
    return t3174;
  }
}

static KLObject* native_kl_shen_2efactor_2dselectors_2dh_59 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t3193 = objects[0];
    KLObject* t3194 = objects[1];
  tail_start_kl_shen_2efactor_2dselectors_2dh_59: ;
  KLObject* t3195;
  {
  KLObject* t3196 = shen_empty_list(ctx);
  KLObject* t3198 = shen_eq(ctx, t3196, t3193);
    if (!shen_is_boolean(ctx, t3198))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t3198)) {
      t3195 = t3194;
    } else {
  KLObject* t3201 = shen_cons_p(ctx, t3193);
    if (!shen_is_boolean(ctx, t3201))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t3201)) {
  KLObject* t3205 = shen_hd(ctx, t3193);
  KLObject* t3203;
  {
    KLObject* a3203[] = {t3205, t3194};
    t3203 = shen_apply_direct(ctx, "occurrences", 2, a3203);
  }
  KLObject* t3207 = shen_number_l(ctx, 1);
  KLObject* t3208 = shen_gt(ctx, t3203, t3207);
  KLObject* t3202;
  if (!shen_is_boolean(ctx, t3208))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t3208)) {
  KLObject* t3210 = shen_intern(ctx, "Select");
  KLObject* t3209;
  {
    KLObject* a3209[] = {t3210};
    t3209 = shen_apply_direct(ctx, "gensym", 1, a3209);
  }
  KLObject* t3211 = shen_intern(ctx, "let");
  KLObject* t3214 = shen_hd(ctx, t3193);
  KLObject* t3217 = shen_tl(ctx, t3193);
  KLObject* t3221 = shen_hd(ctx, t3193);
  KLObject* t3218;
  {
    KLObject* a3218[] = {t3209, t3221, t3194};
    t3218 = shen_apply_direct(ctx, "subst", 3, a3218);
  }
  KLObject* t3215;
  {
    KLObject* a3215[] = {t3217, t3218};
    t3215 = shen_apply_direct(ctx, "shen.factor-selectors-h", 2, a3215);
  }
  KLObject* t3223 = shen_empty_list(ctx);
  KLObject* t3224 = shen_cons(ctx, t3215, t3223);
  KLObject* t3225 = shen_cons(ctx, t3214, t3224);
  KLObject* t3226 = shen_cons(ctx, t3209, t3225);
  KLObject* t3227 = shen_cons(ctx, t3211, t3226);
    t3202 = t3227;
  } else {
  KLObject* t3229 = shen_tl(ctx, t3193);
  {
    KLObject* n3231_0 = t3229;
    KLObject* n3231_1 = t3194;
    t3193 = n3231_0;
    t3194 = n3231_1;
    goto tail_start_kl_shen_2efactor_2dselectors_2dh_59;
  }
  KLObject* t3231 = NULL;
    t3202 = t3231;
  }
      t3195 = t3202;
    } else {
  KLObject* t3232 = shen_true(ctx);
    if (!shen_is_boolean(ctx, t3232))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t3232)) {
  KLObject* t3234 = shen_string(ctx, "partial function shen.factor-selectors-h");
  KLObject* t3233;
  {
    KLObject* a3233[] = {t3234};
    t3233 = shen_tail_apply_direct(ctx, "simple-error", 1, a3233);
  }
      t3195 = t3233;
    } else {
      shen_simple_error(ctx, "No true case found for cond");
      t3195 = shen_empty_list(ctx);
    }
    }
    }
  }
    return t3195;
  }
}

void shen_kernel_aot_install_core (shen_context* ctx)
{
  shen_register_defun(ctx, "shen.shen->kl", 1, &native_kl_shen_2eshen_2d_3ekl_0);
  shen_register_defun(ctx, "shen.record-and-evaluate", 1, &native_kl_shen_2erecord_2dand_2devaluate_1);
  shen_register_defun(ctx, "shen.shen->kl-h", 1, &native_kl_shen_2eshen_2d_3ekl_2dh_2);
  shen_register_defun(ctx, "shen.shendef->kldef", 2, &native_kl_shen_2eshendef_2d_3ekldef_3);
  shen_register_defun(ctx, "shen.<define>", 1, &native_kl_shen_2e_3cdefine_3e_4);
  shen_register_defun(ctx, "shen.shendef->kldef-h", 2, &native_kl_shen_2eshendef_2d_3ekldef_2dh_5);
  shen_register_defun(ctx, "shen.unprotect", 1, &native_kl_shen_2eunprotect_6);
  shen_register_defun(ctx, "shen.<name>", 1, &native_kl_shen_2e_3cname_3e_7);
  shen_register_defun(ctx, "shen.<signature>", 1, &native_kl_shen_2e_3csignature_3e_8);
  shen_register_defun(ctx, "shen.<rules>", 1, &native_kl_shen_2e_3crules_3e_9);
  shen_register_defun(ctx, "shen.linearise", 1, &native_kl_shen_2elinearise_10);
  shen_register_defun(ctx, "shen.linearise-h", 4, &native_kl_shen_2elinearise_2dh_11);
  shen_register_defun(ctx, "shen.<rule>", 1, &native_kl_shen_2e_3crule_3e_12);
  shen_register_defun(ctx, "shen.<patterns>", 1, &native_kl_shen_2e_3cpatterns_3e_13);
  shen_register_defun(ctx, "shen.<pattern>", 1, &native_kl_shen_2e_3cpattern_3e_14);
  shen_register_defun(ctx, "shen.<constructor>", 1, &native_kl_shen_2e_3cconstructor_3e_15);
  shen_register_defun(ctx, "shen.constructor?", 1, &native_kl_shen_2econstructor_3f_16);
  shen_register_defun(ctx, "shen.constructor-error", 1, &native_kl_shen_2econstructor_2derror_17);
  shen_register_defun(ctx, "shen.<simple-pattern>", 1, &native_kl_shen_2e_3csimple_2dpattern_3e_18);
  shen_register_defun(ctx, "shen.<pattern1>", 1, &native_kl_shen_2e_3cpattern1_3e_19);
  shen_register_defun(ctx, "shen.<pattern2>", 1, &native_kl_shen_2e_3cpattern2_3e_20);
  shen_register_defun(ctx, "shen.fn-print", 1, &native_kl_shen_2efn_2dprint_21);
  shen_register_defun(ctx, "shen.printF", 1, &native_kl_shen_2eprintF_22);
  shen_register_defun(ctx, "shen.arity-chk", 2, &native_kl_shen_2earity_2dchk_23);
  shen_register_defun(ctx, "shen.free-var-chk", 2, &native_kl_shen_2efree_2dvar_2dchk_24);
  shen_register_defun(ctx, "shen.free-variable-error-message", 2, &native_kl_shen_2efree_2dvariable_2derror_2dmessage_25);
  shen_register_defun(ctx, "shen.extract-vars", 1, &native_kl_shen_2eextract_2dvars_26);
  shen_register_defun(ctx, "shen.find-free-vars", 2, &native_kl_shen_2efind_2dfree_2dvars_27);
  shen_register_defun(ctx, "shen.free-variable?", 2, &native_kl_shen_2efree_2dvariable_3f_28);
  shen_register_defun(ctx, "shen.record-kl", 2, &native_kl_shen_2erecord_2dkl_29);
  shen_register_defun(ctx, "shen.compile-to-kl", 3, &native_kl_shen_2ecompile_2dto_2dkl_30);
  shen_register_defun(ctx, "shen.parameters", 1, &native_kl_shen_2eparameters_31);
  shen_register_defun(ctx, "shen.cond-form", 1, &native_kl_shen_2econd_2dform_32);
  shen_register_defun(ctx, "shen.scan-body", 2, &native_kl_shen_2escan_2dbody_33);
  shen_register_defun(ctx, "shen.choicepoint?", 1, &native_kl_shen_2echoicepoint_3f_34);
  shen_register_defun(ctx, "shen.choicepoint", 5, &native_kl_shen_2echoicepoint_35);
  shen_register_defun(ctx, "shen.rep-X", 3, &native_kl_shen_2erep_2dX_36);
  shen_register_defun(ctx, "shen.kl-body", 2, &native_kl_shen_2ekl_2dbody_37);
  shen_register_defun(ctx, "shen.alpha-convert", 1, &native_kl_shen_2ealpha_2dconvert_38);
  shen_register_defun(ctx, "shen.triple-stack", 4, &native_kl_shen_2etriple_2dstack_39);
  shen_register_defun(ctx, "shen.rectify-test", 1, &native_kl_shen_2erectify_2dtest_40);
  shen_register_defun(ctx, "shen.beta", 3, &native_kl_shen_2ebeta_41);
  shen_register_defun(ctx, "shen.op1", 1, &native_kl_shen_2eop1_42);
  shen_register_defun(ctx, "shen.op2", 1, &native_kl_shen_2eop2_43);
  shen_register_defun(ctx, "shen.op-test", 1, &native_kl_shen_2eop_2dtest_44);
  shen_register_defun(ctx, "shen.+string?", 1, &native_kl_shen_2e_2bstring_3f_45);
  shen_register_defun(ctx, "shen.+vector?", 1, &native_kl_shen_2e_2bvector_3f_46);
  shen_register_defun(ctx, "factorise", 1, &native_kl_factorise_47);
  shen_register_defun(ctx, "shen.factorise-code", 1, &native_kl_shen_2efactorise_2dcode_48);
  shen_register_defun(ctx, "shen.factor", 1, &native_kl_shen_2efactor_49);
  shen_register_defun(ctx, "shen.factor-recognisors", 1, &native_kl_shen_2efactor_2drecognisors_50);
  shen_register_defun(ctx, "shen.recursively-factor-selectors", 2, &native_kl_shen_2erecursively_2dfactor_2dselectors_51);
  shen_register_defun(ctx, "shen.restore-P", 2, &native_kl_shen_2erestore_2dP_52);
  shen_register_defun(ctx, "shen.restore-local", 3, &native_kl_shen_2erestore_2dlocal_53);
  shen_register_defun(ctx, "shen.bad-pivot?", 1, &native_kl_shen_2ebad_2dpivot_3f_54);
  shen_register_defun(ctx, "shen.remove-indirection", 1, &native_kl_shen_2eremove_2dindirection_55);
  shen_register_defun(ctx, "shen.pivot-on", 3, &native_kl_shen_2epivot_2don_56);
  shen_register_defun(ctx, "shen.factor-selectors", 2, &native_kl_shen_2efactor_2dselectors_57);
  shen_register_defun(ctx, "shen.op", 1, &native_kl_shen_2eop_58);
  shen_register_defun(ctx, "shen.factor-selectors-h", 2, &native_kl_shen_2efactor_2dselectors_2dh_59);
}
