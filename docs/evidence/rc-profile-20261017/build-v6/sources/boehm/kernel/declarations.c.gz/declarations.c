#include "rc_phase_profile.h"
/* Generated always-AOT kernel module (KL defuns -> NativeFunctions).
 * Install after tree-walker boot overwrites UserFunctions.
 * Toplevel declare/set stay on the walker. Not overlay-after-load.
 * Sidecar tests stay on the tree-walker. Not a second main. Source: declarations.kl
 */
#include "abi.h"

void shen_kernel_aot_install_declarations (shen_context* ctx);

static KLObject* lambda_0 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t2 = objects[0];
  KLObject* t3;
  {
    KLObject* a3[] = {t2};
    t3 = shen_tail_apply_direct(ctx, "shen.typename", 1, a3);
  }
    return t3;
  }
}

static KLObject* lambda_1 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t9 = objects[0];
  KLObject* t10;
  {
    KLObject* a10[] = {t9};
    t10 = shen_tail_apply_direct(ctx, "shen.typename", 1, a10);
  }
    return t10;
  }
}

static KLObject* trap_body_0 (void* data)
{
  shen_context* ctx = &shen_root_context;
  Vector* env = (Vector*)data;
  KLObject* t88 = shen_vector_get(ctx, env, 0);
  KLObject* t91 = shen_intern(ctx, "arity");
  KLObject* t93 = shen_intern(ctx, "*property-vector*");
  KLObject* t92;
  {
    KLObject* a92[] = {t93};
    t92 = shen_apply_direct(ctx, "value", 1, a92);
  }
  KLObject* t89;
  {
    KLObject* a89[] = {t88, t91, t92};
    t89 = shen_apply_direct(ctx, "get", 3, a89);
  }
  return t89;
}

static KLObject* lambda_2 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t96 = objects[0];
  KLObject* t97 = shen_number_l(ctx, -1);
    return t97;
  }
}

static KLObject* trap_handler_0 (KLObject* exception, void* data)
{
  shen_context* ctx = &shen_root_context;
  Vector* env = (Vector*)data;
  Vector* args;
  KLObject* t94 = shen_vector_get(ctx, env, 0);
  KLObject* t95;
  {
    Vector* caps_2 = shen_vector(ctx, 0);
    t95 = shen_native_closure(ctx, 1, &lambda_2, caps_2);
  }
  args = shen_vector(ctx, 1);
  shen_vector_set(ctx, args, 0, exception);
  {
    KLObject* t98 = shen_apply(ctx, t95, args);
    return t98;
  }
}

static KLObject* lambda_3 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t176 = objects[0];
  KLObject* t177;
  {
    KLObject* a177[] = {t176};
    t177 = shen_tail_apply_direct(ctx, "shen.lambda-entry", 1, a177);
  }
    return t177;
  }
}

static KLObject* lambda_4 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t184 = objects[0];
  KLObject* t185;
  {
    KLObject* a185[] = {t184};
    t185 = shen_tail_apply_direct(ctx, "shen.tuple", 1, a185);
  }
    return t185;
  }
}

static KLObject* lambda_5 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t190 = objects[0];
  KLObject* t191;
  {
    KLObject* a191[] = {t190};
    t191 = shen_tail_apply_direct(ctx, "shen.pvar", 1, a191);
  }
    return t191;
  }
}

static KLObject* lambda_6 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t196 = objects[0];
  KLObject* t197;
  {
    KLObject* a197[] = {t196};
    t197 = shen_tail_apply_direct(ctx, "shen.print-prolog-vector", 1, a197);
  }
    return t197;
  }
}

static KLObject* lambda_7 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t202 = objects[0];
  KLObject* t203;
  {
    KLObject* a203[] = {t202};
    t203 = shen_tail_apply_direct(ctx, "shen.print-freshterm", 1, a203);
  }
    return t203;
  }
}

static KLObject* lambda_8 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t208 = objects[0];
  KLObject* t209;
  {
    KLObject* a209[] = {t208};
    t209 = shen_tail_apply_direct(ctx, "shen.printF", 1, a209);
  }
    return t209;
  }
}

static KLObject* native_kl_datatypes_0 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  (void)function_object;
  (void)arguments;
  {
  tail_start_kl_datatypes_0: ;
  KLObject* t1;
  {
    Vector* caps_0 = shen_vector(ctx, 0);
    t1 = shen_native_closure(ctx, 1, &lambda_0, caps_0);
  }
  KLObject* t6 = shen_intern(ctx, "shen.*alldatatypes*");
  KLObject* t5;
  {
    KLObject* a5[] = {t6};
    t5 = shen_apply_direct(ctx, "value", 1, a5);
  }
  KLObject* t0;
  {
    KLObject* a0[] = {t1, t5};
    t0 = shen_tail_apply_direct(ctx, "map", 2, a0);
  }
    return t0;
  }
}

static KLObject* native_kl_included_1 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  (void)function_object;
  (void)arguments;
  {
  tail_start_kl_included_1: ;
  KLObject* t8;
  {
    Vector* caps_1 = shen_vector(ctx, 0);
    t8 = shen_native_closure(ctx, 1, &lambda_1, caps_1);
  }
  KLObject* t13 = shen_intern(ctx, "shen.*datatypes*");
  KLObject* t12;
  {
    KLObject* a12[] = {t13};
    t12 = shen_apply_direct(ctx, "value", 1, a12);
  }
  KLObject* t7;
  {
    KLObject* a7[] = {t8, t12};
    t7 = shen_tail_apply_direct(ctx, "map", 2, a7);
  }
    return t7;
  }
}

static KLObject* native_kl_shen_2etypename_2 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t14 = objects[0];
  tail_start_kl_shen_2etypename_2: ;
  KLObject* t15;
  {
  KLObject* t17 = shen_cons_p(ctx, t14);
    if (!shen_is_boolean(ctx, t17))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t17)) {
  KLObject* t22 = shen_hd(ctx, t14);
  KLObject* t20;
  {
    KLObject* a20[] = {t22};
    t20 = shen_apply_direct(ctx, "str", 1, a20);
  }
  KLObject* t19;
  {
    KLObject* a19[] = {t20};
    t19 = shen_apply_direct(ctx, "shen.typename-h", 1, a19);
  }
  KLObject* t18;
  {
    KLObject* a18[] = {t19};
    t18 = shen_tail_apply_direct(ctx, "intern", 1, a18);
  }
      t15 = t18;
    } else {
  KLObject* t23 = shen_true(ctx);
    if (!shen_is_boolean(ctx, t23))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t23)) {
  KLObject* t25 = shen_string(ctx, "partial function shen.typename");
  KLObject* t24;
  {
    KLObject* a24[] = {t25};
    t24 = shen_tail_apply_direct(ctx, "simple-error", 1, a24);
  }
      t15 = t24;
    } else {
      shen_simple_error(ctx, "No true case found for cond");
      t15 = shen_empty_list(ctx);
    }
    }
  }
    return t15;
  }
}

static KLObject* native_kl_shen_2etypename_2dh_3 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t26 = objects[0];
  tail_start_kl_shen_2etypename_2dh_3: ;
  KLObject* t27;
  {
  KLObject* t28 = shen_string(ctx, "#type");
  KLObject* t30 = shen_eq(ctx, t28, t26);
    if (!shen_is_boolean(ctx, t30))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t30)) {
  KLObject* t31 = shen_string(ctx, "");
      t27 = t31;
    } else {
  KLObject* t32;
  {
    KLObject* a32[] = {t26};
    t32 = shen_apply_direct(ctx, "shen.+string?", 1, a32);
  }
    if (!shen_is_boolean(ctx, t32))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t32)) {
  KLObject* t35;
  {
    KLObject* a35[] = {t26};
    t35 = shen_apply_direct(ctx, "hdstr", 1, a35);
  }
  KLObject* t38;
  {
    KLObject* a38[] = {t26};
    t38 = shen_apply_direct(ctx, "tlstr", 1, a38);
  }
  KLObject* t37;
  {
    KLObject* a37[] = {t38};
    t37 = shen_apply_direct(ctx, "shen.typename-h", 1, a37);
  }
  KLObject* t34;
  {
    KLObject* a34[] = {t35, t37};
    t34 = shen_tail_apply_direct(ctx, "cn", 2, a34);
  }
      t27 = t34;
    } else {
  KLObject* t40 = shen_true(ctx);
    if (!shen_is_boolean(ctx, t40))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t40)) {
  KLObject* t42 = shen_string(ctx, "partial function shen.typename-h");
  KLObject* t41;
  {
    KLObject* a41[] = {t42};
    t41 = shen_tail_apply_direct(ctx, "simple-error", 1, a41);
  }
      t27 = t41;
    } else {
      shen_simple_error(ctx, "No true case found for cond");
      t27 = shen_empty_list(ctx);
    }
    }
    }
  }
    return t27;
  }
}

static KLObject* native_kl_prolog_2dmemory_4 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t43 = objects[0];
  tail_start_kl_prolog_2dmemory_4: ;
  KLObject* t46 = shen_number_l(ctx, 0);
  KLObject* t47 = shen_lt(ctx, t43, t46);
  KLObject* t44;
  if (!shen_is_boolean(ctx, t47))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t47)) {
  KLObject* t49 = shen_intern(ctx, "shen.*prolog-memory*");
  KLObject* t48;
  {
    KLObject* a48[] = {t49};
    t48 = shen_tail_apply_direct(ctx, "value", 1, a48);
  }
    t44 = t48;
  } else {
  KLObject* t51;
  {
    KLObject* a51[] = {t43};
    t51 = shen_apply_direct(ctx, "integer?", 1, a51);
  }
  KLObject* t50;
  if (!shen_is_boolean(ctx, t51))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t51)) {
  KLObject* t54 = shen_intern(ctx, "shen.*prolog-memory*");
  KLObject* t53;
  {
    KLObject* a53[] = {t54, t43};
    t53 = shen_tail_apply_direct(ctx, "set", 2, a53);
  }
    t50 = t53;
  } else {
  KLObject* t57 = shen_string(ctx, "prolog memory expects an integer value\n");
  KLObject* t56;
  {
    KLObject* a56[] = {t57};
    t56 = shen_tail_apply_direct(ctx, "simple-error", 1, a56);
  }
    t50 = t56;
  }
    t44 = t50;
  }
    return t44;
  }
}

static KLObject* native_kl_shen_2einitialise_2dlambda_2dtables_5 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t58 = objects[0];
  tail_start_kl_shen_2einitialise_2dlambda_2dtables_5: ;
  KLObject* t59;
  {
  KLObject* t60 = shen_empty_list(ctx);
  KLObject* t62 = shen_eq(ctx, t60, t58);
    if (!shen_is_boolean(ctx, t62))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t62)) {
  KLObject* t63 = shen_empty_list(ctx);
      t59 = t63;
    } else {
  KLObject* t66 = shen_cons_p(ctx, t58);
  KLObject* t64;
  if (!shen_is_boolean(ctx, t66))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t66)) {
    t64 = t66;
  } else {
  KLObject* t68 = shen_tl(ctx, t58);
  KLObject* t69 = shen_cons_p(ctx, t68);
    if (!shen_is_boolean(ctx, t69))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t64 = t69;
  }
    if (!shen_is_boolean(ctx, t64))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t64)) {
  KLObject* t72 = shen_hd(ctx, t58);
  KLObject* t73 = shen_intern(ctx, "arity");
  KLObject* t75 = shen_tl(ctx, t58);
  KLObject* t76 = shen_hd(ctx, t75);
  KLObject* t78 = shen_intern(ctx, "*property-vector*");
  KLObject* t77;
  {
    KLObject* a77[] = {t78};
    t77 = shen_apply_direct(ctx, "value", 1, a77);
  }
  KLObject* t70;
  {
    KLObject* a70[] = {t72, t73, t76, t77};
    t70 = shen_apply_direct(ctx, "put", 4, a70);
  }
  KLObject* t81 = shen_tl(ctx, t58);
  KLObject* t82 = shen_tl(ctx, t81);
  KLObject* t79;
  {
    KLObject* a79[] = {t82};
    t79 = shen_tail_apply_direct(ctx, "shen.initialise-arity-table", 1, a79);
  }
      t59 = t79;
    } else {
  KLObject* t83 = shen_true(ctx);
    if (!shen_is_boolean(ctx, t83))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t83)) {
  KLObject* t85 = shen_string(ctx, "implementation error in shen.initialise-arity-table");
  KLObject* t84;
  {
    KLObject* a84[] = {t85};
    t84 = shen_tail_apply_direct(ctx, "simple-error", 1, a84);
  }
      t59 = t84;
    } else {
      shen_simple_error(ctx, "No true case found for cond");
      t59 = shen_empty_list(ctx);
    }
    }
    }
  }
    return t59;
  }
}

static KLObject* native_kl_arity_6 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t86 = objects[0];
  tail_start_kl_arity_6: ;
  KLObject* t87;
  {
    Vector* tenv_0 = shen_vector(ctx, 1);
    shen_vector_set(ctx, tenv_0, 0, t86);
    t87 = shen_trap_error(ctx, trap_body_0, trap_handler_0, tenv_0);
  }
    return t87;
  }
}

static KLObject* native_kl_shen_2einitialise_2darity_2dtable_7 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t99 = objects[0];
  tail_start_kl_shen_2einitialise_2darity_2dtable_7: ;
  KLObject* t100;
  {
  KLObject* t101 = shen_empty_list(ctx);
  KLObject* t103 = shen_eq(ctx, t101, t99);
    if (!shen_is_boolean(ctx, t103))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t103)) {
  KLObject* t104 = shen_empty_list(ctx);
      t100 = t104;
    } else {
  KLObject* t107 = shen_cons_p(ctx, t99);
  KLObject* t105;
  if (!shen_is_boolean(ctx, t107))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t107)) {
    t105 = t107;
  } else {
  KLObject* t109 = shen_tl(ctx, t99);
  KLObject* t110 = shen_cons_p(ctx, t109);
    if (!shen_is_boolean(ctx, t110))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t105 = t110;
  }
    if (!shen_is_boolean(ctx, t105))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t105)) {
  KLObject* t113 = shen_hd(ctx, t99);
  KLObject* t114 = shen_intern(ctx, "arity");
  KLObject* t116 = shen_tl(ctx, t99);
  KLObject* t117 = shen_hd(ctx, t116);
  KLObject* t119 = shen_intern(ctx, "*property-vector*");
  KLObject* t118;
  {
    KLObject* a118[] = {t119};
    t118 = shen_apply_direct(ctx, "value", 1, a118);
  }
  KLObject* t111;
  {
    KLObject* a111[] = {t113, t114, t117, t118};
    t111 = shen_apply_direct(ctx, "put", 4, a111);
  }
  KLObject* t121 = shen_tl(ctx, t99);
  KLObject* t122 = shen_tl(ctx, t121);
  {
    KLObject* n123_0 = t122;
    t99 = n123_0;
    goto tail_start_kl_shen_2einitialise_2darity_2dtable_7;
  }
  KLObject* t123 = NULL;
      t100 = t123;
    } else {
  KLObject* t124 = shen_true(ctx);
    if (!shen_is_boolean(ctx, t124))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t124)) {
  KLObject* t126 = shen_string(ctx, "implementation error in shen.initialise-arity-table");
  KLObject* t125;
  {
    KLObject* a125[] = {t126};
    t125 = shen_tail_apply_direct(ctx, "simple-error", 1, a125);
  }
      t100 = t125;
    } else {
      shen_simple_error(ctx, "No true case found for cond");
      t100 = shen_empty_list(ctx);
    }
    }
    }
  }
    return t100;
  }
}

static KLObject* native_kl_systemf_8 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t127 = objects[0];
  tail_start_kl_systemf_8: ;
  KLObject* t129 = shen_intern(ctx, "shen");
  KLObject* t130 = shen_intern(ctx, "shen.external-symbols");
  KLObject* t132 = shen_intern(ctx, "*property-vector*");
  KLObject* t131;
  {
    KLObject* a131[] = {t132};
    t131 = shen_apply_direct(ctx, "value", 1, a131);
  }
  KLObject* t128;
  {
    KLObject* a128[] = {t129, t130, t131};
    t128 = shen_apply_direct(ctx, "get", 3, a128);
  }
  KLObject* t134 = shen_intern(ctx, "shen");
  KLObject* t135 = shen_intern(ctx, "shen.external-symbols");
  KLObject* t136;
  {
    KLObject* a136[] = {t127, t128};
    t136 = shen_apply_direct(ctx, "adjoin", 2, a136);
  }
  KLObject* t140 = shen_intern(ctx, "*property-vector*");
  KLObject* t139;
  {
    KLObject* a139[] = {t140};
    t139 = shen_apply_direct(ctx, "value", 1, a139);
  }
  KLObject* t133;
  {
    KLObject* a133[] = {t134, t135, t136, t139};
    t133 = shen_apply_direct(ctx, "put", 4, a133);
  }
    return t127;
  }
}

static KLObject* native_kl_adjoin_9 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t142 = objects[0];
    KLObject* t143 = objects[1];
  tail_start_kl_adjoin_9: ;
  KLObject* t145;
  {
    KLObject* a145[] = {t142, t143};
    t145 = shen_apply_direct(ctx, "element?", 2, a145);
  }
  KLObject* t144;
  if (!shen_is_boolean(ctx, t145))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t145)) {
    t144 = t143;
  } else {
  KLObject* t151 = shen_cons(ctx, t142, t143);
    t144 = t151;
  }
    return t144;
  }
}

static KLObject* native_kl_shen_2elambda_2dentry_10 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t152 = objects[0];
  tail_start_kl_shen_2elambda_2dentry_10: ;
    if (t152 == NULL || get_kl_object_type(t152) != KL_TYPE_SYMBOL) {
      KLObject* t153 = shen_empty_list(ctx);
      return t153;
    }
  KLObject* t154;
  {
    KLObject* a154[] = {t152};
    t154 = shen_apply_direct(ctx, "arity", 1, a154);
  }
  KLObject* t159 = shen_number_l(ctx, -1);
  KLObject* t160 = shen_eq(ctx, t154, t159);
  KLObject* t157;
  if (!shen_is_boolean(ctx, t160))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (shen_boolean_value(ctx, t160)) {
    t157 = t160;
  } else {
  KLObject* t162 = shen_number_l(ctx, 0);
  KLObject* t163 = shen_eq(ctx, t154, t162);
    if (!shen_is_boolean(ctx, t163))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t157 = t163;
  }
  KLObject* t156;
  if (!shen_is_boolean(ctx, t157))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t157)) {
  KLObject* t164 = shen_empty_list(ctx);
    t156 = t164;
  } else {
  KLObject* t168 = shen_empty_list(ctx);
  KLObject* t169 = shen_cons(ctx, t152, t168);
  KLObject* t166;
  {
    KLObject* a166[] = {t169, t154};
    t166 = shen_apply_direct(ctx, "shen.lambda-function", 2, a166);
  }
  KLObject* t171 = shen_eval_kl(ctx, t166);
  KLObject* t172 = shen_cons(ctx, t152, t171);
    t156 = t172;
  }
    return t156;
  }
}

static KLObject* native_kl_shen_2ebuild_2dlambda_2dtable_11 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t173 = objects[0];
  tail_start_kl_shen_2ebuild_2dlambda_2dtable_11: ;
  KLObject* t175;
  {
    Vector* caps_3 = shen_vector(ctx, 0);
    t175 = shen_native_closure(ctx, 1, &lambda_3, caps_3);
  }
  KLObject* t174;
  {
    KLObject* a174[] = {t175, t173};
    t174 = shen_apply_direct(ctx, "map", 2, a174);
  }
  KLObject* t181 = shen_intern(ctx, "shen.*lambdatable*");
  KLObject* t182 = shen_intern(ctx, "shen.tuple");
  KLObject* t183;
  {
    Vector* caps_4 = shen_vector(ctx, 0);
    t183 = shen_native_closure(ctx, 1, &lambda_4, caps_4);
  }
  KLObject* t187 = shen_cons(ctx, t182, t183);
  KLObject* t188 = shen_intern(ctx, "shen.pvar");
  KLObject* t189;
  {
    Vector* caps_5 = shen_vector(ctx, 0);
    t189 = shen_native_closure(ctx, 1, &lambda_5, caps_5);
  }
  KLObject* t193 = shen_cons(ctx, t188, t189);
  KLObject* t194 = shen_intern(ctx, "shen.print-prolog-vector");
  KLObject* t195;
  {
    Vector* caps_6 = shen_vector(ctx, 0);
    t195 = shen_native_closure(ctx, 1, &lambda_6, caps_6);
  }
  KLObject* t199 = shen_cons(ctx, t194, t195);
  KLObject* t200 = shen_intern(ctx, "shen.print-freshterm");
  KLObject* t201;
  {
    Vector* caps_7 = shen_vector(ctx, 0);
    t201 = shen_native_closure(ctx, 1, &lambda_7, caps_7);
  }
  KLObject* t205 = shen_cons(ctx, t200, t201);
  KLObject* t206 = shen_intern(ctx, "shen.printF");
  KLObject* t207;
  {
    Vector* caps_8 = shen_vector(ctx, 0);
    t207 = shen_native_closure(ctx, 1, &lambda_8, caps_8);
  }
  KLObject* t211 = shen_cons(ctx, t206, t207);
  KLObject* t213 = shen_cons(ctx, t211, t174);
  KLObject* t214 = shen_cons(ctx, t205, t213);
  KLObject* t215 = shen_cons(ctx, t199, t214);
  KLObject* t216 = shen_cons(ctx, t193, t215);
  KLObject* t217 = shen_cons(ctx, t187, t216);
  KLObject* t180;
  {
    KLObject* a180[] = {t181, t217};
    t180 = shen_tail_apply_direct(ctx, "set", 2, a180);
  }
    return t180;
  }
}

void shen_kernel_aot_install_declarations (shen_context* ctx)
{
  shen_register_defun(ctx, "datatypes", 0, &native_kl_datatypes_0);
  shen_register_defun(ctx, "included", 0, &native_kl_included_1);
  shen_register_defun(ctx, "shen.typename", 1, &native_kl_shen_2etypename_2);
  shen_register_defun(ctx, "shen.typename-h", 1, &native_kl_shen_2etypename_2dh_3);
  shen_register_defun(ctx, "prolog-memory", 1, &native_kl_prolog_2dmemory_4);
  shen_register_defun(ctx, "shen.initialise-lambda-tables", 1, &native_kl_shen_2einitialise_2dlambda_2dtables_5);
  shen_register_defun(ctx, "arity", 1, &native_kl_arity_6);
  shen_register_defun(ctx, "shen.initialise-arity-table", 1, &native_kl_shen_2einitialise_2darity_2dtable_7);
  shen_register_defun(ctx, "systemf", 1, &native_kl_systemf_8);
  shen_register_defun(ctx, "adjoin", 2, &native_kl_adjoin_9);
  shen_register_defun(ctx, "shen.lambda-entry", 1, &native_kl_shen_2elambda_2dentry_10);
  shen_register_defun(ctx, "shen.build-lambda-table", 1, &native_kl_shen_2ebuild_2dlambda_2dtable_11);
}
