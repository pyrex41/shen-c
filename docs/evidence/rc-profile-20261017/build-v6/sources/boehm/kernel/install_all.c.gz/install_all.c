#include "rc_phase_profile.h"
/* Generated always-AOT kernel install_all (rust analog).
 * Call after load_shen_kl_files. Not overlay-after-load.
 * Sidecar tests stay on the tree-walker.
 */
#include "abi.h"

void shen_kernel_aot_install_sys (shen_context* ctx);
void shen_kernel_aot_install_writer (shen_context* ctx);
void shen_kernel_aot_install_core (shen_context* ctx);
void shen_kernel_aot_install_reader (shen_context* ctx);
void shen_kernel_aot_install_declarations (shen_context* ctx);
void shen_kernel_aot_install_toplevel (shen_context* ctx);
void shen_kernel_aot_install_macros (shen_context* ctx);
void shen_kernel_aot_install_load (shen_context* ctx);
void shen_kernel_aot_install_prolog (shen_context* ctx);
void shen_kernel_aot_install_sequent (shen_context* ctx);
void shen_kernel_aot_install_track (shen_context* ctx);
void shen_kernel_aot_install_t_star (shen_context* ctx);
void shen_kernel_aot_install_yacc (shen_context* ctx);
void shen_kernel_aot_install_types (shen_context* ctx);

void shen_kernel_aot_install_all (void)
{
  shen_context* ctx = &shen_root_context;
  shen_kernel_aot_install_sys(ctx);
  shen_kernel_aot_install_writer(ctx);
  shen_kernel_aot_install_core(ctx);
  shen_kernel_aot_install_reader(ctx);
  shen_kernel_aot_install_declarations(ctx);
  shen_kernel_aot_install_toplevel(ctx);
  shen_kernel_aot_install_macros(ctx);
  shen_kernel_aot_install_load(ctx);
  shen_kernel_aot_install_prolog(ctx);
  shen_kernel_aot_install_sequent(ctx);
  shen_kernel_aot_install_track(ctx);
  shen_kernel_aot_install_t_star(ctx);
  shen_kernel_aot_install_yacc(ctx);
  shen_kernel_aot_install_types(ctx);
}
