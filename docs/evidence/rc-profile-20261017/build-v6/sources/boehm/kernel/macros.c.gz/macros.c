#include "rc_phase_profile.h"
/* Generated always-AOT kernel module (KL defuns -> NativeFunctions).
 * Install after tree-walker boot overwrites UserFunctions.
 * Toplevel declare/set stay on the walker. Not overlay-after-load.
 * Sidecar tests stay on the tree-walker. Not a second main. Source: macros.kl
 */
#include "abi.h"

void shen_kernel_aot_install_macros (shen_context* ctx);

static KLObject* lambda_0 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t3 = objects[0];
  KLObject* t5 = shen_tl(ctx, t3);
    return t5;
  }
}

static KLObject* lambda_1 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  KLObject* t51 = shen_vector_get(ctx, caps, 0);
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t52 = objects[0];
  KLObject* t53;
  {
    KLObject* a53[] = {t51, t52};
    t53 = shen_tail_apply_direct(ctx, "shen.walk", 2, a53);
  }
    return t53;
  }
}

static KLObject* lambda_2 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  KLObject* t62 = shen_vector_get(ctx, caps, 0);
  (void)arguments;
    return t62;
}

static KLObject* lambda_3 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  KLObject* t454 = shen_vector_get(ctx, caps, 0);
  KLObject* t455 = shen_vector_get(ctx, caps, 1);
  KLObject* t456 = shen_vector_get(ctx, caps, 2);
  (void)arguments;
  KLObject* t460 = shen_cons_p(ctx, t454);
  KLObject* t458;
  if (!shen_is_boolean(ctx, t460))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t460)) {
    t458 = t460;
  } else {
  KLObject* t462 = shen_tl(ctx, t454);
  KLObject* t465 = shen_cons_p(ctx, t462);
  KLObject* t463;
  if (!shen_is_boolean(ctx, t465))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t465)) {
    t463 = t465;
  } else {
  KLObject* t468 = shen_tl(ctx, t462);
  KLObject* t469 = shen_cons_p(ctx, t468);
  KLObject* t466;
  if (!shen_is_boolean(ctx, t469))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t469)) {
    t466 = t469;
  } else {
  KLObject* t472 = shen_intern(ctx, "@p");
  KLObject* t473 = shen_intern(ctx, "@v");
  KLObject* t474 = shen_intern(ctx, "append");
  KLObject* t475 = shen_intern(ctx, "and");
  KLObject* t476 = shen_intern(ctx, "or");
  KLObject* t477 = shen_intern(ctx, "+");
  KLObject* t478 = shen_intern(ctx, "*");
  KLObject* t479 = shen_intern(ctx, "do");
  KLObject* t480 = shen_empty_list(ctx);
  KLObject* t481 = shen_cons(ctx, t479, t480);
  KLObject* t482 = shen_cons(ctx, t478, t481);
  KLObject* t483 = shen_cons(ctx, t477, t482);
  KLObject* t484 = shen_cons(ctx, t476, t483);
  KLObject* t485 = shen_cons(ctx, t475, t484);
  KLObject* t486 = shen_cons(ctx, t474, t485);
  KLObject* t487 = shen_cons(ctx, t473, t486);
  KLObject* t488 = shen_cons(ctx, t472, t487);
  KLObject* t470;
  {
    KLObject* a470[] = {t455, t488};
    t470 = shen_apply_direct(ctx, "element?", 2, a470);
  }
    if (!shen_is_boolean(ctx, t470))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t466 = t470;
  }
    if (!shen_is_boolean(ctx, t466))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t463 = t466;
  }
    if (!shen_is_boolean(ctx, t463))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t458 = t463;
  }
  KLObject* t457;
  if (!shen_is_boolean(ctx, t458))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t458)) {
  KLObject* t491 = shen_hd(ctx, t454);
  KLObject* t495 = shen_tl(ctx, t454);
  KLObject* t496 = shen_cons(ctx, t455, t495);
  KLObject* t492;
  {
    KLObject* a492[] = {t496};
    t492 = shen_apply_direct(ctx, "shen.process-assoc", 1, a492);
  }
  KLObject* t497 = shen_empty_list(ctx);
  KLObject* t498 = shen_cons(ctx, t492, t497);
  KLObject* t499 = shen_cons(ctx, t491, t498);
  KLObject* t500 = shen_cons(ctx, t455, t499);
    t457 = t500;
  } else {
  KLObject* t501;
  {
    KLObject* a501[] = {t456};
    t501 = shen_tail_apply_direct(ctx, "thaw", 1, a501);
  }
    t457 = t501;
  }
    return t457;
}

static KLObject* lambda_4 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  (void)arguments;
  KLObject* t578 = shen_string(ctx, "partial function shen.process-input+");
  KLObject* t577;
  {
    KLObject* a577[] = {t578};
    t577 = shen_tail_apply_direct(ctx, "simple-error", 1, a577);
  }
    return t577;
}

static KLObject* lambda_5 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  KLObject* t634 = shen_vector_get(ctx, caps, 0);
  (void)arguments;
    return t634;
}

static KLObject* lambda_6 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  KLObject* t777 = shen_vector_get(ctx, caps, 0);
  (void)arguments;
    return t777;
}

static KLObject* lambda_7 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t851 = objects[0];
  KLObject* t852;
  {
    KLObject* a852[] = {t851};
    t852 = shen_tail_apply_direct(ctx, "shen.<datatype>", 1, a852);
  }
    return t852;
  }
}

static KLObject* lambda_8 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t875 = objects[0];
  KLObject* t876;
  {
    KLObject* a876[] = {t875};
    t876 = shen_tail_apply_direct(ctx, "shen.curry-type", 1, a876);
  }
    return t876;
  }
}

static KLObject* lambda_9 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  KLObject* t927 = shen_vector_get(ctx, caps, 0);
  (void)arguments;
    return t927;
}

static KLObject* lambda_10 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  KLObject* t991 = shen_vector_get(ctx, caps, 0);
  (void)arguments;
    return t991;
}

static KLObject* lambda_11 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  KLObject* t1020 = shen_vector_get(ctx, caps, 0);
  KLObject* t1021 = shen_vector_get(ctx, caps, 1);
  (void)arguments;
  KLObject* t1023 = shen_empty_list(ctx);
  KLObject* t1025 = shen_eq(ctx, t1023, t1020);
  KLObject* t1022;
  if (!shen_is_boolean(ctx, t1025))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1025)) {
  KLObject* t1027 = shen_string(ctx, "error: odd number of case elements\n");
  KLObject* t1026;
  {
    KLObject* a1026[] = {t1027};
    t1026 = shen_tail_apply_direct(ctx, "simple-error", 1, a1026);
  }
    t1022 = t1026;
  } else {
  KLObject* t1028;
  {
    KLObject* a1028[] = {t1021};
    t1028 = shen_tail_apply_direct(ctx, "thaw", 1, a1028);
  }
    t1022 = t1028;
  }
    return t1022;
}

static KLObject* lambda_12 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  (void)arguments;
  KLObject* t1234 = shen_string(ctx, "implementation error in shen.update-assoc");
  KLObject* t1233;
  {
    KLObject* a1233[] = {t1234};
    t1233 = shen_tail_apply_direct(ctx, "simple-error", 1, a1233);
  }
    return t1233;
}

static KLObject* lambda_13 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t1310 = objects[0];
  KLObject* t1311;
  {
    KLObject* a1311[] = {t1310};
    t1311 = shen_tail_apply_direct(ctx, "shen.<body>", 1, a1311);
  }
    return t1311;
  }
}

static KLObject* lambda_14 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  (void)arguments;
  KLObject* t1368 = shen_empty_list(ctx);
    return t1368;
}

static KLObject* lambda_15 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  KLObject* t1412 = shen_vector_get(ctx, caps, 0);
  (void)arguments;
    return t1412;
}

static KLObject* native_kl_macroexpand_0 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t0 = objects[0];
  tail_start_kl_macroexpand_0: ;
  KLObject* t2;
  {
    Vector* caps_0 = shen_vector(ctx, 0);
    t2 = shen_native_closure(ctx, 1, &lambda_0, caps_0);
  }
  KLObject* t7 = shen_intern(ctx, "*macros*");
  KLObject* t6;
  {
    KLObject* a6[] = {t7};
    t6 = shen_apply_direct(ctx, "value", 1, a6);
  }
  KLObject* t1;
  {
    KLObject* a1[] = {t2, t6};
    t1 = shen_apply_direct(ctx, "map", 2, a1);
  }
  KLObject* t8;
  {
    KLObject* a8[] = {t0, t1, t1};
    t8 = shen_tail_apply_direct(ctx, "shen.macroexpand-h", 3, a8);
  }
    return t8;
  }
}

static KLObject* native_kl_shen_2emacroexpand_2dh_1 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t12 = objects[0];
    KLObject* t13 = objects[1];
    KLObject* t14 = objects[2];
  tail_start_kl_shen_2emacroexpand_2dh_1: ;
  KLObject* t16 = shen_empty_list(ctx);
  KLObject* t18 = shen_eq(ctx, t16, t13);
  KLObject* t15;
  if (!shen_is_boolean(ctx, t18))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t18)) {
    t15 = t12;
  } else {
  KLObject* t22 = shen_cons_p(ctx, t13);
  KLObject* t20;
  if (!shen_is_boolean(ctx, t22))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t22)) {
  KLObject* t25 = shen_hd(ctx, t13);
  KLObject* t23;
  {
    KLObject* a23[] = {t25, t12};
    t23 = shen_apply_direct(ctx, "shen.walk", 2, a23);
  }
  KLObject* t30 = shen_eq(ctx, t12, t23);
  KLObject* t27;
  if (!shen_is_boolean(ctx, t30))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t30)) {
  KLObject* t33 = shen_tl(ctx, t13);
  {
    KLObject* n35_0 = t12;
    KLObject* n35_1 = t33;
    KLObject* n35_2 = t14;
    t12 = n35_0;
    t13 = n35_1;
    t14 = n35_2;
    goto tail_start_kl_shen_2emacroexpand_2dh_1;
  }
  KLObject* t35 = NULL;
    t27 = t35;
  } else {
  {
    KLObject* n39_0 = t23;
    KLObject* n39_1 = t14;
    KLObject* n39_2 = t14;
    t12 = n39_0;
    t13 = n39_1;
    t14 = n39_2;
    goto tail_start_kl_shen_2emacroexpand_2dh_1;
  }
  KLObject* t39 = NULL;
    t27 = t39;
  }
    t20 = t27;
  } else {
  KLObject* t41 = shen_string(ctx, "implementation error in shen.macroexpand-h");
  KLObject* t40;
  {
    KLObject* a40[] = {t41};
    t40 = shen_tail_apply_direct(ctx, "simple-error", 1, a40);
  }
    t20 = t40;
  }
    t15 = t20;
  }
    return t15;
  }
}

static KLObject* native_kl_shen_2ewalk_2 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t42 = objects[0];
    KLObject* t43 = objects[1];
  tail_start_kl_shen_2ewalk_2: ;
  KLObject* t46 = shen_cons_p(ctx, t43);
  KLObject* t44;
  if (!shen_is_boolean(ctx, t46))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t46)) {
  KLObject* t50;
  {
    Vector* caps_1 = shen_vector(ctx, 1);
    shen_vector_set(ctx, caps_1, 0, t42);
    t50 = shen_native_closure(ctx, 1, &lambda_1, caps_1);
  }
  KLObject* t49;
  {
    KLObject* a49[] = {t50, t43};
    t49 = shen_apply_direct(ctx, "map", 2, a49);
  }
  KLObject* t47;
  {
    Vector* a47 = shen_vector(ctx, 1);
    shen_vector_set(ctx, a47, 0, t49);
    t47 = shen_tail_apply(ctx, t42, a47);
  }
    t44 = t47;
  } else {
  KLObject* t57;
  {
    Vector* a57 = shen_vector(ctx, 1);
    shen_vector_set(ctx, a57, 0, t43);
    t57 = shen_tail_apply(ctx, t42, a57);
  }
    t44 = t57;
  }
    return t44;
  }
}

static KLObject* native_kl_shen_2emacros_3 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t60 = objects[0];
  tail_start_kl_shen_2emacros_3: ;
  KLObject* t61;
  {
    Vector* caps_2 = shen_vector(ctx, 1);
    shen_vector_set(ctx, caps_2, 0, t60);
    t61 = shen_native_closure(ctx, 0, &lambda_2, caps_2);
  }
  KLObject* t66 = shen_cons_p(ctx, t60);
  KLObject* t64;
  if (!shen_is_boolean(ctx, t66))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t66)) {
  KLObject* t68 = shen_hd(ctx, t60);
  KLObject* t70 = shen_tl(ctx, t60);
  KLObject* t73 = shen_intern(ctx, "defmacro");
  KLObject* t75 = shen_eq(ctx, t73, t68);
  KLObject* t72;
  if (!shen_is_boolean(ctx, t75))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t75)) {
    t72 = t75;
  } else {
  KLObject* t77 = shen_cons_p(ctx, t70);
    if (!shen_is_boolean(ctx, t77))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t72 = t77;
  }
  KLObject* t71;
  if (!shen_is_boolean(ctx, t72))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t72)) {
  KLObject* t80 = shen_hd(ctx, t70);
  KLObject* t82 = shen_tl(ctx, t70);
  KLObject* t78;
  {
    KLObject* a78[] = {t80, t82};
    t78 = shen_tail_apply_direct(ctx, "shen.process-def", 2, a78);
  }
    t71 = t78;
  } else {
  KLObject* t84 = shen_intern(ctx, "defcc");
  KLObject* t86 = shen_eq(ctx, t84, t68);
  KLObject* t83;
  if (!shen_is_boolean(ctx, t86))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t86)) {
  KLObject* t87;
  {
    KLObject* a87[] = {t70};
    t87 = shen_tail_apply_direct(ctx, "shen.yacc->shen", 1, a87);
  }
    t83 = t87;
  } else {
  KLObject* t91 = shen_intern(ctx, "u!");
  KLObject* t93 = shen_eq(ctx, t91, t68);
  KLObject* t90;
  if (!shen_is_boolean(ctx, t93))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t93)) {
    t90 = t93;
  } else {
  KLObject* t96 = shen_cons_p(ctx, t70);
  KLObject* t94;
  if (!shen_is_boolean(ctx, t96))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t96)) {
    t94 = t96;
  } else {
  KLObject* t97 = shen_empty_list(ctx);
  KLObject* t99 = shen_tl(ctx, t70);
  KLObject* t100 = shen_eq(ctx, t97, t99);
    if (!shen_is_boolean(ctx, t100))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t94 = t100;
  }
    if (!shen_is_boolean(ctx, t94))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t90 = t94;
  }
  KLObject* t89;
  if (!shen_is_boolean(ctx, t90))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t90)) {
  KLObject* t101 = shen_intern(ctx, "protect");
  KLObject* t104 = shen_hd(ctx, t70);
  KLObject* t102;
  {
    KLObject* a102[] = {t104};
    t102 = shen_apply_direct(ctx, "shen.make-uppercase", 1, a102);
  }
  KLObject* t105 = shen_empty_list(ctx);
  KLObject* t106 = shen_cons(ctx, t102, t105);
  KLObject* t107 = shen_cons(ctx, t101, t106);
    t89 = t107;
  } else {
  KLObject* t110 = shen_intern(ctx, "error");
  KLObject* t112 = shen_eq(ctx, t110, t68);
  KLObject* t109;
  if (!shen_is_boolean(ctx, t112))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t112)) {
    t109 = t112;
  } else {
  KLObject* t114 = shen_cons_p(ctx, t70);
    if (!shen_is_boolean(ctx, t114))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t109 = t114;
  }
  KLObject* t108;
  if (!shen_is_boolean(ctx, t109))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t109)) {
  KLObject* t115 = shen_intern(ctx, "simple-error");
  KLObject* t118 = shen_hd(ctx, t70);
  KLObject* t120 = shen_tl(ctx, t70);
  KLObject* t116;
  {
    KLObject* a116[] = {t118, t120};
    t116 = shen_apply_direct(ctx, "shen.mkstr", 2, a116);
  }
  KLObject* t121 = shen_empty_list(ctx);
  KLObject* t122 = shen_cons(ctx, t116, t121);
  KLObject* t123 = shen_cons(ctx, t115, t122);
    t108 = t123;
  } else {
  KLObject* t126 = shen_intern(ctx, "output");
  KLObject* t128 = shen_eq(ctx, t126, t68);
  KLObject* t125;
  if (!shen_is_boolean(ctx, t128))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t128)) {
    t125 = t128;
  } else {
  KLObject* t130 = shen_cons_p(ctx, t70);
    if (!shen_is_boolean(ctx, t130))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t125 = t130;
  }
  KLObject* t124;
  if (!shen_is_boolean(ctx, t125))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t125)) {
  KLObject* t131 = shen_intern(ctx, "pr");
  KLObject* t134 = shen_hd(ctx, t70);
  KLObject* t136 = shen_tl(ctx, t70);
  KLObject* t132;
  {
    KLObject* a132[] = {t134, t136};
    t132 = shen_apply_direct(ctx, "shen.mkstr", 2, a132);
  }
  KLObject* t137 = shen_intern(ctx, "stoutput");
  KLObject* t138 = shen_empty_list(ctx);
  KLObject* t139 = shen_cons(ctx, t137, t138);
  KLObject* t140 = shen_empty_list(ctx);
  KLObject* t141 = shen_cons(ctx, t139, t140);
  KLObject* t142 = shen_cons(ctx, t132, t141);
  KLObject* t143 = shen_cons(ctx, t131, t142);
    t124 = t143;
  } else {
  KLObject* t146 = shen_intern(ctx, "pr");
  KLObject* t148 = shen_eq(ctx, t146, t68);
  KLObject* t145;
  if (!shen_is_boolean(ctx, t148))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t148)) {
    t145 = t148;
  } else {
  KLObject* t151 = shen_cons_p(ctx, t70);
  KLObject* t149;
  if (!shen_is_boolean(ctx, t151))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t151)) {
    t149 = t151;
  } else {
  KLObject* t152 = shen_empty_list(ctx);
  KLObject* t154 = shen_tl(ctx, t70);
  KLObject* t155 = shen_eq(ctx, t152, t154);
    if (!shen_is_boolean(ctx, t155))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t149 = t155;
  }
    if (!shen_is_boolean(ctx, t149))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t145 = t149;
  }
  KLObject* t144;
  if (!shen_is_boolean(ctx, t145))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t145)) {
  KLObject* t156 = shen_intern(ctx, "pr");
  KLObject* t158 = shen_hd(ctx, t70);
  KLObject* t159 = shen_intern(ctx, "stoutput");
  KLObject* t160 = shen_empty_list(ctx);
  KLObject* t161 = shen_cons(ctx, t159, t160);
  KLObject* t162 = shen_empty_list(ctx);
  KLObject* t163 = shen_cons(ctx, t161, t162);
  KLObject* t164 = shen_cons(ctx, t158, t163);
  KLObject* t165 = shen_cons(ctx, t156, t164);
    t144 = t165;
  } else {
  KLObject* t168 = shen_intern(ctx, "make-string");
  KLObject* t170 = shen_eq(ctx, t168, t68);
  KLObject* t167;
  if (!shen_is_boolean(ctx, t170))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t170)) {
    t167 = t170;
  } else {
  KLObject* t172 = shen_cons_p(ctx, t70);
    if (!shen_is_boolean(ctx, t172))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t167 = t172;
  }
  KLObject* t166;
  if (!shen_is_boolean(ctx, t167))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t167)) {
  KLObject* t175 = shen_hd(ctx, t70);
  KLObject* t177 = shen_tl(ctx, t70);
  KLObject* t173;
  {
    KLObject* a173[] = {t175, t177};
    t173 = shen_tail_apply_direct(ctx, "shen.mkstr", 2, a173);
  }
    t166 = t173;
  } else {
  KLObject* t180 = shen_intern(ctx, "lineread");
  KLObject* t182 = shen_eq(ctx, t180, t68);
  KLObject* t179;
  if (!shen_is_boolean(ctx, t182))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t182)) {
    t179 = t182;
  } else {
  KLObject* t183 = shen_empty_list(ctx);
  KLObject* t185 = shen_eq(ctx, t183, t70);
    if (!shen_is_boolean(ctx, t185))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t179 = t185;
  }
  KLObject* t178;
  if (!shen_is_boolean(ctx, t179))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t179)) {
  KLObject* t186 = shen_intern(ctx, "lineread");
  KLObject* t187 = shen_intern(ctx, "stinput");
  KLObject* t188 = shen_empty_list(ctx);
  KLObject* t189 = shen_cons(ctx, t187, t188);
  KLObject* t190 = shen_empty_list(ctx);
  KLObject* t191 = shen_cons(ctx, t189, t190);
  KLObject* t192 = shen_cons(ctx, t186, t191);
    t178 = t192;
  } else {
  KLObject* t195 = shen_intern(ctx, "input");
  KLObject* t197 = shen_eq(ctx, t195, t68);
  KLObject* t194;
  if (!shen_is_boolean(ctx, t197))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t197)) {
    t194 = t197;
  } else {
  KLObject* t198 = shen_empty_list(ctx);
  KLObject* t200 = shen_eq(ctx, t198, t70);
    if (!shen_is_boolean(ctx, t200))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t194 = t200;
  }
  KLObject* t193;
  if (!shen_is_boolean(ctx, t194))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t194)) {
  KLObject* t201 = shen_intern(ctx, "input");
  KLObject* t202 = shen_intern(ctx, "stinput");
  KLObject* t203 = shen_empty_list(ctx);
  KLObject* t204 = shen_cons(ctx, t202, t203);
  KLObject* t205 = shen_empty_list(ctx);
  KLObject* t206 = shen_cons(ctx, t204, t205);
  KLObject* t207 = shen_cons(ctx, t201, t206);
    t193 = t207;
  } else {
  KLObject* t210 = shen_intern(ctx, "read");
  KLObject* t212 = shen_eq(ctx, t210, t68);
  KLObject* t209;
  if (!shen_is_boolean(ctx, t212))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t212)) {
    t209 = t212;
  } else {
  KLObject* t213 = shen_empty_list(ctx);
  KLObject* t215 = shen_eq(ctx, t213, t70);
    if (!shen_is_boolean(ctx, t215))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t209 = t215;
  }
  KLObject* t208;
  if (!shen_is_boolean(ctx, t209))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t209)) {
  KLObject* t216 = shen_intern(ctx, "read");
  KLObject* t217 = shen_intern(ctx, "stinput");
  KLObject* t218 = shen_empty_list(ctx);
  KLObject* t219 = shen_cons(ctx, t217, t218);
  KLObject* t220 = shen_empty_list(ctx);
  KLObject* t221 = shen_cons(ctx, t219, t220);
  KLObject* t222 = shen_cons(ctx, t216, t221);
    t208 = t222;
  } else {
  KLObject* t225 = shen_intern(ctx, "input+");
  KLObject* t227 = shen_eq(ctx, t225, t68);
  KLObject* t224;
  if (!shen_is_boolean(ctx, t227))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t227)) {
    t224 = t227;
  } else {
  KLObject* t229 = shen_cons_p(ctx, t70);
    if (!shen_is_boolean(ctx, t229))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t224 = t229;
  }
  KLObject* t223;
  if (!shen_is_boolean(ctx, t224))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t224)) {
  KLObject* t230;
  {
    KLObject* a230[] = {t60};
    t230 = shen_tail_apply_direct(ctx, "shen.process-input+", 1, a230);
  }
    t223 = t230;
  } else {
  KLObject* t234 = shen_intern(ctx, "read-byte");
  KLObject* t236 = shen_eq(ctx, t234, t68);
  KLObject* t233;
  if (!shen_is_boolean(ctx, t236))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t236)) {
    t233 = t236;
  } else {
  KLObject* t237 = shen_empty_list(ctx);
  KLObject* t239 = shen_eq(ctx, t237, t70);
    if (!shen_is_boolean(ctx, t239))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t233 = t239;
  }
  KLObject* t232;
  if (!shen_is_boolean(ctx, t233))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t233)) {
  KLObject* t240 = shen_tail_apply_direct(ctx, "shen.process-read-byte", 0, NULL);
    t232 = t240;
  } else {
  KLObject* t242 = shen_intern(ctx, "prolog?");
  KLObject* t244 = shen_eq(ctx, t242, t68);
  KLObject* t241;
  if (!shen_is_boolean(ctx, t244))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t244)) {
  KLObject* t245;
  {
    KLObject* a245[] = {t70};
    t245 = shen_tail_apply_direct(ctx, "shen.call-prolog", 1, a245);
  }
    t241 = t245;
  } else {
  KLObject* t249 = shen_intern(ctx, "defprolog");
  KLObject* t251 = shen_eq(ctx, t249, t68);
  KLObject* t248;
  if (!shen_is_boolean(ctx, t251))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t251)) {
    t248 = t251;
  } else {
  KLObject* t253 = shen_cons_p(ctx, t70);
    if (!shen_is_boolean(ctx, t253))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t248 = t253;
  }
  KLObject* t247;
  if (!shen_is_boolean(ctx, t248))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t248)) {
  KLObject* t256 = shen_hd(ctx, t70);
  KLObject* t258 = shen_tl(ctx, t70);
  KLObject* t254;
  {
    KLObject* a254[] = {t256, t258};
    t254 = shen_tail_apply_direct(ctx, "shen.compile-prolog", 2, a254);
  }
    t247 = t254;
  } else {
  KLObject* t261 = shen_intern(ctx, "datatype");
  KLObject* t263 = shen_eq(ctx, t261, t68);
  KLObject* t260;
  if (!shen_is_boolean(ctx, t263))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t263)) {
    t260 = t263;
  } else {
  KLObject* t265 = shen_cons_p(ctx, t70);
    if (!shen_is_boolean(ctx, t265))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t260 = t265;
  }
  KLObject* t259;
  if (!shen_is_boolean(ctx, t260))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t260)) {
  KLObject* t268 = shen_hd(ctx, t70);
  KLObject* t270 = shen_tl(ctx, t70);
  KLObject* t266;
  {
    KLObject* a266[] = {t268, t270};
    t266 = shen_tail_apply_direct(ctx, "shen.process-datatype", 2, a266);
  }
    t259 = t266;
  } else {
  KLObject* t272 = shen_intern(ctx, "@s");
  KLObject* t274 = shen_eq(ctx, t272, t68);
  KLObject* t271;
  if (!shen_is_boolean(ctx, t274))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t274)) {
  KLObject* t275;
  {
    KLObject* a275[] = {t60};
    t275 = shen_tail_apply_direct(ctx, "shen.process-@s", 1, a275);
  }
    t271 = t275;
  } else {
  KLObject* t278 = shen_intern(ctx, "synonyms");
  KLObject* t280 = shen_eq(ctx, t278, t68);
  KLObject* t277;
  if (!shen_is_boolean(ctx, t280))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t280)) {
  KLObject* t281;
  {
    KLObject* a281[] = {t70};
    t281 = shen_tail_apply_direct(ctx, "shen.process-synonyms", 1, a281);
  }
    t277 = t281;
  } else {
  KLObject* t285 = shen_intern(ctx, "nl");
  KLObject* t287 = shen_eq(ctx, t285, t68);
  KLObject* t284;
  if (!shen_is_boolean(ctx, t287))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t287)) {
    t284 = t287;
  } else {
  KLObject* t288 = shen_empty_list(ctx);
  KLObject* t290 = shen_eq(ctx, t288, t70);
    if (!shen_is_boolean(ctx, t290))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t284 = t290;
  }
  KLObject* t283;
  if (!shen_is_boolean(ctx, t284))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t284)) {
  KLObject* t291 = shen_intern(ctx, "nl");
  KLObject* t292 = shen_number_l(ctx, 1);
  KLObject* t293 = shen_empty_list(ctx);
  KLObject* t294 = shen_cons(ctx, t292, t293);
  KLObject* t295 = shen_cons(ctx, t291, t294);
    t283 = t295;
  } else {
  KLObject* t297 = shen_intern(ctx, "let");
  KLObject* t299 = shen_eq(ctx, t297, t68);
  KLObject* t296;
  if (!shen_is_boolean(ctx, t299))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t299)) {
  KLObject* t300;
  {
    KLObject* a300[] = {t60};
    t300 = shen_tail_apply_direct(ctx, "shen.process-let", 1, a300);
  }
    t296 = t300;
  } else {
  KLObject* t303 = shen_intern(ctx, "/.");
  KLObject* t305 = shen_eq(ctx, t303, t68);
  KLObject* t302;
  if (!shen_is_boolean(ctx, t305))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t305)) {
  KLObject* t306;
  {
    KLObject* a306[] = {t60};
    t306 = shen_tail_apply_direct(ctx, "shen.process-lambda", 1, a306);
  }
    t302 = t306;
  } else {
  KLObject* t309 = shen_intern(ctx, "cases");
  KLObject* t311 = shen_eq(ctx, t309, t68);
  KLObject* t308;
  if (!shen_is_boolean(ctx, t311))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t311)) {
  KLObject* t312;
  {
    KLObject* a312[] = {t60};
    t312 = shen_tail_apply_direct(ctx, "shen.process-cases", 1, a312);
  }
    t308 = t312;
  } else {
  KLObject* t316 = shen_intern(ctx, "time");
  KLObject* t318 = shen_eq(ctx, t316, t68);
  KLObject* t315;
  if (!shen_is_boolean(ctx, t318))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t318)) {
    t315 = t318;
  } else {
  KLObject* t321 = shen_cons_p(ctx, t70);
  KLObject* t319;
  if (!shen_is_boolean(ctx, t321))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t321)) {
    t319 = t321;
  } else {
  KLObject* t322 = shen_empty_list(ctx);
  KLObject* t324 = shen_tl(ctx, t70);
  KLObject* t325 = shen_eq(ctx, t322, t324);
    if (!shen_is_boolean(ctx, t325))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t319 = t325;
  }
    if (!shen_is_boolean(ctx, t319))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t315 = t319;
  }
  KLObject* t314;
  if (!shen_is_boolean(ctx, t315))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t315)) {
  KLObject* t328 = shen_hd(ctx, t70);
  KLObject* t326;
  {
    KLObject* a326[] = {t328};
    t326 = shen_tail_apply_direct(ctx, "shen.process-time", 1, a326);
  }
    t314 = t326;
  } else {
  KLObject* t331 = shen_intern(ctx, "put");
  KLObject* t333 = shen_eq(ctx, t331, t68);
  KLObject* t330;
  if (!shen_is_boolean(ctx, t333))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t333)) {
    t330 = t333;
  } else {
  KLObject* t336 = shen_cons_p(ctx, t70);
  KLObject* t334;
  if (!shen_is_boolean(ctx, t336))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t336)) {
    t334 = t336;
  } else {
  KLObject* t338 = shen_tl(ctx, t70);
  KLObject* t341 = shen_cons_p(ctx, t338);
  KLObject* t339;
  if (!shen_is_boolean(ctx, t341))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t341)) {
    t339 = t341;
  } else {
  KLObject* t343 = shen_tl(ctx, t338);
  KLObject* t346 = shen_cons_p(ctx, t343);
  KLObject* t344;
  if (!shen_is_boolean(ctx, t346))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t346)) {
    t344 = t346;
  } else {
  KLObject* t347 = shen_empty_list(ctx);
  KLObject* t349 = shen_tl(ctx, t343);
  KLObject* t350 = shen_eq(ctx, t347, t349);
    if (!shen_is_boolean(ctx, t350))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t344 = t350;
  }
    if (!shen_is_boolean(ctx, t344))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t339 = t344;
  }
    if (!shen_is_boolean(ctx, t339))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t334 = t339;
  }
    if (!shen_is_boolean(ctx, t334))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t330 = t334;
  }
  KLObject* t329;
  if (!shen_is_boolean(ctx, t330))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t330)) {
  KLObject* t352 = shen_tl(ctx, t70);
  KLObject* t353 = shen_intern(ctx, "put");
  KLObject* t355 = shen_hd(ctx, t70);
  KLObject* t357 = shen_hd(ctx, t352);
  KLObject* t359 = shen_tl(ctx, t352);
  KLObject* t360 = shen_hd(ctx, t359);
  KLObject* t361 = shen_intern(ctx, "value");
  KLObject* t362 = shen_intern(ctx, "*property-vector*");
  KLObject* t363 = shen_empty_list(ctx);
  KLObject* t364 = shen_cons(ctx, t362, t363);
  KLObject* t365 = shen_cons(ctx, t361, t364);
  KLObject* t366 = shen_empty_list(ctx);
  KLObject* t367 = shen_cons(ctx, t365, t366);
  KLObject* t368 = shen_cons(ctx, t360, t367);
  KLObject* t369 = shen_cons(ctx, t357, t368);
  KLObject* t370 = shen_cons(ctx, t355, t369);
  KLObject* t371 = shen_cons(ctx, t353, t370);
    t329 = t371;
  } else {
  KLObject* t374 = shen_intern(ctx, "get");
  KLObject* t376 = shen_eq(ctx, t374, t68);
  KLObject* t373;
  if (!shen_is_boolean(ctx, t376))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t376)) {
    t373 = t376;
  } else {
  KLObject* t379 = shen_cons_p(ctx, t70);
  KLObject* t377;
  if (!shen_is_boolean(ctx, t379))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t379)) {
    t377 = t379;
  } else {
  KLObject* t381 = shen_tl(ctx, t70);
  KLObject* t384 = shen_cons_p(ctx, t381);
  KLObject* t382;
  if (!shen_is_boolean(ctx, t384))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t384)) {
    t382 = t384;
  } else {
  KLObject* t385 = shen_empty_list(ctx);
  KLObject* t387 = shen_tl(ctx, t381);
  KLObject* t388 = shen_eq(ctx, t385, t387);
    if (!shen_is_boolean(ctx, t388))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t382 = t388;
  }
    if (!shen_is_boolean(ctx, t382))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t377 = t382;
  }
    if (!shen_is_boolean(ctx, t377))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t373 = t377;
  }
  KLObject* t372;
  if (!shen_is_boolean(ctx, t373))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t373)) {
  KLObject* t389 = shen_intern(ctx, "get");
  KLObject* t391 = shen_hd(ctx, t70);
  KLObject* t393 = shen_tl(ctx, t70);
  KLObject* t394 = shen_hd(ctx, t393);
  KLObject* t395 = shen_intern(ctx, "value");
  KLObject* t396 = shen_intern(ctx, "*property-vector*");
  KLObject* t397 = shen_empty_list(ctx);
  KLObject* t398 = shen_cons(ctx, t396, t397);
  KLObject* t399 = shen_cons(ctx, t395, t398);
  KLObject* t400 = shen_empty_list(ctx);
  KLObject* t401 = shen_cons(ctx, t399, t400);
  KLObject* t402 = shen_cons(ctx, t394, t401);
  KLObject* t403 = shen_cons(ctx, t391, t402);
  KLObject* t404 = shen_cons(ctx, t389, t403);
    t372 = t404;
  } else {
  KLObject* t407 = shen_intern(ctx, "unput");
  KLObject* t409 = shen_eq(ctx, t407, t68);
  KLObject* t406;
  if (!shen_is_boolean(ctx, t409))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t409)) {
    t406 = t409;
  } else {
  KLObject* t412 = shen_cons_p(ctx, t70);
  KLObject* t410;
  if (!shen_is_boolean(ctx, t412))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t412)) {
    t410 = t412;
  } else {
  KLObject* t414 = shen_tl(ctx, t70);
  KLObject* t417 = shen_cons_p(ctx, t414);
  KLObject* t415;
  if (!shen_is_boolean(ctx, t417))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t417)) {
    t415 = t417;
  } else {
  KLObject* t418 = shen_empty_list(ctx);
  KLObject* t420 = shen_tl(ctx, t414);
  KLObject* t421 = shen_eq(ctx, t418, t420);
    if (!shen_is_boolean(ctx, t421))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t415 = t421;
  }
    if (!shen_is_boolean(ctx, t415))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t410 = t415;
  }
    if (!shen_is_boolean(ctx, t410))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t406 = t410;
  }
  KLObject* t405;
  if (!shen_is_boolean(ctx, t406))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t406)) {
  KLObject* t422 = shen_intern(ctx, "unput");
  KLObject* t424 = shen_hd(ctx, t70);
  KLObject* t426 = shen_tl(ctx, t70);
  KLObject* t427 = shen_hd(ctx, t426);
  KLObject* t428 = shen_intern(ctx, "value");
  KLObject* t429 = shen_intern(ctx, "*property-vector*");
  KLObject* t430 = shen_empty_list(ctx);
  KLObject* t431 = shen_cons(ctx, t429, t430);
  KLObject* t432 = shen_cons(ctx, t428, t431);
  KLObject* t433 = shen_empty_list(ctx);
  KLObject* t434 = shen_cons(ctx, t432, t433);
  KLObject* t435 = shen_cons(ctx, t427, t434);
  KLObject* t436 = shen_cons(ctx, t424, t435);
  KLObject* t437 = shen_cons(ctx, t422, t436);
    t405 = t437;
  } else {
  KLObject* t440 = shen_intern(ctx, "shen.@c");
  KLObject* t442 = shen_eq(ctx, t440, t68);
  KLObject* t439;
  if (!shen_is_boolean(ctx, t442))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t442)) {
    t439 = t442;
  } else {
  KLObject* t445 = shen_cons_p(ctx, t70);
  KLObject* t443;
  if (!shen_is_boolean(ctx, t445))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t445)) {
    t443 = t445;
  } else {
  KLObject* t446 = shen_empty_list(ctx);
  KLObject* t448 = shen_tl(ctx, t70);
  KLObject* t449 = shen_eq(ctx, t446, t448);
    if (!shen_is_boolean(ctx, t449))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t443 = t449;
  }
    if (!shen_is_boolean(ctx, t443))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t439 = t443;
  }
  KLObject* t438;
  if (!shen_is_boolean(ctx, t439))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t439)) {
  KLObject* t452 = shen_hd(ctx, t70);
  KLObject* t450;
  {
    KLObject* a450[] = {t452};
    t450 = shen_tail_apply_direct(ctx, "shen.rcons_form", 1, a450);
  }
    t438 = t450;
  } else {
  KLObject* t453;
  {
    Vector* caps_3 = shen_vector(ctx, 3);
    shen_vector_set(ctx, caps_3, 0, t70);
    shen_vector_set(ctx, caps_3, 1, t68);
    shen_vector_set(ctx, caps_3, 2, t61);
    t453 = shen_native_closure(ctx, 0, &lambda_3, caps_3);
  }
  KLObject* t504 = shen_intern(ctx, "shen.@ch");
  KLObject* t506 = shen_eq(ctx, t504, t68);
  KLObject* t503;
  if (!shen_is_boolean(ctx, t506))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t506)) {
  KLObject* t509 = shen_cons_p(ctx, t70);
  KLObject* t507;
  if (!shen_is_boolean(ctx, t509))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t509)) {
  KLObject* t511 = shen_hd(ctx, t70);
  KLObject* t513 = shen_tl(ctx, t70);
  KLObject* t517 = shen_cons_p(ctx, t511);
  KLObject* t515;
  if (!shen_is_boolean(ctx, t517))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t517)) {
    t515 = t517;
  } else {
  KLObject* t519 = shen_tl(ctx, t511);
  KLObject* t522 = shen_cons_p(ctx, t519);
  KLObject* t520;
  if (!shen_is_boolean(ctx, t522))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t522)) {
    t520 = t522;
  } else {
  KLObject* t524 = shen_tl(ctx, t519);
  KLObject* t527 = shen_cons_p(ctx, t524);
  KLObject* t525;
  if (!shen_is_boolean(ctx, t527))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t527)) {
    t525 = t527;
  } else {
  KLObject* t529 = shen_empty_list(ctx);
  KLObject* t531 = shen_tl(ctx, t524);
  KLObject* t532 = shen_eq(ctx, t529, t531);
  KLObject* t528;
  if (!shen_is_boolean(ctx, t532))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t532)) {
    t528 = t532;
  } else {
  KLObject* t534 = shen_empty_list(ctx);
  KLObject* t536 = shen_eq(ctx, t534, t513);
  KLObject* t533;
  if (!shen_is_boolean(ctx, t536))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t536)) {
    t533 = t536;
  } else {
  KLObject* t538 = shen_hd(ctx, t519);
  KLObject* t540 = shen_string(ctx, ":");
  KLObject* t539;
  {
    KLObject* a539[] = {t540};
    t539 = shen_apply_direct(ctx, "intern", 1, a539);
  }
  KLObject* t541 = shen_eq(ctx, t538, t539);
    if (!shen_is_boolean(ctx, t541))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t533 = t541;
  }
    if (!shen_is_boolean(ctx, t533))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t528 = t533;
  }
    if (!shen_is_boolean(ctx, t528))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t525 = t528;
  }
    if (!shen_is_boolean(ctx, t525))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t520 = t525;
  }
    if (!shen_is_boolean(ctx, t520))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t515 = t520;
  }
  KLObject* t514;
  if (!shen_is_boolean(ctx, t515))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t515)) {
  KLObject* t543 = shen_tl(ctx, t511);
  KLObject* t545 = shen_intern(ctx, "-");
  KLObject* t547 = shen_hd(ctx, t511);
  KLObject* t549 = shen_hd(ctx, t543);
  KLObject* t550 = shen_intern(ctx, "+");
  KLObject* t552 = shen_tl(ctx, t543);
  KLObject* t553 = shen_cons(ctx, t550, t552);
  KLObject* t554 = shen_empty_list(ctx);
  KLObject* t555 = shen_cons(ctx, t553, t554);
  KLObject* t556 = shen_cons(ctx, t549, t555);
  KLObject* t557 = shen_cons(ctx, t547, t556);
  KLObject* t558 = shen_empty_list(ctx);
  KLObject* t559 = shen_cons(ctx, t557, t558);
  KLObject* t560 = shen_cons(ctx, t545, t559);
  KLObject* t544;
  {
    KLObject* a544[] = {t560};
    t544 = shen_tail_apply_direct(ctx, "shen.cons-form-respect-modes", 1, a544);
  }
    t514 = t544;
  } else {
  KLObject* t562 = shen_empty_list(ctx);
  KLObject* t564 = shen_eq(ctx, t562, t513);
  KLObject* t561;
  if (!shen_is_boolean(ctx, t564))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t564)) {
  KLObject* t565;
  {
    KLObject* a565[] = {t511};
    t565 = shen_tail_apply_direct(ctx, "shen.cons-form-respect-modes", 1, a565);
  }
    t561 = t565;
  } else {
  KLObject* t567;
  {
    KLObject* a567[] = {t453};
    t567 = shen_tail_apply_direct(ctx, "thaw", 1, a567);
  }
    t561 = t567;
  }
    t514 = t561;
  }
    t507 = t514;
  } else {
  KLObject* t569;
  {
    KLObject* a569[] = {t453};
    t569 = shen_tail_apply_direct(ctx, "thaw", 1, a569);
  }
    t507 = t569;
  }
    t503 = t507;
  } else {
  KLObject* t571;
  {
    KLObject* a571[] = {t453};
    t571 = shen_tail_apply_direct(ctx, "thaw", 1, a571);
  }
    t503 = t571;
  }
    t438 = t503;
  }
    t405 = t438;
  }
    t372 = t405;
  }
    t329 = t372;
  }
    t314 = t329;
  }
    t308 = t314;
  }
    t302 = t308;
  }
    t296 = t302;
  }
    t283 = t296;
  }
    t277 = t283;
  }
    t271 = t277;
  }
    t259 = t271;
  }
    t247 = t259;
  }
    t241 = t247;
  }
    t232 = t241;
  }
    t223 = t232;
  }
    t208 = t223;
  }
    t193 = t208;
  }
    t178 = t193;
  }
    t166 = t178;
  }
    t144 = t166;
  }
    t124 = t144;
  }
    t108 = t124;
  }
    t89 = t108;
  }
    t83 = t89;
  }
    t71 = t83;
  }
    t64 = t71;
  } else {
  KLObject* t573;
  {
    KLObject* a573[] = {t61};
    t573 = shen_tail_apply_direct(ctx, "thaw", 1, a573);
  }
    t64 = t573;
  }
    return t64;
  }
}

static KLObject* native_kl_shen_2eprocess_2dinput_2b_4 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t575 = objects[0];
  tail_start_kl_shen_2eprocess_2dinput_2b_4: ;
  KLObject* t576;
  {
    Vector* caps_4 = shen_vector(ctx, 0);
    t576 = shen_native_closure(ctx, 0, &lambda_4, caps_4);
  }
  KLObject* t581 = shen_cons_p(ctx, t575);
  KLObject* t579;
  if (!shen_is_boolean(ctx, t581))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t581)) {
  KLObject* t583 = shen_tl(ctx, t575);
  KLObject* t585 = shen_intern(ctx, "input+");
  KLObject* t587 = shen_hd(ctx, t575);
  KLObject* t588 = shen_eq(ctx, t585, t587);
  KLObject* t584;
  if (!shen_is_boolean(ctx, t588))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t588)) {
  KLObject* t591 = shen_cons_p(ctx, t583);
  KLObject* t589;
  if (!shen_is_boolean(ctx, t591))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t591)) {
  KLObject* t593 = shen_hd(ctx, t583);
  KLObject* t595 = shen_tl(ctx, t583);
  KLObject* t597 = shen_empty_list(ctx);
  KLObject* t599 = shen_eq(ctx, t597, t595);
  KLObject* t596;
  if (!shen_is_boolean(ctx, t599))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t599)) {
  KLObject* t600 = shen_intern(ctx, "shen.input-h+");
  KLObject* t601;
  {
    KLObject* a601[] = {t593};
    t601 = shen_apply_direct(ctx, "shen.rcons_form", 1, a601);
  }
  KLObject* t603 = shen_intern(ctx, "stinput");
  KLObject* t604 = shen_empty_list(ctx);
  KLObject* t605 = shen_cons(ctx, t603, t604);
  KLObject* t606 = shen_empty_list(ctx);
  KLObject* t607 = shen_cons(ctx, t605, t606);
  KLObject* t608 = shen_cons(ctx, t601, t607);
  KLObject* t609 = shen_cons(ctx, t600, t608);
    t596 = t609;
  } else {
  KLObject* t613 = shen_cons_p(ctx, t595);
  KLObject* t611;
  if (!shen_is_boolean(ctx, t613))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t613)) {
    t611 = t613;
  } else {
  KLObject* t614 = shen_empty_list(ctx);
  KLObject* t616 = shen_tl(ctx, t595);
  KLObject* t617 = shen_eq(ctx, t614, t616);
    if (!shen_is_boolean(ctx, t617))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t611 = t617;
  }
  KLObject* t610;
  if (!shen_is_boolean(ctx, t611))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t611)) {
  KLObject* t618 = shen_intern(ctx, "shen.input-h+");
  KLObject* t619;
  {
    KLObject* a619[] = {t593};
    t619 = shen_apply_direct(ctx, "shen.rcons_form", 1, a619);
  }
  KLObject* t622 = shen_cons(ctx, t619, t595);
  KLObject* t623 = shen_cons(ctx, t618, t622);
    t610 = t623;
  } else {
  KLObject* t624;
  {
    KLObject* a624[] = {t576};
    t624 = shen_tail_apply_direct(ctx, "thaw", 1, a624);
  }
    t610 = t624;
  }
    t596 = t610;
  }
    t589 = t596;
  } else {
  KLObject* t626;
  {
    KLObject* a626[] = {t576};
    t626 = shen_tail_apply_direct(ctx, "thaw", 1, a626);
  }
    t589 = t626;
  }
    t584 = t589;
  } else {
  KLObject* t628;
  {
    KLObject* a628[] = {t576};
    t628 = shen_tail_apply_direct(ctx, "thaw", 1, a628);
  }
    t584 = t628;
  }
    t579 = t584;
  } else {
  KLObject* t630;
  {
    KLObject* a630[] = {t576};
    t630 = shen_tail_apply_direct(ctx, "thaw", 1, a630);
  }
    t579 = t630;
  }
    return t579;
  }
}

static KLObject* native_kl_shen_2econs_2dform_2drespect_2dmodes_5 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t632 = objects[0];
  tail_start_kl_shen_2econs_2dform_2drespect_2dmodes_5: ;
  KLObject* t633;
  {
    Vector* caps_5 = shen_vector(ctx, 1);
    shen_vector_set(ctx, caps_5, 0, t632);
    t633 = shen_native_closure(ctx, 0, &lambda_5, caps_5);
  }
  KLObject* t638 = shen_cons_p(ctx, t632);
  KLObject* t636;
  if (!shen_is_boolean(ctx, t638))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t638)) {
  KLObject* t640 = shen_hd(ctx, t632);
  KLObject* t642 = shen_tl(ctx, t632);
  KLObject* t645 = shen_intern(ctx, "+");
  KLObject* t647 = shen_eq(ctx, t645, t640);
  KLObject* t644;
  if (!shen_is_boolean(ctx, t647))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t647)) {
    t644 = t647;
  } else {
  KLObject* t650 = shen_cons_p(ctx, t642);
  KLObject* t648;
  if (!shen_is_boolean(ctx, t650))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t650)) {
    t648 = t650;
  } else {
  KLObject* t651 = shen_empty_list(ctx);
  KLObject* t653 = shen_tl(ctx, t642);
  KLObject* t654 = shen_eq(ctx, t651, t653);
    if (!shen_is_boolean(ctx, t654))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t648 = t654;
  }
    if (!shen_is_boolean(ctx, t648))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t644 = t648;
  }
  KLObject* t643;
  if (!shen_is_boolean(ctx, t644))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t644)) {
  KLObject* t655 = shen_intern(ctx, "+");
  KLObject* t658 = shen_hd(ctx, t642);
  KLObject* t656;
  {
    KLObject* a656[] = {t658};
    t656 = shen_apply_direct(ctx, "shen.cons-form-respect-modes", 1, a656);
  }
  KLObject* t659 = shen_empty_list(ctx);
  KLObject* t660 = shen_cons(ctx, t656, t659);
  KLObject* t661 = shen_cons(ctx, t655, t660);
    t643 = t661;
  } else {
  KLObject* t664 = shen_intern(ctx, "-");
  KLObject* t666 = shen_eq(ctx, t664, t640);
  KLObject* t663;
  if (!shen_is_boolean(ctx, t666))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t666)) {
    t663 = t666;
  } else {
  KLObject* t669 = shen_cons_p(ctx, t642);
  KLObject* t667;
  if (!shen_is_boolean(ctx, t669))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t669)) {
    t667 = t669;
  } else {
  KLObject* t670 = shen_empty_list(ctx);
  KLObject* t672 = shen_tl(ctx, t642);
  KLObject* t673 = shen_eq(ctx, t670, t672);
    if (!shen_is_boolean(ctx, t673))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t667 = t673;
  }
    if (!shen_is_boolean(ctx, t667))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t663 = t667;
  }
  KLObject* t662;
  if (!shen_is_boolean(ctx, t663))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t663)) {
  KLObject* t674 = shen_intern(ctx, "-");
  KLObject* t677 = shen_hd(ctx, t642);
  KLObject* t675;
  {
    KLObject* a675[] = {t677};
    t675 = shen_apply_direct(ctx, "shen.cons-form-respect-modes", 1, a675);
  }
  KLObject* t678 = shen_empty_list(ctx);
  KLObject* t679 = shen_cons(ctx, t675, t678);
  KLObject* t680 = shen_cons(ctx, t674, t679);
    t662 = t680;
  } else {
  KLObject* t683 = shen_intern(ctx, "bar!");
  KLObject* t685 = shen_eq(ctx, t683, t640);
  KLObject* t682;
  if (!shen_is_boolean(ctx, t685))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t685)) {
    t682 = t685;
  } else {
  KLObject* t688 = shen_cons_p(ctx, t642);
  KLObject* t686;
  if (!shen_is_boolean(ctx, t688))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t688)) {
    t686 = t688;
  } else {
  KLObject* t689 = shen_empty_list(ctx);
  KLObject* t691 = shen_tl(ctx, t642);
  KLObject* t692 = shen_eq(ctx, t689, t691);
    if (!shen_is_boolean(ctx, t692))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t686 = t692;
  }
    if (!shen_is_boolean(ctx, t686))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t682 = t686;
  }
  KLObject* t681;
  if (!shen_is_boolean(ctx, t682))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t682)) {
  KLObject* t694 = shen_hd(ctx, t642);
    t681 = t694;
  } else {
  KLObject* t695 = shen_intern(ctx, "cons");
  KLObject* t696;
  {
    KLObject* a696[] = {t640};
    t696 = shen_apply_direct(ctx, "shen.cons-form-respect-modes", 1, a696);
  }
  KLObject* t698;
  {
    KLObject* a698[] = {t642};
    t698 = shen_apply_direct(ctx, "shen.cons-form-respect-modes", 1, a698);
  }
  KLObject* t700 = shen_empty_list(ctx);
  KLObject* t701 = shen_cons(ctx, t698, t700);
  KLObject* t702 = shen_cons(ctx, t696, t701);
  KLObject* t703 = shen_cons(ctx, t695, t702);
    t681 = t703;
  }
    t662 = t681;
  }
    t643 = t662;
  }
    t636 = t643;
  } else {
  KLObject* t704;
  {
    KLObject* a704[] = {t633};
    t704 = shen_tail_apply_direct(ctx, "thaw", 1, a704);
  }
    t636 = t704;
  }
    return t636;
  }
}

static KLObject* native_kl_shen_2eprocess_2ddef_6 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t706 = objects[0];
    KLObject* t707 = objects[1];
  tail_start_kl_shen_2eprocess_2ddef_6: ;
  KLObject* t708 = shen_intern(ctx, "X");
  KLObject* t709 = shen_intern(ctx, "->");
  KLObject* t710 = shen_intern(ctx, "X");
  KLObject* t711 = shen_empty_list(ctx);
  KLObject* t712 = shen_cons(ctx, t710, t711);
  KLObject* t713 = shen_cons(ctx, t709, t712);
  KLObject* t714 = shen_cons(ctx, t708, t713);
  KLObject* t716 = shen_intern(ctx, "define");
  KLObject* t718;
  {
    KLObject* a718[] = {t707, t714};
    t718 = shen_apply_direct(ctx, "append", 2, a718);
  }
  KLObject* t721 = shen_cons(ctx, t706, t718);
  KLObject* t722 = shen_cons(ctx, t716, t721);
  KLObject* t715;
  {
    KLObject* a715[] = {t722};
    t715 = shen_apply_direct(ctx, "eval", 1, a715);
  }
  KLObject* t725;
  {
    KLObject* a725[] = {t706};
    t725 = shen_apply_direct(ctx, "fn", 1, a725);
  }
  KLObject* t723;
  {
    KLObject* a723[] = {t706, t725};
    t723 = shen_apply_direct(ctx, "shen.record-macro", 2, a723);
  }
    return t706;
  }
}

static KLObject* native_kl_shen_2eprocess_2dlet_7 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t728 = objects[0];
  tail_start_kl_shen_2eprocess_2dlet_7: ;
  KLObject* t732 = shen_cons_p(ctx, t728);
  KLObject* t730;
  if (!shen_is_boolean(ctx, t732))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t732)) {
    t730 = t732;
  } else {
  KLObject* t734 = shen_tl(ctx, t728);
  KLObject* t736 = shen_intern(ctx, "let");
  KLObject* t738 = shen_hd(ctx, t728);
  KLObject* t739 = shen_eq(ctx, t736, t738);
  KLObject* t735;
  if (!shen_is_boolean(ctx, t739))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t739)) {
    t735 = t739;
  } else {
  KLObject* t742 = shen_cons_p(ctx, t734);
  KLObject* t740;
  if (!shen_is_boolean(ctx, t742))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t742)) {
    t740 = t742;
  } else {
  KLObject* t744 = shen_tl(ctx, t734);
  KLObject* t747 = shen_cons_p(ctx, t744);
  KLObject* t745;
  if (!shen_is_boolean(ctx, t747))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t747)) {
    t745 = t747;
  } else {
  KLObject* t749 = shen_tl(ctx, t744);
  KLObject* t752 = shen_cons_p(ctx, t749);
  KLObject* t750;
  if (!shen_is_boolean(ctx, t752))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t752)) {
    t750 = t752;
  } else {
  KLObject* t754 = shen_tl(ctx, t749);
  KLObject* t755 = shen_cons_p(ctx, t754);
    if (!shen_is_boolean(ctx, t755))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t750 = t755;
  }
    if (!shen_is_boolean(ctx, t750))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t745 = t750;
  }
    if (!shen_is_boolean(ctx, t745))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t740 = t745;
  }
    if (!shen_is_boolean(ctx, t740))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t735 = t740;
  }
    if (!shen_is_boolean(ctx, t735))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t730 = t735;
  }
  KLObject* t729;
  if (!shen_is_boolean(ctx, t730))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t730)) {
  KLObject* t757 = shen_tl(ctx, t728);
  KLObject* t758 = shen_intern(ctx, "let");
  KLObject* t760 = shen_hd(ctx, t757);
  KLObject* t762 = shen_tl(ctx, t757);
  KLObject* t763 = shen_hd(ctx, t762);
  KLObject* t764 = shen_intern(ctx, "let");
  KLObject* t766 = shen_tl(ctx, t757);
  KLObject* t767 = shen_tl(ctx, t766);
  KLObject* t768 = shen_cons(ctx, t764, t767);
  KLObject* t769 = shen_empty_list(ctx);
  KLObject* t770 = shen_cons(ctx, t768, t769);
  KLObject* t771 = shen_cons(ctx, t763, t770);
  KLObject* t772 = shen_cons(ctx, t760, t771);
  KLObject* t773 = shen_cons(ctx, t758, t772);
    t729 = t773;
  } else {
    t729 = t728;
  }
    return t729;
  }
}

static KLObject* native_kl_shen_2eprocess_2d_40s_8 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t775 = objects[0];
  tail_start_kl_shen_2eprocess_2d_40s_8: ;
  KLObject* t776;
  {
    Vector* caps_6 = shen_vector(ctx, 1);
    shen_vector_set(ctx, caps_6, 0, t775);
    t776 = shen_native_closure(ctx, 0, &lambda_6, caps_6);
  }
  KLObject* t781 = shen_cons_p(ctx, t775);
  KLObject* t779;
  if (!shen_is_boolean(ctx, t781))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t781)) {
  KLObject* t783 = shen_tl(ctx, t775);
  KLObject* t785 = shen_intern(ctx, "@s");
  KLObject* t787 = shen_hd(ctx, t775);
  KLObject* t788 = shen_eq(ctx, t785, t787);
  KLObject* t784;
  if (!shen_is_boolean(ctx, t788))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t788)) {
  KLObject* t791 = shen_cons_p(ctx, t783);
  KLObject* t789;
  if (!shen_is_boolean(ctx, t791))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t791)) {
  KLObject* t793 = shen_hd(ctx, t783);
  KLObject* t795 = shen_tl(ctx, t783);
  KLObject* t798 = shen_cons_p(ctx, t795);
  KLObject* t796;
  if (!shen_is_boolean(ctx, t798))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t798)) {
  KLObject* t800 = shen_tl(ctx, t795);
  KLObject* t803 = shen_cons_p(ctx, t800);
  KLObject* t801;
  if (!shen_is_boolean(ctx, t803))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t803)) {
  KLObject* t804 = shen_intern(ctx, "@s");
  KLObject* t807 = shen_intern(ctx, "@s");
  KLObject* t809 = shen_cons(ctx, t807, t795);
  KLObject* t806;
  {
    KLObject* a806[] = {t809};
    t806 = shen_apply_direct(ctx, "shen.process-@s", 1, a806);
  }
  KLObject* t810 = shen_empty_list(ctx);
  KLObject* t811 = shen_cons(ctx, t806, t810);
  KLObject* t812 = shen_cons(ctx, t793, t811);
  KLObject* t813 = shen_cons(ctx, t804, t812);
    t801 = t813;
  } else {
  KLObject* t816 = shen_empty_list(ctx);
  KLObject* t818 = shen_eq(ctx, t816, t800);
  KLObject* t815;
  if (!shen_is_boolean(ctx, t818))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t818)) {
    t815 = t818;
  } else {
  KLObject* t820 = shen_string_p(ctx, t793);
    if (!shen_is_boolean(ctx, t820))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t815 = t820;
  }
  KLObject* t814;
  if (!shen_is_boolean(ctx, t815))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t815)) {
  KLObject* t821;
  {
    KLObject* a821[] = {t793};
    t821 = shen_apply_direct(ctx, "explode", 1, a821);
  }
  KLObject* t824;
  {
    KLObject* a824[] = {t821};
    t824 = shen_apply_direct(ctx, "length", 1, a824);
  }
  KLObject* t826 = shen_number_l(ctx, 1);
  KLObject* t827 = shen_gt(ctx, t824, t826);
  KLObject* t823;
  if (!shen_is_boolean(ctx, t827))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t827)) {
  KLObject* t828 = shen_intern(ctx, "@s");
  KLObject* t829;
  {
    KLObject* a829[] = {t821, t795};
    t829 = shen_apply_direct(ctx, "append", 2, a829);
  }
  KLObject* t832 = shen_cons(ctx, t828, t829);
  {
    KLObject* n833_0 = t832;
    t775 = n833_0;
    goto tail_start_kl_shen_2eprocess_2d_40s_8;
  }
  KLObject* t833 = NULL;
    t823 = t833;
  } else {
    t823 = t775;
  }
    t814 = t823;
  } else {
  KLObject* t835;
  {
    KLObject* a835[] = {t776};
    t835 = shen_tail_apply_direct(ctx, "thaw", 1, a835);
  }
    t814 = t835;
  }
    t801 = t814;
  }
    t796 = t801;
  } else {
  KLObject* t837;
  {
    KLObject* a837[] = {t776};
    t837 = shen_tail_apply_direct(ctx, "thaw", 1, a837);
  }
    t796 = t837;
  }
    t789 = t796;
  } else {
  KLObject* t839;
  {
    KLObject* a839[] = {t776};
    t839 = shen_tail_apply_direct(ctx, "thaw", 1, a839);
  }
    t789 = t839;
  }
    t784 = t789;
  } else {
  KLObject* t841;
  {
    KLObject* a841[] = {t776};
    t841 = shen_tail_apply_direct(ctx, "thaw", 1, a841);
  }
    t784 = t841;
  }
    t779 = t784;
  } else {
  KLObject* t843;
  {
    KLObject* a843[] = {t776};
    t843 = shen_tail_apply_direct(ctx, "thaw", 1, a843);
  }
    t779 = t843;
  }
    return t779;
  }
}

static KLObject* native_kl_shen_2eprocess_2ddatatype_9 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t845 = objects[0];
    KLObject* t846 = objects[1];
  tail_start_kl_shen_2eprocess_2ddatatype_9: ;
  KLObject* t847;
  {
    KLObject* a847[] = {t845};
    t847 = shen_apply_direct(ctx, "shen.intern-type", 1, a847);
  }
  KLObject* t850;
  {
    Vector* caps_7 = shen_vector(ctx, 0);
    t850 = shen_native_closure(ctx, 1, &lambda_7, caps_7);
  }
  KLObject* t856 = shen_cons(ctx, t847, t846);
  KLObject* t849;
  {
    KLObject* a849[] = {t850, t856};
    t849 = shen_apply_direct(ctx, "compile", 2, a849);
  }
    return t847;
  }
}

static KLObject* native_kl_shen_2eintern_2dtype_10 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t858 = objects[0];
  tail_start_kl_shen_2eintern_2dtype_10: ;
  KLObject* t861;
  {
    KLObject* a861[] = {t858};
    t861 = shen_apply_direct(ctx, "str", 1, a861);
  }
  KLObject* t863 = shen_string(ctx, "#type");
  KLObject* t860;
  {
    KLObject* a860[] = {t861, t863};
    t860 = shen_apply_direct(ctx, "cn", 2, a860);
  }
  KLObject* t859;
  {
    KLObject* a859[] = {t860};
    t859 = shen_tail_apply_direct(ctx, "intern", 1, a859);
  }
    return t859;
  }
}

static KLObject* native_kl_shen_2eprocess_2dsynonyms_11 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t864 = objects[0];
  tail_start_kl_shen_2eprocess_2dsynonyms_11: ;
  KLObject* t867 = shen_intern(ctx, "shen.*synonyms*");
  KLObject* t871 = shen_intern(ctx, "shen.*synonyms*");
  KLObject* t870;
  {
    KLObject* a870[] = {t871};
    t870 = shen_apply_direct(ctx, "value", 1, a870);
  }
  KLObject* t868;
  {
    KLObject* a868[] = {t864, t870};
    t868 = shen_apply_direct(ctx, "append", 2, a868);
  }
  KLObject* t866;
  {
    KLObject* a866[] = {t867, t868};
    t866 = shen_apply_direct(ctx, "set", 2, a866);
  }
  KLObject* t865;
  {
    KLObject* a865[] = {t866};
    t865 = shen_tail_apply_direct(ctx, "shen.synonyms-h", 1, a865);
  }
    return t865;
  }
}

static KLObject* native_kl_shen_2esynonyms_2dh_12 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t872 = objects[0];
  tail_start_kl_shen_2esynonyms_2dh_12: ;
  KLObject* t874;
  {
    Vector* caps_8 = shen_vector(ctx, 0);
    t874 = shen_native_closure(ctx, 1, &lambda_8, caps_8);
  }
  KLObject* t873;
  {
    KLObject* a873[] = {t874, t872};
    t873 = shen_apply_direct(ctx, "map", 2, a873);
  }
  KLObject* t880 = shen_intern(ctx, "define");
  KLObject* t881 = shen_intern(ctx, "shen.demod");
  KLObject* t882;
  {
    KLObject* a882[] = {t873};
    t882 = shen_apply_direct(ctx, "shen.compile-synonyms", 1, a882);
  }
  KLObject* t884 = shen_cons(ctx, t881, t882);
  KLObject* t885 = shen_cons(ctx, t880, t884);
  KLObject* t879;
  {
    KLObject* a879[] = {t885};
    t879 = shen_apply_direct(ctx, "eval", 1, a879);
  }
  KLObject* t886 = shen_intern(ctx, "synonyms");
    return t886;
  }
}

static KLObject* native_kl_shen_2ecompile_2dsynonyms_13 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t887 = objects[0];
  tail_start_kl_shen_2ecompile_2dsynonyms_13: ;
  KLObject* t889 = shen_empty_list(ctx);
  KLObject* t891 = shen_eq(ctx, t889, t887);
  KLObject* t888;
  if (!shen_is_boolean(ctx, t891))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t891)) {
  KLObject* t893 = shen_intern(ctx, "X");
  KLObject* t892;
  {
    KLObject* a892[] = {t893};
    t892 = shen_apply_direct(ctx, "gensym", 1, a892);
  }
  KLObject* t895 = shen_intern(ctx, "->");
  KLObject* t897 = shen_empty_list(ctx);
  KLObject* t898 = shen_cons(ctx, t892, t897);
  KLObject* t899 = shen_cons(ctx, t895, t898);
  KLObject* t900 = shen_cons(ctx, t892, t899);
    t888 = t900;
  } else {
  KLObject* t904 = shen_cons_p(ctx, t887);
  KLObject* t902;
  if (!shen_is_boolean(ctx, t904))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t904)) {
    t902 = t904;
  } else {
  KLObject* t906 = shen_tl(ctx, t887);
  KLObject* t907 = shen_cons_p(ctx, t906);
    if (!shen_is_boolean(ctx, t907))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t902 = t907;
  }
  KLObject* t901;
  if (!shen_is_boolean(ctx, t902))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t902)) {
  KLObject* t909 = shen_tl(ctx, t887);
  KLObject* t912 = shen_hd(ctx, t887);
  KLObject* t910;
  {
    KLObject* a910[] = {t912};
    t910 = shen_apply_direct(ctx, "shen.rcons_form", 1, a910);
  }
  KLObject* t913 = shen_intern(ctx, "->");
  KLObject* t916 = shen_hd(ctx, t909);
  KLObject* t914;
  {
    KLObject* a914[] = {t916};
    t914 = shen_apply_direct(ctx, "shen.rcons_form", 1, a914);
  }
  KLObject* t919 = shen_tl(ctx, t909);
  KLObject* t917;
  {
    KLObject* a917[] = {t919};
    t917 = shen_apply_direct(ctx, "shen.compile-synonyms", 1, a917);
  }
  KLObject* t920 = shen_cons(ctx, t914, t917);
  KLObject* t921 = shen_cons(ctx, t913, t920);
  KLObject* t922 = shen_cons(ctx, t910, t921);
    t901 = t922;
  } else {
  KLObject* t924 = shen_string(ctx, "synonyms requires an even number of arguments\n");
  KLObject* t923;
  {
    KLObject* a923[] = {t924};
    t923 = shen_tail_apply_direct(ctx, "simple-error", 1, a923);
  }
    t901 = t923;
  }
    t888 = t901;
  }
    return t888;
  }
}

static KLObject* native_kl_shen_2eprocess_2dlambda_14 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t925 = objects[0];
  tail_start_kl_shen_2eprocess_2dlambda_14: ;
  KLObject* t926;
  {
    Vector* caps_9 = shen_vector(ctx, 1);
    shen_vector_set(ctx, caps_9, 0, t925);
    t926 = shen_native_closure(ctx, 0, &lambda_9, caps_9);
  }
  KLObject* t931 = shen_cons_p(ctx, t925);
  KLObject* t929;
  if (!shen_is_boolean(ctx, t931))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t931)) {
  KLObject* t933 = shen_tl(ctx, t925);
  KLObject* t935 = shen_intern(ctx, "/.");
  KLObject* t937 = shen_hd(ctx, t925);
  KLObject* t938 = shen_eq(ctx, t935, t937);
  KLObject* t934;
  if (!shen_is_boolean(ctx, t938))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t938)) {
  KLObject* t941 = shen_cons_p(ctx, t933);
  KLObject* t939;
  if (!shen_is_boolean(ctx, t941))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t941)) {
  KLObject* t943 = shen_hd(ctx, t933);
  KLObject* t945 = shen_tl(ctx, t933);
  KLObject* t948 = shen_cons_p(ctx, t945);
  KLObject* t946;
  if (!shen_is_boolean(ctx, t948))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t948)) {
  KLObject* t950 = shen_tl(ctx, t945);
  KLObject* t953 = shen_cons_p(ctx, t950);
  KLObject* t951;
  if (!shen_is_boolean(ctx, t953))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t953)) {
  KLObject* t954 = shen_intern(ctx, "lambda");
  KLObject* t957 = shen_intern(ctx, "/.");
  KLObject* t959 = shen_cons(ctx, t957, t945);
  KLObject* t956;
  {
    KLObject* a956[] = {t959};
    t956 = shen_apply_direct(ctx, "shen.process-lambda", 1, a956);
  }
  KLObject* t960 = shen_empty_list(ctx);
  KLObject* t961 = shen_cons(ctx, t956, t960);
  KLObject* t962 = shen_cons(ctx, t943, t961);
  KLObject* t963 = shen_cons(ctx, t954, t962);
    t951 = t963;
  } else {
  KLObject* t965 = shen_empty_list(ctx);
  KLObject* t967 = shen_eq(ctx, t965, t950);
  KLObject* t964;
  if (!shen_is_boolean(ctx, t967))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t967)) {
  KLObject* t969;
  {
    KLObject* a969[] = {t943};
    t969 = shen_apply_direct(ctx, "variable?", 1, a969);
  }
  KLObject* t968;
  if (!shen_is_boolean(ctx, t969))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t969)) {
  KLObject* t971 = shen_intern(ctx, "lambda");
  KLObject* t973 = shen_cons(ctx, t971, t933);
    t968 = t973;
  } else {
  KLObject* t977 = shen_string(ctx, " is not a variable\n");
  KLObject* t978 = shen_intern(ctx, "shen.s");
  KLObject* t975;
  {
    KLObject* a975[] = {t943, t977, t978};
    t975 = shen_apply_direct(ctx, "shen.app", 3, a975);
  }
  KLObject* t974;
  {
    KLObject* a974[] = {t975};
    t974 = shen_tail_apply_direct(ctx, "simple-error", 1, a974);
  }
    t968 = t974;
  }
    t964 = t968;
  } else {
  KLObject* t979;
  {
    KLObject* a979[] = {t926};
    t979 = shen_tail_apply_direct(ctx, "thaw", 1, a979);
  }
    t964 = t979;
  }
    t951 = t964;
  }
    t946 = t951;
  } else {
  KLObject* t981;
  {
    KLObject* a981[] = {t926};
    t981 = shen_tail_apply_direct(ctx, "thaw", 1, a981);
  }
    t946 = t981;
  }
    t939 = t946;
  } else {
  KLObject* t983;
  {
    KLObject* a983[] = {t926};
    t983 = shen_tail_apply_direct(ctx, "thaw", 1, a983);
  }
    t939 = t983;
  }
    t934 = t939;
  } else {
  KLObject* t985;
  {
    KLObject* a985[] = {t926};
    t985 = shen_tail_apply_direct(ctx, "thaw", 1, a985);
  }
    t934 = t985;
  }
    t929 = t934;
  } else {
  KLObject* t987;
  {
    KLObject* a987[] = {t926};
    t987 = shen_tail_apply_direct(ctx, "thaw", 1, a987);
  }
    t929 = t987;
  }
    return t929;
  }
}

static KLObject* native_kl_shen_2eprocess_2dcases_15 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t989 = objects[0];
  tail_start_kl_shen_2eprocess_2dcases_15: ;
  KLObject* t990;
  {
    Vector* caps_10 = shen_vector(ctx, 1);
    shen_vector_set(ctx, caps_10, 0, t989);
    t990 = shen_native_closure(ctx, 0, &lambda_10, caps_10);
  }
  KLObject* t995 = shen_cons_p(ctx, t989);
  KLObject* t993;
  if (!shen_is_boolean(ctx, t995))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t995)) {
  KLObject* t997 = shen_tl(ctx, t989);
  KLObject* t999 = shen_intern(ctx, "cases");
  KLObject* t1001 = shen_hd(ctx, t989);
  KLObject* t1002 = shen_eq(ctx, t999, t1001);
  KLObject* t998;
  if (!shen_is_boolean(ctx, t1002))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1002)) {
  KLObject* t1005 = shen_cons_p(ctx, t997);
  KLObject* t1003;
  if (!shen_is_boolean(ctx, t1005))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1005)) {
  KLObject* t1007 = shen_hd(ctx, t997);
  KLObject* t1009 = shen_tl(ctx, t997);
  KLObject* t1012 = shen_true(ctx);
  KLObject* t1014 = shen_eq(ctx, t1012, t1007);
  KLObject* t1011;
  if (!shen_is_boolean(ctx, t1014))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t1014)) {
    t1011 = t1014;
  } else {
  KLObject* t1016 = shen_cons_p(ctx, t1009);
    if (!shen_is_boolean(ctx, t1016))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t1011 = t1016;
  }
  KLObject* t1010;
  if (!shen_is_boolean(ctx, t1011))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1011)) {
  KLObject* t1018 = shen_hd(ctx, t1009);
    t1010 = t1018;
  } else {
  KLObject* t1019;
  {
    Vector* caps_11 = shen_vector(ctx, 2);
    shen_vector_set(ctx, caps_11, 0, t1009);
    shen_vector_set(ctx, caps_11, 1, t990);
    t1019 = shen_native_closure(ctx, 0, &lambda_11, caps_11);
  }
  KLObject* t1032 = shen_cons_p(ctx, t1009);
  KLObject* t1030;
  if (!shen_is_boolean(ctx, t1032))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1032)) {
  KLObject* t1034 = shen_hd(ctx, t1009);
  KLObject* t1036 = shen_tl(ctx, t1009);
  KLObject* t1038 = shen_empty_list(ctx);
  KLObject* t1040 = shen_eq(ctx, t1038, t1036);
  KLObject* t1037;
  if (!shen_is_boolean(ctx, t1040))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1040)) {
  KLObject* t1041 = shen_intern(ctx, "if");
  KLObject* t1044 = shen_intern(ctx, "simple-error");
  KLObject* t1045 = shen_string(ctx, "error: cases exhausted");
  KLObject* t1046 = shen_empty_list(ctx);
  KLObject* t1047 = shen_cons(ctx, t1045, t1046);
  KLObject* t1048 = shen_cons(ctx, t1044, t1047);
  KLObject* t1049 = shen_empty_list(ctx);
  KLObject* t1050 = shen_cons(ctx, t1048, t1049);
  KLObject* t1051 = shen_cons(ctx, t1034, t1050);
  KLObject* t1052 = shen_cons(ctx, t1007, t1051);
  KLObject* t1053 = shen_cons(ctx, t1041, t1052);
    t1037 = t1053;
  } else {
  KLObject* t1054 = shen_intern(ctx, "if");
  KLObject* t1058 = shen_intern(ctx, "cases");
  KLObject* t1060 = shen_cons(ctx, t1058, t1036);
  KLObject* t1057;
  {
    KLObject* a1057[] = {t1060};
    t1057 = shen_apply_direct(ctx, "shen.process-cases", 1, a1057);
  }
  KLObject* t1061 = shen_empty_list(ctx);
  KLObject* t1062 = shen_cons(ctx, t1057, t1061);
  KLObject* t1063 = shen_cons(ctx, t1034, t1062);
  KLObject* t1064 = shen_cons(ctx, t1007, t1063);
  KLObject* t1065 = shen_cons(ctx, t1054, t1064);
    t1037 = t1065;
  }
    t1030 = t1037;
  } else {
  KLObject* t1066;
  {
    KLObject* a1066[] = {t1019};
    t1066 = shen_tail_apply_direct(ctx, "thaw", 1, a1066);
  }
    t1030 = t1066;
  }
    t1010 = t1030;
  }
    t1003 = t1010;
  } else {
  KLObject* t1068;
  {
    KLObject* a1068[] = {t990};
    t1068 = shen_tail_apply_direct(ctx, "thaw", 1, a1068);
  }
    t1003 = t1068;
  }
    t998 = t1003;
  } else {
  KLObject* t1070;
  {
    KLObject* a1070[] = {t990};
    t1070 = shen_tail_apply_direct(ctx, "thaw", 1, a1070);
  }
    t998 = t1070;
  }
    t993 = t998;
  } else {
  KLObject* t1072;
  {
    KLObject* a1072[] = {t990};
    t1072 = shen_tail_apply_direct(ctx, "thaw", 1, a1072);
  }
    t993 = t1072;
  }
    return t993;
  }
}

static KLObject* native_kl_shen_2eprocess_2dtime_16 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t1074 = objects[0];
  tail_start_kl_shen_2eprocess_2dtime_16: ;
  KLObject* t1075 = shen_intern(ctx, "let");
  KLObject* t1076 = shen_intern(ctx, "Start");
  KLObject* t1077 = shen_intern(ctx, "get-time");
  KLObject* t1078 = shen_intern(ctx, "run");
  KLObject* t1079 = shen_empty_list(ctx);
  KLObject* t1080 = shen_cons(ctx, t1078, t1079);
  KLObject* t1081 = shen_cons(ctx, t1077, t1080);
  KLObject* t1082 = shen_intern(ctx, "Result");
  KLObject* t1084 = shen_intern(ctx, "Finish");
  KLObject* t1085 = shen_intern(ctx, "get-time");
  KLObject* t1086 = shen_intern(ctx, "run");
  KLObject* t1087 = shen_empty_list(ctx);
  KLObject* t1088 = shen_cons(ctx, t1086, t1087);
  KLObject* t1089 = shen_cons(ctx, t1085, t1088);
  KLObject* t1090 = shen_intern(ctx, "Time");
  KLObject* t1091 = shen_intern(ctx, "-");
  KLObject* t1092 = shen_intern(ctx, "Finish");
  KLObject* t1093 = shen_intern(ctx, "Start");
  KLObject* t1094 = shen_empty_list(ctx);
  KLObject* t1095 = shen_cons(ctx, t1093, t1094);
  KLObject* t1096 = shen_cons(ctx, t1092, t1095);
  KLObject* t1097 = shen_cons(ctx, t1091, t1096);
  KLObject* t1098 = shen_intern(ctx, "Message");
  KLObject* t1099 = shen_intern(ctx, "pr");
  KLObject* t1100 = shen_intern(ctx, "cn");
  KLObject* t1101 = shen_string(ctx, "\nrun time: ");
  KLObject* t1102 = shen_intern(ctx, "cn");
  KLObject* t1103 = shen_intern(ctx, "str");
  KLObject* t1104 = shen_intern(ctx, "Time");
  KLObject* t1105 = shen_empty_list(ctx);
  KLObject* t1106 = shen_cons(ctx, t1104, t1105);
  KLObject* t1107 = shen_cons(ctx, t1103, t1106);
  KLObject* t1108 = shen_string(ctx, " secs\n");
  KLObject* t1109 = shen_empty_list(ctx);
  KLObject* t1110 = shen_cons(ctx, t1108, t1109);
  KLObject* t1111 = shen_cons(ctx, t1107, t1110);
  KLObject* t1112 = shen_cons(ctx, t1102, t1111);
  KLObject* t1113 = shen_empty_list(ctx);
  KLObject* t1114 = shen_cons(ctx, t1112, t1113);
  KLObject* t1115 = shen_cons(ctx, t1101, t1114);
  KLObject* t1116 = shen_cons(ctx, t1100, t1115);
  KLObject* t1117 = shen_intern(ctx, "stoutput");
  KLObject* t1118 = shen_empty_list(ctx);
  KLObject* t1119 = shen_cons(ctx, t1117, t1118);
  KLObject* t1120 = shen_empty_list(ctx);
  KLObject* t1121 = shen_cons(ctx, t1119, t1120);
  KLObject* t1122 = shen_cons(ctx, t1116, t1121);
  KLObject* t1123 = shen_cons(ctx, t1099, t1122);
  KLObject* t1124 = shen_intern(ctx, "Result");
  KLObject* t1125 = shen_empty_list(ctx);
  KLObject* t1126 = shen_cons(ctx, t1124, t1125);
  KLObject* t1127 = shen_cons(ctx, t1123, t1126);
  KLObject* t1128 = shen_cons(ctx, t1098, t1127);
  KLObject* t1129 = shen_cons(ctx, t1097, t1128);
  KLObject* t1130 = shen_cons(ctx, t1090, t1129);
  KLObject* t1131 = shen_cons(ctx, t1089, t1130);
  KLObject* t1132 = shen_cons(ctx, t1084, t1131);
  KLObject* t1133 = shen_cons(ctx, t1074, t1132);
  KLObject* t1134 = shen_cons(ctx, t1082, t1133);
  KLObject* t1135 = shen_cons(ctx, t1081, t1134);
  KLObject* t1136 = shen_cons(ctx, t1076, t1135);
  KLObject* t1137 = shen_cons(ctx, t1075, t1136);
    return t1137;
  }
}

static KLObject* native_kl_shen_2eprocess_2dassoc_17 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t1138 = objects[0];
  tail_start_kl_shen_2eprocess_2dassoc_17: ;
  KLObject* t1142 = shen_cons_p(ctx, t1138);
  KLObject* t1140;
  if (!shen_is_boolean(ctx, t1142))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t1142)) {
    t1140 = t1142;
  } else {
  KLObject* t1144 = shen_tl(ctx, t1138);
  KLObject* t1147 = shen_cons_p(ctx, t1144);
  KLObject* t1145;
  if (!shen_is_boolean(ctx, t1147))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t1147)) {
    t1145 = t1147;
  } else {
  KLObject* t1149 = shen_tl(ctx, t1144);
  KLObject* t1152 = shen_cons_p(ctx, t1149);
  KLObject* t1150;
  if (!shen_is_boolean(ctx, t1152))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t1152)) {
    t1150 = t1152;
  } else {
  KLObject* t1154 = shen_tl(ctx, t1149);
  KLObject* t1155 = shen_cons_p(ctx, t1154);
    if (!shen_is_boolean(ctx, t1155))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t1150 = t1155;
  }
    if (!shen_is_boolean(ctx, t1150))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t1145 = t1150;
  }
    if (!shen_is_boolean(ctx, t1145))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t1140 = t1145;
  }
  KLObject* t1139;
  if (!shen_is_boolean(ctx, t1140))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1140)) {
  KLObject* t1157 = shen_hd(ctx, t1138);
  KLObject* t1159 = shen_tl(ctx, t1138);
  KLObject* t1162 = shen_hd(ctx, t1159);
  KLObject* t1165 = shen_tl(ctx, t1159);
  KLObject* t1166 = shen_cons(ctx, t1157, t1165);
  KLObject* t1167 = shen_empty_list(ctx);
  KLObject* t1168 = shen_cons(ctx, t1166, t1167);
  KLObject* t1169 = shen_cons(ctx, t1162, t1168);
  KLObject* t1170 = shen_cons(ctx, t1157, t1169);
    t1139 = t1170;
  } else {
    t1139 = t1138;
  }
    return t1139;
  }
}

static KLObject* native_kl_shen_2emake_2duppercase_18 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t1172 = objects[0];
  tail_start_kl_shen_2emake_2duppercase_18: ;
  KLObject* t1175;
  {
    KLObject* a1175[] = {t1172};
    t1175 = shen_apply_direct(ctx, "str", 1, a1175);
  }
  KLObject* t1174;
  {
    KLObject* a1174[] = {t1175};
    t1174 = shen_apply_direct(ctx, "shen.mu-h", 1, a1174);
  }
  KLObject* t1173;
  {
    KLObject* a1173[] = {t1174};
    t1173 = shen_tail_apply_direct(ctx, "intern", 1, a1173);
  }
    return t1173;
  }
}

static KLObject* native_kl_shen_2emu_2dh_19 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t1177 = objects[0];
  tail_start_kl_shen_2emu_2dh_19: ;
  KLObject* t1179 = shen_string(ctx, "");
  KLObject* t1181 = shen_eq(ctx, t1179, t1177);
  KLObject* t1178;
  if (!shen_is_boolean(ctx, t1181))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1181)) {
  KLObject* t1182 = shen_string(ctx, "");
    t1178 = t1182;
  } else {
  KLObject* t1184;
  {
    KLObject* a1184[] = {t1177};
    t1184 = shen_apply_direct(ctx, "shen.+string?", 1, a1184);
  }
  KLObject* t1183;
  if (!shen_is_boolean(ctx, t1184))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1184)) {
  KLObject* t1187;
  {
    KLObject* a1187[] = {t1177};
    t1187 = shen_apply_direct(ctx, "hdstr", 1, a1187);
  }
  KLObject* t1186;
  {
    KLObject* a1186[] = {t1187};
    t1186 = shen_apply_direct(ctx, "string->n", 1, a1186);
  }
  KLObject* t1190 = shen_number_l(ctx, 32);
  KLObject* t1191 = shen_sub(ctx, t1186, t1190);
  KLObject* t1195 = shen_number_l(ctx, 97);
  KLObject* t1196 = shen_gte(ctx, t1186, t1195);
  KLObject* t1193;
  if (!shen_is_boolean(ctx, t1196))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t1196)) {
    t1193 = t1196;
  } else {
  KLObject* t1198 = shen_number_l(ctx, 122);
  KLObject* t1199 = shen_lte(ctx, t1186, t1198);
    if (!shen_is_boolean(ctx, t1199))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t1193 = t1199;
  }
  KLObject* t1192;
  if (!shen_is_boolean(ctx, t1193))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1193)) {
  KLObject* t1200;
  {
    KLObject* a1200[] = {t1191};
    t1200 = shen_apply_direct(ctx, "n->string", 1, a1200);
  }
    t1192 = t1200;
  } else {
  KLObject* t1202;
  {
    KLObject* a1202[] = {t1177};
    t1202 = shen_apply_direct(ctx, "hdstr", 1, a1202);
  }
    t1192 = t1202;
  }
  KLObject* t1207;
  {
    KLObject* a1207[] = {t1177};
    t1207 = shen_apply_direct(ctx, "tlstr", 1, a1207);
  }
  KLObject* t1206;
  {
    KLObject* a1206[] = {t1207};
    t1206 = shen_apply_direct(ctx, "shen.mu-h", 1, a1206);
  }
  KLObject* t1204;
  {
    KLObject* a1204[] = {t1192, t1206};
    t1204 = shen_tail_apply_direct(ctx, "@s", 2, a1204);
  }
    t1183 = t1204;
  } else {
  KLObject* t1210 = shen_string(ctx, "partial function shen.mu-h");
  KLObject* t1209;
  {
    KLObject* a1209[] = {t1210};
    t1209 = shen_tail_apply_direct(ctx, "simple-error", 1, a1209);
  }
    t1183 = t1209;
  }
    t1178 = t1183;
  }
    return t1178;
  }
}

static KLObject* native_kl_shen_2erecord_2dmacro_20 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t1211 = objects[0];
    KLObject* t1212 = objects[1];
  tail_start_kl_shen_2erecord_2dmacro_20: ;
  KLObject* t1214 = shen_intern(ctx, "*macros*");
  KLObject* t1219 = shen_intern(ctx, "*macros*");
  KLObject* t1218;
  {
    KLObject* a1218[] = {t1219};
    t1218 = shen_apply_direct(ctx, "value", 1, a1218);
  }
  KLObject* t1215;
  {
    KLObject* a1215[] = {t1211, t1212, t1218};
    t1215 = shen_apply_direct(ctx, "shen.update-assoc", 3, a1215);
  }
  KLObject* t1213;
  {
    KLObject* a1213[] = {t1214, t1215};
    t1213 = shen_tail_apply_direct(ctx, "set", 2, a1213);
  }
    return t1213;
  }
}

static KLObject* native_kl_shen_2eupdate_2dassoc_21 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t1220 = objects[0];
    KLObject* t1221 = objects[1];
    KLObject* t1222 = objects[2];
  tail_start_kl_shen_2eupdate_2dassoc_21: ;
  KLObject* t1224 = shen_empty_list(ctx);
  KLObject* t1226 = shen_eq(ctx, t1224, t1222);
  KLObject* t1223;
  if (!shen_is_boolean(ctx, t1226))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1226)) {
  KLObject* t1229 = shen_cons(ctx, t1220, t1221);
  KLObject* t1230 = shen_empty_list(ctx);
  KLObject* t1231 = shen_cons(ctx, t1229, t1230);
    t1223 = t1231;
  } else {
  KLObject* t1232;
  {
    Vector* caps_12 = shen_vector(ctx, 0);
    t1232 = shen_native_closure(ctx, 0, &lambda_12, caps_12);
  }
  KLObject* t1237 = shen_cons_p(ctx, t1222);
  KLObject* t1235;
  if (!shen_is_boolean(ctx, t1237))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1237)) {
  KLObject* t1239 = shen_hd(ctx, t1222);
  KLObject* t1241 = shen_tl(ctx, t1222);
  KLObject* t1245 = shen_cons_p(ctx, t1239);
  KLObject* t1243;
  if (!shen_is_boolean(ctx, t1245))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t1245)) {
    t1243 = t1245;
  } else {
  KLObject* t1248 = shen_hd(ctx, t1239);
  KLObject* t1249 = shen_eq(ctx, t1220, t1248);
    if (!shen_is_boolean(ctx, t1249))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t1243 = t1249;
  }
  KLObject* t1242;
  if (!shen_is_boolean(ctx, t1243))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1243)) {
  KLObject* t1251 = shen_hd(ctx, t1239);
  KLObject* t1253 = shen_cons(ctx, t1251, t1221);
  KLObject* t1255 = shen_cons(ctx, t1253, t1241);
    t1242 = t1255;
  } else {
  KLObject* t1257;
  {
    KLObject* a1257[] = {t1220, t1221, t1241};
    t1257 = shen_apply_direct(ctx, "shen.update-assoc", 3, a1257);
  }
  KLObject* t1261 = shen_cons(ctx, t1239, t1257);
    t1242 = t1261;
  }
    t1235 = t1242;
  } else {
  KLObject* t1262;
  {
    KLObject* a1262[] = {t1232};
    t1262 = shen_tail_apply_direct(ctx, "thaw", 1, a1262);
  }
    t1235 = t1262;
  }
    t1223 = t1235;
  }
    return t1223;
  }
}

static KLObject* native_kl_shen_2eprocess_2dread_2dbyte_22 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  (void)function_object;
  (void)arguments;
  {
  tail_start_kl_shen_2eprocess_2dread_2dbyte_22: ;
  KLObject* t1266 = shen_apply_direct(ctx, "stinput", 0, NULL);
  KLObject* t1265;
  {
    KLObject* a1265[] = {t1266};
    t1265 = shen_apply_direct(ctx, "char-stream?", 1, a1265);
  }
  KLObject* t1264;
  if (!shen_is_boolean(ctx, t1265))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1265)) {
  KLObject* t1267 = shen_intern(ctx, "string->n");
  KLObject* t1268 = shen_intern(ctx, "read-unit-string");
  KLObject* t1269 = shen_intern(ctx, "stinput");
  KLObject* t1270 = shen_empty_list(ctx);
  KLObject* t1271 = shen_cons(ctx, t1269, t1270);
  KLObject* t1272 = shen_empty_list(ctx);
  KLObject* t1273 = shen_cons(ctx, t1271, t1272);
  KLObject* t1274 = shen_cons(ctx, t1268, t1273);
  KLObject* t1275 = shen_empty_list(ctx);
  KLObject* t1276 = shen_cons(ctx, t1274, t1275);
  KLObject* t1277 = shen_cons(ctx, t1267, t1276);
    t1264 = t1277;
  } else {
  KLObject* t1278 = shen_intern(ctx, "read-byte");
  KLObject* t1279 = shen_intern(ctx, "stinput");
  KLObject* t1280 = shen_empty_list(ctx);
  KLObject* t1281 = shen_cons(ctx, t1279, t1280);
  KLObject* t1282 = shen_empty_list(ctx);
  KLObject* t1283 = shen_cons(ctx, t1281, t1282);
  KLObject* t1284 = shen_cons(ctx, t1278, t1283);
    t1264 = t1284;
  }
    return t1264;
  }
}

static KLObject* native_kl_shen_2ecall_2dprolog_23 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t1285 = objects[0];
  tail_start_kl_shen_2ecall_2dprolog_23: ;
  KLObject* t1286 = shen_intern(ctx, "shen.prolog-vector");
  KLObject* t1287 = shen_empty_list(ctx);
  KLObject* t1288 = shen_cons(ctx, t1286, t1287);
  KLObject* t1289 = shen_intern(ctx, "@v");
  KLObject* t1290 = shen_true(ctx);
  KLObject* t1291 = shen_number_l(ctx, 0);
  KLObject* t1292 = shen_intern(ctx, "vector");
  KLObject* t1293 = shen_number_l(ctx, 0);
  KLObject* t1294 = shen_empty_list(ctx);
  KLObject* t1295 = shen_cons(ctx, t1293, t1294);
  KLObject* t1296 = shen_cons(ctx, t1292, t1295);
  KLObject* t1297 = shen_empty_list(ctx);
  KLObject* t1298 = shen_cons(ctx, t1296, t1297);
  KLObject* t1299 = shen_cons(ctx, t1291, t1298);
  KLObject* t1300 = shen_cons(ctx, t1290, t1299);
  KLObject* t1301 = shen_cons(ctx, t1289, t1300);
  KLObject* t1302 = shen_number_l(ctx, 0);
  KLObject* t1303 = shen_intern(ctx, "freeze");
  KLObject* t1304 = shen_true(ctx);
  KLObject* t1305 = shen_empty_list(ctx);
  KLObject* t1306 = shen_cons(ctx, t1304, t1305);
  KLObject* t1307 = shen_cons(ctx, t1303, t1306);
  KLObject* t1309;
  {
    Vector* caps_13 = shen_vector(ctx, 0);
    t1309 = shen_native_closure(ctx, 1, &lambda_13, caps_13);
  }
  KLObject* t1308;
  {
    KLObject* a1308[] = {t1309, t1285};
    t1308 = shen_apply_direct(ctx, "compile", 2, a1308);
  }
  KLObject* t1314;
  {
    KLObject* a1314[] = {t1285};
    t1314 = shen_apply_direct(ctx, "shen.received", 1, a1314);
  }
  KLObject* t1317 = shen_intern(ctx, "V");
  KLObject* t1316;
  {
    KLObject* a1316[] = {t1317};
    t1316 = shen_apply_direct(ctx, "gensym", 1, a1316);
  }
  KLObject* t1319 = shen_intern(ctx, "L");
  KLObject* t1318;
  {
    KLObject* a1318[] = {t1319};
    t1318 = shen_apply_direct(ctx, "gensym", 1, a1318);
  }
  KLObject* t1321 = shen_intern(ctx, "K");
  KLObject* t1320;
  {
    KLObject* a1320[] = {t1321};
    t1320 = shen_apply_direct(ctx, "gensym", 1, a1320);
  }
  KLObject* t1323 = shen_intern(ctx, "C");
  KLObject* t1322;
  {
    KLObject* a1322[] = {t1323};
    t1322 = shen_apply_direct(ctx, "gensym", 1, a1322);
  }
  KLObject* t1324 = shen_intern(ctx, "lambda");
  KLObject* t1326 = shen_intern(ctx, "lambda");
  KLObject* t1328 = shen_intern(ctx, "lambda");
  KLObject* t1330 = shen_intern(ctx, "lambda");
  KLObject* t1332;
  {
    KLObject* a1332[] = {t1314, t1308, t1316, t1318, t1320, t1322};
    t1332 = shen_apply_direct(ctx, "shen.continue", 6, a1332);
  }
  KLObject* t1339 = shen_empty_list(ctx);
  KLObject* t1340 = shen_cons(ctx, t1332, t1339);
  KLObject* t1341 = shen_cons(ctx, t1322, t1340);
  KLObject* t1342 = shen_cons(ctx, t1330, t1341);
  KLObject* t1343 = shen_empty_list(ctx);
  KLObject* t1344 = shen_cons(ctx, t1342, t1343);
  KLObject* t1345 = shen_cons(ctx, t1320, t1344);
  KLObject* t1346 = shen_cons(ctx, t1328, t1345);
  KLObject* t1347 = shen_empty_list(ctx);
  KLObject* t1348 = shen_cons(ctx, t1346, t1347);
  KLObject* t1349 = shen_cons(ctx, t1318, t1348);
  KLObject* t1350 = shen_cons(ctx, t1326, t1349);
  KLObject* t1351 = shen_empty_list(ctx);
  KLObject* t1352 = shen_cons(ctx, t1350, t1351);
  KLObject* t1353 = shen_cons(ctx, t1316, t1352);
  KLObject* t1354 = shen_cons(ctx, t1324, t1353);
  KLObject* t1360 = shen_empty_list(ctx);
  KLObject* t1361 = shen_cons(ctx, t1307, t1360);
  KLObject* t1362 = shen_cons(ctx, t1302, t1361);
  KLObject* t1363 = shen_cons(ctx, t1301, t1362);
  KLObject* t1364 = shen_cons(ctx, t1288, t1363);
  KLObject* t1365 = shen_cons(ctx, t1354, t1364);
    return t1365;
  }
}

static KLObject* native_kl_shen_2ereceived_24 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t1366 = objects[0];
  tail_start_kl_shen_2ereceived_24: ;
  KLObject* t1367;
  {
    Vector* caps_14 = shen_vector(ctx, 0);
    t1367 = shen_native_closure(ctx, 0, &lambda_14, caps_14);
  }
  KLObject* t1371 = shen_cons_p(ctx, t1366);
  KLObject* t1369;
  if (!shen_is_boolean(ctx, t1371))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1371)) {
  KLObject* t1373 = shen_hd(ctx, t1366);
  KLObject* t1375 = shen_tl(ctx, t1366);
  KLObject* t1378 = shen_intern(ctx, "receive");
  KLObject* t1380 = shen_eq(ctx, t1378, t1373);
  KLObject* t1377;
  if (!shen_is_boolean(ctx, t1380))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t1380)) {
    t1377 = t1380;
  } else {
  KLObject* t1383 = shen_cons_p(ctx, t1375);
  KLObject* t1381;
  if (!shen_is_boolean(ctx, t1383))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t1383)) {
    t1381 = t1383;
  } else {
  KLObject* t1384 = shen_empty_list(ctx);
  KLObject* t1386 = shen_tl(ctx, t1375);
  KLObject* t1387 = shen_eq(ctx, t1384, t1386);
    if (!shen_is_boolean(ctx, t1387))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t1381 = t1387;
  }
    if (!shen_is_boolean(ctx, t1381))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t1377 = t1381;
  }
  KLObject* t1376;
  if (!shen_is_boolean(ctx, t1377))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1377)) {
    t1376 = t1375;
  } else {
  KLObject* t1390;
  {
    KLObject* a1390[] = {t1373};
    t1390 = shen_apply_direct(ctx, "shen.received", 1, a1390);
  }
  KLObject* t1392;
  {
    KLObject* a1392[] = {t1375};
    t1392 = shen_apply_direct(ctx, "shen.received", 1, a1392);
  }
  KLObject* t1389;
  {
    KLObject* a1389[] = {t1390, t1392};
    t1389 = shen_tail_apply_direct(ctx, "union", 2, a1389);
  }
    t1376 = t1389;
  }
    t1369 = t1376;
  } else {
  KLObject* t1394;
  {
    KLObject* a1394[] = {t1367};
    t1394 = shen_tail_apply_direct(ctx, "thaw", 1, a1394);
  }
    t1369 = t1394;
  }
    return t1369;
  }
}

static KLObject* native_kl_shen_2eprolog_2dvector_25 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  (void)function_object;
  (void)arguments;
  {
  tail_start_kl_shen_2eprolog_2dvector_25: ;
  KLObject* t1398 = shen_intern(ctx, "shen.*prolog-memory*");
  KLObject* t1397;
  {
    KLObject* a1397[] = {t1398};
    t1397 = shen_apply_direct(ctx, "value", 1, a1397);
  }
  KLObject* t1396;
  {
    KLObject* a1396[] = {t1397};
    t1396 = shen_apply_direct(ctx, "absvector", 1, a1396);
  }
  KLObject* t1401 = shen_number_l(ctx, 0);
  KLObject* t1402 = shen_intern(ctx, "shen.print-prolog-vector");
  KLObject* t1399;
  {
    KLObject* a1399[] = {t1396, t1401, t1402};
    t1399 = shen_apply_direct(ctx, "address->", 3, a1399);
  }
  KLObject* t1405 = shen_number_l(ctx, 1);
  KLObject* t1406 = shen_number_l(ctx, 2);
  KLObject* t1403;
  {
    KLObject* a1403[] = {t1396, t1405, t1406};
    t1403 = shen_apply_direct(ctx, "address->", 3, a1403);
  }
    return t1403;
  }
}

static KLObject* native_kl_receive_26 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t1408 = objects[0];
  tail_start_kl_receive_26: ;
    return t1408;
  }
}

static KLObject* native_kl_shen_2ercons_5fform_27 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t1410 = objects[0];
  tail_start_kl_shen_2ercons_5fform_27: ;
  KLObject* t1411;
  {
    Vector* caps_15 = shen_vector(ctx, 1);
    shen_vector_set(ctx, caps_15, 0, t1410);
    t1411 = shen_native_closure(ctx, 0, &lambda_15, caps_15);
  }
  KLObject* t1416 = shen_cons_p(ctx, t1410);
  KLObject* t1414;
  if (!shen_is_boolean(ctx, t1416))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1416)) {
  KLObject* t1418 = shen_hd(ctx, t1410);
  KLObject* t1420 = shen_tl(ctx, t1410);
  KLObject* t1423 = shen_intern(ctx, "bar!");
  KLObject* t1425 = shen_eq(ctx, t1423, t1418);
  KLObject* t1422;
  if (!shen_is_boolean(ctx, t1425))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t1425)) {
    t1422 = t1425;
  } else {
  KLObject* t1428 = shen_cons_p(ctx, t1420);
  KLObject* t1426;
  if (!shen_is_boolean(ctx, t1428))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t1428)) {
    t1426 = t1428;
  } else {
  KLObject* t1429 = shen_empty_list(ctx);
  KLObject* t1431 = shen_tl(ctx, t1420);
  KLObject* t1432 = shen_eq(ctx, t1429, t1431);
    if (!shen_is_boolean(ctx, t1432))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t1426 = t1432;
  }
    if (!shen_is_boolean(ctx, t1426))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t1422 = t1426;
  }
  KLObject* t1421;
  if (!shen_is_boolean(ctx, t1422))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1422)) {
  KLObject* t1434 = shen_hd(ctx, t1420);
    t1421 = t1434;
  } else {
  KLObject* t1435 = shen_intern(ctx, "cons");
  KLObject* t1436;
  {
    KLObject* a1436[] = {t1418};
    t1436 = shen_apply_direct(ctx, "shen.rcons_form", 1, a1436);
  }
  KLObject* t1438;
  {
    KLObject* a1438[] = {t1420};
    t1438 = shen_apply_direct(ctx, "shen.rcons_form", 1, a1438);
  }
  KLObject* t1440 = shen_empty_list(ctx);
  KLObject* t1441 = shen_cons(ctx, t1438, t1440);
  KLObject* t1442 = shen_cons(ctx, t1436, t1441);
  KLObject* t1443 = shen_cons(ctx, t1435, t1442);
    t1421 = t1443;
  }
    t1414 = t1421;
  } else {
  KLObject* t1444;
  {
    KLObject* a1444[] = {t1411};
    t1444 = shen_tail_apply_direct(ctx, "thaw", 1, a1444);
  }
    t1414 = t1444;
  }
    return t1414;
  }
}

static KLObject* native_kl_shen_2etuple_2dup_28 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t1446 = objects[0];
  tail_start_kl_shen_2etuple_2dup_28: ;
  KLObject* t1449 = shen_cons_p(ctx, t1446);
  KLObject* t1447;
  if (!shen_is_boolean(ctx, t1449))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1449)) {
  KLObject* t1450 = shen_intern(ctx, "@p");
  KLObject* t1452 = shen_hd(ctx, t1446);
  KLObject* t1455 = shen_tl(ctx, t1446);
  KLObject* t1453;
  {
    KLObject* a1453[] = {t1455};
    t1453 = shen_apply_direct(ctx, "shen.tuple-up", 1, a1453);
  }
  KLObject* t1456 = shen_empty_list(ctx);
  KLObject* t1457 = shen_cons(ctx, t1453, t1456);
  KLObject* t1458 = shen_cons(ctx, t1452, t1457);
  KLObject* t1459 = shen_cons(ctx, t1450, t1458);
    t1447 = t1459;
  } else {
    t1447 = t1446;
  }
    return t1447;
  }
}

static KLObject* native_kl_undefmacro_29 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t1461 = objects[0];
  tail_start_kl_undefmacro_29: ;
  KLObject* t1463 = shen_intern(ctx, "*macros*");
  KLObject* t1468 = shen_intern(ctx, "*macros*");
  KLObject* t1467;
  {
    KLObject* a1467[] = {t1468};
    t1467 = shen_apply_direct(ctx, "value", 1, a1467);
  }
  KLObject* t1465;
  {
    KLObject* a1465[] = {t1461, t1467};
    t1465 = shen_apply_direct(ctx, "assoc", 2, a1465);
  }
  KLObject* t1470 = shen_intern(ctx, "*macros*");
  KLObject* t1469;
  {
    KLObject* a1469[] = {t1470};
    t1469 = shen_apply_direct(ctx, "value", 1, a1469);
  }
  KLObject* t1464;
  {
    KLObject* a1464[] = {t1465, t1469};
    t1464 = shen_apply_direct(ctx, "remove", 2, a1464);
  }
  KLObject* t1462;
  {
    KLObject* a1462[] = {t1463, t1464};
    t1462 = shen_apply_direct(ctx, "set", 2, a1462);
  }
    return t1461;
  }
}

void shen_kernel_aot_install_macros (shen_context* ctx)
{
  shen_register_defun(ctx, "macroexpand", 1, &native_kl_macroexpand_0);
  shen_register_defun(ctx, "shen.macroexpand-h", 3, &native_kl_shen_2emacroexpand_2dh_1);
  shen_register_defun(ctx, "shen.walk", 2, &native_kl_shen_2ewalk_2);
  shen_register_defun(ctx, "shen.macros", 1, &native_kl_shen_2emacros_3);
  shen_register_defun(ctx, "shen.process-input+", 1, &native_kl_shen_2eprocess_2dinput_2b_4);
  shen_register_defun(ctx, "shen.cons-form-respect-modes", 1, &native_kl_shen_2econs_2dform_2drespect_2dmodes_5);
  shen_register_defun(ctx, "shen.process-def", 2, &native_kl_shen_2eprocess_2ddef_6);
  shen_register_defun(ctx, "shen.process-let", 1, &native_kl_shen_2eprocess_2dlet_7);
  shen_register_defun(ctx, "shen.process-@s", 1, &native_kl_shen_2eprocess_2d_40s_8);
  shen_register_defun(ctx, "shen.process-datatype", 2, &native_kl_shen_2eprocess_2ddatatype_9);
  shen_register_defun(ctx, "shen.intern-type", 1, &native_kl_shen_2eintern_2dtype_10);
  shen_register_defun(ctx, "shen.process-synonyms", 1, &native_kl_shen_2eprocess_2dsynonyms_11);
  shen_register_defun(ctx, "shen.synonyms-h", 1, &native_kl_shen_2esynonyms_2dh_12);
  shen_register_defun(ctx, "shen.compile-synonyms", 1, &native_kl_shen_2ecompile_2dsynonyms_13);
  shen_register_defun(ctx, "shen.process-lambda", 1, &native_kl_shen_2eprocess_2dlambda_14);
  shen_register_defun(ctx, "shen.process-cases", 1, &native_kl_shen_2eprocess_2dcases_15);
  shen_register_defun(ctx, "shen.process-time", 1, &native_kl_shen_2eprocess_2dtime_16);
  shen_register_defun(ctx, "shen.process-assoc", 1, &native_kl_shen_2eprocess_2dassoc_17);
  shen_register_defun(ctx, "shen.make-uppercase", 1, &native_kl_shen_2emake_2duppercase_18);
  shen_register_defun(ctx, "shen.mu-h", 1, &native_kl_shen_2emu_2dh_19);
  shen_register_defun(ctx, "shen.record-macro", 2, &native_kl_shen_2erecord_2dmacro_20);
  shen_register_defun(ctx, "shen.update-assoc", 3, &native_kl_shen_2eupdate_2dassoc_21);
  shen_register_defun(ctx, "shen.process-read-byte", 0, &native_kl_shen_2eprocess_2dread_2dbyte_22);
  shen_register_defun(ctx, "shen.call-prolog", 1, &native_kl_shen_2ecall_2dprolog_23);
  shen_register_defun(ctx, "shen.received", 1, &native_kl_shen_2ereceived_24);
  shen_register_defun(ctx, "shen.prolog-vector", 0, &native_kl_shen_2eprolog_2dvector_25);
  shen_register_defun(ctx, "receive", 1, &native_kl_receive_26);
  shen_register_defun(ctx, "shen.rcons_form", 1, &native_kl_shen_2ercons_5fform_27);
  shen_register_defun(ctx, "shen.tuple-up", 1, &native_kl_shen_2etuple_2dup_28);
  shen_register_defun(ctx, "undefmacro", 1, &native_kl_undefmacro_29);
}
