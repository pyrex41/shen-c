#include "rc_phase_profile.h"
/* Generated always-AOT kernel module (KL defuns -> NativeFunctions).
 * Install after tree-walker boot overwrites UserFunctions.
 * Toplevel declare/set stay on the walker. Not overlay-after-load.
 * Sidecar tests stay on the tree-walker. Not a second main. Source: prolog.kl
 */
#include "abi.h"

void shen_kernel_aot_install_prolog (shen_context* ctx);

static KLObject* lambda_0 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t355 = objects[0];
  KLObject* t356;
  {
    KLObject* a356[] = {t355};
    t356 = shen_tail_apply_direct(ctx, "shen.<defprolog>", 1, a356);
  }
    return t356;
  }
}

static KLObject* lambda_1 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t386 = objects[0];
  KLObject* t387;
  {
    KLObject* a387[] = {t386};
    t387 = shen_tail_apply_direct(ctx, "shen.linearise-clause", 1, a387);
  }
    return t387;
  }
}

static KLObject* lambda_2 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  KLObject* t1937 = shen_vector_get(ctx, caps, 0);
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t1938 = objects[0];
  KLObject* t1939;
  {
    KLObject* a1939[] = {t1938, t1937};
    t1939 = shen_tail_apply_direct(ctx, "shen.function-calls", 2, a1939);
  }
    return t1939;
  }
}

static KLObject* lambda_3 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  KLObject* t2161 = shen_vector_get(ctx, caps, 0);
  KLObject* t2162 = shen_vector_get(ctx, caps, 1);
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t2163 = objects[0];
  KLObject* t2164;
  {
    KLObject* a2164[] = {t2163, t2161, t2162};
    t2164 = shen_tail_apply_direct(ctx, "shen.deref-terms", 3, a2164);
  }
    return t2164;
  }
}

static KLObject* lambda_4 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t2934 = objects[0];
  KLObject* t2935;
  {
    KLObject* a2935[] = {t2934};
    t2935 = shen_tail_apply_direct(ctx, "shen.demode", 1, a2935);
  }
    return t2935;
  }
}

static KLObject* lambda_5 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t2950 = objects[0];
  KLObject* t2951;
  {
    KLObject* a2951[] = {t2950};
    t2951 = shen_tail_apply_direct(ctx, "shen.tame", 1, a2951);
  }
    return t2951;
  }
}

static KLObject* trap_body_0 (void* data)
{
  shen_context* ctx = &shen_root_context;
  Vector* env = (Vector*)data;
  KLObject* t3015 = shen_vector_get(ctx, env, 0);
  KLObject* t3018 = shen_absvector_p(ctx, t3015);
  KLObject* t3016;
  if (!shen_is_boolean(ctx, t3018))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t3018)) {
    t3016 = t3018;
  } else {
  KLObject* t3021 = shen_number_l(ctx, 0);
  KLObject* t3019;
  {
    KLObject* a3019[] = {t3015, t3021};
    t3019 = shen_apply_direct(ctx, "<-address", 2, a3019);
  }
  KLObject* t3022 = shen_intern(ctx, "shen.pvar");
  KLObject* t3023 = shen_eq(ctx, t3019, t3022);
    if (!shen_is_boolean(ctx, t3023))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t3016 = t3023;
  }
  return t3016;
}

static KLObject* lambda_6 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t3026 = objects[0];
  KLObject* t3027 = shen_false(ctx);
    return t3027;
  }
}

static KLObject* trap_handler_0 (KLObject* exception, void* data)
{
  shen_context* ctx = &shen_root_context;
  Vector* env = (Vector*)data;
  Vector* args;
  KLObject* t3024 = shen_vector_get(ctx, env, 0);
  KLObject* t3025;
  {
    Vector* caps_6 = shen_vector(ctx, 0);
    t3025 = shen_native_closure(ctx, 1, &lambda_6, caps_6);
  }
  args = shen_vector(ctx, 1);
  shen_vector_set(ctx, args, 0, exception);
  {
    KLObject* t3028 = shen_apply(ctx, t3025, args);
    return t3028;
  }
}

static KLObject* lambda_7 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  KLObject* t3296 = shen_vector_get(ctx, caps, 0);
  KLObject* t3297 = shen_vector_get(ctx, caps, 1);
  KLObject* t3298 = shen_vector_get(ctx, caps, 2);
  KLObject* t3299 = shen_vector_get(ctx, caps, 3);
  (void)arguments;
  KLObject* t3303 = shen_tl(ctx, t3296);
  KLObject* t3301;
  {
    KLObject* a3301[] = {t3303, t3297};
    t3301 = shen_apply_direct(ctx, "shen.lazyderef", 2, a3301);
  }
  KLObject* t3307 = shen_tl(ctx, t3298);
  KLObject* t3305;
  {
    KLObject* a3305[] = {t3307, t3297};
    t3305 = shen_apply_direct(ctx, "shen.lazyderef", 2, a3305);
  }
  KLObject* t3300;
  {
    KLObject* a3300[] = {t3301, t3305, t3297, t3299};
    t3300 = shen_tail_apply_direct(ctx, "shen.lzy=!", 4, a3300);
  }
    return t3300;
}

static KLObject* lambda_8 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  KLObject* t3353 = shen_vector_get(ctx, caps, 0);
  KLObject* t3354 = shen_vector_get(ctx, caps, 1);
  KLObject* t3355 = shen_vector_get(ctx, caps, 2);
  KLObject* t3356 = shen_vector_get(ctx, caps, 3);
  (void)arguments;
  KLObject* t3360 = shen_tl(ctx, t3353);
  KLObject* t3358;
  {
    KLObject* a3358[] = {t3360, t3354};
    t3358 = shen_apply_direct(ctx, "shen.lazyderef", 2, a3358);
  }
  KLObject* t3364 = shen_tl(ctx, t3355);
  KLObject* t3362;
  {
    KLObject* a3362[] = {t3364, t3354};
    t3362 = shen_apply_direct(ctx, "shen.lazyderef", 2, a3362);
  }
  KLObject* t3357;
  {
    KLObject* a3357[] = {t3358, t3362, t3354, t3356};
    t3357 = shen_tail_apply_direct(ctx, "shen.lzy=", 4, a3357);
  }
    return t3357;
}

static KLObject* lambda_9 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  KLObject* t3538 = shen_vector_get(ctx, caps, 0);
  KLObject* t3539 = shen_vector_get(ctx, caps, 1);
  KLObject* t3540 = shen_vector_get(ctx, caps, 2);
  KLObject* t3541 = shen_vector_get(ctx, caps, 3);
  KLObject* t3542 = shen_vector_get(ctx, caps, 4);
  KLObject* t3543 = shen_vector_get(ctx, caps, 5);
  KLObject* t3544 = shen_vector_get(ctx, caps, 6);
  KLObject* t3545 = shen_vector_get(ctx, caps, 7);
  (void)arguments;
  KLObject* t3546;
  {
    KLObject* a3546[] = {t3538, t3539, t3540, t3541, t3542, t3543, t3544, t3545};
    t3546 = shen_tail_apply_direct(ctx, "shen.findall-h", 8, a3546);
  }
    return t3546;
}

static KLObject* lambda_10 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  KLObject* t3574 = shen_vector_get(ctx, caps, 0);
  KLObject* t3575 = shen_vector_get(ctx, caps, 1);
  KLObject* t3576 = shen_vector_get(ctx, caps, 2);
  KLObject* t3577 = shen_vector_get(ctx, caps, 3);
  KLObject* t3578 = shen_vector_get(ctx, caps, 4);
  KLObject* t3579 = shen_vector_get(ctx, caps, 5);
  (void)arguments;
  KLObject* t3580;
  {
    KLObject* a3580[] = {t3574, t3575, t3576, t3577, t3578, t3579};
    t3580 = shen_tail_apply_direct(ctx, "shen.overbind", 6, a3580);
  }
    return t3580;
}

static KLObject* native_kl_asserta_0 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t0 = objects[0];
  tail_start_kl_asserta_0: ;
  KLObject* t3 = shen_intern(ctx, "shen.top");
  KLObject* t1;
  {
    KLObject* a1[] = {t0, t3};
    t1 = shen_tail_apply_direct(ctx, "shen.assert*", 2, a1);
  }
    return t1;
  }
}

static KLObject* native_kl_assertz_1 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t4 = objects[0];
  tail_start_kl_assertz_1: ;
  KLObject* t7 = shen_intern(ctx, "shen.bottom");
  KLObject* t5;
  {
    KLObject* a5[] = {t4, t7};
    t5 = shen_tail_apply_direct(ctx, "shen.assert*", 2, a5);
  }
    return t5;
  }
}

static KLObject* native_kl_shen_2eassert_2a_2 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t8 = objects[0];
    KLObject* t9 = objects[1];
  tail_start_kl_shen_2eassert_2a_2: ;
  KLObject* t10;
  {
  KLObject* t13 = shen_cons_p(ctx, t8);
  KLObject* t11;
  if (!shen_is_boolean(ctx, t13))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t13)) {
    t11 = t13;
  } else {
  KLObject* t16 = shen_tl(ctx, t8);
  KLObject* t17 = shen_cons_p(ctx, t16);
  KLObject* t14;
  if (!shen_is_boolean(ctx, t17))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t17)) {
    t14 = t17;
  } else {
  KLObject* t18 = shen_intern(ctx, "<--");
  KLObject* t20 = shen_tl(ctx, t8);
  KLObject* t21 = shen_hd(ctx, t20);
  KLObject* t22 = shen_eq(ctx, t18, t21);
    if (!shen_is_boolean(ctx, t22))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t14 = t22;
  }
    if (!shen_is_boolean(ctx, t14))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t11 = t14;
  }
    if (!shen_is_boolean(ctx, t11))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t11)) {
  KLObject* t25 = shen_hd(ctx, t8);
  KLObject* t23;
  {
    KLObject* a23[] = {t25};
    t23 = shen_apply_direct(ctx, "shen.predicate", 1, a23);
  }
  KLObject* t28 = shen_hd(ctx, t8);
  KLObject* t26;
  {
    KLObject* a26[] = {t28};
    t26 = shen_apply_direct(ctx, "shen.terms", 1, a26);
  }
  KLObject* t29;
  {
    KLObject* a29[] = {t26};
    t29 = shen_apply_direct(ctx, "length", 1, a29);
  }
  KLObject* t31;
  {
    KLObject* a31[] = {t29};
    t31 = shen_apply_direct(ctx, "shen.parameters", 1, a31);
  }
  KLObject* t33;
  {
    KLObject* a33[] = {t23};
    t33 = shen_apply_direct(ctx, "arity", 1, a33);
  }
  KLObject* t37 = shen_number_l(ctx, -1);
  KLObject* t38 = shen_eq(ctx, t33, t37);
  KLObject* t35;
  if (!shen_is_boolean(ctx, t38))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t38)) {
  KLObject* t40;
  {
    KLObject* a40[] = {t23, t31};
    t40 = shen_apply_direct(ctx, "shen.create-skeleton", 2, a40);
  }
  KLObject* t39;
  {
    KLObject* a39[] = {t40};
    t39 = shen_apply_direct(ctx, "eval", 1, a39);
  }
  KLObject* t45 = shen_intern(ctx, "shen.dynamic");
  KLObject* t46 = shen_empty_list(ctx);
  KLObject* t48 = shen_intern(ctx, "*property-vector*");
  KLObject* t47;
  {
    KLObject* a47[] = {t48};
    t47 = shen_apply_direct(ctx, "value", 1, a47);
  }
  KLObject* t43;
  {
    KLObject* a43[] = {t23, t45, t46, t47};
    t43 = shen_apply_direct(ctx, "put", 4, a43);
  }
    t35 = t43;
  } else {
  KLObject* t49 = shen_intern(ctx, "shen.skip");
    t35 = t49;
  }
  KLObject* t54 = shen_tl(ctx, t8);
  KLObject* t55 = shen_tl(ctx, t54);
  KLObject* t50;
  {
    KLObject* a50[] = {t23, t26, t55, t8, t9};
    t50 = shen_apply_direct(ctx, "shen.insert-info", 5, a50);
  }
      t10 = t23;
    } else {
  KLObject* t59 = shen_true(ctx);
    if (!shen_is_boolean(ctx, t59))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t59)) {
  KLObject* t61 = shen_string(ctx, "partial function shen.assert*");
  KLObject* t60;
  {
    KLObject* a60[] = {t61};
    t60 = shen_tail_apply_direct(ctx, "simple-error", 1, a60);
  }
      t10 = t60;
    } else {
      shen_simple_error(ctx, "No true case found for cond");
      t10 = shen_empty_list(ctx);
    }
    }
  }
    return t10;
  }
}

static KLObject* native_kl_shen_2epredicate_3 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t62 = objects[0];
  tail_start_kl_shen_2epredicate_3: ;
  KLObject* t63;
  {
  KLObject* t65 = shen_cons_p(ctx, t62);
    if (!shen_is_boolean(ctx, t65))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t65)) {
  KLObject* t67 = shen_hd(ctx, t62);
      t63 = t67;
    } else {
  KLObject* t68 = shen_true(ctx);
    if (!shen_is_boolean(ctx, t68))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t68)) {
      t63 = t62;
    } else {
      shen_simple_error(ctx, "No true case found for cond");
      t63 = shen_empty_list(ctx);
    }
    }
  }
    return t63;
  }
}

static KLObject* native_kl_shen_2eterms_4 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t70 = objects[0];
  tail_start_kl_shen_2eterms_4: ;
  KLObject* t71;
  {
  KLObject* t73 = shen_cons_p(ctx, t70);
    if (!shen_is_boolean(ctx, t73))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t73)) {
  KLObject* t75 = shen_tl(ctx, t70);
      t71 = t75;
    } else {
  KLObject* t76 = shen_true(ctx);
    if (!shen_is_boolean(ctx, t76))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t76)) {
  KLObject* t77 = shen_empty_list(ctx);
      t71 = t77;
    } else {
      shen_simple_error(ctx, "No true case found for cond");
      t71 = shen_empty_list(ctx);
    }
    }
  }
    return t71;
  }
}

static KLObject* native_kl_shen_2ecreate_2dskeleton_5 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t78 = objects[0];
    KLObject* t79 = objects[1];
  tail_start_kl_shen_2ecreate_2dskeleton_5: ;
  KLObject* t80 = shen_intern(ctx, "defprolog");
  KLObject* t82;
  {
    KLObject* a82[] = {t78, t79};
    t82 = shen_apply_direct(ctx, "shen.dynamic-default", 2, a82);
  }
  KLObject* t85 = shen_cons(ctx, t78, t82);
  KLObject* t86 = shen_cons(ctx, t80, t85);
    return t86;
  }
}

static KLObject* native_kl_shen_2edynamic_2ddefault_6 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t87 = objects[0];
    KLObject* t88 = objects[1];
  tail_start_kl_shen_2edynamic_2ddefault_6: ;
  KLObject* t91 = shen_intern(ctx, "<--");
  KLObject* t92 = shen_intern(ctx, "shen.call-dynamic");
  KLObject* t93;
  {
    KLObject* a93[] = {t88};
    t93 = shen_apply_direct(ctx, "shen.cons-form", 1, a93);
  }
  KLObject* t95 = shen_intern(ctx, "get");
  KLObject* t97 = shen_intern(ctx, "shen.dynamic");
  KLObject* t98 = shen_empty_list(ctx);
  KLObject* t99 = shen_cons(ctx, t97, t98);
  KLObject* t100 = shen_cons(ctx, t87, t99);
  KLObject* t101 = shen_cons(ctx, t95, t100);
  KLObject* t102 = shen_empty_list(ctx);
  KLObject* t103 = shen_cons(ctx, t101, t102);
  KLObject* t104 = shen_cons(ctx, t93, t103);
  KLObject* t105 = shen_cons(ctx, t92, t104);
  KLObject* t107 = shen_string(ctx, ";");
  KLObject* t106;
  {
    KLObject* a106[] = {t107};
    t106 = shen_apply_direct(ctx, "intern", 1, a106);
  }
  KLObject* t108 = shen_empty_list(ctx);
  KLObject* t109 = shen_cons(ctx, t106, t108);
  KLObject* t110 = shen_cons(ctx, t105, t109);
  KLObject* t111 = shen_cons(ctx, t91, t110);
  KLObject* t89;
  {
    KLObject* a89[] = {t88, t111};
    t89 = shen_tail_apply_direct(ctx, "append", 2, a89);
  }
    return t89;
  }
}

static KLObject* native_kl_shen_2einsert_2dinfo_7 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t112 = objects[0];
    KLObject* t113 = objects[1];
    KLObject* t114 = objects[2];
    KLObject* t115 = objects[3];
    KLObject* t116 = objects[4];
  tail_start_kl_shen_2einsert_2dinfo_7: ;
  KLObject* t118 = shen_intern(ctx, "shen.g");
  KLObject* t117;
  {
    KLObject* a117[] = {t118};
    t117 = shen_apply_direct(ctx, "gensym", 1, a117);
  }
  KLObject* t121 = shen_intern(ctx, "defprolog");
  KLObject* t123 = shen_empty_list(ctx);
  KLObject* t124 = shen_cons(ctx, t117, t123);
  KLObject* t125 = shen_cons(ctx, t121, t124);
  KLObject* t128 = shen_intern(ctx, "<--");
  KLObject* t130 = shen_cons(ctx, t128, t114);
  KLObject* t126;
  {
    KLObject* a126[] = {t113, t130};
    t126 = shen_apply_direct(ctx, "append", 2, a126);
  }
  KLObject* t120;
  {
    KLObject* a120[] = {t125, t126};
    t120 = shen_apply_direct(ctx, "append", 2, a120);
  }
  KLObject* t119;
  {
    KLObject* a119[] = {t120};
    t119 = shen_apply_direct(ctx, "eval", 1, a119);
  }
  KLObject* t131;
  {
    KLObject* a131[] = {t117};
    t131 = shen_apply_direct(ctx, "fn", 1, a131);
  }
  KLObject* t135 = shen_cons(ctx, t117, t115);
  KLObject* t136 = shen_cons(ctx, t131, t135);
  KLObject* t139 = shen_intern(ctx, "shen.dynamic");
  KLObject* t141 = shen_intern(ctx, "*property-vector*");
  KLObject* t140;
  {
    KLObject* a140[] = {t141};
    t140 = shen_apply_direct(ctx, "value", 1, a140);
  }
  KLObject* t137;
  {
    KLObject* a137[] = {t112, t139, t140};
    t137 = shen_apply_direct(ctx, "get", 3, a137);
  }
  KLObject* t144 = shen_intern(ctx, "shen.top");
  KLObject* t145 = shen_eq(ctx, t116, t144);
  KLObject* t142;
  if (!shen_is_boolean(ctx, t145))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t145)) {
  KLObject* t148 = shen_cons(ctx, t136, t137);
    t142 = t148;
  } else {
  KLObject* t152 = shen_empty_list(ctx);
  KLObject* t153 = shen_cons(ctx, t136, t152);
  KLObject* t149;
  {
    KLObject* a149[] = {t137, t153};
    t149 = shen_apply_direct(ctx, "append", 2, a149);
  }
    t142 = t149;
  }
  KLObject* t156 = shen_intern(ctx, "shen.dynamic");
  KLObject* t159 = shen_intern(ctx, "*property-vector*");
  KLObject* t158;
  {
    KLObject* a158[] = {t159};
    t158 = shen_apply_direct(ctx, "value", 1, a158);
  }
  KLObject* t154;
  {
    KLObject* a154[] = {t112, t156, t142, t158};
    t154 = shen_tail_apply_direct(ctx, "put", 4, a154);
  }
    return t154;
  }
}

static KLObject* native_kl_shen_2enewname_8 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  (void)function_object;
  (void)arguments;
  {
  tail_start_kl_shen_2enewname_8: ;
  KLObject* t161 = shen_intern(ctx, "shen.*names*");
  KLObject* t160;
  {
    KLObject* a160[] = {t161};
    t160 = shen_apply_direct(ctx, "value", 1, a160);
  }
  KLObject* t163;
  {
    KLObject* a163[] = {t160};
    t163 = shen_apply_direct(ctx, "empty?", 1, a163);
  }
  KLObject* t162;
  if (!shen_is_boolean(ctx, t163))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t163)) {
  KLObject* t166 = shen_intern(ctx, "shen.g");
  KLObject* t165;
  {
    KLObject* a165[] = {t166};
    t165 = shen_apply_direct(ctx, "gensym", 1, a165);
  }
    t162 = t165;
  } else {
  KLObject* t168 = shen_intern(ctx, "shen.*names*");
  KLObject* t170 = shen_tl(ctx, t160);
  KLObject* t167;
  {
    KLObject* a167[] = {t168, t170};
    t167 = shen_apply_direct(ctx, "set", 2, a167);
  }
  KLObject* t172 = shen_hd(ctx, t160);
    t162 = t172;
  }
    return t162;
  }
}

static KLObject* native_kl_shen_2ecall_2ddynamic_9 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t174 = objects[0];
    KLObject* t175 = objects[1];
    KLObject* t176 = objects[2];
    KLObject* t177 = objects[3];
    KLObject* t178 = objects[4];
    KLObject* t179 = objects[5];
  tail_start_kl_shen_2ecall_2ddynamic_9: ;
  KLObject* t181;
  {
    KLObject* a181[] = {t177};
    t181 = shen_apply_direct(ctx, "shen.unlocked?", 1, a181);
  }
  KLObject* t180;
  if (!shen_is_boolean(ctx, t181))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t181)) {
  KLObject* t183;
  {
    KLObject* a183[] = {t175, t176};
    t183 = shen_apply_direct(ctx, "shen.lazyderef", 2, a183);
  }
  KLObject* t188 = shen_cons_p(ctx, t183);
  KLObject* t186;
  if (!shen_is_boolean(ctx, t188))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t188)) {
  KLObject* t191 = shen_hd(ctx, t183);
  KLObject* t189;
  {
    KLObject* a189[] = {t191, t176};
    t189 = shen_apply_direct(ctx, "shen.lazyderef", 2, a189);
  }
  KLObject* t195 = shen_cons_p(ctx, t189);
  KLObject* t193;
  if (!shen_is_boolean(ctx, t195))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t195)) {
  KLObject* t197 = shen_hd(ctx, t189);
  KLObject* t198 = shen_apply_direct(ctx, "shen.incinfs", 0, NULL);
  KLObject* t199;
  {
    KLObject* a199[] = {t197, t174, t176, t177, t178, t179};
    t199 = shen_apply_direct(ctx, "shen.callrec", 6, a199);
  }
    t193 = t199;
  } else {
  KLObject* t206 = shen_false(ctx);
    t193 = t206;
  }
    t186 = t193;
  } else {
  KLObject* t207 = shen_false(ctx);
    t186 = t207;
  }
    t180 = t186;
  } else {
  KLObject* t208 = shen_false(ctx);
    t180 = t208;
  }
  KLObject* t211 = shen_false(ctx);
  KLObject* t212 = shen_eq(ctx, t180, t211);
  KLObject* t209;
  if (!shen_is_boolean(ctx, t212))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t212)) {
  KLObject* t214;
  {
    KLObject* a214[] = {t177};
    t214 = shen_apply_direct(ctx, "shen.unlocked?", 1, a214);
  }
  KLObject* t213;
  if (!shen_is_boolean(ctx, t214))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t214)) {
  KLObject* t216;
  {
    KLObject* a216[] = {t175, t176};
    t216 = shen_apply_direct(ctx, "shen.lazyderef", 2, a216);
  }
  KLObject* t221 = shen_cons_p(ctx, t216);
  KLObject* t219;
  if (!shen_is_boolean(ctx, t221))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t221)) {
  KLObject* t223 = shen_tl(ctx, t216);
  KLObject* t224 = shen_apply_direct(ctx, "shen.incinfs", 0, NULL);
  {
    KLObject* n231_0 = t174;
    KLObject* n231_1 = t223;
    KLObject* n231_2 = t176;
    KLObject* n231_3 = t177;
    KLObject* n231_4 = t178;
    KLObject* n231_5 = t179;
    t174 = n231_0;
    t175 = n231_1;
    t176 = n231_2;
    t177 = n231_3;
    t178 = n231_4;
    t179 = n231_5;
    goto tail_start_kl_shen_2ecall_2ddynamic_9;
  }
  KLObject* t231 = NULL;
    t219 = t231;
  } else {
  KLObject* t232 = shen_false(ctx);
    t219 = t232;
  }
    t213 = t219;
  } else {
  KLObject* t233 = shen_false(ctx);
    t213 = t233;
  }
    t209 = t213;
  } else {
    t209 = t180;
  }
    return t209;
  }
}

static KLObject* native_kl_shen_2ecallrec_10 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t235 = objects[0];
    KLObject* t236 = objects[1];
    KLObject* t237 = objects[2];
    KLObject* t238 = objects[3];
    KLObject* t239 = objects[4];
    KLObject* t240 = objects[5];
  tail_start_kl_shen_2ecallrec_10: ;
  KLObject* t241;
  {
  KLObject* t242 = shen_empty_list(ctx);
  KLObject* t244 = shen_eq(ctx, t242, t236);
    if (!shen_is_boolean(ctx, t244))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t244)) {
  KLObject* t248;
  {
    Vector* a248 = shen_vector(ctx, 1);
    shen_vector_set(ctx, a248, 0, t237);
    t248 = shen_apply(ctx, t235, a248);
  }
  KLObject* t247;
  {
    Vector* a247 = shen_vector(ctx, 1);
    shen_vector_set(ctx, a247, 0, t238);
    t247 = shen_apply(ctx, t248, a247);
  }
  KLObject* t246;
  {
    Vector* a246 = shen_vector(ctx, 1);
    shen_vector_set(ctx, a246, 0, t239);
    t246 = shen_apply(ctx, t247, a246);
  }
  KLObject* t245;
  {
    Vector* a245 = shen_vector(ctx, 1);
    shen_vector_set(ctx, a245, 0, t240);
    t245 = shen_tail_apply(ctx, t246, a245);
  }
      t241 = t245;
    } else {
  KLObject* t255 = shen_cons_p(ctx, t236);
    if (!shen_is_boolean(ctx, t255))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t255)) {
  KLObject* t259 = shen_hd(ctx, t236);
  KLObject* t256;
  {
    Vector* a256 = shen_vector(ctx, 1);
    shen_vector_set(ctx, a256, 0, t259);
    t256 = shen_apply(ctx, t235, a256);
  }
  KLObject* t261 = shen_tl(ctx, t236);
  {
    KLObject* n266_0 = t256;
    KLObject* n266_1 = t261;
    KLObject* n266_2 = t237;
    KLObject* n266_3 = t238;
    KLObject* n266_4 = t239;
    KLObject* n266_5 = t240;
    t235 = n266_0;
    t236 = n266_1;
    t237 = n266_2;
    t238 = n266_3;
    t239 = n266_4;
    t240 = n266_5;
    goto tail_start_kl_shen_2ecallrec_10;
  }
  KLObject* t266 = NULL;
      t241 = t266;
    } else {
  KLObject* t267 = shen_true(ctx);
    if (!shen_is_boolean(ctx, t267))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t267)) {
  KLObject* t269 = shen_string(ctx, "partial function shen.callrec");
  KLObject* t268;
  {
    KLObject* a268[] = {t269};
    t268 = shen_tail_apply_direct(ctx, "simple-error", 1, a268);
  }
      t241 = t268;
    } else {
      shen_simple_error(ctx, "No true case found for cond");
      t241 = shen_empty_list(ctx);
    }
    }
    }
  }
    return t241;
  }
}

static KLObject* native_kl_retract_11 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t270 = objects[0];
  tail_start_kl_retract_11: ;
  KLObject* t271;
  {
  KLObject* t274 = shen_cons_p(ctx, t270);
  KLObject* t272;
  if (!shen_is_boolean(ctx, t274))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t274)) {
    t272 = t274;
  } else {
  KLObject* t277 = shen_tl(ctx, t270);
  KLObject* t278 = shen_cons_p(ctx, t277);
  KLObject* t275;
  if (!shen_is_boolean(ctx, t278))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t278)) {
    t275 = t278;
  } else {
  KLObject* t279 = shen_intern(ctx, "<--");
  KLObject* t281 = shen_tl(ctx, t270);
  KLObject* t282 = shen_hd(ctx, t281);
  KLObject* t283 = shen_eq(ctx, t279, t282);
    if (!shen_is_boolean(ctx, t283))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t275 = t283;
  }
    if (!shen_is_boolean(ctx, t275))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t272 = t275;
  }
    if (!shen_is_boolean(ctx, t272))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t272)) {
  KLObject* t286 = shen_hd(ctx, t270);
  KLObject* t284;
  {
    KLObject* a284[] = {t286};
    t284 = shen_apply_direct(ctx, "shen.predicate", 1, a284);
  }
  KLObject* t289 = shen_intern(ctx, "shen.dynamic");
  KLObject* t291 = shen_intern(ctx, "*property-vector*");
  KLObject* t290;
  {
    KLObject* a290[] = {t291};
    t290 = shen_apply_direct(ctx, "value", 1, a290);
  }
  KLObject* t287;
  {
    KLObject* a287[] = {t284, t289, t290};
    t287 = shen_apply_direct(ctx, "get", 3, a287);
  }
  KLObject* t294 = shen_intern(ctx, "shen.dynamic");
  KLObject* t295;
  {
    KLObject* a295[] = {t270, t287};
    t295 = shen_apply_direct(ctx, "shen.retract-clause", 2, a295);
  }
  KLObject* t299 = shen_intern(ctx, "*property-vector*");
  KLObject* t298;
  {
    KLObject* a298[] = {t299};
    t298 = shen_apply_direct(ctx, "value", 1, a298);
  }
  KLObject* t292;
  {
    KLObject* a292[] = {t284, t294, t295, t298};
    t292 = shen_tail_apply_direct(ctx, "put", 4, a292);
  }
      t271 = t292;
    } else {
  KLObject* t300 = shen_true(ctx);
    if (!shen_is_boolean(ctx, t300))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t300)) {
  KLObject* t302 = shen_string(ctx, "partial function retract");
  KLObject* t301;
  {
    KLObject* a301[] = {t302};
    t301 = shen_tail_apply_direct(ctx, "simple-error", 1, a301);
  }
      t271 = t301;
    } else {
      shen_simple_error(ctx, "No true case found for cond");
      t271 = shen_empty_list(ctx);
    }
    }
  }
    return t271;
  }
}

static KLObject* native_kl_shen_2eretract_2dclause_12 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t303 = objects[0];
    KLObject* t304 = objects[1];
  tail_start_kl_shen_2eretract_2dclause_12: ;
  KLObject* t305;
  {
  KLObject* t306 = shen_empty_list(ctx);
  KLObject* t308 = shen_eq(ctx, t306, t304);
    if (!shen_is_boolean(ctx, t308))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t308)) {
  KLObject* t309 = shen_empty_list(ctx);
      t305 = t309;
    } else {
  KLObject* t312 = shen_cons_p(ctx, t304);
  KLObject* t310;
  if (!shen_is_boolean(ctx, t312))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t312)) {
    t310 = t312;
  } else {
  KLObject* t315 = shen_hd(ctx, t304);
  KLObject* t316 = shen_cons_p(ctx, t315);
  KLObject* t313;
  if (!shen_is_boolean(ctx, t316))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t316)) {
    t313 = t316;
  } else {
  KLObject* t319 = shen_hd(ctx, t304);
  KLObject* t320 = shen_tl(ctx, t319);
  KLObject* t321 = shen_cons_p(ctx, t320);
  KLObject* t317;
  if (!shen_is_boolean(ctx, t321))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t321)) {
    t317 = t321;
  } else {
  KLObject* t324 = shen_hd(ctx, t304);
  KLObject* t325 = shen_tl(ctx, t324);
  KLObject* t326 = shen_tl(ctx, t325);
  KLObject* t327 = shen_eq(ctx, t303, t326);
    if (!shen_is_boolean(ctx, t327))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t317 = t327;
  }
    if (!shen_is_boolean(ctx, t317))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t313 = t317;
  }
    if (!shen_is_boolean(ctx, t313))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t310 = t313;
  }
    if (!shen_is_boolean(ctx, t310))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t310)) {
  KLObject* t329 = shen_intern(ctx, "shen.*names*");
  KLObject* t331 = shen_hd(ctx, t304);
  KLObject* t332 = shen_tl(ctx, t331);
  KLObject* t333 = shen_hd(ctx, t332);
  KLObject* t335 = shen_intern(ctx, "shen.*names*");
  KLObject* t334;
  {
    KLObject* a334[] = {t335};
    t334 = shen_apply_direct(ctx, "value", 1, a334);
  }
  KLObject* t336 = shen_cons(ctx, t333, t334);
  KLObject* t328;
  {
    KLObject* a328[] = {t329, t336};
    t328 = shen_apply_direct(ctx, "set", 2, a328);
  }
  KLObject* t338 = shen_tl(ctx, t304);
      t305 = t338;
    } else {
  KLObject* t340 = shen_cons_p(ctx, t304);
    if (!shen_is_boolean(ctx, t340))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t340)) {
  KLObject* t342 = shen_hd(ctx, t304);
  KLObject* t346 = shen_tl(ctx, t304);
  KLObject* t343;
  {
    KLObject* a343[] = {t303, t346};
    t343 = shen_apply_direct(ctx, "shen.retract-clause", 2, a343);
  }
  KLObject* t347 = shen_cons(ctx, t342, t343);
      t305 = t347;
    } else {
  KLObject* t348 = shen_true(ctx);
    if (!shen_is_boolean(ctx, t348))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t348)) {
  KLObject* t350 = shen_string(ctx, "partial function shen.retract-clause");
  KLObject* t349;
  {
    KLObject* a349[] = {t350};
    t349 = shen_tail_apply_direct(ctx, "simple-error", 1, a349);
  }
      t305 = t349;
    } else {
      shen_simple_error(ctx, "No true case found for cond");
      t305 = shen_empty_list(ctx);
    }
    }
    }
    }
  }
    return t305;
  }
}

static KLObject* native_kl_shen_2ecompile_2dprolog_13 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t351 = objects[0];
    KLObject* t352 = objects[1];
  tail_start_kl_shen_2ecompile_2dprolog_13: ;
  KLObject* t354;
  {
    Vector* caps_0 = shen_vector(ctx, 0);
    t354 = shen_native_closure(ctx, 1, &lambda_0, caps_0);
  }
  KLObject* t360 = shen_cons(ctx, t351, t352);
  KLObject* t353;
  {
    KLObject* a353[] = {t354, t360};
    t353 = shen_tail_apply_direct(ctx, "compile", 2, a353);
  }
    return t353;
  }
}

static KLObject* native_kl_shen_2e_3cdefprolog_3e_14 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t361 = objects[0];
  tail_start_kl_shen_2e_3cdefprolog_3e_14: ;
  KLObject* t364 = shen_cons_p(ctx, t361);
  KLObject* t362;
  if (!shen_is_boolean(ctx, t364))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t364)) {
  KLObject* t365;
  {
    KLObject* a365[] = {t361};
    t365 = shen_apply_direct(ctx, "head", 1, a365);
  }
  KLObject* t367;
  {
    KLObject* a367[] = {t361};
    t367 = shen_apply_direct(ctx, "tail", 1, a367);
  }
  KLObject* t369;
  {
    KLObject* a369[] = {t367};
    t369 = shen_apply_direct(ctx, "shen.<clauses>", 1, a369);
  }
  KLObject* t372;
  {
    KLObject* a372[] = {t369};
    t372 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a372);
  }
  KLObject* t371;
  if (!shen_is_boolean(ctx, t372))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t372)) {
  KLObject* t374 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t371 = t374;
  } else {
  KLObject* t375;
  {
    KLObject* a375[] = {t369};
    t375 = shen_apply_direct(ctx, "shen.<-out", 1, a375);
  }
  KLObject* t377;
  {
    KLObject* a377[] = {t369};
    t377 = shen_apply_direct(ctx, "shen.in->", 1, a377);
  }
  KLObject* t381;
  {
    KLObject* a381[] = {t365, t375};
    t381 = shen_apply_direct(ctx, "shen.prolog-arity-check", 2, a381);
  }
  KLObject* t385;
  {
    Vector* caps_1 = shen_vector(ctx, 0);
    t385 = shen_native_closure(ctx, 1, &lambda_1, caps_1);
  }
  KLObject* t384;
  {
    KLObject* a384[] = {t385, t375};
    t384 = shen_apply_direct(ctx, "map", 2, a384);
  }
  KLObject* t390;
  {
    KLObject* a390[] = {t365, t384};
    t390 = shen_apply_direct(ctx, "shen.horn-clause-procedure", 2, a390);
  }
  KLObject* t379;
  {
    KLObject* a379[] = {t377, t390};
    t379 = shen_apply_direct(ctx, "shen.comb", 2, a379);
  }
    t371 = t379;
  }
    t362 = t371;
  } else {
  KLObject* t393 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t362 = t393;
  }
  KLObject* t395;
  {
    KLObject* a395[] = {t362};
    t395 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a395);
  }
  KLObject* t394;
  if (!shen_is_boolean(ctx, t395))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t395)) {
  KLObject* t397 = shen_tail_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t394 = t397;
  } else {
    t394 = t362;
  }
    return t394;
  }
}

static KLObject* native_kl_shen_2eprolog_2darity_2dcheck_15 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t399 = objects[0];
    KLObject* t400 = objects[1];
  tail_start_kl_shen_2eprolog_2darity_2dcheck_15: ;
  KLObject* t401;
  {
  KLObject* t404 = shen_cons_p(ctx, t400);
  KLObject* t402;
  if (!shen_is_boolean(ctx, t404))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t404)) {
    t402 = t404;
  } else {
  KLObject* t407 = shen_hd(ctx, t400);
  KLObject* t408 = shen_cons_p(ctx, t407);
  KLObject* t405;
  if (!shen_is_boolean(ctx, t408))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t408)) {
    t405 = t408;
  } else {
  KLObject* t411 = shen_hd(ctx, t400);
  KLObject* t412 = shen_tl(ctx, t411);
  KLObject* t413 = shen_cons_p(ctx, t412);
  KLObject* t409;
  if (!shen_is_boolean(ctx, t413))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t413)) {
    t409 = t413;
  } else {
  KLObject* t415 = shen_empty_list(ctx);
  KLObject* t417 = shen_hd(ctx, t400);
  KLObject* t418 = shen_tl(ctx, t417);
  KLObject* t419 = shen_tl(ctx, t418);
  KLObject* t420 = shen_eq(ctx, t415, t419);
  KLObject* t414;
  if (!shen_is_boolean(ctx, t420))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t420)) {
    t414 = t420;
  } else {
  KLObject* t421 = shen_empty_list(ctx);
  KLObject* t423 = shen_tl(ctx, t400);
  KLObject* t424 = shen_eq(ctx, t421, t423);
    if (!shen_is_boolean(ctx, t424))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t414 = t424;
  }
    if (!shen_is_boolean(ctx, t414))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t409 = t414;
  }
    if (!shen_is_boolean(ctx, t409))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t405 = t409;
  }
    if (!shen_is_boolean(ctx, t405))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t402 = t405;
  }
    if (!shen_is_boolean(ctx, t402))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t402)) {
  KLObject* t427 = shen_hd(ctx, t400);
  KLObject* t428 = shen_hd(ctx, t427);
  KLObject* t425;
  {
    KLObject* a425[] = {t428};
    t425 = shen_tail_apply_direct(ctx, "length", 1, a425);
  }
      t401 = t425;
    } else {
  KLObject* t431 = shen_cons_p(ctx, t400);
  KLObject* t429;
  if (!shen_is_boolean(ctx, t431))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t431)) {
    t429 = t431;
  } else {
  KLObject* t434 = shen_hd(ctx, t400);
  KLObject* t435 = shen_cons_p(ctx, t434);
  KLObject* t432;
  if (!shen_is_boolean(ctx, t435))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t435)) {
    t432 = t435;
  } else {
  KLObject* t438 = shen_hd(ctx, t400);
  KLObject* t439 = shen_tl(ctx, t438);
  KLObject* t440 = shen_cons_p(ctx, t439);
  KLObject* t436;
  if (!shen_is_boolean(ctx, t440))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t440)) {
    t436 = t440;
  } else {
  KLObject* t441 = shen_empty_list(ctx);
  KLObject* t443 = shen_hd(ctx, t400);
  KLObject* t444 = shen_tl(ctx, t443);
  KLObject* t445 = shen_tl(ctx, t444);
  KLObject* t446 = shen_eq(ctx, t441, t445);
    if (!shen_is_boolean(ctx, t446))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t436 = t446;
  }
    if (!shen_is_boolean(ctx, t436))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t432 = t436;
  }
    if (!shen_is_boolean(ctx, t432))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t429 = t432;
  }
    if (!shen_is_boolean(ctx, t429))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t429)) {
  KLObject* t451 = shen_hd(ctx, t400);
  KLObject* t452 = shen_hd(ctx, t451);
  KLObject* t449;
  {
    KLObject* a449[] = {t452};
    t449 = shen_apply_direct(ctx, "length", 1, a449);
  }
  KLObject* t454 = shen_tl(ctx, t400);
  KLObject* t447;
  {
    KLObject* a447[] = {t399, t449, t454};
    t447 = shen_tail_apply_direct(ctx, "shen.pac-h", 3, a447);
  }
      t401 = t447;
    } else {
  KLObject* t455 = shen_true(ctx);
    if (!shen_is_boolean(ctx, t455))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t455)) {
  KLObject* t457 = shen_string(ctx, "partial function shen.prolog-arity-check");
  KLObject* t456;
  {
    KLObject* a456[] = {t457};
    t456 = shen_tail_apply_direct(ctx, "simple-error", 1, a456);
  }
      t401 = t456;
    } else {
      shen_simple_error(ctx, "No true case found for cond");
      t401 = shen_empty_list(ctx);
    }
    }
    }
  }
    return t401;
  }
}

static KLObject* native_kl_shen_2epac_2dh_16 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t458 = objects[0];
    KLObject* t459 = objects[1];
    KLObject* t460 = objects[2];
  tail_start_kl_shen_2epac_2dh_16: ;
  KLObject* t461;
  {
  KLObject* t462 = shen_empty_list(ctx);
  KLObject* t464 = shen_eq(ctx, t462, t460);
    if (!shen_is_boolean(ctx, t464))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t464)) {
      t461 = t459;
    } else {
  KLObject* t468 = shen_cons_p(ctx, t460);
  KLObject* t466;
  if (!shen_is_boolean(ctx, t468))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t468)) {
    t466 = t468;
  } else {
  KLObject* t470 = shen_hd(ctx, t460);
  KLObject* t471 = shen_cons_p(ctx, t470);
    if (!shen_is_boolean(ctx, t471))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t466 = t471;
  }
    if (!shen_is_boolean(ctx, t466))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t466)) {
  KLObject* t476 = shen_hd(ctx, t460);
  KLObject* t477 = shen_hd(ctx, t476);
  KLObject* t474;
  {
    KLObject* a474[] = {t477};
    t474 = shen_apply_direct(ctx, "length", 1, a474);
  }
  KLObject* t478 = shen_eq(ctx, t459, t474);
  KLObject* t472;
  if (!shen_is_boolean(ctx, t478))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t478)) {
  KLObject* t482 = shen_tl(ctx, t460);
  {
    KLObject* n483_0 = t458;
    KLObject* n483_1 = t459;
    KLObject* n483_2 = t482;
    t458 = n483_0;
    t459 = n483_1;
    t460 = n483_2;
    goto tail_start_kl_shen_2epac_2dh_16;
  }
  KLObject* t483 = NULL;
    t472 = t483;
  } else {
  KLObject* t486 = shen_string(ctx, "arity error in prolog procedure ");
  KLObject* t489 = shen_string(ctx, "\n");
  KLObject* t490 = shen_intern(ctx, "shen.a");
  KLObject* t487;
  {
    KLObject* a487[] = {t458, t489, t490};
    t487 = shen_apply_direct(ctx, "shen.app", 3, a487);
  }
  KLObject* t485;
  {
    KLObject* a485[] = {t486, t487};
    t485 = shen_apply_direct(ctx, "cn", 2, a485);
  }
  KLObject* t484;
  {
    KLObject* a484[] = {t485};
    t484 = shen_tail_apply_direct(ctx, "simple-error", 1, a484);
  }
    t472 = t484;
  }
      t461 = t472;
    } else {
  KLObject* t491 = shen_true(ctx);
    if (!shen_is_boolean(ctx, t491))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t491)) {
  KLObject* t493 = shen_string(ctx, "partial function shen.pac-h");
  KLObject* t492;
  {
    KLObject* a492[] = {t493};
    t492 = shen_tail_apply_direct(ctx, "simple-error", 1, a492);
  }
      t461 = t492;
    } else {
      shen_simple_error(ctx, "No true case found for cond");
      t461 = shen_empty_list(ctx);
    }
    }
    }
  }
    return t461;
  }
}

static KLObject* native_kl_shen_2e_3cclauses_3e_17 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t494 = objects[0];
  tail_start_kl_shen_2e_3cclauses_3e_17: ;
  KLObject* t495;
  {
    KLObject* a495[] = {t494};
    t495 = shen_apply_direct(ctx, "shen.<clause>", 1, a495);
  }
  KLObject* t498;
  {
    KLObject* a498[] = {t495};
    t498 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a498);
  }
  KLObject* t497;
  if (!shen_is_boolean(ctx, t498))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t498)) {
  KLObject* t500 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t497 = t500;
  } else {
  KLObject* t501;
  {
    KLObject* a501[] = {t495};
    t501 = shen_apply_direct(ctx, "shen.<-out", 1, a501);
  }
  KLObject* t503;
  {
    KLObject* a503[] = {t495};
    t503 = shen_apply_direct(ctx, "shen.in->", 1, a503);
  }
  KLObject* t505;
  {
    KLObject* a505[] = {t503};
    t505 = shen_apply_direct(ctx, "shen.<clauses>", 1, a505);
  }
  KLObject* t508;
  {
    KLObject* a508[] = {t505};
    t508 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a508);
  }
  KLObject* t507;
  if (!shen_is_boolean(ctx, t508))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t508)) {
  KLObject* t510 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t507 = t510;
  } else {
  KLObject* t511;
  {
    KLObject* a511[] = {t505};
    t511 = shen_apply_direct(ctx, "shen.<-out", 1, a511);
  }
  KLObject* t513;
  {
    KLObject* a513[] = {t505};
    t513 = shen_apply_direct(ctx, "shen.in->", 1, a513);
  }
  KLObject* t519 = shen_cons(ctx, t501, t511);
  KLObject* t515;
  {
    KLObject* a515[] = {t513, t519};
    t515 = shen_apply_direct(ctx, "shen.comb", 2, a515);
  }
    t507 = t515;
  }
    t497 = t507;
  }
  KLObject* t521;
  {
    KLObject* a521[] = {t497};
    t521 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a521);
  }
  KLObject* t520;
  if (!shen_is_boolean(ctx, t521))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t521)) {
  KLObject* t523;
  {
    KLObject* a523[] = {t494};
    t523 = shen_apply_direct(ctx, "<!>", 1, a523);
  }
  KLObject* t526;
  {
    KLObject* a526[] = {t523};
    t526 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a526);
  }
  KLObject* t525;
  if (!shen_is_boolean(ctx, t526))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t526)) {
  KLObject* t528 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t525 = t528;
  } else {
  KLObject* t529;
  {
    KLObject* a529[] = {t523};
    t529 = shen_apply_direct(ctx, "shen.<-out", 1, a529);
  }
  KLObject* t531;
  {
    KLObject* a531[] = {t523};
    t531 = shen_apply_direct(ctx, "shen.in->", 1, a531);
  }
  KLObject* t536;
  {
    KLObject* a536[] = {t529};
    t536 = shen_apply_direct(ctx, "empty?", 1, a536);
  }
  KLObject* t535;
  if (!shen_is_boolean(ctx, t536))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t536)) {
  KLObject* t538 = shen_empty_list(ctx);
    t535 = t538;
  } else {
  KLObject* t541 = shen_string(ctx, "Prolog syntax error here:\n ");
  KLObject* t544 = shen_string(ctx, "\n ...");
  KLObject* t545 = shen_intern(ctx, "shen.r");
  KLObject* t542;
  {
    KLObject* a542[] = {t529, t544, t545};
    t542 = shen_apply_direct(ctx, "shen.app", 3, a542);
  }
  KLObject* t540;
  {
    KLObject* a540[] = {t541, t542};
    t540 = shen_apply_direct(ctx, "cn", 2, a540);
  }
  KLObject* t539;
  {
    KLObject* a539[] = {t540};
    t539 = shen_apply_direct(ctx, "simple-error", 1, a539);
  }
    t535 = t539;
  }
  KLObject* t533;
  {
    KLObject* a533[] = {t531, t535};
    t533 = shen_apply_direct(ctx, "shen.comb", 2, a533);
  }
    t525 = t533;
  }
  KLObject* t547;
  {
    KLObject* a547[] = {t525};
    t547 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a547);
  }
  KLObject* t546;
  if (!shen_is_boolean(ctx, t547))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t547)) {
  KLObject* t549 = shen_tail_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t546 = t549;
  } else {
    t546 = t525;
  }
    t520 = t546;
  } else {
    t520 = t497;
  }
    return t520;
  }
}

static KLObject* native_kl_shen_2elinearise_2dclause_18 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t552 = objects[0];
  tail_start_kl_shen_2elinearise_2dclause_18: ;
  KLObject* t553;
  {
  KLObject* t556 = shen_cons_p(ctx, t552);
  KLObject* t554;
  if (!shen_is_boolean(ctx, t556))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t556)) {
    t554 = t556;
  } else {
  KLObject* t559 = shen_tl(ctx, t552);
  KLObject* t560 = shen_cons_p(ctx, t559);
  KLObject* t557;
  if (!shen_is_boolean(ctx, t560))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t560)) {
    t557 = t560;
  } else {
  KLObject* t561 = shen_empty_list(ctx);
  KLObject* t563 = shen_tl(ctx, t552);
  KLObject* t564 = shen_tl(ctx, t563);
  KLObject* t565 = shen_eq(ctx, t561, t564);
    if (!shen_is_boolean(ctx, t565))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t557 = t565;
  }
    if (!shen_is_boolean(ctx, t557))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t554 = t557;
  }
    if (!shen_is_boolean(ctx, t554))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t554)) {
  KLObject* t570 = shen_hd(ctx, t552);
  KLObject* t572 = shen_tl(ctx, t552);
  KLObject* t573 = shen_hd(ctx, t572);
  KLObject* t568;
  {
    KLObject* a568[] = {t570, t573};
    t568 = shen_apply_direct(ctx, "@p", 2, a568);
  }
  KLObject* t567;
  {
    KLObject* a567[] = {t568};
    t567 = shen_apply_direct(ctx, "shen.linearise", 1, a567);
  }
  KLObject* t566;
  {
    KLObject* a566[] = {t567};
    t566 = shen_tail_apply_direct(ctx, "shen.lch", 1, a566);
  }
      t553 = t566;
    } else {
  KLObject* t574 = shen_true(ctx);
    if (!shen_is_boolean(ctx, t574))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t574)) {
  KLObject* t576 = shen_string(ctx, "partial function shen.linearise-clause");
  KLObject* t575;
  {
    KLObject* a575[] = {t576};
    t575 = shen_tail_apply_direct(ctx, "simple-error", 1, a575);
  }
      t553 = t575;
    } else {
      shen_simple_error(ctx, "No true case found for cond");
      t553 = shen_empty_list(ctx);
    }
    }
  }
    return t553;
  }
}

static KLObject* native_kl_shen_2elch_19 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t577 = objects[0];
  tail_start_kl_shen_2elch_19: ;
  KLObject* t578;
  {
  KLObject* t579;
  {
    KLObject* a579[] = {t577};
    t579 = shen_apply_direct(ctx, "tuple?", 1, a579);
  }
    if (!shen_is_boolean(ctx, t579))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t579)) {
  KLObject* t581;
  {
    KLObject* a581[] = {t577};
    t581 = shen_apply_direct(ctx, "fst", 1, a581);
  }
  KLObject* t584;
  {
    KLObject* a584[] = {t577};
    t584 = shen_apply_direct(ctx, "snd", 1, a584);
  }
  KLObject* t583;
  {
    KLObject* a583[] = {t584};
    t583 = shen_apply_direct(ctx, "shen.lchh", 1, a583);
  }
  KLObject* t586 = shen_empty_list(ctx);
  KLObject* t587 = shen_cons(ctx, t583, t586);
  KLObject* t588 = shen_cons(ctx, t581, t587);
      t578 = t588;
    } else {
  KLObject* t589 = shen_true(ctx);
    if (!shen_is_boolean(ctx, t589))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t589)) {
  KLObject* t591 = shen_string(ctx, "partial function shen.lch");
  KLObject* t590;
  {
    KLObject* a590[] = {t591};
    t590 = shen_tail_apply_direct(ctx, "simple-error", 1, a590);
  }
      t578 = t590;
    } else {
      shen_simple_error(ctx, "No true case found for cond");
      t578 = shen_empty_list(ctx);
    }
    }
  }
    return t578;
  }
}

static KLObject* native_kl_shen_2elchh_20 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t592 = objects[0];
  tail_start_kl_shen_2elchh_20: ;
  KLObject* t593;
  {
  KLObject* t596 = shen_cons_p(ctx, t592);
  KLObject* t594;
  if (!shen_is_boolean(ctx, t596))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t596)) {
    t594 = t596;
  } else {
  KLObject* t598 = shen_intern(ctx, "where");
  KLObject* t600 = shen_hd(ctx, t592);
  KLObject* t601 = shen_eq(ctx, t598, t600);
  KLObject* t597;
  if (!shen_is_boolean(ctx, t601))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t601)) {
    t597 = t601;
  } else {
  KLObject* t604 = shen_tl(ctx, t592);
  KLObject* t605 = shen_cons_p(ctx, t604);
  KLObject* t602;
  if (!shen_is_boolean(ctx, t605))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t605)) {
    t602 = t605;
  } else {
  KLObject* t608 = shen_tl(ctx, t592);
  KLObject* t609 = shen_hd(ctx, t608);
  KLObject* t610 = shen_cons_p(ctx, t609);
  KLObject* t606;
  if (!shen_is_boolean(ctx, t610))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t610)) {
    t606 = t610;
  } else {
  KLObject* t612 = shen_intern(ctx, "=");
  KLObject* t614 = shen_tl(ctx, t592);
  KLObject* t615 = shen_hd(ctx, t614);
  KLObject* t616 = shen_hd(ctx, t615);
  KLObject* t617 = shen_eq(ctx, t612, t616);
  KLObject* t611;
  if (!shen_is_boolean(ctx, t617))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t617)) {
    t611 = t617;
  } else {
  KLObject* t620 = shen_tl(ctx, t592);
  KLObject* t621 = shen_hd(ctx, t620);
  KLObject* t622 = shen_tl(ctx, t621);
  KLObject* t623 = shen_cons_p(ctx, t622);
  KLObject* t618;
  if (!shen_is_boolean(ctx, t623))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t623)) {
    t618 = t623;
  } else {
  KLObject* t626 = shen_tl(ctx, t592);
  KLObject* t627 = shen_hd(ctx, t626);
  KLObject* t628 = shen_tl(ctx, t627);
  KLObject* t629 = shen_tl(ctx, t628);
  KLObject* t630 = shen_cons_p(ctx, t629);
  KLObject* t624;
  if (!shen_is_boolean(ctx, t630))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t630)) {
    t624 = t630;
  } else {
  KLObject* t632 = shen_empty_list(ctx);
  KLObject* t634 = shen_tl(ctx, t592);
  KLObject* t635 = shen_hd(ctx, t634);
  KLObject* t636 = shen_tl(ctx, t635);
  KLObject* t637 = shen_tl(ctx, t636);
  KLObject* t638 = shen_tl(ctx, t637);
  KLObject* t639 = shen_eq(ctx, t632, t638);
  KLObject* t631;
  if (!shen_is_boolean(ctx, t639))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t639)) {
    t631 = t639;
  } else {
  KLObject* t642 = shen_tl(ctx, t592);
  KLObject* t643 = shen_tl(ctx, t642);
  KLObject* t644 = shen_cons_p(ctx, t643);
  KLObject* t640;
  if (!shen_is_boolean(ctx, t644))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t644)) {
    t640 = t644;
  } else {
  KLObject* t645 = shen_empty_list(ctx);
  KLObject* t647 = shen_tl(ctx, t592);
  KLObject* t648 = shen_tl(ctx, t647);
  KLObject* t649 = shen_tl(ctx, t648);
  KLObject* t650 = shen_eq(ctx, t645, t649);
    if (!shen_is_boolean(ctx, t650))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t640 = t650;
  }
    if (!shen_is_boolean(ctx, t640))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t631 = t640;
  }
    if (!shen_is_boolean(ctx, t631))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t624 = t631;
  }
    if (!shen_is_boolean(ctx, t624))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t618 = t624;
  }
    if (!shen_is_boolean(ctx, t618))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t611 = t618;
  }
    if (!shen_is_boolean(ctx, t611))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t606 = t611;
  }
    if (!shen_is_boolean(ctx, t606))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t602 = t606;
  }
    if (!shen_is_boolean(ctx, t602))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t597 = t602;
  }
    if (!shen_is_boolean(ctx, t597))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t594 = t597;
  }
    if (!shen_is_boolean(ctx, t594))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t594)) {
  KLObject* t653 = shen_intern(ctx, "shen.*occurs*");
  KLObject* t652;
  {
    KLObject* a652[] = {t653};
    t652 = shen_apply_direct(ctx, "value", 1, a652);
  }
  KLObject* t651;
  if (!shen_is_boolean(ctx, t652))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t652)) {
  KLObject* t654 = shen_intern(ctx, "is!");
    t651 = t654;
  } else {
  KLObject* t655 = shen_intern(ctx, "is");
    t651 = t655;
  }
  KLObject* t657 = shen_tl(ctx, t592);
  KLObject* t658 = shen_hd(ctx, t657);
  KLObject* t659 = shen_tl(ctx, t658);
  KLObject* t660 = shen_cons(ctx, t651, t659);
  KLObject* t663 = shen_tl(ctx, t592);
  KLObject* t664 = shen_tl(ctx, t663);
  KLObject* t665 = shen_hd(ctx, t664);
  KLObject* t661;
  {
    KLObject* a661[] = {t665};
    t661 = shen_apply_direct(ctx, "shen.lchh", 1, a661);
  }
  KLObject* t666 = shen_cons(ctx, t660, t661);
      t593 = t666;
    } else {
  KLObject* t667 = shen_true(ctx);
    if (!shen_is_boolean(ctx, t667))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t667)) {
      t593 = t592;
    } else {
      shen_simple_error(ctx, "No true case found for cond");
      t593 = shen_empty_list(ctx);
    }
    }
  }
    return t593;
  }
}

static KLObject* native_kl_shen_2e_3cclause_3e_21 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t669 = objects[0];
  tail_start_kl_shen_2e_3cclause_3e_21: ;
  KLObject* t670;
  {
    KLObject* a670[] = {t669};
    t670 = shen_apply_direct(ctx, "shen.<head>", 1, a670);
  }
  KLObject* t673;
  {
    KLObject* a673[] = {t670};
    t673 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a673);
  }
  KLObject* t672;
  if (!shen_is_boolean(ctx, t673))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t673)) {
  KLObject* t675 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t672 = t675;
  } else {
  KLObject* t676;
  {
    KLObject* a676[] = {t670};
    t676 = shen_apply_direct(ctx, "shen.<-out", 1, a676);
  }
  KLObject* t678;
  {
    KLObject* a678[] = {t670};
    t678 = shen_apply_direct(ctx, "shen.in->", 1, a678);
  }
  KLObject* t683 = shen_intern(ctx, "<--");
  KLObject* t681;
  {
    KLObject* a681[] = {t678, t683};
    t681 = shen_apply_direct(ctx, "shen.hds=?", 2, a681);
  }
  KLObject* t680;
  if (!shen_is_boolean(ctx, t681))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t681)) {
  KLObject* t684;
  {
    KLObject* a684[] = {t678};
    t684 = shen_apply_direct(ctx, "tail", 1, a684);
  }
  KLObject* t686;
  {
    KLObject* a686[] = {t684};
    t686 = shen_apply_direct(ctx, "shen.<body>", 1, a686);
  }
  KLObject* t689;
  {
    KLObject* a689[] = {t686};
    t689 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a689);
  }
  KLObject* t688;
  if (!shen_is_boolean(ctx, t689))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t689)) {
  KLObject* t691 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t688 = t691;
  } else {
  KLObject* t692;
  {
    KLObject* a692[] = {t686};
    t692 = shen_apply_direct(ctx, "shen.<-out", 1, a692);
  }
  KLObject* t694;
  {
    KLObject* a694[] = {t686};
    t694 = shen_apply_direct(ctx, "shen.in->", 1, a694);
  }
  KLObject* t696;
  {
    KLObject* a696[] = {t694};
    t696 = shen_apply_direct(ctx, "shen.<sc>", 1, a696);
  }
  KLObject* t699;
  {
    KLObject* a699[] = {t696};
    t699 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a699);
  }
  KLObject* t698;
  if (!shen_is_boolean(ctx, t699))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t699)) {
  KLObject* t701 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t698 = t701;
  } else {
  KLObject* t702;
  {
    KLObject* a702[] = {t696};
    t702 = shen_apply_direct(ctx, "shen.in->", 1, a702);
  }
  KLObject* t708 = shen_empty_list(ctx);
  KLObject* t709 = shen_cons(ctx, t692, t708);
  KLObject* t710 = shen_cons(ctx, t676, t709);
  KLObject* t704;
  {
    KLObject* a704[] = {t702, t710};
    t704 = shen_apply_direct(ctx, "shen.comb", 2, a704);
  }
    t698 = t704;
  }
    t688 = t698;
  }
    t680 = t688;
  } else {
  KLObject* t711 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t680 = t711;
  }
    t672 = t680;
  }
  KLObject* t713;
  {
    KLObject* a713[] = {t672};
    t713 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a713);
  }
  KLObject* t712;
  if (!shen_is_boolean(ctx, t713))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t713)) {
  KLObject* t715 = shen_tail_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t712 = t715;
  } else {
    t712 = t672;
  }
    return t712;
  }
}

static KLObject* native_kl_shen_2e_3chead_3e_22 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t717 = objects[0];
  tail_start_kl_shen_2e_3chead_3e_22: ;
  KLObject* t718;
  {
    KLObject* a718[] = {t717};
    t718 = shen_apply_direct(ctx, "shen.<hterm>", 1, a718);
  }
  KLObject* t721;
  {
    KLObject* a721[] = {t718};
    t721 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a721);
  }
  KLObject* t720;
  if (!shen_is_boolean(ctx, t721))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t721)) {
  KLObject* t723 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t720 = t723;
  } else {
  KLObject* t724;
  {
    KLObject* a724[] = {t718};
    t724 = shen_apply_direct(ctx, "shen.<-out", 1, a724);
  }
  KLObject* t726;
  {
    KLObject* a726[] = {t718};
    t726 = shen_apply_direct(ctx, "shen.in->", 1, a726);
  }
  KLObject* t728;
  {
    KLObject* a728[] = {t726};
    t728 = shen_apply_direct(ctx, "shen.<head>", 1, a728);
  }
  KLObject* t731;
  {
    KLObject* a731[] = {t728};
    t731 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a731);
  }
  KLObject* t730;
  if (!shen_is_boolean(ctx, t731))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t731)) {
  KLObject* t733 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t730 = t733;
  } else {
  KLObject* t734;
  {
    KLObject* a734[] = {t728};
    t734 = shen_apply_direct(ctx, "shen.<-out", 1, a734);
  }
  KLObject* t736;
  {
    KLObject* a736[] = {t728};
    t736 = shen_apply_direct(ctx, "shen.in->", 1, a736);
  }
  KLObject* t742 = shen_cons(ctx, t724, t734);
  KLObject* t738;
  {
    KLObject* a738[] = {t736, t742};
    t738 = shen_apply_direct(ctx, "shen.comb", 2, a738);
  }
    t730 = t738;
  }
    t720 = t730;
  }
  KLObject* t744;
  {
    KLObject* a744[] = {t720};
    t744 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a744);
  }
  KLObject* t743;
  if (!shen_is_boolean(ctx, t744))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t744)) {
  KLObject* t746;
  {
    KLObject* a746[] = {t717};
    t746 = shen_apply_direct(ctx, "<e>", 1, a746);
  }
  KLObject* t749;
  {
    KLObject* a749[] = {t746};
    t749 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a749);
  }
  KLObject* t748;
  if (!shen_is_boolean(ctx, t749))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t749)) {
  KLObject* t751 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t748 = t751;
  } else {
  KLObject* t752;
  {
    KLObject* a752[] = {t746};
    t752 = shen_apply_direct(ctx, "shen.in->", 1, a752);
  }
  KLObject* t756 = shen_empty_list(ctx);
  KLObject* t754;
  {
    KLObject* a754[] = {t752, t756};
    t754 = shen_apply_direct(ctx, "shen.comb", 2, a754);
  }
    t748 = t754;
  }
  KLObject* t758;
  {
    KLObject* a758[] = {t748};
    t758 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a758);
  }
  KLObject* t757;
  if (!shen_is_boolean(ctx, t758))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t758)) {
  KLObject* t760 = shen_tail_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t757 = t760;
  } else {
    t757 = t748;
  }
    t743 = t757;
  } else {
    t743 = t720;
  }
    return t743;
  }
}

static KLObject* native_kl_shen_2e_3chterm_3e_23 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t763 = objects[0];
  tail_start_kl_shen_2e_3chterm_3e_23: ;
  KLObject* t766 = shen_cons_p(ctx, t763);
  KLObject* t764;
  if (!shen_is_boolean(ctx, t766))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t766)) {
  KLObject* t767;
  {
    KLObject* a767[] = {t763};
    t767 = shen_apply_direct(ctx, "head", 1, a767);
  }
  KLObject* t769;
  {
    KLObject* a769[] = {t763};
    t769 = shen_apply_direct(ctx, "tail", 1, a769);
  }
  KLObject* t773;
  {
    KLObject* a773[] = {t767};
    t773 = shen_apply_direct(ctx, "atom?", 1, a773);
  }
  KLObject* t772;
  if (!shen_is_boolean(ctx, t773))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t773)) {
    t772 = t773;
  } else {
  KLObject* t776;
  {
    KLObject* a776[] = {t767};
    t776 = shen_apply_direct(ctx, "shen.prolog-keyword?", 1, a776);
  }
  KLObject* t775;
  {
    KLObject* a775[] = {t776};
    t775 = shen_apply_direct(ctx, "not", 1, a775);
  }
    if (!shen_is_boolean(ctx, t775))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t772 = t775;
  }
  KLObject* t771;
  if (!shen_is_boolean(ctx, t772))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t772)) {
  KLObject* t778;
  {
    KLObject* a778[] = {t769, t767};
    t778 = shen_apply_direct(ctx, "shen.comb", 2, a778);
  }
    t771 = t778;
  } else {
  KLObject* t781 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t771 = t781;
  }
    t764 = t771;
  } else {
  KLObject* t782 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t764 = t782;
  }
  KLObject* t784;
  {
    KLObject* a784[] = {t764};
    t784 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a784);
  }
  KLObject* t783;
  if (!shen_is_boolean(ctx, t784))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t784)) {
  KLObject* t788 = shen_cons_p(ctx, t763);
  KLObject* t786;
  if (!shen_is_boolean(ctx, t788))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t788)) {
  KLObject* t789;
  {
    KLObject* a789[] = {t763};
    t789 = shen_apply_direct(ctx, "head", 1, a789);
  }
  KLObject* t791;
  {
    KLObject* a791[] = {t763};
    t791 = shen_apply_direct(ctx, "tail", 1, a791);
  }
  KLObject* t796 = shen_string(ctx, ":");
  KLObject* t795;
  {
    KLObject* a795[] = {t796};
    t795 = shen_apply_direct(ctx, "intern", 1, a795);
  }
  KLObject* t797 = shen_eq(ctx, t789, t795);
  KLObject* t793;
  if (!shen_is_boolean(ctx, t797))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t797)) {
  KLObject* t798;
  {
    KLObject* a798[] = {t791, t789};
    t798 = shen_apply_direct(ctx, "shen.comb", 2, a798);
  }
    t793 = t798;
  } else {
  KLObject* t801 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t793 = t801;
  }
    t786 = t793;
  } else {
  KLObject* t802 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t786 = t802;
  }
  KLObject* t804;
  {
    KLObject* a804[] = {t786};
    t804 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a804);
  }
  KLObject* t803;
  if (!shen_is_boolean(ctx, t804))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t804)) {
  KLObject* t807;
  {
    KLObject* a807[] = {t763};
    t807 = shen_apply_direct(ctx, "shen.ccons?", 1, a807);
  }
  KLObject* t806;
  if (!shen_is_boolean(ctx, t807))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t807)) {
  KLObject* t809;
  {
    KLObject* a809[] = {t763};
    t809 = shen_apply_direct(ctx, "head", 1, a809);
  }
  KLObject* t811;
  {
    KLObject* a811[] = {t763};
    t811 = shen_apply_direct(ctx, "tail", 1, a811);
  }
  KLObject* t816 = shen_intern(ctx, "cons");
  KLObject* t814;
  {
    KLObject* a814[] = {t809, t816};
    t814 = shen_apply_direct(ctx, "shen.hds=?", 2, a814);
  }
  KLObject* t813;
  if (!shen_is_boolean(ctx, t814))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t814)) {
  KLObject* t817;
  {
    KLObject* a817[] = {t809};
    t817 = shen_apply_direct(ctx, "tail", 1, a817);
  }
  KLObject* t819;
  {
    KLObject* a819[] = {t817};
    t819 = shen_apply_direct(ctx, "shen.<hterm1>", 1, a819);
  }
  KLObject* t822;
  {
    KLObject* a822[] = {t819};
    t822 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a822);
  }
  KLObject* t821;
  if (!shen_is_boolean(ctx, t822))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t822)) {
  KLObject* t824 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t821 = t824;
  } else {
  KLObject* t825;
  {
    KLObject* a825[] = {t819};
    t825 = shen_apply_direct(ctx, "shen.<-out", 1, a825);
  }
  KLObject* t827;
  {
    KLObject* a827[] = {t819};
    t827 = shen_apply_direct(ctx, "shen.in->", 1, a827);
  }
  KLObject* t829;
  {
    KLObject* a829[] = {t827};
    t829 = shen_apply_direct(ctx, "shen.<hterm2>", 1, a829);
  }
  KLObject* t832;
  {
    KLObject* a832[] = {t829};
    t832 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a832);
  }
  KLObject* t831;
  if (!shen_is_boolean(ctx, t832))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t832)) {
  KLObject* t834 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t831 = t834;
  } else {
  KLObject* t835;
  {
    KLObject* a835[] = {t829};
    t835 = shen_apply_direct(ctx, "shen.<-out", 1, a835);
  }
  KLObject* t837;
  {
    KLObject* a837[] = {t829};
    t837 = shen_apply_direct(ctx, "shen.in->", 1, a837);
  }
  KLObject* t839;
  {
    KLObject* a839[] = {t837};
    t839 = shen_apply_direct(ctx, "<end>", 1, a839);
  }
  KLObject* t842;
  {
    KLObject* a842[] = {t839};
    t842 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a842);
  }
  KLObject* t841;
  if (!shen_is_boolean(ctx, t842))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t842)) {
  KLObject* t844 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t841 = t844;
  } else {
  KLObject* t845;
  {
    KLObject* a845[] = {t839};
    t845 = shen_apply_direct(ctx, "shen.in->", 1, a845);
  }
  KLObject* t849 = shen_intern(ctx, "cons");
  KLObject* t852 = shen_empty_list(ctx);
  KLObject* t853 = shen_cons(ctx, t835, t852);
  KLObject* t854 = shen_cons(ctx, t825, t853);
  KLObject* t855 = shen_cons(ctx, t849, t854);
  KLObject* t847;
  {
    KLObject* a847[] = {t811, t855};
    t847 = shen_apply_direct(ctx, "shen.comb", 2, a847);
  }
    t841 = t847;
  }
    t831 = t841;
  }
    t821 = t831;
  }
    t813 = t821;
  } else {
  KLObject* t856 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t813 = t856;
  }
    t806 = t813;
  } else {
  KLObject* t857 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t806 = t857;
  }
  KLObject* t859;
  {
    KLObject* a859[] = {t806};
    t859 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a859);
  }
  KLObject* t858;
  if (!shen_is_boolean(ctx, t859))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t859)) {
  KLObject* t862;
  {
    KLObject* a862[] = {t763};
    t862 = shen_apply_direct(ctx, "shen.ccons?", 1, a862);
  }
  KLObject* t861;
  if (!shen_is_boolean(ctx, t862))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t862)) {
  KLObject* t864;
  {
    KLObject* a864[] = {t763};
    t864 = shen_apply_direct(ctx, "head", 1, a864);
  }
  KLObject* t866;
  {
    KLObject* a866[] = {t763};
    t866 = shen_apply_direct(ctx, "tail", 1, a866);
  }
  KLObject* t871 = shen_intern(ctx, "+");
  KLObject* t869;
  {
    KLObject* a869[] = {t864, t871};
    t869 = shen_apply_direct(ctx, "shen.hds=?", 2, a869);
  }
  KLObject* t868;
  if (!shen_is_boolean(ctx, t869))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t869)) {
  KLObject* t872;
  {
    KLObject* a872[] = {t864};
    t872 = shen_apply_direct(ctx, "tail", 1, a872);
  }
  KLObject* t874;
  {
    KLObject* a874[] = {t872};
    t874 = shen_apply_direct(ctx, "shen.<hterm>", 1, a874);
  }
  KLObject* t877;
  {
    KLObject* a877[] = {t874};
    t877 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a877);
  }
  KLObject* t876;
  if (!shen_is_boolean(ctx, t877))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t877)) {
  KLObject* t879 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t876 = t879;
  } else {
  KLObject* t880;
  {
    KLObject* a880[] = {t874};
    t880 = shen_apply_direct(ctx, "shen.<-out", 1, a880);
  }
  KLObject* t882;
  {
    KLObject* a882[] = {t874};
    t882 = shen_apply_direct(ctx, "shen.in->", 1, a882);
  }
  KLObject* t884;
  {
    KLObject* a884[] = {t882};
    t884 = shen_apply_direct(ctx, "<end>", 1, a884);
  }
  KLObject* t887;
  {
    KLObject* a887[] = {t884};
    t887 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a887);
  }
  KLObject* t886;
  if (!shen_is_boolean(ctx, t887))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t887)) {
  KLObject* t889 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t886 = t889;
  } else {
  KLObject* t890;
  {
    KLObject* a890[] = {t884};
    t890 = shen_apply_direct(ctx, "shen.in->", 1, a890);
  }
  KLObject* t894 = shen_intern(ctx, "shen.+m");
  KLObject* t896 = shen_empty_list(ctx);
  KLObject* t897 = shen_cons(ctx, t880, t896);
  KLObject* t898 = shen_cons(ctx, t894, t897);
  KLObject* t892;
  {
    KLObject* a892[] = {t866, t898};
    t892 = shen_apply_direct(ctx, "shen.comb", 2, a892);
  }
    t886 = t892;
  }
    t876 = t886;
  }
    t868 = t876;
  } else {
  KLObject* t899 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t868 = t899;
  }
    t861 = t868;
  } else {
  KLObject* t900 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t861 = t900;
  }
  KLObject* t902;
  {
    KLObject* a902[] = {t861};
    t902 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a902);
  }
  KLObject* t901;
  if (!shen_is_boolean(ctx, t902))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t902)) {
  KLObject* t905;
  {
    KLObject* a905[] = {t763};
    t905 = shen_apply_direct(ctx, "shen.ccons?", 1, a905);
  }
  KLObject* t904;
  if (!shen_is_boolean(ctx, t905))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t905)) {
  KLObject* t907;
  {
    KLObject* a907[] = {t763};
    t907 = shen_apply_direct(ctx, "head", 1, a907);
  }
  KLObject* t909;
  {
    KLObject* a909[] = {t763};
    t909 = shen_apply_direct(ctx, "tail", 1, a909);
  }
  KLObject* t914 = shen_intern(ctx, "-");
  KLObject* t912;
  {
    KLObject* a912[] = {t907, t914};
    t912 = shen_apply_direct(ctx, "shen.hds=?", 2, a912);
  }
  KLObject* t911;
  if (!shen_is_boolean(ctx, t912))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t912)) {
  KLObject* t915;
  {
    KLObject* a915[] = {t907};
    t915 = shen_apply_direct(ctx, "tail", 1, a915);
  }
  KLObject* t917;
  {
    KLObject* a917[] = {t915};
    t917 = shen_apply_direct(ctx, "shen.<hterm>", 1, a917);
  }
  KLObject* t920;
  {
    KLObject* a920[] = {t917};
    t920 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a920);
  }
  KLObject* t919;
  if (!shen_is_boolean(ctx, t920))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t920)) {
  KLObject* t922 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t919 = t922;
  } else {
  KLObject* t923;
  {
    KLObject* a923[] = {t917};
    t923 = shen_apply_direct(ctx, "shen.<-out", 1, a923);
  }
  KLObject* t925;
  {
    KLObject* a925[] = {t917};
    t925 = shen_apply_direct(ctx, "shen.in->", 1, a925);
  }
  KLObject* t927;
  {
    KLObject* a927[] = {t925};
    t927 = shen_apply_direct(ctx, "<end>", 1, a927);
  }
  KLObject* t930;
  {
    KLObject* a930[] = {t927};
    t930 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a930);
  }
  KLObject* t929;
  if (!shen_is_boolean(ctx, t930))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t930)) {
  KLObject* t932 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t929 = t932;
  } else {
  KLObject* t933;
  {
    KLObject* a933[] = {t927};
    t933 = shen_apply_direct(ctx, "shen.in->", 1, a933);
  }
  KLObject* t937 = shen_intern(ctx, "shen.-m");
  KLObject* t939 = shen_empty_list(ctx);
  KLObject* t940 = shen_cons(ctx, t923, t939);
  KLObject* t941 = shen_cons(ctx, t937, t940);
  KLObject* t935;
  {
    KLObject* a935[] = {t909, t941};
    t935 = shen_apply_direct(ctx, "shen.comb", 2, a935);
  }
    t929 = t935;
  }
    t919 = t929;
  }
    t911 = t919;
  } else {
  KLObject* t942 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t911 = t942;
  }
    t904 = t911;
  } else {
  KLObject* t943 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t904 = t943;
  }
  KLObject* t945;
  {
    KLObject* a945[] = {t904};
    t945 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a945);
  }
  KLObject* t944;
  if (!shen_is_boolean(ctx, t945))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t945)) {
  KLObject* t948;
  {
    KLObject* a948[] = {t763};
    t948 = shen_apply_direct(ctx, "shen.ccons?", 1, a948);
  }
  KLObject* t947;
  if (!shen_is_boolean(ctx, t948))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t948)) {
  KLObject* t950;
  {
    KLObject* a950[] = {t763};
    t950 = shen_apply_direct(ctx, "head", 1, a950);
  }
  KLObject* t952;
  {
    KLObject* a952[] = {t763};
    t952 = shen_apply_direct(ctx, "tail", 1, a952);
  }
  KLObject* t957 = shen_intern(ctx, "mode");
  KLObject* t955;
  {
    KLObject* a955[] = {t950, t957};
    t955 = shen_apply_direct(ctx, "shen.hds=?", 2, a955);
  }
  KLObject* t954;
  if (!shen_is_boolean(ctx, t955))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t955)) {
  KLObject* t958;
  {
    KLObject* a958[] = {t950};
    t958 = shen_apply_direct(ctx, "tail", 1, a958);
  }
  KLObject* t960;
  {
    KLObject* a960[] = {t958};
    t960 = shen_apply_direct(ctx, "shen.<hterm>", 1, a960);
  }
  KLObject* t963;
  {
    KLObject* a963[] = {t960};
    t963 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a963);
  }
  KLObject* t962;
  if (!shen_is_boolean(ctx, t963))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t963)) {
  KLObject* t965 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t962 = t965;
  } else {
  KLObject* t966;
  {
    KLObject* a966[] = {t960};
    t966 = shen_apply_direct(ctx, "shen.<-out", 1, a966);
  }
  KLObject* t968;
  {
    KLObject* a968[] = {t960};
    t968 = shen_apply_direct(ctx, "shen.in->", 1, a968);
  }
  KLObject* t973 = shen_intern(ctx, "+");
  KLObject* t971;
  {
    KLObject* a971[] = {t968, t973};
    t971 = shen_apply_direct(ctx, "shen.hds=?", 2, a971);
  }
  KLObject* t970;
  if (!shen_is_boolean(ctx, t971))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t971)) {
  KLObject* t974;
  {
    KLObject* a974[] = {t968};
    t974 = shen_apply_direct(ctx, "tail", 1, a974);
  }
  KLObject* t976;
  {
    KLObject* a976[] = {t974};
    t976 = shen_apply_direct(ctx, "<end>", 1, a976);
  }
  KLObject* t979;
  {
    KLObject* a979[] = {t976};
    t979 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a979);
  }
  KLObject* t978;
  if (!shen_is_boolean(ctx, t979))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t979)) {
  KLObject* t981 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t978 = t981;
  } else {
  KLObject* t982;
  {
    KLObject* a982[] = {t976};
    t982 = shen_apply_direct(ctx, "shen.in->", 1, a982);
  }
  KLObject* t986 = shen_intern(ctx, "shen.+m");
  KLObject* t988 = shen_empty_list(ctx);
  KLObject* t989 = shen_cons(ctx, t966, t988);
  KLObject* t990 = shen_cons(ctx, t986, t989);
  KLObject* t984;
  {
    KLObject* a984[] = {t952, t990};
    t984 = shen_apply_direct(ctx, "shen.comb", 2, a984);
  }
    t978 = t984;
  }
    t970 = t978;
  } else {
  KLObject* t991 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t970 = t991;
  }
    t962 = t970;
  }
    t954 = t962;
  } else {
  KLObject* t992 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t954 = t992;
  }
    t947 = t954;
  } else {
  KLObject* t993 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t947 = t993;
  }
  KLObject* t995;
  {
    KLObject* a995[] = {t947};
    t995 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a995);
  }
  KLObject* t994;
  if (!shen_is_boolean(ctx, t995))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t995)) {
  KLObject* t998;
  {
    KLObject* a998[] = {t763};
    t998 = shen_apply_direct(ctx, "shen.ccons?", 1, a998);
  }
  KLObject* t997;
  if (!shen_is_boolean(ctx, t998))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t998)) {
  KLObject* t1000;
  {
    KLObject* a1000[] = {t763};
    t1000 = shen_apply_direct(ctx, "head", 1, a1000);
  }
  KLObject* t1002;
  {
    KLObject* a1002[] = {t763};
    t1002 = shen_apply_direct(ctx, "tail", 1, a1002);
  }
  KLObject* t1007 = shen_intern(ctx, "mode");
  KLObject* t1005;
  {
    KLObject* a1005[] = {t1000, t1007};
    t1005 = shen_apply_direct(ctx, "shen.hds=?", 2, a1005);
  }
  KLObject* t1004;
  if (!shen_is_boolean(ctx, t1005))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1005)) {
  KLObject* t1008;
  {
    KLObject* a1008[] = {t1000};
    t1008 = shen_apply_direct(ctx, "tail", 1, a1008);
  }
  KLObject* t1010;
  {
    KLObject* a1010[] = {t1008};
    t1010 = shen_apply_direct(ctx, "shen.<hterm>", 1, a1010);
  }
  KLObject* t1013;
  {
    KLObject* a1013[] = {t1010};
    t1013 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a1013);
  }
  KLObject* t1012;
  if (!shen_is_boolean(ctx, t1013))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1013)) {
  KLObject* t1015 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t1012 = t1015;
  } else {
  KLObject* t1016;
  {
    KLObject* a1016[] = {t1010};
    t1016 = shen_apply_direct(ctx, "shen.<-out", 1, a1016);
  }
  KLObject* t1018;
  {
    KLObject* a1018[] = {t1010};
    t1018 = shen_apply_direct(ctx, "shen.in->", 1, a1018);
  }
  KLObject* t1023 = shen_intern(ctx, "-");
  KLObject* t1021;
  {
    KLObject* a1021[] = {t1018, t1023};
    t1021 = shen_apply_direct(ctx, "shen.hds=?", 2, a1021);
  }
  KLObject* t1020;
  if (!shen_is_boolean(ctx, t1021))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1021)) {
  KLObject* t1024;
  {
    KLObject* a1024[] = {t1018};
    t1024 = shen_apply_direct(ctx, "tail", 1, a1024);
  }
  KLObject* t1026;
  {
    KLObject* a1026[] = {t1024};
    t1026 = shen_apply_direct(ctx, "<end>", 1, a1026);
  }
  KLObject* t1029;
  {
    KLObject* a1029[] = {t1026};
    t1029 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a1029);
  }
  KLObject* t1028;
  if (!shen_is_boolean(ctx, t1029))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1029)) {
  KLObject* t1031 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t1028 = t1031;
  } else {
  KLObject* t1032;
  {
    KLObject* a1032[] = {t1026};
    t1032 = shen_apply_direct(ctx, "shen.in->", 1, a1032);
  }
  KLObject* t1036 = shen_intern(ctx, "shen.-m");
  KLObject* t1038 = shen_empty_list(ctx);
  KLObject* t1039 = shen_cons(ctx, t1016, t1038);
  KLObject* t1040 = shen_cons(ctx, t1036, t1039);
  KLObject* t1034;
  {
    KLObject* a1034[] = {t1002, t1040};
    t1034 = shen_apply_direct(ctx, "shen.comb", 2, a1034);
  }
    t1028 = t1034;
  }
    t1020 = t1028;
  } else {
  KLObject* t1041 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t1020 = t1041;
  }
    t1012 = t1020;
  }
    t1004 = t1012;
  } else {
  KLObject* t1042 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t1004 = t1042;
  }
    t997 = t1004;
  } else {
  KLObject* t1043 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t997 = t1043;
  }
  KLObject* t1045;
  {
    KLObject* a1045[] = {t997};
    t1045 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a1045);
  }
  KLObject* t1044;
  if (!shen_is_boolean(ctx, t1045))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1045)) {
  KLObject* t1047 = shen_tail_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t1044 = t1047;
  } else {
    t1044 = t997;
  }
    t994 = t1044;
  } else {
    t994 = t947;
  }
    t944 = t994;
  } else {
    t944 = t904;
  }
    t901 = t944;
  } else {
    t901 = t861;
  }
    t858 = t901;
  } else {
    t858 = t806;
  }
    t803 = t858;
  } else {
    t803 = t786;
  }
    t783 = t803;
  } else {
    t783 = t764;
  }
    return t783;
  }
}

static KLObject* native_kl_shen_2eprolog_2dkeyword_3f_24 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t1055 = objects[0];
  tail_start_kl_shen_2eprolog_2dkeyword_3f_24: ;
  KLObject* t1059 = shen_string(ctx, ";");
  KLObject* t1058;
  {
    KLObject* a1058[] = {t1059};
    t1058 = shen_apply_direct(ctx, "intern", 1, a1058);
  }
  KLObject* t1060 = shen_intern(ctx, "<--");
  KLObject* t1061 = shen_empty_list(ctx);
  KLObject* t1062 = shen_cons(ctx, t1060, t1061);
  KLObject* t1063 = shen_cons(ctx, t1058, t1062);
  KLObject* t1056;
  {
    KLObject* a1056[] = {t1055, t1063};
    t1056 = shen_tail_apply_direct(ctx, "element?", 2, a1056);
  }
    return t1056;
  }
}

static KLObject* native_kl_atom_3f_25 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t1064 = objects[0];
  tail_start_kl_atom_3f_25: ;
  KLObject* t1067 = shen_symbol_p(ctx, t1064);
  KLObject* t1065;
  if (!shen_is_boolean(ctx, t1067))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (shen_boolean_value(ctx, t1067)) {
    t1065 = t1067;
  } else {
  KLObject* t1070 = shen_string_p(ctx, t1064);
  KLObject* t1068;
  if (!shen_is_boolean(ctx, t1070))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (shen_boolean_value(ctx, t1070)) {
    t1068 = t1070;
  } else {
  KLObject* t1072;
  {
    KLObject* a1072[] = {t1064};
    t1072 = shen_apply_direct(ctx, "boolean?", 1, a1072);
  }
  KLObject* t1071;
  if (!shen_is_boolean(ctx, t1072))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (shen_boolean_value(ctx, t1072)) {
    t1071 = t1072;
  } else {
  KLObject* t1076 = shen_number_p(ctx, t1064);
  KLObject* t1074;
  if (!shen_is_boolean(ctx, t1076))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (shen_boolean_value(ctx, t1076)) {
    t1074 = t1076;
  } else {
  KLObject* t1077;
  {
    KLObject* a1077[] = {t1064};
    t1077 = shen_apply_direct(ctx, "empty?", 1, a1077);
  }
    if (!shen_is_boolean(ctx, t1077))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t1074 = t1077;
  }
    if (!shen_is_boolean(ctx, t1074))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t1071 = t1074;
  }
    if (!shen_is_boolean(ctx, t1071))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t1068 = t1071;
  }
    if (!shen_is_boolean(ctx, t1068))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t1065 = t1068;
  }
    return t1065;
  }
}

static KLObject* native_kl_shen_2e_3chterm1_3e_26 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t1079 = objects[0];
  tail_start_kl_shen_2e_3chterm1_3e_26: ;
  KLObject* t1080;
  {
    KLObject* a1080[] = {t1079};
    t1080 = shen_apply_direct(ctx, "shen.<hterm>", 1, a1080);
  }
  KLObject* t1083;
  {
    KLObject* a1083[] = {t1080};
    t1083 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a1083);
  }
  KLObject* t1082;
  if (!shen_is_boolean(ctx, t1083))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1083)) {
  KLObject* t1085 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t1082 = t1085;
  } else {
  KLObject* t1086;
  {
    KLObject* a1086[] = {t1080};
    t1086 = shen_apply_direct(ctx, "shen.<-out", 1, a1086);
  }
  KLObject* t1088;
  {
    KLObject* a1088[] = {t1080};
    t1088 = shen_apply_direct(ctx, "shen.in->", 1, a1088);
  }
  KLObject* t1090;
  {
    KLObject* a1090[] = {t1088, t1086};
    t1090 = shen_apply_direct(ctx, "shen.comb", 2, a1090);
  }
    t1082 = t1090;
  }
  KLObject* t1094;
  {
    KLObject* a1094[] = {t1082};
    t1094 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a1094);
  }
  KLObject* t1093;
  if (!shen_is_boolean(ctx, t1094))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1094)) {
  KLObject* t1096 = shen_tail_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t1093 = t1096;
  } else {
    t1093 = t1082;
  }
    return t1093;
  }
}

static KLObject* native_kl_shen_2e_3chterm2_3e_27 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t1098 = objects[0];
  tail_start_kl_shen_2e_3chterm2_3e_27: ;
  KLObject* t1099;
  {
    KLObject* a1099[] = {t1098};
    t1099 = shen_apply_direct(ctx, "shen.<hterm>", 1, a1099);
  }
  KLObject* t1102;
  {
    KLObject* a1102[] = {t1099};
    t1102 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a1102);
  }
  KLObject* t1101;
  if (!shen_is_boolean(ctx, t1102))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1102)) {
  KLObject* t1104 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t1101 = t1104;
  } else {
  KLObject* t1105;
  {
    KLObject* a1105[] = {t1099};
    t1105 = shen_apply_direct(ctx, "shen.<-out", 1, a1105);
  }
  KLObject* t1107;
  {
    KLObject* a1107[] = {t1099};
    t1107 = shen_apply_direct(ctx, "shen.in->", 1, a1107);
  }
  KLObject* t1109;
  {
    KLObject* a1109[] = {t1107, t1105};
    t1109 = shen_apply_direct(ctx, "shen.comb", 2, a1109);
  }
    t1101 = t1109;
  }
  KLObject* t1113;
  {
    KLObject* a1113[] = {t1101};
    t1113 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a1113);
  }
  KLObject* t1112;
  if (!shen_is_boolean(ctx, t1113))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1113)) {
  KLObject* t1115 = shen_tail_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t1112 = t1115;
  } else {
    t1112 = t1101;
  }
    return t1112;
  }
}

static KLObject* native_kl_shen_2e_3cbody_3e_28 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t1117 = objects[0];
  tail_start_kl_shen_2e_3cbody_3e_28: ;
  KLObject* t1118;
  {
    KLObject* a1118[] = {t1117};
    t1118 = shen_apply_direct(ctx, "shen.<literal>", 1, a1118);
  }
  KLObject* t1121;
  {
    KLObject* a1121[] = {t1118};
    t1121 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a1121);
  }
  KLObject* t1120;
  if (!shen_is_boolean(ctx, t1121))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1121)) {
  KLObject* t1123 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t1120 = t1123;
  } else {
  KLObject* t1124;
  {
    KLObject* a1124[] = {t1118};
    t1124 = shen_apply_direct(ctx, "shen.<-out", 1, a1124);
  }
  KLObject* t1126;
  {
    KLObject* a1126[] = {t1118};
    t1126 = shen_apply_direct(ctx, "shen.in->", 1, a1126);
  }
  KLObject* t1128;
  {
    KLObject* a1128[] = {t1126};
    t1128 = shen_apply_direct(ctx, "shen.<body>", 1, a1128);
  }
  KLObject* t1131;
  {
    KLObject* a1131[] = {t1128};
    t1131 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a1131);
  }
  KLObject* t1130;
  if (!shen_is_boolean(ctx, t1131))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1131)) {
  KLObject* t1133 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t1130 = t1133;
  } else {
  KLObject* t1134;
  {
    KLObject* a1134[] = {t1128};
    t1134 = shen_apply_direct(ctx, "shen.<-out", 1, a1134);
  }
  KLObject* t1136;
  {
    KLObject* a1136[] = {t1128};
    t1136 = shen_apply_direct(ctx, "shen.in->", 1, a1136);
  }
  KLObject* t1142 = shen_cons(ctx, t1124, t1134);
  KLObject* t1138;
  {
    KLObject* a1138[] = {t1136, t1142};
    t1138 = shen_apply_direct(ctx, "shen.comb", 2, a1138);
  }
    t1130 = t1138;
  }
    t1120 = t1130;
  }
  KLObject* t1144;
  {
    KLObject* a1144[] = {t1120};
    t1144 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a1144);
  }
  KLObject* t1143;
  if (!shen_is_boolean(ctx, t1144))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1144)) {
  KLObject* t1146;
  {
    KLObject* a1146[] = {t1117};
    t1146 = shen_apply_direct(ctx, "<e>", 1, a1146);
  }
  KLObject* t1149;
  {
    KLObject* a1149[] = {t1146};
    t1149 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a1149);
  }
  KLObject* t1148;
  if (!shen_is_boolean(ctx, t1149))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1149)) {
  KLObject* t1151 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t1148 = t1151;
  } else {
  KLObject* t1152;
  {
    KLObject* a1152[] = {t1146};
    t1152 = shen_apply_direct(ctx, "shen.in->", 1, a1152);
  }
  KLObject* t1156 = shen_empty_list(ctx);
  KLObject* t1154;
  {
    KLObject* a1154[] = {t1152, t1156};
    t1154 = shen_apply_direct(ctx, "shen.comb", 2, a1154);
  }
    t1148 = t1154;
  }
  KLObject* t1158;
  {
    KLObject* a1158[] = {t1148};
    t1158 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a1158);
  }
  KLObject* t1157;
  if (!shen_is_boolean(ctx, t1158))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1158)) {
  KLObject* t1160 = shen_tail_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t1157 = t1160;
  } else {
    t1157 = t1148;
  }
    t1143 = t1157;
  } else {
    t1143 = t1120;
  }
    return t1143;
  }
}

static KLObject* native_kl_shen_2e_3cliteral_3e_29 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t1163 = objects[0];
  tail_start_kl_shen_2e_3cliteral_3e_29: ;
  KLObject* t1167 = shen_intern(ctx, "!");
  KLObject* t1165;
  {
    KLObject* a1165[] = {t1163, t1167};
    t1165 = shen_apply_direct(ctx, "shen.hds=?", 2, a1165);
  }
  KLObject* t1164;
  if (!shen_is_boolean(ctx, t1165))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1165)) {
  KLObject* t1168;
  {
    KLObject* a1168[] = {t1163};
    t1168 = shen_apply_direct(ctx, "tail", 1, a1168);
  }
  KLObject* t1172 = shen_intern(ctx, "!");
  KLObject* t1170;
  {
    KLObject* a1170[] = {t1168, t1172};
    t1170 = shen_apply_direct(ctx, "shen.comb", 2, a1170);
  }
    t1164 = t1170;
  } else {
  KLObject* t1173 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t1164 = t1173;
  }
  KLObject* t1175;
  {
    KLObject* a1175[] = {t1164};
    t1175 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a1175);
  }
  KLObject* t1174;
  if (!shen_is_boolean(ctx, t1175))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1175)) {
  KLObject* t1178;
  {
    KLObject* a1178[] = {t1163};
    t1178 = shen_apply_direct(ctx, "shen.ccons?", 1, a1178);
  }
  KLObject* t1177;
  if (!shen_is_boolean(ctx, t1178))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1178)) {
  KLObject* t1180;
  {
    KLObject* a1180[] = {t1163};
    t1180 = shen_apply_direct(ctx, "head", 1, a1180);
  }
  KLObject* t1182;
  {
    KLObject* a1182[] = {t1163};
    t1182 = shen_apply_direct(ctx, "tail", 1, a1182);
  }
  KLObject* t1184;
  {
    KLObject* a1184[] = {t1180};
    t1184 = shen_apply_direct(ctx, "shen.<bterms>", 1, a1184);
  }
  KLObject* t1187;
  {
    KLObject* a1187[] = {t1184};
    t1187 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a1187);
  }
  KLObject* t1186;
  if (!shen_is_boolean(ctx, t1187))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1187)) {
  KLObject* t1189 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t1186 = t1189;
  } else {
  KLObject* t1190;
  {
    KLObject* a1190[] = {t1184};
    t1190 = shen_apply_direct(ctx, "shen.<-out", 1, a1190);
  }
  KLObject* t1192;
  {
    KLObject* a1192[] = {t1184};
    t1192 = shen_apply_direct(ctx, "shen.in->", 1, a1192);
  }
  KLObject* t1194;
  {
    KLObject* a1194[] = {t1192};
    t1194 = shen_apply_direct(ctx, "<end>", 1, a1194);
  }
  KLObject* t1197;
  {
    KLObject* a1197[] = {t1194};
    t1197 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a1197);
  }
  KLObject* t1196;
  if (!shen_is_boolean(ctx, t1197))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1197)) {
  KLObject* t1199 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t1196 = t1199;
  } else {
  KLObject* t1200;
  {
    KLObject* a1200[] = {t1194};
    t1200 = shen_apply_direct(ctx, "shen.in->", 1, a1200);
  }
  KLObject* t1202;
  {
    KLObject* a1202[] = {t1182, t1190};
    t1202 = shen_apply_direct(ctx, "shen.comb", 2, a1202);
  }
    t1196 = t1202;
  }
    t1186 = t1196;
  }
    t1177 = t1186;
  } else {
  KLObject* t1205 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t1177 = t1205;
  }
  KLObject* t1207;
  {
    KLObject* a1207[] = {t1177};
    t1207 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a1207);
  }
  KLObject* t1206;
  if (!shen_is_boolean(ctx, t1207))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1207)) {
  KLObject* t1209 = shen_tail_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t1206 = t1209;
  } else {
    t1206 = t1177;
  }
    t1174 = t1206;
  } else {
    t1174 = t1164;
  }
    return t1174;
  }
}

static KLObject* native_kl_shen_2e_3cbterms_3e_30 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t1212 = objects[0];
  tail_start_kl_shen_2e_3cbterms_3e_30: ;
  KLObject* t1213;
  {
    KLObject* a1213[] = {t1212};
    t1213 = shen_apply_direct(ctx, "shen.<bterm>", 1, a1213);
  }
  KLObject* t1216;
  {
    KLObject* a1216[] = {t1213};
    t1216 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a1216);
  }
  KLObject* t1215;
  if (!shen_is_boolean(ctx, t1216))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1216)) {
  KLObject* t1218 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t1215 = t1218;
  } else {
  KLObject* t1219;
  {
    KLObject* a1219[] = {t1213};
    t1219 = shen_apply_direct(ctx, "shen.<-out", 1, a1219);
  }
  KLObject* t1221;
  {
    KLObject* a1221[] = {t1213};
    t1221 = shen_apply_direct(ctx, "shen.in->", 1, a1221);
  }
  KLObject* t1223;
  {
    KLObject* a1223[] = {t1221};
    t1223 = shen_apply_direct(ctx, "shen.<bterms>", 1, a1223);
  }
  KLObject* t1226;
  {
    KLObject* a1226[] = {t1223};
    t1226 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a1226);
  }
  KLObject* t1225;
  if (!shen_is_boolean(ctx, t1226))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1226)) {
  KLObject* t1228 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t1225 = t1228;
  } else {
  KLObject* t1229;
  {
    KLObject* a1229[] = {t1223};
    t1229 = shen_apply_direct(ctx, "shen.<-out", 1, a1229);
  }
  KLObject* t1231;
  {
    KLObject* a1231[] = {t1223};
    t1231 = shen_apply_direct(ctx, "shen.in->", 1, a1231);
  }
  KLObject* t1237 = shen_cons(ctx, t1219, t1229);
  KLObject* t1233;
  {
    KLObject* a1233[] = {t1231, t1237};
    t1233 = shen_apply_direct(ctx, "shen.comb", 2, a1233);
  }
    t1225 = t1233;
  }
    t1215 = t1225;
  }
  KLObject* t1239;
  {
    KLObject* a1239[] = {t1215};
    t1239 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a1239);
  }
  KLObject* t1238;
  if (!shen_is_boolean(ctx, t1239))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1239)) {
  KLObject* t1241;
  {
    KLObject* a1241[] = {t1212};
    t1241 = shen_apply_direct(ctx, "<e>", 1, a1241);
  }
  KLObject* t1244;
  {
    KLObject* a1244[] = {t1241};
    t1244 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a1244);
  }
  KLObject* t1243;
  if (!shen_is_boolean(ctx, t1244))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1244)) {
  KLObject* t1246 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t1243 = t1246;
  } else {
  KLObject* t1247;
  {
    KLObject* a1247[] = {t1241};
    t1247 = shen_apply_direct(ctx, "shen.in->", 1, a1247);
  }
  KLObject* t1251 = shen_empty_list(ctx);
  KLObject* t1249;
  {
    KLObject* a1249[] = {t1247, t1251};
    t1249 = shen_apply_direct(ctx, "shen.comb", 2, a1249);
  }
    t1243 = t1249;
  }
  KLObject* t1253;
  {
    KLObject* a1253[] = {t1243};
    t1253 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a1253);
  }
  KLObject* t1252;
  if (!shen_is_boolean(ctx, t1253))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1253)) {
  KLObject* t1255 = shen_tail_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t1252 = t1255;
  } else {
    t1252 = t1243;
  }
    t1238 = t1252;
  } else {
    t1238 = t1215;
  }
    return t1238;
  }
}

static KLObject* native_kl_shen_2e_3cbterm_3e_31 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t1258 = objects[0];
  tail_start_kl_shen_2e_3cbterm_3e_31: ;
  KLObject* t1259;
  {
    KLObject* a1259[] = {t1258};
    t1259 = shen_apply_direct(ctx, "shen.<wildcard>", 1, a1259);
  }
  KLObject* t1262;
  {
    KLObject* a1262[] = {t1259};
    t1262 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a1262);
  }
  KLObject* t1261;
  if (!shen_is_boolean(ctx, t1262))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1262)) {
  KLObject* t1264 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t1261 = t1264;
  } else {
  KLObject* t1265;
  {
    KLObject* a1265[] = {t1259};
    t1265 = shen_apply_direct(ctx, "shen.<-out", 1, a1265);
  }
  KLObject* t1267;
  {
    KLObject* a1267[] = {t1259};
    t1267 = shen_apply_direct(ctx, "shen.in->", 1, a1267);
  }
  KLObject* t1269;
  {
    KLObject* a1269[] = {t1267, t1265};
    t1269 = shen_apply_direct(ctx, "shen.comb", 2, a1269);
  }
    t1261 = t1269;
  }
  KLObject* t1273;
  {
    KLObject* a1273[] = {t1261};
    t1273 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a1273);
  }
  KLObject* t1272;
  if (!shen_is_boolean(ctx, t1273))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1273)) {
  KLObject* t1277 = shen_cons_p(ctx, t1258);
  KLObject* t1275;
  if (!shen_is_boolean(ctx, t1277))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1277)) {
  KLObject* t1278;
  {
    KLObject* a1278[] = {t1258};
    t1278 = shen_apply_direct(ctx, "head", 1, a1278);
  }
  KLObject* t1280;
  {
    KLObject* a1280[] = {t1258};
    t1280 = shen_apply_direct(ctx, "tail", 1, a1280);
  }
  KLObject* t1283;
  {
    KLObject* a1283[] = {t1278};
    t1283 = shen_apply_direct(ctx, "atom?", 1, a1283);
  }
  KLObject* t1282;
  if (!shen_is_boolean(ctx, t1283))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1283)) {
  KLObject* t1285;
  {
    KLObject* a1285[] = {t1280, t1278};
    t1285 = shen_apply_direct(ctx, "shen.comb", 2, a1285);
  }
    t1282 = t1285;
  } else {
  KLObject* t1288 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t1282 = t1288;
  }
    t1275 = t1282;
  } else {
  KLObject* t1289 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t1275 = t1289;
  }
  KLObject* t1291;
  {
    KLObject* a1291[] = {t1275};
    t1291 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a1291);
  }
  KLObject* t1290;
  if (!shen_is_boolean(ctx, t1291))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1291)) {
  KLObject* t1294;
  {
    KLObject* a1294[] = {t1258};
    t1294 = shen_apply_direct(ctx, "shen.ccons?", 1, a1294);
  }
  KLObject* t1293;
  if (!shen_is_boolean(ctx, t1294))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1294)) {
  KLObject* t1296;
  {
    KLObject* a1296[] = {t1258};
    t1296 = shen_apply_direct(ctx, "head", 1, a1296);
  }
  KLObject* t1298;
  {
    KLObject* a1298[] = {t1258};
    t1298 = shen_apply_direct(ctx, "tail", 1, a1298);
  }
  KLObject* t1300;
  {
    KLObject* a1300[] = {t1296};
    t1300 = shen_apply_direct(ctx, "shen.<bterms>", 1, a1300);
  }
  KLObject* t1303;
  {
    KLObject* a1303[] = {t1300};
    t1303 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a1303);
  }
  KLObject* t1302;
  if (!shen_is_boolean(ctx, t1303))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1303)) {
  KLObject* t1305 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t1302 = t1305;
  } else {
  KLObject* t1306;
  {
    KLObject* a1306[] = {t1300};
    t1306 = shen_apply_direct(ctx, "shen.<-out", 1, a1306);
  }
  KLObject* t1308;
  {
    KLObject* a1308[] = {t1300};
    t1308 = shen_apply_direct(ctx, "shen.in->", 1, a1308);
  }
  KLObject* t1310;
  {
    KLObject* a1310[] = {t1308};
    t1310 = shen_apply_direct(ctx, "<end>", 1, a1310);
  }
  KLObject* t1313;
  {
    KLObject* a1313[] = {t1310};
    t1313 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a1313);
  }
  KLObject* t1312;
  if (!shen_is_boolean(ctx, t1313))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1313)) {
  KLObject* t1315 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t1312 = t1315;
  } else {
  KLObject* t1316;
  {
    KLObject* a1316[] = {t1310};
    t1316 = shen_apply_direct(ctx, "shen.in->", 1, a1316);
  }
  KLObject* t1318;
  {
    KLObject* a1318[] = {t1298, t1306};
    t1318 = shen_apply_direct(ctx, "shen.comb", 2, a1318);
  }
    t1312 = t1318;
  }
    t1302 = t1312;
  }
    t1293 = t1302;
  } else {
  KLObject* t1321 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t1293 = t1321;
  }
  KLObject* t1323;
  {
    KLObject* a1323[] = {t1293};
    t1323 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a1323);
  }
  KLObject* t1322;
  if (!shen_is_boolean(ctx, t1323))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1323)) {
  KLObject* t1325 = shen_tail_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t1322 = t1325;
  } else {
    t1322 = t1293;
  }
    t1290 = t1322;
  } else {
    t1290 = t1275;
  }
    t1272 = t1290;
  } else {
    t1272 = t1261;
  }
    return t1272;
  }
}

static KLObject* native_kl_shen_2e_3cwildcard_3e_32 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t1329 = objects[0];
  tail_start_kl_shen_2e_3cwildcard_3e_32: ;
  KLObject* t1332 = shen_cons_p(ctx, t1329);
  KLObject* t1330;
  if (!shen_is_boolean(ctx, t1332))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1332)) {
  KLObject* t1333;
  {
    KLObject* a1333[] = {t1329};
    t1333 = shen_apply_direct(ctx, "head", 1, a1333);
  }
  KLObject* t1335;
  {
    KLObject* a1335[] = {t1329};
    t1335 = shen_apply_direct(ctx, "tail", 1, a1335);
  }
  KLObject* t1339 = shen_intern(ctx, "_");
  KLObject* t1340 = shen_eq(ctx, t1333, t1339);
  KLObject* t1337;
  if (!shen_is_boolean(ctx, t1340))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1340)) {
  KLObject* t1344 = shen_intern(ctx, "Y");
  KLObject* t1343;
  {
    KLObject* a1343[] = {t1344};
    t1343 = shen_apply_direct(ctx, "gensym", 1, a1343);
  }
  KLObject* t1341;
  {
    KLObject* a1341[] = {t1335, t1343};
    t1341 = shen_apply_direct(ctx, "shen.comb", 2, a1341);
  }
    t1337 = t1341;
  } else {
  KLObject* t1345 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t1337 = t1345;
  }
    t1330 = t1337;
  } else {
  KLObject* t1346 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t1330 = t1346;
  }
  KLObject* t1348;
  {
    KLObject* a1348[] = {t1330};
    t1348 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a1348);
  }
  KLObject* t1347;
  if (!shen_is_boolean(ctx, t1348))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1348)) {
  KLObject* t1350 = shen_tail_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t1347 = t1350;
  } else {
    t1347 = t1330;
  }
    return t1347;
  }
}

static KLObject* native_kl_shen_2e_3csc_3e_33 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t1352 = objects[0];
  tail_start_kl_shen_2e_3csc_3e_33: ;
  KLObject* t1355 = shen_cons_p(ctx, t1352);
  KLObject* t1353;
  if (!shen_is_boolean(ctx, t1355))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1355)) {
  KLObject* t1356;
  {
    KLObject* a1356[] = {t1352};
    t1356 = shen_apply_direct(ctx, "head", 1, a1356);
  }
  KLObject* t1358;
  {
    KLObject* a1358[] = {t1352};
    t1358 = shen_apply_direct(ctx, "tail", 1, a1358);
  }
  KLObject* t1361;
  {
    KLObject* a1361[] = {t1356};
    t1361 = shen_apply_direct(ctx, "shen.semicolon?", 1, a1361);
  }
  KLObject* t1360;
  if (!shen_is_boolean(ctx, t1361))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1361)) {
  KLObject* t1363;
  {
    KLObject* a1363[] = {t1358, t1356};
    t1363 = shen_apply_direct(ctx, "shen.comb", 2, a1363);
  }
    t1360 = t1363;
  } else {
  KLObject* t1366 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t1360 = t1366;
  }
    t1353 = t1360;
  } else {
  KLObject* t1367 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t1353 = t1367;
  }
  KLObject* t1369;
  {
    KLObject* a1369[] = {t1353};
    t1369 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a1369);
  }
  KLObject* t1368;
  if (!shen_is_boolean(ctx, t1369))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1369)) {
  KLObject* t1371 = shen_tail_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t1368 = t1371;
  } else {
    t1368 = t1353;
  }
    return t1368;
  }
}

static KLObject* native_kl_shen_2ehorn_2dclause_2dprocedure_34 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t1373 = objects[0];
    KLObject* t1374 = objects[1];
  tail_start_kl_shen_2ehorn_2dclause_2dprocedure_34: ;
  KLObject* t1376 = shen_intern(ctx, "B");
  KLObject* t1375;
  {
    KLObject* a1375[] = {t1376};
    t1375 = shen_apply_direct(ctx, "gensym", 1, a1375);
  }
  KLObject* t1378 = shen_intern(ctx, "L");
  KLObject* t1377;
  {
    KLObject* a1377[] = {t1378};
    t1377 = shen_apply_direct(ctx, "gensym", 1, a1377);
  }
  KLObject* t1380 = shen_intern(ctx, "K");
  KLObject* t1379;
  {
    KLObject* a1379[] = {t1380};
    t1379 = shen_apply_direct(ctx, "gensym", 1, a1379);
  }
  KLObject* t1382 = shen_intern(ctx, "C");
  KLObject* t1381;
  {
    KLObject* a1381[] = {t1382};
    t1381 = shen_apply_direct(ctx, "gensym", 1, a1381);
  }
  KLObject* t1383;
  {
    KLObject* a1383[] = {t1374};
    t1383 = shen_apply_direct(ctx, "shen.prolog-parameters", 1, a1383);
  }
  KLObject* t1385;
  {
    KLObject* a1385[] = {t1374};
    t1385 = shen_apply_direct(ctx, "shen.hascut?", 1, a1385);
  }
  KLObject* t1387;
  {
    KLObject* a1387[] = {t1374, t1383, t1375, t1377, t1379, t1381, t1385};
    t1387 = shen_apply_direct(ctx, "shen.prolog-fbody", 7, a1387);
  }
  KLObject* t1395;
  if (!shen_is_boolean(ctx, t1385))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1385)) {
  KLObject* t1397 = shen_intern(ctx, "let");
  KLObject* t1399 = shen_intern(ctx, "+");
  KLObject* t1401 = shen_number_l(ctx, 1);
  KLObject* t1402 = shen_empty_list(ctx);
  KLObject* t1403 = shen_cons(ctx, t1401, t1402);
  KLObject* t1404 = shen_cons(ctx, t1379, t1403);
  KLObject* t1405 = shen_cons(ctx, t1399, t1404);
  KLObject* t1407 = shen_empty_list(ctx);
  KLObject* t1408 = shen_cons(ctx, t1387, t1407);
  KLObject* t1409 = shen_cons(ctx, t1405, t1408);
  KLObject* t1410 = shen_cons(ctx, t1379, t1409);
  KLObject* t1411 = shen_cons(ctx, t1397, t1410);
    t1395 = t1411;
  } else {
    t1395 = t1387;
  }
  KLObject* t1413 = shen_intern(ctx, "define");
  KLObject* t1422 = shen_intern(ctx, "->");
  KLObject* t1423 = shen_empty_list(ctx);
  KLObject* t1424 = shen_cons(ctx, t1422, t1423);
  KLObject* t1425 = shen_cons(ctx, t1381, t1424);
  KLObject* t1426 = shen_cons(ctx, t1379, t1425);
  KLObject* t1427 = shen_cons(ctx, t1377, t1426);
  KLObject* t1428 = shen_cons(ctx, t1375, t1427);
  KLObject* t1430 = shen_empty_list(ctx);
  KLObject* t1431 = shen_cons(ctx, t1395, t1430);
  KLObject* t1417;
  {
    KLObject* a1417[] = {t1428, t1431};
    t1417 = shen_apply_direct(ctx, "append", 2, a1417);
  }
  KLObject* t1415;
  {
    KLObject* a1415[] = {t1383, t1417};
    t1415 = shen_apply_direct(ctx, "append", 2, a1415);
  }
  KLObject* t1432 = shen_cons(ctx, t1373, t1415);
  KLObject* t1433 = shen_cons(ctx, t1413, t1432);
    return t1433;
  }
}

static KLObject* native_kl_shen_2ehascut_3f_35 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t1435 = objects[0];
  tail_start_kl_shen_2ehascut_3f_35: ;
  KLObject* t1436;
  {
  KLObject* t1437 = shen_intern(ctx, "!");
  KLObject* t1439 = shen_eq(ctx, t1437, t1435);
    if (!shen_is_boolean(ctx, t1439))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t1439)) {
  KLObject* t1440 = shen_true(ctx);
      t1436 = t1440;
    } else {
  KLObject* t1442 = shen_cons_p(ctx, t1435);
    if (!shen_is_boolean(ctx, t1442))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t1442)) {
  KLObject* t1446 = shen_hd(ctx, t1435);
  KLObject* t1444;
  {
    KLObject* a1444[] = {t1446};
    t1444 = shen_apply_direct(ctx, "shen.hascut?", 1, a1444);
  }
  KLObject* t1443;
  if (!shen_is_boolean(ctx, t1444))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (shen_boolean_value(ctx, t1444)) {
    t1443 = t1444;
  } else {
  KLObject* t1449 = shen_tl(ctx, t1435);
  KLObject* t1447;
  {
    KLObject* a1447[] = {t1449};
    t1447 = shen_apply_direct(ctx, "shen.hascut?", 1, a1447);
  }
    if (!shen_is_boolean(ctx, t1447))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t1443 = t1447;
  }
      t1436 = t1443;
    } else {
  KLObject* t1450 = shen_true(ctx);
    if (!shen_is_boolean(ctx, t1450))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t1450)) {
  KLObject* t1451 = shen_false(ctx);
      t1436 = t1451;
    } else {
      shen_simple_error(ctx, "No true case found for cond");
      t1436 = shen_empty_list(ctx);
    }
    }
    }
  }
    return t1436;
  }
}

static KLObject* native_kl_shen_2eprolog_2dparameters_36 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t1452 = objects[0];
  tail_start_kl_shen_2eprolog_2dparameters_36: ;
  KLObject* t1453;
  {
  KLObject* t1456 = shen_cons_p(ctx, t1452);
  KLObject* t1454;
  if (!shen_is_boolean(ctx, t1456))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t1456)) {
    t1454 = t1456;
  } else {
  KLObject* t1458 = shen_hd(ctx, t1452);
  KLObject* t1459 = shen_cons_p(ctx, t1458);
    if (!shen_is_boolean(ctx, t1459))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t1454 = t1459;
  }
    if (!shen_is_boolean(ctx, t1454))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t1454)) {
  KLObject* t1463 = shen_hd(ctx, t1452);
  KLObject* t1464 = shen_hd(ctx, t1463);
  KLObject* t1461;
  {
    KLObject* a1461[] = {t1464};
    t1461 = shen_apply_direct(ctx, "length", 1, a1461);
  }
  KLObject* t1460;
  {
    KLObject* a1460[] = {t1461};
    t1460 = shen_tail_apply_direct(ctx, "shen.parameters", 1, a1460);
  }
      t1453 = t1460;
    } else {
  KLObject* t1465 = shen_true(ctx);
    if (!shen_is_boolean(ctx, t1465))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t1465)) {
  KLObject* t1467 = shen_string(ctx, "partial function shen.prolog-parameters");
  KLObject* t1466;
  {
    KLObject* a1466[] = {t1467};
    t1466 = shen_tail_apply_direct(ctx, "simple-error", 1, a1466);
  }
      t1453 = t1466;
    } else {
      shen_simple_error(ctx, "No true case found for cond");
      t1453 = shen_empty_list(ctx);
    }
    }
  }
    return t1453;
  }
}

static KLObject* native_kl_shen_2eprolog_2dfbody_37 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t1468 = objects[0];
    KLObject* t1469 = objects[1];
    KLObject* t1470 = objects[2];
    KLObject* t1471 = objects[3];
    KLObject* t1472 = objects[4];
    KLObject* t1473 = objects[5];
    KLObject* t1474 = objects[6];
  tail_start_kl_shen_2eprolog_2dfbody_37: ;
  KLObject* t1475;
  {
  KLObject* t1477 = shen_empty_list(ctx);
  KLObject* t1479 = shen_eq(ctx, t1477, t1468);
  KLObject* t1476;
  if (!shen_is_boolean(ctx, t1479))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t1479)) {
    t1476 = t1479;
  } else {
  KLObject* t1480 = shen_true(ctx);
  KLObject* t1482 = shen_eq(ctx, t1480, t1474);
    if (!shen_is_boolean(ctx, t1482))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t1476 = t1482;
  }
    if (!shen_is_boolean(ctx, t1476))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t1476)) {
  KLObject* t1483 = shen_intern(ctx, "shen.unlock");
  KLObject* t1486 = shen_empty_list(ctx);
  KLObject* t1487 = shen_cons(ctx, t1472, t1486);
  KLObject* t1488 = shen_cons(ctx, t1471, t1487);
  KLObject* t1489 = shen_cons(ctx, t1483, t1488);
      t1475 = t1489;
    } else {
  KLObject* t1492 = shen_cons_p(ctx, t1468);
  KLObject* t1490;
  if (!shen_is_boolean(ctx, t1492))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t1492)) {
    t1490 = t1492;
  } else {
  KLObject* t1495 = shen_hd(ctx, t1468);
  KLObject* t1496 = shen_cons_p(ctx, t1495);
  KLObject* t1493;
  if (!shen_is_boolean(ctx, t1496))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t1496)) {
    t1493 = t1496;
  } else {
  KLObject* t1499 = shen_hd(ctx, t1468);
  KLObject* t1500 = shen_tl(ctx, t1499);
  KLObject* t1501 = shen_cons_p(ctx, t1500);
  KLObject* t1497;
  if (!shen_is_boolean(ctx, t1501))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t1501)) {
    t1497 = t1501;
  } else {
  KLObject* t1503 = shen_empty_list(ctx);
  KLObject* t1505 = shen_hd(ctx, t1468);
  KLObject* t1506 = shen_tl(ctx, t1505);
  KLObject* t1507 = shen_tl(ctx, t1506);
  KLObject* t1508 = shen_eq(ctx, t1503, t1507);
  KLObject* t1502;
  if (!shen_is_boolean(ctx, t1508))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t1508)) {
    t1502 = t1508;
  } else {
  KLObject* t1510 = shen_empty_list(ctx);
  KLObject* t1512 = shen_tl(ctx, t1468);
  KLObject* t1513 = shen_eq(ctx, t1510, t1512);
  KLObject* t1509;
  if (!shen_is_boolean(ctx, t1513))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t1513)) {
    t1509 = t1513;
  } else {
  KLObject* t1514 = shen_false(ctx);
  KLObject* t1516 = shen_eq(ctx, t1514, t1474);
    if (!shen_is_boolean(ctx, t1516))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t1509 = t1516;
  }
    if (!shen_is_boolean(ctx, t1509))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t1502 = t1509;
  }
    if (!shen_is_boolean(ctx, t1502))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t1497 = t1502;
  }
    if (!shen_is_boolean(ctx, t1497))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t1493 = t1497;
  }
    if (!shen_is_boolean(ctx, t1493))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t1490 = t1493;
  }
    if (!shen_is_boolean(ctx, t1490))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t1490)) {
  KLObject* t1519 = shen_hd(ctx, t1468);
  KLObject* t1520 = shen_hd(ctx, t1519);
  KLObject* t1522 = shen_hd(ctx, t1468);
  KLObject* t1523 = shen_tl(ctx, t1522);
  KLObject* t1524 = shen_hd(ctx, t1523);
  KLObject* t1517;
  {
    KLObject* a1517[] = {t1520, t1524, t1470, t1471, t1472, t1473};
    t1517 = shen_apply_direct(ctx, "shen.continue", 6, a1517);
  }
  KLObject* t1529 = shen_intern(ctx, "if");
  KLObject* t1530 = shen_intern(ctx, "shen.unlocked?");
  KLObject* t1532 = shen_empty_list(ctx);
  KLObject* t1533 = shen_cons(ctx, t1471, t1532);
  KLObject* t1534 = shen_cons(ctx, t1530, t1533);
  KLObject* t1536 = shen_intern(ctx, "shen.+m");
  KLObject* t1538 = shen_hd(ctx, t1468);
  KLObject* t1539 = shen_hd(ctx, t1538);
  KLObject* t1535;
  {
    KLObject* a1535[] = {t1536, t1539, t1469, t1470, t1517};
    t1535 = shen_apply_direct(ctx, "shen.compile-head", 5, a1535);
  }
  KLObject* t1543 = shen_false(ctx);
  KLObject* t1544 = shen_empty_list(ctx);
  KLObject* t1545 = shen_cons(ctx, t1543, t1544);
  KLObject* t1546 = shen_cons(ctx, t1535, t1545);
  KLObject* t1547 = shen_cons(ctx, t1534, t1546);
  KLObject* t1548 = shen_cons(ctx, t1529, t1547);
      t1475 = t1548;
    } else {
  KLObject* t1551 = shen_cons_p(ctx, t1468);
  KLObject* t1549;
  if (!shen_is_boolean(ctx, t1551))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t1551)) {
    t1549 = t1551;
  } else {
  KLObject* t1554 = shen_hd(ctx, t1468);
  KLObject* t1555 = shen_cons_p(ctx, t1554);
  KLObject* t1552;
  if (!shen_is_boolean(ctx, t1555))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t1555)) {
    t1552 = t1555;
  } else {
  KLObject* t1558 = shen_hd(ctx, t1468);
  KLObject* t1559 = shen_tl(ctx, t1558);
  KLObject* t1560 = shen_cons_p(ctx, t1559);
  KLObject* t1556;
  if (!shen_is_boolean(ctx, t1560))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t1560)) {
    t1556 = t1560;
  } else {
  KLObject* t1561 = shen_empty_list(ctx);
  KLObject* t1563 = shen_hd(ctx, t1468);
  KLObject* t1564 = shen_tl(ctx, t1563);
  KLObject* t1565 = shen_tl(ctx, t1564);
  KLObject* t1566 = shen_eq(ctx, t1561, t1565);
    if (!shen_is_boolean(ctx, t1566))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t1556 = t1566;
  }
    if (!shen_is_boolean(ctx, t1556))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t1552 = t1556;
  }
    if (!shen_is_boolean(ctx, t1552))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t1549 = t1552;
  }
    if (!shen_is_boolean(ctx, t1549))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t1549)) {
  KLObject* t1568 = shen_intern(ctx, "C");
  KLObject* t1567;
  {
    KLObject* a1567[] = {t1568};
    t1567 = shen_apply_direct(ctx, "gensym", 1, a1567);
  }
  KLObject* t1571 = shen_hd(ctx, t1468);
  KLObject* t1572 = shen_hd(ctx, t1571);
  KLObject* t1574 = shen_hd(ctx, t1468);
  KLObject* t1575 = shen_tl(ctx, t1574);
  KLObject* t1576 = shen_hd(ctx, t1575);
  KLObject* t1569;
  {
    KLObject* a1569[] = {t1572, t1576, t1470, t1471, t1472, t1473};
    t1569 = shen_apply_direct(ctx, "shen.continue", 6, a1569);
  }
  KLObject* t1581 = shen_intern(ctx, "let");
  KLObject* t1583 = shen_intern(ctx, "if");
  KLObject* t1584 = shen_intern(ctx, "shen.unlocked?");
  KLObject* t1586 = shen_empty_list(ctx);
  KLObject* t1587 = shen_cons(ctx, t1471, t1586);
  KLObject* t1588 = shen_cons(ctx, t1584, t1587);
  KLObject* t1590 = shen_intern(ctx, "shen.+m");
  KLObject* t1592 = shen_hd(ctx, t1468);
  KLObject* t1593 = shen_hd(ctx, t1592);
  KLObject* t1589;
  {
    KLObject* a1589[] = {t1590, t1593, t1469, t1470, t1569};
    t1589 = shen_apply_direct(ctx, "shen.compile-head", 5, a1589);
  }
  KLObject* t1597 = shen_false(ctx);
  KLObject* t1598 = shen_empty_list(ctx);
  KLObject* t1599 = shen_cons(ctx, t1597, t1598);
  KLObject* t1600 = shen_cons(ctx, t1589, t1599);
  KLObject* t1601 = shen_cons(ctx, t1588, t1600);
  KLObject* t1602 = shen_cons(ctx, t1583, t1601);
  KLObject* t1603 = shen_intern(ctx, "if");
  KLObject* t1604 = shen_intern(ctx, "=");
  KLObject* t1606 = shen_false(ctx);
  KLObject* t1607 = shen_empty_list(ctx);
  KLObject* t1608 = shen_cons(ctx, t1606, t1607);
  KLObject* t1609 = shen_cons(ctx, t1567, t1608);
  KLObject* t1610 = shen_cons(ctx, t1604, t1609);
  KLObject* t1613 = shen_tl(ctx, t1468);
  KLObject* t1611;
  {
    KLObject* a1611[] = {t1613, t1469, t1470, t1471, t1472, t1473, t1474};
    t1611 = shen_apply_direct(ctx, "shen.prolog-fbody", 7, a1611);
  }
  KLObject* t1621 = shen_empty_list(ctx);
  KLObject* t1622 = shen_cons(ctx, t1567, t1621);
  KLObject* t1623 = shen_cons(ctx, t1611, t1622);
  KLObject* t1624 = shen_cons(ctx, t1610, t1623);
  KLObject* t1625 = shen_cons(ctx, t1603, t1624);
  KLObject* t1626 = shen_empty_list(ctx);
  KLObject* t1627 = shen_cons(ctx, t1625, t1626);
  KLObject* t1628 = shen_cons(ctx, t1602, t1627);
  KLObject* t1629 = shen_cons(ctx, t1567, t1628);
  KLObject* t1630 = shen_cons(ctx, t1581, t1629);
      t1475 = t1630;
    } else {
  KLObject* t1631 = shen_true(ctx);
    if (!shen_is_boolean(ctx, t1631))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t1631)) {
  KLObject* t1633 = shen_string(ctx, "implementation error in shen.prolog-fbody");
  KLObject* t1632;
  {
    KLObject* a1632[] = {t1633};
    t1632 = shen_tail_apply_direct(ctx, "simple-error", 1, a1632);
  }
      t1475 = t1632;
    } else {
      shen_simple_error(ctx, "No true case found for cond");
      t1475 = shen_empty_list(ctx);
    }
    }
    }
    }
  }
    return t1475;
  }
}

static KLObject* native_kl_shen_2eunlock_38 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t1634 = objects[0];
    KLObject* t1635 = objects[1];
  tail_start_kl_shen_2eunlock_38: ;
  KLObject* t1638;
  {
    KLObject* a1638[] = {t1634};
    t1638 = shen_apply_direct(ctx, "shen.locked?", 1, a1638);
  }
  KLObject* t1637;
  if (!shen_is_boolean(ctx, t1638))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t1638)) {
    t1637 = t1638;
  } else {
  KLObject* t1640;
  {
    KLObject* a1640[] = {t1635, t1634};
    t1640 = shen_apply_direct(ctx, "shen.fits?", 2, a1640);
  }
    if (!shen_is_boolean(ctx, t1640))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t1637 = t1640;
  }
  KLObject* t1636;
  if (!shen_is_boolean(ctx, t1637))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1637)) {
  KLObject* t1643;
  {
    KLObject* a1643[] = {t1634};
    t1643 = shen_tail_apply_direct(ctx, "shen.openlock", 1, a1643);
  }
    t1636 = t1643;
  } else {
  KLObject* t1645 = shen_false(ctx);
    t1636 = t1645;
  }
    return t1636;
  }
}

static KLObject* native_kl_shen_2elocked_3f_39 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t1646 = objects[0];
  tail_start_kl_shen_2elocked_3f_39: ;
  KLObject* t1648;
  {
    KLObject* a1648[] = {t1646};
    t1648 = shen_apply_direct(ctx, "shen.unlocked?", 1, a1648);
  }
  KLObject* t1647;
  {
    KLObject* a1647[] = {t1648};
    t1647 = shen_tail_apply_direct(ctx, "not", 1, a1647);
  }
    return t1647;
  }
}

static KLObject* native_kl_shen_2eunlocked_3f_40 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t1650 = objects[0];
  tail_start_kl_shen_2eunlocked_3f_40: ;
  KLObject* t1653 = shen_number_l(ctx, 1);
  KLObject* t1651;
  {
    KLObject* a1651[] = {t1650, t1653};
    t1651 = shen_tail_apply_direct(ctx, "<-address", 2, a1651);
  }
    return t1651;
  }
}

static KLObject* native_kl_shen_2eopenlock_41 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t1654 = objects[0];
  tail_start_kl_shen_2eopenlock_41: ;
  KLObject* t1657 = shen_number_l(ctx, 1);
  KLObject* t1658 = shen_true(ctx);
  KLObject* t1655;
  {
    KLObject* a1655[] = {t1654, t1657, t1658};
    t1655 = shen_apply_direct(ctx, "address->", 3, a1655);
  }
  KLObject* t1659 = shen_false(ctx);
    return t1659;
  }
}

static KLObject* native_kl_shen_2efits_3f_42 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t1660 = objects[0];
    KLObject* t1661 = objects[1];
  tail_start_kl_shen_2efits_3f_42: ;
  KLObject* t1665 = shen_number_l(ctx, 2);
  KLObject* t1663;
  {
    KLObject* a1663[] = {t1661, t1665};
    t1663 = shen_apply_direct(ctx, "<-address", 2, a1663);
  }
  KLObject* t1666 = shen_eq(ctx, t1660, t1663);
    return t1666;
  }
}

static KLObject* native_kl_shen_2ecut_43 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t1667 = objects[0];
    KLObject* t1668 = objects[1];
    KLObject* t1669 = objects[2];
    KLObject* t1670 = objects[3];
  tail_start_kl_shen_2ecut_43: ;
  KLObject* t1671;
  {
    KLObject* a1671[] = {t1670};
    t1671 = shen_apply_direct(ctx, "thaw", 1, a1671);
  }
  KLObject* t1676 = shen_false(ctx);
  KLObject* t1677 = shen_eq(ctx, t1671, t1676);
  KLObject* t1674;
  if (!shen_is_boolean(ctx, t1677))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t1677)) {
    t1674 = t1677;
  } else {
  KLObject* t1678;
  {
    KLObject* a1678[] = {t1668};
    t1678 = shen_apply_direct(ctx, "shen.unlocked?", 1, a1678);
  }
    if (!shen_is_boolean(ctx, t1678))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t1674 = t1678;
  }
  KLObject* t1673;
  if (!shen_is_boolean(ctx, t1674))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1674)) {
  KLObject* t1680;
  {
    KLObject* a1680[] = {t1669, t1668};
    t1680 = shen_tail_apply_direct(ctx, "shen.lock", 2, a1680);
  }
    t1673 = t1680;
  } else {
    t1673 = t1671;
  }
    return t1673;
  }
}

static KLObject* native_kl_shen_2elock_44 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t1684 = objects[0];
    KLObject* t1685 = objects[1];
  tail_start_kl_shen_2elock_44: ;
  KLObject* t1688 = shen_number_l(ctx, 1);
  KLObject* t1689 = shen_false(ctx);
  KLObject* t1686;
  {
    KLObject* a1686[] = {t1685, t1688, t1689};
    t1686 = shen_apply_direct(ctx, "address->", 3, a1686);
  }
  KLObject* t1692 = shen_number_l(ctx, 2);
  KLObject* t1690;
  {
    KLObject* a1690[] = {t1685, t1692, t1684};
    t1690 = shen_apply_direct(ctx, "address->", 3, a1690);
  }
  KLObject* t1694 = shen_false(ctx);
    return t1694;
  }
}

static KLObject* native_kl_shen_2econtinue_45 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t1695 = objects[0];
    KLObject* t1696 = objects[1];
    KLObject* t1697 = objects[2];
    KLObject* t1698 = objects[3];
    KLObject* t1699 = objects[4];
    KLObject* t1700 = objects[5];
  tail_start_kl_shen_2econtinue_45: ;
  KLObject* t1701;
  {
    KLObject* a1701[] = {t1695};
    t1701 = shen_apply_direct(ctx, "shen.extract-vars", 1, a1701);
  }
  KLObject* t1703;
  {
    KLObject* a1703[] = {t1696};
    t1703 = shen_apply_direct(ctx, "shen.extract-free-vars", 1, a1703);
  }
  KLObject* t1705;
  {
    KLObject* a1705[] = {t1703, t1701};
    t1705 = shen_apply_direct(ctx, "difference", 2, a1705);
  }
  KLObject* t1708 = shen_intern(ctx, "do");
  KLObject* t1709 = shen_intern(ctx, "shen.incinfs");
  KLObject* t1710 = shen_empty_list(ctx);
  KLObject* t1711 = shen_cons(ctx, t1709, t1710);
  KLObject* t1712;
  {
    KLObject* a1712[] = {t1696, t1697, t1698, t1699, t1700};
    t1712 = shen_apply_direct(ctx, "shen.compile-body", 5, a1712);
  }
  KLObject* t1718 = shen_empty_list(ctx);
  KLObject* t1719 = shen_cons(ctx, t1712, t1718);
  KLObject* t1720 = shen_cons(ctx, t1711, t1719);
  KLObject* t1721 = shen_cons(ctx, t1708, t1720);
  KLObject* t1722;
  {
    KLObject* a1722[] = {t1705, t1721, t1697};
    t1722 = shen_tail_apply_direct(ctx, "shen.stpart", 3, a1722);
  }
    return t1722;
  }
}

static KLObject* native_kl_shen_2eextract_2dfree_2dvars_46 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t1726 = objects[0];
  tail_start_kl_shen_2eextract_2dfree_2dvars_46: ;
  KLObject* t1727;
  {
  KLObject* t1730 = shen_cons_p(ctx, t1726);
  KLObject* t1728;
  if (!shen_is_boolean(ctx, t1730))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t1730)) {
    t1728 = t1730;
  } else {
  KLObject* t1732 = shen_intern(ctx, "lambda");
  KLObject* t1734 = shen_hd(ctx, t1726);
  KLObject* t1735 = shen_eq(ctx, t1732, t1734);
  KLObject* t1731;
  if (!shen_is_boolean(ctx, t1735))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t1735)) {
    t1731 = t1735;
  } else {
  KLObject* t1738 = shen_tl(ctx, t1726);
  KLObject* t1739 = shen_cons_p(ctx, t1738);
  KLObject* t1736;
  if (!shen_is_boolean(ctx, t1739))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t1739)) {
    t1736 = t1739;
  } else {
  KLObject* t1742 = shen_tl(ctx, t1726);
  KLObject* t1743 = shen_tl(ctx, t1742);
  KLObject* t1744 = shen_cons_p(ctx, t1743);
  KLObject* t1740;
  if (!shen_is_boolean(ctx, t1744))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t1744)) {
    t1740 = t1744;
  } else {
  KLObject* t1745 = shen_empty_list(ctx);
  KLObject* t1747 = shen_tl(ctx, t1726);
  KLObject* t1748 = shen_tl(ctx, t1747);
  KLObject* t1749 = shen_tl(ctx, t1748);
  KLObject* t1750 = shen_eq(ctx, t1745, t1749);
    if (!shen_is_boolean(ctx, t1750))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t1740 = t1750;
  }
    if (!shen_is_boolean(ctx, t1740))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t1736 = t1740;
  }
    if (!shen_is_boolean(ctx, t1736))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t1731 = t1736;
  }
    if (!shen_is_boolean(ctx, t1731))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t1728 = t1731;
  }
    if (!shen_is_boolean(ctx, t1728))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t1728)) {
  KLObject* t1753 = shen_tl(ctx, t1726);
  KLObject* t1754 = shen_hd(ctx, t1753);
  KLObject* t1757 = shen_tl(ctx, t1726);
  KLObject* t1758 = shen_tl(ctx, t1757);
  KLObject* t1759 = shen_hd(ctx, t1758);
  KLObject* t1755;
  {
    KLObject* a1755[] = {t1759};
    t1755 = shen_apply_direct(ctx, "shen.extract-free-vars", 1, a1755);
  }
  KLObject* t1751;
  {
    KLObject* a1751[] = {t1754, t1755};
    t1751 = shen_tail_apply_direct(ctx, "remove", 2, a1751);
  }
      t1727 = t1751;
    } else {
  KLObject* t1761 = shen_cons_p(ctx, t1726);
    if (!shen_is_boolean(ctx, t1761))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t1761)) {
  KLObject* t1765 = shen_hd(ctx, t1726);
  KLObject* t1763;
  {
    KLObject* a1763[] = {t1765};
    t1763 = shen_apply_direct(ctx, "shen.extract-free-vars", 1, a1763);
  }
  KLObject* t1768 = shen_tl(ctx, t1726);
  KLObject* t1766;
  {
    KLObject* a1766[] = {t1768};
    t1766 = shen_apply_direct(ctx, "shen.extract-free-vars", 1, a1766);
  }
  KLObject* t1762;
  {
    KLObject* a1762[] = {t1763, t1766};
    t1762 = shen_tail_apply_direct(ctx, "union", 2, a1762);
  }
      t1727 = t1762;
    } else {
  KLObject* t1769;
  {
    KLObject* a1769[] = {t1726};
    t1769 = shen_apply_direct(ctx, "variable?", 1, a1769);
  }
    if (!shen_is_boolean(ctx, t1769))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t1769)) {
  KLObject* t1772 = shen_empty_list(ctx);
  KLObject* t1773 = shen_cons(ctx, t1726, t1772);
      t1727 = t1773;
    } else {
  KLObject* t1774 = shen_true(ctx);
    if (!shen_is_boolean(ctx, t1774))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t1774)) {
  KLObject* t1775 = shen_empty_list(ctx);
      t1727 = t1775;
    } else {
      shen_simple_error(ctx, "No true case found for cond");
      t1727 = shen_empty_list(ctx);
    }
    }
    }
    }
  }
    return t1727;
  }
}

static KLObject* native_kl_shen_2ecompile_2dbody_47 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t1776 = objects[0];
    KLObject* t1777 = objects[1];
    KLObject* t1778 = objects[2];
    KLObject* t1779 = objects[3];
    KLObject* t1780 = objects[4];
  tail_start_kl_shen_2ecompile_2dbody_47: ;
  KLObject* t1781;
  {
  KLObject* t1782 = shen_empty_list(ctx);
  KLObject* t1784 = shen_eq(ctx, t1782, t1776);
    if (!shen_is_boolean(ctx, t1784))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t1784)) {
  KLObject* t1785 = shen_intern(ctx, "thaw");
  KLObject* t1787 = shen_empty_list(ctx);
  KLObject* t1788 = shen_cons(ctx, t1780, t1787);
  KLObject* t1789 = shen_cons(ctx, t1785, t1788);
      t1781 = t1789;
    } else {
  KLObject* t1792 = shen_cons_p(ctx, t1776);
  KLObject* t1790;
  if (!shen_is_boolean(ctx, t1792))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t1792)) {
    t1790 = t1792;
  } else {
  KLObject* t1793 = shen_intern(ctx, "!");
  KLObject* t1795 = shen_hd(ctx, t1776);
  KLObject* t1796 = shen_eq(ctx, t1793, t1795);
    if (!shen_is_boolean(ctx, t1796))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t1790 = t1796;
  }
    if (!shen_is_boolean(ctx, t1790))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t1790)) {
  KLObject* t1797 = shen_intern(ctx, "shen.cut");
  KLObject* t1798 = shen_empty_list(ctx);
  KLObject* t1799 = shen_cons(ctx, t1797, t1798);
  KLObject* t1801 = shen_tl(ctx, t1776);
  KLObject* t1802 = shen_cons(ctx, t1799, t1801);
  {
    KLObject* n1807_0 = t1802;
    KLObject* n1807_1 = t1777;
    KLObject* n1807_2 = t1778;
    KLObject* n1807_3 = t1779;
    KLObject* n1807_4 = t1780;
    t1776 = n1807_0;
    t1777 = n1807_1;
    t1778 = n1807_2;
    t1779 = n1807_3;
    t1780 = n1807_4;
    goto tail_start_kl_shen_2ecompile_2dbody_47;
  }
  KLObject* t1807 = NULL;
      t1781 = t1807;
    } else {
  KLObject* t1810 = shen_cons_p(ctx, t1776);
  KLObject* t1808;
  if (!shen_is_boolean(ctx, t1810))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t1810)) {
    t1808 = t1810;
  } else {
  KLObject* t1811 = shen_empty_list(ctx);
  KLObject* t1813 = shen_tl(ctx, t1776);
  KLObject* t1814 = shen_eq(ctx, t1811, t1813);
    if (!shen_is_boolean(ctx, t1814))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t1808 = t1814;
  }
    if (!shen_is_boolean(ctx, t1808))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t1808)) {
  KLObject* t1818 = shen_hd(ctx, t1776);
  KLObject* t1816;
  {
    KLObject* a1816[] = {t1818, t1777};
    t1816 = shen_apply_direct(ctx, "shen.deref-calls", 2, a1816);
  }
  KLObject* t1824 = shen_empty_list(ctx);
  KLObject* t1825 = shen_cons(ctx, t1780, t1824);
  KLObject* t1826 = shen_cons(ctx, t1779, t1825);
  KLObject* t1827 = shen_cons(ctx, t1778, t1826);
  KLObject* t1828 = shen_cons(ctx, t1777, t1827);
  KLObject* t1815;
  {
    KLObject* a1815[] = {t1816, t1828};
    t1815 = shen_tail_apply_direct(ctx, "append", 2, a1815);
  }
      t1781 = t1815;
    } else {
  KLObject* t1830 = shen_cons_p(ctx, t1776);
    if (!shen_is_boolean(ctx, t1830))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t1830)) {
  KLObject* t1833 = shen_hd(ctx, t1776);
  KLObject* t1831;
  {
    KLObject* a1831[] = {t1833, t1777};
    t1831 = shen_apply_direct(ctx, "shen.deref-calls", 2, a1831);
  }
  KLObject* t1842 = shen_tl(ctx, t1776);
  KLObject* t1840;
  {
    KLObject* a1840[] = {t1842, t1777, t1778, t1779, t1780};
    t1840 = shen_apply_direct(ctx, "shen.freeze-literals", 5, a1840);
  }
  KLObject* t1847 = shen_empty_list(ctx);
  KLObject* t1848 = shen_cons(ctx, t1840, t1847);
  KLObject* t1849 = shen_cons(ctx, t1779, t1848);
  KLObject* t1850 = shen_cons(ctx, t1778, t1849);
  KLObject* t1851 = shen_cons(ctx, t1777, t1850);
  KLObject* t1835;
  {
    KLObject* a1835[] = {t1831, t1851};
    t1835 = shen_tail_apply_direct(ctx, "append", 2, a1835);
  }
      t1781 = t1835;
    } else {
  KLObject* t1852 = shen_true(ctx);
    if (!shen_is_boolean(ctx, t1852))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t1852)) {
  KLObject* t1854 = shen_string(ctx, "implementation error in shen.compile-fbody");
  KLObject* t1853;
  {
    KLObject* a1853[] = {t1854};
    t1853 = shen_tail_apply_direct(ctx, "simple-error", 1, a1853);
  }
      t1781 = t1853;
    } else {
      shen_simple_error(ctx, "No true case found for cond");
      t1781 = shen_empty_list(ctx);
    }
    }
    }
    }
    }
  }
    return t1781;
  }
}

static KLObject* native_kl_shen_2efreeze_2dliterals_48 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t1855 = objects[0];
    KLObject* t1856 = objects[1];
    KLObject* t1857 = objects[2];
    KLObject* t1858 = objects[3];
    KLObject* t1859 = objects[4];
  tail_start_kl_shen_2efreeze_2dliterals_48: ;
  KLObject* t1860;
  {
  KLObject* t1861 = shen_empty_list(ctx);
  KLObject* t1863 = shen_eq(ctx, t1861, t1855);
    if (!shen_is_boolean(ctx, t1863))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t1863)) {
      t1860 = t1859;
    } else {
  KLObject* t1867 = shen_cons_p(ctx, t1855);
  KLObject* t1865;
  if (!shen_is_boolean(ctx, t1867))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t1867)) {
    t1865 = t1867;
  } else {
  KLObject* t1868 = shen_intern(ctx, "!");
  KLObject* t1870 = shen_hd(ctx, t1855);
  KLObject* t1871 = shen_eq(ctx, t1868, t1870);
    if (!shen_is_boolean(ctx, t1871))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t1865 = t1871;
  }
    if (!shen_is_boolean(ctx, t1865))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t1865)) {
  KLObject* t1872 = shen_intern(ctx, "shen.cut");
  KLObject* t1873 = shen_empty_list(ctx);
  KLObject* t1874 = shen_cons(ctx, t1872, t1873);
  KLObject* t1876 = shen_tl(ctx, t1855);
  KLObject* t1877 = shen_cons(ctx, t1874, t1876);
  {
    KLObject* n1882_0 = t1877;
    KLObject* n1882_1 = t1856;
    KLObject* n1882_2 = t1857;
    KLObject* n1882_3 = t1858;
    KLObject* n1882_4 = t1859;
    t1855 = n1882_0;
    t1856 = n1882_1;
    t1857 = n1882_2;
    t1858 = n1882_3;
    t1859 = n1882_4;
    goto tail_start_kl_shen_2efreeze_2dliterals_48;
  }
  KLObject* t1882 = NULL;
      t1860 = t1882;
    } else {
  KLObject* t1884 = shen_cons_p(ctx, t1855);
    if (!shen_is_boolean(ctx, t1884))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t1884)) {
  KLObject* t1887 = shen_hd(ctx, t1855);
  KLObject* t1885;
  {
    KLObject* a1885[] = {t1887, t1856};
    t1885 = shen_apply_direct(ctx, "shen.deref-calls", 2, a1885);
  }
  KLObject* t1889 = shen_intern(ctx, "freeze");
  KLObject* t1897 = shen_tl(ctx, t1855);
  KLObject* t1895;
  {
    KLObject* a1895[] = {t1897, t1856, t1857, t1858, t1859};
    t1895 = shen_apply_direct(ctx, "shen.freeze-literals", 5, a1895);
  }
  KLObject* t1902 = shen_empty_list(ctx);
  KLObject* t1903 = shen_cons(ctx, t1895, t1902);
  KLObject* t1904 = shen_cons(ctx, t1858, t1903);
  KLObject* t1905 = shen_cons(ctx, t1857, t1904);
  KLObject* t1906 = shen_cons(ctx, t1856, t1905);
  KLObject* t1890;
  {
    KLObject* a1890[] = {t1885, t1906};
    t1890 = shen_apply_direct(ctx, "append", 2, a1890);
  }
  KLObject* t1907 = shen_empty_list(ctx);
  KLObject* t1908 = shen_cons(ctx, t1890, t1907);
  KLObject* t1909 = shen_cons(ctx, t1889, t1908);
      t1860 = t1909;
    } else {
  KLObject* t1910 = shen_true(ctx);
    if (!shen_is_boolean(ctx, t1910))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t1910)) {
  KLObject* t1912 = shen_string(ctx, "implementation error in shen.freeze-literals");
  KLObject* t1911;
  {
    KLObject* a1911[] = {t1912};
    t1911 = shen_tail_apply_direct(ctx, "simple-error", 1, a1911);
  }
      t1860 = t1911;
    } else {
      shen_simple_error(ctx, "No true case found for cond");
      t1860 = shen_empty_list(ctx);
    }
    }
    }
    }
  }
    return t1860;
  }
}

static KLObject* native_kl_shen_2ederef_2dcalls_49 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t1913 = objects[0];
    KLObject* t1914 = objects[1];
  tail_start_kl_shen_2ederef_2dcalls_49: ;
  KLObject* t1915;
  {
  KLObject* t1918 = shen_cons_p(ctx, t1913);
  KLObject* t1916;
  if (!shen_is_boolean(ctx, t1918))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t1918)) {
    t1916 = t1918;
  } else {
  KLObject* t1919 = shen_intern(ctx, "fork");
  KLObject* t1921 = shen_hd(ctx, t1913);
  KLObject* t1922 = shen_eq(ctx, t1919, t1921);
    if (!shen_is_boolean(ctx, t1922))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t1916 = t1922;
  }
    if (!shen_is_boolean(ctx, t1916))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t1916)) {
  KLObject* t1923 = shen_intern(ctx, "fork");
  KLObject* t1926 = shen_tl(ctx, t1913);
  KLObject* t1924;
  {
    KLObject* a1924[] = {t1926, t1914};
    t1924 = shen_apply_direct(ctx, "shen.deref-forked-literals", 2, a1924);
  }
  KLObject* t1928 = shen_empty_list(ctx);
  KLObject* t1929 = shen_cons(ctx, t1924, t1928);
  KLObject* t1930 = shen_cons(ctx, t1923, t1929);
      t1915 = t1930;
    } else {
  KLObject* t1932 = shen_cons_p(ctx, t1913);
    if (!shen_is_boolean(ctx, t1932))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t1932)) {
  KLObject* t1934 = shen_hd(ctx, t1913);
  KLObject* t1936;
  {
    Vector* caps_2 = shen_vector(ctx, 1);
    shen_vector_set(ctx, caps_2, 0, t1914);
    t1936 = shen_native_closure(ctx, 1, &lambda_2, caps_2);
  }
  KLObject* t1943 = shen_tl(ctx, t1913);
  KLObject* t1935;
  {
    KLObject* a1935[] = {t1936, t1943};
    t1935 = shen_apply_direct(ctx, "map", 2, a1935);
  }
  KLObject* t1944 = shen_cons(ctx, t1934, t1935);
      t1915 = t1944;
    } else {
  KLObject* t1945 = shen_true(ctx);
    if (!shen_is_boolean(ctx, t1945))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t1945)) {
  KLObject* t1947 = shen_string(ctx, "implementation error in shen.deref-calls");
  KLObject* t1946;
  {
    KLObject* a1946[] = {t1947};
    t1946 = shen_tail_apply_direct(ctx, "simple-error", 1, a1946);
  }
      t1915 = t1946;
    } else {
      shen_simple_error(ctx, "No true case found for cond");
      t1915 = shen_empty_list(ctx);
    }
    }
    }
  }
    return t1915;
  }
}

static KLObject* native_kl_shen_2ederef_2dforked_2dliterals_50 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t1948 = objects[0];
    KLObject* t1949 = objects[1];
  tail_start_kl_shen_2ederef_2dforked_2dliterals_50: ;
  KLObject* t1950;
  {
  KLObject* t1951 = shen_empty_list(ctx);
  KLObject* t1953 = shen_eq(ctx, t1951, t1948);
    if (!shen_is_boolean(ctx, t1953))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t1953)) {
  KLObject* t1954 = shen_empty_list(ctx);
      t1950 = t1954;
    } else {
  KLObject* t1956 = shen_cons_p(ctx, t1948);
    if (!shen_is_boolean(ctx, t1956))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t1956)) {
  KLObject* t1957 = shen_intern(ctx, "cons");
  KLObject* t1960 = shen_hd(ctx, t1948);
  KLObject* t1958;
  {
    KLObject* a1958[] = {t1960, t1949};
    t1958 = shen_apply_direct(ctx, "shen.deref-calls", 2, a1958);
  }
  KLObject* t1964 = shen_tl(ctx, t1948);
  KLObject* t1962;
  {
    KLObject* a1962[] = {t1964, t1949};
    t1962 = shen_apply_direct(ctx, "shen.deref-forked-literals", 2, a1962);
  }
  KLObject* t1966 = shen_empty_list(ctx);
  KLObject* t1967 = shen_cons(ctx, t1962, t1966);
  KLObject* t1968 = shen_cons(ctx, t1958, t1967);
  KLObject* t1969 = shen_cons(ctx, t1957, t1968);
      t1950 = t1969;
    } else {
  KLObject* t1970 = shen_true(ctx);
    if (!shen_is_boolean(ctx, t1970))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t1970)) {
  KLObject* t1972 = shen_string(ctx, "fork requires a list of literals\n");
  KLObject* t1971;
  {
    KLObject* a1971[] = {t1972};
    t1971 = shen_tail_apply_direct(ctx, "simple-error", 1, a1971);
  }
      t1950 = t1971;
    } else {
      shen_simple_error(ctx, "No true case found for cond");
      t1950 = shen_empty_list(ctx);
    }
    }
    }
  }
    return t1950;
  }
}

static KLObject* native_kl_shen_2efunction_2dcalls_51 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t1973 = objects[0];
    KLObject* t1974 = objects[1];
  tail_start_kl_shen_2efunction_2dcalls_51: ;
  KLObject* t1975;
  {
  KLObject* t1978 = shen_cons_p(ctx, t1973);
  KLObject* t1976;
  if (!shen_is_boolean(ctx, t1978))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t1978)) {
    t1976 = t1978;
  } else {
  KLObject* t1980 = shen_intern(ctx, "cons");
  KLObject* t1982 = shen_hd(ctx, t1973);
  KLObject* t1983 = shen_eq(ctx, t1980, t1982);
  KLObject* t1979;
  if (!shen_is_boolean(ctx, t1983))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t1983)) {
    t1979 = t1983;
  } else {
  KLObject* t1986 = shen_tl(ctx, t1973);
  KLObject* t1987 = shen_cons_p(ctx, t1986);
  KLObject* t1984;
  if (!shen_is_boolean(ctx, t1987))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t1987)) {
    t1984 = t1987;
  } else {
  KLObject* t1990 = shen_tl(ctx, t1973);
  KLObject* t1991 = shen_tl(ctx, t1990);
  KLObject* t1992 = shen_cons_p(ctx, t1991);
  KLObject* t1988;
  if (!shen_is_boolean(ctx, t1992))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t1992)) {
    t1988 = t1992;
  } else {
  KLObject* t1993 = shen_empty_list(ctx);
  KLObject* t1995 = shen_tl(ctx, t1973);
  KLObject* t1996 = shen_tl(ctx, t1995);
  KLObject* t1997 = shen_tl(ctx, t1996);
  KLObject* t1998 = shen_eq(ctx, t1993, t1997);
    if (!shen_is_boolean(ctx, t1998))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t1988 = t1998;
  }
    if (!shen_is_boolean(ctx, t1988))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t1984 = t1988;
  }
    if (!shen_is_boolean(ctx, t1984))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t1979 = t1984;
  }
    if (!shen_is_boolean(ctx, t1979))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t1976 = t1979;
  }
    if (!shen_is_boolean(ctx, t1976))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t1976)) {
  KLObject* t1999 = shen_intern(ctx, "cons");
  KLObject* t2002 = shen_tl(ctx, t1973);
  KLObject* t2003 = shen_hd(ctx, t2002);
  KLObject* t2000;
  {
    KLObject* a2000[] = {t2003, t1974};
    t2000 = shen_apply_direct(ctx, "shen.function-calls", 2, a2000);
  }
  KLObject* t2007 = shen_tl(ctx, t1973);
  KLObject* t2008 = shen_tl(ctx, t2007);
  KLObject* t2009 = shen_hd(ctx, t2008);
  KLObject* t2005;
  {
    KLObject* a2005[] = {t2009, t1974};
    t2005 = shen_apply_direct(ctx, "shen.function-calls", 2, a2005);
  }
  KLObject* t2011 = shen_empty_list(ctx);
  KLObject* t2012 = shen_cons(ctx, t2005, t2011);
  KLObject* t2013 = shen_cons(ctx, t2000, t2012);
  KLObject* t2014 = shen_cons(ctx, t1999, t2013);
      t1975 = t2014;
    } else {
  KLObject* t2016 = shen_cons_p(ctx, t1973);
    if (!shen_is_boolean(ctx, t2016))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t2016)) {
  KLObject* t2020 = shen_empty_list(ctx);
  KLObject* t2017;
  {
    KLObject* a2017[] = {t1973, t1974, t2020};
    t2017 = shen_tail_apply_direct(ctx, "shen.deref-terms", 3, a2017);
  }
      t1975 = t2017;
    } else {
  KLObject* t2021 = shen_true(ctx);
    if (!shen_is_boolean(ctx, t2021))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t2021)) {
      t1975 = t1973;
    } else {
      shen_simple_error(ctx, "No true case found for cond");
      t1975 = shen_empty_list(ctx);
    }
    }
    }
  }
    return t1975;
  }
}

static KLObject* native_kl_shen_2ederef_2dterms_52 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t2023 = objects[0];
    KLObject* t2024 = objects[1];
    KLObject* t2025 = objects[2];
  tail_start_kl_shen_2ederef_2dterms_52: ;
  KLObject* t2026;
  {
  KLObject* t2029 = shen_cons_p(ctx, t2023);
  KLObject* t2027;
  if (!shen_is_boolean(ctx, t2029))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t2029)) {
    t2027 = t2029;
  } else {
  KLObject* t2031 = shen_number_l(ctx, 0);
  KLObject* t2033 = shen_hd(ctx, t2023);
  KLObject* t2034 = shen_eq(ctx, t2031, t2033);
  KLObject* t2030;
  if (!shen_is_boolean(ctx, t2034))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t2034)) {
    t2030 = t2034;
  } else {
  KLObject* t2037 = shen_tl(ctx, t2023);
  KLObject* t2038 = shen_cons_p(ctx, t2037);
  KLObject* t2035;
  if (!shen_is_boolean(ctx, t2038))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t2038)) {
    t2035 = t2038;
  } else {
  KLObject* t2039 = shen_empty_list(ctx);
  KLObject* t2041 = shen_tl(ctx, t2023);
  KLObject* t2042 = shen_tl(ctx, t2041);
  KLObject* t2043 = shen_eq(ctx, t2039, t2042);
    if (!shen_is_boolean(ctx, t2043))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t2035 = t2043;
  }
    if (!shen_is_boolean(ctx, t2035))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t2030 = t2035;
  }
    if (!shen_is_boolean(ctx, t2030))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t2027 = t2030;
  }
    if (!shen_is_boolean(ctx, t2027))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t2027)) {
  KLObject* t2047 = shen_tl(ctx, t2023);
  KLObject* t2048 = shen_hd(ctx, t2047);
  KLObject* t2045;
  {
    KLObject* a2045[] = {t2048};
    t2045 = shen_apply_direct(ctx, "variable?", 1, a2045);
  }
  KLObject* t2044;
  if (!shen_is_boolean(ctx, t2045))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t2045)) {
  KLObject* t2050 = shen_tl(ctx, t2023);
  KLObject* t2051 = shen_hd(ctx, t2050);
    t2044 = t2051;
  } else {
  KLObject* t2054 = shen_string(ctx, "attempt to optimise a non-variable ");
  KLObject* t2057 = shen_tl(ctx, t2023);
  KLObject* t2058 = shen_hd(ctx, t2057);
  KLObject* t2059 = shen_string(ctx, "\n");
  KLObject* t2060 = shen_intern(ctx, "shen.s");
  KLObject* t2055;
  {
    KLObject* a2055[] = {t2058, t2059, t2060};
    t2055 = shen_apply_direct(ctx, "shen.app", 3, a2055);
  }
  KLObject* t2053;
  {
    KLObject* a2053[] = {t2054, t2055};
    t2053 = shen_apply_direct(ctx, "cn", 2, a2053);
  }
  KLObject* t2052;
  {
    KLObject* a2052[] = {t2053};
    t2052 = shen_tail_apply_direct(ctx, "simple-error", 1, a2052);
  }
    t2044 = t2052;
  }
      t2026 = t2044;
    } else {
  KLObject* t2063 = shen_cons_p(ctx, t2023);
  KLObject* t2061;
  if (!shen_is_boolean(ctx, t2063))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t2063)) {
    t2061 = t2063;
  } else {
  KLObject* t2065 = shen_number_l(ctx, 1);
  KLObject* t2067 = shen_hd(ctx, t2023);
  KLObject* t2068 = shen_eq(ctx, t2065, t2067);
  KLObject* t2064;
  if (!shen_is_boolean(ctx, t2068))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t2068)) {
    t2064 = t2068;
  } else {
  KLObject* t2071 = shen_tl(ctx, t2023);
  KLObject* t2072 = shen_cons_p(ctx, t2071);
  KLObject* t2069;
  if (!shen_is_boolean(ctx, t2072))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t2072)) {
    t2069 = t2072;
  } else {
  KLObject* t2073 = shen_empty_list(ctx);
  KLObject* t2075 = shen_tl(ctx, t2023);
  KLObject* t2076 = shen_tl(ctx, t2075);
  KLObject* t2077 = shen_eq(ctx, t2073, t2076);
    if (!shen_is_boolean(ctx, t2077))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t2069 = t2077;
  }
    if (!shen_is_boolean(ctx, t2069))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t2064 = t2069;
  }
    if (!shen_is_boolean(ctx, t2064))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t2061 = t2064;
  }
    if (!shen_is_boolean(ctx, t2061))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t2061)) {
  KLObject* t2081 = shen_tl(ctx, t2023);
  KLObject* t2082 = shen_hd(ctx, t2081);
  KLObject* t2079;
  {
    KLObject* a2079[] = {t2082};
    t2079 = shen_apply_direct(ctx, "variable?", 1, a2079);
  }
  KLObject* t2078;
  if (!shen_is_boolean(ctx, t2079))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t2079)) {
  KLObject* t2083 = shen_intern(ctx, "shen.lazyderef");
  KLObject* t2085 = shen_tl(ctx, t2023);
  KLObject* t2086 = shen_hd(ctx, t2085);
  KLObject* t2088 = shen_empty_list(ctx);
  KLObject* t2089 = shen_cons(ctx, t2024, t2088);
  KLObject* t2090 = shen_cons(ctx, t2086, t2089);
  KLObject* t2091 = shen_cons(ctx, t2083, t2090);
    t2078 = t2091;
  } else {
  KLObject* t2094 = shen_string(ctx, "attempt to optimise a non-variable ");
  KLObject* t2097 = shen_tl(ctx, t2023);
  KLObject* t2098 = shen_hd(ctx, t2097);
  KLObject* t2099 = shen_string(ctx, "\n");
  KLObject* t2100 = shen_intern(ctx, "shen.s");
  KLObject* t2095;
  {
    KLObject* a2095[] = {t2098, t2099, t2100};
    t2095 = shen_apply_direct(ctx, "shen.app", 3, a2095);
  }
  KLObject* t2093;
  {
    KLObject* a2093[] = {t2094, t2095};
    t2093 = shen_apply_direct(ctx, "cn", 2, a2093);
  }
  KLObject* t2092;
  {
    KLObject* a2092[] = {t2093};
    t2092 = shen_tail_apply_direct(ctx, "simple-error", 1, a2092);
  }
    t2078 = t2092;
  }
      t2026 = t2078;
    } else {
  KLObject* t2103;
  {
    KLObject* a2103[] = {t2023, t2025};
    t2103 = shen_apply_direct(ctx, "element?", 2, a2103);
  }
  KLObject* t2102;
  {
    KLObject* a2102[] = {t2103};
    t2102 = shen_apply_direct(ctx, "not", 1, a2102);
  }
  KLObject* t2101;
  if (!shen_is_boolean(ctx, t2102))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t2102)) {
    t2101 = t2102;
  } else {
  KLObject* t2106;
  {
    KLObject* a2106[] = {t2023};
    t2106 = shen_apply_direct(ctx, "variable?", 1, a2106);
  }
    if (!shen_is_boolean(ctx, t2106))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t2101 = t2106;
  }
    if (!shen_is_boolean(ctx, t2101))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t2101)) {
  KLObject* t2108 = shen_intern(ctx, "shen.deref");
  KLObject* t2111 = shen_empty_list(ctx);
  KLObject* t2112 = shen_cons(ctx, t2024, t2111);
  KLObject* t2113 = shen_cons(ctx, t2023, t2112);
  KLObject* t2114 = shen_cons(ctx, t2108, t2113);
      t2026 = t2114;
    } else {
  KLObject* t2117 = shen_cons_p(ctx, t2023);
  KLObject* t2115;
  if (!shen_is_boolean(ctx, t2117))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t2117)) {
    t2115 = t2117;
  } else {
  KLObject* t2119 = shen_intern(ctx, "lambda");
  KLObject* t2121 = shen_hd(ctx, t2023);
  KLObject* t2122 = shen_eq(ctx, t2119, t2121);
  KLObject* t2118;
  if (!shen_is_boolean(ctx, t2122))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t2122)) {
    t2118 = t2122;
  } else {
  KLObject* t2125 = shen_tl(ctx, t2023);
  KLObject* t2126 = shen_cons_p(ctx, t2125);
  KLObject* t2123;
  if (!shen_is_boolean(ctx, t2126))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t2126)) {
    t2123 = t2126;
  } else {
  KLObject* t2129 = shen_tl(ctx, t2023);
  KLObject* t2130 = shen_tl(ctx, t2129);
  KLObject* t2131 = shen_cons_p(ctx, t2130);
  KLObject* t2127;
  if (!shen_is_boolean(ctx, t2131))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t2131)) {
    t2127 = t2131;
  } else {
  KLObject* t2132 = shen_empty_list(ctx);
  KLObject* t2134 = shen_tl(ctx, t2023);
  KLObject* t2135 = shen_tl(ctx, t2134);
  KLObject* t2136 = shen_tl(ctx, t2135);
  KLObject* t2137 = shen_eq(ctx, t2132, t2136);
    if (!shen_is_boolean(ctx, t2137))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t2127 = t2137;
  }
    if (!shen_is_boolean(ctx, t2127))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t2123 = t2127;
  }
    if (!shen_is_boolean(ctx, t2123))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t2118 = t2123;
  }
    if (!shen_is_boolean(ctx, t2118))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t2115 = t2118;
  }
    if (!shen_is_boolean(ctx, t2115))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t2115)) {
  KLObject* t2138 = shen_intern(ctx, "lambda");
  KLObject* t2140 = shen_tl(ctx, t2023);
  KLObject* t2141 = shen_hd(ctx, t2140);
  KLObject* t2144 = shen_tl(ctx, t2023);
  KLObject* t2145 = shen_tl(ctx, t2144);
  KLObject* t2146 = shen_hd(ctx, t2145);
  KLObject* t2149 = shen_tl(ctx, t2023);
  KLObject* t2150 = shen_hd(ctx, t2149);
  KLObject* t2152 = shen_cons(ctx, t2150, t2025);
  KLObject* t2142;
  {
    KLObject* a2142[] = {t2146, t2024, t2152};
    t2142 = shen_apply_direct(ctx, "shen.deref-terms", 3, a2142);
  }
  KLObject* t2153 = shen_empty_list(ctx);
  KLObject* t2154 = shen_cons(ctx, t2142, t2153);
  KLObject* t2155 = shen_cons(ctx, t2141, t2154);
  KLObject* t2156 = shen_cons(ctx, t2138, t2155);
      t2026 = t2156;
    } else {
  KLObject* t2158 = shen_cons_p(ctx, t2023);
    if (!shen_is_boolean(ctx, t2158))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t2158)) {
  KLObject* t2160;
  {
    Vector* caps_3 = shen_vector(ctx, 2);
    shen_vector_set(ctx, caps_3, 0, t2024);
    shen_vector_set(ctx, caps_3, 1, t2025);
    t2160 = shen_native_closure(ctx, 1, &lambda_3, caps_3);
  }
  KLObject* t2159;
  {
    KLObject* a2159[] = {t2160, t2023};
    t2159 = shen_tail_apply_direct(ctx, "map", 2, a2159);
  }
      t2026 = t2159;
    } else {
  KLObject* t2169 = shen_true(ctx);
    if (!shen_is_boolean(ctx, t2169))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t2169)) {
      t2026 = t2023;
    } else {
      shen_simple_error(ctx, "No true case found for cond");
      t2026 = shen_empty_list(ctx);
    }
    }
    }
    }
    }
    }
  }
    return t2026;
  }
}

static KLObject* native_kl_shen_2ecompile_2dhead_53 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t2171 = objects[0];
    KLObject* t2172 = objects[1];
    KLObject* t2173 = objects[2];
    KLObject* t2174 = objects[3];
    KLObject* t2175 = objects[4];
  tail_start_kl_shen_2ecompile_2dhead_53: ;
  KLObject* t2176;
  {
  KLObject* t2178 = shen_empty_list(ctx);
  KLObject* t2180 = shen_eq(ctx, t2178, t2172);
  KLObject* t2177;
  if (!shen_is_boolean(ctx, t2180))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t2180)) {
    t2177 = t2180;
  } else {
  KLObject* t2181 = shen_empty_list(ctx);
  KLObject* t2183 = shen_eq(ctx, t2181, t2173);
    if (!shen_is_boolean(ctx, t2183))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t2177 = t2183;
  }
    if (!shen_is_boolean(ctx, t2177))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t2177)) {
      t2176 = t2175;
    } else {
  KLObject* t2187 = shen_cons_p(ctx, t2172);
  KLObject* t2185;
  if (!shen_is_boolean(ctx, t2187))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t2187)) {
    t2185 = t2187;
  } else {
  KLObject* t2190 = shen_hd(ctx, t2172);
  KLObject* t2191 = shen_cons_p(ctx, t2190);
  KLObject* t2188;
  if (!shen_is_boolean(ctx, t2191))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t2191)) {
    t2188 = t2191;
  } else {
  KLObject* t2193 = shen_intern(ctx, "shen.+m");
  KLObject* t2195 = shen_hd(ctx, t2172);
  KLObject* t2196 = shen_hd(ctx, t2195);
  KLObject* t2197 = shen_eq(ctx, t2193, t2196);
  KLObject* t2192;
  if (!shen_is_boolean(ctx, t2197))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t2197)) {
    t2192 = t2197;
  } else {
  KLObject* t2200 = shen_hd(ctx, t2172);
  KLObject* t2201 = shen_tl(ctx, t2200);
  KLObject* t2202 = shen_cons_p(ctx, t2201);
  KLObject* t2198;
  if (!shen_is_boolean(ctx, t2202))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t2202)) {
    t2198 = t2202;
  } else {
  KLObject* t2203 = shen_empty_list(ctx);
  KLObject* t2205 = shen_hd(ctx, t2172);
  KLObject* t2206 = shen_tl(ctx, t2205);
  KLObject* t2207 = shen_tl(ctx, t2206);
  KLObject* t2208 = shen_eq(ctx, t2203, t2207);
    if (!shen_is_boolean(ctx, t2208))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t2198 = t2208;
  }
    if (!shen_is_boolean(ctx, t2198))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t2192 = t2198;
  }
    if (!shen_is_boolean(ctx, t2192))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t2188 = t2192;
  }
    if (!shen_is_boolean(ctx, t2188))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t2185 = t2188;
  }
    if (!shen_is_boolean(ctx, t2185))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t2185)) {
  KLObject* t2210 = shen_intern(ctx, "shen.+m");
  KLObject* t2212 = shen_hd(ctx, t2172);
  KLObject* t2213 = shen_tl(ctx, t2212);
  KLObject* t2214 = shen_hd(ctx, t2213);
  KLObject* t2217 = shen_tl(ctx, t2172);
  KLObject* t2218 = shen_cons(ctx, t2171, t2217);
  KLObject* t2219 = shen_cons(ctx, t2214, t2218);
  KLObject* t2220 = shen_cons(ctx, t2210, t2219);
  {
    KLObject* n2224_0 = t2171;
    KLObject* n2224_1 = t2220;
    KLObject* n2224_2 = t2173;
    KLObject* n2224_3 = t2174;
    KLObject* n2224_4 = t2175;
    t2171 = n2224_0;
    t2172 = n2224_1;
    t2173 = n2224_2;
    t2174 = n2224_3;
    t2175 = n2224_4;
    goto tail_start_kl_shen_2ecompile_2dhead_53;
  }
  KLObject* t2224 = NULL;
      t2176 = t2224;
    } else {
  KLObject* t2227 = shen_cons_p(ctx, t2172);
  KLObject* t2225;
  if (!shen_is_boolean(ctx, t2227))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t2227)) {
    t2225 = t2227;
  } else {
  KLObject* t2230 = shen_hd(ctx, t2172);
  KLObject* t2231 = shen_cons_p(ctx, t2230);
  KLObject* t2228;
  if (!shen_is_boolean(ctx, t2231))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t2231)) {
    t2228 = t2231;
  } else {
  KLObject* t2233 = shen_intern(ctx, "shen.-m");
  KLObject* t2235 = shen_hd(ctx, t2172);
  KLObject* t2236 = shen_hd(ctx, t2235);
  KLObject* t2237 = shen_eq(ctx, t2233, t2236);
  KLObject* t2232;
  if (!shen_is_boolean(ctx, t2237))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t2237)) {
    t2232 = t2237;
  } else {
  KLObject* t2240 = shen_hd(ctx, t2172);
  KLObject* t2241 = shen_tl(ctx, t2240);
  KLObject* t2242 = shen_cons_p(ctx, t2241);
  KLObject* t2238;
  if (!shen_is_boolean(ctx, t2242))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t2242)) {
    t2238 = t2242;
  } else {
  KLObject* t2243 = shen_empty_list(ctx);
  KLObject* t2245 = shen_hd(ctx, t2172);
  KLObject* t2246 = shen_tl(ctx, t2245);
  KLObject* t2247 = shen_tl(ctx, t2246);
  KLObject* t2248 = shen_eq(ctx, t2243, t2247);
    if (!shen_is_boolean(ctx, t2248))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t2238 = t2248;
  }
    if (!shen_is_boolean(ctx, t2238))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t2232 = t2238;
  }
    if (!shen_is_boolean(ctx, t2232))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t2228 = t2232;
  }
    if (!shen_is_boolean(ctx, t2228))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t2225 = t2228;
  }
    if (!shen_is_boolean(ctx, t2225))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t2225)) {
  KLObject* t2250 = shen_intern(ctx, "shen.-m");
  KLObject* t2252 = shen_hd(ctx, t2172);
  KLObject* t2253 = shen_tl(ctx, t2252);
  KLObject* t2254 = shen_hd(ctx, t2253);
  KLObject* t2257 = shen_tl(ctx, t2172);
  KLObject* t2258 = shen_cons(ctx, t2171, t2257);
  KLObject* t2259 = shen_cons(ctx, t2254, t2258);
  KLObject* t2260 = shen_cons(ctx, t2250, t2259);
  {
    KLObject* n2264_0 = t2171;
    KLObject* n2264_1 = t2260;
    KLObject* n2264_2 = t2173;
    KLObject* n2264_3 = t2174;
    KLObject* n2264_4 = t2175;
    t2171 = n2264_0;
    t2172 = n2264_1;
    t2173 = n2264_2;
    t2174 = n2264_3;
    t2175 = n2264_4;
    goto tail_start_kl_shen_2ecompile_2dhead_53;
  }
  KLObject* t2264 = NULL;
      t2176 = t2264;
    } else {
  KLObject* t2267 = shen_cons_p(ctx, t2172);
  KLObject* t2265;
  if (!shen_is_boolean(ctx, t2267))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t2267)) {
    t2265 = t2267;
  } else {
  KLObject* t2268 = shen_intern(ctx, "shen.-m");
  KLObject* t2270 = shen_hd(ctx, t2172);
  KLObject* t2271 = shen_eq(ctx, t2268, t2270);
    if (!shen_is_boolean(ctx, t2271))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t2265 = t2271;
  }
    if (!shen_is_boolean(ctx, t2265))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t2265)) {
  KLObject* t2272 = shen_intern(ctx, "shen.-m");
  KLObject* t2274 = shen_tl(ctx, t2172);
  {
    KLObject* n2278_0 = t2272;
    KLObject* n2278_1 = t2274;
    KLObject* n2278_2 = t2173;
    KLObject* n2278_3 = t2174;
    KLObject* n2278_4 = t2175;
    t2171 = n2278_0;
    t2172 = n2278_1;
    t2173 = n2278_2;
    t2174 = n2278_3;
    t2175 = n2278_4;
    goto tail_start_kl_shen_2ecompile_2dhead_53;
  }
  KLObject* t2278 = NULL;
      t2176 = t2278;
    } else {
  KLObject* t2281 = shen_cons_p(ctx, t2172);
  KLObject* t2279;
  if (!shen_is_boolean(ctx, t2281))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t2281)) {
    t2279 = t2281;
  } else {
  KLObject* t2282 = shen_intern(ctx, "shen.+m");
  KLObject* t2284 = shen_hd(ctx, t2172);
  KLObject* t2285 = shen_eq(ctx, t2282, t2284);
    if (!shen_is_boolean(ctx, t2285))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t2279 = t2285;
  }
    if (!shen_is_boolean(ctx, t2279))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t2279)) {
  KLObject* t2286 = shen_intern(ctx, "shen.+m");
  KLObject* t2288 = shen_tl(ctx, t2172);
  {
    KLObject* n2292_0 = t2286;
    KLObject* n2292_1 = t2288;
    KLObject* n2292_2 = t2173;
    KLObject* n2292_3 = t2174;
    KLObject* n2292_4 = t2175;
    t2171 = n2292_0;
    t2172 = n2292_1;
    t2173 = n2292_2;
    t2174 = n2292_3;
    t2175 = n2292_4;
    goto tail_start_kl_shen_2ecompile_2dhead_53;
  }
  KLObject* t2292 = NULL;
      t2176 = t2292;
    } else {
  KLObject* t2295 = shen_cons_p(ctx, t2172);
  KLObject* t2293;
  if (!shen_is_boolean(ctx, t2295))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t2295)) {
    t2293 = t2295;
  } else {
  KLObject* t2298 = shen_cons_p(ctx, t2173);
  KLObject* t2296;
  if (!shen_is_boolean(ctx, t2298))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t2298)) {
    t2296 = t2298;
  } else {
  KLObject* t2301 = shen_hd(ctx, t2172);
  KLObject* t2299;
  {
    KLObject* a2299[] = {t2301};
    t2299 = shen_apply_direct(ctx, "shen.wildcard?", 1, a2299);
  }
    if (!shen_is_boolean(ctx, t2299))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t2296 = t2299;
  }
    if (!shen_is_boolean(ctx, t2296))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t2293 = t2296;
  }
    if (!shen_is_boolean(ctx, t2293))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t2293)) {
  KLObject* t2304 = shen_tl(ctx, t2172);
  KLObject* t2306 = shen_tl(ctx, t2173);
  {
    KLObject* n2309_0 = t2171;
    KLObject* n2309_1 = t2304;
    KLObject* n2309_2 = t2306;
    KLObject* n2309_3 = t2174;
    KLObject* n2309_4 = t2175;
    t2171 = n2309_0;
    t2172 = n2309_1;
    t2173 = n2309_2;
    t2174 = n2309_3;
    t2175 = n2309_4;
    goto tail_start_kl_shen_2ecompile_2dhead_53;
  }
  KLObject* t2309 = NULL;
      t2176 = t2309;
    } else {
  KLObject* t2312 = shen_cons_p(ctx, t2172);
  KLObject* t2310;
  if (!shen_is_boolean(ctx, t2312))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t2312)) {
    t2310 = t2312;
  } else {
  KLObject* t2315 = shen_hd(ctx, t2172);
  KLObject* t2313;
  {
    KLObject* a2313[] = {t2315};
    t2313 = shen_apply_direct(ctx, "variable?", 1, a2313);
  }
    if (!shen_is_boolean(ctx, t2313))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t2310 = t2313;
  }
    if (!shen_is_boolean(ctx, t2310))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t2310)) {
  KLObject* t2316;
  {
    KLObject* a2316[] = {t2171, t2172, t2173, t2174, t2175};
    t2316 = shen_tail_apply_direct(ctx, "shen.variable-case", 5, a2316);
  }
      t2176 = t2316;
    } else {
  KLObject* t2323 = shen_intern(ctx, "shen.-m");
  KLObject* t2325 = shen_eq(ctx, t2323, t2171);
  KLObject* t2322;
  if (!shen_is_boolean(ctx, t2325))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t2325)) {
    t2322 = t2325;
  } else {
  KLObject* t2328 = shen_cons_p(ctx, t2172);
  KLObject* t2326;
  if (!shen_is_boolean(ctx, t2328))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t2328)) {
    t2326 = t2328;
  } else {
  KLObject* t2331 = shen_hd(ctx, t2172);
  KLObject* t2329;
  {
    KLObject* a2329[] = {t2331};
    t2329 = shen_apply_direct(ctx, "atom?", 1, a2329);
  }
    if (!shen_is_boolean(ctx, t2329))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t2326 = t2329;
  }
    if (!shen_is_boolean(ctx, t2326))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t2322 = t2326;
  }
    if (!shen_is_boolean(ctx, t2322))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t2322)) {
  KLObject* t2332;
  {
    KLObject* a2332[] = {t2172, t2173, t2174, t2175};
    t2332 = shen_tail_apply_direct(ctx, "shen.atom-case-minus", 4, a2332);
  }
      t2176 = t2332;
    } else {
  KLObject* t2338 = shen_intern(ctx, "shen.-m");
  KLObject* t2340 = shen_eq(ctx, t2338, t2171);
  KLObject* t2337;
  if (!shen_is_boolean(ctx, t2340))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t2340)) {
    t2337 = t2340;
  } else {
  KLObject* t2343 = shen_cons_p(ctx, t2172);
  KLObject* t2341;
  if (!shen_is_boolean(ctx, t2343))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t2343)) {
    t2341 = t2343;
  } else {
  KLObject* t2346 = shen_hd(ctx, t2172);
  KLObject* t2347 = shen_cons_p(ctx, t2346);
  KLObject* t2344;
  if (!shen_is_boolean(ctx, t2347))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t2347)) {
    t2344 = t2347;
  } else {
  KLObject* t2349 = shen_intern(ctx, "cons");
  KLObject* t2351 = shen_hd(ctx, t2172);
  KLObject* t2352 = shen_hd(ctx, t2351);
  KLObject* t2353 = shen_eq(ctx, t2349, t2352);
  KLObject* t2348;
  if (!shen_is_boolean(ctx, t2353))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t2353)) {
    t2348 = t2353;
  } else {
  KLObject* t2356 = shen_hd(ctx, t2172);
  KLObject* t2357 = shen_tl(ctx, t2356);
  KLObject* t2358 = shen_cons_p(ctx, t2357);
  KLObject* t2354;
  if (!shen_is_boolean(ctx, t2358))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t2358)) {
    t2354 = t2358;
  } else {
  KLObject* t2361 = shen_hd(ctx, t2172);
  KLObject* t2362 = shen_tl(ctx, t2361);
  KLObject* t2363 = shen_tl(ctx, t2362);
  KLObject* t2364 = shen_cons_p(ctx, t2363);
  KLObject* t2359;
  if (!shen_is_boolean(ctx, t2364))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t2364)) {
    t2359 = t2364;
  } else {
  KLObject* t2365 = shen_empty_list(ctx);
  KLObject* t2367 = shen_hd(ctx, t2172);
  KLObject* t2368 = shen_tl(ctx, t2367);
  KLObject* t2369 = shen_tl(ctx, t2368);
  KLObject* t2370 = shen_tl(ctx, t2369);
  KLObject* t2371 = shen_eq(ctx, t2365, t2370);
    if (!shen_is_boolean(ctx, t2371))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t2359 = t2371;
  }
    if (!shen_is_boolean(ctx, t2359))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t2354 = t2359;
  }
    if (!shen_is_boolean(ctx, t2354))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t2348 = t2354;
  }
    if (!shen_is_boolean(ctx, t2348))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t2344 = t2348;
  }
    if (!shen_is_boolean(ctx, t2344))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t2341 = t2344;
  }
    if (!shen_is_boolean(ctx, t2341))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t2337 = t2341;
  }
    if (!shen_is_boolean(ctx, t2337))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t2337)) {
  KLObject* t2372;
  {
    KLObject* a2372[] = {t2172, t2173, t2174, t2175};
    t2372 = shen_tail_apply_direct(ctx, "shen.cons-case-minus", 4, a2372);
  }
      t2176 = t2372;
    } else {
  KLObject* t2378 = shen_intern(ctx, "shen.+m");
  KLObject* t2380 = shen_eq(ctx, t2378, t2171);
  KLObject* t2377;
  if (!shen_is_boolean(ctx, t2380))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t2380)) {
    t2377 = t2380;
  } else {
  KLObject* t2383 = shen_cons_p(ctx, t2172);
  KLObject* t2381;
  if (!shen_is_boolean(ctx, t2383))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t2383)) {
    t2381 = t2383;
  } else {
  KLObject* t2386 = shen_hd(ctx, t2172);
  KLObject* t2384;
  {
    KLObject* a2384[] = {t2386};
    t2384 = shen_apply_direct(ctx, "atom?", 1, a2384);
  }
    if (!shen_is_boolean(ctx, t2384))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t2381 = t2384;
  }
    if (!shen_is_boolean(ctx, t2381))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t2377 = t2381;
  }
    if (!shen_is_boolean(ctx, t2377))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t2377)) {
  KLObject* t2387;
  {
    KLObject* a2387[] = {t2172, t2173, t2174, t2175};
    t2387 = shen_tail_apply_direct(ctx, "shen.atom-case-plus", 4, a2387);
  }
      t2176 = t2387;
    } else {
  KLObject* t2393 = shen_intern(ctx, "shen.+m");
  KLObject* t2395 = shen_eq(ctx, t2393, t2171);
  KLObject* t2392;
  if (!shen_is_boolean(ctx, t2395))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t2395)) {
    t2392 = t2395;
  } else {
  KLObject* t2398 = shen_cons_p(ctx, t2172);
  KLObject* t2396;
  if (!shen_is_boolean(ctx, t2398))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t2398)) {
    t2396 = t2398;
  } else {
  KLObject* t2401 = shen_hd(ctx, t2172);
  KLObject* t2402 = shen_cons_p(ctx, t2401);
  KLObject* t2399;
  if (!shen_is_boolean(ctx, t2402))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t2402)) {
    t2399 = t2402;
  } else {
  KLObject* t2404 = shen_intern(ctx, "cons");
  KLObject* t2406 = shen_hd(ctx, t2172);
  KLObject* t2407 = shen_hd(ctx, t2406);
  KLObject* t2408 = shen_eq(ctx, t2404, t2407);
  KLObject* t2403;
  if (!shen_is_boolean(ctx, t2408))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t2408)) {
    t2403 = t2408;
  } else {
  KLObject* t2411 = shen_hd(ctx, t2172);
  KLObject* t2412 = shen_tl(ctx, t2411);
  KLObject* t2413 = shen_cons_p(ctx, t2412);
  KLObject* t2409;
  if (!shen_is_boolean(ctx, t2413))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t2413)) {
    t2409 = t2413;
  } else {
  KLObject* t2416 = shen_hd(ctx, t2172);
  KLObject* t2417 = shen_tl(ctx, t2416);
  KLObject* t2418 = shen_tl(ctx, t2417);
  KLObject* t2419 = shen_cons_p(ctx, t2418);
  KLObject* t2414;
  if (!shen_is_boolean(ctx, t2419))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t2419)) {
    t2414 = t2419;
  } else {
  KLObject* t2420 = shen_empty_list(ctx);
  KLObject* t2422 = shen_hd(ctx, t2172);
  KLObject* t2423 = shen_tl(ctx, t2422);
  KLObject* t2424 = shen_tl(ctx, t2423);
  KLObject* t2425 = shen_tl(ctx, t2424);
  KLObject* t2426 = shen_eq(ctx, t2420, t2425);
    if (!shen_is_boolean(ctx, t2426))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t2414 = t2426;
  }
    if (!shen_is_boolean(ctx, t2414))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t2409 = t2414;
  }
    if (!shen_is_boolean(ctx, t2409))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t2403 = t2409;
  }
    if (!shen_is_boolean(ctx, t2403))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t2399 = t2403;
  }
    if (!shen_is_boolean(ctx, t2399))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t2396 = t2399;
  }
    if (!shen_is_boolean(ctx, t2396))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t2392 = t2396;
  }
    if (!shen_is_boolean(ctx, t2392))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t2392)) {
  KLObject* t2427;
  {
    KLObject* a2427[] = {t2172, t2173, t2174, t2175};
    t2427 = shen_tail_apply_direct(ctx, "shen.cons-case-plus", 4, a2427);
  }
      t2176 = t2427;
    } else {
  KLObject* t2432 = shen_true(ctx);
    if (!shen_is_boolean(ctx, t2432))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t2432)) {
  KLObject* t2434 = shen_string(ctx, "implementation error in shen.compile-head");
  KLObject* t2433;
  {
    KLObject* a2433[] = {t2434};
    t2433 = shen_tail_apply_direct(ctx, "simple-error", 1, a2433);
  }
      t2176 = t2433;
    } else {
      shen_simple_error(ctx, "No true case found for cond");
      t2176 = shen_empty_list(ctx);
    }
    }
    }
    }
    }
    }
    }
    }
    }
    }
    }
    }
  }
    return t2176;
  }
}

static KLObject* native_kl_shen_2evariable_2dcase_54 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t2435 = objects[0];
    KLObject* t2436 = objects[1];
    KLObject* t2437 = objects[2];
    KLObject* t2438 = objects[3];
    KLObject* t2439 = objects[4];
  tail_start_kl_shen_2evariable_2dcase_54: ;
  KLObject* t2440;
  {
  KLObject* t2443 = shen_cons_p(ctx, t2436);
  KLObject* t2441;
  if (!shen_is_boolean(ctx, t2443))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t2443)) {
    t2441 = t2443;
  } else {
  KLObject* t2445 = shen_cons_p(ctx, t2437);
    if (!shen_is_boolean(ctx, t2445))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t2441 = t2445;
  }
    if (!shen_is_boolean(ctx, t2441))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t2441)) {
  KLObject* t2449 = shen_hd(ctx, t2437);
  KLObject* t2447;
  {
    KLObject* a2447[] = {t2449};
    t2447 = shen_apply_direct(ctx, "variable?", 1, a2447);
  }
  KLObject* t2446;
  if (!shen_is_boolean(ctx, t2447))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t2447)) {
  KLObject* t2453 = shen_tl(ctx, t2436);
  KLObject* t2455 = shen_tl(ctx, t2437);
  KLObject* t2459 = shen_hd(ctx, t2437);
  KLObject* t2461 = shen_hd(ctx, t2436);
  KLObject* t2457;
  {
    KLObject* a2457[] = {t2459, t2461, t2439};
    t2457 = shen_apply_direct(ctx, "subst", 3, a2457);
  }
  KLObject* t2450;
  {
    KLObject* a2450[] = {t2435, t2453, t2455, t2438, t2457};
    t2450 = shen_tail_apply_direct(ctx, "shen.compile-head", 5, a2450);
  }
    t2446 = t2450;
  } else {
  KLObject* t2463 = shen_intern(ctx, "let");
  KLObject* t2465 = shen_hd(ctx, t2436);
  KLObject* t2467 = shen_hd(ctx, t2437);
  KLObject* t2471 = shen_tl(ctx, t2436);
  KLObject* t2473 = shen_tl(ctx, t2437);
  KLObject* t2468;
  {
    KLObject* a2468[] = {t2435, t2471, t2473, t2438, t2439};
    t2468 = shen_apply_direct(ctx, "shen.compile-head", 5, a2468);
  }
  KLObject* t2476 = shen_empty_list(ctx);
  KLObject* t2477 = shen_cons(ctx, t2468, t2476);
  KLObject* t2478 = shen_cons(ctx, t2467, t2477);
  KLObject* t2479 = shen_cons(ctx, t2465, t2478);
  KLObject* t2480 = shen_cons(ctx, t2463, t2479);
    t2446 = t2480;
  }
      t2440 = t2446;
    } else {
  KLObject* t2481 = shen_true(ctx);
    if (!shen_is_boolean(ctx, t2481))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t2481)) {
  KLObject* t2483 = shen_string(ctx, "implementation error in shen.variable-case");
  KLObject* t2482;
  {
    KLObject* a2482[] = {t2483};
    t2482 = shen_tail_apply_direct(ctx, "simple-error", 1, a2482);
  }
      t2440 = t2482;
    } else {
      shen_simple_error(ctx, "No true case found for cond");
      t2440 = shen_empty_list(ctx);
    }
    }
  }
    return t2440;
  }
}

static KLObject* native_kl_shen_2eatom_2dcase_2dminus_55 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t2484 = objects[0];
    KLObject* t2485 = objects[1];
    KLObject* t2486 = objects[2];
    KLObject* t2487 = objects[3];
  tail_start_kl_shen_2eatom_2dcase_2dminus_55: ;
  KLObject* t2488;
  {
  KLObject* t2491 = shen_cons_p(ctx, t2484);
  KLObject* t2489;
  if (!shen_is_boolean(ctx, t2491))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t2491)) {
    t2489 = t2491;
  } else {
  KLObject* t2493 = shen_cons_p(ctx, t2485);
    if (!shen_is_boolean(ctx, t2493))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t2489 = t2493;
  }
    if (!shen_is_boolean(ctx, t2489))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t2489)) {
  KLObject* t2495 = shen_intern(ctx, "Tm");
  KLObject* t2494;
  {
    KLObject* a2494[] = {t2495};
    t2494 = shen_apply_direct(ctx, "gensym", 1, a2494);
  }
  KLObject* t2496 = shen_intern(ctx, "let");
  KLObject* t2498 = shen_intern(ctx, "shen.lazyderef");
  KLObject* t2500 = shen_hd(ctx, t2485);
  KLObject* t2502 = shen_empty_list(ctx);
  KLObject* t2503 = shen_cons(ctx, t2486, t2502);
  KLObject* t2504 = shen_cons(ctx, t2500, t2503);
  KLObject* t2505 = shen_cons(ctx, t2498, t2504);
  KLObject* t2506 = shen_intern(ctx, "if");
  KLObject* t2507 = shen_intern(ctx, "=");
  KLObject* t2510 = shen_hd(ctx, t2484);
  KLObject* t2511 = shen_empty_list(ctx);
  KLObject* t2512 = shen_cons(ctx, t2510, t2511);
  KLObject* t2513 = shen_cons(ctx, t2494, t2512);
  KLObject* t2514 = shen_cons(ctx, t2507, t2513);
  KLObject* t2516 = shen_intern(ctx, "shen.-m");
  KLObject* t2518 = shen_tl(ctx, t2484);
  KLObject* t2520 = shen_tl(ctx, t2485);
  KLObject* t2515;
  {
    KLObject* a2515[] = {t2516, t2518, t2520, t2486, t2487};
    t2515 = shen_apply_direct(ctx, "shen.compile-head", 5, a2515);
  }
  KLObject* t2523 = shen_false(ctx);
  KLObject* t2524 = shen_empty_list(ctx);
  KLObject* t2525 = shen_cons(ctx, t2523, t2524);
  KLObject* t2526 = shen_cons(ctx, t2515, t2525);
  KLObject* t2527 = shen_cons(ctx, t2514, t2526);
  KLObject* t2528 = shen_cons(ctx, t2506, t2527);
  KLObject* t2529 = shen_empty_list(ctx);
  KLObject* t2530 = shen_cons(ctx, t2528, t2529);
  KLObject* t2531 = shen_cons(ctx, t2505, t2530);
  KLObject* t2532 = shen_cons(ctx, t2494, t2531);
  KLObject* t2533 = shen_cons(ctx, t2496, t2532);
      t2488 = t2533;
    } else {
  KLObject* t2534 = shen_true(ctx);
    if (!shen_is_boolean(ctx, t2534))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t2534)) {
  KLObject* t2536 = shen_string(ctx, "implementation error in shen.atom-case-minus");
  KLObject* t2535;
  {
    KLObject* a2535[] = {t2536};
    t2535 = shen_tail_apply_direct(ctx, "simple-error", 1, a2535);
  }
      t2488 = t2535;
    } else {
      shen_simple_error(ctx, "No true case found for cond");
      t2488 = shen_empty_list(ctx);
    }
    }
  }
    return t2488;
  }
}

static KLObject* native_kl_shen_2econs_2dcase_2dminus_56 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t2537 = objects[0];
    KLObject* t2538 = objects[1];
    KLObject* t2539 = objects[2];
    KLObject* t2540 = objects[3];
  tail_start_kl_shen_2econs_2dcase_2dminus_56: ;
  KLObject* t2541;
  {
  KLObject* t2544 = shen_cons_p(ctx, t2537);
  KLObject* t2542;
  if (!shen_is_boolean(ctx, t2544))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t2544)) {
    t2542 = t2544;
  } else {
  KLObject* t2547 = shen_hd(ctx, t2537);
  KLObject* t2548 = shen_cons_p(ctx, t2547);
  KLObject* t2545;
  if (!shen_is_boolean(ctx, t2548))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t2548)) {
    t2545 = t2548;
  } else {
  KLObject* t2550 = shen_intern(ctx, "cons");
  KLObject* t2552 = shen_hd(ctx, t2537);
  KLObject* t2553 = shen_hd(ctx, t2552);
  KLObject* t2554 = shen_eq(ctx, t2550, t2553);
  KLObject* t2549;
  if (!shen_is_boolean(ctx, t2554))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t2554)) {
    t2549 = t2554;
  } else {
  KLObject* t2557 = shen_hd(ctx, t2537);
  KLObject* t2558 = shen_tl(ctx, t2557);
  KLObject* t2559 = shen_cons_p(ctx, t2558);
  KLObject* t2555;
  if (!shen_is_boolean(ctx, t2559))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t2559)) {
    t2555 = t2559;
  } else {
  KLObject* t2562 = shen_hd(ctx, t2537);
  KLObject* t2563 = shen_tl(ctx, t2562);
  KLObject* t2564 = shen_tl(ctx, t2563);
  KLObject* t2565 = shen_cons_p(ctx, t2564);
  KLObject* t2560;
  if (!shen_is_boolean(ctx, t2565))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t2565)) {
    t2560 = t2565;
  } else {
  KLObject* t2567 = shen_empty_list(ctx);
  KLObject* t2569 = shen_hd(ctx, t2537);
  KLObject* t2570 = shen_tl(ctx, t2569);
  KLObject* t2571 = shen_tl(ctx, t2570);
  KLObject* t2572 = shen_tl(ctx, t2571);
  KLObject* t2573 = shen_eq(ctx, t2567, t2572);
  KLObject* t2566;
  if (!shen_is_boolean(ctx, t2573))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t2573)) {
    t2566 = t2573;
  } else {
  KLObject* t2575 = shen_cons_p(ctx, t2538);
    if (!shen_is_boolean(ctx, t2575))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t2566 = t2575;
  }
    if (!shen_is_boolean(ctx, t2566))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t2560 = t2566;
  }
    if (!shen_is_boolean(ctx, t2560))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t2555 = t2560;
  }
    if (!shen_is_boolean(ctx, t2555))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t2549 = t2555;
  }
    if (!shen_is_boolean(ctx, t2549))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t2545 = t2549;
  }
    if (!shen_is_boolean(ctx, t2545))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t2542 = t2545;
  }
    if (!shen_is_boolean(ctx, t2542))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t2542)) {
  KLObject* t2577 = shen_intern(ctx, "Tm");
  KLObject* t2576;
  {
    KLObject* a2576[] = {t2577};
    t2576 = shen_apply_direct(ctx, "gensym", 1, a2576);
  }
  KLObject* t2578 = shen_intern(ctx, "let");
  KLObject* t2580 = shen_intern(ctx, "shen.lazyderef");
  KLObject* t2582 = shen_hd(ctx, t2538);
  KLObject* t2584 = shen_empty_list(ctx);
  KLObject* t2585 = shen_cons(ctx, t2539, t2584);
  KLObject* t2586 = shen_cons(ctx, t2582, t2585);
  KLObject* t2587 = shen_cons(ctx, t2580, t2586);
  KLObject* t2588 = shen_intern(ctx, "if");
  KLObject* t2589 = shen_intern(ctx, "cons?");
  KLObject* t2591 = shen_empty_list(ctx);
  KLObject* t2592 = shen_cons(ctx, t2576, t2591);
  KLObject* t2593 = shen_cons(ctx, t2589, t2592);
  KLObject* t2595 = shen_intern(ctx, "shen.-m");
  KLObject* t2597 = shen_hd(ctx, t2537);
  KLObject* t2598 = shen_tl(ctx, t2597);
  KLObject* t2599 = shen_hd(ctx, t2598);
  KLObject* t2601 = shen_hd(ctx, t2537);
  KLObject* t2602 = shen_tl(ctx, t2601);
  KLObject* t2603 = shen_tl(ctx, t2602);
  KLObject* t2604 = shen_hd(ctx, t2603);
  KLObject* t2606 = shen_tl(ctx, t2537);
  KLObject* t2607 = shen_cons(ctx, t2604, t2606);
  KLObject* t2608 = shen_cons(ctx, t2599, t2607);
  KLObject* t2609 = shen_intern(ctx, "hd");
  KLObject* t2611 = shen_empty_list(ctx);
  KLObject* t2612 = shen_cons(ctx, t2576, t2611);
  KLObject* t2613 = shen_cons(ctx, t2609, t2612);
  KLObject* t2614 = shen_intern(ctx, "tl");
  KLObject* t2616 = shen_empty_list(ctx);
  KLObject* t2617 = shen_cons(ctx, t2576, t2616);
  KLObject* t2618 = shen_cons(ctx, t2614, t2617);
  KLObject* t2620 = shen_tl(ctx, t2538);
  KLObject* t2621 = shen_cons(ctx, t2618, t2620);
  KLObject* t2622 = shen_cons(ctx, t2613, t2621);
  KLObject* t2594;
  {
    KLObject* a2594[] = {t2595, t2608, t2622, t2539, t2540};
    t2594 = shen_apply_direct(ctx, "shen.compile-head", 5, a2594);
  }
  KLObject* t2625 = shen_false(ctx);
  KLObject* t2626 = shen_empty_list(ctx);
  KLObject* t2627 = shen_cons(ctx, t2625, t2626);
  KLObject* t2628 = shen_cons(ctx, t2594, t2627);
  KLObject* t2629 = shen_cons(ctx, t2593, t2628);
  KLObject* t2630 = shen_cons(ctx, t2588, t2629);
  KLObject* t2631 = shen_empty_list(ctx);
  KLObject* t2632 = shen_cons(ctx, t2630, t2631);
  KLObject* t2633 = shen_cons(ctx, t2587, t2632);
  KLObject* t2634 = shen_cons(ctx, t2576, t2633);
  KLObject* t2635 = shen_cons(ctx, t2578, t2634);
      t2541 = t2635;
    } else {
  KLObject* t2636 = shen_true(ctx);
    if (!shen_is_boolean(ctx, t2636))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t2636)) {
  KLObject* t2638 = shen_string(ctx, "implementation error in shen.cons-case-minus");
  KLObject* t2637;
  {
    KLObject* a2637[] = {t2638};
    t2637 = shen_tail_apply_direct(ctx, "simple-error", 1, a2637);
  }
      t2541 = t2637;
    } else {
      shen_simple_error(ctx, "No true case found for cond");
      t2541 = shen_empty_list(ctx);
    }
    }
  }
    return t2541;
  }
}

static KLObject* native_kl_shen_2eatom_2dcase_2dplus_57 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t2639 = objects[0];
    KLObject* t2640 = objects[1];
    KLObject* t2641 = objects[2];
    KLObject* t2642 = objects[3];
  tail_start_kl_shen_2eatom_2dcase_2dplus_57: ;
  KLObject* t2643;
  {
  KLObject* t2646 = shen_cons_p(ctx, t2639);
  KLObject* t2644;
  if (!shen_is_boolean(ctx, t2646))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t2646)) {
    t2644 = t2646;
  } else {
  KLObject* t2648 = shen_cons_p(ctx, t2640);
    if (!shen_is_boolean(ctx, t2648))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t2644 = t2648;
  }
    if (!shen_is_boolean(ctx, t2644))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t2644)) {
  KLObject* t2650 = shen_intern(ctx, "Tm");
  KLObject* t2649;
  {
    KLObject* a2649[] = {t2650};
    t2649 = shen_apply_direct(ctx, "gensym", 1, a2649);
  }
  KLObject* t2652 = shen_intern(ctx, "GoTo");
  KLObject* t2651;
  {
    KLObject* a2651[] = {t2652};
    t2651 = shen_apply_direct(ctx, "gensym", 1, a2651);
  }
  KLObject* t2653 = shen_intern(ctx, "let");
  KLObject* t2655 = shen_intern(ctx, "shen.lazyderef");
  KLObject* t2657 = shen_hd(ctx, t2640);
  KLObject* t2659 = shen_empty_list(ctx);
  KLObject* t2660 = shen_cons(ctx, t2641, t2659);
  KLObject* t2661 = shen_cons(ctx, t2657, t2660);
  KLObject* t2662 = shen_cons(ctx, t2655, t2661);
  KLObject* t2664 = shen_intern(ctx, "freeze");
  KLObject* t2666 = shen_intern(ctx, "shen.+m");
  KLObject* t2668 = shen_tl(ctx, t2639);
  KLObject* t2670 = shen_tl(ctx, t2640);
  KLObject* t2665;
  {
    KLObject* a2665[] = {t2666, t2668, t2670, t2641, t2642};
    t2665 = shen_apply_direct(ctx, "shen.compile-head", 5, a2665);
  }
  KLObject* t2673 = shen_empty_list(ctx);
  KLObject* t2674 = shen_cons(ctx, t2665, t2673);
  KLObject* t2675 = shen_cons(ctx, t2664, t2674);
  KLObject* t2676 = shen_intern(ctx, "if");
  KLObject* t2677 = shen_intern(ctx, "=");
  KLObject* t2680 = shen_hd(ctx, t2639);
  KLObject* t2681 = shen_empty_list(ctx);
  KLObject* t2682 = shen_cons(ctx, t2680, t2681);
  KLObject* t2683 = shen_cons(ctx, t2649, t2682);
  KLObject* t2684 = shen_cons(ctx, t2677, t2683);
  KLObject* t2685 = shen_intern(ctx, "thaw");
  KLObject* t2687 = shen_empty_list(ctx);
  KLObject* t2688 = shen_cons(ctx, t2651, t2687);
  KLObject* t2689 = shen_cons(ctx, t2685, t2688);
  KLObject* t2690 = shen_intern(ctx, "if");
  KLObject* t2691 = shen_intern(ctx, "shen.pvar?");
  KLObject* t2693 = shen_empty_list(ctx);
  KLObject* t2694 = shen_cons(ctx, t2649, t2693);
  KLObject* t2695 = shen_cons(ctx, t2691, t2694);
  KLObject* t2696 = shen_intern(ctx, "shen.bind!");
  KLObject* t2700 = shen_hd(ctx, t2639);
  KLObject* t2698;
  {
    KLObject* a2698[] = {t2700};
    t2698 = shen_apply_direct(ctx, "shen.demode", 1, a2698);
  }
  KLObject* t2703 = shen_empty_list(ctx);
  KLObject* t2704 = shen_cons(ctx, t2651, t2703);
  KLObject* t2705 = shen_cons(ctx, t2641, t2704);
  KLObject* t2706 = shen_cons(ctx, t2698, t2705);
  KLObject* t2707 = shen_cons(ctx, t2649, t2706);
  KLObject* t2708 = shen_cons(ctx, t2696, t2707);
  KLObject* t2709 = shen_false(ctx);
  KLObject* t2710 = shen_empty_list(ctx);
  KLObject* t2711 = shen_cons(ctx, t2709, t2710);
  KLObject* t2712 = shen_cons(ctx, t2708, t2711);
  KLObject* t2713 = shen_cons(ctx, t2695, t2712);
  KLObject* t2714 = shen_cons(ctx, t2690, t2713);
  KLObject* t2715 = shen_empty_list(ctx);
  KLObject* t2716 = shen_cons(ctx, t2714, t2715);
  KLObject* t2717 = shen_cons(ctx, t2689, t2716);
  KLObject* t2718 = shen_cons(ctx, t2684, t2717);
  KLObject* t2719 = shen_cons(ctx, t2676, t2718);
  KLObject* t2720 = shen_empty_list(ctx);
  KLObject* t2721 = shen_cons(ctx, t2719, t2720);
  KLObject* t2722 = shen_cons(ctx, t2675, t2721);
  KLObject* t2723 = shen_cons(ctx, t2651, t2722);
  KLObject* t2724 = shen_cons(ctx, t2662, t2723);
  KLObject* t2725 = shen_cons(ctx, t2649, t2724);
  KLObject* t2726 = shen_cons(ctx, t2653, t2725);
      t2643 = t2726;
    } else {
  KLObject* t2727 = shen_true(ctx);
    if (!shen_is_boolean(ctx, t2727))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t2727)) {
  KLObject* t2729 = shen_string(ctx, "implementation error in shen.atom-case-plus");
  KLObject* t2728;
  {
    KLObject* a2728[] = {t2729};
    t2728 = shen_tail_apply_direct(ctx, "simple-error", 1, a2728);
  }
      t2643 = t2728;
    } else {
      shen_simple_error(ctx, "No true case found for cond");
      t2643 = shen_empty_list(ctx);
    }
    }
  }
    return t2643;
  }
}

static KLObject* native_kl_shen_2econs_2dcase_2dplus_58 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t2730 = objects[0];
    KLObject* t2731 = objects[1];
    KLObject* t2732 = objects[2];
    KLObject* t2733 = objects[3];
  tail_start_kl_shen_2econs_2dcase_2dplus_58: ;
  KLObject* t2734;
  {
  KLObject* t2737 = shen_cons_p(ctx, t2730);
  KLObject* t2735;
  if (!shen_is_boolean(ctx, t2737))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t2737)) {
    t2735 = t2737;
  } else {
  KLObject* t2740 = shen_hd(ctx, t2730);
  KLObject* t2741 = shen_cons_p(ctx, t2740);
  KLObject* t2738;
  if (!shen_is_boolean(ctx, t2741))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t2741)) {
    t2738 = t2741;
  } else {
  KLObject* t2743 = shen_intern(ctx, "cons");
  KLObject* t2745 = shen_hd(ctx, t2730);
  KLObject* t2746 = shen_hd(ctx, t2745);
  KLObject* t2747 = shen_eq(ctx, t2743, t2746);
  KLObject* t2742;
  if (!shen_is_boolean(ctx, t2747))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t2747)) {
    t2742 = t2747;
  } else {
  KLObject* t2750 = shen_hd(ctx, t2730);
  KLObject* t2751 = shen_tl(ctx, t2750);
  KLObject* t2752 = shen_cons_p(ctx, t2751);
  KLObject* t2748;
  if (!shen_is_boolean(ctx, t2752))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t2752)) {
    t2748 = t2752;
  } else {
  KLObject* t2755 = shen_hd(ctx, t2730);
  KLObject* t2756 = shen_tl(ctx, t2755);
  KLObject* t2757 = shen_tl(ctx, t2756);
  KLObject* t2758 = shen_cons_p(ctx, t2757);
  KLObject* t2753;
  if (!shen_is_boolean(ctx, t2758))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t2758)) {
    t2753 = t2758;
  } else {
  KLObject* t2760 = shen_empty_list(ctx);
  KLObject* t2762 = shen_hd(ctx, t2730);
  KLObject* t2763 = shen_tl(ctx, t2762);
  KLObject* t2764 = shen_tl(ctx, t2763);
  KLObject* t2765 = shen_tl(ctx, t2764);
  KLObject* t2766 = shen_eq(ctx, t2760, t2765);
  KLObject* t2759;
  if (!shen_is_boolean(ctx, t2766))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t2766)) {
    t2759 = t2766;
  } else {
  KLObject* t2768 = shen_cons_p(ctx, t2731);
    if (!shen_is_boolean(ctx, t2768))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t2759 = t2768;
  }
    if (!shen_is_boolean(ctx, t2759))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t2753 = t2759;
  }
    if (!shen_is_boolean(ctx, t2753))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t2748 = t2753;
  }
    if (!shen_is_boolean(ctx, t2748))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t2742 = t2748;
  }
    if (!shen_is_boolean(ctx, t2742))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t2738 = t2742;
  }
    if (!shen_is_boolean(ctx, t2738))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t2735 = t2738;
  }
    if (!shen_is_boolean(ctx, t2735))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t2735)) {
  KLObject* t2770 = shen_intern(ctx, "Tm");
  KLObject* t2769;
  {
    KLObject* a2769[] = {t2770};
    t2769 = shen_apply_direct(ctx, "gensym", 1, a2769);
  }
  KLObject* t2772 = shen_intern(ctx, "GoTo");
  KLObject* t2771;
  {
    KLObject* a2771[] = {t2772};
    t2771 = shen_apply_direct(ctx, "gensym", 1, a2771);
  }
  KLObject* t2775 = shen_hd(ctx, t2730);
  KLObject* t2776 = shen_tl(ctx, t2775);
  KLObject* t2777 = shen_hd(ctx, t2776);
  KLObject* t2779 = shen_hd(ctx, t2730);
  KLObject* t2780 = shen_tl(ctx, t2779);
  KLObject* t2781 = shen_tl(ctx, t2780);
  KLObject* t2782 = shen_hd(ctx, t2781);
  KLObject* t2783 = shen_cons(ctx, t2777, t2782);
  KLObject* t2773;
  {
    KLObject* a2773[] = {t2783};
    t2773 = shen_apply_direct(ctx, "shen.extract-vars", 1, a2773);
  }
  KLObject* t2786 = shen_hd(ctx, t2730);
  KLObject* t2784;
  {
    KLObject* a2784[] = {t2786};
    t2784 = shen_apply_direct(ctx, "shen.tame", 1, a2784);
  }
  KLObject* t2787;
  {
    KLObject* a2787[] = {t2784};
    t2787 = shen_apply_direct(ctx, "shen.extract-vars", 1, a2787);
  }
  KLObject* t2789 = shen_intern(ctx, "let");
  KLObject* t2791 = shen_intern(ctx, "shen.lazyderef");
  KLObject* t2793 = shen_hd(ctx, t2731);
  KLObject* t2795 = shen_empty_list(ctx);
  KLObject* t2796 = shen_cons(ctx, t2732, t2795);
  KLObject* t2797 = shen_cons(ctx, t2793, t2796);
  KLObject* t2798 = shen_cons(ctx, t2791, t2797);
  KLObject* t2803 = shen_intern(ctx, "shen.+m");
  KLObject* t2805 = shen_tl(ctx, t2730);
  KLObject* t2807 = shen_tl(ctx, t2731);
  KLObject* t2802;
  {
    KLObject* a2802[] = {t2803, t2805, t2807, t2732, t2733};
    t2802 = shen_apply_direct(ctx, "shen.compile-head", 5, a2802);
  }
  KLObject* t2800;
  {
    KLObject* a2800[] = {t2773, t2802};
    t2800 = shen_apply_direct(ctx, "shen.goto", 2, a2800);
  }
  KLObject* t2810 = shen_intern(ctx, "if");
  KLObject* t2811 = shen_intern(ctx, "cons?");
  KLObject* t2813 = shen_empty_list(ctx);
  KLObject* t2814 = shen_cons(ctx, t2769, t2813);
  KLObject* t2815 = shen_cons(ctx, t2811, t2814);
  KLObject* t2817 = shen_intern(ctx, "shen.+m");
  KLObject* t2819 = shen_hd(ctx, t2730);
  KLObject* t2820 = shen_tl(ctx, t2819);
  KLObject* t2821 = shen_intern(ctx, "hd");
  KLObject* t2823 = shen_empty_list(ctx);
  KLObject* t2824 = shen_cons(ctx, t2769, t2823);
  KLObject* t2825 = shen_cons(ctx, t2821, t2824);
  KLObject* t2826 = shen_intern(ctx, "tl");
  KLObject* t2828 = shen_empty_list(ctx);
  KLObject* t2829 = shen_cons(ctx, t2769, t2828);
  KLObject* t2830 = shen_cons(ctx, t2826, t2829);
  KLObject* t2831 = shen_empty_list(ctx);
  KLObject* t2832 = shen_cons(ctx, t2830, t2831);
  KLObject* t2833 = shen_cons(ctx, t2825, t2832);
  KLObject* t2835;
  {
    KLObject* a2835[] = {t2771, t2773};
    t2835 = shen_apply_direct(ctx, "shen.invoke", 2, a2835);
  }
  KLObject* t2816;
  {
    KLObject* a2816[] = {t2817, t2820, t2833, t2732, t2835};
    t2816 = shen_apply_direct(ctx, "shen.compile-head", 5, a2816);
  }
  KLObject* t2838 = shen_intern(ctx, "if");
  KLObject* t2839 = shen_intern(ctx, "shen.pvar?");
  KLObject* t2841 = shen_empty_list(ctx);
  KLObject* t2842 = shen_cons(ctx, t2769, t2841);
  KLObject* t2843 = shen_cons(ctx, t2839, t2842);
  KLObject* t2846 = shen_intern(ctx, "shen.bind!");
  KLObject* t2848;
  {
    KLObject* a2848[] = {t2784};
    t2848 = shen_apply_direct(ctx, "shen.demode", 1, a2848);
  }
  KLObject* t2851 = shen_intern(ctx, "freeze");
  KLObject* t2852;
  {
    KLObject* a2852[] = {t2771, t2773};
    t2852 = shen_apply_direct(ctx, "shen.invoke", 2, a2852);
  }
  KLObject* t2855 = shen_empty_list(ctx);
  KLObject* t2856 = shen_cons(ctx, t2852, t2855);
  KLObject* t2857 = shen_cons(ctx, t2851, t2856);
  KLObject* t2858 = shen_empty_list(ctx);
  KLObject* t2859 = shen_cons(ctx, t2857, t2858);
  KLObject* t2860 = shen_cons(ctx, t2732, t2859);
  KLObject* t2861 = shen_cons(ctx, t2848, t2860);
  KLObject* t2862 = shen_cons(ctx, t2769, t2861);
  KLObject* t2863 = shen_cons(ctx, t2846, t2862);
  KLObject* t2844;
  {
    KLObject* a2844[] = {t2787, t2863, t2732};
    t2844 = shen_apply_direct(ctx, "shen.stpart", 3, a2844);
  }
  KLObject* t2865 = shen_false(ctx);
  KLObject* t2866 = shen_empty_list(ctx);
  KLObject* t2867 = shen_cons(ctx, t2865, t2866);
  KLObject* t2868 = shen_cons(ctx, t2844, t2867);
  KLObject* t2869 = shen_cons(ctx, t2843, t2868);
  KLObject* t2870 = shen_cons(ctx, t2838, t2869);
  KLObject* t2871 = shen_empty_list(ctx);
  KLObject* t2872 = shen_cons(ctx, t2870, t2871);
  KLObject* t2873 = shen_cons(ctx, t2816, t2872);
  KLObject* t2874 = shen_cons(ctx, t2815, t2873);
  KLObject* t2875 = shen_cons(ctx, t2810, t2874);
  KLObject* t2876 = shen_empty_list(ctx);
  KLObject* t2877 = shen_cons(ctx, t2875, t2876);
  KLObject* t2878 = shen_cons(ctx, t2800, t2877);
  KLObject* t2879 = shen_cons(ctx, t2771, t2878);
  KLObject* t2880 = shen_cons(ctx, t2798, t2879);
  KLObject* t2881 = shen_cons(ctx, t2769, t2880);
  KLObject* t2882 = shen_cons(ctx, t2789, t2881);
      t2734 = t2882;
    } else {
  KLObject* t2883 = shen_true(ctx);
    if (!shen_is_boolean(ctx, t2883))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t2883)) {
  KLObject* t2885 = shen_string(ctx, "implementation error in shen.cons-case-plus");
  KLObject* t2884;
  {
    KLObject* a2884[] = {t2885};
    t2884 = shen_tail_apply_direct(ctx, "simple-error", 1, a2884);
  }
      t2734 = t2884;
    } else {
      shen_simple_error(ctx, "No true case found for cond");
      t2734 = shen_empty_list(ctx);
    }
    }
  }
    return t2734;
  }
}

static KLObject* native_kl_shen_2edemode_59 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t2886 = objects[0];
  tail_start_kl_shen_2edemode_59: ;
  KLObject* t2887;
  {
  KLObject* t2890 = shen_cons_p(ctx, t2886);
  KLObject* t2888;
  if (!shen_is_boolean(ctx, t2890))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t2890)) {
    t2888 = t2890;
  } else {
  KLObject* t2892 = shen_intern(ctx, "shen.+m");
  KLObject* t2894 = shen_hd(ctx, t2886);
  KLObject* t2895 = shen_eq(ctx, t2892, t2894);
  KLObject* t2891;
  if (!shen_is_boolean(ctx, t2895))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t2895)) {
    t2891 = t2895;
  } else {
  KLObject* t2898 = shen_tl(ctx, t2886);
  KLObject* t2899 = shen_cons_p(ctx, t2898);
  KLObject* t2896;
  if (!shen_is_boolean(ctx, t2899))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t2899)) {
    t2896 = t2899;
  } else {
  KLObject* t2900 = shen_empty_list(ctx);
  KLObject* t2902 = shen_tl(ctx, t2886);
  KLObject* t2903 = shen_tl(ctx, t2902);
  KLObject* t2904 = shen_eq(ctx, t2900, t2903);
    if (!shen_is_boolean(ctx, t2904))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t2896 = t2904;
  }
    if (!shen_is_boolean(ctx, t2896))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t2891 = t2896;
  }
    if (!shen_is_boolean(ctx, t2891))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t2888 = t2891;
  }
    if (!shen_is_boolean(ctx, t2888))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t2888)) {
  KLObject* t2906 = shen_tl(ctx, t2886);
  KLObject* t2907 = shen_hd(ctx, t2906);
  {
    KLObject* n2908_0 = t2907;
    t2886 = n2908_0;
    goto tail_start_kl_shen_2edemode_59;
  }
  KLObject* t2908 = NULL;
      t2887 = t2908;
    } else {
  KLObject* t2911 = shen_cons_p(ctx, t2886);
  KLObject* t2909;
  if (!shen_is_boolean(ctx, t2911))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t2911)) {
    t2909 = t2911;
  } else {
  KLObject* t2913 = shen_intern(ctx, "shen.-m");
  KLObject* t2915 = shen_hd(ctx, t2886);
  KLObject* t2916 = shen_eq(ctx, t2913, t2915);
  KLObject* t2912;
  if (!shen_is_boolean(ctx, t2916))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t2916)) {
    t2912 = t2916;
  } else {
  KLObject* t2919 = shen_tl(ctx, t2886);
  KLObject* t2920 = shen_cons_p(ctx, t2919);
  KLObject* t2917;
  if (!shen_is_boolean(ctx, t2920))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t2920)) {
    t2917 = t2920;
  } else {
  KLObject* t2921 = shen_empty_list(ctx);
  KLObject* t2923 = shen_tl(ctx, t2886);
  KLObject* t2924 = shen_tl(ctx, t2923);
  KLObject* t2925 = shen_eq(ctx, t2921, t2924);
    if (!shen_is_boolean(ctx, t2925))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t2917 = t2925;
  }
    if (!shen_is_boolean(ctx, t2917))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t2912 = t2917;
  }
    if (!shen_is_boolean(ctx, t2912))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t2909 = t2912;
  }
    if (!shen_is_boolean(ctx, t2909))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t2909)) {
  KLObject* t2927 = shen_tl(ctx, t2886);
  KLObject* t2928 = shen_hd(ctx, t2927);
  {
    KLObject* n2929_0 = t2928;
    t2886 = n2929_0;
    goto tail_start_kl_shen_2edemode_59;
  }
  KLObject* t2929 = NULL;
      t2887 = t2929;
    } else {
  KLObject* t2931 = shen_cons_p(ctx, t2886);
    if (!shen_is_boolean(ctx, t2931))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t2931)) {
  KLObject* t2933;
  {
    Vector* caps_4 = shen_vector(ctx, 0);
    t2933 = shen_native_closure(ctx, 1, &lambda_4, caps_4);
  }
  KLObject* t2932;
  {
    KLObject* a2932[] = {t2933, t2886};
    t2932 = shen_tail_apply_direct(ctx, "map", 2, a2932);
  }
      t2887 = t2932;
    } else {
  KLObject* t2938 = shen_true(ctx);
    if (!shen_is_boolean(ctx, t2938))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t2938)) {
      t2887 = t2886;
    } else {
      shen_simple_error(ctx, "No true case found for cond");
      t2887 = shen_empty_list(ctx);
    }
    }
    }
    }
  }
    return t2887;
  }
}

static KLObject* native_kl_shen_2etame_60 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t2940 = objects[0];
  tail_start_kl_shen_2etame_60: ;
  KLObject* t2941;
  {
  KLObject* t2942;
  {
    KLObject* a2942[] = {t2940};
    t2942 = shen_apply_direct(ctx, "shen.wildcard?", 1, a2942);
  }
    if (!shen_is_boolean(ctx, t2942))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t2942)) {
  KLObject* t2945 = shen_intern(ctx, "Y");
  KLObject* t2944;
  {
    KLObject* a2944[] = {t2945};
    t2944 = shen_tail_apply_direct(ctx, "gensym", 1, a2944);
  }
      t2941 = t2944;
    } else {
  KLObject* t2947 = shen_cons_p(ctx, t2940);
    if (!shen_is_boolean(ctx, t2947))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t2947)) {
  KLObject* t2949;
  {
    Vector* caps_5 = shen_vector(ctx, 0);
    t2949 = shen_native_closure(ctx, 1, &lambda_5, caps_5);
  }
  KLObject* t2948;
  {
    KLObject* a2948[] = {t2949, t2940};
    t2948 = shen_tail_apply_direct(ctx, "map", 2, a2948);
  }
      t2941 = t2948;
    } else {
  KLObject* t2954 = shen_true(ctx);
    if (!shen_is_boolean(ctx, t2954))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t2954)) {
      t2941 = t2940;
    } else {
      shen_simple_error(ctx, "No true case found for cond");
      t2941 = shen_empty_list(ctx);
    }
    }
    }
  }
    return t2941;
  }
}

static KLObject* native_kl_shen_2egoto_61 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t2956 = objects[0];
    KLObject* t2957 = objects[1];
  tail_start_kl_shen_2egoto_61: ;
  KLObject* t2958;
  {
  KLObject* t2959 = shen_empty_list(ctx);
  KLObject* t2961 = shen_eq(ctx, t2959, t2956);
    if (!shen_is_boolean(ctx, t2961))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t2961)) {
  KLObject* t2962 = shen_intern(ctx, "freeze");
  KLObject* t2964 = shen_empty_list(ctx);
  KLObject* t2965 = shen_cons(ctx, t2957, t2964);
  KLObject* t2966 = shen_cons(ctx, t2962, t2965);
      t2958 = t2966;
    } else {
  KLObject* t2967 = shen_true(ctx);
    if (!shen_is_boolean(ctx, t2967))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t2967)) {
  KLObject* t2968;
  {
    KLObject* a2968[] = {t2956, t2957};
    t2968 = shen_tail_apply_direct(ctx, "shen.goto-h", 2, a2968);
  }
      t2958 = t2968;
    } else {
      shen_simple_error(ctx, "No true case found for cond");
      t2958 = shen_empty_list(ctx);
    }
    }
  }
    return t2958;
  }
}

static KLObject* native_kl_shen_2egoto_2dh_62 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t2971 = objects[0];
    KLObject* t2972 = objects[1];
  tail_start_kl_shen_2egoto_2dh_62: ;
  KLObject* t2973;
  {
  KLObject* t2974 = shen_empty_list(ctx);
  KLObject* t2976 = shen_eq(ctx, t2974, t2971);
    if (!shen_is_boolean(ctx, t2976))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t2976)) {
      t2973 = t2972;
    } else {
  KLObject* t2979 = shen_cons_p(ctx, t2971);
    if (!shen_is_boolean(ctx, t2979))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t2979)) {
  KLObject* t2980 = shen_intern(ctx, "lambda");
  KLObject* t2982 = shen_hd(ctx, t2971);
  KLObject* t2985 = shen_tl(ctx, t2971);
  KLObject* t2983;
  {
    KLObject* a2983[] = {t2985, t2972};
    t2983 = shen_apply_direct(ctx, "shen.goto-h", 2, a2983);
  }
  KLObject* t2987 = shen_empty_list(ctx);
  KLObject* t2988 = shen_cons(ctx, t2983, t2987);
  KLObject* t2989 = shen_cons(ctx, t2982, t2988);
  KLObject* t2990 = shen_cons(ctx, t2980, t2989);
      t2973 = t2990;
    } else {
  KLObject* t2991 = shen_true(ctx);
    if (!shen_is_boolean(ctx, t2991))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t2991)) {
  KLObject* t2993 = shen_string(ctx, "partial function shen.goto-h");
  KLObject* t2992;
  {
    KLObject* a2992[] = {t2993};
    t2992 = shen_tail_apply_direct(ctx, "simple-error", 1, a2992);
  }
      t2973 = t2992;
    } else {
      shen_simple_error(ctx, "No true case found for cond");
      t2973 = shen_empty_list(ctx);
    }
    }
    }
  }
    return t2973;
  }
}

static KLObject* native_kl_shen_2einvoke_63 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t2994 = objects[0];
    KLObject* t2995 = objects[1];
  tail_start_kl_shen_2einvoke_63: ;
  KLObject* t2996;
  {
  KLObject* t2997 = shen_empty_list(ctx);
  KLObject* t2999 = shen_eq(ctx, t2997, t2995);
    if (!shen_is_boolean(ctx, t2999))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t2999)) {
  KLObject* t3000 = shen_intern(ctx, "thaw");
  KLObject* t3002 = shen_empty_list(ctx);
  KLObject* t3003 = shen_cons(ctx, t2994, t3002);
  KLObject* t3004 = shen_cons(ctx, t3000, t3003);
      t2996 = t3004;
    } else {
  KLObject* t3005 = shen_true(ctx);
    if (!shen_is_boolean(ctx, t3005))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t3005)) {
  KLObject* t3008 = shen_cons(ctx, t2994, t2995);
      t2996 = t3008;
    } else {
      shen_simple_error(ctx, "No true case found for cond");
      t2996 = shen_empty_list(ctx);
    }
    }
  }
    return t2996;
  }
}

static KLObject* native_kl_shen_2ewildcard_3f_64 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t3009 = objects[0];
  tail_start_kl_shen_2ewildcard_3f_64: ;
  KLObject* t3011 = shen_intern(ctx, "_");
  KLObject* t3012 = shen_eq(ctx, t3009, t3011);
    return t3012;
  }
}

static KLObject* native_kl_shen_2epvar_3f_65 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t3013 = objects[0];
  tail_start_kl_shen_2epvar_3f_65: ;
  KLObject* t3014;
  {
    Vector* tenv_0 = shen_vector(ctx, 1);
    shen_vector_set(ctx, tenv_0, 0, t3013);
    t3014 = shen_trap_error(ctx, trap_body_0, trap_handler_0, tenv_0);
  }
    return t3014;
  }
}

static KLObject* native_kl_shen_2elazyderef_66 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t3029 = objects[0];
    KLObject* t3030 = objects[1];
  tail_start_kl_shen_2elazyderef_66: ;
  KLObject* t3032;
  {
    KLObject* a3032[] = {t3029};
    t3032 = shen_apply_direct(ctx, "shen.pvar?", 1, a3032);
  }
  KLObject* t3031;
  if (!shen_is_boolean(ctx, t3032))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t3032)) {
  KLObject* t3038 = shen_number_l(ctx, 1);
  KLObject* t3036;
  {
    KLObject* a3036[] = {t3029, t3038};
    t3036 = shen_apply_direct(ctx, "<-address", 2, a3036);
  }
  KLObject* t3034;
  {
    KLObject* a3034[] = {t3030, t3036};
    t3034 = shen_apply_direct(ctx, "<-address", 2, a3034);
  }
  KLObject* t3041 = shen_intern(ctx, "shen.-null-");
  KLObject* t3042 = shen_eq(ctx, t3034, t3041);
  KLObject* t3039;
  if (!shen_is_boolean(ctx, t3042))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t3042)) {
    t3039 = t3029;
  } else {
  {
    KLObject* n3046_0 = t3034;
    KLObject* n3046_1 = t3030;
    t3029 = n3046_0;
    t3030 = n3046_1;
    goto tail_start_kl_shen_2elazyderef_66;
  }
  KLObject* t3046 = NULL;
    t3039 = t3046;
  }
    t3031 = t3039;
  } else {
    t3031 = t3029;
  }
    return t3031;
  }
}

static KLObject* native_kl_shen_2ederef_67 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t3048 = objects[0];
    KLObject* t3049 = objects[1];
  tail_start_kl_shen_2ederef_67: ;
  KLObject* t3050;
  {
  KLObject* t3052 = shen_cons_p(ctx, t3048);
    if (!shen_is_boolean(ctx, t3052))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t3052)) {
  KLObject* t3055 = shen_hd(ctx, t3048);
  KLObject* t3053;
  {
    KLObject* a3053[] = {t3055, t3049};
    t3053 = shen_apply_direct(ctx, "shen.deref", 2, a3053);
  }
  KLObject* t3059 = shen_tl(ctx, t3048);
  KLObject* t3057;
  {
    KLObject* a3057[] = {t3059, t3049};
    t3057 = shen_apply_direct(ctx, "shen.deref", 2, a3057);
  }
  KLObject* t3061 = shen_cons(ctx, t3053, t3057);
      t3050 = t3061;
    } else {
  KLObject* t3062 = shen_true(ctx);
    if (!shen_is_boolean(ctx, t3062))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t3062)) {
  KLObject* t3064;
  {
    KLObject* a3064[] = {t3048};
    t3064 = shen_apply_direct(ctx, "shen.pvar?", 1, a3064);
  }
  KLObject* t3063;
  if (!shen_is_boolean(ctx, t3064))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t3064)) {
  KLObject* t3070 = shen_number_l(ctx, 1);
  KLObject* t3068;
  {
    KLObject* a3068[] = {t3048, t3070};
    t3068 = shen_apply_direct(ctx, "<-address", 2, a3068);
  }
  KLObject* t3066;
  {
    KLObject* a3066[] = {t3049, t3068};
    t3066 = shen_apply_direct(ctx, "<-address", 2, a3066);
  }
  KLObject* t3073 = shen_intern(ctx, "shen.-null-");
  KLObject* t3074 = shen_eq(ctx, t3066, t3073);
  KLObject* t3071;
  if (!shen_is_boolean(ctx, t3074))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t3074)) {
    t3071 = t3048;
  } else {
  {
    KLObject* n3078_0 = t3066;
    KLObject* n3078_1 = t3049;
    t3048 = n3078_0;
    t3049 = n3078_1;
    goto tail_start_kl_shen_2ederef_67;
  }
  KLObject* t3078 = NULL;
    t3071 = t3078;
  }
    t3063 = t3071;
  } else {
    t3063 = t3048;
  }
      t3050 = t3063;
    } else {
      shen_simple_error(ctx, "No true case found for cond");
      t3050 = shen_empty_list(ctx);
    }
    }
  }
    return t3050;
  }
}

static KLObject* native_kl_shen_2ebind_21_68 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t3080 = objects[0];
    KLObject* t3081 = objects[1];
    KLObject* t3082 = objects[2];
    KLObject* t3083 = objects[3];
  tail_start_kl_shen_2ebind_21_68: ;
  KLObject* t3084;
  {
    KLObject* a3084[] = {t3080, t3081, t3082};
    t3084 = shen_apply_direct(ctx, "shen.bindv", 3, a3084);
  }
  KLObject* t3088;
  {
    KLObject* a3088[] = {t3083};
    t3088 = shen_apply_direct(ctx, "thaw", 1, a3088);
  }
  KLObject* t3092 = shen_false(ctx);
  KLObject* t3093 = shen_eq(ctx, t3088, t3092);
  KLObject* t3090;
  if (!shen_is_boolean(ctx, t3093))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t3093)) {
  KLObject* t3094;
  {
    KLObject* a3094[] = {t3080, t3082, t3088};
    t3094 = shen_tail_apply_direct(ctx, "shen.unwind", 3, a3094);
  }
    t3090 = t3094;
  } else {
    t3090 = t3088;
  }
    return t3090;
  }
}

static KLObject* native_kl_shen_2ebindv_69 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t3099 = objects[0];
    KLObject* t3100 = objects[1];
    KLObject* t3101 = objects[2];
  tail_start_kl_shen_2ebindv_69: ;
  KLObject* t3106 = shen_number_l(ctx, 1);
  KLObject* t3104;
  {
    KLObject* a3104[] = {t3099, t3106};
    t3104 = shen_apply_direct(ctx, "<-address", 2, a3104);
  }
  KLObject* t3102;
  {
    KLObject* a3102[] = {t3101, t3104, t3100};
    t3102 = shen_tail_apply_direct(ctx, "address->", 3, a3102);
  }
    return t3102;
  }
}

static KLObject* native_kl_shen_2eunwind_70 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t3108 = objects[0];
    KLObject* t3109 = objects[1];
    KLObject* t3110 = objects[2];
  tail_start_kl_shen_2eunwind_70: ;
  KLObject* t3115 = shen_number_l(ctx, 1);
  KLObject* t3113;
  {
    KLObject* a3113[] = {t3108, t3115};
    t3113 = shen_apply_direct(ctx, "<-address", 2, a3113);
  }
  KLObject* t3116 = shen_intern(ctx, "shen.-null-");
  KLObject* t3111;
  {
    KLObject* a3111[] = {t3109, t3113, t3116};
    t3111 = shen_apply_direct(ctx, "address->", 3, a3111);
  }
    return t3110;
  }
}

static KLObject* native_kl_shen_2estpart_71 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t3118 = objects[0];
    KLObject* t3119 = objects[1];
    KLObject* t3120 = objects[2];
  tail_start_kl_shen_2estpart_71: ;
  KLObject* t3121;
  {
  KLObject* t3122 = shen_empty_list(ctx);
  KLObject* t3124 = shen_eq(ctx, t3122, t3118);
    if (!shen_is_boolean(ctx, t3124))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t3124)) {
      t3121 = t3119;
    } else {
  KLObject* t3127 = shen_cons_p(ctx, t3118);
    if (!shen_is_boolean(ctx, t3127))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t3127)) {
  KLObject* t3128 = shen_intern(ctx, "let");
  KLObject* t3130 = shen_hd(ctx, t3118);
  KLObject* t3131 = shen_intern(ctx, "shen.newpv");
  KLObject* t3133 = shen_empty_list(ctx);
  KLObject* t3134 = shen_cons(ctx, t3120, t3133);
  KLObject* t3135 = shen_cons(ctx, t3131, t3134);
  KLObject* t3136 = shen_intern(ctx, "shen.gc");
  KLObject* t3140 = shen_tl(ctx, t3118);
  KLObject* t3138;
  {
    KLObject* a3138[] = {t3140, t3119, t3120};
    t3138 = shen_apply_direct(ctx, "shen.stpart", 3, a3138);
  }
  KLObject* t3143 = shen_empty_list(ctx);
  KLObject* t3144 = shen_cons(ctx, t3138, t3143);
  KLObject* t3145 = shen_cons(ctx, t3120, t3144);
  KLObject* t3146 = shen_cons(ctx, t3136, t3145);
  KLObject* t3147 = shen_empty_list(ctx);
  KLObject* t3148 = shen_cons(ctx, t3146, t3147);
  KLObject* t3149 = shen_cons(ctx, t3135, t3148);
  KLObject* t3150 = shen_cons(ctx, t3130, t3149);
  KLObject* t3151 = shen_cons(ctx, t3128, t3150);
      t3121 = t3151;
    } else {
  KLObject* t3152 = shen_true(ctx);
    if (!shen_is_boolean(ctx, t3152))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t3152)) {
  KLObject* t3154 = shen_string(ctx, "implementation error in shen.stpart");
  KLObject* t3153;
  {
    KLObject* a3153[] = {t3154};
    t3153 = shen_tail_apply_direct(ctx, "simple-error", 1, a3153);
  }
      t3121 = t3153;
    } else {
      shen_simple_error(ctx, "No true case found for cond");
      t3121 = shen_empty_list(ctx);
    }
    }
    }
  }
    return t3121;
  }
}

static KLObject* native_kl_shen_2egc_72 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t3155 = objects[0];
    KLObject* t3156 = objects[1];
  tail_start_kl_shen_2egc_72: ;
  KLObject* t3159 = shen_false(ctx);
  KLObject* t3160 = shen_eq(ctx, t3156, t3159);
  KLObject* t3157;
  if (!shen_is_boolean(ctx, t3160))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t3160)) {
  KLObject* t3161;
  {
    KLObject* a3161[] = {t3155};
    t3161 = shen_apply_direct(ctx, "shen.ticket-number", 1, a3161);
  }
  KLObject* t3163;
  {
    KLObject* a3163[] = {t3161, t3155};
    t3163 = shen_apply_direct(ctx, "shen.decrement-ticket", 2, a3163);
  }
    t3157 = t3156;
  } else {
    t3157 = t3156;
  }
    return t3157;
  }
}

static KLObject* native_kl_shen_2edecrement_2dticket_73 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t3168 = objects[0];
    KLObject* t3169 = objects[1];
  tail_start_kl_shen_2edecrement_2dticket_73: ;
  KLObject* t3172 = shen_number_l(ctx, 1);
  KLObject* t3174 = shen_number_l(ctx, 1);
  KLObject* t3175 = shen_sub(ctx, t3168, t3174);
  KLObject* t3170;
  {
    KLObject* a3170[] = {t3169, t3172, t3175};
    t3170 = shen_tail_apply_direct(ctx, "address->", 3, a3170);
  }
    return t3170;
  }
}

static KLObject* native_kl_shen_2enewpv_74 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t3176 = objects[0];
  tail_start_kl_shen_2enewpv_74: ;
  KLObject* t3177;
  {
    KLObject* a3177[] = {t3176};
    t3177 = shen_apply_direct(ctx, "shen.ticket-number", 1, a3177);
  }
  KLObject* t3179;
  {
    KLObject* a3179[] = {t3177};
    t3179 = shen_apply_direct(ctx, "shen.make-prolog-variable", 1, a3179);
  }
  KLObject* t3181;
  {
    KLObject* a3181[] = {t3176, t3177};
    t3181 = shen_apply_direct(ctx, "shen.nextticket", 2, a3181);
  }
    return t3179;
  }
}

static KLObject* native_kl_shen_2eticket_2dnumber_75 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t3185 = objects[0];
  tail_start_kl_shen_2eticket_2dnumber_75: ;
  KLObject* t3188 = shen_number_l(ctx, 1);
  KLObject* t3186;
  {
    KLObject* a3186[] = {t3185, t3188};
    t3186 = shen_tail_apply_direct(ctx, "<-address", 2, a3186);
  }
    return t3186;
  }
}

static KLObject* native_kl_shen_2enextticket_76 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t3189 = objects[0];
    KLObject* t3190 = objects[1];
  tail_start_kl_shen_2enextticket_76: ;
  KLObject* t3194 = shen_intern(ctx, "shen.-null-");
  KLObject* t3191;
  {
    KLObject* a3191[] = {t3189, t3190, t3194};
    t3191 = shen_apply_direct(ctx, "address->", 3, a3191);
  }
  KLObject* t3197 = shen_number_l(ctx, 1);
  KLObject* t3199 = shen_number_l(ctx, 1);
  KLObject* t3200 = shen_add(ctx, t3190, t3199);
  KLObject* t3195;
  {
    KLObject* a3195[] = {t3191, t3197, t3200};
    t3195 = shen_tail_apply_direct(ctx, "address->", 3, a3195);
  }
    return t3195;
  }
}

static KLObject* native_kl_shen_2emake_2dprolog_2dvariable_77 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t3201 = objects[0];
  tail_start_kl_shen_2emake_2dprolog_2dvariable_77: ;
  KLObject* t3205 = shen_number_l(ctx, 2);
  KLObject* t3204;
  {
    KLObject* a3204[] = {t3205};
    t3204 = shen_apply_direct(ctx, "absvector", 1, a3204);
  }
  KLObject* t3206 = shen_number_l(ctx, 0);
  KLObject* t3207 = shen_intern(ctx, "shen.pvar");
  KLObject* t3203;
  {
    KLObject* a3203[] = {t3204, t3206, t3207};
    t3203 = shen_apply_direct(ctx, "address->", 3, a3203);
  }
  KLObject* t3208 = shen_number_l(ctx, 1);
  KLObject* t3202;
  {
    KLObject* a3202[] = {t3203, t3208, t3201};
    t3202 = shen_tail_apply_direct(ctx, "address->", 3, a3202);
  }
    return t3202;
  }
}

static KLObject* native_kl_shen_2epvar_78 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t3210 = objects[0];
  tail_start_kl_shen_2epvar_78: ;
  KLObject* t3212 = shen_string(ctx, "Var");
  KLObject* t3216 = shen_number_l(ctx, 1);
  KLObject* t3214;
  {
    KLObject* a3214[] = {t3210, t3216};
    t3214 = shen_apply_direct(ctx, "<-address", 2, a3214);
  }
  KLObject* t3217 = shen_string(ctx, "");
  KLObject* t3218 = shen_intern(ctx, "shen.a");
  KLObject* t3213;
  {
    KLObject* a3213[] = {t3214, t3217, t3218};
    t3213 = shen_apply_direct(ctx, "shen.app", 3, a3213);
  }
  KLObject* t3211;
  {
    KLObject* a3211[] = {t3212, t3213};
    t3211 = shen_tail_apply_direct(ctx, "cn", 2, a3211);
  }
    return t3211;
  }
}

static KLObject* native_kl_shen_2eincinfs_79 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  (void)function_object;
  (void)arguments;
  {
  tail_start_kl_shen_2eincinfs_79: ;
  KLObject* t3220 = shen_intern(ctx, "shen.*infs*");
  KLObject* t3221 = shen_number_l(ctx, 1);
  KLObject* t3223 = shen_intern(ctx, "shen.*infs*");
  KLObject* t3222;
  {
    KLObject* a3222[] = {t3223};
    t3222 = shen_apply_direct(ctx, "value", 1, a3222);
  }
  KLObject* t3224 = shen_add(ctx, t3221, t3222);
  KLObject* t3219;
  {
    KLObject* a3219[] = {t3220, t3224};
    t3219 = shen_tail_apply_direct(ctx, "set", 2, a3219);
  }
    return t3219;
  }
}

static KLObject* native_kl_shen_2eprolog_2dvector_2dsize_80 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t3225 = objects[0];
  tail_start_kl_shen_2eprolog_2dvector_2dsize_80: ;
  KLObject* t3228;
  {
    KLObject* a3228[] = {t3225};
    t3228 = shen_apply_direct(ctx, "integer?", 1, a3228);
  }
  KLObject* t3227;
  if (!shen_is_boolean(ctx, t3228))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t3228)) {
    t3227 = t3228;
  } else {
  KLObject* t3231 = shen_number_l(ctx, 0);
  KLObject* t3232 = shen_gt(ctx, t3225, t3231);
    if (!shen_is_boolean(ctx, t3232))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t3227 = t3232;
  }
  KLObject* t3226;
  if (!shen_is_boolean(ctx, t3227))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t3227)) {
  KLObject* t3234 = shen_intern(ctx, "shen.*size-prolog-vector*");
  KLObject* t3233;
  {
    KLObject* a3233[] = {t3234, t3225};
    t3233 = shen_tail_apply_direct(ctx, "set", 2, a3233);
  }
    t3226 = t3233;
  } else {
  KLObject* t3238 = shen_string(ctx, "prolog vector size: size should be a positive integer; not ");
  KLObject* t3241 = shen_string(ctx, "");
  KLObject* t3242 = shen_intern(ctx, "shen.a");
  KLObject* t3239;
  {
    KLObject* a3239[] = {t3225, t3241, t3242};
    t3239 = shen_apply_direct(ctx, "shen.app", 3, a3239);
  }
  KLObject* t3237;
  {
    KLObject* a3237[] = {t3238, t3239};
    t3237 = shen_apply_direct(ctx, "cn", 2, a3237);
  }
  KLObject* t3236;
  {
    KLObject* a3236[] = {t3237};
    t3236 = shen_tail_apply_direct(ctx, "simple-error", 1, a3236);
  }
    t3226 = t3236;
  }
    return t3226;
  }
}

static KLObject* native_kl_shen_2elzy_3d_21_81 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t3243 = objects[0];
    KLObject* t3244 = objects[1];
    KLObject* t3245 = objects[2];
    KLObject* t3246 = objects[3];
  tail_start_kl_shen_2elzy_3d_21_81: ;
  KLObject* t3247;
  {
  KLObject* t3250 = shen_eq(ctx, t3243, t3244);
    if (!shen_is_boolean(ctx, t3250))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t3250)) {
  KLObject* t3251;
  {
    KLObject* a3251[] = {t3246};
    t3251 = shen_tail_apply_direct(ctx, "thaw", 1, a3251);
  }
      t3247 = t3251;
    } else {
  KLObject* t3254;
  {
    KLObject* a3254[] = {t3243};
    t3254 = shen_apply_direct(ctx, "shen.pvar?", 1, a3254);
  }
  KLObject* t3253;
  if (!shen_is_boolean(ctx, t3254))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t3254)) {
    t3253 = t3254;
  } else {
  KLObject* t3259;
  {
    KLObject* a3259[] = {t3244, t3245};
    t3259 = shen_apply_direct(ctx, "shen.deref", 2, a3259);
  }
  KLObject* t3257;
  {
    KLObject* a3257[] = {t3243, t3259};
    t3257 = shen_apply_direct(ctx, "shen.occurs-check?", 2, a3257);
  }
  KLObject* t3256;
  {
    KLObject* a3256[] = {t3257};
    t3256 = shen_apply_direct(ctx, "not", 1, a3256);
  }
    if (!shen_is_boolean(ctx, t3256))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t3253 = t3256;
  }
    if (!shen_is_boolean(ctx, t3253))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t3253)) {
  KLObject* t3262;
  {
    KLObject* a3262[] = {t3243, t3244, t3245, t3246};
    t3262 = shen_tail_apply_direct(ctx, "shen.bind!", 4, a3262);
  }
      t3247 = t3262;
    } else {
  KLObject* t3268;
  {
    KLObject* a3268[] = {t3244};
    t3268 = shen_apply_direct(ctx, "shen.pvar?", 1, a3268);
  }
  KLObject* t3267;
  if (!shen_is_boolean(ctx, t3268))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t3268)) {
    t3267 = t3268;
  } else {
  KLObject* t3273;
  {
    KLObject* a3273[] = {t3243, t3245};
    t3273 = shen_apply_direct(ctx, "shen.deref", 2, a3273);
  }
  KLObject* t3271;
  {
    KLObject* a3271[] = {t3244, t3273};
    t3271 = shen_apply_direct(ctx, "shen.occurs-check?", 2, a3271);
  }
  KLObject* t3270;
  {
    KLObject* a3270[] = {t3271};
    t3270 = shen_apply_direct(ctx, "not", 1, a3270);
  }
    if (!shen_is_boolean(ctx, t3270))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t3267 = t3270;
  }
    if (!shen_is_boolean(ctx, t3267))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t3267)) {
  KLObject* t3276;
  {
    KLObject* a3276[] = {t3244, t3243, t3245, t3246};
    t3276 = shen_tail_apply_direct(ctx, "shen.bind!", 4, a3276);
  }
      t3247 = t3276;
    } else {
  KLObject* t3283 = shen_cons_p(ctx, t3243);
  KLObject* t3281;
  if (!shen_is_boolean(ctx, t3283))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t3283)) {
    t3281 = t3283;
  } else {
  KLObject* t3285 = shen_cons_p(ctx, t3244);
    if (!shen_is_boolean(ctx, t3285))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t3281 = t3285;
  }
    if (!shen_is_boolean(ctx, t3281))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t3281)) {
  KLObject* t3288 = shen_hd(ctx, t3243);
  KLObject* t3286;
  {
    KLObject* a3286[] = {t3288, t3245};
    t3286 = shen_apply_direct(ctx, "shen.lazyderef", 2, a3286);
  }
  KLObject* t3292 = shen_hd(ctx, t3244);
  KLObject* t3290;
  {
    KLObject* a3290[] = {t3292, t3245};
    t3290 = shen_apply_direct(ctx, "shen.lazyderef", 2, a3290);
  }
  KLObject* t3295;
  {
    Vector* caps_7 = shen_vector(ctx, 4);
    shen_vector_set(ctx, caps_7, 0, t3243);
    shen_vector_set(ctx, caps_7, 1, t3245);
    shen_vector_set(ctx, caps_7, 2, t3244);
    shen_vector_set(ctx, caps_7, 3, t3246);
    t3295 = shen_native_closure(ctx, 0, &lambda_7, caps_7);
  }
  {
    KLObject* n3311_0 = t3286;
    KLObject* n3311_1 = t3290;
    KLObject* n3311_2 = t3245;
    KLObject* n3311_3 = t3295;
    t3243 = n3311_0;
    t3244 = n3311_1;
    t3245 = n3311_2;
    t3246 = n3311_3;
    goto tail_start_kl_shen_2elzy_3d_21_81;
  }
  KLObject* t3311 = NULL;
      t3247 = t3311;
    } else {
  KLObject* t3312 = shen_true(ctx);
    if (!shen_is_boolean(ctx, t3312))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t3312)) {
  KLObject* t3313 = shen_false(ctx);
      t3247 = t3313;
    } else {
      shen_simple_error(ctx, "No true case found for cond");
      t3247 = shen_empty_list(ctx);
    }
    }
    }
    }
    }
  }
    return t3247;
  }
}

static KLObject* native_kl_shen_2elzy_3d_82 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t3314 = objects[0];
    KLObject* t3315 = objects[1];
    KLObject* t3316 = objects[2];
    KLObject* t3317 = objects[3];
  tail_start_kl_shen_2elzy_3d_82: ;
  KLObject* t3318;
  {
  KLObject* t3321 = shen_eq(ctx, t3314, t3315);
    if (!shen_is_boolean(ctx, t3321))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t3321)) {
  KLObject* t3322;
  {
    KLObject* a3322[] = {t3317};
    t3322 = shen_tail_apply_direct(ctx, "thaw", 1, a3322);
  }
      t3318 = t3322;
    } else {
  KLObject* t3324;
  {
    KLObject* a3324[] = {t3314};
    t3324 = shen_apply_direct(ctx, "shen.pvar?", 1, a3324);
  }
    if (!shen_is_boolean(ctx, t3324))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t3324)) {
  KLObject* t3326;
  {
    KLObject* a3326[] = {t3314, t3315, t3316, t3317};
    t3326 = shen_tail_apply_direct(ctx, "shen.bind!", 4, a3326);
  }
      t3318 = t3326;
    } else {
  KLObject* t3331;
  {
    KLObject* a3331[] = {t3315};
    t3331 = shen_apply_direct(ctx, "shen.pvar?", 1, a3331);
  }
    if (!shen_is_boolean(ctx, t3331))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t3331)) {
  KLObject* t3333;
  {
    KLObject* a3333[] = {t3315, t3314, t3316, t3317};
    t3333 = shen_tail_apply_direct(ctx, "shen.bind!", 4, a3333);
  }
      t3318 = t3333;
    } else {
  KLObject* t3340 = shen_cons_p(ctx, t3314);
  KLObject* t3338;
  if (!shen_is_boolean(ctx, t3340))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t3340)) {
    t3338 = t3340;
  } else {
  KLObject* t3342 = shen_cons_p(ctx, t3315);
    if (!shen_is_boolean(ctx, t3342))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t3338 = t3342;
  }
    if (!shen_is_boolean(ctx, t3338))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t3338)) {
  KLObject* t3345 = shen_hd(ctx, t3314);
  KLObject* t3343;
  {
    KLObject* a3343[] = {t3345, t3316};
    t3343 = shen_apply_direct(ctx, "shen.lazyderef", 2, a3343);
  }
  KLObject* t3349 = shen_hd(ctx, t3315);
  KLObject* t3347;
  {
    KLObject* a3347[] = {t3349, t3316};
    t3347 = shen_apply_direct(ctx, "shen.lazyderef", 2, a3347);
  }
  KLObject* t3352;
  {
    Vector* caps_8 = shen_vector(ctx, 4);
    shen_vector_set(ctx, caps_8, 0, t3314);
    shen_vector_set(ctx, caps_8, 1, t3316);
    shen_vector_set(ctx, caps_8, 2, t3315);
    shen_vector_set(ctx, caps_8, 3, t3317);
    t3352 = shen_native_closure(ctx, 0, &lambda_8, caps_8);
  }
  {
    KLObject* n3368_0 = t3343;
    KLObject* n3368_1 = t3347;
    KLObject* n3368_2 = t3316;
    KLObject* n3368_3 = t3352;
    t3314 = n3368_0;
    t3315 = n3368_1;
    t3316 = n3368_2;
    t3317 = n3368_3;
    goto tail_start_kl_shen_2elzy_3d_82;
  }
  KLObject* t3368 = NULL;
      t3318 = t3368;
    } else {
  KLObject* t3369 = shen_true(ctx);
    if (!shen_is_boolean(ctx, t3369))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t3369)) {
  KLObject* t3370 = shen_false(ctx);
      t3318 = t3370;
    } else {
      shen_simple_error(ctx, "No true case found for cond");
      t3318 = shen_empty_list(ctx);
    }
    }
    }
    }
    }
  }
    return t3318;
  }
}

static KLObject* native_kl_shen_2eoccurs_2dcheck_3f_83 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t3371 = objects[0];
    KLObject* t3372 = objects[1];
  tail_start_kl_shen_2eoccurs_2dcheck_3f_83: ;
  KLObject* t3373;
  {
  KLObject* t3376 = shen_eq(ctx, t3371, t3372);
    if (!shen_is_boolean(ctx, t3376))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t3376)) {
  KLObject* t3377 = shen_true(ctx);
      t3373 = t3377;
    } else {
  KLObject* t3379 = shen_cons_p(ctx, t3372);
    if (!shen_is_boolean(ctx, t3379))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t3379)) {
  KLObject* t3384 = shen_hd(ctx, t3372);
  KLObject* t3381;
  {
    KLObject* a3381[] = {t3371, t3384};
    t3381 = shen_apply_direct(ctx, "shen.occurs-check?", 2, a3381);
  }
  KLObject* t3380;
  if (!shen_is_boolean(ctx, t3381))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (shen_boolean_value(ctx, t3381)) {
    t3380 = t3381;
  } else {
  KLObject* t3388 = shen_tl(ctx, t3372);
  KLObject* t3385;
  {
    KLObject* a3385[] = {t3371, t3388};
    t3385 = shen_apply_direct(ctx, "shen.occurs-check?", 2, a3385);
  }
    if (!shen_is_boolean(ctx, t3385))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t3380 = t3385;
  }
      t3373 = t3380;
    } else {
  KLObject* t3389 = shen_true(ctx);
    if (!shen_is_boolean(ctx, t3389))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t3389)) {
  KLObject* t3390 = shen_false(ctx);
      t3373 = t3390;
    } else {
      shen_simple_error(ctx, "No true case found for cond");
      t3373 = shen_empty_list(ctx);
    }
    }
    }
  }
    return t3373;
  }
}

static KLObject* native_kl_call_84 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t3391 = objects[0];
    KLObject* t3392 = objects[1];
    KLObject* t3393 = objects[2];
    KLObject* t3394 = objects[3];
    KLObject* t3395 = objects[4];
  tail_start_kl_call_84: ;
  KLObject* t3399;
  {
    Vector* a3399 = shen_vector(ctx, 1);
    shen_vector_set(ctx, a3399, 0, t3392);
    t3399 = shen_apply(ctx, t3391, a3399);
  }
  KLObject* t3398;
  {
    Vector* a3398 = shen_vector(ctx, 1);
    shen_vector_set(ctx, a3398, 0, t3393);
    t3398 = shen_apply(ctx, t3399, a3398);
  }
  KLObject* t3397;
  {
    Vector* a3397 = shen_vector(ctx, 1);
    shen_vector_set(ctx, a3397, 0, t3394);
    t3397 = shen_apply(ctx, t3398, a3397);
  }
  KLObject* t3396;
  {
    Vector* a3396 = shen_vector(ctx, 1);
    shen_vector_set(ctx, a3396, 0, t3395);
    t3396 = shen_tail_apply(ctx, t3397, a3396);
  }
    return t3396;
  }
}

static KLObject* native_kl_return_85 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t3405 = objects[0];
    KLObject* t3406 = objects[1];
    KLObject* t3407 = objects[2];
    KLObject* t3408 = objects[3];
    KLObject* t3409 = objects[4];
  tail_start_kl_return_85: ;
  KLObject* t3410;
  {
    KLObject* a3410[] = {t3405, t3406};
    t3410 = shen_tail_apply_direct(ctx, "shen.deref", 2, a3410);
  }
    return t3410;
  }
}

static KLObject* native_kl_when_86 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t3413 = objects[0];
    KLObject* t3414 = objects[1];
    KLObject* t3415 = objects[2];
    KLObject* t3416 = objects[3];
    KLObject* t3417 = objects[4];
  tail_start_kl_when_86: ;
  KLObject* t3418;
  if (!shen_is_boolean(ctx, t3413))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t3413)) {
  KLObject* t3420;
  {
    KLObject* a3420[] = {t3417};
    t3420 = shen_tail_apply_direct(ctx, "thaw", 1, a3420);
  }
    t3418 = t3420;
  } else {
  KLObject* t3422 = shen_false(ctx);
    t3418 = t3422;
  }
    return t3418;
  }
}

static KLObject* native_kl_is_87 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t3423 = objects[0];
    KLObject* t3424 = objects[1];
    KLObject* t3425 = objects[2];
    KLObject* t3426 = objects[3];
    KLObject* t3427 = objects[4];
    KLObject* t3428 = objects[5];
  tail_start_kl_is_87: ;
  KLObject* t3430;
  {
    KLObject* a3430[] = {t3423, t3425};
    t3430 = shen_apply_direct(ctx, "shen.lazyderef", 2, a3430);
  }
  KLObject* t3433;
  {
    KLObject* a3433[] = {t3424, t3425};
    t3433 = shen_apply_direct(ctx, "shen.lazyderef", 2, a3433);
  }
  KLObject* t3429;
  {
    KLObject* a3429[] = {t3430, t3433, t3425, t3428};
    t3429 = shen_tail_apply_direct(ctx, "shen.lzy=", 4, a3429);
  }
    return t3429;
  }
}

static KLObject* native_kl_is_21_88 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t3438 = objects[0];
    KLObject* t3439 = objects[1];
    KLObject* t3440 = objects[2];
    KLObject* t3441 = objects[3];
    KLObject* t3442 = objects[4];
    KLObject* t3443 = objects[5];
  tail_start_kl_is_21_88: ;
  KLObject* t3445;
  {
    KLObject* a3445[] = {t3438, t3440};
    t3445 = shen_apply_direct(ctx, "shen.lazyderef", 2, a3445);
  }
  KLObject* t3448;
  {
    KLObject* a3448[] = {t3439, t3440};
    t3448 = shen_apply_direct(ctx, "shen.lazyderef", 2, a3448);
  }
  KLObject* t3444;
  {
    KLObject* a3444[] = {t3445, t3448, t3440, t3443};
    t3444 = shen_tail_apply_direct(ctx, "shen.lzy=!", 4, a3444);
  }
    return t3444;
  }
}

static KLObject* native_kl_bind_89 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t3453 = objects[0];
    KLObject* t3454 = objects[1];
    KLObject* t3455 = objects[2];
    KLObject* t3456 = objects[3];
    KLObject* t3457 = objects[4];
    KLObject* t3458 = objects[5];
  tail_start_kl_bind_89: ;
  KLObject* t3459;
  {
    KLObject* a3459[] = {t3453, t3454, t3455, t3458};
    t3459 = shen_tail_apply_direct(ctx, "shen.bind!", 4, a3459);
  }
    return t3459;
  }
}

static KLObject* native_kl_var_3f_90 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t3464 = objects[0];
    KLObject* t3465 = objects[1];
    KLObject* t3466 = objects[2];
    KLObject* t3467 = objects[3];
    KLObject* t3468 = objects[4];
  tail_start_kl_var_3f_90: ;
  KLObject* t3471;
  {
    KLObject* a3471[] = {t3464, t3465};
    t3471 = shen_apply_direct(ctx, "shen.lazyderef", 2, a3471);
  }
  KLObject* t3470;
  {
    KLObject* a3470[] = {t3471};
    t3470 = shen_apply_direct(ctx, "shen.pvar?", 1, a3470);
  }
  KLObject* t3469;
  if (!shen_is_boolean(ctx, t3470))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t3470)) {
  KLObject* t3474;
  {
    KLObject* a3474[] = {t3468};
    t3474 = shen_tail_apply_direct(ctx, "thaw", 1, a3474);
  }
    t3469 = t3474;
  } else {
  KLObject* t3476 = shen_false(ctx);
    t3469 = t3476;
  }
    return t3469;
  }
}

static KLObject* native_kl_shen_2eprint_2dprolog_2dvector_91 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t3477 = objects[0];
  tail_start_kl_shen_2eprint_2dprolog_2dvector_91: ;
  KLObject* t3478 = shen_string(ctx, "|prolog vector|");
    return t3478;
  }
}

static KLObject* native_kl_fork_92 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t3479 = objects[0];
    KLObject* t3480 = objects[1];
    KLObject* t3481 = objects[2];
    KLObject* t3482 = objects[3];
    KLObject* t3483 = objects[4];
  tail_start_kl_fork_92: ;
  KLObject* t3484;
  {
  KLObject* t3485 = shen_empty_list(ctx);
  KLObject* t3487 = shen_eq(ctx, t3485, t3479);
    if (!shen_is_boolean(ctx, t3487))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t3487)) {
  KLObject* t3488 = shen_false(ctx);
      t3484 = t3488;
    } else {
  KLObject* t3490 = shen_cons_p(ctx, t3479);
    if (!shen_is_boolean(ctx, t3490))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t3490)) {
  KLObject* t3496 = shen_hd(ctx, t3479);
  KLObject* t3494;
  {
    Vector* a3494 = shen_vector(ctx, 1);
    shen_vector_set(ctx, a3494, 0, t3480);
    t3494 = shen_apply(ctx, t3496, a3494);
  }
  KLObject* t3493;
  {
    Vector* a3493 = shen_vector(ctx, 1);
    shen_vector_set(ctx, a3493, 0, t3481);
    t3493 = shen_apply(ctx, t3494, a3493);
  }
  KLObject* t3492;
  {
    Vector* a3492 = shen_vector(ctx, 1);
    shen_vector_set(ctx, a3492, 0, t3482);
    t3492 = shen_apply(ctx, t3493, a3492);
  }
  KLObject* t3491;
  {
    Vector* a3491 = shen_vector(ctx, 1);
    shen_vector_set(ctx, a3491, 0, t3483);
    t3491 = shen_apply(ctx, t3492, a3491);
  }
  KLObject* t3503 = shen_false(ctx);
  KLObject* t3504 = shen_eq(ctx, t3491, t3503);
  KLObject* t3501;
  if (!shen_is_boolean(ctx, t3504))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t3504)) {
  KLObject* t3506 = shen_tl(ctx, t3479);
  {
    KLObject* n3511_0 = t3506;
    KLObject* n3511_1 = t3480;
    KLObject* n3511_2 = t3481;
    KLObject* n3511_3 = t3482;
    KLObject* n3511_4 = t3483;
    t3479 = n3511_0;
    t3480 = n3511_1;
    t3481 = n3511_2;
    t3482 = n3511_3;
    t3483 = n3511_4;
    goto tail_start_kl_fork_92;
  }
  KLObject* t3511 = NULL;
    t3501 = t3511;
  } else {
    t3501 = t3491;
  }
      t3484 = t3501;
    } else {
  KLObject* t3513 = shen_true(ctx);
    if (!shen_is_boolean(ctx, t3513))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t3513)) {
  KLObject* t3515 = shen_string(ctx, "fork expects a list of literals\n");
  KLObject* t3514;
  {
    KLObject* a3514[] = {t3515};
    t3514 = shen_tail_apply_direct(ctx, "simple-error", 1, a3514);
  }
      t3484 = t3514;
    } else {
      shen_simple_error(ctx, "No true case found for cond");
      t3484 = shen_empty_list(ctx);
    }
    }
    }
  }
    return t3484;
  }
}

static KLObject* native_kl_findall_93 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t3516 = objects[0];
    KLObject* t3517 = objects[1];
    KLObject* t3518 = objects[2];
    KLObject* t3519 = objects[3];
    KLObject* t3520 = objects[4];
    KLObject* t3521 = objects[5];
    KLObject* t3522 = objects[6];
  tail_start_kl_findall_93: ;
  KLObject* t3524;
  {
    KLObject* a3524[] = {t3520};
    t3524 = shen_apply_direct(ctx, "shen.unlocked?", 1, a3524);
  }
  KLObject* t3523;
  if (!shen_is_boolean(ctx, t3524))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t3524)) {
  KLObject* t3526;
  {
    KLObject* a3526[] = {t3519};
    t3526 = shen_apply_direct(ctx, "shen.newpv", 1, a3526);
  }
  KLObject* t3530 = shen_apply_direct(ctx, "shen.incinfs", 0, NULL);
  KLObject* t3533 = shen_empty_list(ctx);
  KLObject* t3537;
  {
    Vector* caps_9 = shen_vector(ctx, 8);
    shen_vector_set(ctx, caps_9, 0, t3516);
    shen_vector_set(ctx, caps_9, 1, t3517);
    shen_vector_set(ctx, caps_9, 2, t3518);
    shen_vector_set(ctx, caps_9, 3, t3526);
    shen_vector_set(ctx, caps_9, 4, t3519);
    shen_vector_set(ctx, caps_9, 5, t3520);
    shen_vector_set(ctx, caps_9, 6, t3521);
    shen_vector_set(ctx, caps_9, 7, t3522);
    t3537 = shen_native_closure(ctx, 0, &lambda_9, caps_9);
  }
  KLObject* t3531;
  {
    KLObject* a3531[] = {t3526, t3533, t3519, t3520, t3521, t3537};
    t3531 = shen_apply_direct(ctx, "is", 6, a3531);
  }
  KLObject* t3528;
  {
    KLObject* a3528[] = {t3519, t3531};
    t3528 = shen_tail_apply_direct(ctx, "shen.gc", 2, a3528);
  }
    t3523 = t3528;
  } else {
  KLObject* t3555 = shen_false(ctx);
    t3523 = t3555;
  }
    return t3523;
  }
}

static KLObject* native_kl_shen_2efindall_2dh_94 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t3556 = objects[0];
    KLObject* t3557 = objects[1];
    KLObject* t3558 = objects[2];
    KLObject* t3559 = objects[3];
    KLObject* t3560 = objects[4];
    KLObject* t3561 = objects[5];
    KLObject* t3562 = objects[6];
    KLObject* t3563 = objects[7];
  tail_start_kl_shen_2efindall_2dh_94: ;
  KLObject* t3565;
  {
    KLObject* a3565[] = {t3561};
    t3565 = shen_apply_direct(ctx, "shen.unlocked?", 1, a3565);
  }
  KLObject* t3564;
  if (!shen_is_boolean(ctx, t3565))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t3565)) {
  KLObject* t3567 = shen_apply_direct(ctx, "shen.incinfs", 0, NULL);
  KLObject* t3573;
  {
    Vector* caps_10 = shen_vector(ctx, 6);
    shen_vector_set(ctx, caps_10, 0, t3556);
    shen_vector_set(ctx, caps_10, 1, t3559);
    shen_vector_set(ctx, caps_10, 2, t3560);
    shen_vector_set(ctx, caps_10, 3, t3561);
    shen_vector_set(ctx, caps_10, 4, t3562);
    shen_vector_set(ctx, caps_10, 5, t3563);
    t3573 = shen_native_closure(ctx, 0, &lambda_10, caps_10);
  }
  KLObject* t3568;
  {
    KLObject* a3568[] = {t3557, t3560, t3561, t3562, t3573};
    t3568 = shen_apply_direct(ctx, "call", 5, a3568);
  }
    t3564 = t3568;
  } else {
  KLObject* t3587 = shen_false(ctx);
    t3564 = t3587;
  }
  KLObject* t3590 = shen_false(ctx);
  KLObject* t3591 = shen_eq(ctx, t3564, t3590);
  KLObject* t3588;
  if (!shen_is_boolean(ctx, t3591))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t3591)) {
  KLObject* t3593;
  {
    KLObject* a3593[] = {t3561};
    t3593 = shen_apply_direct(ctx, "shen.unlocked?", 1, a3593);
  }
  KLObject* t3592;
  if (!shen_is_boolean(ctx, t3593))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t3593)) {
  KLObject* t3595 = shen_apply_direct(ctx, "shen.incinfs", 0, NULL);
  KLObject* t3596;
  {
    KLObject* a3596[] = {t3558, t3559, t3560, t3561, t3562, t3563};
    t3596 = shen_tail_apply_direct(ctx, "is!", 6, a3596);
  }
    t3592 = t3596;
  } else {
  KLObject* t3603 = shen_false(ctx);
    t3592 = t3603;
  }
    t3588 = t3592;
  } else {
    t3588 = t3564;
  }
    return t3588;
  }
}

static KLObject* native_kl_shen_2eoverbind_95 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t3605 = objects[0];
    KLObject* t3606 = objects[1];
    KLObject* t3607 = objects[2];
    KLObject* t3608 = objects[3];
    KLObject* t3609 = objects[4];
    KLObject* t3610 = objects[5];
  tail_start_kl_shen_2eoverbind_95: ;
  KLObject* t3613;
  {
    KLObject* a3613[] = {t3605, t3607};
    t3613 = shen_apply_direct(ctx, "shen.deref", 2, a3613);
  }
  KLObject* t3616;
  {
    KLObject* a3616[] = {t3606, t3607};
    t3616 = shen_apply_direct(ctx, "shen.lazyderef", 2, a3616);
  }
  KLObject* t3619 = shen_cons(ctx, t3613, t3616);
  KLObject* t3611;
  {
    KLObject* a3611[] = {t3606, t3619, t3607};
    t3611 = shen_apply_direct(ctx, "shen.bindv", 3, a3611);
  }
  KLObject* t3621 = shen_false(ctx);
    return t3621;
  }
}

static KLObject* native_kl_occurs_2dcheck_96 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t3622 = objects[0];
  tail_start_kl_occurs_2dcheck_96: ;
  KLObject* t3623;
  {
  KLObject* t3624 = shen_intern(ctx, "+");
  KLObject* t3626 = shen_eq(ctx, t3624, t3622);
    if (!shen_is_boolean(ctx, t3626))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t3626)) {
  KLObject* t3628 = shen_intern(ctx, "shen.*occurs*");
  KLObject* t3629 = shen_true(ctx);
  KLObject* t3627;
  {
    KLObject* a3627[] = {t3628, t3629};
    t3627 = shen_tail_apply_direct(ctx, "set", 2, a3627);
  }
      t3623 = t3627;
    } else {
  KLObject* t3630 = shen_intern(ctx, "-");
  KLObject* t3632 = shen_eq(ctx, t3630, t3622);
    if (!shen_is_boolean(ctx, t3632))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t3632)) {
  KLObject* t3634 = shen_intern(ctx, "shen.*occurs*");
  KLObject* t3635 = shen_false(ctx);
  KLObject* t3633;
  {
    KLObject* a3633[] = {t3634, t3635};
    t3633 = shen_tail_apply_direct(ctx, "set", 2, a3633);
  }
      t3623 = t3633;
    } else {
  KLObject* t3636 = shen_true(ctx);
    if (!shen_is_boolean(ctx, t3636))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t3636)) {
  KLObject* t3638 = shen_string(ctx, "occurs-check expects a + or a -.\n");
  KLObject* t3637;
  {
    KLObject* a3637[] = {t3638};
    t3637 = shen_tail_apply_direct(ctx, "simple-error", 1, a3637);
  }
      t3623 = t3637;
    } else {
      shen_simple_error(ctx, "No true case found for cond");
      t3623 = shen_empty_list(ctx);
    }
    }
    }
  }
    return t3623;
  }
}

void shen_kernel_aot_install_prolog (shen_context* ctx)
{
  shen_register_defun(ctx, "asserta", 1, &native_kl_asserta_0);
  shen_register_defun(ctx, "assertz", 1, &native_kl_assertz_1);
  shen_register_defun(ctx, "shen.assert*", 2, &native_kl_shen_2eassert_2a_2);
  shen_register_defun(ctx, "shen.predicate", 1, &native_kl_shen_2epredicate_3);
  shen_register_defun(ctx, "shen.terms", 1, &native_kl_shen_2eterms_4);
  shen_register_defun(ctx, "shen.create-skeleton", 2, &native_kl_shen_2ecreate_2dskeleton_5);
  shen_register_defun(ctx, "shen.dynamic-default", 2, &native_kl_shen_2edynamic_2ddefault_6);
  shen_register_defun(ctx, "shen.insert-info", 5, &native_kl_shen_2einsert_2dinfo_7);
  shen_register_defun(ctx, "shen.newname", 0, &native_kl_shen_2enewname_8);
  shen_register_defun(ctx, "shen.call-dynamic", 6, &native_kl_shen_2ecall_2ddynamic_9);
  shen_register_defun(ctx, "shen.callrec", 6, &native_kl_shen_2ecallrec_10);
  shen_register_defun(ctx, "retract", 1, &native_kl_retract_11);
  shen_register_defun(ctx, "shen.retract-clause", 2, &native_kl_shen_2eretract_2dclause_12);
  shen_register_defun(ctx, "shen.compile-prolog", 2, &native_kl_shen_2ecompile_2dprolog_13);
  shen_register_defun(ctx, "shen.<defprolog>", 1, &native_kl_shen_2e_3cdefprolog_3e_14);
  shen_register_defun(ctx, "shen.prolog-arity-check", 2, &native_kl_shen_2eprolog_2darity_2dcheck_15);
  shen_register_defun(ctx, "shen.pac-h", 3, &native_kl_shen_2epac_2dh_16);
  shen_register_defun(ctx, "shen.<clauses>", 1, &native_kl_shen_2e_3cclauses_3e_17);
  shen_register_defun(ctx, "shen.linearise-clause", 1, &native_kl_shen_2elinearise_2dclause_18);
  shen_register_defun(ctx, "shen.lch", 1, &native_kl_shen_2elch_19);
  shen_register_defun(ctx, "shen.lchh", 1, &native_kl_shen_2elchh_20);
  shen_register_defun(ctx, "shen.<clause>", 1, &native_kl_shen_2e_3cclause_3e_21);
  shen_register_defun(ctx, "shen.<head>", 1, &native_kl_shen_2e_3chead_3e_22);
  shen_register_defun(ctx, "shen.<hterm>", 1, &native_kl_shen_2e_3chterm_3e_23);
  shen_register_defun(ctx, "shen.prolog-keyword?", 1, &native_kl_shen_2eprolog_2dkeyword_3f_24);
  shen_register_defun(ctx, "atom?", 1, &native_kl_atom_3f_25);
  shen_register_defun(ctx, "shen.<hterm1>", 1, &native_kl_shen_2e_3chterm1_3e_26);
  shen_register_defun(ctx, "shen.<hterm2>", 1, &native_kl_shen_2e_3chterm2_3e_27);
  shen_register_defun(ctx, "shen.<body>", 1, &native_kl_shen_2e_3cbody_3e_28);
  shen_register_defun(ctx, "shen.<literal>", 1, &native_kl_shen_2e_3cliteral_3e_29);
  shen_register_defun(ctx, "shen.<bterms>", 1, &native_kl_shen_2e_3cbterms_3e_30);
  shen_register_defun(ctx, "shen.<bterm>", 1, &native_kl_shen_2e_3cbterm_3e_31);
  shen_register_defun(ctx, "shen.<wildcard>", 1, &native_kl_shen_2e_3cwildcard_3e_32);
  shen_register_defun(ctx, "shen.<sc>", 1, &native_kl_shen_2e_3csc_3e_33);
  shen_register_defun(ctx, "shen.horn-clause-procedure", 2, &native_kl_shen_2ehorn_2dclause_2dprocedure_34);
  shen_register_defun(ctx, "shen.hascut?", 1, &native_kl_shen_2ehascut_3f_35);
  shen_register_defun(ctx, "shen.prolog-parameters", 1, &native_kl_shen_2eprolog_2dparameters_36);
  shen_register_defun(ctx, "shen.prolog-fbody", 7, &native_kl_shen_2eprolog_2dfbody_37);
  shen_register_defun(ctx, "shen.unlock", 2, &native_kl_shen_2eunlock_38);
  shen_register_defun(ctx, "shen.locked?", 1, &native_kl_shen_2elocked_3f_39);
  shen_register_defun(ctx, "shen.unlocked?", 1, &native_kl_shen_2eunlocked_3f_40);
  shen_register_defun(ctx, "shen.openlock", 1, &native_kl_shen_2eopenlock_41);
  shen_register_defun(ctx, "shen.fits?", 2, &native_kl_shen_2efits_3f_42);
  shen_register_defun(ctx, "shen.cut", 4, &native_kl_shen_2ecut_43);
  shen_register_defun(ctx, "shen.lock", 2, &native_kl_shen_2elock_44);
  shen_register_defun(ctx, "shen.continue", 6, &native_kl_shen_2econtinue_45);
  shen_register_defun(ctx, "shen.extract-free-vars", 1, &native_kl_shen_2eextract_2dfree_2dvars_46);
  shen_register_defun(ctx, "shen.compile-body", 5, &native_kl_shen_2ecompile_2dbody_47);
  shen_register_defun(ctx, "shen.freeze-literals", 5, &native_kl_shen_2efreeze_2dliterals_48);
  shen_register_defun(ctx, "shen.deref-calls", 2, &native_kl_shen_2ederef_2dcalls_49);
  shen_register_defun(ctx, "shen.deref-forked-literals", 2, &native_kl_shen_2ederef_2dforked_2dliterals_50);
  shen_register_defun(ctx, "shen.function-calls", 2, &native_kl_shen_2efunction_2dcalls_51);
  shen_register_defun(ctx, "shen.deref-terms", 3, &native_kl_shen_2ederef_2dterms_52);
  shen_register_defun(ctx, "shen.compile-head", 5, &native_kl_shen_2ecompile_2dhead_53);
  shen_register_defun(ctx, "shen.variable-case", 5, &native_kl_shen_2evariable_2dcase_54);
  shen_register_defun(ctx, "shen.atom-case-minus", 4, &native_kl_shen_2eatom_2dcase_2dminus_55);
  shen_register_defun(ctx, "shen.cons-case-minus", 4, &native_kl_shen_2econs_2dcase_2dminus_56);
  shen_register_defun(ctx, "shen.atom-case-plus", 4, &native_kl_shen_2eatom_2dcase_2dplus_57);
  shen_register_defun(ctx, "shen.cons-case-plus", 4, &native_kl_shen_2econs_2dcase_2dplus_58);
  shen_register_defun(ctx, "shen.demode", 1, &native_kl_shen_2edemode_59);
  shen_register_defun(ctx, "shen.tame", 1, &native_kl_shen_2etame_60);
  shen_register_defun(ctx, "shen.goto", 2, &native_kl_shen_2egoto_61);
  shen_register_defun(ctx, "shen.goto-h", 2, &native_kl_shen_2egoto_2dh_62);
  shen_register_defun(ctx, "shen.invoke", 2, &native_kl_shen_2einvoke_63);
  shen_register_defun(ctx, "shen.wildcard?", 1, &native_kl_shen_2ewildcard_3f_64);
  shen_register_defun(ctx, "shen.pvar?", 1, &native_kl_shen_2epvar_3f_65);
  shen_register_defun(ctx, "shen.lazyderef", 2, &native_kl_shen_2elazyderef_66);
  shen_register_defun(ctx, "shen.deref", 2, &native_kl_shen_2ederef_67);
  shen_register_defun(ctx, "shen.bind!", 4, &native_kl_shen_2ebind_21_68);
  shen_register_defun(ctx, "shen.bindv", 3, &native_kl_shen_2ebindv_69);
  shen_register_defun(ctx, "shen.unwind", 3, &native_kl_shen_2eunwind_70);
  shen_register_defun(ctx, "shen.stpart", 3, &native_kl_shen_2estpart_71);
  shen_register_defun(ctx, "shen.gc", 2, &native_kl_shen_2egc_72);
  shen_register_defun(ctx, "shen.decrement-ticket", 2, &native_kl_shen_2edecrement_2dticket_73);
  shen_register_defun(ctx, "shen.newpv", 1, &native_kl_shen_2enewpv_74);
  shen_register_defun(ctx, "shen.ticket-number", 1, &native_kl_shen_2eticket_2dnumber_75);
  shen_register_defun(ctx, "shen.nextticket", 2, &native_kl_shen_2enextticket_76);
  shen_register_defun(ctx, "shen.make-prolog-variable", 1, &native_kl_shen_2emake_2dprolog_2dvariable_77);
  shen_register_defun(ctx, "shen.pvar", 1, &native_kl_shen_2epvar_78);
  shen_register_defun(ctx, "shen.incinfs", 0, &native_kl_shen_2eincinfs_79);
  shen_register_defun(ctx, "shen.prolog-vector-size", 1, &native_kl_shen_2eprolog_2dvector_2dsize_80);
  shen_register_defun(ctx, "shen.lzy=!", 4, &native_kl_shen_2elzy_3d_21_81);
  shen_register_defun(ctx, "shen.lzy=", 4, &native_kl_shen_2elzy_3d_82);
  shen_register_defun(ctx, "shen.occurs-check?", 2, &native_kl_shen_2eoccurs_2dcheck_3f_83);
  shen_register_defun(ctx, "call", 5, &native_kl_call_84);
  shen_register_defun(ctx, "return", 5, &native_kl_return_85);
  shen_register_defun(ctx, "when", 5, &native_kl_when_86);
  shen_register_defun(ctx, "is", 6, &native_kl_is_87);
  shen_register_defun(ctx, "is!", 6, &native_kl_is_21_88);
  shen_register_defun(ctx, "bind", 6, &native_kl_bind_89);
  shen_register_defun(ctx, "var?", 5, &native_kl_var_3f_90);
  shen_register_defun(ctx, "shen.print-prolog-vector", 1, &native_kl_shen_2eprint_2dprolog_2dvector_91);
  shen_register_defun(ctx, "fork", 5, &native_kl_fork_92);
  shen_register_defun(ctx, "findall", 7, &native_kl_findall_93);
  shen_register_defun(ctx, "shen.findall-h", 8, &native_kl_shen_2efindall_2dh_94);
  shen_register_defun(ctx, "shen.overbind", 6, &native_kl_shen_2eoverbind_95);
  shen_register_defun(ctx, "occurs-check", 1, &native_kl_occurs_2dcheck_96);
}
