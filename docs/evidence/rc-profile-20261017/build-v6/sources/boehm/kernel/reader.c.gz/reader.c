#include "rc_phase_profile.h"
/* Generated always-AOT kernel module (KL defuns -> NativeFunctions).
 * Install after tree-walker boot overwrites UserFunctions.
 * Toplevel declare/set stay on the walker. Not overlay-after-load.
 * Sidecar tests stay on the tree-walker. Not a second main. Source: reader.kl
 */
#include "abi.h"

void shen_kernel_aot_install_reader (shen_context* ctx);

static KLObject* lambda_0 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t8 = objects[0];
  KLObject* t9;
  {
    KLObject* a9[] = {t8};
    t9 = shen_tail_apply_direct(ctx, "shen.<s-exprs>", 1, a9);
  }
    return t9;
  }
}

static KLObject* trap_body_0 (void* data)
{
  shen_context* ctx = &shen_root_context;
  Vector* env = (Vector*)data;
  KLObject* t4 = shen_vector_get(ctx, env, 0);
  KLObject* t5 = shen_vector_get(ctx, env, 1);
  KLObject* t7;
  {
    Vector* caps_0 = shen_vector(ctx, 0);
    t7 = shen_native_closure(ctx, 1, &lambda_0, caps_0);
  }
  KLObject* t6;
  {
    KLObject* a6[] = {t7, t5};
    t6 = shen_apply_direct(ctx, "compile", 2, a6);
  }
  return t6;
}

static KLObject* lambda_1 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t15 = objects[0];
  KLObject* t18 = shen_intern(ctx, "shen.*residue*");
  KLObject* t17;
  {
    KLObject* a17[] = {t18};
    t17 = shen_apply_direct(ctx, "value", 1, a17);
  }
  KLObject* t16;
  {
    KLObject* a16[] = {t17};
    t16 = shen_tail_apply_direct(ctx, "shen.reader-error", 1, a16);
  }
    return t16;
  }
}

static KLObject* trap_handler_0 (KLObject* exception, void* data)
{
  shen_context* ctx = &shen_root_context;
  Vector* env = (Vector*)data;
  Vector* args;
  KLObject* t12 = shen_vector_get(ctx, env, 0);
  KLObject* t13 = shen_vector_get(ctx, env, 1);
  KLObject* t14;
  {
    Vector* caps_1 = shen_vector(ctx, 0);
    t14 = shen_native_closure(ctx, 1, &lambda_1, caps_1);
  }
  args = shen_vector(ctx, 1);
  shen_vector_set(ctx, args, 0, exception);
  {
    KLObject* t19 = shen_apply(ctx, t14, args);
    return t19;
  }
}

static KLObject* lambda_2 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t157 = objects[0];
  KLObject* t158;
  {
    KLObject* a158[] = {t157};
    t158 = shen_tail_apply_direct(ctx, "shen.monotype", 1, a158);
  }
    return t158;
  }
}

static KLObject* lambda_3 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t180 = objects[0];
  KLObject* t181;
  {
    KLObject* a181[] = {t180};
    t181 = shen_tail_apply_direct(ctx, "shen.return?", 1, a181);
  }
    return t181;
  }
}

static KLObject* lambda_4 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t188 = objects[0];
  KLObject* t189;
  {
    KLObject* a189[] = {t188};
    t189 = shen_tail_apply_direct(ctx, "shen.<s-exprs>", 1, a189);
  }
    return t189;
  }
}

static KLObject* lambda_5 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t200 = objects[0];
  KLObject* t201;
  {
    KLObject* a201[] = {t200};
    t201 = shen_tail_apply_direct(ctx, "shen.<s-exprs>", 1, a201);
  }
    return t201;
  }
}

static KLObject* lambda_6 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t230 = objects[0];
  KLObject* t231;
  {
    KLObject* a231[] = {t230};
    t231 = shen_tail_apply_direct(ctx, "shen.whitespace?", 1, a231);
  }
    return t231;
  }
}

static KLObject* lambda_7 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t263 = objects[0];
  KLObject* t264;
  {
    KLObject* a264[] = {t263};
    t264 = shen_tail_apply_direct(ctx, "shen.<s-exprs>", 1, a264);
  }
    return t264;
  }
}

static KLObject* lambda_8 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t314 = objects[0];
  KLObject* t315;
  {
    KLObject* a315[] = {t314};
    t315 = shen_tail_apply_direct(ctx, "shen.<s-exprs>", 1, a315);
  }
    return t315;
  }
}

static KLObject* trap_body_1 (void* data)
{
  shen_context* ctx = &shen_root_context;
  Vector* env = (Vector*)data;
  KLObject* t311 = shen_vector_get(ctx, env, 0);
  KLObject* t313;
  {
    Vector* caps_8 = shen_vector(ctx, 0);
    t313 = shen_native_closure(ctx, 1, &lambda_8, caps_8);
  }
  KLObject* t312;
  {
    KLObject* a312[] = {t313, t311};
    t312 = shen_apply_direct(ctx, "compile", 2, a312);
  }
  return t312;
}

static KLObject* lambda_9 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t320 = objects[0];
  KLObject* t321 = shen_intern(ctx, "shen.i-failed!");
    return t321;
  }
}

static KLObject* trap_handler_1 (KLObject* exception, void* data)
{
  shen_context* ctx = &shen_root_context;
  Vector* env = (Vector*)data;
  Vector* args;
  KLObject* t318 = shen_vector_get(ctx, env, 0);
  KLObject* t319;
  {
    Vector* caps_9 = shen_vector(ctx, 0);
    t319 = shen_native_closure(ctx, 1, &lambda_9, caps_9);
  }
  args = shen_vector(ctx, 1);
  shen_vector_set(ctx, args, 0, exception);
  {
    KLObject* t322 = shen_apply(ctx, t319, args);
    return t322;
  }
}

static KLObject* lambda_10 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  KLObject* t373 = shen_vector_get(ctx, caps, 0);
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t374 = objects[0];
  KLObject* t375;
  {
    KLObject* a375[] = {t374, t373};
    t375 = shen_tail_apply_direct(ctx, "shen.process-applications", 2, a375);
  }
    return t375;
  }
}

static KLObject* lambda_11 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t477 = objects[0];
  KLObject* t478;
  {
    KLObject* a478[] = {t477};
    t478 = shen_tail_apply_direct(ctx, "shen.find-arities", 1, a478);
  }
    return t478;
  }
}

static KLObject* trap_body_2 (void* data)
{
  shen_context* ctx = &shen_root_context;
  Vector* env = (Vector*)data;
  KLObject* t3118 = shen_vector_get(ctx, env, 0);
  KLObject* t3119 = shen_vector_get(ctx, env, 1);
  KLObject* t3120 = shen_vector_get(ctx, env, 2);
  KLObject* t3123 = shen_intern(ctx, "shen.internal-symbols");
  KLObject* t3125 = shen_intern(ctx, "*property-vector*");
  KLObject* t3124;
  {
    KLObject* a3124[] = {t3125};
    t3124 = shen_apply_direct(ctx, "value", 1, a3124);
  }
  KLObject* t3121;
  {
    KLObject* a3121[] = {t3118, t3123, t3124};
    t3121 = shen_apply_direct(ctx, "get", 3, a3121);
  }
  return t3121;
}

static KLObject* lambda_12 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t3130 = objects[0];
  KLObject* t3131 = shen_empty_list(ctx);
    return t3131;
  }
}

static KLObject* trap_handler_2 (KLObject* exception, void* data)
{
  shen_context* ctx = &shen_root_context;
  Vector* env = (Vector*)data;
  Vector* args;
  KLObject* t3126 = shen_vector_get(ctx, env, 0);
  KLObject* t3127 = shen_vector_get(ctx, env, 1);
  KLObject* t3128 = shen_vector_get(ctx, env, 2);
  KLObject* t3129;
  {
    Vector* caps_12 = shen_vector(ctx, 0);
    t3129 = shen_native_closure(ctx, 1, &lambda_12, caps_12);
  }
  args = shen_vector(ctx, 1);
  shen_vector_set(ctx, args, 0, exception);
  {
    KLObject* t3132 = shen_apply(ctx, t3129, args);
    return t3132;
  }
}

static KLObject* trap_body_3 (void* data)
{
  shen_context* ctx = &shen_root_context;
  Vector* env = (Vector*)data;
  KLObject* t3177 = shen_vector_get(ctx, env, 0);
  KLObject* t3178 = shen_vector_get(ctx, env, 1);
  KLObject* t3181 = shen_intern(ctx, "shen.external-symbols");
  KLObject* t3183 = shen_intern(ctx, "*property-vector*");
  KLObject* t3182;
  {
    KLObject* a3182[] = {t3183};
    t3182 = shen_apply_direct(ctx, "value", 1, a3182);
  }
  KLObject* t3179;
  {
    KLObject* a3179[] = {t3177, t3181, t3182};
    t3179 = shen_apply_direct(ctx, "get", 3, a3179);
  }
  return t3179;
}

static KLObject* lambda_13 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t3187 = objects[0];
  KLObject* t3188 = shen_empty_list(ctx);
    return t3188;
  }
}

static KLObject* trap_handler_3 (KLObject* exception, void* data)
{
  shen_context* ctx = &shen_root_context;
  Vector* env = (Vector*)data;
  Vector* args;
  KLObject* t3184 = shen_vector_get(ctx, env, 0);
  KLObject* t3185 = shen_vector_get(ctx, env, 1);
  KLObject* t3186;
  {
    Vector* caps_13 = shen_vector(ctx, 0);
    t3186 = shen_native_closure(ctx, 1, &lambda_13, caps_13);
  }
  args = shen_vector(ctx, 1);
  shen_vector_set(ctx, args, 0, exception);
  {
    KLObject* t3189 = shen_apply(ctx, t3186, args);
    return t3189;
  }
}

static KLObject* lambda_14 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  KLObject* t3206 = shen_vector_get(ctx, caps, 0);
  KLObject* t3207 = shen_vector_get(ctx, caps, 1);
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t3208 = objects[0];
  KLObject* t3209;
  {
    KLObject* a3209[] = {t3206, t3207, t3208};
    t3209 = shen_tail_apply_direct(ctx, "shen.package-symbols", 3, a3209);
  }
    return t3209;
  }
}

static KLObject* lambda_15 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  KLObject* t3397 = shen_vector_get(ctx, caps, 0);
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t3398 = objects[0];
  KLObject* t3399;
  {
    KLObject* a3399[] = {t3398, t3397};
    t3399 = shen_tail_apply_direct(ctx, "shen.process-applications", 2, a3399);
  }
    return t3399;
  }
}

static KLObject* lambda_16 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  KLObject* t3629 = shen_vector_get(ctx, caps, 0);
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t3630 = objects[0];
  KLObject* t3631;
  {
    KLObject* a3631[] = {t3630, t3629};
    t3631 = shen_tail_apply_direct(ctx, "shen.process-applications", 2, a3631);
  }
    return t3631;
  }
}

static KLObject* lambda_17 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  KLObject* t3734 = shen_vector_get(ctx, caps, 0);
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t3735 = objects[0];
  KLObject* t3736;
  {
    KLObject* a3736[] = {t3735, t3734};
    t3736 = shen_tail_apply_direct(ctx, "shen.process-applications", 2, a3736);
  }
    return t3736;
  }
}

static KLObject* lambda_18 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  KLObject* t3766 = shen_vector_get(ctx, caps, 0);
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t3767 = objects[0];
  KLObject* t3768;
  {
    KLObject* a3768[] = {t3767, t3766};
    t3768 = shen_tail_apply_direct(ctx, "shen.process-applications", 2, a3768);
  }
    return t3768;
  }
}

static KLObject* native_kl_read_2dfile_0 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t0 = objects[0];
  tail_start_kl_read_2dfile_0: ;
  KLObject* t1;
  {
    KLObject* a1[] = {t0};
    t1 = shen_apply_direct(ctx, "read-file-as-bytelist", 1, a1);
  }
  KLObject* t3;
  {
    Vector* tenv_0 = shen_vector(ctx, 2);
    shen_vector_set(ctx, tenv_0, 0, t0);
    shen_vector_set(ctx, tenv_0, 1, t1);
    t3 = shen_trap_error(ctx, trap_body_0, trap_handler_0, tenv_0);
  }
  KLObject* t20;
  {
    KLObject* a20[] = {t3};
    t20 = shen_apply_direct(ctx, "shen.process-sexprs", 1, a20);
  }
    return t20;
  }
}

static KLObject* native_kl_shen_2ereader_2derror_1 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t23 = objects[0];
  tail_start_kl_shen_2ereader_2derror_1: ;
  KLObject* t27 = shen_string(ctx, "reader error near here: ");
  KLObject* t30 = shen_intern(ctx, "*maximum-print-sequence-size*");
  KLObject* t29;
  {
    KLObject* a29[] = {t30};
    t29 = shen_apply_direct(ctx, "value", 1, a29);
  }
  KLObject* t31 = shen_number_l(ctx, 0);
  KLObject* t28;
  {
    KLObject* a28[] = {t29, t31, t23};
    t28 = shen_apply_direct(ctx, "shen.reader-error-message", 3, a28);
  }
  KLObject* t26;
  {
    KLObject* a26[] = {t27, t28};
    t26 = shen_apply_direct(ctx, "cn", 2, a26);
  }
  KLObject* t25;
  {
    KLObject* a25[] = {t26};
    t25 = shen_apply_direct(ctx, "shen.proc-nl", 1, a25);
  }
  KLObject* t24;
  {
    KLObject* a24[] = {t25};
    t24 = shen_tail_apply_direct(ctx, "simple-error", 1, a24);
  }
    return t24;
  }
}

static KLObject* native_kl_shen_2ereader_2derror_2dmessage_2 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t33 = objects[0];
    KLObject* t34 = objects[1];
    KLObject* t35 = objects[2];
  tail_start_kl_shen_2ereader_2derror_2dmessage_2: ;
  KLObject* t36;
  {
  KLObject* t37 = shen_empty_list(ctx);
  KLObject* t39 = shen_eq(ctx, t37, t35);
    if (!shen_is_boolean(ctx, t39))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t39)) {
  KLObject* t40 = shen_string(ctx, "");
      t36 = t40;
    } else {
  KLObject* t43 = shen_eq(ctx, t33, t34);
    if (!shen_is_boolean(ctx, t43))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t43)) {
  KLObject* t44 = shen_string(ctx, "");
      t36 = t44;
    } else {
  KLObject* t46 = shen_cons_p(ctx, t35);
    if (!shen_is_boolean(ctx, t46))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t46)) {
  KLObject* t50 = shen_hd(ctx, t35);
  KLObject* t48;
  {
    KLObject* a48[] = {t50};
    t48 = shen_apply_direct(ctx, "n->string", 1, a48);
  }
  KLObject* t54 = shen_number_l(ctx, 1);
  KLObject* t55 = shen_add(ctx, t34, t54);
  KLObject* t57 = shen_tl(ctx, t35);
  KLObject* t51;
  {
    KLObject* a51[] = {t33, t55, t57};
    t51 = shen_apply_direct(ctx, "shen.reader-error-message", 3, a51);
  }
  KLObject* t47;
  {
    KLObject* a47[] = {t48, t51};
    t47 = shen_tail_apply_direct(ctx, "cn", 2, a47);
  }
      t36 = t47;
    } else {
  KLObject* t58 = shen_true(ctx);
    if (!shen_is_boolean(ctx, t58))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t58)) {
  KLObject* t60 = shen_string(ctx, "partial function shen.reader-error-message");
  KLObject* t59;
  {
    KLObject* a59[] = {t60};
    t59 = shen_tail_apply_direct(ctx, "simple-error", 1, a59);
  }
      t36 = t59;
    } else {
      shen_simple_error(ctx, "No true case found for cond");
      t36 = shen_empty_list(ctx);
    }
    }
    }
    }
  }
    return t36;
  }
}

static KLObject* native_kl_it_3 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  (void)function_object;
  (void)arguments;
  {
  tail_start_kl_it_3: ;
  KLObject* t62 = shen_intern(ctx, "shen.*it*");
  KLObject* t61;
  {
    KLObject* a61[] = {t62};
    t61 = shen_tail_apply_direct(ctx, "value", 1, a61);
  }
    return t61;
  }
}

static KLObject* native_kl_read_2dfile_2das_2dbytelist_4 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t63 = objects[0];
  tail_start_kl_read_2dfile_2das_2dbytelist_4: ;
  KLObject* t66 = shen_intern(ctx, "in");
  KLObject* t64;
  {
    KLObject* a64[] = {t63, t66};
    t64 = shen_apply_direct(ctx, "open", 2, a64);
  }
  KLObject* t67;
  {
    KLObject* a67[] = {t64};
    t67 = shen_apply_direct(ctx, "read-byte", 1, a67);
  }
  KLObject* t72 = shen_empty_list(ctx);
  KLObject* t69;
  {
    KLObject* a69[] = {t64, t67, t72};
    t69 = shen_apply_direct(ctx, "shen.read-file-as-bytelist-help", 3, a69);
  }
  KLObject* t73;
  {
    KLObject* a73[] = {t64};
    t73 = shen_apply_direct(ctx, "close", 1, a73);
  }
  KLObject* t75;
  {
    KLObject* a75[] = {t69};
    t75 = shen_tail_apply_direct(ctx, "reverse", 1, a75);
  }
    return t75;
  }
}

static KLObject* native_kl_shen_2eread_2dfile_2das_2dbytelist_2dhelp_5 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t77 = objects[0];
    KLObject* t78 = objects[1];
    KLObject* t79 = objects[2];
  tail_start_kl_shen_2eread_2dfile_2das_2dbytelist_2dhelp_5: ;
  KLObject* t80;
  {
  KLObject* t81 = shen_number_l(ctx, -1);
  KLObject* t83 = shen_eq(ctx, t81, t78);
    if (!shen_is_boolean(ctx, t83))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t83)) {
      t80 = t79;
    } else {
  KLObject* t85 = shen_true(ctx);
    if (!shen_is_boolean(ctx, t85))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t85)) {
  KLObject* t87;
  {
    KLObject* a87[] = {t77};
    t87 = shen_apply_direct(ctx, "read-byte", 1, a87);
  }
  KLObject* t91 = shen_cons(ctx, t78, t79);
  {
    KLObject* n92_0 = t77;
    KLObject* n92_1 = t87;
    KLObject* n92_2 = t91;
    t77 = n92_0;
    t78 = n92_1;
    t79 = n92_2;
    goto tail_start_kl_shen_2eread_2dfile_2das_2dbytelist_2dhelp_5;
  }
  KLObject* t92 = NULL;
      t80 = t92;
    } else {
      shen_simple_error(ctx, "No true case found for cond");
      t80 = shen_empty_list(ctx);
    }
    }
  }
    return t80;
  }
}

static KLObject* native_kl_read_2dfile_2das_2dstring_6 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t93 = objects[0];
  tail_start_kl_read_2dfile_2das_2dstring_6: ;
  KLObject* t96 = shen_intern(ctx, "in");
  KLObject* t94;
  {
    KLObject* a94[] = {t93, t96};
    t94 = shen_apply_direct(ctx, "open", 2, a94);
  }
  KLObject* t99;
  {
    KLObject* a99[] = {t94};
    t99 = shen_apply_direct(ctx, "read-byte", 1, a99);
  }
  KLObject* t101 = shen_string(ctx, "");
  KLObject* t97;
  {
    KLObject* a97[] = {t94, t99, t101};
    t97 = shen_tail_apply_direct(ctx, "shen.rfas-h", 3, a97);
  }
    return t97;
  }
}

static KLObject* native_kl_shen_2erfas_2dh_7 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t102 = objects[0];
    KLObject* t103 = objects[1];
    KLObject* t104 = objects[2];
  tail_start_kl_shen_2erfas_2dh_7: ;
  KLObject* t105;
  {
  KLObject* t106 = shen_number_l(ctx, -1);
  KLObject* t108 = shen_eq(ctx, t106, t103);
    if (!shen_is_boolean(ctx, t108))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t108)) {
  KLObject* t109;
  {
    KLObject* a109[] = {t102};
    t109 = shen_apply_direct(ctx, "close", 1, a109);
  }
      t105 = t104;
    } else {
  KLObject* t112 = shen_true(ctx);
    if (!shen_is_boolean(ctx, t112))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t112)) {
  KLObject* t114;
  {
    KLObject* a114[] = {t102};
    t114 = shen_apply_direct(ctx, "read-byte", 1, a114);
  }
  KLObject* t118;
  {
    KLObject* a118[] = {t103};
    t118 = shen_apply_direct(ctx, "n->string", 1, a118);
  }
  KLObject* t116;
  {
    KLObject* a116[] = {t104, t118};
    t116 = shen_apply_direct(ctx, "cn", 2, a116);
  }
  {
    KLObject* n120_0 = t102;
    KLObject* n120_1 = t114;
    KLObject* n120_2 = t116;
    t102 = n120_0;
    t103 = n120_1;
    t104 = n120_2;
    goto tail_start_kl_shen_2erfas_2dh_7;
  }
  KLObject* t120 = NULL;
      t105 = t120;
    } else {
      shen_simple_error(ctx, "No true case found for cond");
      t105 = shen_empty_list(ctx);
    }
    }
  }
    return t105;
  }
}

static KLObject* native_kl_input_8 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t121 = objects[0];
  tail_start_kl_input_8: ;
  KLObject* t122;
  {
    KLObject* a122[] = {t121};
    t122 = shen_apply_direct(ctx, "read", 1, a122);
  }
  KLObject* t124 = shen_eval_kl(ctx, t122);
    return t124;
  }
}

static KLObject* native_kl_shen_2einput_2dh_2b_9 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t125 = objects[0];
    KLObject* t126 = objects[1];
  tail_start_kl_shen_2einput_2dh_2b_9: ;
  KLObject* t127;
  {
    KLObject* a127[] = {t125};
    t127 = shen_apply_direct(ctx, "shen.monotype", 1, a127);
  }
  KLObject* t129;
  {
    KLObject* a129[] = {t126};
    t129 = shen_apply_direct(ctx, "read", 1, a129);
  }
  KLObject* t132 = shen_false(ctx);
  KLObject* t133;
  {
    KLObject* a133[] = {t129, t125};
    t133 = sp_boehm_phase_2(ctx, "shen.typecheck", 2, a133);
  }
  KLObject* t136 = shen_eq(ctx, t132, t133);
  KLObject* t131;
  if (!shen_is_boolean(ctx, t136))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t136)) {
  KLObject* t139 = shen_string(ctx, "type error: ");
  KLObject* t143 = shen_string(ctx, " is not of type ");
  KLObject* t146 = shen_string(ctx, "\n");
  KLObject* t147 = shen_intern(ctx, "shen.r");
  KLObject* t144;
  {
    KLObject* a144[] = {t125, t146, t147};
    t144 = shen_apply_direct(ctx, "shen.app", 3, a144);
  }
  KLObject* t142;
  {
    KLObject* a142[] = {t143, t144};
    t142 = shen_apply_direct(ctx, "cn", 2, a142);
  }
  KLObject* t148 = shen_intern(ctx, "shen.r");
  KLObject* t140;
  {
    KLObject* a140[] = {t129, t142, t148};
    t140 = shen_apply_direct(ctx, "shen.app", 3, a140);
  }
  KLObject* t138;
  {
    KLObject* a138[] = {t139, t140};
    t138 = shen_apply_direct(ctx, "cn", 2, a138);
  }
  KLObject* t137;
  {
    KLObject* a137[] = {t138};
    t137 = shen_tail_apply_direct(ctx, "simple-error", 1, a137);
  }
    t131 = t137;
  } else {
  KLObject* t150 = shen_eval_kl(ctx, t129);
    t131 = t150;
  }
    return t131;
  }
}

static KLObject* native_kl_shen_2emonotype_10 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t151 = objects[0];
  tail_start_kl_shen_2emonotype_10: ;
  KLObject* t152;
  {
  KLObject* t154 = shen_cons_p(ctx, t151);
    if (!shen_is_boolean(ctx, t154))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t154)) {
  KLObject* t156;
  {
    Vector* caps_2 = shen_vector(ctx, 0);
    t156 = shen_native_closure(ctx, 1, &lambda_2, caps_2);
  }
  KLObject* t155;
  {
    KLObject* a155[] = {t156, t151};
    t155 = shen_tail_apply_direct(ctx, "map", 2, a155);
  }
      t152 = t155;
    } else {
  KLObject* t161 = shen_true(ctx);
    if (!shen_is_boolean(ctx, t161))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t161)) {
  KLObject* t163;
  {
    KLObject* a163[] = {t151};
    t163 = shen_apply_direct(ctx, "variable?", 1, a163);
  }
  KLObject* t162;
  if (!shen_is_boolean(ctx, t163))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t163)) {
  KLObject* t167 = shen_string(ctx, "input+ expects a monotype: not ");
  KLObject* t170 = shen_string(ctx, "\n");
  KLObject* t171 = shen_intern(ctx, "shen.a");
  KLObject* t168;
  {
    KLObject* a168[] = {t151, t170, t171};
    t168 = shen_apply_direct(ctx, "shen.app", 3, a168);
  }
  KLObject* t166;
  {
    KLObject* a166[] = {t167, t168};
    t166 = shen_apply_direct(ctx, "cn", 2, a166);
  }
  KLObject* t165;
  {
    KLObject* a165[] = {t166};
    t165 = shen_tail_apply_direct(ctx, "simple-error", 1, a165);
  }
    t162 = t165;
  } else {
    t162 = t151;
  }
      t152 = t162;
    } else {
      shen_simple_error(ctx, "No true case found for cond");
      t152 = shen_empty_list(ctx);
    }
    }
  }
    return t152;
  }
}

static KLObject* native_kl_lineread_11 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t173 = objects[0];
  tail_start_kl_lineread_11: ;
  KLObject* t176;
  {
    KLObject* a176[] = {t173};
    t176 = shen_apply_direct(ctx, "shen.my-read-byte", 1, a176);
  }
  KLObject* t178 = shen_empty_list(ctx);
  KLObject* t179;
  {
    Vector* caps_3 = shen_vector(ctx, 0);
    t179 = shen_native_closure(ctx, 1, &lambda_3, caps_3);
  }
  KLObject* t174;
  {
    KLObject* a174[] = {t173, t176, t178, t179};
    t174 = shen_tail_apply_direct(ctx, "shen.read-loop", 4, a174);
  }
    return t174;
  }
}

static KLObject* native_kl_read_2dfrom_2dstring_12 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t183 = objects[0];
  tail_start_kl_read_2dfrom_2dstring_12: ;
  KLObject* t184;
  {
    KLObject* a184[] = {t183};
    t184 = shen_apply_direct(ctx, "shen.str->bytes", 1, a184);
  }
  KLObject* t187;
  {
    Vector* caps_4 = shen_vector(ctx, 0);
    t187 = shen_native_closure(ctx, 1, &lambda_4, caps_4);
  }
  KLObject* t186;
  {
    KLObject* a186[] = {t187, t184};
    t186 = shen_apply_direct(ctx, "compile", 2, a186);
  }
  KLObject* t192;
  {
    KLObject* a192[] = {t186};
    t192 = shen_apply_direct(ctx, "shen.process-sexprs", 1, a192);
  }
    return t192;
  }
}

static KLObject* native_kl_read_2dfrom_2dstring_2dunprocessed_13 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t195 = objects[0];
  tail_start_kl_read_2dfrom_2dstring_2dunprocessed_13: ;
  KLObject* t196;
  {
    KLObject* a196[] = {t195};
    t196 = shen_apply_direct(ctx, "shen.str->bytes", 1, a196);
  }
  KLObject* t199;
  {
    Vector* caps_5 = shen_vector(ctx, 0);
    t199 = shen_native_closure(ctx, 1, &lambda_5, caps_5);
  }
  KLObject* t198;
  {
    KLObject* a198[] = {t199, t196};
    t198 = shen_apply_direct(ctx, "compile", 2, a198);
  }
    return t198;
  }
}

static KLObject* native_kl_shen_2estr_2d_3ebytes_14 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t205 = objects[0];
  tail_start_kl_shen_2estr_2d_3ebytes_14: ;
  KLObject* t206;
  {
  KLObject* t207 = shen_string(ctx, "");
  KLObject* t209 = shen_eq(ctx, t207, t205);
    if (!shen_is_boolean(ctx, t209))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t209)) {
  KLObject* t210 = shen_empty_list(ctx);
      t206 = t210;
    } else {
  KLObject* t211;
  {
    KLObject* a211[] = {t205};
    t211 = shen_apply_direct(ctx, "shen.+string?", 1, a211);
  }
    if (!shen_is_boolean(ctx, t211))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t211)) {
  KLObject* t214;
  {
    KLObject* a214[] = {t205};
    t214 = shen_apply_direct(ctx, "hdstr", 1, a214);
  }
  KLObject* t213;
  {
    KLObject* a213[] = {t214};
    t213 = shen_apply_direct(ctx, "string->n", 1, a213);
  }
  KLObject* t217;
  {
    KLObject* a217[] = {t205};
    t217 = shen_apply_direct(ctx, "tlstr", 1, a217);
  }
  KLObject* t216;
  {
    KLObject* a216[] = {t217};
    t216 = shen_apply_direct(ctx, "shen.str->bytes", 1, a216);
  }
  KLObject* t219 = shen_cons(ctx, t213, t216);
      t206 = t219;
    } else {
  KLObject* t220 = shen_true(ctx);
    if (!shen_is_boolean(ctx, t220))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t220)) {
  KLObject* t222 = shen_string(ctx, "partial function shen.str->bytes");
  KLObject* t221;
  {
    KLObject* a221[] = {t222};
    t221 = shen_tail_apply_direct(ctx, "simple-error", 1, a221);
  }
      t206 = t221;
    } else {
      shen_simple_error(ctx, "No true case found for cond");
      t206 = shen_empty_list(ctx);
    }
    }
    }
  }
    return t206;
  }
}

static KLObject* native_kl_read_15 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t223 = objects[0];
  tail_start_kl_read_15: ;
  KLObject* t226;
  {
    KLObject* a226[] = {t223};
    t226 = shen_apply_direct(ctx, "shen.my-read-byte", 1, a226);
  }
  KLObject* t228 = shen_empty_list(ctx);
  KLObject* t229;
  {
    Vector* caps_6 = shen_vector(ctx, 0);
    t229 = shen_native_closure(ctx, 1, &lambda_6, caps_6);
  }
  KLObject* t224;
  {
    KLObject* a224[] = {t223, t226, t228, t229};
    t224 = shen_apply_direct(ctx, "shen.read-loop", 4, a224);
  }
  KLObject* t233 = shen_hd(ctx, t224);
    return t233;
  }
}

static KLObject* native_kl_shen_2emy_2dread_2dbyte_16 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t234 = objects[0];
  tail_start_kl_shen_2emy_2dread_2dbyte_16: ;
  KLObject* t236;
  {
    KLObject* a236[] = {t234};
    t236 = shen_apply_direct(ctx, "char-stream?", 1, a236);
  }
  KLObject* t235;
  if (!shen_is_boolean(ctx, t236))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t236)) {
  KLObject* t239;
  {
    KLObject* a239[] = {t234};
    t239 = shen_apply_direct(ctx, "read-unit-string", 1, a239);
  }
  KLObject* t238;
  {
    KLObject* a238[] = {t239};
    t238 = shen_tail_apply_direct(ctx, "string->n", 1, a238);
  }
    t235 = t238;
  } else {
  KLObject* t241;
  {
    KLObject* a241[] = {t234};
    t241 = shen_tail_apply_direct(ctx, "read-byte", 1, a241);
  }
    t235 = t241;
  }
    return t235;
  }
}

static KLObject* native_kl_shen_2eread_2dloop_17 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t243 = objects[0];
    KLObject* t244 = objects[1];
    KLObject* t245 = objects[2];
    KLObject* t246 = objects[3];
  tail_start_kl_shen_2eread_2dloop_17: ;
  KLObject* t247;
  {
  KLObject* t248 = shen_number_l(ctx, 94);
  KLObject* t250 = shen_eq(ctx, t248, t244);
    if (!shen_is_boolean(ctx, t250))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t250)) {
  KLObject* t252 = shen_string(ctx, "read aborted");
  KLObject* t251;
  {
    KLObject* a251[] = {t252};
    t251 = shen_tail_apply_direct(ctx, "simple-error", 1, a251);
  }
      t247 = t251;
    } else {
  KLObject* t253 = shen_number_l(ctx, -1);
  KLObject* t255 = shen_eq(ctx, t253, t244);
    if (!shen_is_boolean(ctx, t255))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t255)) {
  KLObject* t257;
  {
    KLObject* a257[] = {t245};
    t257 = shen_apply_direct(ctx, "empty?", 1, a257);
  }
  KLObject* t256;
  if (!shen_is_boolean(ctx, t257))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t257)) {
  KLObject* t260 = shen_string(ctx, "error: empty stream");
  KLObject* t259;
  {
    KLObject* a259[] = {t260};
    t259 = shen_tail_apply_direct(ctx, "simple-error", 1, a259);
  }
    t256 = t259;
  } else {
  KLObject* t262;
  {
    Vector* caps_7 = shen_vector(ctx, 0);
    t262 = shen_native_closure(ctx, 1, &lambda_7, caps_7);
  }
  KLObject* t261;
  {
    KLObject* a261[] = {t262, t245};
    t261 = shen_tail_apply_direct(ctx, "compile", 2, a261);
  }
    t256 = t261;
  }
      t247 = t256;
    } else {
  KLObject* t267 = shen_number_l(ctx, 0);
  KLObject* t269 = shen_eq(ctx, t267, t244);
    if (!shen_is_boolean(ctx, t269))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t269)) {
  KLObject* t271;
  {
    KLObject* a271[] = {t243};
    t271 = shen_apply_direct(ctx, "shen.my-read-byte", 1, a271);
  }
  {
    KLObject* n275_0 = t243;
    KLObject* n275_1 = t271;
    KLObject* n275_2 = t245;
    KLObject* n275_3 = t246;
    t243 = n275_0;
    t244 = n275_1;
    t245 = n275_2;
    t246 = n275_3;
    goto tail_start_kl_shen_2eread_2dloop_17;
  }
  KLObject* t275 = NULL;
      t247 = t275;
    } else {
  KLObject* t276 = shen_true(ctx);
    if (!shen_is_boolean(ctx, t276))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t276)) {
  KLObject* t278;
  {
    Vector* a278 = shen_vector(ctx, 1);
    shen_vector_set(ctx, a278, 0, t244);
    t278 = shen_apply(ctx, t246, a278);
  }
  KLObject* t277;
  if (!shen_is_boolean(ctx, t278))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t278)) {
  KLObject* t281;
  {
    KLObject* a281[] = {t245};
    t281 = shen_apply_direct(ctx, "shen.try-parse", 1, a281);
  }
  KLObject* t284;
  {
    KLObject* a284[] = {t281};
    t284 = shen_apply_direct(ctx, "shen.nothing-doing?", 1, a284);
  }
  KLObject* t283;
  if (!shen_is_boolean(ctx, t284))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t284)) {
  KLObject* t287;
  {
    KLObject* a287[] = {t243};
    t287 = shen_apply_direct(ctx, "shen.my-read-byte", 1, a287);
  }
  KLObject* t292 = shen_empty_list(ctx);
  KLObject* t293 = shen_cons(ctx, t244, t292);
  KLObject* t289;
  {
    KLObject* a289[] = {t245, t293};
    t289 = shen_apply_direct(ctx, "append", 2, a289);
  }
  {
    KLObject* n295_0 = t243;
    KLObject* n295_1 = t287;
    KLObject* n295_2 = t289;
    KLObject* n295_3 = t246;
    t243 = n295_0;
    t244 = n295_1;
    t245 = n295_2;
    t246 = n295_3;
    goto tail_start_kl_shen_2eread_2dloop_17;
  }
  KLObject* t295 = NULL;
    t283 = t295;
  } else {
  KLObject* t296;
  {
    KLObject* a296[] = {t245};
    t296 = shen_apply_direct(ctx, "shen.record-it", 1, a296);
  }
    t283 = t281;
  }
    t277 = t283;
  } else {
  KLObject* t300;
  {
    KLObject* a300[] = {t243};
    t300 = shen_apply_direct(ctx, "shen.my-read-byte", 1, a300);
  }
  KLObject* t305 = shen_empty_list(ctx);
  KLObject* t306 = shen_cons(ctx, t244, t305);
  KLObject* t302;
  {
    KLObject* a302[] = {t245, t306};
    t302 = shen_apply_direct(ctx, "append", 2, a302);
  }
  {
    KLObject* n308_0 = t243;
    KLObject* n308_1 = t300;
    KLObject* n308_2 = t302;
    KLObject* n308_3 = t246;
    t243 = n308_0;
    t244 = n308_1;
    t245 = n308_2;
    t246 = n308_3;
    goto tail_start_kl_shen_2eread_2dloop_17;
  }
  KLObject* t308 = NULL;
    t277 = t308;
  }
      t247 = t277;
    } else {
      shen_simple_error(ctx, "No true case found for cond");
      t247 = shen_empty_list(ctx);
    }
    }
    }
    }
  }
    return t247;
  }
}

static KLObject* native_kl_shen_2etry_2dparse_18 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t309 = objects[0];
  tail_start_kl_shen_2etry_2dparse_18: ;
  KLObject* t310;
  {
    Vector* tenv_1 = shen_vector(ctx, 1);
    shen_vector_set(ctx, tenv_1, 0, t309);
    t310 = shen_trap_error(ctx, trap_body_1, trap_handler_1, tenv_1);
  }
  KLObject* t324;
  {
    KLObject* a324[] = {t310};
    t324 = shen_apply_direct(ctx, "shen.nothing-doing?", 1, a324);
  }
  KLObject* t323;
  if (!shen_is_boolean(ctx, t324))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t324)) {
  KLObject* t326 = shen_intern(ctx, "shen.i-failed!");
    t323 = t326;
  } else {
  KLObject* t327;
  {
    KLObject* a327[] = {t310};
    t327 = shen_tail_apply_direct(ctx, "shen.process-sexprs", 1, a327);
  }
    t323 = t327;
  }
    return t323;
  }
}

static KLObject* native_kl_shen_2enothing_2ddoing_3f_19 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t329 = objects[0];
  tail_start_kl_shen_2enothing_2ddoing_3f_19: ;
  KLObject* t330;
  {
  KLObject* t331 = shen_intern(ctx, "shen.i-failed!");
  KLObject* t333 = shen_eq(ctx, t331, t329);
    if (!shen_is_boolean(ctx, t333))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t333)) {
  KLObject* t334 = shen_true(ctx);
      t330 = t334;
    } else {
  KLObject* t335 = shen_empty_list(ctx);
  KLObject* t337 = shen_eq(ctx, t335, t329);
    if (!shen_is_boolean(ctx, t337))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t337)) {
  KLObject* t338 = shen_true(ctx);
      t330 = t338;
    } else {
  KLObject* t339 = shen_true(ctx);
    if (!shen_is_boolean(ctx, t339))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t339)) {
  KLObject* t340 = shen_false(ctx);
      t330 = t340;
    } else {
      shen_simple_error(ctx, "No true case found for cond");
      t330 = shen_empty_list(ctx);
    }
    }
    }
  }
    return t330;
  }
}

static KLObject* native_kl_shen_2erecord_2dit_20 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t341 = objects[0];
  tail_start_kl_shen_2erecord_2dit_20: ;
  KLObject* t343 = shen_intern(ctx, "shen.*it*");
  KLObject* t344;
  {
    KLObject* a344[] = {t341};
    t344 = shen_apply_direct(ctx, "shen.bytes->string", 1, a344);
  }
  KLObject* t342;
  {
    KLObject* a342[] = {t343, t344};
    t342 = shen_tail_apply_direct(ctx, "set", 2, a342);
  }
    return t342;
  }
}

static KLObject* native_kl_shen_2ebytes_2d_3estring_21 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t346 = objects[0];
  tail_start_kl_shen_2ebytes_2d_3estring_21: ;
  KLObject* t347;
  {
  KLObject* t348 = shen_empty_list(ctx);
  KLObject* t350 = shen_eq(ctx, t348, t346);
    if (!shen_is_boolean(ctx, t350))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t350)) {
  KLObject* t351 = shen_string(ctx, "");
      t347 = t351;
    } else {
  KLObject* t353 = shen_cons_p(ctx, t346);
    if (!shen_is_boolean(ctx, t353))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t353)) {
  KLObject* t357 = shen_hd(ctx, t346);
  KLObject* t355;
  {
    KLObject* a355[] = {t357};
    t355 = shen_apply_direct(ctx, "n->string", 1, a355);
  }
  KLObject* t360 = shen_tl(ctx, t346);
  KLObject* t358;
  {
    KLObject* a358[] = {t360};
    t358 = shen_apply_direct(ctx, "shen.bytes->string", 1, a358);
  }
  KLObject* t354;
  {
    KLObject* a354[] = {t355, t358};
    t354 = shen_tail_apply_direct(ctx, "cn", 2, a354);
  }
      t347 = t354;
    } else {
  KLObject* t361 = shen_true(ctx);
    if (!shen_is_boolean(ctx, t361))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t361)) {
  KLObject* t363 = shen_string(ctx, "partial function shen.bytes->string");
  KLObject* t362;
  {
    KLObject* a362[] = {t363};
    t362 = shen_tail_apply_direct(ctx, "simple-error", 1, a362);
  }
      t347 = t362;
    } else {
      shen_simple_error(ctx, "No true case found for cond");
      t347 = shen_empty_list(ctx);
    }
    }
    }
  }
    return t347;
  }
}

static KLObject* native_kl_shen_2eprocess_2dsexprs_22 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t364 = objects[0];
  tail_start_kl_shen_2eprocess_2dsexprs_22: ;
  KLObject* t365;
  {
    KLObject* a365[] = {t364};
    t365 = shen_apply_direct(ctx, "shen.unpackage&macroexpand", 1, a365);
  }
  KLObject* t367;
  {
    KLObject* a367[] = {t365};
    t367 = shen_apply_direct(ctx, "shen.find-arities", 1, a367);
  }
  KLObject* t369;
  {
    KLObject* a369[] = {t365};
    t369 = shen_apply_direct(ctx, "shen.find-types", 1, a369);
  }
  KLObject* t372;
  {
    Vector* caps_10 = shen_vector(ctx, 1);
    shen_vector_set(ctx, caps_10, 0, t369);
    t372 = shen_native_closure(ctx, 1, &lambda_10, caps_10);
  }
  KLObject* t371;
  {
    KLObject* a371[] = {t372, t365};
    t371 = shen_tail_apply_direct(ctx, "map", 2, a371);
  }
    return t371;
  }
}

static KLObject* native_kl_shen_2efind_2dtypes_23 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t379 = objects[0];
  tail_start_kl_shen_2efind_2dtypes_23: ;
  KLObject* t380;
  {
  KLObject* t383 = shen_cons_p(ctx, t379);
  KLObject* t381;
  if (!shen_is_boolean(ctx, t383))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t383)) {
    t381 = t383;
  } else {
  KLObject* t386 = shen_tl(ctx, t379);
  KLObject* t387 = shen_cons_p(ctx, t386);
  KLObject* t384;
  if (!shen_is_boolean(ctx, t387))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t387)) {
    t384 = t387;
  } else {
  KLObject* t389 = shen_hd(ctx, t379);
  KLObject* t391 = shen_string(ctx, ":");
  KLObject* t390;
  {
    KLObject* a390[] = {t391};
    t390 = shen_apply_direct(ctx, "intern", 1, a390);
  }
  KLObject* t392 = shen_eq(ctx, t389, t390);
    if (!shen_is_boolean(ctx, t392))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t384 = t392;
  }
    if (!shen_is_boolean(ctx, t384))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t381 = t384;
  }
    if (!shen_is_boolean(ctx, t381))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t381)) {
  KLObject* t394 = shen_tl(ctx, t379);
  KLObject* t395 = shen_hd(ctx, t394);
  KLObject* t398 = shen_tl(ctx, t379);
  KLObject* t399 = shen_tl(ctx, t398);
  KLObject* t396;
  {
    KLObject* a396[] = {t399};
    t396 = shen_apply_direct(ctx, "shen.find-types", 1, a396);
  }
  KLObject* t400 = shen_cons(ctx, t395, t396);
      t380 = t400;
    } else {
  KLObject* t402 = shen_cons_p(ctx, t379);
    if (!shen_is_boolean(ctx, t402))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t402)) {
  KLObject* t406 = shen_hd(ctx, t379);
  KLObject* t404;
  {
    KLObject* a404[] = {t406};
    t404 = shen_apply_direct(ctx, "shen.find-types", 1, a404);
  }
  KLObject* t409 = shen_tl(ctx, t379);
  KLObject* t407;
  {
    KLObject* a407[] = {t409};
    t407 = shen_apply_direct(ctx, "shen.find-types", 1, a407);
  }
  KLObject* t403;
  {
    KLObject* a403[] = {t404, t407};
    t403 = shen_tail_apply_direct(ctx, "append", 2, a403);
  }
      t380 = t403;
    } else {
  KLObject* t410 = shen_true(ctx);
    if (!shen_is_boolean(ctx, t410))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t410)) {
  KLObject* t411 = shen_empty_list(ctx);
      t380 = t411;
    } else {
      shen_simple_error(ctx, "No true case found for cond");
      t380 = shen_empty_list(ctx);
    }
    }
    }
  }
    return t380;
  }
}

static KLObject* native_kl_shen_2efind_2darities_24 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t412 = objects[0];
  tail_start_kl_shen_2efind_2darities_24: ;
  KLObject* t413;
  {
  KLObject* t416 = shen_cons_p(ctx, t412);
  KLObject* t414;
  if (!shen_is_boolean(ctx, t416))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t416)) {
    t414 = t416;
  } else {
  KLObject* t418 = shen_intern(ctx, "define");
  KLObject* t420 = shen_hd(ctx, t412);
  KLObject* t421 = shen_eq(ctx, t418, t420);
  KLObject* t417;
  if (!shen_is_boolean(ctx, t421))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t421)) {
    t417 = t421;
  } else {
  KLObject* t424 = shen_tl(ctx, t412);
  KLObject* t425 = shen_cons_p(ctx, t424);
  KLObject* t422;
  if (!shen_is_boolean(ctx, t425))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t425)) {
    t422 = t425;
  } else {
  KLObject* t428 = shen_tl(ctx, t412);
  KLObject* t429 = shen_tl(ctx, t428);
  KLObject* t430 = shen_cons_p(ctx, t429);
  KLObject* t426;
  if (!shen_is_boolean(ctx, t430))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t430)) {
    t426 = t430;
  } else {
  KLObject* t431 = shen_intern(ctx, "{");
  KLObject* t433 = shen_tl(ctx, t412);
  KLObject* t434 = shen_tl(ctx, t433);
  KLObject* t435 = shen_hd(ctx, t434);
  KLObject* t436 = shen_eq(ctx, t431, t435);
    if (!shen_is_boolean(ctx, t436))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t426 = t436;
  }
    if (!shen_is_boolean(ctx, t426))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t422 = t426;
  }
    if (!shen_is_boolean(ctx, t422))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t417 = t422;
  }
    if (!shen_is_boolean(ctx, t417))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t414 = t417;
  }
    if (!shen_is_boolean(ctx, t414))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t414)) {
  KLObject* t439 = shen_tl(ctx, t412);
  KLObject* t440 = shen_hd(ctx, t439);
  KLObject* t443 = shen_tl(ctx, t412);
  KLObject* t444 = shen_hd(ctx, t443);
  KLObject* t445 = shen_number_l(ctx, 1);
  KLObject* t447 = shen_tl(ctx, t412);
  KLObject* t448 = shen_tl(ctx, t447);
  KLObject* t449 = shen_tl(ctx, t448);
  KLObject* t441;
  {
    KLObject* a441[] = {t444, t445, t449};
    t441 = shen_apply_direct(ctx, "shen.find-arity", 3, a441);
  }
  KLObject* t437;
  {
    KLObject* a437[] = {t440, t441};
    t437 = shen_tail_apply_direct(ctx, "shen.store-arity", 2, a437);
  }
      t413 = t437;
    } else {
  KLObject* t452 = shen_cons_p(ctx, t412);
  KLObject* t450;
  if (!shen_is_boolean(ctx, t452))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t452)) {
    t450 = t452;
  } else {
  KLObject* t454 = shen_intern(ctx, "define");
  KLObject* t456 = shen_hd(ctx, t412);
  KLObject* t457 = shen_eq(ctx, t454, t456);
  KLObject* t453;
  if (!shen_is_boolean(ctx, t457))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t457)) {
    t453 = t457;
  } else {
  KLObject* t459 = shen_tl(ctx, t412);
  KLObject* t460 = shen_cons_p(ctx, t459);
    if (!shen_is_boolean(ctx, t460))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t453 = t460;
  }
    if (!shen_is_boolean(ctx, t453))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t450 = t453;
  }
    if (!shen_is_boolean(ctx, t450))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t450)) {
  KLObject* t463 = shen_tl(ctx, t412);
  KLObject* t464 = shen_hd(ctx, t463);
  KLObject* t467 = shen_tl(ctx, t412);
  KLObject* t468 = shen_hd(ctx, t467);
  KLObject* t469 = shen_number_l(ctx, 0);
  KLObject* t471 = shen_tl(ctx, t412);
  KLObject* t472 = shen_tl(ctx, t471);
  KLObject* t465;
  {
    KLObject* a465[] = {t468, t469, t472};
    t465 = shen_apply_direct(ctx, "shen.find-arity", 3, a465);
  }
  KLObject* t461;
  {
    KLObject* a461[] = {t464, t465};
    t461 = shen_tail_apply_direct(ctx, "shen.store-arity", 2, a461);
  }
      t413 = t461;
    } else {
  KLObject* t474 = shen_cons_p(ctx, t412);
    if (!shen_is_boolean(ctx, t474))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t474)) {
  KLObject* t476;
  {
    Vector* caps_11 = shen_vector(ctx, 0);
    t476 = shen_native_closure(ctx, 1, &lambda_11, caps_11);
  }
  KLObject* t475;
  {
    KLObject* a475[] = {t476, t412};
    t475 = shen_tail_apply_direct(ctx, "map", 2, a475);
  }
      t413 = t475;
    } else {
  KLObject* t481 = shen_true(ctx);
    if (!shen_is_boolean(ctx, t481))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t481)) {
  KLObject* t482 = shen_intern(ctx, "shen.skip");
      t413 = t482;
    } else {
      shen_simple_error(ctx, "No true case found for cond");
      t413 = shen_empty_list(ctx);
    }
    }
    }
    }
  }
    return t413;
  }
}

static KLObject* native_kl_shen_2estore_2darity_25 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t483 = objects[0];
    KLObject* t484 = objects[1];
  tail_start_kl_shen_2estore_2darity_25: ;
  KLObject* t485;
  {
    KLObject* a485[] = {t483};
    t485 = shen_apply_direct(ctx, "arity", 1, a485);
  }
  KLObject* t489 = shen_number_l(ctx, -1);
  KLObject* t490 = shen_eq(ctx, t485, t489);
  KLObject* t487;
  if (!shen_is_boolean(ctx, t490))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t490)) {
  KLObject* t491;
  {
    KLObject* a491[] = {t483, t484};
    t491 = shen_tail_apply_direct(ctx, "shen.execute-store-arity", 2, a491);
  }
    t487 = t491;
  } else {
  KLObject* t497 = shen_eq(ctx, t485, t484);
  KLObject* t494;
  if (!shen_is_boolean(ctx, t497))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t497)) {
  KLObject* t498 = shen_intern(ctx, "shen.skip");
    t494 = t498;
  } else {
  KLObject* t500;
  {
    KLObject* a500[] = {t483};
    t500 = shen_apply_direct(ctx, "shen.sysfunc?", 1, a500);
  }
  KLObject* t499;
  if (!shen_is_boolean(ctx, t500))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t500)) {
  KLObject* t505 = shen_string(ctx, " is a system function\n");
  KLObject* t506 = shen_intern(ctx, "shen.a");
  KLObject* t503;
  {
    KLObject* a503[] = {t483, t505, t506};
    t503 = shen_apply_direct(ctx, "shen.app", 3, a503);
  }
  KLObject* t502;
  {
    KLObject* a502[] = {t503};
    t502 = shen_tail_apply_direct(ctx, "simple-error", 1, a502);
  }
    t499 = t502;
  } else {
  KLObject* t509 = shen_string(ctx, "changing the arity of ");
  KLObject* t512 = shen_string(ctx, " may cause errors\n");
  KLObject* t513 = shen_intern(ctx, "shen.a");
  KLObject* t510;
  {
    KLObject* a510[] = {t483, t512, t513};
    t510 = shen_apply_direct(ctx, "shen.app", 3, a510);
  }
  KLObject* t508;
  {
    KLObject* a508[] = {t509, t510};
    t508 = shen_apply_direct(ctx, "cn", 2, a508);
  }
  KLObject* t514 = shen_apply_direct(ctx, "stoutput", 0, NULL);
  KLObject* t507;
  {
    KLObject* a507[] = {t508, t514};
    t507 = shen_apply_direct(ctx, "pr", 2, a507);
  }
  KLObject* t515;
  {
    KLObject* a515[] = {t483, t484};
    t515 = shen_tail_apply_direct(ctx, "shen.execute-store-arity", 2, a515);
  }
    t499 = t515;
  }
    t494 = t499;
  }
    t487 = t494;
  }
    return t487;
  }
}

static KLObject* native_kl_shen_2eexecute_2dstore_2darity_26 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t518 = objects[0];
    KLObject* t519 = objects[1];
  tail_start_kl_shen_2eexecute_2dstore_2darity_26: ;
  KLObject* t520;
  {
  KLObject* t521 = shen_number_l(ctx, 0);
  KLObject* t523 = shen_eq(ctx, t521, t519);
    if (!shen_is_boolean(ctx, t523))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t523)) {
  KLObject* t526 = shen_intern(ctx, "arity");
  KLObject* t527 = shen_number_l(ctx, 0);
  KLObject* t529 = shen_intern(ctx, "*property-vector*");
  KLObject* t528;
  {
    KLObject* a528[] = {t529};
    t528 = shen_apply_direct(ctx, "value", 1, a528);
  }
  KLObject* t524;
  {
    KLObject* a524[] = {t518, t526, t527, t528};
    t524 = shen_tail_apply_direct(ctx, "put", 4, a524);
  }
      t520 = t524;
    } else {
  KLObject* t530 = shen_true(ctx);
    if (!shen_is_boolean(ctx, t530))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t530)) {
  KLObject* t533 = shen_intern(ctx, "arity");
  KLObject* t536 = shen_intern(ctx, "*property-vector*");
  KLObject* t535;
  {
    KLObject* a535[] = {t536};
    t535 = shen_apply_direct(ctx, "value", 1, a535);
  }
  KLObject* t531;
  {
    KLObject* a531[] = {t518, t533, t519, t535};
    t531 = shen_apply_direct(ctx, "put", 4, a531);
  }
  KLObject* t537;
  {
    KLObject* a537[] = {t518, t519};
    t537 = shen_tail_apply_direct(ctx, "shen.update-lambdatable", 2, a537);
  }
      t520 = t537;
    } else {
      shen_simple_error(ctx, "No true case found for cond");
      t520 = shen_empty_list(ctx);
    }
    }
  }
    return t520;
  }
}

static KLObject* native_kl_shen_2eupdate_2dlambdatable_27 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t540 = objects[0];
    KLObject* t541 = objects[1];
  tail_start_kl_shen_2eupdate_2dlambdatable_27: ;
  KLObject* t543 = shen_intern(ctx, "shen.*lambdatable*");
  KLObject* t542;
  {
    KLObject* a542[] = {t543};
    t542 = shen_apply_direct(ctx, "value", 1, a542);
  }
  KLObject* t546 = shen_empty_list(ctx);
  KLObject* t547 = shen_cons(ctx, t540, t546);
  KLObject* t544;
  {
    KLObject* a544[] = {t547, t541};
    t544 = shen_apply_direct(ctx, "shen.lambda-function", 2, a544);
  }
  KLObject* t549 = shen_eval_kl(ctx, t544);
  KLObject* t550;
  {
    KLObject* a550[] = {t540, t549, t542};
    t550 = shen_apply_direct(ctx, "shen.assoc->", 3, a550);
  }
  KLObject* t555 = shen_intern(ctx, "shen.*lambdatable*");
  KLObject* t554;
  {
    KLObject* a554[] = {t555, t550};
    t554 = shen_apply_direct(ctx, "set", 2, a554);
  }
    return t554;
  }
}

static KLObject* native_kl_shen_2elambda_2dfunction_28 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t558 = objects[0];
    KLObject* t559 = objects[1];
  tail_start_kl_shen_2elambda_2dfunction_28: ;
  KLObject* t560;
  {
  KLObject* t561 = shen_number_l(ctx, 0);
  KLObject* t563 = shen_eq(ctx, t561, t559);
    if (!shen_is_boolean(ctx, t563))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t563)) {
  KLObject* t564 = shen_intern(ctx, "shen.skip");
      t560 = t564;
    } else {
  KLObject* t565 = shen_number_l(ctx, 1);
  KLObject* t567 = shen_eq(ctx, t565, t559);
    if (!shen_is_boolean(ctx, t567))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t567)) {
  KLObject* t569 = shen_intern(ctx, "Y");
  KLObject* t568;
  {
    KLObject* a568[] = {t569};
    t568 = shen_apply_direct(ctx, "gensym", 1, a568);
  }
  KLObject* t570 = shen_intern(ctx, "lambda");
  KLObject* t575 = shen_empty_list(ctx);
  KLObject* t576 = shen_cons(ctx, t568, t575);
  KLObject* t572;
  {
    KLObject* a572[] = {t558, t576};
    t572 = shen_apply_direct(ctx, "append", 2, a572);
  }
  KLObject* t577 = shen_empty_list(ctx);
  KLObject* t578 = shen_cons(ctx, t572, t577);
  KLObject* t579 = shen_cons(ctx, t568, t578);
  KLObject* t580 = shen_cons(ctx, t570, t579);
      t560 = t580;
    } else {
  KLObject* t581 = shen_true(ctx);
    if (!shen_is_boolean(ctx, t581))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t581)) {
  KLObject* t583 = shen_intern(ctx, "Y");
  KLObject* t582;
  {
    KLObject* a582[] = {t583};
    t582 = shen_apply_direct(ctx, "gensym", 1, a582);
  }
  KLObject* t584 = shen_intern(ctx, "lambda");
  KLObject* t590 = shen_empty_list(ctx);
  KLObject* t591 = shen_cons(ctx, t582, t590);
  KLObject* t587;
  {
    KLObject* a587[] = {t558, t591};
    t587 = shen_apply_direct(ctx, "append", 2, a587);
  }
  KLObject* t593 = shen_number_l(ctx, 1);
  KLObject* t594 = shen_sub(ctx, t559, t593);
  KLObject* t586;
  {
    KLObject* a586[] = {t587, t594};
    t586 = shen_apply_direct(ctx, "shen.lambda-function", 2, a586);
  }
  KLObject* t595 = shen_empty_list(ctx);
  KLObject* t596 = shen_cons(ctx, t586, t595);
  KLObject* t597 = shen_cons(ctx, t582, t596);
  KLObject* t598 = shen_cons(ctx, t584, t597);
      t560 = t598;
    } else {
      shen_simple_error(ctx, "No true case found for cond");
      t560 = shen_empty_list(ctx);
    }
    }
    }
  }
    return t560;
  }
}

static KLObject* native_kl_shen_2eassoc_2d_3e_29 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t599 = objects[0];
    KLObject* t600 = objects[1];
    KLObject* t601 = objects[2];
  tail_start_kl_shen_2eassoc_2d_3e_29: ;
  KLObject* t602;
  {
  KLObject* t603 = shen_empty_list(ctx);
  KLObject* t605 = shen_eq(ctx, t603, t601);
    if (!shen_is_boolean(ctx, t605))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t605)) {
  KLObject* t608 = shen_cons(ctx, t599, t600);
  KLObject* t609 = shen_empty_list(ctx);
  KLObject* t610 = shen_cons(ctx, t608, t609);
      t602 = t610;
    } else {
  KLObject* t613 = shen_cons_p(ctx, t601);
  KLObject* t611;
  if (!shen_is_boolean(ctx, t613))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t613)) {
    t611 = t613;
  } else {
  KLObject* t616 = shen_hd(ctx, t601);
  KLObject* t617 = shen_cons_p(ctx, t616);
  KLObject* t614;
  if (!shen_is_boolean(ctx, t617))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t617)) {
    t614 = t617;
  } else {
  KLObject* t620 = shen_hd(ctx, t601);
  KLObject* t621 = shen_hd(ctx, t620);
  KLObject* t622 = shen_eq(ctx, t599, t621);
    if (!shen_is_boolean(ctx, t622))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t614 = t622;
  }
    if (!shen_is_boolean(ctx, t614))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t611 = t614;
  }
    if (!shen_is_boolean(ctx, t611))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t611)) {
  KLObject* t624 = shen_hd(ctx, t601);
  KLObject* t625 = shen_hd(ctx, t624);
  KLObject* t627 = shen_cons(ctx, t625, t600);
  KLObject* t629 = shen_tl(ctx, t601);
  KLObject* t630 = shen_cons(ctx, t627, t629);
      t602 = t630;
    } else {
  KLObject* t632 = shen_cons_p(ctx, t601);
    if (!shen_is_boolean(ctx, t632))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t632)) {
  KLObject* t634 = shen_hd(ctx, t601);
  KLObject* t639 = shen_tl(ctx, t601);
  KLObject* t635;
  {
    KLObject* a635[] = {t599, t600, t639};
    t635 = shen_apply_direct(ctx, "shen.assoc->", 3, a635);
  }
  KLObject* t640 = shen_cons(ctx, t634, t635);
      t602 = t640;
    } else {
  KLObject* t641 = shen_true(ctx);
    if (!shen_is_boolean(ctx, t641))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t641)) {
  KLObject* t643 = shen_string(ctx, "implementation error in shen.assoc->");
  KLObject* t642;
  {
    KLObject* a642[] = {t643};
    t642 = shen_tail_apply_direct(ctx, "simple-error", 1, a642);
  }
      t602 = t642;
    } else {
      shen_simple_error(ctx, "No true case found for cond");
      t602 = shen_empty_list(ctx);
    }
    }
    }
    }
  }
    return t602;
  }
}

static KLObject* native_kl_shen_2efind_2darity_30 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t644 = objects[0];
    KLObject* t645 = objects[1];
    KLObject* t646 = objects[2];
  tail_start_kl_shen_2efind_2darity_30: ;
  KLObject* t647;
  {
  KLObject* t649 = shen_number_l(ctx, 0);
  KLObject* t651 = shen_eq(ctx, t649, t645);
  KLObject* t648;
  if (!shen_is_boolean(ctx, t651))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t651)) {
    t648 = t651;
  } else {
  KLObject* t654 = shen_cons_p(ctx, t646);
  KLObject* t652;
  if (!shen_is_boolean(ctx, t654))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t654)) {
    t652 = t654;
  } else {
  KLObject* t656 = shen_hd(ctx, t646);
  KLObject* t657 = shen_intern(ctx, "->");
  KLObject* t658 = shen_eq(ctx, t656, t657);
    if (!shen_is_boolean(ctx, t658))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t652 = t658;
  }
    if (!shen_is_boolean(ctx, t652))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t648 = t652;
  }
    if (!shen_is_boolean(ctx, t648))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t648)) {
  KLObject* t659 = shen_number_l(ctx, 0);
      t647 = t659;
    } else {
  KLObject* t661 = shen_number_l(ctx, 0);
  KLObject* t663 = shen_eq(ctx, t661, t645);
  KLObject* t660;
  if (!shen_is_boolean(ctx, t663))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t663)) {
    t660 = t663;
  } else {
  KLObject* t666 = shen_cons_p(ctx, t646);
  KLObject* t664;
  if (!shen_is_boolean(ctx, t666))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t666)) {
    t664 = t666;
  } else {
  KLObject* t668 = shen_hd(ctx, t646);
  KLObject* t669 = shen_intern(ctx, "<-");
  KLObject* t670 = shen_eq(ctx, t668, t669);
    if (!shen_is_boolean(ctx, t670))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t664 = t670;
  }
    if (!shen_is_boolean(ctx, t664))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t660 = t664;
  }
    if (!shen_is_boolean(ctx, t660))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t660)) {
  KLObject* t671 = shen_number_l(ctx, 0);
      t647 = t671;
    } else {
  KLObject* t673 = shen_number_l(ctx, 0);
  KLObject* t675 = shen_eq(ctx, t673, t645);
  KLObject* t672;
  if (!shen_is_boolean(ctx, t675))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t675)) {
    t672 = t675;
  } else {
  KLObject* t677 = shen_cons_p(ctx, t646);
    if (!shen_is_boolean(ctx, t677))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t672 = t677;
  }
    if (!shen_is_boolean(ctx, t672))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t672)) {
  KLObject* t678 = shen_number_l(ctx, 1);
  KLObject* t681 = shen_number_l(ctx, 0);
  KLObject* t683 = shen_tl(ctx, t646);
  KLObject* t679;
  {
    KLObject* a679[] = {t644, t681, t683};
    t679 = shen_apply_direct(ctx, "shen.find-arity", 3, a679);
  }
  KLObject* t684 = shen_add(ctx, t678, t679);
      t647 = t684;
    } else {
  KLObject* t686 = shen_number_l(ctx, 1);
  KLObject* t688 = shen_eq(ctx, t686, t645);
  KLObject* t685;
  if (!shen_is_boolean(ctx, t688))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t688)) {
    t685 = t688;
  } else {
  KLObject* t691 = shen_cons_p(ctx, t646);
  KLObject* t689;
  if (!shen_is_boolean(ctx, t691))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t691)) {
    t689 = t691;
  } else {
  KLObject* t692 = shen_intern(ctx, "}");
  KLObject* t694 = shen_hd(ctx, t646);
  KLObject* t695 = shen_eq(ctx, t692, t694);
    if (!shen_is_boolean(ctx, t695))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t689 = t695;
  }
    if (!shen_is_boolean(ctx, t689))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t685 = t689;
  }
    if (!shen_is_boolean(ctx, t685))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t685)) {
  KLObject* t697 = shen_number_l(ctx, 0);
  KLObject* t699 = shen_tl(ctx, t646);
  {
    KLObject* n700_0 = t644;
    KLObject* n700_1 = t697;
    KLObject* n700_2 = t699;
    t644 = n700_0;
    t645 = n700_1;
    t646 = n700_2;
    goto tail_start_kl_shen_2efind_2darity_30;
  }
  KLObject* t700 = NULL;
      t647 = t700;
    } else {
  KLObject* t702 = shen_number_l(ctx, 1);
  KLObject* t704 = shen_eq(ctx, t702, t645);
  KLObject* t701;
  if (!shen_is_boolean(ctx, t704))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t704)) {
    t701 = t704;
  } else {
  KLObject* t706 = shen_cons_p(ctx, t646);
    if (!shen_is_boolean(ctx, t706))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t701 = t706;
  }
    if (!shen_is_boolean(ctx, t701))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t701)) {
  KLObject* t708 = shen_number_l(ctx, 1);
  KLObject* t710 = shen_tl(ctx, t646);
  {
    KLObject* n711_0 = t644;
    KLObject* n711_1 = t708;
    KLObject* n711_2 = t710;
    t644 = n711_0;
    t645 = n711_1;
    t646 = n711_2;
    goto tail_start_kl_shen_2efind_2darity_30;
  }
  KLObject* t711 = NULL;
      t647 = t711;
    } else {
  KLObject* t712 = shen_number_l(ctx, 1);
  KLObject* t714 = shen_eq(ctx, t712, t645);
    if (!shen_is_boolean(ctx, t714))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t714)) {
  KLObject* t717 = shen_string(ctx, "syntax error in ");
  KLObject* t720 = shen_string(ctx, " definition: missing }\n");
  KLObject* t721 = shen_intern(ctx, "shen.a");
  KLObject* t718;
  {
    KLObject* a718[] = {t644, t720, t721};
    t718 = shen_apply_direct(ctx, "shen.app", 3, a718);
  }
  KLObject* t716;
  {
    KLObject* a716[] = {t717, t718};
    t716 = shen_apply_direct(ctx, "cn", 2, a716);
  }
  KLObject* t715;
  {
    KLObject* a715[] = {t716};
    t715 = shen_tail_apply_direct(ctx, "simple-error", 1, a715);
  }
      t647 = t715;
    } else {
  KLObject* t722 = shen_true(ctx);
    if (!shen_is_boolean(ctx, t722))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t722)) {
  KLObject* t725 = shen_string(ctx, "syntax error in ");
  KLObject* t728 = shen_string(ctx, " definition: missing -> or <-\n");
  KLObject* t729 = shen_intern(ctx, "shen.a");
  KLObject* t726;
  {
    KLObject* a726[] = {t644, t728, t729};
    t726 = shen_apply_direct(ctx, "shen.app", 3, a726);
  }
  KLObject* t724;
  {
    KLObject* a724[] = {t725, t726};
    t724 = shen_apply_direct(ctx, "cn", 2, a724);
  }
  KLObject* t723;
  {
    KLObject* a723[] = {t724};
    t723 = shen_tail_apply_direct(ctx, "simple-error", 1, a723);
  }
      t647 = t723;
    } else {
      shen_simple_error(ctx, "No true case found for cond");
      t647 = shen_empty_list(ctx);
    }
    }
    }
    }
    }
    }
    }
  }
    return t647;
  }
}

static KLObject* native_kl_shen_2e_3cs_2dexprs_3e_31 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t730 = objects[0];
  tail_start_kl_shen_2e_3cs_2dexprs_3e_31: ;
  KLObject* t731;
  {
    KLObject* a731[] = {t730};
    t731 = shen_apply_direct(ctx, "shen.<lsb>", 1, a731);
  }
  KLObject* t734;
  {
    KLObject* a734[] = {t731};
    t734 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a734);
  }
  KLObject* t733;
  if (!shen_is_boolean(ctx, t734))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t734)) {
  KLObject* t736 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t733 = t736;
  } else {
  KLObject* t737;
  {
    KLObject* a737[] = {t731};
    t737 = shen_apply_direct(ctx, "shen.in->", 1, a737);
  }
  KLObject* t739;
  {
    KLObject* a739[] = {t737};
    t739 = shen_apply_direct(ctx, "shen.<s-exprs1>", 1, a739);
  }
  KLObject* t742;
  {
    KLObject* a742[] = {t739};
    t742 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a742);
  }
  KLObject* t741;
  if (!shen_is_boolean(ctx, t742))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t742)) {
  KLObject* t744 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t741 = t744;
  } else {
  KLObject* t745;
  {
    KLObject* a745[] = {t739};
    t745 = shen_apply_direct(ctx, "shen.<-out", 1, a745);
  }
  KLObject* t747;
  {
    KLObject* a747[] = {t739};
    t747 = shen_apply_direct(ctx, "shen.in->", 1, a747);
  }
  KLObject* t749;
  {
    KLObject* a749[] = {t747};
    t749 = shen_apply_direct(ctx, "shen.<rsb>", 1, a749);
  }
  KLObject* t752;
  {
    KLObject* a752[] = {t749};
    t752 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a752);
  }
  KLObject* t751;
  if (!shen_is_boolean(ctx, t752))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t752)) {
  KLObject* t754 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t751 = t754;
  } else {
  KLObject* t755;
  {
    KLObject* a755[] = {t749};
    t755 = shen_apply_direct(ctx, "shen.in->", 1, a755);
  }
  KLObject* t757;
  {
    KLObject* a757[] = {t755};
    t757 = shen_apply_direct(ctx, "shen.<s-exprs2>", 1, a757);
  }
  KLObject* t760;
  {
    KLObject* a760[] = {t757};
    t760 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a760);
  }
  KLObject* t759;
  if (!shen_is_boolean(ctx, t760))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t760)) {
  KLObject* t762 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t759 = t762;
  } else {
  KLObject* t763;
  {
    KLObject* a763[] = {t757};
    t763 = shen_apply_direct(ctx, "shen.<-out", 1, a763);
  }
  KLObject* t765;
  {
    KLObject* a765[] = {t757};
    t765 = shen_apply_direct(ctx, "shen.in->", 1, a765);
  }
  KLObject* t769;
  {
    KLObject* a769[] = {t745};
    t769 = shen_apply_direct(ctx, "shen.cons-form", 1, a769);
  }
  KLObject* t772 = shen_cons(ctx, t769, t763);
  KLObject* t767;
  {
    KLObject* a767[] = {t765, t772};
    t767 = shen_apply_direct(ctx, "shen.comb", 2, a767);
  }
    t759 = t767;
  }
    t751 = t759;
  }
    t741 = t751;
  }
    t733 = t741;
  }
  KLObject* t774;
  {
    KLObject* a774[] = {t733};
    t774 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a774);
  }
  KLObject* t773;
  if (!shen_is_boolean(ctx, t774))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t774)) {
  KLObject* t776;
  {
    KLObject* a776[] = {t730};
    t776 = shen_apply_direct(ctx, "shen.<lrb>", 1, a776);
  }
  KLObject* t779;
  {
    KLObject* a779[] = {t776};
    t779 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a779);
  }
  KLObject* t778;
  if (!shen_is_boolean(ctx, t779))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t779)) {
  KLObject* t781 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t778 = t781;
  } else {
  KLObject* t782;
  {
    KLObject* a782[] = {t776};
    t782 = shen_apply_direct(ctx, "shen.in->", 1, a782);
  }
  KLObject* t784;
  {
    KLObject* a784[] = {t782};
    t784 = shen_apply_direct(ctx, "shen.<s-exprs1>", 1, a784);
  }
  KLObject* t787;
  {
    KLObject* a787[] = {t784};
    t787 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a787);
  }
  KLObject* t786;
  if (!shen_is_boolean(ctx, t787))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t787)) {
  KLObject* t789 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t786 = t789;
  } else {
  KLObject* t790;
  {
    KLObject* a790[] = {t784};
    t790 = shen_apply_direct(ctx, "shen.<-out", 1, a790);
  }
  KLObject* t792;
  {
    KLObject* a792[] = {t784};
    t792 = shen_apply_direct(ctx, "shen.in->", 1, a792);
  }
  KLObject* t794;
  {
    KLObject* a794[] = {t792};
    t794 = shen_apply_direct(ctx, "shen.<rrb>", 1, a794);
  }
  KLObject* t797;
  {
    KLObject* a797[] = {t794};
    t797 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a797);
  }
  KLObject* t796;
  if (!shen_is_boolean(ctx, t797))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t797)) {
  KLObject* t799 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t796 = t799;
  } else {
  KLObject* t800;
  {
    KLObject* a800[] = {t794};
    t800 = shen_apply_direct(ctx, "shen.in->", 1, a800);
  }
  KLObject* t802;
  {
    KLObject* a802[] = {t800};
    t802 = shen_apply_direct(ctx, "shen.<s-exprs2>", 1, a802);
  }
  KLObject* t805;
  {
    KLObject* a805[] = {t802};
    t805 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a805);
  }
  KLObject* t804;
  if (!shen_is_boolean(ctx, t805))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t805)) {
  KLObject* t807 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t804 = t807;
  } else {
  KLObject* t808;
  {
    KLObject* a808[] = {t802};
    t808 = shen_apply_direct(ctx, "shen.<-out", 1, a808);
  }
  KLObject* t810;
  {
    KLObject* a810[] = {t802};
    t810 = shen_apply_direct(ctx, "shen.in->", 1, a810);
  }
  KLObject* t814;
  {
    KLObject* a814[] = {t790, t808};
    t814 = shen_apply_direct(ctx, "shen.add-sexpr", 2, a814);
  }
  KLObject* t812;
  {
    KLObject* a812[] = {t810, t814};
    t812 = shen_apply_direct(ctx, "shen.comb", 2, a812);
  }
    t804 = t812;
  }
    t796 = t804;
  }
    t786 = t796;
  }
    t778 = t786;
  }
  KLObject* t818;
  {
    KLObject* a818[] = {t778};
    t818 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a818);
  }
  KLObject* t817;
  if (!shen_is_boolean(ctx, t818))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t818)) {
  KLObject* t820;
  {
    KLObject* a820[] = {t730};
    t820 = shen_apply_direct(ctx, "shen.<lcurly>", 1, a820);
  }
  KLObject* t823;
  {
    KLObject* a823[] = {t820};
    t823 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a823);
  }
  KLObject* t822;
  if (!shen_is_boolean(ctx, t823))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t823)) {
  KLObject* t825 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t822 = t825;
  } else {
  KLObject* t826;
  {
    KLObject* a826[] = {t820};
    t826 = shen_apply_direct(ctx, "shen.in->", 1, a826);
  }
  KLObject* t828;
  {
    KLObject* a828[] = {t826};
    t828 = shen_apply_direct(ctx, "shen.<s-exprs>", 1, a828);
  }
  KLObject* t831;
  {
    KLObject* a831[] = {t828};
    t831 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a831);
  }
  KLObject* t830;
  if (!shen_is_boolean(ctx, t831))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t831)) {
  KLObject* t833 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t830 = t833;
  } else {
  KLObject* t834;
  {
    KLObject* a834[] = {t828};
    t834 = shen_apply_direct(ctx, "shen.<-out", 1, a834);
  }
  KLObject* t836;
  {
    KLObject* a836[] = {t828};
    t836 = shen_apply_direct(ctx, "shen.in->", 1, a836);
  }
  KLObject* t840 = shen_intern(ctx, "{");
  KLObject* t842 = shen_cons(ctx, t840, t834);
  KLObject* t838;
  {
    KLObject* a838[] = {t836, t842};
    t838 = shen_apply_direct(ctx, "shen.comb", 2, a838);
  }
    t830 = t838;
  }
    t822 = t830;
  }
  KLObject* t844;
  {
    KLObject* a844[] = {t822};
    t844 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a844);
  }
  KLObject* t843;
  if (!shen_is_boolean(ctx, t844))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t844)) {
  KLObject* t846;
  {
    KLObject* a846[] = {t730};
    t846 = shen_apply_direct(ctx, "shen.<rcurly>", 1, a846);
  }
  KLObject* t849;
  {
    KLObject* a849[] = {t846};
    t849 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a849);
  }
  KLObject* t848;
  if (!shen_is_boolean(ctx, t849))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t849)) {
  KLObject* t851 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t848 = t851;
  } else {
  KLObject* t852;
  {
    KLObject* a852[] = {t846};
    t852 = shen_apply_direct(ctx, "shen.in->", 1, a852);
  }
  KLObject* t854;
  {
    KLObject* a854[] = {t852};
    t854 = shen_apply_direct(ctx, "shen.<s-exprs>", 1, a854);
  }
  KLObject* t857;
  {
    KLObject* a857[] = {t854};
    t857 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a857);
  }
  KLObject* t856;
  if (!shen_is_boolean(ctx, t857))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t857)) {
  KLObject* t859 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t856 = t859;
  } else {
  KLObject* t860;
  {
    KLObject* a860[] = {t854};
    t860 = shen_apply_direct(ctx, "shen.<-out", 1, a860);
  }
  KLObject* t862;
  {
    KLObject* a862[] = {t854};
    t862 = shen_apply_direct(ctx, "shen.in->", 1, a862);
  }
  KLObject* t866 = shen_intern(ctx, "}");
  KLObject* t868 = shen_cons(ctx, t866, t860);
  KLObject* t864;
  {
    KLObject* a864[] = {t862, t868};
    t864 = shen_apply_direct(ctx, "shen.comb", 2, a864);
  }
    t856 = t864;
  }
    t848 = t856;
  }
  KLObject* t870;
  {
    KLObject* a870[] = {t848};
    t870 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a870);
  }
  KLObject* t869;
  if (!shen_is_boolean(ctx, t870))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t870)) {
  KLObject* t872;
  {
    KLObject* a872[] = {t730};
    t872 = shen_apply_direct(ctx, "shen.<bar>", 1, a872);
  }
  KLObject* t875;
  {
    KLObject* a875[] = {t872};
    t875 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a875);
  }
  KLObject* t874;
  if (!shen_is_boolean(ctx, t875))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t875)) {
  KLObject* t877 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t874 = t877;
  } else {
  KLObject* t878;
  {
    KLObject* a878[] = {t872};
    t878 = shen_apply_direct(ctx, "shen.in->", 1, a878);
  }
  KLObject* t880;
  {
    KLObject* a880[] = {t878};
    t880 = shen_apply_direct(ctx, "shen.<s-exprs>", 1, a880);
  }
  KLObject* t883;
  {
    KLObject* a883[] = {t880};
    t883 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a883);
  }
  KLObject* t882;
  if (!shen_is_boolean(ctx, t883))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t883)) {
  KLObject* t885 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t882 = t885;
  } else {
  KLObject* t886;
  {
    KLObject* a886[] = {t880};
    t886 = shen_apply_direct(ctx, "shen.<-out", 1, a886);
  }
  KLObject* t888;
  {
    KLObject* a888[] = {t880};
    t888 = shen_apply_direct(ctx, "shen.in->", 1, a888);
  }
  KLObject* t892 = shen_intern(ctx, "bar!");
  KLObject* t894 = shen_cons(ctx, t892, t886);
  KLObject* t890;
  {
    KLObject* a890[] = {t888, t894};
    t890 = shen_apply_direct(ctx, "shen.comb", 2, a890);
  }
    t882 = t890;
  }
    t874 = t882;
  }
  KLObject* t896;
  {
    KLObject* a896[] = {t874};
    t896 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a896);
  }
  KLObject* t895;
  if (!shen_is_boolean(ctx, t896))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t896)) {
  KLObject* t898;
  {
    KLObject* a898[] = {t730};
    t898 = shen_apply_direct(ctx, "shen.<semicolon>", 1, a898);
  }
  KLObject* t901;
  {
    KLObject* a901[] = {t898};
    t901 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a901);
  }
  KLObject* t900;
  if (!shen_is_boolean(ctx, t901))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t901)) {
  KLObject* t903 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t900 = t903;
  } else {
  KLObject* t904;
  {
    KLObject* a904[] = {t898};
    t904 = shen_apply_direct(ctx, "shen.in->", 1, a904);
  }
  KLObject* t906;
  {
    KLObject* a906[] = {t904};
    t906 = shen_apply_direct(ctx, "shen.<s-exprs>", 1, a906);
  }
  KLObject* t909;
  {
    KLObject* a909[] = {t906};
    t909 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a909);
  }
  KLObject* t908;
  if (!shen_is_boolean(ctx, t909))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t909)) {
  KLObject* t911 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t908 = t911;
  } else {
  KLObject* t912;
  {
    KLObject* a912[] = {t906};
    t912 = shen_apply_direct(ctx, "shen.<-out", 1, a912);
  }
  KLObject* t914;
  {
    KLObject* a914[] = {t906};
    t914 = shen_apply_direct(ctx, "shen.in->", 1, a914);
  }
  KLObject* t919 = shen_string(ctx, ";");
  KLObject* t918;
  {
    KLObject* a918[] = {t919};
    t918 = shen_apply_direct(ctx, "intern", 1, a918);
  }
  KLObject* t921 = shen_cons(ctx, t918, t912);
  KLObject* t916;
  {
    KLObject* a916[] = {t914, t921};
    t916 = shen_apply_direct(ctx, "shen.comb", 2, a916);
  }
    t908 = t916;
  }
    t900 = t908;
  }
  KLObject* t923;
  {
    KLObject* a923[] = {t900};
    t923 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a923);
  }
  KLObject* t922;
  if (!shen_is_boolean(ctx, t923))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t923)) {
  KLObject* t925;
  {
    KLObject* a925[] = {t730};
    t925 = shen_apply_direct(ctx, "shen.<colon>", 1, a925);
  }
  KLObject* t928;
  {
    KLObject* a928[] = {t925};
    t928 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a928);
  }
  KLObject* t927;
  if (!shen_is_boolean(ctx, t928))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t928)) {
  KLObject* t930 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t927 = t930;
  } else {
  KLObject* t931;
  {
    KLObject* a931[] = {t925};
    t931 = shen_apply_direct(ctx, "shen.in->", 1, a931);
  }
  KLObject* t933;
  {
    KLObject* a933[] = {t931};
    t933 = shen_apply_direct(ctx, "shen.<equal>", 1, a933);
  }
  KLObject* t936;
  {
    KLObject* a936[] = {t933};
    t936 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a936);
  }
  KLObject* t935;
  if (!shen_is_boolean(ctx, t936))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t936)) {
  KLObject* t938 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t935 = t938;
  } else {
  KLObject* t939;
  {
    KLObject* a939[] = {t933};
    t939 = shen_apply_direct(ctx, "shen.in->", 1, a939);
  }
  KLObject* t941;
  {
    KLObject* a941[] = {t939};
    t941 = shen_apply_direct(ctx, "shen.<s-exprs>", 1, a941);
  }
  KLObject* t944;
  {
    KLObject* a944[] = {t941};
    t944 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a944);
  }
  KLObject* t943;
  if (!shen_is_boolean(ctx, t944))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t944)) {
  KLObject* t946 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t943 = t946;
  } else {
  KLObject* t947;
  {
    KLObject* a947[] = {t941};
    t947 = shen_apply_direct(ctx, "shen.<-out", 1, a947);
  }
  KLObject* t949;
  {
    KLObject* a949[] = {t941};
    t949 = shen_apply_direct(ctx, "shen.in->", 1, a949);
  }
  KLObject* t954 = shen_string(ctx, ":=");
  KLObject* t953;
  {
    KLObject* a953[] = {t954};
    t953 = shen_apply_direct(ctx, "intern", 1, a953);
  }
  KLObject* t956 = shen_cons(ctx, t953, t947);
  KLObject* t951;
  {
    KLObject* a951[] = {t949, t956};
    t951 = shen_apply_direct(ctx, "shen.comb", 2, a951);
  }
    t943 = t951;
  }
    t935 = t943;
  }
    t927 = t935;
  }
  KLObject* t958;
  {
    KLObject* a958[] = {t927};
    t958 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a958);
  }
  KLObject* t957;
  if (!shen_is_boolean(ctx, t958))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t958)) {
  KLObject* t960;
  {
    KLObject* a960[] = {t730};
    t960 = shen_apply_direct(ctx, "shen.<colon>", 1, a960);
  }
  KLObject* t963;
  {
    KLObject* a963[] = {t960};
    t963 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a963);
  }
  KLObject* t962;
  if (!shen_is_boolean(ctx, t963))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t963)) {
  KLObject* t965 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t962 = t965;
  } else {
  KLObject* t966;
  {
    KLObject* a966[] = {t960};
    t966 = shen_apply_direct(ctx, "shen.in->", 1, a966);
  }
  KLObject* t968;
  {
    KLObject* a968[] = {t966};
    t968 = shen_apply_direct(ctx, "shen.<s-exprs>", 1, a968);
  }
  KLObject* t971;
  {
    KLObject* a971[] = {t968};
    t971 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a971);
  }
  KLObject* t970;
  if (!shen_is_boolean(ctx, t971))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t971)) {
  KLObject* t973 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t970 = t973;
  } else {
  KLObject* t974;
  {
    KLObject* a974[] = {t968};
    t974 = shen_apply_direct(ctx, "shen.<-out", 1, a974);
  }
  KLObject* t976;
  {
    KLObject* a976[] = {t968};
    t976 = shen_apply_direct(ctx, "shen.in->", 1, a976);
  }
  KLObject* t981 = shen_string(ctx, ":");
  KLObject* t980;
  {
    KLObject* a980[] = {t981};
    t980 = shen_apply_direct(ctx, "intern", 1, a980);
  }
  KLObject* t983 = shen_cons(ctx, t980, t974);
  KLObject* t978;
  {
    KLObject* a978[] = {t976, t983};
    t978 = shen_apply_direct(ctx, "shen.comb", 2, a978);
  }
    t970 = t978;
  }
    t962 = t970;
  }
  KLObject* t985;
  {
    KLObject* a985[] = {t962};
    t985 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a985);
  }
  KLObject* t984;
  if (!shen_is_boolean(ctx, t985))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t985)) {
  KLObject* t987;
  {
    KLObject* a987[] = {t730};
    t987 = shen_apply_direct(ctx, "shen.<comma>", 1, a987);
  }
  KLObject* t990;
  {
    KLObject* a990[] = {t987};
    t990 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a990);
  }
  KLObject* t989;
  if (!shen_is_boolean(ctx, t990))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t990)) {
  KLObject* t992 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t989 = t992;
  } else {
  KLObject* t993;
  {
    KLObject* a993[] = {t987};
    t993 = shen_apply_direct(ctx, "shen.in->", 1, a993);
  }
  KLObject* t995;
  {
    KLObject* a995[] = {t993};
    t995 = shen_apply_direct(ctx, "shen.<s-exprs>", 1, a995);
  }
  KLObject* t998;
  {
    KLObject* a998[] = {t995};
    t998 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a998);
  }
  KLObject* t997;
  if (!shen_is_boolean(ctx, t998))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t998)) {
  KLObject* t1000 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t997 = t1000;
  } else {
  KLObject* t1001;
  {
    KLObject* a1001[] = {t995};
    t1001 = shen_apply_direct(ctx, "shen.<-out", 1, a1001);
  }
  KLObject* t1003;
  {
    KLObject* a1003[] = {t995};
    t1003 = shen_apply_direct(ctx, "shen.in->", 1, a1003);
  }
  KLObject* t1008 = shen_string(ctx, ",");
  KLObject* t1007;
  {
    KLObject* a1007[] = {t1008};
    t1007 = shen_apply_direct(ctx, "intern", 1, a1007);
  }
  KLObject* t1010 = shen_cons(ctx, t1007, t1001);
  KLObject* t1005;
  {
    KLObject* a1005[] = {t1003, t1010};
    t1005 = shen_apply_direct(ctx, "shen.comb", 2, a1005);
  }
    t997 = t1005;
  }
    t989 = t997;
  }
  KLObject* t1012;
  {
    KLObject* a1012[] = {t989};
    t1012 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a1012);
  }
  KLObject* t1011;
  if (!shen_is_boolean(ctx, t1012))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1012)) {
  KLObject* t1014;
  {
    KLObject* a1014[] = {t730};
    t1014 = shen_apply_direct(ctx, "shen.<comment>", 1, a1014);
  }
  KLObject* t1017;
  {
    KLObject* a1017[] = {t1014};
    t1017 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a1017);
  }
  KLObject* t1016;
  if (!shen_is_boolean(ctx, t1017))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1017)) {
  KLObject* t1019 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t1016 = t1019;
  } else {
  KLObject* t1020;
  {
    KLObject* a1020[] = {t1014};
    t1020 = shen_apply_direct(ctx, "shen.in->", 1, a1020);
  }
  KLObject* t1022;
  {
    KLObject* a1022[] = {t1020};
    t1022 = shen_apply_direct(ctx, "shen.<s-exprs>", 1, a1022);
  }
  KLObject* t1025;
  {
    KLObject* a1025[] = {t1022};
    t1025 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a1025);
  }
  KLObject* t1024;
  if (!shen_is_boolean(ctx, t1025))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1025)) {
  KLObject* t1027 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t1024 = t1027;
  } else {
  KLObject* t1028;
  {
    KLObject* a1028[] = {t1022};
    t1028 = shen_apply_direct(ctx, "shen.<-out", 1, a1028);
  }
  KLObject* t1030;
  {
    KLObject* a1030[] = {t1022};
    t1030 = shen_apply_direct(ctx, "shen.in->", 1, a1030);
  }
  KLObject* t1032;
  {
    KLObject* a1032[] = {t1030, t1028};
    t1032 = shen_apply_direct(ctx, "shen.comb", 2, a1032);
  }
    t1024 = t1032;
  }
    t1016 = t1024;
  }
  KLObject* t1036;
  {
    KLObject* a1036[] = {t1016};
    t1036 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a1036);
  }
  KLObject* t1035;
  if (!shen_is_boolean(ctx, t1036))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1036)) {
  KLObject* t1038;
  {
    KLObject* a1038[] = {t730};
    t1038 = shen_apply_direct(ctx, "shen.<atom>", 1, a1038);
  }
  KLObject* t1041;
  {
    KLObject* a1041[] = {t1038};
    t1041 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a1041);
  }
  KLObject* t1040;
  if (!shen_is_boolean(ctx, t1041))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1041)) {
  KLObject* t1043 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t1040 = t1043;
  } else {
  KLObject* t1044;
  {
    KLObject* a1044[] = {t1038};
    t1044 = shen_apply_direct(ctx, "shen.<-out", 1, a1044);
  }
  KLObject* t1046;
  {
    KLObject* a1046[] = {t1038};
    t1046 = shen_apply_direct(ctx, "shen.in->", 1, a1046);
  }
  KLObject* t1048;
  {
    KLObject* a1048[] = {t1046};
    t1048 = shen_apply_direct(ctx, "shen.<s-exprs>", 1, a1048);
  }
  KLObject* t1051;
  {
    KLObject* a1051[] = {t1048};
    t1051 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a1051);
  }
  KLObject* t1050;
  if (!shen_is_boolean(ctx, t1051))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1051)) {
  KLObject* t1053 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t1050 = t1053;
  } else {
  KLObject* t1054;
  {
    KLObject* a1054[] = {t1048};
    t1054 = shen_apply_direct(ctx, "shen.<-out", 1, a1054);
  }
  KLObject* t1056;
  {
    KLObject* a1056[] = {t1048};
    t1056 = shen_apply_direct(ctx, "shen.in->", 1, a1056);
  }
  KLObject* t1062 = shen_cons(ctx, t1044, t1054);
  KLObject* t1058;
  {
    KLObject* a1058[] = {t1056, t1062};
    t1058 = shen_apply_direct(ctx, "shen.comb", 2, a1058);
  }
    t1050 = t1058;
  }
    t1040 = t1050;
  }
  KLObject* t1064;
  {
    KLObject* a1064[] = {t1040};
    t1064 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a1064);
  }
  KLObject* t1063;
  if (!shen_is_boolean(ctx, t1064))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1064)) {
  KLObject* t1066;
  {
    KLObject* a1066[] = {t730};
    t1066 = shen_apply_direct(ctx, "shen.<whitespaces>", 1, a1066);
  }
  KLObject* t1069;
  {
    KLObject* a1069[] = {t1066};
    t1069 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a1069);
  }
  KLObject* t1068;
  if (!shen_is_boolean(ctx, t1069))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1069)) {
  KLObject* t1071 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t1068 = t1071;
  } else {
  KLObject* t1072;
  {
    KLObject* a1072[] = {t1066};
    t1072 = shen_apply_direct(ctx, "shen.in->", 1, a1072);
  }
  KLObject* t1074;
  {
    KLObject* a1074[] = {t1072};
    t1074 = shen_apply_direct(ctx, "shen.<s-exprs>", 1, a1074);
  }
  KLObject* t1077;
  {
    KLObject* a1077[] = {t1074};
    t1077 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a1077);
  }
  KLObject* t1076;
  if (!shen_is_boolean(ctx, t1077))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1077)) {
  KLObject* t1079 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t1076 = t1079;
  } else {
  KLObject* t1080;
  {
    KLObject* a1080[] = {t1074};
    t1080 = shen_apply_direct(ctx, "shen.<-out", 1, a1080);
  }
  KLObject* t1082;
  {
    KLObject* a1082[] = {t1074};
    t1082 = shen_apply_direct(ctx, "shen.in->", 1, a1082);
  }
  KLObject* t1084;
  {
    KLObject* a1084[] = {t1082, t1080};
    t1084 = shen_apply_direct(ctx, "shen.comb", 2, a1084);
  }
    t1076 = t1084;
  }
    t1068 = t1076;
  }
  KLObject* t1088;
  {
    KLObject* a1088[] = {t1068};
    t1088 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a1088);
  }
  KLObject* t1087;
  if (!shen_is_boolean(ctx, t1088))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1088)) {
  KLObject* t1090;
  {
    KLObject* a1090[] = {t730};
    t1090 = shen_apply_direct(ctx, "<e>", 1, a1090);
  }
  KLObject* t1093;
  {
    KLObject* a1093[] = {t1090};
    t1093 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a1093);
  }
  KLObject* t1092;
  if (!shen_is_boolean(ctx, t1093))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1093)) {
  KLObject* t1095 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t1092 = t1095;
  } else {
  KLObject* t1096;
  {
    KLObject* a1096[] = {t1090};
    t1096 = shen_apply_direct(ctx, "shen.in->", 1, a1096);
  }
  KLObject* t1100 = shen_empty_list(ctx);
  KLObject* t1098;
  {
    KLObject* a1098[] = {t1096, t1100};
    t1098 = shen_apply_direct(ctx, "shen.comb", 2, a1098);
  }
    t1092 = t1098;
  }
  KLObject* t1102;
  {
    KLObject* a1102[] = {t1092};
    t1102 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a1102);
  }
  KLObject* t1101;
  if (!shen_is_boolean(ctx, t1102))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1102)) {
  KLObject* t1104 = shen_tail_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t1101 = t1104;
  } else {
    t1101 = t1092;
  }
    t1087 = t1101;
  } else {
    t1087 = t1068;
  }
    t1063 = t1087;
  } else {
    t1063 = t1040;
  }
    t1035 = t1063;
  } else {
    t1035 = t1016;
  }
    t1011 = t1035;
  } else {
    t1011 = t989;
  }
    t984 = t1011;
  } else {
    t984 = t962;
  }
    t957 = t984;
  } else {
    t957 = t927;
  }
    t922 = t957;
  } else {
    t922 = t900;
  }
    t895 = t922;
  } else {
    t895 = t874;
  }
    t869 = t895;
  } else {
    t869 = t848;
  }
    t843 = t869;
  } else {
    t843 = t822;
  }
    t817 = t843;
  } else {
    t817 = t778;
  }
    t773 = t817;
  } else {
    t773 = t733;
  }
    return t773;
  }
}

static KLObject* native_kl_shen_2eadd_2dsexpr_32 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t1118 = objects[0];
    KLObject* t1119 = objects[1];
  tail_start_kl_shen_2eadd_2dsexpr_32: ;
  KLObject* t1120;
  {
  KLObject* t1123 = shen_cons_p(ctx, t1118);
  KLObject* t1121;
  if (!shen_is_boolean(ctx, t1123))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t1123)) {
    t1121 = t1123;
  } else {
  KLObject* t1125 = shen_intern(ctx, "$");
  KLObject* t1127 = shen_hd(ctx, t1118);
  KLObject* t1128 = shen_eq(ctx, t1125, t1127);
  KLObject* t1124;
  if (!shen_is_boolean(ctx, t1128))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t1128)) {
    t1124 = t1128;
  } else {
  KLObject* t1131 = shen_tl(ctx, t1118);
  KLObject* t1132 = shen_cons_p(ctx, t1131);
  KLObject* t1129;
  if (!shen_is_boolean(ctx, t1132))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t1132)) {
    t1129 = t1132;
  } else {
  KLObject* t1133 = shen_empty_list(ctx);
  KLObject* t1135 = shen_tl(ctx, t1118);
  KLObject* t1136 = shen_tl(ctx, t1135);
  KLObject* t1137 = shen_eq(ctx, t1133, t1136);
    if (!shen_is_boolean(ctx, t1137))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t1129 = t1137;
  }
    if (!shen_is_boolean(ctx, t1129))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t1124 = t1129;
  }
    if (!shen_is_boolean(ctx, t1124))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t1121 = t1124;
  }
    if (!shen_is_boolean(ctx, t1121))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t1121)) {
  KLObject* t1141 = shen_tl(ctx, t1118);
  KLObject* t1142 = shen_hd(ctx, t1141);
  KLObject* t1139;
  {
    KLObject* a1139[] = {t1142};
    t1139 = shen_apply_direct(ctx, "explode", 1, a1139);
  }
  KLObject* t1138;
  {
    KLObject* a1138[] = {t1139, t1119};
    t1138 = shen_tail_apply_direct(ctx, "append", 2, a1138);
  }
      t1120 = t1138;
    } else {
  KLObject* t1144 = shen_true(ctx);
    if (!shen_is_boolean(ctx, t1144))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t1144)) {
  KLObject* t1147 = shen_cons(ctx, t1118, t1119);
      t1120 = t1147;
    } else {
      shen_simple_error(ctx, "No true case found for cond");
      t1120 = shen_empty_list(ctx);
    }
    }
  }
    return t1120;
  }
}

static KLObject* native_kl_shen_2e_3clsb_3e_33 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t1148 = objects[0];
  tail_start_kl_shen_2e_3clsb_3e_33: ;
  KLObject* t1152 = shen_number_l(ctx, 91);
  KLObject* t1150;
  {
    KLObject* a1150[] = {t1148, t1152};
    t1150 = shen_apply_direct(ctx, "shen.hds=?", 2, a1150);
  }
  KLObject* t1149;
  if (!shen_is_boolean(ctx, t1150))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1150)) {
  KLObject* t1153;
  {
    KLObject* a1153[] = {t1148};
    t1153 = shen_apply_direct(ctx, "tail", 1, a1153);
  }
  KLObject* t1157 = shen_intern(ctx, "shen.skip");
  KLObject* t1155;
  {
    KLObject* a1155[] = {t1153, t1157};
    t1155 = shen_apply_direct(ctx, "shen.comb", 2, a1155);
  }
    t1149 = t1155;
  } else {
  KLObject* t1158 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t1149 = t1158;
  }
  KLObject* t1160;
  {
    KLObject* a1160[] = {t1149};
    t1160 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a1160);
  }
  KLObject* t1159;
  if (!shen_is_boolean(ctx, t1160))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1160)) {
  KLObject* t1162 = shen_tail_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t1159 = t1162;
  } else {
    t1159 = t1149;
  }
    return t1159;
  }
}

static KLObject* native_kl_shen_2e_3crsb_3e_34 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t1164 = objects[0];
  tail_start_kl_shen_2e_3crsb_3e_34: ;
  KLObject* t1168 = shen_number_l(ctx, 93);
  KLObject* t1166;
  {
    KLObject* a1166[] = {t1164, t1168};
    t1166 = shen_apply_direct(ctx, "shen.hds=?", 2, a1166);
  }
  KLObject* t1165;
  if (!shen_is_boolean(ctx, t1166))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1166)) {
  KLObject* t1169;
  {
    KLObject* a1169[] = {t1164};
    t1169 = shen_apply_direct(ctx, "tail", 1, a1169);
  }
  KLObject* t1173 = shen_intern(ctx, "shen.skip");
  KLObject* t1171;
  {
    KLObject* a1171[] = {t1169, t1173};
    t1171 = shen_apply_direct(ctx, "shen.comb", 2, a1171);
  }
    t1165 = t1171;
  } else {
  KLObject* t1174 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t1165 = t1174;
  }
  KLObject* t1176;
  {
    KLObject* a1176[] = {t1165};
    t1176 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a1176);
  }
  KLObject* t1175;
  if (!shen_is_boolean(ctx, t1176))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1176)) {
  KLObject* t1178 = shen_tail_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t1175 = t1178;
  } else {
    t1175 = t1165;
  }
    return t1175;
  }
}

static KLObject* native_kl_shen_2e_3cs_2dexprs1_3e_35 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t1180 = objects[0];
  tail_start_kl_shen_2e_3cs_2dexprs1_3e_35: ;
  KLObject* t1181;
  {
    KLObject* a1181[] = {t1180};
    t1181 = shen_apply_direct(ctx, "shen.<s-exprs>", 1, a1181);
  }
  KLObject* t1184;
  {
    KLObject* a1184[] = {t1181};
    t1184 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a1184);
  }
  KLObject* t1183;
  if (!shen_is_boolean(ctx, t1184))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1184)) {
  KLObject* t1186 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t1183 = t1186;
  } else {
  KLObject* t1187;
  {
    KLObject* a1187[] = {t1181};
    t1187 = shen_apply_direct(ctx, "shen.<-out", 1, a1187);
  }
  KLObject* t1189;
  {
    KLObject* a1189[] = {t1181};
    t1189 = shen_apply_direct(ctx, "shen.in->", 1, a1189);
  }
  KLObject* t1191;
  {
    KLObject* a1191[] = {t1189, t1187};
    t1191 = shen_apply_direct(ctx, "shen.comb", 2, a1191);
  }
    t1183 = t1191;
  }
  KLObject* t1195;
  {
    KLObject* a1195[] = {t1183};
    t1195 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a1195);
  }
  KLObject* t1194;
  if (!shen_is_boolean(ctx, t1195))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1195)) {
  KLObject* t1197 = shen_tail_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t1194 = t1197;
  } else {
    t1194 = t1183;
  }
    return t1194;
  }
}

static KLObject* native_kl_shen_2e_3cs_2dexprs2_3e_36 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t1199 = objects[0];
  tail_start_kl_shen_2e_3cs_2dexprs2_3e_36: ;
  KLObject* t1200;
  {
    KLObject* a1200[] = {t1199};
    t1200 = shen_apply_direct(ctx, "shen.<s-exprs>", 1, a1200);
  }
  KLObject* t1203;
  {
    KLObject* a1203[] = {t1200};
    t1203 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a1203);
  }
  KLObject* t1202;
  if (!shen_is_boolean(ctx, t1203))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1203)) {
  KLObject* t1205 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t1202 = t1205;
  } else {
  KLObject* t1206;
  {
    KLObject* a1206[] = {t1200};
    t1206 = shen_apply_direct(ctx, "shen.<-out", 1, a1206);
  }
  KLObject* t1208;
  {
    KLObject* a1208[] = {t1200};
    t1208 = shen_apply_direct(ctx, "shen.in->", 1, a1208);
  }
  KLObject* t1210;
  {
    KLObject* a1210[] = {t1208, t1206};
    t1210 = shen_apply_direct(ctx, "shen.comb", 2, a1210);
  }
    t1202 = t1210;
  }
  KLObject* t1214;
  {
    KLObject* a1214[] = {t1202};
    t1214 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a1214);
  }
  KLObject* t1213;
  if (!shen_is_boolean(ctx, t1214))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1214)) {
  KLObject* t1216 = shen_tail_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t1213 = t1216;
  } else {
    t1213 = t1202;
  }
    return t1213;
  }
}

static KLObject* native_kl_shen_2econs_2dform_37 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t1218 = objects[0];
  tail_start_kl_shen_2econs_2dform_37: ;
  KLObject* t1219;
  {
  KLObject* t1220 = shen_empty_list(ctx);
  KLObject* t1222 = shen_eq(ctx, t1220, t1218);
    if (!shen_is_boolean(ctx, t1222))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t1222)) {
  KLObject* t1223 = shen_empty_list(ctx);
      t1219 = t1223;
    } else {
  KLObject* t1226 = shen_cons_p(ctx, t1218);
  KLObject* t1224;
  if (!shen_is_boolean(ctx, t1226))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t1226)) {
    t1224 = t1226;
  } else {
  KLObject* t1229 = shen_tl(ctx, t1218);
  KLObject* t1230 = shen_cons_p(ctx, t1229);
  KLObject* t1227;
  if (!shen_is_boolean(ctx, t1230))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t1230)) {
    t1227 = t1230;
  } else {
  KLObject* t1233 = shen_tl(ctx, t1218);
  KLObject* t1234 = shen_tl(ctx, t1233);
  KLObject* t1235 = shen_cons_p(ctx, t1234);
  KLObject* t1231;
  if (!shen_is_boolean(ctx, t1235))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t1235)) {
    t1231 = t1235;
  } else {
  KLObject* t1237 = shen_empty_list(ctx);
  KLObject* t1239 = shen_tl(ctx, t1218);
  KLObject* t1240 = shen_tl(ctx, t1239);
  KLObject* t1241 = shen_tl(ctx, t1240);
  KLObject* t1242 = shen_eq(ctx, t1237, t1241);
  KLObject* t1236;
  if (!shen_is_boolean(ctx, t1242))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t1242)) {
    t1236 = t1242;
  } else {
  KLObject* t1244 = shen_tl(ctx, t1218);
  KLObject* t1245 = shen_hd(ctx, t1244);
  KLObject* t1246 = shen_intern(ctx, "bar!");
  KLObject* t1247 = shen_eq(ctx, t1245, t1246);
    if (!shen_is_boolean(ctx, t1247))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t1236 = t1247;
  }
    if (!shen_is_boolean(ctx, t1236))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t1231 = t1236;
  }
    if (!shen_is_boolean(ctx, t1231))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t1227 = t1231;
  }
    if (!shen_is_boolean(ctx, t1227))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t1224 = t1227;
  }
    if (!shen_is_boolean(ctx, t1224))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t1224)) {
  KLObject* t1248 = shen_intern(ctx, "cons");
  KLObject* t1250 = shen_hd(ctx, t1218);
  KLObject* t1252 = shen_tl(ctx, t1218);
  KLObject* t1253 = shen_tl(ctx, t1252);
  KLObject* t1254 = shen_cons(ctx, t1250, t1253);
  KLObject* t1255 = shen_cons(ctx, t1248, t1254);
      t1219 = t1255;
    } else {
  KLObject* t1258 = shen_cons_p(ctx, t1218);
  KLObject* t1256;
  if (!shen_is_boolean(ctx, t1258))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t1258)) {
    t1256 = t1258;
  } else {
  KLObject* t1261 = shen_tl(ctx, t1218);
  KLObject* t1262 = shen_cons_p(ctx, t1261);
  KLObject* t1259;
  if (!shen_is_boolean(ctx, t1262))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t1262)) {
    t1259 = t1262;
  } else {
  KLObject* t1265 = shen_tl(ctx, t1218);
  KLObject* t1266 = shen_tl(ctx, t1265);
  KLObject* t1267 = shen_cons_p(ctx, t1266);
  KLObject* t1263;
  if (!shen_is_boolean(ctx, t1267))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t1267)) {
    t1263 = t1267;
  } else {
  KLObject* t1270 = shen_tl(ctx, t1218);
  KLObject* t1271 = shen_tl(ctx, t1270);
  KLObject* t1272 = shen_tl(ctx, t1271);
  KLObject* t1273 = shen_cons_p(ctx, t1272);
  KLObject* t1268;
  if (!shen_is_boolean(ctx, t1273))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t1273)) {
    t1268 = t1273;
  } else {
  KLObject* t1275 = shen_tl(ctx, t1218);
  KLObject* t1276 = shen_hd(ctx, t1275);
  KLObject* t1277 = shen_intern(ctx, "bar!");
  KLObject* t1278 = shen_eq(ctx, t1276, t1277);
    if (!shen_is_boolean(ctx, t1278))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t1268 = t1278;
  }
    if (!shen_is_boolean(ctx, t1268))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t1263 = t1268;
  }
    if (!shen_is_boolean(ctx, t1263))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t1259 = t1263;
  }
    if (!shen_is_boolean(ctx, t1259))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t1256 = t1259;
  }
    if (!shen_is_boolean(ctx, t1256))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t1256)) {
  KLObject* t1280 = shen_string(ctx, "misapplication of |\n");
  KLObject* t1279;
  {
    KLObject* a1279[] = {t1280};
    t1279 = shen_tail_apply_direct(ctx, "simple-error", 1, a1279);
  }
      t1219 = t1279;
    } else {
  KLObject* t1282 = shen_cons_p(ctx, t1218);
    if (!shen_is_boolean(ctx, t1282))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t1282)) {
  KLObject* t1283 = shen_intern(ctx, "cons");
  KLObject* t1285 = shen_hd(ctx, t1218);
  KLObject* t1288 = shen_tl(ctx, t1218);
  KLObject* t1286;
  {
    KLObject* a1286[] = {t1288};
    t1286 = shen_apply_direct(ctx, "shen.cons-form", 1, a1286);
  }
  KLObject* t1289 = shen_empty_list(ctx);
  KLObject* t1290 = shen_cons(ctx, t1286, t1289);
  KLObject* t1291 = shen_cons(ctx, t1285, t1290);
  KLObject* t1292 = shen_cons(ctx, t1283, t1291);
      t1219 = t1292;
    } else {
  KLObject* t1293 = shen_true(ctx);
    if (!shen_is_boolean(ctx, t1293))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t1293)) {
  KLObject* t1295 = shen_string(ctx, "partial function shen.cons-form");
  KLObject* t1294;
  {
    KLObject* a1294[] = {t1295};
    t1294 = shen_tail_apply_direct(ctx, "simple-error", 1, a1294);
  }
      t1219 = t1294;
    } else {
      shen_simple_error(ctx, "No true case found for cond");
      t1219 = shen_empty_list(ctx);
    }
    }
    }
    }
    }
  }
    return t1219;
  }
}

static KLObject* native_kl_shen_2e_3clrb_3e_38 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t1296 = objects[0];
  tail_start_kl_shen_2e_3clrb_3e_38: ;
  KLObject* t1300 = shen_number_l(ctx, 40);
  KLObject* t1298;
  {
    KLObject* a1298[] = {t1296, t1300};
    t1298 = shen_apply_direct(ctx, "shen.hds=?", 2, a1298);
  }
  KLObject* t1297;
  if (!shen_is_boolean(ctx, t1298))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1298)) {
  KLObject* t1301;
  {
    KLObject* a1301[] = {t1296};
    t1301 = shen_apply_direct(ctx, "tail", 1, a1301);
  }
  KLObject* t1305 = shen_intern(ctx, "shen.skip");
  KLObject* t1303;
  {
    KLObject* a1303[] = {t1301, t1305};
    t1303 = shen_apply_direct(ctx, "shen.comb", 2, a1303);
  }
    t1297 = t1303;
  } else {
  KLObject* t1306 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t1297 = t1306;
  }
  KLObject* t1308;
  {
    KLObject* a1308[] = {t1297};
    t1308 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a1308);
  }
  KLObject* t1307;
  if (!shen_is_boolean(ctx, t1308))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1308)) {
  KLObject* t1310 = shen_tail_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t1307 = t1310;
  } else {
    t1307 = t1297;
  }
    return t1307;
  }
}

static KLObject* native_kl_shen_2e_3crrb_3e_39 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t1312 = objects[0];
  tail_start_kl_shen_2e_3crrb_3e_39: ;
  KLObject* t1316 = shen_number_l(ctx, 41);
  KLObject* t1314;
  {
    KLObject* a1314[] = {t1312, t1316};
    t1314 = shen_apply_direct(ctx, "shen.hds=?", 2, a1314);
  }
  KLObject* t1313;
  if (!shen_is_boolean(ctx, t1314))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1314)) {
  KLObject* t1317;
  {
    KLObject* a1317[] = {t1312};
    t1317 = shen_apply_direct(ctx, "tail", 1, a1317);
  }
  KLObject* t1321 = shen_intern(ctx, "shen.skip");
  KLObject* t1319;
  {
    KLObject* a1319[] = {t1317, t1321};
    t1319 = shen_apply_direct(ctx, "shen.comb", 2, a1319);
  }
    t1313 = t1319;
  } else {
  KLObject* t1322 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t1313 = t1322;
  }
  KLObject* t1324;
  {
    KLObject* a1324[] = {t1313};
    t1324 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a1324);
  }
  KLObject* t1323;
  if (!shen_is_boolean(ctx, t1324))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1324)) {
  KLObject* t1326 = shen_tail_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t1323 = t1326;
  } else {
    t1323 = t1313;
  }
    return t1323;
  }
}

static KLObject* native_kl_shen_2e_3clcurly_3e_40 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t1328 = objects[0];
  tail_start_kl_shen_2e_3clcurly_3e_40: ;
  KLObject* t1332 = shen_number_l(ctx, 123);
  KLObject* t1330;
  {
    KLObject* a1330[] = {t1328, t1332};
    t1330 = shen_apply_direct(ctx, "shen.hds=?", 2, a1330);
  }
  KLObject* t1329;
  if (!shen_is_boolean(ctx, t1330))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1330)) {
  KLObject* t1333;
  {
    KLObject* a1333[] = {t1328};
    t1333 = shen_apply_direct(ctx, "tail", 1, a1333);
  }
  KLObject* t1337 = shen_intern(ctx, "shen.skip");
  KLObject* t1335;
  {
    KLObject* a1335[] = {t1333, t1337};
    t1335 = shen_apply_direct(ctx, "shen.comb", 2, a1335);
  }
    t1329 = t1335;
  } else {
  KLObject* t1338 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t1329 = t1338;
  }
  KLObject* t1340;
  {
    KLObject* a1340[] = {t1329};
    t1340 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a1340);
  }
  KLObject* t1339;
  if (!shen_is_boolean(ctx, t1340))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1340)) {
  KLObject* t1342 = shen_tail_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t1339 = t1342;
  } else {
    t1339 = t1329;
  }
    return t1339;
  }
}

static KLObject* native_kl_shen_2e_3crcurly_3e_41 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t1344 = objects[0];
  tail_start_kl_shen_2e_3crcurly_3e_41: ;
  KLObject* t1348 = shen_number_l(ctx, 125);
  KLObject* t1346;
  {
    KLObject* a1346[] = {t1344, t1348};
    t1346 = shen_apply_direct(ctx, "shen.hds=?", 2, a1346);
  }
  KLObject* t1345;
  if (!shen_is_boolean(ctx, t1346))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1346)) {
  KLObject* t1349;
  {
    KLObject* a1349[] = {t1344};
    t1349 = shen_apply_direct(ctx, "tail", 1, a1349);
  }
  KLObject* t1353 = shen_intern(ctx, "shen.skip");
  KLObject* t1351;
  {
    KLObject* a1351[] = {t1349, t1353};
    t1351 = shen_apply_direct(ctx, "shen.comb", 2, a1351);
  }
    t1345 = t1351;
  } else {
  KLObject* t1354 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t1345 = t1354;
  }
  KLObject* t1356;
  {
    KLObject* a1356[] = {t1345};
    t1356 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a1356);
  }
  KLObject* t1355;
  if (!shen_is_boolean(ctx, t1356))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1356)) {
  KLObject* t1358 = shen_tail_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t1355 = t1358;
  } else {
    t1355 = t1345;
  }
    return t1355;
  }
}

static KLObject* native_kl_shen_2e_3cbar_3e_42 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t1360 = objects[0];
  tail_start_kl_shen_2e_3cbar_3e_42: ;
  KLObject* t1364 = shen_number_l(ctx, 124);
  KLObject* t1362;
  {
    KLObject* a1362[] = {t1360, t1364};
    t1362 = shen_apply_direct(ctx, "shen.hds=?", 2, a1362);
  }
  KLObject* t1361;
  if (!shen_is_boolean(ctx, t1362))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1362)) {
  KLObject* t1365;
  {
    KLObject* a1365[] = {t1360};
    t1365 = shen_apply_direct(ctx, "tail", 1, a1365);
  }
  KLObject* t1369 = shen_intern(ctx, "shen.skip");
  KLObject* t1367;
  {
    KLObject* a1367[] = {t1365, t1369};
    t1367 = shen_apply_direct(ctx, "shen.comb", 2, a1367);
  }
    t1361 = t1367;
  } else {
  KLObject* t1370 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t1361 = t1370;
  }
  KLObject* t1372;
  {
    KLObject* a1372[] = {t1361};
    t1372 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a1372);
  }
  KLObject* t1371;
  if (!shen_is_boolean(ctx, t1372))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1372)) {
  KLObject* t1374 = shen_tail_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t1371 = t1374;
  } else {
    t1371 = t1361;
  }
    return t1371;
  }
}

static KLObject* native_kl_shen_2e_3csemicolon_3e_43 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t1376 = objects[0];
  tail_start_kl_shen_2e_3csemicolon_3e_43: ;
  KLObject* t1380 = shen_number_l(ctx, 59);
  KLObject* t1378;
  {
    KLObject* a1378[] = {t1376, t1380};
    t1378 = shen_apply_direct(ctx, "shen.hds=?", 2, a1378);
  }
  KLObject* t1377;
  if (!shen_is_boolean(ctx, t1378))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1378)) {
  KLObject* t1381;
  {
    KLObject* a1381[] = {t1376};
    t1381 = shen_apply_direct(ctx, "tail", 1, a1381);
  }
  KLObject* t1385 = shen_intern(ctx, "shen.skip");
  KLObject* t1383;
  {
    KLObject* a1383[] = {t1381, t1385};
    t1383 = shen_apply_direct(ctx, "shen.comb", 2, a1383);
  }
    t1377 = t1383;
  } else {
  KLObject* t1386 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t1377 = t1386;
  }
  KLObject* t1388;
  {
    KLObject* a1388[] = {t1377};
    t1388 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a1388);
  }
  KLObject* t1387;
  if (!shen_is_boolean(ctx, t1388))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1388)) {
  KLObject* t1390 = shen_tail_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t1387 = t1390;
  } else {
    t1387 = t1377;
  }
    return t1387;
  }
}

static KLObject* native_kl_shen_2e_3ccolon_3e_44 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t1392 = objects[0];
  tail_start_kl_shen_2e_3ccolon_3e_44: ;
  KLObject* t1396 = shen_number_l(ctx, 58);
  KLObject* t1394;
  {
    KLObject* a1394[] = {t1392, t1396};
    t1394 = shen_apply_direct(ctx, "shen.hds=?", 2, a1394);
  }
  KLObject* t1393;
  if (!shen_is_boolean(ctx, t1394))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1394)) {
  KLObject* t1397;
  {
    KLObject* a1397[] = {t1392};
    t1397 = shen_apply_direct(ctx, "tail", 1, a1397);
  }
  KLObject* t1401 = shen_intern(ctx, "shen.skip");
  KLObject* t1399;
  {
    KLObject* a1399[] = {t1397, t1401};
    t1399 = shen_apply_direct(ctx, "shen.comb", 2, a1399);
  }
    t1393 = t1399;
  } else {
  KLObject* t1402 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t1393 = t1402;
  }
  KLObject* t1404;
  {
    KLObject* a1404[] = {t1393};
    t1404 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a1404);
  }
  KLObject* t1403;
  if (!shen_is_boolean(ctx, t1404))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1404)) {
  KLObject* t1406 = shen_tail_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t1403 = t1406;
  } else {
    t1403 = t1393;
  }
    return t1403;
  }
}

static KLObject* native_kl_shen_2e_3ccomma_3e_45 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t1408 = objects[0];
  tail_start_kl_shen_2e_3ccomma_3e_45: ;
  KLObject* t1412 = shen_number_l(ctx, 44);
  KLObject* t1410;
  {
    KLObject* a1410[] = {t1408, t1412};
    t1410 = shen_apply_direct(ctx, "shen.hds=?", 2, a1410);
  }
  KLObject* t1409;
  if (!shen_is_boolean(ctx, t1410))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1410)) {
  KLObject* t1413;
  {
    KLObject* a1413[] = {t1408};
    t1413 = shen_apply_direct(ctx, "tail", 1, a1413);
  }
  KLObject* t1417 = shen_intern(ctx, "shen.skip");
  KLObject* t1415;
  {
    KLObject* a1415[] = {t1413, t1417};
    t1415 = shen_apply_direct(ctx, "shen.comb", 2, a1415);
  }
    t1409 = t1415;
  } else {
  KLObject* t1418 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t1409 = t1418;
  }
  KLObject* t1420;
  {
    KLObject* a1420[] = {t1409};
    t1420 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a1420);
  }
  KLObject* t1419;
  if (!shen_is_boolean(ctx, t1420))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1420)) {
  KLObject* t1422 = shen_tail_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t1419 = t1422;
  } else {
    t1419 = t1409;
  }
    return t1419;
  }
}

static KLObject* native_kl_shen_2e_3cequal_3e_46 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t1424 = objects[0];
  tail_start_kl_shen_2e_3cequal_3e_46: ;
  KLObject* t1428 = shen_number_l(ctx, 61);
  KLObject* t1426;
  {
    KLObject* a1426[] = {t1424, t1428};
    t1426 = shen_apply_direct(ctx, "shen.hds=?", 2, a1426);
  }
  KLObject* t1425;
  if (!shen_is_boolean(ctx, t1426))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1426)) {
  KLObject* t1429;
  {
    KLObject* a1429[] = {t1424};
    t1429 = shen_apply_direct(ctx, "tail", 1, a1429);
  }
  KLObject* t1433 = shen_intern(ctx, "shen.skip");
  KLObject* t1431;
  {
    KLObject* a1431[] = {t1429, t1433};
    t1431 = shen_apply_direct(ctx, "shen.comb", 2, a1431);
  }
    t1425 = t1431;
  } else {
  KLObject* t1434 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t1425 = t1434;
  }
  KLObject* t1436;
  {
    KLObject* a1436[] = {t1425};
    t1436 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a1436);
  }
  KLObject* t1435;
  if (!shen_is_boolean(ctx, t1436))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1436)) {
  KLObject* t1438 = shen_tail_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t1435 = t1438;
  } else {
    t1435 = t1425;
  }
    return t1435;
  }
}

static KLObject* native_kl_shen_2e_3ccomment_3e_47 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t1440 = objects[0];
  tail_start_kl_shen_2e_3ccomment_3e_47: ;
  KLObject* t1441;
  {
    KLObject* a1441[] = {t1440};
    t1441 = shen_apply_direct(ctx, "shen.<singleline>", 1, a1441);
  }
  KLObject* t1444;
  {
    KLObject* a1444[] = {t1441};
    t1444 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a1444);
  }
  KLObject* t1443;
  if (!shen_is_boolean(ctx, t1444))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1444)) {
  KLObject* t1446 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t1443 = t1446;
  } else {
  KLObject* t1447;
  {
    KLObject* a1447[] = {t1441};
    t1447 = shen_apply_direct(ctx, "shen.in->", 1, a1447);
  }
  KLObject* t1451 = shen_intern(ctx, "shen.skip");
  KLObject* t1449;
  {
    KLObject* a1449[] = {t1447, t1451};
    t1449 = shen_apply_direct(ctx, "shen.comb", 2, a1449);
  }
    t1443 = t1449;
  }
  KLObject* t1453;
  {
    KLObject* a1453[] = {t1443};
    t1453 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a1453);
  }
  KLObject* t1452;
  if (!shen_is_boolean(ctx, t1453))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1453)) {
  KLObject* t1455;
  {
    KLObject* a1455[] = {t1440};
    t1455 = shen_apply_direct(ctx, "shen.<multiline>", 1, a1455);
  }
  KLObject* t1458;
  {
    KLObject* a1458[] = {t1455};
    t1458 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a1458);
  }
  KLObject* t1457;
  if (!shen_is_boolean(ctx, t1458))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1458)) {
  KLObject* t1460 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t1457 = t1460;
  } else {
  KLObject* t1461;
  {
    KLObject* a1461[] = {t1455};
    t1461 = shen_apply_direct(ctx, "shen.in->", 1, a1461);
  }
  KLObject* t1465 = shen_intern(ctx, "shen.skip");
  KLObject* t1463;
  {
    KLObject* a1463[] = {t1461, t1465};
    t1463 = shen_apply_direct(ctx, "shen.comb", 2, a1463);
  }
    t1457 = t1463;
  }
  KLObject* t1467;
  {
    KLObject* a1467[] = {t1457};
    t1467 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a1467);
  }
  KLObject* t1466;
  if (!shen_is_boolean(ctx, t1467))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1467)) {
  KLObject* t1469 = shen_tail_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t1466 = t1469;
  } else {
    t1466 = t1457;
  }
    t1452 = t1466;
  } else {
    t1452 = t1443;
  }
    return t1452;
  }
}

static KLObject* native_kl_shen_2e_3csingleline_3e_48 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t1472 = objects[0];
  tail_start_kl_shen_2e_3csingleline_3e_48: ;
  KLObject* t1473;
  {
    KLObject* a1473[] = {t1472};
    t1473 = shen_apply_direct(ctx, "shen.<backslash>", 1, a1473);
  }
  KLObject* t1476;
  {
    KLObject* a1476[] = {t1473};
    t1476 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a1476);
  }
  KLObject* t1475;
  if (!shen_is_boolean(ctx, t1476))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1476)) {
  KLObject* t1478 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t1475 = t1478;
  } else {
  KLObject* t1479;
  {
    KLObject* a1479[] = {t1473};
    t1479 = shen_apply_direct(ctx, "shen.in->", 1, a1479);
  }
  KLObject* t1481;
  {
    KLObject* a1481[] = {t1479};
    t1481 = shen_apply_direct(ctx, "shen.<backslash>", 1, a1481);
  }
  KLObject* t1484;
  {
    KLObject* a1484[] = {t1481};
    t1484 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a1484);
  }
  KLObject* t1483;
  if (!shen_is_boolean(ctx, t1484))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1484)) {
  KLObject* t1486 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t1483 = t1486;
  } else {
  KLObject* t1487;
  {
    KLObject* a1487[] = {t1481};
    t1487 = shen_apply_direct(ctx, "shen.in->", 1, a1487);
  }
  KLObject* t1489;
  {
    KLObject* a1489[] = {t1487};
    t1489 = shen_apply_direct(ctx, "shen.<shortnatters>", 1, a1489);
  }
  KLObject* t1492;
  {
    KLObject* a1492[] = {t1489};
    t1492 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a1492);
  }
  KLObject* t1491;
  if (!shen_is_boolean(ctx, t1492))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1492)) {
  KLObject* t1494 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t1491 = t1494;
  } else {
  KLObject* t1495;
  {
    KLObject* a1495[] = {t1489};
    t1495 = shen_apply_direct(ctx, "shen.in->", 1, a1495);
  }
  KLObject* t1497;
  {
    KLObject* a1497[] = {t1495};
    t1497 = shen_apply_direct(ctx, "shen.<returns>", 1, a1497);
  }
  KLObject* t1500;
  {
    KLObject* a1500[] = {t1497};
    t1500 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a1500);
  }
  KLObject* t1499;
  if (!shen_is_boolean(ctx, t1500))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1500)) {
  KLObject* t1502 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t1499 = t1502;
  } else {
  KLObject* t1503;
  {
    KLObject* a1503[] = {t1497};
    t1503 = shen_apply_direct(ctx, "shen.in->", 1, a1503);
  }
  KLObject* t1507 = shen_intern(ctx, "shen.skip");
  KLObject* t1505;
  {
    KLObject* a1505[] = {t1503, t1507};
    t1505 = shen_apply_direct(ctx, "shen.comb", 2, a1505);
  }
    t1499 = t1505;
  }
    t1491 = t1499;
  }
    t1483 = t1491;
  }
    t1475 = t1483;
  }
  KLObject* t1509;
  {
    KLObject* a1509[] = {t1475};
    t1509 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a1509);
  }
  KLObject* t1508;
  if (!shen_is_boolean(ctx, t1509))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1509)) {
  KLObject* t1511 = shen_tail_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t1508 = t1511;
  } else {
    t1508 = t1475;
  }
    return t1508;
  }
}

static KLObject* native_kl_shen_2e_3cbackslash_3e_49 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t1513 = objects[0];
  tail_start_kl_shen_2e_3cbackslash_3e_49: ;
  KLObject* t1517 = shen_number_l(ctx, 92);
  KLObject* t1515;
  {
    KLObject* a1515[] = {t1513, t1517};
    t1515 = shen_apply_direct(ctx, "shen.hds=?", 2, a1515);
  }
  KLObject* t1514;
  if (!shen_is_boolean(ctx, t1515))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1515)) {
  KLObject* t1518;
  {
    KLObject* a1518[] = {t1513};
    t1518 = shen_apply_direct(ctx, "tail", 1, a1518);
  }
  KLObject* t1522 = shen_intern(ctx, "shen.skip");
  KLObject* t1520;
  {
    KLObject* a1520[] = {t1518, t1522};
    t1520 = shen_apply_direct(ctx, "shen.comb", 2, a1520);
  }
    t1514 = t1520;
  } else {
  KLObject* t1523 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t1514 = t1523;
  }
  KLObject* t1525;
  {
    KLObject* a1525[] = {t1514};
    t1525 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a1525);
  }
  KLObject* t1524;
  if (!shen_is_boolean(ctx, t1525))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1525)) {
  KLObject* t1527 = shen_tail_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t1524 = t1527;
  } else {
    t1524 = t1514;
  }
    return t1524;
  }
}

static KLObject* native_kl_shen_2e_3cshortnatters_3e_50 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t1529 = objects[0];
  tail_start_kl_shen_2e_3cshortnatters_3e_50: ;
  KLObject* t1530;
  {
    KLObject* a1530[] = {t1529};
    t1530 = shen_apply_direct(ctx, "shen.<shortnatter>", 1, a1530);
  }
  KLObject* t1533;
  {
    KLObject* a1533[] = {t1530};
    t1533 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a1533);
  }
  KLObject* t1532;
  if (!shen_is_boolean(ctx, t1533))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1533)) {
  KLObject* t1535 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t1532 = t1535;
  } else {
  KLObject* t1536;
  {
    KLObject* a1536[] = {t1530};
    t1536 = shen_apply_direct(ctx, "shen.in->", 1, a1536);
  }
  KLObject* t1538;
  {
    KLObject* a1538[] = {t1536};
    t1538 = shen_apply_direct(ctx, "shen.<shortnatters>", 1, a1538);
  }
  KLObject* t1541;
  {
    KLObject* a1541[] = {t1538};
    t1541 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a1541);
  }
  KLObject* t1540;
  if (!shen_is_boolean(ctx, t1541))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1541)) {
  KLObject* t1543 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t1540 = t1543;
  } else {
  KLObject* t1544;
  {
    KLObject* a1544[] = {t1538};
    t1544 = shen_apply_direct(ctx, "shen.in->", 1, a1544);
  }
  KLObject* t1548 = shen_intern(ctx, "shen.skip");
  KLObject* t1546;
  {
    KLObject* a1546[] = {t1544, t1548};
    t1546 = shen_apply_direct(ctx, "shen.comb", 2, a1546);
  }
    t1540 = t1546;
  }
    t1532 = t1540;
  }
  KLObject* t1550;
  {
    KLObject* a1550[] = {t1532};
    t1550 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a1550);
  }
  KLObject* t1549;
  if (!shen_is_boolean(ctx, t1550))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1550)) {
  KLObject* t1552;
  {
    KLObject* a1552[] = {t1529};
    t1552 = shen_apply_direct(ctx, "<e>", 1, a1552);
  }
  KLObject* t1555;
  {
    KLObject* a1555[] = {t1552};
    t1555 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a1555);
  }
  KLObject* t1554;
  if (!shen_is_boolean(ctx, t1555))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1555)) {
  KLObject* t1557 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t1554 = t1557;
  } else {
  KLObject* t1558;
  {
    KLObject* a1558[] = {t1552};
    t1558 = shen_apply_direct(ctx, "shen.in->", 1, a1558);
  }
  KLObject* t1562 = shen_intern(ctx, "shen.skip");
  KLObject* t1560;
  {
    KLObject* a1560[] = {t1558, t1562};
    t1560 = shen_apply_direct(ctx, "shen.comb", 2, a1560);
  }
    t1554 = t1560;
  }
  KLObject* t1564;
  {
    KLObject* a1564[] = {t1554};
    t1564 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a1564);
  }
  KLObject* t1563;
  if (!shen_is_boolean(ctx, t1564))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1564)) {
  KLObject* t1566 = shen_tail_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t1563 = t1566;
  } else {
    t1563 = t1554;
  }
    t1549 = t1563;
  } else {
    t1549 = t1532;
  }
    return t1549;
  }
}

static KLObject* native_kl_shen_2e_3cshortnatter_3e_51 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t1569 = objects[0];
  tail_start_kl_shen_2e_3cshortnatter_3e_51: ;
  KLObject* t1572 = shen_cons_p(ctx, t1569);
  KLObject* t1570;
  if (!shen_is_boolean(ctx, t1572))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1572)) {
  KLObject* t1573;
  {
    KLObject* a1573[] = {t1569};
    t1573 = shen_apply_direct(ctx, "head", 1, a1573);
  }
  KLObject* t1575;
  {
    KLObject* a1575[] = {t1569};
    t1575 = shen_apply_direct(ctx, "tail", 1, a1575);
  }
  KLObject* t1579;
  {
    KLObject* a1579[] = {t1573};
    t1579 = shen_apply_direct(ctx, "shen.return?", 1, a1579);
  }
  KLObject* t1578;
  {
    KLObject* a1578[] = {t1579};
    t1578 = shen_apply_direct(ctx, "not", 1, a1578);
  }
  KLObject* t1577;
  if (!shen_is_boolean(ctx, t1578))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1578)) {
  KLObject* t1583 = shen_intern(ctx, "shen.skip");
  KLObject* t1581;
  {
    KLObject* a1581[] = {t1575, t1583};
    t1581 = shen_apply_direct(ctx, "shen.comb", 2, a1581);
  }
    t1577 = t1581;
  } else {
  KLObject* t1584 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t1577 = t1584;
  }
    t1570 = t1577;
  } else {
  KLObject* t1585 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t1570 = t1585;
  }
  KLObject* t1587;
  {
    KLObject* a1587[] = {t1570};
    t1587 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a1587);
  }
  KLObject* t1586;
  if (!shen_is_boolean(ctx, t1587))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1587)) {
  KLObject* t1589 = shen_tail_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t1586 = t1589;
  } else {
    t1586 = t1570;
  }
    return t1586;
  }
}

static KLObject* native_kl_shen_2e_3creturns_3e_52 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t1591 = objects[0];
  tail_start_kl_shen_2e_3creturns_3e_52: ;
  KLObject* t1592;
  {
    KLObject* a1592[] = {t1591};
    t1592 = shen_apply_direct(ctx, "shen.<return>", 1, a1592);
  }
  KLObject* t1595;
  {
    KLObject* a1595[] = {t1592};
    t1595 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a1595);
  }
  KLObject* t1594;
  if (!shen_is_boolean(ctx, t1595))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1595)) {
  KLObject* t1597 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t1594 = t1597;
  } else {
  KLObject* t1598;
  {
    KLObject* a1598[] = {t1592};
    t1598 = shen_apply_direct(ctx, "shen.in->", 1, a1598);
  }
  KLObject* t1600;
  {
    KLObject* a1600[] = {t1598};
    t1600 = shen_apply_direct(ctx, "shen.<returns>", 1, a1600);
  }
  KLObject* t1603;
  {
    KLObject* a1603[] = {t1600};
    t1603 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a1603);
  }
  KLObject* t1602;
  if (!shen_is_boolean(ctx, t1603))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1603)) {
  KLObject* t1605 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t1602 = t1605;
  } else {
  KLObject* t1606;
  {
    KLObject* a1606[] = {t1600};
    t1606 = shen_apply_direct(ctx, "shen.in->", 1, a1606);
  }
  KLObject* t1610 = shen_intern(ctx, "shen.skip");
  KLObject* t1608;
  {
    KLObject* a1608[] = {t1606, t1610};
    t1608 = shen_apply_direct(ctx, "shen.comb", 2, a1608);
  }
    t1602 = t1608;
  }
    t1594 = t1602;
  }
  KLObject* t1612;
  {
    KLObject* a1612[] = {t1594};
    t1612 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a1612);
  }
  KLObject* t1611;
  if (!shen_is_boolean(ctx, t1612))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1612)) {
  KLObject* t1614;
  {
    KLObject* a1614[] = {t1591};
    t1614 = shen_apply_direct(ctx, "shen.<return>", 1, a1614);
  }
  KLObject* t1617;
  {
    KLObject* a1617[] = {t1614};
    t1617 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a1617);
  }
  KLObject* t1616;
  if (!shen_is_boolean(ctx, t1617))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1617)) {
  KLObject* t1619 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t1616 = t1619;
  } else {
  KLObject* t1620;
  {
    KLObject* a1620[] = {t1614};
    t1620 = shen_apply_direct(ctx, "shen.in->", 1, a1620);
  }
  KLObject* t1624 = shen_intern(ctx, "shen.skip");
  KLObject* t1622;
  {
    KLObject* a1622[] = {t1620, t1624};
    t1622 = shen_apply_direct(ctx, "shen.comb", 2, a1622);
  }
    t1616 = t1622;
  }
  KLObject* t1626;
  {
    KLObject* a1626[] = {t1616};
    t1626 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a1626);
  }
  KLObject* t1625;
  if (!shen_is_boolean(ctx, t1626))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1626)) {
  KLObject* t1628 = shen_tail_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t1625 = t1628;
  } else {
    t1625 = t1616;
  }
    t1611 = t1625;
  } else {
    t1611 = t1594;
  }
    return t1611;
  }
}

static KLObject* native_kl_shen_2e_3creturn_3e_53 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t1631 = objects[0];
  tail_start_kl_shen_2e_3creturn_3e_53: ;
  KLObject* t1634 = shen_cons_p(ctx, t1631);
  KLObject* t1632;
  if (!shen_is_boolean(ctx, t1634))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1634)) {
  KLObject* t1635;
  {
    KLObject* a1635[] = {t1631};
    t1635 = shen_apply_direct(ctx, "head", 1, a1635);
  }
  KLObject* t1637;
  {
    KLObject* a1637[] = {t1631};
    t1637 = shen_apply_direct(ctx, "tail", 1, a1637);
  }
  KLObject* t1640;
  {
    KLObject* a1640[] = {t1635};
    t1640 = shen_apply_direct(ctx, "shen.return?", 1, a1640);
  }
  KLObject* t1639;
  if (!shen_is_boolean(ctx, t1640))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1640)) {
  KLObject* t1644 = shen_intern(ctx, "shen.skip");
  KLObject* t1642;
  {
    KLObject* a1642[] = {t1637, t1644};
    t1642 = shen_apply_direct(ctx, "shen.comb", 2, a1642);
  }
    t1639 = t1642;
  } else {
  KLObject* t1645 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t1639 = t1645;
  }
    t1632 = t1639;
  } else {
  KLObject* t1646 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t1632 = t1646;
  }
  KLObject* t1648;
  {
    KLObject* a1648[] = {t1632};
    t1648 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a1648);
  }
  KLObject* t1647;
  if (!shen_is_boolean(ctx, t1648))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1648)) {
  KLObject* t1650 = shen_tail_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t1647 = t1650;
  } else {
    t1647 = t1632;
  }
    return t1647;
  }
}

static KLObject* native_kl_shen_2ereturn_3f_54 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t1652 = objects[0];
  tail_start_kl_shen_2ereturn_3f_54: ;
  KLObject* t1655 = shen_number_l(ctx, 9);
  KLObject* t1656 = shen_number_l(ctx, 10);
  KLObject* t1657 = shen_number_l(ctx, 13);
  KLObject* t1658 = shen_empty_list(ctx);
  KLObject* t1659 = shen_cons(ctx, t1657, t1658);
  KLObject* t1660 = shen_cons(ctx, t1656, t1659);
  KLObject* t1661 = shen_cons(ctx, t1655, t1660);
  KLObject* t1653;
  {
    KLObject* a1653[] = {t1652, t1661};
    t1653 = shen_tail_apply_direct(ctx, "element?", 2, a1653);
  }
    return t1653;
  }
}

static KLObject* native_kl_shen_2e_3cmultiline_3e_55 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t1662 = objects[0];
  tail_start_kl_shen_2e_3cmultiline_3e_55: ;
  KLObject* t1663;
  {
    KLObject* a1663[] = {t1662};
    t1663 = shen_apply_direct(ctx, "shen.<backslash>", 1, a1663);
  }
  KLObject* t1666;
  {
    KLObject* a1666[] = {t1663};
    t1666 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a1666);
  }
  KLObject* t1665;
  if (!shen_is_boolean(ctx, t1666))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1666)) {
  KLObject* t1668 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t1665 = t1668;
  } else {
  KLObject* t1669;
  {
    KLObject* a1669[] = {t1663};
    t1669 = shen_apply_direct(ctx, "shen.in->", 1, a1669);
  }
  KLObject* t1671;
  {
    KLObject* a1671[] = {t1669};
    t1671 = shen_apply_direct(ctx, "shen.<times>", 1, a1671);
  }
  KLObject* t1674;
  {
    KLObject* a1674[] = {t1671};
    t1674 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a1674);
  }
  KLObject* t1673;
  if (!shen_is_boolean(ctx, t1674))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1674)) {
  KLObject* t1676 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t1673 = t1676;
  } else {
  KLObject* t1677;
  {
    KLObject* a1677[] = {t1671};
    t1677 = shen_apply_direct(ctx, "shen.in->", 1, a1677);
  }
  KLObject* t1679;
  {
    KLObject* a1679[] = {t1677};
    t1679 = shen_apply_direct(ctx, "shen.<longnatter>", 1, a1679);
  }
  KLObject* t1682;
  {
    KLObject* a1682[] = {t1679};
    t1682 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a1682);
  }
  KLObject* t1681;
  if (!shen_is_boolean(ctx, t1682))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1682)) {
  KLObject* t1684 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t1681 = t1684;
  } else {
  KLObject* t1685;
  {
    KLObject* a1685[] = {t1679};
    t1685 = shen_apply_direct(ctx, "shen.in->", 1, a1685);
  }
  KLObject* t1689 = shen_intern(ctx, "shen.skip");
  KLObject* t1687;
  {
    KLObject* a1687[] = {t1685, t1689};
    t1687 = shen_apply_direct(ctx, "shen.comb", 2, a1687);
  }
    t1681 = t1687;
  }
    t1673 = t1681;
  }
    t1665 = t1673;
  }
  KLObject* t1691;
  {
    KLObject* a1691[] = {t1665};
    t1691 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a1691);
  }
  KLObject* t1690;
  if (!shen_is_boolean(ctx, t1691))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1691)) {
  KLObject* t1693 = shen_tail_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t1690 = t1693;
  } else {
    t1690 = t1665;
  }
    return t1690;
  }
}

static KLObject* native_kl_shen_2e_3ctimes_3e_56 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t1695 = objects[0];
  tail_start_kl_shen_2e_3ctimes_3e_56: ;
  KLObject* t1699 = shen_number_l(ctx, 42);
  KLObject* t1697;
  {
    KLObject* a1697[] = {t1695, t1699};
    t1697 = shen_apply_direct(ctx, "shen.hds=?", 2, a1697);
  }
  KLObject* t1696;
  if (!shen_is_boolean(ctx, t1697))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1697)) {
  KLObject* t1700;
  {
    KLObject* a1700[] = {t1695};
    t1700 = shen_apply_direct(ctx, "tail", 1, a1700);
  }
  KLObject* t1704 = shen_intern(ctx, "shen.skip");
  KLObject* t1702;
  {
    KLObject* a1702[] = {t1700, t1704};
    t1702 = shen_apply_direct(ctx, "shen.comb", 2, a1702);
  }
    t1696 = t1702;
  } else {
  KLObject* t1705 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t1696 = t1705;
  }
  KLObject* t1707;
  {
    KLObject* a1707[] = {t1696};
    t1707 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a1707);
  }
  KLObject* t1706;
  if (!shen_is_boolean(ctx, t1707))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1707)) {
  KLObject* t1709 = shen_tail_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t1706 = t1709;
  } else {
    t1706 = t1696;
  }
    return t1706;
  }
}

static KLObject* native_kl_shen_2e_3clongnatter_3e_57 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t1711 = objects[0];
  tail_start_kl_shen_2e_3clongnatter_3e_57: ;
  KLObject* t1712;
  {
    KLObject* a1712[] = {t1711};
    t1712 = shen_apply_direct(ctx, "shen.<comment>", 1, a1712);
  }
  KLObject* t1715;
  {
    KLObject* a1715[] = {t1712};
    t1715 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a1715);
  }
  KLObject* t1714;
  if (!shen_is_boolean(ctx, t1715))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1715)) {
  KLObject* t1717 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t1714 = t1717;
  } else {
  KLObject* t1718;
  {
    KLObject* a1718[] = {t1712};
    t1718 = shen_apply_direct(ctx, "shen.in->", 1, a1718);
  }
  KLObject* t1720;
  {
    KLObject* a1720[] = {t1718};
    t1720 = shen_apply_direct(ctx, "shen.<longnatter>", 1, a1720);
  }
  KLObject* t1723;
  {
    KLObject* a1723[] = {t1720};
    t1723 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a1723);
  }
  KLObject* t1722;
  if (!shen_is_boolean(ctx, t1723))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1723)) {
  KLObject* t1725 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t1722 = t1725;
  } else {
  KLObject* t1726;
  {
    KLObject* a1726[] = {t1720};
    t1726 = shen_apply_direct(ctx, "shen.in->", 1, a1726);
  }
  KLObject* t1730 = shen_intern(ctx, "shen.skip");
  KLObject* t1728;
  {
    KLObject* a1728[] = {t1726, t1730};
    t1728 = shen_apply_direct(ctx, "shen.comb", 2, a1728);
  }
    t1722 = t1728;
  }
    t1714 = t1722;
  }
  KLObject* t1732;
  {
    KLObject* a1732[] = {t1714};
    t1732 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a1732);
  }
  KLObject* t1731;
  if (!shen_is_boolean(ctx, t1732))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1732)) {
  KLObject* t1734;
  {
    KLObject* a1734[] = {t1711};
    t1734 = shen_apply_direct(ctx, "shen.<times>", 1, a1734);
  }
  KLObject* t1737;
  {
    KLObject* a1737[] = {t1734};
    t1737 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a1737);
  }
  KLObject* t1736;
  if (!shen_is_boolean(ctx, t1737))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1737)) {
  KLObject* t1739 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t1736 = t1739;
  } else {
  KLObject* t1740;
  {
    KLObject* a1740[] = {t1734};
    t1740 = shen_apply_direct(ctx, "shen.in->", 1, a1740);
  }
  KLObject* t1742;
  {
    KLObject* a1742[] = {t1740};
    t1742 = shen_apply_direct(ctx, "shen.<backslash>", 1, a1742);
  }
  KLObject* t1745;
  {
    KLObject* a1745[] = {t1742};
    t1745 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a1745);
  }
  KLObject* t1744;
  if (!shen_is_boolean(ctx, t1745))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1745)) {
  KLObject* t1747 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t1744 = t1747;
  } else {
  KLObject* t1748;
  {
    KLObject* a1748[] = {t1742};
    t1748 = shen_apply_direct(ctx, "shen.in->", 1, a1748);
  }
  KLObject* t1752 = shen_intern(ctx, "shen.skip");
  KLObject* t1750;
  {
    KLObject* a1750[] = {t1748, t1752};
    t1750 = shen_apply_direct(ctx, "shen.comb", 2, a1750);
  }
    t1744 = t1750;
  }
    t1736 = t1744;
  }
  KLObject* t1754;
  {
    KLObject* a1754[] = {t1736};
    t1754 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a1754);
  }
  KLObject* t1753;
  if (!shen_is_boolean(ctx, t1754))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1754)) {
  KLObject* t1758 = shen_cons_p(ctx, t1711);
  KLObject* t1756;
  if (!shen_is_boolean(ctx, t1758))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1758)) {
  KLObject* t1759;
  {
    KLObject* a1759[] = {t1711};
    t1759 = shen_apply_direct(ctx, "tail", 1, a1759);
  }
  KLObject* t1761;
  {
    KLObject* a1761[] = {t1759};
    t1761 = shen_apply_direct(ctx, "shen.<longnatter>", 1, a1761);
  }
  KLObject* t1764;
  {
    KLObject* a1764[] = {t1761};
    t1764 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a1764);
  }
  KLObject* t1763;
  if (!shen_is_boolean(ctx, t1764))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1764)) {
  KLObject* t1766 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t1763 = t1766;
  } else {
  KLObject* t1767;
  {
    KLObject* a1767[] = {t1761};
    t1767 = shen_apply_direct(ctx, "shen.in->", 1, a1767);
  }
  KLObject* t1771 = shen_intern(ctx, "shen.skip");
  KLObject* t1769;
  {
    KLObject* a1769[] = {t1767, t1771};
    t1769 = shen_apply_direct(ctx, "shen.comb", 2, a1769);
  }
    t1763 = t1769;
  }
    t1756 = t1763;
  } else {
  KLObject* t1772 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t1756 = t1772;
  }
  KLObject* t1774;
  {
    KLObject* a1774[] = {t1756};
    t1774 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a1774);
  }
  KLObject* t1773;
  if (!shen_is_boolean(ctx, t1774))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1774)) {
  KLObject* t1776 = shen_tail_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t1773 = t1776;
  } else {
    t1773 = t1756;
  }
    t1753 = t1773;
  } else {
    t1753 = t1736;
  }
    t1731 = t1753;
  } else {
    t1731 = t1714;
  }
    return t1731;
  }
}

static KLObject* native_kl_shen_2e_3catom_3e_58 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t1780 = objects[0];
  tail_start_kl_shen_2e_3catom_3e_58: ;
  KLObject* t1781;
  {
    KLObject* a1781[] = {t1780};
    t1781 = shen_apply_direct(ctx, "shen.<str>", 1, a1781);
  }
  KLObject* t1784;
  {
    KLObject* a1784[] = {t1781};
    t1784 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a1784);
  }
  KLObject* t1783;
  if (!shen_is_boolean(ctx, t1784))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1784)) {
  KLObject* t1786 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t1783 = t1786;
  } else {
  KLObject* t1787;
  {
    KLObject* a1787[] = {t1781};
    t1787 = shen_apply_direct(ctx, "shen.<-out", 1, a1787);
  }
  KLObject* t1789;
  {
    KLObject* a1789[] = {t1781};
    t1789 = shen_apply_direct(ctx, "shen.in->", 1, a1789);
  }
  KLObject* t1791;
  {
    KLObject* a1791[] = {t1789, t1787};
    t1791 = shen_apply_direct(ctx, "shen.comb", 2, a1791);
  }
    t1783 = t1791;
  }
  KLObject* t1795;
  {
    KLObject* a1795[] = {t1783};
    t1795 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a1795);
  }
  KLObject* t1794;
  if (!shen_is_boolean(ctx, t1795))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1795)) {
  KLObject* t1797;
  {
    KLObject* a1797[] = {t1780};
    t1797 = shen_apply_direct(ctx, "shen.<number>", 1, a1797);
  }
  KLObject* t1800;
  {
    KLObject* a1800[] = {t1797};
    t1800 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a1800);
  }
  KLObject* t1799;
  if (!shen_is_boolean(ctx, t1800))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1800)) {
  KLObject* t1802 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t1799 = t1802;
  } else {
  KLObject* t1803;
  {
    KLObject* a1803[] = {t1797};
    t1803 = shen_apply_direct(ctx, "shen.<-out", 1, a1803);
  }
  KLObject* t1805;
  {
    KLObject* a1805[] = {t1797};
    t1805 = shen_apply_direct(ctx, "shen.in->", 1, a1805);
  }
  KLObject* t1807;
  {
    KLObject* a1807[] = {t1805, t1803};
    t1807 = shen_apply_direct(ctx, "shen.comb", 2, a1807);
  }
    t1799 = t1807;
  }
  KLObject* t1811;
  {
    KLObject* a1811[] = {t1799};
    t1811 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a1811);
  }
  KLObject* t1810;
  if (!shen_is_boolean(ctx, t1811))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1811)) {
  KLObject* t1813;
  {
    KLObject* a1813[] = {t1780};
    t1813 = shen_apply_direct(ctx, "shen.<sym>", 1, a1813);
  }
  KLObject* t1816;
  {
    KLObject* a1816[] = {t1813};
    t1816 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a1816);
  }
  KLObject* t1815;
  if (!shen_is_boolean(ctx, t1816))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1816)) {
  KLObject* t1818 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t1815 = t1818;
  } else {
  KLObject* t1819;
  {
    KLObject* a1819[] = {t1813};
    t1819 = shen_apply_direct(ctx, "shen.<-out", 1, a1819);
  }
  KLObject* t1821;
  {
    KLObject* a1821[] = {t1813};
    t1821 = shen_apply_direct(ctx, "shen.in->", 1, a1821);
  }
  KLObject* t1827 = shen_string(ctx, "<>");
  KLObject* t1828 = shen_eq(ctx, t1819, t1827);
  KLObject* t1825;
  if (!shen_is_boolean(ctx, t1828))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1828)) {
  KLObject* t1829 = shen_intern(ctx, "vector");
  KLObject* t1830 = shen_number_l(ctx, 0);
  KLObject* t1831 = shen_empty_list(ctx);
  KLObject* t1832 = shen_cons(ctx, t1830, t1831);
  KLObject* t1833 = shen_cons(ctx, t1829, t1832);
    t1825 = t1833;
  } else {
  KLObject* t1834;
  {
    KLObject* a1834[] = {t1819};
    t1834 = shen_apply_direct(ctx, "intern", 1, a1834);
  }
    t1825 = t1834;
  }
  KLObject* t1823;
  {
    KLObject* a1823[] = {t1821, t1825};
    t1823 = shen_apply_direct(ctx, "shen.comb", 2, a1823);
  }
    t1815 = t1823;
  }
  KLObject* t1837;
  {
    KLObject* a1837[] = {t1815};
    t1837 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a1837);
  }
  KLObject* t1836;
  if (!shen_is_boolean(ctx, t1837))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1837)) {
  KLObject* t1839 = shen_tail_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t1836 = t1839;
  } else {
    t1836 = t1815;
  }
    t1810 = t1836;
  } else {
    t1810 = t1799;
  }
    t1794 = t1810;
  } else {
    t1794 = t1783;
  }
    return t1794;
  }
}

static KLObject* native_kl_shen_2e_3csym_3e_59 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t1843 = objects[0];
  tail_start_kl_shen_2e_3csym_3e_59: ;
  KLObject* t1844;
  {
    KLObject* a1844[] = {t1843};
    t1844 = shen_apply_direct(ctx, "shen.<alpha>", 1, a1844);
  }
  KLObject* t1847;
  {
    KLObject* a1847[] = {t1844};
    t1847 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a1847);
  }
  KLObject* t1846;
  if (!shen_is_boolean(ctx, t1847))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1847)) {
  KLObject* t1849 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t1846 = t1849;
  } else {
  KLObject* t1850;
  {
    KLObject* a1850[] = {t1844};
    t1850 = shen_apply_direct(ctx, "shen.<-out", 1, a1850);
  }
  KLObject* t1852;
  {
    KLObject* a1852[] = {t1844};
    t1852 = shen_apply_direct(ctx, "shen.in->", 1, a1852);
  }
  KLObject* t1854;
  {
    KLObject* a1854[] = {t1852};
    t1854 = shen_apply_direct(ctx, "shen.<alphanums>", 1, a1854);
  }
  KLObject* t1857;
  {
    KLObject* a1857[] = {t1854};
    t1857 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a1857);
  }
  KLObject* t1856;
  if (!shen_is_boolean(ctx, t1857))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1857)) {
  KLObject* t1859 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t1856 = t1859;
  } else {
  KLObject* t1860;
  {
    KLObject* a1860[] = {t1854};
    t1860 = shen_apply_direct(ctx, "shen.<-out", 1, a1860);
  }
  KLObject* t1862;
  {
    KLObject* a1862[] = {t1854};
    t1862 = shen_apply_direct(ctx, "shen.in->", 1, a1862);
  }
  KLObject* t1866;
  {
    KLObject* a1866[] = {t1850, t1860};
    t1866 = shen_apply_direct(ctx, "cn", 2, a1866);
  }
  KLObject* t1864;
  {
    KLObject* a1864[] = {t1862, t1866};
    t1864 = shen_apply_direct(ctx, "shen.comb", 2, a1864);
  }
    t1856 = t1864;
  }
    t1846 = t1856;
  }
  KLObject* t1870;
  {
    KLObject* a1870[] = {t1846};
    t1870 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a1870);
  }
  KLObject* t1869;
  if (!shen_is_boolean(ctx, t1870))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1870)) {
  KLObject* t1872 = shen_tail_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t1869 = t1872;
  } else {
    t1869 = t1846;
  }
    return t1869;
  }
}

static KLObject* native_kl_shen_2e_3calpha_3e_60 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t1874 = objects[0];
  tail_start_kl_shen_2e_3calpha_3e_60: ;
  KLObject* t1877 = shen_cons_p(ctx, t1874);
  KLObject* t1875;
  if (!shen_is_boolean(ctx, t1877))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1877)) {
  KLObject* t1878;
  {
    KLObject* a1878[] = {t1874};
    t1878 = shen_apply_direct(ctx, "head", 1, a1878);
  }
  KLObject* t1880;
  {
    KLObject* a1880[] = {t1874};
    t1880 = shen_apply_direct(ctx, "tail", 1, a1880);
  }
  KLObject* t1883;
  {
    KLObject* a1883[] = {t1878};
    t1883 = shen_apply_direct(ctx, "shen.alpha?", 1, a1883);
  }
  KLObject* t1882;
  if (!shen_is_boolean(ctx, t1883))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1883)) {
  KLObject* t1887;
  {
    KLObject* a1887[] = {t1878};
    t1887 = shen_apply_direct(ctx, "n->string", 1, a1887);
  }
  KLObject* t1885;
  {
    KLObject* a1885[] = {t1880, t1887};
    t1885 = shen_apply_direct(ctx, "shen.comb", 2, a1885);
  }
    t1882 = t1885;
  } else {
  KLObject* t1889 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t1882 = t1889;
  }
    t1875 = t1882;
  } else {
  KLObject* t1890 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t1875 = t1890;
  }
  KLObject* t1892;
  {
    KLObject* a1892[] = {t1875};
    t1892 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a1892);
  }
  KLObject* t1891;
  if (!shen_is_boolean(ctx, t1892))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1892)) {
  KLObject* t1894 = shen_tail_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t1891 = t1894;
  } else {
    t1891 = t1875;
  }
    return t1891;
  }
}

static KLObject* native_kl_shen_2ealpha_3f_61 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t1896 = objects[0];
  tail_start_kl_shen_2ealpha_3f_61: ;
  KLObject* t1898;
  {
    KLObject* a1898[] = {t1896};
    t1898 = shen_apply_direct(ctx, "shen.lowercase?", 1, a1898);
  }
  KLObject* t1897;
  if (!shen_is_boolean(ctx, t1898))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (shen_boolean_value(ctx, t1898)) {
    t1897 = t1898;
  } else {
  KLObject* t1901;
  {
    KLObject* a1901[] = {t1896};
    t1901 = shen_apply_direct(ctx, "shen.uppercase?", 1, a1901);
  }
  KLObject* t1900;
  if (!shen_is_boolean(ctx, t1901))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (shen_boolean_value(ctx, t1901)) {
    t1900 = t1901;
  } else {
  KLObject* t1903;
  {
    KLObject* a1903[] = {t1896};
    t1903 = shen_apply_direct(ctx, "shen.misc?", 1, a1903);
  }
    if (!shen_is_boolean(ctx, t1903))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t1900 = t1903;
  }
    if (!shen_is_boolean(ctx, t1900))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t1897 = t1900;
  }
    return t1897;
  }
}

static KLObject* native_kl_shen_2elowercase_3f_62 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t1905 = objects[0];
  tail_start_kl_shen_2elowercase_3f_62: ;
  KLObject* t1908 = shen_number_l(ctx, 97);
  KLObject* t1909 = shen_gte(ctx, t1905, t1908);
  KLObject* t1906;
  if (!shen_is_boolean(ctx, t1909))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t1909)) {
    t1906 = t1909;
  } else {
  KLObject* t1911 = shen_number_l(ctx, 122);
  KLObject* t1912 = shen_lte(ctx, t1905, t1911);
    if (!shen_is_boolean(ctx, t1912))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t1906 = t1912;
  }
    return t1906;
  }
}

static KLObject* native_kl_shen_2euppercase_3f_63 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t1913 = objects[0];
  tail_start_kl_shen_2euppercase_3f_63: ;
  KLObject* t1916 = shen_number_l(ctx, 65);
  KLObject* t1917 = shen_gte(ctx, t1913, t1916);
  KLObject* t1914;
  if (!shen_is_boolean(ctx, t1917))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t1917)) {
    t1914 = t1917;
  } else {
  KLObject* t1919 = shen_number_l(ctx, 90);
  KLObject* t1920 = shen_lte(ctx, t1913, t1919);
    if (!shen_is_boolean(ctx, t1920))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t1914 = t1920;
  }
    return t1914;
  }
}

static KLObject* native_kl_shen_2emisc_3f_64 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t1921 = objects[0];
  tail_start_kl_shen_2emisc_3f_64: ;
  KLObject* t1924 = shen_number_l(ctx, 61);
  KLObject* t1925 = shen_number_l(ctx, 45);
  KLObject* t1926 = shen_number_l(ctx, 42);
  KLObject* t1927 = shen_number_l(ctx, 47);
  KLObject* t1928 = shen_number_l(ctx, 43);
  KLObject* t1929 = shen_number_l(ctx, 95);
  KLObject* t1930 = shen_number_l(ctx, 63);
  KLObject* t1931 = shen_number_l(ctx, 36);
  KLObject* t1932 = shen_number_l(ctx, 33);
  KLObject* t1933 = shen_number_l(ctx, 64);
  KLObject* t1934 = shen_number_l(ctx, 126);
  KLObject* t1935 = shen_number_l(ctx, 46);
  KLObject* t1936 = shen_number_l(ctx, 62);
  KLObject* t1937 = shen_number_l(ctx, 60);
  KLObject* t1938 = shen_number_l(ctx, 38);
  KLObject* t1939 = shen_number_l(ctx, 37);
  KLObject* t1940 = shen_number_l(ctx, 39);
  KLObject* t1941 = shen_number_l(ctx, 35);
  KLObject* t1942 = shen_number_l(ctx, 96);
  KLObject* t1943 = shen_empty_list(ctx);
  KLObject* t1944 = shen_cons(ctx, t1942, t1943);
  KLObject* t1945 = shen_cons(ctx, t1941, t1944);
  KLObject* t1946 = shen_cons(ctx, t1940, t1945);
  KLObject* t1947 = shen_cons(ctx, t1939, t1946);
  KLObject* t1948 = shen_cons(ctx, t1938, t1947);
  KLObject* t1949 = shen_cons(ctx, t1937, t1948);
  KLObject* t1950 = shen_cons(ctx, t1936, t1949);
  KLObject* t1951 = shen_cons(ctx, t1935, t1950);
  KLObject* t1952 = shen_cons(ctx, t1934, t1951);
  KLObject* t1953 = shen_cons(ctx, t1933, t1952);
  KLObject* t1954 = shen_cons(ctx, t1932, t1953);
  KLObject* t1955 = shen_cons(ctx, t1931, t1954);
  KLObject* t1956 = shen_cons(ctx, t1930, t1955);
  KLObject* t1957 = shen_cons(ctx, t1929, t1956);
  KLObject* t1958 = shen_cons(ctx, t1928, t1957);
  KLObject* t1959 = shen_cons(ctx, t1927, t1958);
  KLObject* t1960 = shen_cons(ctx, t1926, t1959);
  KLObject* t1961 = shen_cons(ctx, t1925, t1960);
  KLObject* t1962 = shen_cons(ctx, t1924, t1961);
  KLObject* t1922;
  {
    KLObject* a1922[] = {t1921, t1962};
    t1922 = shen_tail_apply_direct(ctx, "element?", 2, a1922);
  }
    return t1922;
  }
}

static KLObject* native_kl_shen_2e_3calphanums_3e_65 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t1963 = objects[0];
  tail_start_kl_shen_2e_3calphanums_3e_65: ;
  KLObject* t1964;
  {
    KLObject* a1964[] = {t1963};
    t1964 = shen_apply_direct(ctx, "shen.<alphanum>", 1, a1964);
  }
  KLObject* t1967;
  {
    KLObject* a1967[] = {t1964};
    t1967 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a1967);
  }
  KLObject* t1966;
  if (!shen_is_boolean(ctx, t1967))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1967)) {
  KLObject* t1969 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t1966 = t1969;
  } else {
  KLObject* t1970;
  {
    KLObject* a1970[] = {t1964};
    t1970 = shen_apply_direct(ctx, "shen.<-out", 1, a1970);
  }
  KLObject* t1972;
  {
    KLObject* a1972[] = {t1964};
    t1972 = shen_apply_direct(ctx, "shen.in->", 1, a1972);
  }
  KLObject* t1974;
  {
    KLObject* a1974[] = {t1972};
    t1974 = shen_apply_direct(ctx, "shen.<alphanums>", 1, a1974);
  }
  KLObject* t1977;
  {
    KLObject* a1977[] = {t1974};
    t1977 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a1977);
  }
  KLObject* t1976;
  if (!shen_is_boolean(ctx, t1977))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1977)) {
  KLObject* t1979 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t1976 = t1979;
  } else {
  KLObject* t1980;
  {
    KLObject* a1980[] = {t1974};
    t1980 = shen_apply_direct(ctx, "shen.<-out", 1, a1980);
  }
  KLObject* t1982;
  {
    KLObject* a1982[] = {t1974};
    t1982 = shen_apply_direct(ctx, "shen.in->", 1, a1982);
  }
  KLObject* t1986;
  {
    KLObject* a1986[] = {t1970, t1980};
    t1986 = shen_apply_direct(ctx, "cn", 2, a1986);
  }
  KLObject* t1984;
  {
    KLObject* a1984[] = {t1982, t1986};
    t1984 = shen_apply_direct(ctx, "shen.comb", 2, a1984);
  }
    t1976 = t1984;
  }
    t1966 = t1976;
  }
  KLObject* t1990;
  {
    KLObject* a1990[] = {t1966};
    t1990 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a1990);
  }
  KLObject* t1989;
  if (!shen_is_boolean(ctx, t1990))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1990)) {
  KLObject* t1992;
  {
    KLObject* a1992[] = {t1963};
    t1992 = shen_apply_direct(ctx, "<e>", 1, a1992);
  }
  KLObject* t1995;
  {
    KLObject* a1995[] = {t1992};
    t1995 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a1995);
  }
  KLObject* t1994;
  if (!shen_is_boolean(ctx, t1995))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1995)) {
  KLObject* t1997 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t1994 = t1997;
  } else {
  KLObject* t1998;
  {
    KLObject* a1998[] = {t1992};
    t1998 = shen_apply_direct(ctx, "shen.in->", 1, a1998);
  }
  KLObject* t2002 = shen_string(ctx, "");
  KLObject* t2000;
  {
    KLObject* a2000[] = {t1998, t2002};
    t2000 = shen_apply_direct(ctx, "shen.comb", 2, a2000);
  }
    t1994 = t2000;
  }
  KLObject* t2004;
  {
    KLObject* a2004[] = {t1994};
    t2004 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a2004);
  }
  KLObject* t2003;
  if (!shen_is_boolean(ctx, t2004))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t2004)) {
  KLObject* t2006 = shen_tail_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t2003 = t2006;
  } else {
    t2003 = t1994;
  }
    t1989 = t2003;
  } else {
    t1989 = t1966;
  }
    return t1989;
  }
}

static KLObject* native_kl_shen_2e_3calphanum_3e_66 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t2009 = objects[0];
  tail_start_kl_shen_2e_3calphanum_3e_66: ;
  KLObject* t2010;
  {
    KLObject* a2010[] = {t2009};
    t2010 = shen_apply_direct(ctx, "shen.<alpha>", 1, a2010);
  }
  KLObject* t2013;
  {
    KLObject* a2013[] = {t2010};
    t2013 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a2013);
  }
  KLObject* t2012;
  if (!shen_is_boolean(ctx, t2013))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t2013)) {
  KLObject* t2015 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t2012 = t2015;
  } else {
  KLObject* t2016;
  {
    KLObject* a2016[] = {t2010};
    t2016 = shen_apply_direct(ctx, "shen.<-out", 1, a2016);
  }
  KLObject* t2018;
  {
    KLObject* a2018[] = {t2010};
    t2018 = shen_apply_direct(ctx, "shen.in->", 1, a2018);
  }
  KLObject* t2020;
  {
    KLObject* a2020[] = {t2018, t2016};
    t2020 = shen_apply_direct(ctx, "shen.comb", 2, a2020);
  }
    t2012 = t2020;
  }
  KLObject* t2024;
  {
    KLObject* a2024[] = {t2012};
    t2024 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a2024);
  }
  KLObject* t2023;
  if (!shen_is_boolean(ctx, t2024))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t2024)) {
  KLObject* t2026;
  {
    KLObject* a2026[] = {t2009};
    t2026 = shen_apply_direct(ctx, "shen.<numeral>", 1, a2026);
  }
  KLObject* t2029;
  {
    KLObject* a2029[] = {t2026};
    t2029 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a2029);
  }
  KLObject* t2028;
  if (!shen_is_boolean(ctx, t2029))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t2029)) {
  KLObject* t2031 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t2028 = t2031;
  } else {
  KLObject* t2032;
  {
    KLObject* a2032[] = {t2026};
    t2032 = shen_apply_direct(ctx, "shen.<-out", 1, a2032);
  }
  KLObject* t2034;
  {
    KLObject* a2034[] = {t2026};
    t2034 = shen_apply_direct(ctx, "shen.in->", 1, a2034);
  }
  KLObject* t2036;
  {
    KLObject* a2036[] = {t2034, t2032};
    t2036 = shen_apply_direct(ctx, "shen.comb", 2, a2036);
  }
    t2028 = t2036;
  }
  KLObject* t2040;
  {
    KLObject* a2040[] = {t2028};
    t2040 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a2040);
  }
  KLObject* t2039;
  if (!shen_is_boolean(ctx, t2040))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t2040)) {
  KLObject* t2042 = shen_tail_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t2039 = t2042;
  } else {
    t2039 = t2028;
  }
    t2023 = t2039;
  } else {
    t2023 = t2012;
  }
    return t2023;
  }
}

static KLObject* native_kl_shen_2e_3cnumeral_3e_67 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t2045 = objects[0];
  tail_start_kl_shen_2e_3cnumeral_3e_67: ;
  KLObject* t2048 = shen_cons_p(ctx, t2045);
  KLObject* t2046;
  if (!shen_is_boolean(ctx, t2048))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t2048)) {
  KLObject* t2049;
  {
    KLObject* a2049[] = {t2045};
    t2049 = shen_apply_direct(ctx, "head", 1, a2049);
  }
  KLObject* t2051;
  {
    KLObject* a2051[] = {t2045};
    t2051 = shen_apply_direct(ctx, "tail", 1, a2051);
  }
  KLObject* t2054;
  {
    KLObject* a2054[] = {t2049};
    t2054 = shen_apply_direct(ctx, "shen.digit?", 1, a2054);
  }
  KLObject* t2053;
  if (!shen_is_boolean(ctx, t2054))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t2054)) {
  KLObject* t2058;
  {
    KLObject* a2058[] = {t2049};
    t2058 = shen_apply_direct(ctx, "n->string", 1, a2058);
  }
  KLObject* t2056;
  {
    KLObject* a2056[] = {t2051, t2058};
    t2056 = shen_apply_direct(ctx, "shen.comb", 2, a2056);
  }
    t2053 = t2056;
  } else {
  KLObject* t2060 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t2053 = t2060;
  }
    t2046 = t2053;
  } else {
  KLObject* t2061 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t2046 = t2061;
  }
  KLObject* t2063;
  {
    KLObject* a2063[] = {t2046};
    t2063 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a2063);
  }
  KLObject* t2062;
  if (!shen_is_boolean(ctx, t2063))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t2063)) {
  KLObject* t2065 = shen_tail_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t2062 = t2065;
  } else {
    t2062 = t2046;
  }
    return t2062;
  }
}

static KLObject* native_kl_shen_2edigit_3f_68 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t2067 = objects[0];
  tail_start_kl_shen_2edigit_3f_68: ;
  KLObject* t2070 = shen_number_l(ctx, 48);
  KLObject* t2071 = shen_gte(ctx, t2067, t2070);
  KLObject* t2068;
  if (!shen_is_boolean(ctx, t2071))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t2071)) {
    t2068 = t2071;
  } else {
  KLObject* t2073 = shen_number_l(ctx, 57);
  KLObject* t2074 = shen_lte(ctx, t2067, t2073);
    if (!shen_is_boolean(ctx, t2074))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t2068 = t2074;
  }
    return t2068;
  }
}

static KLObject* native_kl_shen_2e_3cstr_3e_69 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t2075 = objects[0];
  tail_start_kl_shen_2e_3cstr_3e_69: ;
  KLObject* t2076;
  {
    KLObject* a2076[] = {t2075};
    t2076 = shen_apply_direct(ctx, "shen.<dbq>", 1, a2076);
  }
  KLObject* t2079;
  {
    KLObject* a2079[] = {t2076};
    t2079 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a2079);
  }
  KLObject* t2078;
  if (!shen_is_boolean(ctx, t2079))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t2079)) {
  KLObject* t2081 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t2078 = t2081;
  } else {
  KLObject* t2082;
  {
    KLObject* a2082[] = {t2076};
    t2082 = shen_apply_direct(ctx, "shen.in->", 1, a2082);
  }
  KLObject* t2084;
  {
    KLObject* a2084[] = {t2082};
    t2084 = shen_apply_direct(ctx, "shen.<strcontents>", 1, a2084);
  }
  KLObject* t2087;
  {
    KLObject* a2087[] = {t2084};
    t2087 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a2087);
  }
  KLObject* t2086;
  if (!shen_is_boolean(ctx, t2087))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t2087)) {
  KLObject* t2089 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t2086 = t2089;
  } else {
  KLObject* t2090;
  {
    KLObject* a2090[] = {t2084};
    t2090 = shen_apply_direct(ctx, "shen.<-out", 1, a2090);
  }
  KLObject* t2092;
  {
    KLObject* a2092[] = {t2084};
    t2092 = shen_apply_direct(ctx, "shen.in->", 1, a2092);
  }
  KLObject* t2094;
  {
    KLObject* a2094[] = {t2092};
    t2094 = shen_apply_direct(ctx, "shen.<dbq>", 1, a2094);
  }
  KLObject* t2097;
  {
    KLObject* a2097[] = {t2094};
    t2097 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a2097);
  }
  KLObject* t2096;
  if (!shen_is_boolean(ctx, t2097))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t2097)) {
  KLObject* t2099 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t2096 = t2099;
  } else {
  KLObject* t2100;
  {
    KLObject* a2100[] = {t2094};
    t2100 = shen_apply_direct(ctx, "shen.in->", 1, a2100);
  }
  KLObject* t2102;
  {
    KLObject* a2102[] = {t2100, t2090};
    t2102 = shen_apply_direct(ctx, "shen.comb", 2, a2102);
  }
    t2096 = t2102;
  }
    t2086 = t2096;
  }
    t2078 = t2086;
  }
  KLObject* t2106;
  {
    KLObject* a2106[] = {t2078};
    t2106 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a2106);
  }
  KLObject* t2105;
  if (!shen_is_boolean(ctx, t2106))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t2106)) {
  KLObject* t2108 = shen_tail_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t2105 = t2108;
  } else {
    t2105 = t2078;
  }
    return t2105;
  }
}

static KLObject* native_kl_shen_2e_3cdbq_3e_70 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t2110 = objects[0];
  tail_start_kl_shen_2e_3cdbq_3e_70: ;
  KLObject* t2114 = shen_number_l(ctx, 34);
  KLObject* t2112;
  {
    KLObject* a2112[] = {t2110, t2114};
    t2112 = shen_apply_direct(ctx, "shen.hds=?", 2, a2112);
  }
  KLObject* t2111;
  if (!shen_is_boolean(ctx, t2112))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t2112)) {
  KLObject* t2115;
  {
    KLObject* a2115[] = {t2110};
    t2115 = shen_apply_direct(ctx, "tail", 1, a2115);
  }
  KLObject* t2119 = shen_intern(ctx, "shen.skip");
  KLObject* t2117;
  {
    KLObject* a2117[] = {t2115, t2119};
    t2117 = shen_apply_direct(ctx, "shen.comb", 2, a2117);
  }
    t2111 = t2117;
  } else {
  KLObject* t2120 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t2111 = t2120;
  }
  KLObject* t2122;
  {
    KLObject* a2122[] = {t2111};
    t2122 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a2122);
  }
  KLObject* t2121;
  if (!shen_is_boolean(ctx, t2122))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t2122)) {
  KLObject* t2124 = shen_tail_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t2121 = t2124;
  } else {
    t2121 = t2111;
  }
    return t2121;
  }
}

static KLObject* native_kl_shen_2e_3cstrcontents_3e_71 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t2126 = objects[0];
  tail_start_kl_shen_2e_3cstrcontents_3e_71: ;
  KLObject* t2127;
  {
    KLObject* a2127[] = {t2126};
    t2127 = shen_apply_direct(ctx, "shen.<strc>", 1, a2127);
  }
  KLObject* t2130;
  {
    KLObject* a2130[] = {t2127};
    t2130 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a2130);
  }
  KLObject* t2129;
  if (!shen_is_boolean(ctx, t2130))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t2130)) {
  KLObject* t2132 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t2129 = t2132;
  } else {
  KLObject* t2133;
  {
    KLObject* a2133[] = {t2127};
    t2133 = shen_apply_direct(ctx, "shen.<-out", 1, a2133);
  }
  KLObject* t2135;
  {
    KLObject* a2135[] = {t2127};
    t2135 = shen_apply_direct(ctx, "shen.in->", 1, a2135);
  }
  KLObject* t2137;
  {
    KLObject* a2137[] = {t2135};
    t2137 = shen_apply_direct(ctx, "shen.<strcontents>", 1, a2137);
  }
  KLObject* t2140;
  {
    KLObject* a2140[] = {t2137};
    t2140 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a2140);
  }
  KLObject* t2139;
  if (!shen_is_boolean(ctx, t2140))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t2140)) {
  KLObject* t2142 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t2139 = t2142;
  } else {
  KLObject* t2143;
  {
    KLObject* a2143[] = {t2137};
    t2143 = shen_apply_direct(ctx, "shen.<-out", 1, a2143);
  }
  KLObject* t2145;
  {
    KLObject* a2145[] = {t2137};
    t2145 = shen_apply_direct(ctx, "shen.in->", 1, a2145);
  }
  KLObject* t2149;
  {
    KLObject* a2149[] = {t2133, t2143};
    t2149 = shen_apply_direct(ctx, "cn", 2, a2149);
  }
  KLObject* t2147;
  {
    KLObject* a2147[] = {t2145, t2149};
    t2147 = shen_apply_direct(ctx, "shen.comb", 2, a2147);
  }
    t2139 = t2147;
  }
    t2129 = t2139;
  }
  KLObject* t2153;
  {
    KLObject* a2153[] = {t2129};
    t2153 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a2153);
  }
  KLObject* t2152;
  if (!shen_is_boolean(ctx, t2153))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t2153)) {
  KLObject* t2155;
  {
    KLObject* a2155[] = {t2126};
    t2155 = shen_apply_direct(ctx, "<e>", 1, a2155);
  }
  KLObject* t2158;
  {
    KLObject* a2158[] = {t2155};
    t2158 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a2158);
  }
  KLObject* t2157;
  if (!shen_is_boolean(ctx, t2158))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t2158)) {
  KLObject* t2160 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t2157 = t2160;
  } else {
  KLObject* t2161;
  {
    KLObject* a2161[] = {t2155};
    t2161 = shen_apply_direct(ctx, "shen.in->", 1, a2161);
  }
  KLObject* t2165 = shen_string(ctx, "");
  KLObject* t2163;
  {
    KLObject* a2163[] = {t2161, t2165};
    t2163 = shen_apply_direct(ctx, "shen.comb", 2, a2163);
  }
    t2157 = t2163;
  }
  KLObject* t2167;
  {
    KLObject* a2167[] = {t2157};
    t2167 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a2167);
  }
  KLObject* t2166;
  if (!shen_is_boolean(ctx, t2167))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t2167)) {
  KLObject* t2169 = shen_tail_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t2166 = t2169;
  } else {
    t2166 = t2157;
  }
    t2152 = t2166;
  } else {
    t2152 = t2129;
  }
    return t2152;
  }
}

static KLObject* native_kl_shen_2e_3cstrc_3e_72 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t2172 = objects[0];
  tail_start_kl_shen_2e_3cstrc_3e_72: ;
  KLObject* t2173;
  {
    KLObject* a2173[] = {t2172};
    t2173 = shen_apply_direct(ctx, "shen.<control>", 1, a2173);
  }
  KLObject* t2176;
  {
    KLObject* a2176[] = {t2173};
    t2176 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a2176);
  }
  KLObject* t2175;
  if (!shen_is_boolean(ctx, t2176))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t2176)) {
  KLObject* t2178 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t2175 = t2178;
  } else {
  KLObject* t2179;
  {
    KLObject* a2179[] = {t2173};
    t2179 = shen_apply_direct(ctx, "shen.<-out", 1, a2179);
  }
  KLObject* t2181;
  {
    KLObject* a2181[] = {t2173};
    t2181 = shen_apply_direct(ctx, "shen.in->", 1, a2181);
  }
  KLObject* t2183;
  {
    KLObject* a2183[] = {t2181, t2179};
    t2183 = shen_apply_direct(ctx, "shen.comb", 2, a2183);
  }
    t2175 = t2183;
  }
  KLObject* t2187;
  {
    KLObject* a2187[] = {t2175};
    t2187 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a2187);
  }
  KLObject* t2186;
  if (!shen_is_boolean(ctx, t2187))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t2187)) {
  KLObject* t2189;
  {
    KLObject* a2189[] = {t2172};
    t2189 = shen_apply_direct(ctx, "shen.<notdbq>", 1, a2189);
  }
  KLObject* t2192;
  {
    KLObject* a2192[] = {t2189};
    t2192 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a2192);
  }
  KLObject* t2191;
  if (!shen_is_boolean(ctx, t2192))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t2192)) {
  KLObject* t2194 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t2191 = t2194;
  } else {
  KLObject* t2195;
  {
    KLObject* a2195[] = {t2189};
    t2195 = shen_apply_direct(ctx, "shen.<-out", 1, a2195);
  }
  KLObject* t2197;
  {
    KLObject* a2197[] = {t2189};
    t2197 = shen_apply_direct(ctx, "shen.in->", 1, a2197);
  }
  KLObject* t2199;
  {
    KLObject* a2199[] = {t2197, t2195};
    t2199 = shen_apply_direct(ctx, "shen.comb", 2, a2199);
  }
    t2191 = t2199;
  }
  KLObject* t2203;
  {
    KLObject* a2203[] = {t2191};
    t2203 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a2203);
  }
  KLObject* t2202;
  if (!shen_is_boolean(ctx, t2203))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t2203)) {
  KLObject* t2205 = shen_tail_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t2202 = t2205;
  } else {
    t2202 = t2191;
  }
    t2186 = t2202;
  } else {
    t2186 = t2175;
  }
    return t2186;
  }
}

static KLObject* native_kl_shen_2e_3ccontrol_3e_73 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t2208 = objects[0];
  tail_start_kl_shen_2e_3ccontrol_3e_73: ;
  KLObject* t2209;
  {
    KLObject* a2209[] = {t2208};
    t2209 = shen_apply_direct(ctx, "shen.<lowC>", 1, a2209);
  }
  KLObject* t2212;
  {
    KLObject* a2212[] = {t2209};
    t2212 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a2212);
  }
  KLObject* t2211;
  if (!shen_is_boolean(ctx, t2212))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t2212)) {
  KLObject* t2214 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t2211 = t2214;
  } else {
  KLObject* t2215;
  {
    KLObject* a2215[] = {t2209};
    t2215 = shen_apply_direct(ctx, "shen.in->", 1, a2215);
  }
  KLObject* t2217;
  {
    KLObject* a2217[] = {t2215};
    t2217 = shen_apply_direct(ctx, "shen.<hash>", 1, a2217);
  }
  KLObject* t2220;
  {
    KLObject* a2220[] = {t2217};
    t2220 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a2220);
  }
  KLObject* t2219;
  if (!shen_is_boolean(ctx, t2220))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t2220)) {
  KLObject* t2222 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t2219 = t2222;
  } else {
  KLObject* t2223;
  {
    KLObject* a2223[] = {t2217};
    t2223 = shen_apply_direct(ctx, "shen.in->", 1, a2223);
  }
  KLObject* t2225;
  {
    KLObject* a2225[] = {t2223};
    t2225 = shen_apply_direct(ctx, "shen.<integer>", 1, a2225);
  }
  KLObject* t2228;
  {
    KLObject* a2228[] = {t2225};
    t2228 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a2228);
  }
  KLObject* t2227;
  if (!shen_is_boolean(ctx, t2228))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t2228)) {
  KLObject* t2230 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t2227 = t2230;
  } else {
  KLObject* t2231;
  {
    KLObject* a2231[] = {t2225};
    t2231 = shen_apply_direct(ctx, "shen.<-out", 1, a2231);
  }
  KLObject* t2233;
  {
    KLObject* a2233[] = {t2225};
    t2233 = shen_apply_direct(ctx, "shen.in->", 1, a2233);
  }
  KLObject* t2235;
  {
    KLObject* a2235[] = {t2233};
    t2235 = shen_apply_direct(ctx, "shen.<semicolon>", 1, a2235);
  }
  KLObject* t2238;
  {
    KLObject* a2238[] = {t2235};
    t2238 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a2238);
  }
  KLObject* t2237;
  if (!shen_is_boolean(ctx, t2238))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t2238)) {
  KLObject* t2240 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t2237 = t2240;
  } else {
  KLObject* t2241;
  {
    KLObject* a2241[] = {t2235};
    t2241 = shen_apply_direct(ctx, "shen.in->", 1, a2241);
  }
  KLObject* t2245;
  {
    KLObject* a2245[] = {t2231};
    t2245 = shen_apply_direct(ctx, "n->string", 1, a2245);
  }
  KLObject* t2243;
  {
    KLObject* a2243[] = {t2241, t2245};
    t2243 = shen_apply_direct(ctx, "shen.comb", 2, a2243);
  }
    t2237 = t2243;
  }
    t2227 = t2237;
  }
    t2219 = t2227;
  }
    t2211 = t2219;
  }
  KLObject* t2248;
  {
    KLObject* a2248[] = {t2211};
    t2248 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a2248);
  }
  KLObject* t2247;
  if (!shen_is_boolean(ctx, t2248))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t2248)) {
  KLObject* t2250 = shen_tail_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t2247 = t2250;
  } else {
    t2247 = t2211;
  }
    return t2247;
  }
}

static KLObject* native_kl_shen_2e_3cnotdbq_3e_74 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t2252 = objects[0];
  tail_start_kl_shen_2e_3cnotdbq_3e_74: ;
  KLObject* t2255 = shen_cons_p(ctx, t2252);
  KLObject* t2253;
  if (!shen_is_boolean(ctx, t2255))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t2255)) {
  KLObject* t2256;
  {
    KLObject* a2256[] = {t2252};
    t2256 = shen_apply_direct(ctx, "head", 1, a2256);
  }
  KLObject* t2258;
  {
    KLObject* a2258[] = {t2252};
    t2258 = shen_apply_direct(ctx, "tail", 1, a2258);
  }
  KLObject* t2263 = shen_number_l(ctx, 34);
  KLObject* t2264 = shen_eq(ctx, t2256, t2263);
  KLObject* t2261;
  {
    KLObject* a2261[] = {t2264};
    t2261 = shen_apply_direct(ctx, "not", 1, a2261);
  }
  KLObject* t2260;
  if (!shen_is_boolean(ctx, t2261))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t2261)) {
  KLObject* t2267;
  {
    KLObject* a2267[] = {t2256};
    t2267 = shen_apply_direct(ctx, "n->string", 1, a2267);
  }
  KLObject* t2265;
  {
    KLObject* a2265[] = {t2258, t2267};
    t2265 = shen_apply_direct(ctx, "shen.comb", 2, a2265);
  }
    t2260 = t2265;
  } else {
  KLObject* t2269 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t2260 = t2269;
  }
    t2253 = t2260;
  } else {
  KLObject* t2270 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t2253 = t2270;
  }
  KLObject* t2272;
  {
    KLObject* a2272[] = {t2253};
    t2272 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a2272);
  }
  KLObject* t2271;
  if (!shen_is_boolean(ctx, t2272))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t2272)) {
  KLObject* t2274 = shen_tail_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t2271 = t2274;
  } else {
    t2271 = t2253;
  }
    return t2271;
  }
}

static KLObject* native_kl_shen_2e_3clowC_3e_75 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t2276 = objects[0];
  tail_start_kl_shen_2e_3clowC_3e_75: ;
  KLObject* t2280 = shen_number_l(ctx, 99);
  KLObject* t2278;
  {
    KLObject* a2278[] = {t2276, t2280};
    t2278 = shen_apply_direct(ctx, "shen.hds=?", 2, a2278);
  }
  KLObject* t2277;
  if (!shen_is_boolean(ctx, t2278))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t2278)) {
  KLObject* t2281;
  {
    KLObject* a2281[] = {t2276};
    t2281 = shen_apply_direct(ctx, "tail", 1, a2281);
  }
  KLObject* t2285 = shen_intern(ctx, "shen.skip");
  KLObject* t2283;
  {
    KLObject* a2283[] = {t2281, t2285};
    t2283 = shen_apply_direct(ctx, "shen.comb", 2, a2283);
  }
    t2277 = t2283;
  } else {
  KLObject* t2286 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t2277 = t2286;
  }
  KLObject* t2288;
  {
    KLObject* a2288[] = {t2277};
    t2288 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a2288);
  }
  KLObject* t2287;
  if (!shen_is_boolean(ctx, t2288))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t2288)) {
  KLObject* t2290 = shen_tail_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t2287 = t2290;
  } else {
    t2287 = t2277;
  }
    return t2287;
  }
}

static KLObject* native_kl_shen_2e_3chash_3e_76 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t2292 = objects[0];
  tail_start_kl_shen_2e_3chash_3e_76: ;
  KLObject* t2296 = shen_number_l(ctx, 35);
  KLObject* t2294;
  {
    KLObject* a2294[] = {t2292, t2296};
    t2294 = shen_apply_direct(ctx, "shen.hds=?", 2, a2294);
  }
  KLObject* t2293;
  if (!shen_is_boolean(ctx, t2294))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t2294)) {
  KLObject* t2297;
  {
    KLObject* a2297[] = {t2292};
    t2297 = shen_apply_direct(ctx, "tail", 1, a2297);
  }
  KLObject* t2301 = shen_intern(ctx, "shen.skip");
  KLObject* t2299;
  {
    KLObject* a2299[] = {t2297, t2301};
    t2299 = shen_apply_direct(ctx, "shen.comb", 2, a2299);
  }
    t2293 = t2299;
  } else {
  KLObject* t2302 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t2293 = t2302;
  }
  KLObject* t2304;
  {
    KLObject* a2304[] = {t2293};
    t2304 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a2304);
  }
  KLObject* t2303;
  if (!shen_is_boolean(ctx, t2304))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t2304)) {
  KLObject* t2306 = shen_tail_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t2303 = t2306;
  } else {
    t2303 = t2293;
  }
    return t2303;
  }
}

static KLObject* native_kl_shen_2e_3cnumber_3e_77 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t2308 = objects[0];
  tail_start_kl_shen_2e_3cnumber_3e_77: ;
  KLObject* t2309;
  {
    KLObject* a2309[] = {t2308};
    t2309 = shen_apply_direct(ctx, "shen.<minus>", 1, a2309);
  }
  KLObject* t2312;
  {
    KLObject* a2312[] = {t2309};
    t2312 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a2312);
  }
  KLObject* t2311;
  if (!shen_is_boolean(ctx, t2312))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t2312)) {
  KLObject* t2314 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t2311 = t2314;
  } else {
  KLObject* t2315;
  {
    KLObject* a2315[] = {t2309};
    t2315 = shen_apply_direct(ctx, "shen.in->", 1, a2315);
  }
  KLObject* t2317;
  {
    KLObject* a2317[] = {t2315};
    t2317 = shen_apply_direct(ctx, "shen.<number>", 1, a2317);
  }
  KLObject* t2320;
  {
    KLObject* a2320[] = {t2317};
    t2320 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a2320);
  }
  KLObject* t2319;
  if (!shen_is_boolean(ctx, t2320))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t2320)) {
  KLObject* t2322 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t2319 = t2322;
  } else {
  KLObject* t2323;
  {
    KLObject* a2323[] = {t2317};
    t2323 = shen_apply_direct(ctx, "shen.<-out", 1, a2323);
  }
  KLObject* t2325;
  {
    KLObject* a2325[] = {t2317};
    t2325 = shen_apply_direct(ctx, "shen.in->", 1, a2325);
  }
  KLObject* t2329 = shen_number_l(ctx, 0);
  KLObject* t2331 = shen_sub(ctx, t2329, t2323);
  KLObject* t2327;
  {
    KLObject* a2327[] = {t2325, t2331};
    t2327 = shen_apply_direct(ctx, "shen.comb", 2, a2327);
  }
    t2319 = t2327;
  }
    t2311 = t2319;
  }
  KLObject* t2333;
  {
    KLObject* a2333[] = {t2311};
    t2333 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a2333);
  }
  KLObject* t2332;
  if (!shen_is_boolean(ctx, t2333))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t2333)) {
  KLObject* t2335;
  {
    KLObject* a2335[] = {t2308};
    t2335 = shen_apply_direct(ctx, "shen.<plus>", 1, a2335);
  }
  KLObject* t2338;
  {
    KLObject* a2338[] = {t2335};
    t2338 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a2338);
  }
  KLObject* t2337;
  if (!shen_is_boolean(ctx, t2338))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t2338)) {
  KLObject* t2340 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t2337 = t2340;
  } else {
  KLObject* t2341;
  {
    KLObject* a2341[] = {t2335};
    t2341 = shen_apply_direct(ctx, "shen.in->", 1, a2341);
  }
  KLObject* t2343;
  {
    KLObject* a2343[] = {t2341};
    t2343 = shen_apply_direct(ctx, "shen.<number>", 1, a2343);
  }
  KLObject* t2346;
  {
    KLObject* a2346[] = {t2343};
    t2346 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a2346);
  }
  KLObject* t2345;
  if (!shen_is_boolean(ctx, t2346))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t2346)) {
  KLObject* t2348 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t2345 = t2348;
  } else {
  KLObject* t2349;
  {
    KLObject* a2349[] = {t2343};
    t2349 = shen_apply_direct(ctx, "shen.<-out", 1, a2349);
  }
  KLObject* t2351;
  {
    KLObject* a2351[] = {t2343};
    t2351 = shen_apply_direct(ctx, "shen.in->", 1, a2351);
  }
  KLObject* t2353;
  {
    KLObject* a2353[] = {t2351, t2349};
    t2353 = shen_apply_direct(ctx, "shen.comb", 2, a2353);
  }
    t2345 = t2353;
  }
    t2337 = t2345;
  }
  KLObject* t2357;
  {
    KLObject* a2357[] = {t2337};
    t2357 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a2357);
  }
  KLObject* t2356;
  if (!shen_is_boolean(ctx, t2357))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t2357)) {
  KLObject* t2359;
  {
    KLObject* a2359[] = {t2308};
    t2359 = shen_apply_direct(ctx, "shen.<e-number>", 1, a2359);
  }
  KLObject* t2362;
  {
    KLObject* a2362[] = {t2359};
    t2362 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a2362);
  }
  KLObject* t2361;
  if (!shen_is_boolean(ctx, t2362))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t2362)) {
  KLObject* t2364 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t2361 = t2364;
  } else {
  KLObject* t2365;
  {
    KLObject* a2365[] = {t2359};
    t2365 = shen_apply_direct(ctx, "shen.<-out", 1, a2365);
  }
  KLObject* t2367;
  {
    KLObject* a2367[] = {t2359};
    t2367 = shen_apply_direct(ctx, "shen.in->", 1, a2367);
  }
  KLObject* t2369;
  {
    KLObject* a2369[] = {t2367, t2365};
    t2369 = shen_apply_direct(ctx, "shen.comb", 2, a2369);
  }
    t2361 = t2369;
  }
  KLObject* t2373;
  {
    KLObject* a2373[] = {t2361};
    t2373 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a2373);
  }
  KLObject* t2372;
  if (!shen_is_boolean(ctx, t2373))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t2373)) {
  KLObject* t2375;
  {
    KLObject* a2375[] = {t2308};
    t2375 = shen_apply_direct(ctx, "shen.<float>", 1, a2375);
  }
  KLObject* t2378;
  {
    KLObject* a2378[] = {t2375};
    t2378 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a2378);
  }
  KLObject* t2377;
  if (!shen_is_boolean(ctx, t2378))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t2378)) {
  KLObject* t2380 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t2377 = t2380;
  } else {
  KLObject* t2381;
  {
    KLObject* a2381[] = {t2375};
    t2381 = shen_apply_direct(ctx, "shen.<-out", 1, a2381);
  }
  KLObject* t2383;
  {
    KLObject* a2383[] = {t2375};
    t2383 = shen_apply_direct(ctx, "shen.in->", 1, a2383);
  }
  KLObject* t2385;
  {
    KLObject* a2385[] = {t2383, t2381};
    t2385 = shen_apply_direct(ctx, "shen.comb", 2, a2385);
  }
    t2377 = t2385;
  }
  KLObject* t2389;
  {
    KLObject* a2389[] = {t2377};
    t2389 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a2389);
  }
  KLObject* t2388;
  if (!shen_is_boolean(ctx, t2389))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t2389)) {
  KLObject* t2391;
  {
    KLObject* a2391[] = {t2308};
    t2391 = shen_apply_direct(ctx, "shen.<integer>", 1, a2391);
  }
  KLObject* t2394;
  {
    KLObject* a2394[] = {t2391};
    t2394 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a2394);
  }
  KLObject* t2393;
  if (!shen_is_boolean(ctx, t2394))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t2394)) {
  KLObject* t2396 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t2393 = t2396;
  } else {
  KLObject* t2397;
  {
    KLObject* a2397[] = {t2391};
    t2397 = shen_apply_direct(ctx, "shen.<-out", 1, a2397);
  }
  KLObject* t2399;
  {
    KLObject* a2399[] = {t2391};
    t2399 = shen_apply_direct(ctx, "shen.in->", 1, a2399);
  }
  KLObject* t2401;
  {
    KLObject* a2401[] = {t2399, t2397};
    t2401 = shen_apply_direct(ctx, "shen.comb", 2, a2401);
  }
    t2393 = t2401;
  }
  KLObject* t2405;
  {
    KLObject* a2405[] = {t2393};
    t2405 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a2405);
  }
  KLObject* t2404;
  if (!shen_is_boolean(ctx, t2405))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t2405)) {
  KLObject* t2407 = shen_tail_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t2404 = t2407;
  } else {
    t2404 = t2393;
  }
    t2388 = t2404;
  } else {
    t2388 = t2377;
  }
    t2372 = t2388;
  } else {
    t2372 = t2361;
  }
    t2356 = t2372;
  } else {
    t2356 = t2337;
  }
    t2332 = t2356;
  } else {
    t2332 = t2311;
  }
    return t2332;
  }
}

static KLObject* native_kl_shen_2e_3cminus_3e_78 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t2413 = objects[0];
  tail_start_kl_shen_2e_3cminus_3e_78: ;
  KLObject* t2417 = shen_number_l(ctx, 45);
  KLObject* t2415;
  {
    KLObject* a2415[] = {t2413, t2417};
    t2415 = shen_apply_direct(ctx, "shen.hds=?", 2, a2415);
  }
  KLObject* t2414;
  if (!shen_is_boolean(ctx, t2415))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t2415)) {
  KLObject* t2418;
  {
    KLObject* a2418[] = {t2413};
    t2418 = shen_apply_direct(ctx, "tail", 1, a2418);
  }
  KLObject* t2422 = shen_intern(ctx, "shen.skip");
  KLObject* t2420;
  {
    KLObject* a2420[] = {t2418, t2422};
    t2420 = shen_apply_direct(ctx, "shen.comb", 2, a2420);
  }
    t2414 = t2420;
  } else {
  KLObject* t2423 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t2414 = t2423;
  }
  KLObject* t2425;
  {
    KLObject* a2425[] = {t2414};
    t2425 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a2425);
  }
  KLObject* t2424;
  if (!shen_is_boolean(ctx, t2425))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t2425)) {
  KLObject* t2427 = shen_tail_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t2424 = t2427;
  } else {
    t2424 = t2414;
  }
    return t2424;
  }
}

static KLObject* native_kl_shen_2e_3cplus_3e_79 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t2429 = objects[0];
  tail_start_kl_shen_2e_3cplus_3e_79: ;
  KLObject* t2433 = shen_number_l(ctx, 43);
  KLObject* t2431;
  {
    KLObject* a2431[] = {t2429, t2433};
    t2431 = shen_apply_direct(ctx, "shen.hds=?", 2, a2431);
  }
  KLObject* t2430;
  if (!shen_is_boolean(ctx, t2431))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t2431)) {
  KLObject* t2434;
  {
    KLObject* a2434[] = {t2429};
    t2434 = shen_apply_direct(ctx, "tail", 1, a2434);
  }
  KLObject* t2438 = shen_intern(ctx, "shen.skip");
  KLObject* t2436;
  {
    KLObject* a2436[] = {t2434, t2438};
    t2436 = shen_apply_direct(ctx, "shen.comb", 2, a2436);
  }
    t2430 = t2436;
  } else {
  KLObject* t2439 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t2430 = t2439;
  }
  KLObject* t2441;
  {
    KLObject* a2441[] = {t2430};
    t2441 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a2441);
  }
  KLObject* t2440;
  if (!shen_is_boolean(ctx, t2441))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t2441)) {
  KLObject* t2443 = shen_tail_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t2440 = t2443;
  } else {
    t2440 = t2430;
  }
    return t2440;
  }
}

static KLObject* native_kl_shen_2e_3cinteger_3e_80 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t2445 = objects[0];
  tail_start_kl_shen_2e_3cinteger_3e_80: ;
  KLObject* t2446;
  {
    KLObject* a2446[] = {t2445};
    t2446 = shen_apply_direct(ctx, "shen.<digits>", 1, a2446);
  }
  KLObject* t2449;
  {
    KLObject* a2449[] = {t2446};
    t2449 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a2449);
  }
  KLObject* t2448;
  if (!shen_is_boolean(ctx, t2449))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t2449)) {
  KLObject* t2451 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t2448 = t2451;
  } else {
  KLObject* t2452;
  {
    KLObject* a2452[] = {t2446};
    t2452 = shen_apply_direct(ctx, "shen.<-out", 1, a2452);
  }
  KLObject* t2454;
  {
    KLObject* a2454[] = {t2446};
    t2454 = shen_apply_direct(ctx, "shen.in->", 1, a2454);
  }
  KLObject* t2458;
  {
    KLObject* a2458[] = {t2452};
    t2458 = shen_apply_direct(ctx, "shen.compute-integer", 1, a2458);
  }
  KLObject* t2456;
  {
    KLObject* a2456[] = {t2454, t2458};
    t2456 = shen_apply_direct(ctx, "shen.comb", 2, a2456);
  }
    t2448 = t2456;
  }
  KLObject* t2461;
  {
    KLObject* a2461[] = {t2448};
    t2461 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a2461);
  }
  KLObject* t2460;
  if (!shen_is_boolean(ctx, t2461))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t2461)) {
  KLObject* t2463 = shen_tail_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t2460 = t2463;
  } else {
    t2460 = t2448;
  }
    return t2460;
  }
}

static KLObject* native_kl_shen_2e_3cdigits_3e_81 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t2465 = objects[0];
  tail_start_kl_shen_2e_3cdigits_3e_81: ;
  KLObject* t2466;
  {
    KLObject* a2466[] = {t2465};
    t2466 = shen_apply_direct(ctx, "shen.<digit>", 1, a2466);
  }
  KLObject* t2469;
  {
    KLObject* a2469[] = {t2466};
    t2469 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a2469);
  }
  KLObject* t2468;
  if (!shen_is_boolean(ctx, t2469))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t2469)) {
  KLObject* t2471 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t2468 = t2471;
  } else {
  KLObject* t2472;
  {
    KLObject* a2472[] = {t2466};
    t2472 = shen_apply_direct(ctx, "shen.<-out", 1, a2472);
  }
  KLObject* t2474;
  {
    KLObject* a2474[] = {t2466};
    t2474 = shen_apply_direct(ctx, "shen.in->", 1, a2474);
  }
  KLObject* t2476;
  {
    KLObject* a2476[] = {t2474};
    t2476 = shen_apply_direct(ctx, "shen.<digits>", 1, a2476);
  }
  KLObject* t2479;
  {
    KLObject* a2479[] = {t2476};
    t2479 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a2479);
  }
  KLObject* t2478;
  if (!shen_is_boolean(ctx, t2479))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t2479)) {
  KLObject* t2481 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t2478 = t2481;
  } else {
  KLObject* t2482;
  {
    KLObject* a2482[] = {t2476};
    t2482 = shen_apply_direct(ctx, "shen.<-out", 1, a2482);
  }
  KLObject* t2484;
  {
    KLObject* a2484[] = {t2476};
    t2484 = shen_apply_direct(ctx, "shen.in->", 1, a2484);
  }
  KLObject* t2490 = shen_cons(ctx, t2472, t2482);
  KLObject* t2486;
  {
    KLObject* a2486[] = {t2484, t2490};
    t2486 = shen_apply_direct(ctx, "shen.comb", 2, a2486);
  }
    t2478 = t2486;
  }
    t2468 = t2478;
  }
  KLObject* t2492;
  {
    KLObject* a2492[] = {t2468};
    t2492 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a2492);
  }
  KLObject* t2491;
  if (!shen_is_boolean(ctx, t2492))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t2492)) {
  KLObject* t2494;
  {
    KLObject* a2494[] = {t2465};
    t2494 = shen_apply_direct(ctx, "shen.<digit>", 1, a2494);
  }
  KLObject* t2497;
  {
    KLObject* a2497[] = {t2494};
    t2497 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a2497);
  }
  KLObject* t2496;
  if (!shen_is_boolean(ctx, t2497))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t2497)) {
  KLObject* t2499 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t2496 = t2499;
  } else {
  KLObject* t2500;
  {
    KLObject* a2500[] = {t2494};
    t2500 = shen_apply_direct(ctx, "shen.<-out", 1, a2500);
  }
  KLObject* t2502;
  {
    KLObject* a2502[] = {t2494};
    t2502 = shen_apply_direct(ctx, "shen.in->", 1, a2502);
  }
  KLObject* t2507 = shen_empty_list(ctx);
  KLObject* t2508 = shen_cons(ctx, t2500, t2507);
  KLObject* t2504;
  {
    KLObject* a2504[] = {t2502, t2508};
    t2504 = shen_apply_direct(ctx, "shen.comb", 2, a2504);
  }
    t2496 = t2504;
  }
  KLObject* t2510;
  {
    KLObject* a2510[] = {t2496};
    t2510 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a2510);
  }
  KLObject* t2509;
  if (!shen_is_boolean(ctx, t2510))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t2510)) {
  KLObject* t2512 = shen_tail_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t2509 = t2512;
  } else {
    t2509 = t2496;
  }
    t2491 = t2509;
  } else {
    t2491 = t2468;
  }
    return t2491;
  }
}

static KLObject* native_kl_shen_2e_3cdigit_3e_82 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t2515 = objects[0];
  tail_start_kl_shen_2e_3cdigit_3e_82: ;
  KLObject* t2518 = shen_cons_p(ctx, t2515);
  KLObject* t2516;
  if (!shen_is_boolean(ctx, t2518))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t2518)) {
  KLObject* t2519;
  {
    KLObject* a2519[] = {t2515};
    t2519 = shen_apply_direct(ctx, "head", 1, a2519);
  }
  KLObject* t2521;
  {
    KLObject* a2521[] = {t2515};
    t2521 = shen_apply_direct(ctx, "tail", 1, a2521);
  }
  KLObject* t2524;
  {
    KLObject* a2524[] = {t2519};
    t2524 = shen_apply_direct(ctx, "shen.digit?", 1, a2524);
  }
  KLObject* t2523;
  if (!shen_is_boolean(ctx, t2524))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t2524)) {
  KLObject* t2528;
  {
    KLObject* a2528[] = {t2519};
    t2528 = shen_apply_direct(ctx, "shen.byte->digit", 1, a2528);
  }
  KLObject* t2526;
  {
    KLObject* a2526[] = {t2521, t2528};
    t2526 = shen_apply_direct(ctx, "shen.comb", 2, a2526);
  }
    t2523 = t2526;
  } else {
  KLObject* t2530 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t2523 = t2530;
  }
    t2516 = t2523;
  } else {
  KLObject* t2531 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t2516 = t2531;
  }
  KLObject* t2533;
  {
    KLObject* a2533[] = {t2516};
    t2533 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a2533);
  }
  KLObject* t2532;
  if (!shen_is_boolean(ctx, t2533))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t2533)) {
  KLObject* t2535 = shen_tail_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t2532 = t2535;
  } else {
    t2532 = t2516;
  }
    return t2532;
  }
}

static KLObject* native_kl_shen_2ebyte_2d_3edigit_83 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t2537 = objects[0];
  tail_start_kl_shen_2ebyte_2d_3edigit_83: ;
  KLObject* t2539 = shen_number_l(ctx, 48);
  KLObject* t2540 = shen_sub(ctx, t2537, t2539);
    return t2540;
  }
}

static KLObject* native_kl_shen_2ecompute_2dinteger_84 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t2541 = objects[0];
  tail_start_kl_shen_2ecompute_2dinteger_84: ;
  KLObject* t2543;
  {
    KLObject* a2543[] = {t2541};
    t2543 = shen_apply_direct(ctx, "reverse", 1, a2543);
  }
  KLObject* t2545 = shen_number_l(ctx, 0);
  KLObject* t2542;
  {
    KLObject* a2542[] = {t2543, t2545};
    t2542 = shen_tail_apply_direct(ctx, "shen.compute-integer-h", 2, a2542);
  }
    return t2542;
  }
}

static KLObject* native_kl_shen_2ecompute_2dinteger_2dh_85 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t2546 = objects[0];
    KLObject* t2547 = objects[1];
  tail_start_kl_shen_2ecompute_2dinteger_2dh_85: ;
  KLObject* t2548;
  {
  KLObject* t2549 = shen_empty_list(ctx);
  KLObject* t2551 = shen_eq(ctx, t2549, t2546);
    if (!shen_is_boolean(ctx, t2551))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t2551)) {
  KLObject* t2552 = shen_number_l(ctx, 0);
      t2548 = t2552;
    } else {
  KLObject* t2554 = shen_cons_p(ctx, t2546);
    if (!shen_is_boolean(ctx, t2554))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t2554)) {
  KLObject* t2556 = shen_number_l(ctx, 10);
  KLObject* t2555;
  {
    KLObject* a2555[] = {t2556, t2547};
    t2555 = shen_apply_direct(ctx, "shen.expt", 2, a2555);
  }
  KLObject* t2559 = shen_hd(ctx, t2546);
  KLObject* t2560 = shen_mul(ctx, t2555, t2559);
  KLObject* t2563 = shen_tl(ctx, t2546);
  KLObject* t2565 = shen_number_l(ctx, 1);
  KLObject* t2566 = shen_add(ctx, t2547, t2565);
  KLObject* t2561;
  {
    KLObject* a2561[] = {t2563, t2566};
    t2561 = shen_apply_direct(ctx, "shen.compute-integer-h", 2, a2561);
  }
  KLObject* t2567 = shen_add(ctx, t2560, t2561);
      t2548 = t2567;
    } else {
  KLObject* t2568 = shen_true(ctx);
    if (!shen_is_boolean(ctx, t2568))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t2568)) {
  KLObject* t2570 = shen_string(ctx, "partial function shen.compute-integer-h");
  KLObject* t2569;
  {
    KLObject* a2569[] = {t2570};
    t2569 = shen_tail_apply_direct(ctx, "simple-error", 1, a2569);
  }
      t2548 = t2569;
    } else {
      shen_simple_error(ctx, "No true case found for cond");
      t2548 = shen_empty_list(ctx);
    }
    }
    }
  }
    return t2548;
  }
}

static KLObject* native_kl_shen_2eexpt_86 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t2571 = objects[0];
    KLObject* t2572 = objects[1];
  tail_start_kl_shen_2eexpt_86: ;
  KLObject* t2573;
  {
  KLObject* t2574 = shen_number_l(ctx, 0);
  KLObject* t2576 = shen_eq(ctx, t2574, t2572);
    if (!shen_is_boolean(ctx, t2576))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t2576)) {
  KLObject* t2577 = shen_number_l(ctx, 1);
      t2573 = t2577;
    } else {
  KLObject* t2579 = shen_number_l(ctx, 0);
  KLObject* t2580 = shen_gt(ctx, t2572, t2579);
    if (!shen_is_boolean(ctx, t2580))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t2580)) {
  KLObject* t2585 = shen_number_l(ctx, 1);
  KLObject* t2586 = shen_sub(ctx, t2572, t2585);
  KLObject* t2582;
  {
    KLObject* a2582[] = {t2571, t2586};
    t2582 = shen_apply_direct(ctx, "shen.expt", 2, a2582);
  }
  KLObject* t2587 = shen_mul(ctx, t2571, t2582);
      t2573 = t2587;
    } else {
  KLObject* t2588 = shen_true(ctx);
    if (!shen_is_boolean(ctx, t2588))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t2588)) {
  KLObject* t2592 = shen_number_l(ctx, 1);
  KLObject* t2593 = shen_add(ctx, t2572, t2592);
  KLObject* t2589;
  {
    KLObject* a2589[] = {t2571, t2593};
    t2589 = shen_apply_direct(ctx, "shen.expt", 2, a2589);
  }
  KLObject* t2595 = shen_div(ctx, t2589, t2571);
      t2573 = t2595;
    } else {
      shen_simple_error(ctx, "No true case found for cond");
      t2573 = shen_empty_list(ctx);
    }
    }
    }
  }
    return t2573;
  }
}

static KLObject* native_kl_shen_2e_3cfloat_3e_87 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t2596 = objects[0];
  tail_start_kl_shen_2e_3cfloat_3e_87: ;
  KLObject* t2597;
  {
    KLObject* a2597[] = {t2596};
    t2597 = shen_apply_direct(ctx, "shen.<integer>", 1, a2597);
  }
  KLObject* t2600;
  {
    KLObject* a2600[] = {t2597};
    t2600 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a2600);
  }
  KLObject* t2599;
  if (!shen_is_boolean(ctx, t2600))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t2600)) {
  KLObject* t2602 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t2599 = t2602;
  } else {
  KLObject* t2603;
  {
    KLObject* a2603[] = {t2597};
    t2603 = shen_apply_direct(ctx, "shen.<-out", 1, a2603);
  }
  KLObject* t2605;
  {
    KLObject* a2605[] = {t2597};
    t2605 = shen_apply_direct(ctx, "shen.in->", 1, a2605);
  }
  KLObject* t2607;
  {
    KLObject* a2607[] = {t2605};
    t2607 = shen_apply_direct(ctx, "shen.<stop>", 1, a2607);
  }
  KLObject* t2610;
  {
    KLObject* a2610[] = {t2607};
    t2610 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a2610);
  }
  KLObject* t2609;
  if (!shen_is_boolean(ctx, t2610))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t2610)) {
  KLObject* t2612 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t2609 = t2612;
  } else {
  KLObject* t2613;
  {
    KLObject* a2613[] = {t2607};
    t2613 = shen_apply_direct(ctx, "shen.in->", 1, a2613);
  }
  KLObject* t2615;
  {
    KLObject* a2615[] = {t2613};
    t2615 = shen_apply_direct(ctx, "shen.<fraction>", 1, a2615);
  }
  KLObject* t2618;
  {
    KLObject* a2618[] = {t2615};
    t2618 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a2618);
  }
  KLObject* t2617;
  if (!shen_is_boolean(ctx, t2618))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t2618)) {
  KLObject* t2620 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t2617 = t2620;
  } else {
  KLObject* t2621;
  {
    KLObject* a2621[] = {t2615};
    t2621 = shen_apply_direct(ctx, "shen.<-out", 1, a2621);
  }
  KLObject* t2623;
  {
    KLObject* a2623[] = {t2615};
    t2623 = shen_apply_direct(ctx, "shen.in->", 1, a2623);
  }
  KLObject* t2629 = shen_add(ctx, t2603, t2621);
  KLObject* t2625;
  {
    KLObject* a2625[] = {t2623, t2629};
    t2625 = shen_apply_direct(ctx, "shen.comb", 2, a2625);
  }
    t2617 = t2625;
  }
    t2609 = t2617;
  }
    t2599 = t2609;
  }
  KLObject* t2631;
  {
    KLObject* a2631[] = {t2599};
    t2631 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a2631);
  }
  KLObject* t2630;
  if (!shen_is_boolean(ctx, t2631))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t2631)) {
  KLObject* t2633;
  {
    KLObject* a2633[] = {t2596};
    t2633 = shen_apply_direct(ctx, "shen.<stop>", 1, a2633);
  }
  KLObject* t2636;
  {
    KLObject* a2636[] = {t2633};
    t2636 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a2636);
  }
  KLObject* t2635;
  if (!shen_is_boolean(ctx, t2636))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t2636)) {
  KLObject* t2638 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t2635 = t2638;
  } else {
  KLObject* t2639;
  {
    KLObject* a2639[] = {t2633};
    t2639 = shen_apply_direct(ctx, "shen.in->", 1, a2639);
  }
  KLObject* t2641;
  {
    KLObject* a2641[] = {t2639};
    t2641 = shen_apply_direct(ctx, "shen.<fraction>", 1, a2641);
  }
  KLObject* t2644;
  {
    KLObject* a2644[] = {t2641};
    t2644 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a2644);
  }
  KLObject* t2643;
  if (!shen_is_boolean(ctx, t2644))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t2644)) {
  KLObject* t2646 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t2643 = t2646;
  } else {
  KLObject* t2647;
  {
    KLObject* a2647[] = {t2641};
    t2647 = shen_apply_direct(ctx, "shen.<-out", 1, a2647);
  }
  KLObject* t2649;
  {
    KLObject* a2649[] = {t2641};
    t2649 = shen_apply_direct(ctx, "shen.in->", 1, a2649);
  }
  KLObject* t2651;
  {
    KLObject* a2651[] = {t2649, t2647};
    t2651 = shen_apply_direct(ctx, "shen.comb", 2, a2651);
  }
    t2643 = t2651;
  }
    t2635 = t2643;
  }
  KLObject* t2655;
  {
    KLObject* a2655[] = {t2635};
    t2655 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a2655);
  }
  KLObject* t2654;
  if (!shen_is_boolean(ctx, t2655))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t2655)) {
  KLObject* t2657 = shen_tail_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t2654 = t2657;
  } else {
    t2654 = t2635;
  }
    t2630 = t2654;
  } else {
    t2630 = t2599;
  }
    return t2630;
  }
}

static KLObject* native_kl_shen_2e_3cstop_3e_88 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t2660 = objects[0];
  tail_start_kl_shen_2e_3cstop_3e_88: ;
  KLObject* t2664 = shen_number_l(ctx, 46);
  KLObject* t2662;
  {
    KLObject* a2662[] = {t2660, t2664};
    t2662 = shen_apply_direct(ctx, "shen.hds=?", 2, a2662);
  }
  KLObject* t2661;
  if (!shen_is_boolean(ctx, t2662))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t2662)) {
  KLObject* t2665;
  {
    KLObject* a2665[] = {t2660};
    t2665 = shen_apply_direct(ctx, "tail", 1, a2665);
  }
  KLObject* t2669 = shen_intern(ctx, "shen.skip");
  KLObject* t2667;
  {
    KLObject* a2667[] = {t2665, t2669};
    t2667 = shen_apply_direct(ctx, "shen.comb", 2, a2667);
  }
    t2661 = t2667;
  } else {
  KLObject* t2670 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t2661 = t2670;
  }
  KLObject* t2672;
  {
    KLObject* a2672[] = {t2661};
    t2672 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a2672);
  }
  KLObject* t2671;
  if (!shen_is_boolean(ctx, t2672))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t2672)) {
  KLObject* t2674 = shen_tail_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t2671 = t2674;
  } else {
    t2671 = t2661;
  }
    return t2671;
  }
}

static KLObject* native_kl_shen_2e_3cfraction_3e_89 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t2676 = objects[0];
  tail_start_kl_shen_2e_3cfraction_3e_89: ;
  KLObject* t2677;
  {
    KLObject* a2677[] = {t2676};
    t2677 = shen_apply_direct(ctx, "shen.<digits>", 1, a2677);
  }
  KLObject* t2680;
  {
    KLObject* a2680[] = {t2677};
    t2680 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a2680);
  }
  KLObject* t2679;
  if (!shen_is_boolean(ctx, t2680))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t2680)) {
  KLObject* t2682 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t2679 = t2682;
  } else {
  KLObject* t2683;
  {
    KLObject* a2683[] = {t2677};
    t2683 = shen_apply_direct(ctx, "shen.<-out", 1, a2683);
  }
  KLObject* t2685;
  {
    KLObject* a2685[] = {t2677};
    t2685 = shen_apply_direct(ctx, "shen.in->", 1, a2685);
  }
  KLObject* t2689;
  {
    KLObject* a2689[] = {t2683};
    t2689 = shen_apply_direct(ctx, "shen.compute-fraction", 1, a2689);
  }
  KLObject* t2687;
  {
    KLObject* a2687[] = {t2685, t2689};
    t2687 = shen_apply_direct(ctx, "shen.comb", 2, a2687);
  }
    t2679 = t2687;
  }
  KLObject* t2692;
  {
    KLObject* a2692[] = {t2679};
    t2692 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a2692);
  }
  KLObject* t2691;
  if (!shen_is_boolean(ctx, t2692))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t2692)) {
  KLObject* t2694 = shen_tail_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t2691 = t2694;
  } else {
    t2691 = t2679;
  }
    return t2691;
  }
}

static KLObject* native_kl_shen_2ecompute_2dfraction_90 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t2696 = objects[0];
  tail_start_kl_shen_2ecompute_2dfraction_90: ;
  KLObject* t2699 = shen_number_l(ctx, -1);
  KLObject* t2697;
  {
    KLObject* a2697[] = {t2696, t2699};
    t2697 = shen_tail_apply_direct(ctx, "shen.compute-fraction-h", 2, a2697);
  }
    return t2697;
  }
}

static KLObject* native_kl_shen_2ecompute_2dfraction_2dh_91 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t2700 = objects[0];
    KLObject* t2701 = objects[1];
  tail_start_kl_shen_2ecompute_2dfraction_2dh_91: ;
  KLObject* t2702;
  {
  KLObject* t2703 = shen_empty_list(ctx);
  KLObject* t2705 = shen_eq(ctx, t2703, t2700);
    if (!shen_is_boolean(ctx, t2705))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t2705)) {
  KLObject* t2706 = shen_number_l(ctx, 0);
      t2702 = t2706;
    } else {
  KLObject* t2708 = shen_cons_p(ctx, t2700);
    if (!shen_is_boolean(ctx, t2708))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t2708)) {
  KLObject* t2710 = shen_number_l(ctx, 10);
  KLObject* t2709;
  {
    KLObject* a2709[] = {t2710, t2701};
    t2709 = shen_apply_direct(ctx, "shen.expt", 2, a2709);
  }
  KLObject* t2713 = shen_hd(ctx, t2700);
  KLObject* t2714 = shen_mul(ctx, t2709, t2713);
  KLObject* t2717 = shen_tl(ctx, t2700);
  KLObject* t2719 = shen_number_l(ctx, 1);
  KLObject* t2720 = shen_sub(ctx, t2701, t2719);
  KLObject* t2715;
  {
    KLObject* a2715[] = {t2717, t2720};
    t2715 = shen_apply_direct(ctx, "shen.compute-fraction-h", 2, a2715);
  }
  KLObject* t2721 = shen_add(ctx, t2714, t2715);
      t2702 = t2721;
    } else {
  KLObject* t2722 = shen_true(ctx);
    if (!shen_is_boolean(ctx, t2722))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t2722)) {
  KLObject* t2724 = shen_string(ctx, "partial function shen.compute-fraction-h");
  KLObject* t2723;
  {
    KLObject* a2723[] = {t2724};
    t2723 = shen_tail_apply_direct(ctx, "simple-error", 1, a2723);
  }
      t2702 = t2723;
    } else {
      shen_simple_error(ctx, "No true case found for cond");
      t2702 = shen_empty_list(ctx);
    }
    }
    }
  }
    return t2702;
  }
}

static KLObject* native_kl_shen_2e_3ce_2dnumber_3e_92 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t2725 = objects[0];
  tail_start_kl_shen_2e_3ce_2dnumber_3e_92: ;
  KLObject* t2726;
  {
    KLObject* a2726[] = {t2725};
    t2726 = shen_apply_direct(ctx, "shen.<float>", 1, a2726);
  }
  KLObject* t2729;
  {
    KLObject* a2729[] = {t2726};
    t2729 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a2729);
  }
  KLObject* t2728;
  if (!shen_is_boolean(ctx, t2729))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t2729)) {
  KLObject* t2731 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t2728 = t2731;
  } else {
  KLObject* t2732;
  {
    KLObject* a2732[] = {t2726};
    t2732 = shen_apply_direct(ctx, "shen.<-out", 1, a2732);
  }
  KLObject* t2734;
  {
    KLObject* a2734[] = {t2726};
    t2734 = shen_apply_direct(ctx, "shen.in->", 1, a2734);
  }
  KLObject* t2736;
  {
    KLObject* a2736[] = {t2734};
    t2736 = shen_apply_direct(ctx, "shen.<lowE>", 1, a2736);
  }
  KLObject* t2739;
  {
    KLObject* a2739[] = {t2736};
    t2739 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a2739);
  }
  KLObject* t2738;
  if (!shen_is_boolean(ctx, t2739))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t2739)) {
  KLObject* t2741 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t2738 = t2741;
  } else {
  KLObject* t2742;
  {
    KLObject* a2742[] = {t2736};
    t2742 = shen_apply_direct(ctx, "shen.in->", 1, a2742);
  }
  KLObject* t2744;
  {
    KLObject* a2744[] = {t2742};
    t2744 = shen_apply_direct(ctx, "shen.<log10>", 1, a2744);
  }
  KLObject* t2747;
  {
    KLObject* a2747[] = {t2744};
    t2747 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a2747);
  }
  KLObject* t2746;
  if (!shen_is_boolean(ctx, t2747))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t2747)) {
  KLObject* t2749 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t2746 = t2749;
  } else {
  KLObject* t2750;
  {
    KLObject* a2750[] = {t2744};
    t2750 = shen_apply_direct(ctx, "shen.<-out", 1, a2750);
  }
  KLObject* t2752;
  {
    KLObject* a2752[] = {t2744};
    t2752 = shen_apply_direct(ctx, "shen.in->", 1, a2752);
  }
  KLObject* t2756;
  {
    KLObject* a2756[] = {t2732, t2750};
    t2756 = shen_apply_direct(ctx, "shen.compute-E", 2, a2756);
  }
  KLObject* t2754;
  {
    KLObject* a2754[] = {t2752, t2756};
    t2754 = shen_apply_direct(ctx, "shen.comb", 2, a2754);
  }
    t2746 = t2754;
  }
    t2738 = t2746;
  }
    t2728 = t2738;
  }
  KLObject* t2760;
  {
    KLObject* a2760[] = {t2728};
    t2760 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a2760);
  }
  KLObject* t2759;
  if (!shen_is_boolean(ctx, t2760))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t2760)) {
  KLObject* t2762;
  {
    KLObject* a2762[] = {t2725};
    t2762 = shen_apply_direct(ctx, "shen.<integer>", 1, a2762);
  }
  KLObject* t2765;
  {
    KLObject* a2765[] = {t2762};
    t2765 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a2765);
  }
  KLObject* t2764;
  if (!shen_is_boolean(ctx, t2765))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t2765)) {
  KLObject* t2767 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t2764 = t2767;
  } else {
  KLObject* t2768;
  {
    KLObject* a2768[] = {t2762};
    t2768 = shen_apply_direct(ctx, "shen.<-out", 1, a2768);
  }
  KLObject* t2770;
  {
    KLObject* a2770[] = {t2762};
    t2770 = shen_apply_direct(ctx, "shen.in->", 1, a2770);
  }
  KLObject* t2772;
  {
    KLObject* a2772[] = {t2770};
    t2772 = shen_apply_direct(ctx, "shen.<lowE>", 1, a2772);
  }
  KLObject* t2775;
  {
    KLObject* a2775[] = {t2772};
    t2775 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a2775);
  }
  KLObject* t2774;
  if (!shen_is_boolean(ctx, t2775))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t2775)) {
  KLObject* t2777 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t2774 = t2777;
  } else {
  KLObject* t2778;
  {
    KLObject* a2778[] = {t2772};
    t2778 = shen_apply_direct(ctx, "shen.in->", 1, a2778);
  }
  KLObject* t2780;
  {
    KLObject* a2780[] = {t2778};
    t2780 = shen_apply_direct(ctx, "shen.<log10>", 1, a2780);
  }
  KLObject* t2783;
  {
    KLObject* a2783[] = {t2780};
    t2783 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a2783);
  }
  KLObject* t2782;
  if (!shen_is_boolean(ctx, t2783))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t2783)) {
  KLObject* t2785 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t2782 = t2785;
  } else {
  KLObject* t2786;
  {
    KLObject* a2786[] = {t2780};
    t2786 = shen_apply_direct(ctx, "shen.<-out", 1, a2786);
  }
  KLObject* t2788;
  {
    KLObject* a2788[] = {t2780};
    t2788 = shen_apply_direct(ctx, "shen.in->", 1, a2788);
  }
  KLObject* t2792;
  {
    KLObject* a2792[] = {t2768, t2786};
    t2792 = shen_apply_direct(ctx, "shen.compute-E", 2, a2792);
  }
  KLObject* t2790;
  {
    KLObject* a2790[] = {t2788, t2792};
    t2790 = shen_apply_direct(ctx, "shen.comb", 2, a2790);
  }
    t2782 = t2790;
  }
    t2774 = t2782;
  }
    t2764 = t2774;
  }
  KLObject* t2796;
  {
    KLObject* a2796[] = {t2764};
    t2796 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a2796);
  }
  KLObject* t2795;
  if (!shen_is_boolean(ctx, t2796))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t2796)) {
  KLObject* t2798 = shen_tail_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t2795 = t2798;
  } else {
    t2795 = t2764;
  }
    t2759 = t2795;
  } else {
    t2759 = t2728;
  }
    return t2759;
  }
}

static KLObject* native_kl_shen_2e_3clog10_3e_93 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t2801 = objects[0];
  tail_start_kl_shen_2e_3clog10_3e_93: ;
  KLObject* t2802;
  {
    KLObject* a2802[] = {t2801};
    t2802 = shen_apply_direct(ctx, "shen.<plus>", 1, a2802);
  }
  KLObject* t2805;
  {
    KLObject* a2805[] = {t2802};
    t2805 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a2805);
  }
  KLObject* t2804;
  if (!shen_is_boolean(ctx, t2805))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t2805)) {
  KLObject* t2807 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t2804 = t2807;
  } else {
  KLObject* t2808;
  {
    KLObject* a2808[] = {t2802};
    t2808 = shen_apply_direct(ctx, "shen.in->", 1, a2808);
  }
  KLObject* t2810;
  {
    KLObject* a2810[] = {t2808};
    t2810 = shen_apply_direct(ctx, "shen.<log10>", 1, a2810);
  }
  KLObject* t2813;
  {
    KLObject* a2813[] = {t2810};
    t2813 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a2813);
  }
  KLObject* t2812;
  if (!shen_is_boolean(ctx, t2813))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t2813)) {
  KLObject* t2815 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t2812 = t2815;
  } else {
  KLObject* t2816;
  {
    KLObject* a2816[] = {t2810};
    t2816 = shen_apply_direct(ctx, "shen.<-out", 1, a2816);
  }
  KLObject* t2818;
  {
    KLObject* a2818[] = {t2810};
    t2818 = shen_apply_direct(ctx, "shen.in->", 1, a2818);
  }
  KLObject* t2820;
  {
    KLObject* a2820[] = {t2818, t2816};
    t2820 = shen_apply_direct(ctx, "shen.comb", 2, a2820);
  }
    t2812 = t2820;
  }
    t2804 = t2812;
  }
  KLObject* t2824;
  {
    KLObject* a2824[] = {t2804};
    t2824 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a2824);
  }
  KLObject* t2823;
  if (!shen_is_boolean(ctx, t2824))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t2824)) {
  KLObject* t2826;
  {
    KLObject* a2826[] = {t2801};
    t2826 = shen_apply_direct(ctx, "shen.<minus>", 1, a2826);
  }
  KLObject* t2829;
  {
    KLObject* a2829[] = {t2826};
    t2829 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a2829);
  }
  KLObject* t2828;
  if (!shen_is_boolean(ctx, t2829))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t2829)) {
  KLObject* t2831 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t2828 = t2831;
  } else {
  KLObject* t2832;
  {
    KLObject* a2832[] = {t2826};
    t2832 = shen_apply_direct(ctx, "shen.in->", 1, a2832);
  }
  KLObject* t2834;
  {
    KLObject* a2834[] = {t2832};
    t2834 = shen_apply_direct(ctx, "shen.<log10>", 1, a2834);
  }
  KLObject* t2837;
  {
    KLObject* a2837[] = {t2834};
    t2837 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a2837);
  }
  KLObject* t2836;
  if (!shen_is_boolean(ctx, t2837))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t2837)) {
  KLObject* t2839 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t2836 = t2839;
  } else {
  KLObject* t2840;
  {
    KLObject* a2840[] = {t2834};
    t2840 = shen_apply_direct(ctx, "shen.<-out", 1, a2840);
  }
  KLObject* t2842;
  {
    KLObject* a2842[] = {t2834};
    t2842 = shen_apply_direct(ctx, "shen.in->", 1, a2842);
  }
  KLObject* t2846 = shen_number_l(ctx, 0);
  KLObject* t2848 = shen_sub(ctx, t2846, t2840);
  KLObject* t2844;
  {
    KLObject* a2844[] = {t2842, t2848};
    t2844 = shen_apply_direct(ctx, "shen.comb", 2, a2844);
  }
    t2836 = t2844;
  }
    t2828 = t2836;
  }
  KLObject* t2850;
  {
    KLObject* a2850[] = {t2828};
    t2850 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a2850);
  }
  KLObject* t2849;
  if (!shen_is_boolean(ctx, t2850))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t2850)) {
  KLObject* t2852;
  {
    KLObject* a2852[] = {t2801};
    t2852 = shen_apply_direct(ctx, "shen.<integer>", 1, a2852);
  }
  KLObject* t2855;
  {
    KLObject* a2855[] = {t2852};
    t2855 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a2855);
  }
  KLObject* t2854;
  if (!shen_is_boolean(ctx, t2855))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t2855)) {
  KLObject* t2857 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t2854 = t2857;
  } else {
  KLObject* t2858;
  {
    KLObject* a2858[] = {t2852};
    t2858 = shen_apply_direct(ctx, "shen.<-out", 1, a2858);
  }
  KLObject* t2860;
  {
    KLObject* a2860[] = {t2852};
    t2860 = shen_apply_direct(ctx, "shen.in->", 1, a2860);
  }
  KLObject* t2862;
  {
    KLObject* a2862[] = {t2860, t2858};
    t2862 = shen_apply_direct(ctx, "shen.comb", 2, a2862);
  }
    t2854 = t2862;
  }
  KLObject* t2866;
  {
    KLObject* a2866[] = {t2854};
    t2866 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a2866);
  }
  KLObject* t2865;
  if (!shen_is_boolean(ctx, t2866))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t2866)) {
  KLObject* t2868 = shen_tail_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t2865 = t2868;
  } else {
    t2865 = t2854;
  }
    t2849 = t2865;
  } else {
    t2849 = t2828;
  }
    t2823 = t2849;
  } else {
    t2823 = t2804;
  }
    return t2823;
  }
}

static KLObject* native_kl_shen_2e_3clowE_3e_94 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t2872 = objects[0];
  tail_start_kl_shen_2e_3clowE_3e_94: ;
  KLObject* t2876 = shen_number_l(ctx, 101);
  KLObject* t2874;
  {
    KLObject* a2874[] = {t2872, t2876};
    t2874 = shen_apply_direct(ctx, "shen.hds=?", 2, a2874);
  }
  KLObject* t2873;
  if (!shen_is_boolean(ctx, t2874))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t2874)) {
  KLObject* t2877;
  {
    KLObject* a2877[] = {t2872};
    t2877 = shen_apply_direct(ctx, "tail", 1, a2877);
  }
  KLObject* t2881 = shen_intern(ctx, "shen.skip");
  KLObject* t2879;
  {
    KLObject* a2879[] = {t2877, t2881};
    t2879 = shen_apply_direct(ctx, "shen.comb", 2, a2879);
  }
    t2873 = t2879;
  } else {
  KLObject* t2882 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t2873 = t2882;
  }
  KLObject* t2884;
  {
    KLObject* a2884[] = {t2873};
    t2884 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a2884);
  }
  KLObject* t2883;
  if (!shen_is_boolean(ctx, t2884))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t2884)) {
  KLObject* t2886 = shen_tail_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t2883 = t2886;
  } else {
    t2883 = t2873;
  }
    return t2883;
  }
}

static KLObject* native_kl_shen_2ecompute_2dE_95 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t2888 = objects[0];
    KLObject* t2889 = objects[1];
  tail_start_kl_shen_2ecompute_2dE_95: ;
  KLObject* t2892 = shen_number_l(ctx, 10);
  KLObject* t2891;
  {
    KLObject* a2891[] = {t2892, t2889};
    t2891 = shen_apply_direct(ctx, "shen.expt", 2, a2891);
  }
  KLObject* t2894 = shen_mul(ctx, t2888, t2891);
    return t2894;
  }
}

static KLObject* native_kl_shen_2e_3cwhitespaces_3e_96 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t2895 = objects[0];
  tail_start_kl_shen_2e_3cwhitespaces_3e_96: ;
  KLObject* t2896;
  {
    KLObject* a2896[] = {t2895};
    t2896 = shen_apply_direct(ctx, "shen.<whitespace>", 1, a2896);
  }
  KLObject* t2899;
  {
    KLObject* a2899[] = {t2896};
    t2899 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a2899);
  }
  KLObject* t2898;
  if (!shen_is_boolean(ctx, t2899))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t2899)) {
  KLObject* t2901 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t2898 = t2901;
  } else {
  KLObject* t2902;
  {
    KLObject* a2902[] = {t2896};
    t2902 = shen_apply_direct(ctx, "shen.in->", 1, a2902);
  }
  KLObject* t2904;
  {
    KLObject* a2904[] = {t2902};
    t2904 = shen_apply_direct(ctx, "shen.<whitespaces>", 1, a2904);
  }
  KLObject* t2907;
  {
    KLObject* a2907[] = {t2904};
    t2907 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a2907);
  }
  KLObject* t2906;
  if (!shen_is_boolean(ctx, t2907))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t2907)) {
  KLObject* t2909 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t2906 = t2909;
  } else {
  KLObject* t2910;
  {
    KLObject* a2910[] = {t2904};
    t2910 = shen_apply_direct(ctx, "shen.in->", 1, a2910);
  }
  KLObject* t2914 = shen_intern(ctx, "shen.skip");
  KLObject* t2912;
  {
    KLObject* a2912[] = {t2910, t2914};
    t2912 = shen_apply_direct(ctx, "shen.comb", 2, a2912);
  }
    t2906 = t2912;
  }
    t2898 = t2906;
  }
  KLObject* t2916;
  {
    KLObject* a2916[] = {t2898};
    t2916 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a2916);
  }
  KLObject* t2915;
  if (!shen_is_boolean(ctx, t2916))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t2916)) {
  KLObject* t2918;
  {
    KLObject* a2918[] = {t2895};
    t2918 = shen_apply_direct(ctx, "shen.<whitespace>", 1, a2918);
  }
  KLObject* t2921;
  {
    KLObject* a2921[] = {t2918};
    t2921 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a2921);
  }
  KLObject* t2920;
  if (!shen_is_boolean(ctx, t2921))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t2921)) {
  KLObject* t2923 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t2920 = t2923;
  } else {
  KLObject* t2924;
  {
    KLObject* a2924[] = {t2918};
    t2924 = shen_apply_direct(ctx, "shen.in->", 1, a2924);
  }
  KLObject* t2928 = shen_intern(ctx, "shen.skip");
  KLObject* t2926;
  {
    KLObject* a2926[] = {t2924, t2928};
    t2926 = shen_apply_direct(ctx, "shen.comb", 2, a2926);
  }
    t2920 = t2926;
  }
  KLObject* t2930;
  {
    KLObject* a2930[] = {t2920};
    t2930 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a2930);
  }
  KLObject* t2929;
  if (!shen_is_boolean(ctx, t2930))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t2930)) {
  KLObject* t2932 = shen_tail_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t2929 = t2932;
  } else {
    t2929 = t2920;
  }
    t2915 = t2929;
  } else {
    t2915 = t2898;
  }
    return t2915;
  }
}

static KLObject* native_kl_shen_2e_3cwhitespace_3e_97 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t2935 = objects[0];
  tail_start_kl_shen_2e_3cwhitespace_3e_97: ;
  KLObject* t2938 = shen_cons_p(ctx, t2935);
  KLObject* t2936;
  if (!shen_is_boolean(ctx, t2938))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t2938)) {
  KLObject* t2939;
  {
    KLObject* a2939[] = {t2935};
    t2939 = shen_apply_direct(ctx, "head", 1, a2939);
  }
  KLObject* t2941;
  {
    KLObject* a2941[] = {t2935};
    t2941 = shen_apply_direct(ctx, "tail", 1, a2941);
  }
  KLObject* t2944;
  {
    KLObject* a2944[] = {t2939};
    t2944 = shen_apply_direct(ctx, "shen.whitespace?", 1, a2944);
  }
  KLObject* t2943;
  if (!shen_is_boolean(ctx, t2944))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t2944)) {
  KLObject* t2948 = shen_intern(ctx, "shen.skip");
  KLObject* t2946;
  {
    KLObject* a2946[] = {t2941, t2948};
    t2946 = shen_apply_direct(ctx, "shen.comb", 2, a2946);
  }
    t2943 = t2946;
  } else {
  KLObject* t2949 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t2943 = t2949;
  }
    t2936 = t2943;
  } else {
  KLObject* t2950 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t2936 = t2950;
  }
  KLObject* t2952;
  {
    KLObject* a2952[] = {t2936};
    t2952 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a2952);
  }
  KLObject* t2951;
  if (!shen_is_boolean(ctx, t2952))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t2952)) {
  KLObject* t2954 = shen_tail_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t2951 = t2954;
  } else {
    t2951 = t2936;
  }
    return t2951;
  }
}

static KLObject* native_kl_shen_2ewhitespace_3f_98 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t2956 = objects[0];
  tail_start_kl_shen_2ewhitespace_3f_98: ;
  KLObject* t2957;
  {
  KLObject* t2958 = shen_number_l(ctx, 32);
  KLObject* t2960 = shen_eq(ctx, t2958, t2956);
    if (!shen_is_boolean(ctx, t2960))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t2960)) {
  KLObject* t2961 = shen_true(ctx);
      t2957 = t2961;
    } else {
  KLObject* t2962 = shen_number_l(ctx, 13);
  KLObject* t2964 = shen_eq(ctx, t2962, t2956);
    if (!shen_is_boolean(ctx, t2964))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t2964)) {
  KLObject* t2965 = shen_true(ctx);
      t2957 = t2965;
    } else {
  KLObject* t2966 = shen_number_l(ctx, 10);
  KLObject* t2968 = shen_eq(ctx, t2966, t2956);
    if (!shen_is_boolean(ctx, t2968))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t2968)) {
  KLObject* t2969 = shen_true(ctx);
      t2957 = t2969;
    } else {
  KLObject* t2970 = shen_number_l(ctx, 9);
  KLObject* t2972 = shen_eq(ctx, t2970, t2956);
    if (!shen_is_boolean(ctx, t2972))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t2972)) {
  KLObject* t2973 = shen_true(ctx);
      t2957 = t2973;
    } else {
  KLObject* t2974 = shen_true(ctx);
    if (!shen_is_boolean(ctx, t2974))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t2974)) {
  KLObject* t2975 = shen_false(ctx);
      t2957 = t2975;
    } else {
      shen_simple_error(ctx, "No true case found for cond");
      t2957 = shen_empty_list(ctx);
    }
    }
    }
    }
    }
  }
    return t2957;
  }
}

static KLObject* native_kl_shen_2eunpackage_26macroexpand_99 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t2976 = objects[0];
  tail_start_kl_shen_2eunpackage_26macroexpand_99: ;
  KLObject* t2977;
  {
  KLObject* t2978 = shen_empty_list(ctx);
  KLObject* t2980 = shen_eq(ctx, t2978, t2976);
    if (!shen_is_boolean(ctx, t2980))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t2980)) {
  KLObject* t2981 = shen_empty_list(ctx);
      t2977 = t2981;
    } else {
  KLObject* t2984 = shen_cons_p(ctx, t2976);
  KLObject* t2982;
  if (!shen_is_boolean(ctx, t2984))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t2984)) {
    t2982 = t2984;
  } else {
  KLObject* t2987 = shen_hd(ctx, t2976);
  KLObject* t2985;
  {
    KLObject* a2985[] = {t2987};
    t2985 = shen_apply_direct(ctx, "shen.packaged?", 1, a2985);
  }
    if (!shen_is_boolean(ctx, t2985))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t2982 = t2985;
  }
    if (!shen_is_boolean(ctx, t2982))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t2982)) {
  KLObject* t2991 = shen_hd(ctx, t2976);
  KLObject* t2989;
  {
    KLObject* a2989[] = {t2991};
    t2989 = shen_apply_direct(ctx, "shen.unpackage", 1, a2989);
  }
  KLObject* t2993 = shen_tl(ctx, t2976);
  KLObject* t2988;
  {
    KLObject* a2988[] = {t2989, t2993};
    t2988 = shen_apply_direct(ctx, "append", 2, a2988);
  }
  {
    KLObject* n2994_0 = t2988;
    t2976 = n2994_0;
    goto tail_start_kl_shen_2eunpackage_26macroexpand_99;
  }
  KLObject* t2994 = NULL;
      t2977 = t2994;
    } else {
  KLObject* t2996 = shen_cons_p(ctx, t2976);
    if (!shen_is_boolean(ctx, t2996))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t2996)) {
  KLObject* t2999 = shen_hd(ctx, t2976);
  KLObject* t2997;
  {
    KLObject* a2997[] = {t2999};
    t2997 = shen_apply_direct(ctx, "macroexpand", 1, a2997);
  }
  KLObject* t3001;
  {
    KLObject* a3001[] = {t2997};
    t3001 = shen_apply_direct(ctx, "shen.packaged?", 1, a3001);
  }
  KLObject* t3000;
  if (!shen_is_boolean(ctx, t3001))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t3001)) {
  KLObject* t3005 = shen_tl(ctx, t2976);
  KLObject* t3006 = shen_cons(ctx, t2997, t3005);
  {
    KLObject* n3007_0 = t3006;
    t2976 = n3007_0;
    goto tail_start_kl_shen_2eunpackage_26macroexpand_99;
  }
  KLObject* t3007 = NULL;
    t3000 = t3007;
  } else {
  KLObject* t3011 = shen_tl(ctx, t2976);
  KLObject* t3009;
  {
    KLObject* a3009[] = {t3011};
    t3009 = shen_apply_direct(ctx, "shen.unpackage&macroexpand", 1, a3009);
  }
  KLObject* t3012 = shen_cons(ctx, t2997, t3009);
    t3000 = t3012;
  }
      t2977 = t3000;
    } else {
  KLObject* t3013 = shen_true(ctx);
    if (!shen_is_boolean(ctx, t3013))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t3013)) {
  KLObject* t3015 = shen_string(ctx, "partial function shen.unpackage&macroexpand");
  KLObject* t3014;
  {
    KLObject* a3014[] = {t3015};
    t3014 = shen_tail_apply_direct(ctx, "simple-error", 1, a3014);
  }
      t2977 = t3014;
    } else {
      shen_simple_error(ctx, "No true case found for cond");
      t2977 = shen_empty_list(ctx);
    }
    }
    }
    }
  }
    return t2977;
  }
}

static KLObject* native_kl_shen_2epackaged_3f_100 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t3016 = objects[0];
  tail_start_kl_shen_2epackaged_3f_100: ;
  KLObject* t3017;
  {
  KLObject* t3020 = shen_cons_p(ctx, t3016);
  KLObject* t3018;
  if (!shen_is_boolean(ctx, t3020))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t3020)) {
    t3018 = t3020;
  } else {
  KLObject* t3022 = shen_intern(ctx, "package");
  KLObject* t3024 = shen_hd(ctx, t3016);
  KLObject* t3025 = shen_eq(ctx, t3022, t3024);
  KLObject* t3021;
  if (!shen_is_boolean(ctx, t3025))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t3025)) {
    t3021 = t3025;
  } else {
  KLObject* t3028 = shen_tl(ctx, t3016);
  KLObject* t3029 = shen_cons_p(ctx, t3028);
  KLObject* t3026;
  if (!shen_is_boolean(ctx, t3029))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t3029)) {
    t3026 = t3029;
  } else {
  KLObject* t3031 = shen_tl(ctx, t3016);
  KLObject* t3032 = shen_tl(ctx, t3031);
  KLObject* t3033 = shen_cons_p(ctx, t3032);
    if (!shen_is_boolean(ctx, t3033))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t3026 = t3033;
  }
    if (!shen_is_boolean(ctx, t3026))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t3021 = t3026;
  }
    if (!shen_is_boolean(ctx, t3021))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t3018 = t3021;
  }
    if (!shen_is_boolean(ctx, t3018))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t3018)) {
  KLObject* t3034 = shen_true(ctx);
      t3017 = t3034;
    } else {
  KLObject* t3035 = shen_true(ctx);
    if (!shen_is_boolean(ctx, t3035))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t3035)) {
  KLObject* t3036 = shen_false(ctx);
      t3017 = t3036;
    } else {
      shen_simple_error(ctx, "No true case found for cond");
      t3017 = shen_empty_list(ctx);
    }
    }
  }
    return t3017;
  }
}

static KLObject* native_kl_shen_2eunpackage_101 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t3037 = objects[0];
  tail_start_kl_shen_2eunpackage_101: ;
  KLObject* t3038;
  {
  KLObject* t3041 = shen_cons_p(ctx, t3037);
  KLObject* t3039;
  if (!shen_is_boolean(ctx, t3041))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t3041)) {
    t3039 = t3041;
  } else {
  KLObject* t3043 = shen_intern(ctx, "package");
  KLObject* t3045 = shen_hd(ctx, t3037);
  KLObject* t3046 = shen_eq(ctx, t3043, t3045);
  KLObject* t3042;
  if (!shen_is_boolean(ctx, t3046))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t3046)) {
    t3042 = t3046;
  } else {
  KLObject* t3049 = shen_tl(ctx, t3037);
  KLObject* t3050 = shen_cons_p(ctx, t3049);
  KLObject* t3047;
  if (!shen_is_boolean(ctx, t3050))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t3050)) {
    t3047 = t3050;
  } else {
  KLObject* t3052 = shen_intern(ctx, "null");
  KLObject* t3054 = shen_tl(ctx, t3037);
  KLObject* t3055 = shen_hd(ctx, t3054);
  KLObject* t3056 = shen_eq(ctx, t3052, t3055);
  KLObject* t3051;
  if (!shen_is_boolean(ctx, t3056))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t3056)) {
    t3051 = t3056;
  } else {
  KLObject* t3058 = shen_tl(ctx, t3037);
  KLObject* t3059 = shen_tl(ctx, t3058);
  KLObject* t3060 = shen_cons_p(ctx, t3059);
    if (!shen_is_boolean(ctx, t3060))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t3051 = t3060;
  }
    if (!shen_is_boolean(ctx, t3051))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t3047 = t3051;
  }
    if (!shen_is_boolean(ctx, t3047))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t3042 = t3047;
  }
    if (!shen_is_boolean(ctx, t3042))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t3039 = t3042;
  }
    if (!shen_is_boolean(ctx, t3039))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t3039)) {
  KLObject* t3062 = shen_tl(ctx, t3037);
  KLObject* t3063 = shen_tl(ctx, t3062);
  KLObject* t3064 = shen_tl(ctx, t3063);
      t3038 = t3064;
    } else {
  KLObject* t3067 = shen_cons_p(ctx, t3037);
  KLObject* t3065;
  if (!shen_is_boolean(ctx, t3067))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t3067)) {
    t3065 = t3067;
  } else {
  KLObject* t3069 = shen_intern(ctx, "package");
  KLObject* t3071 = shen_hd(ctx, t3037);
  KLObject* t3072 = shen_eq(ctx, t3069, t3071);
  KLObject* t3068;
  if (!shen_is_boolean(ctx, t3072))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t3072)) {
    t3068 = t3072;
  } else {
  KLObject* t3075 = shen_tl(ctx, t3037);
  KLObject* t3076 = shen_cons_p(ctx, t3075);
  KLObject* t3073;
  if (!shen_is_boolean(ctx, t3076))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t3076)) {
    t3073 = t3076;
  } else {
  KLObject* t3078 = shen_tl(ctx, t3037);
  KLObject* t3079 = shen_tl(ctx, t3078);
  KLObject* t3080 = shen_cons_p(ctx, t3079);
    if (!shen_is_boolean(ctx, t3080))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t3073 = t3080;
  }
    if (!shen_is_boolean(ctx, t3073))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t3068 = t3073;
  }
    if (!shen_is_boolean(ctx, t3068))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t3065 = t3068;
  }
    if (!shen_is_boolean(ctx, t3065))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t3065)) {
  KLObject* t3083 = shen_tl(ctx, t3037);
  KLObject* t3084 = shen_tl(ctx, t3083);
  KLObject* t3085 = shen_hd(ctx, t3084);
  KLObject* t3081;
  {
    KLObject* a3081[] = {t3085};
    t3081 = shen_apply_direct(ctx, "eval", 1, a3081);
  }
  KLObject* t3089 = shen_tl(ctx, t3037);
  KLObject* t3090 = shen_hd(ctx, t3089);
  KLObject* t3087;
  {
    KLObject* a3087[] = {t3090};
    t3087 = shen_apply_direct(ctx, "str", 1, a3087);
  }
  KLObject* t3093 = shen_tl(ctx, t3037);
  KLObject* t3094 = shen_tl(ctx, t3093);
  KLObject* t3095 = shen_tl(ctx, t3094);
  KLObject* t3086;
  {
    KLObject* a3086[] = {t3087, t3081, t3095};
    t3086 = shen_apply_direct(ctx, "shen.package-symbols", 3, a3086);
  }
  KLObject* t3098 = shen_tl(ctx, t3037);
  KLObject* t3099 = shen_hd(ctx, t3098);
  KLObject* t3096;
  {
    KLObject* a3096[] = {t3099, t3081};
    t3096 = shen_apply_direct(ctx, "shen.record-external", 2, a3096);
  }
  KLObject* t3103 = shen_tl(ctx, t3037);
  KLObject* t3104 = shen_hd(ctx, t3103);
  KLObject* t3107 = shen_tl(ctx, t3037);
  KLObject* t3108 = shen_tl(ctx, t3107);
  KLObject* t3109 = shen_tl(ctx, t3108);
  KLObject* t3101;
  {
    KLObject* a3101[] = {t3104, t3081, t3109};
    t3101 = shen_apply_direct(ctx, "shen.record-internal", 3, a3101);
  }
      t3038 = t3086;
    } else {
  KLObject* t3111 = shen_true(ctx);
    if (!shen_is_boolean(ctx, t3111))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t3111)) {
  KLObject* t3113 = shen_string(ctx, "partial function shen.unpackage");
  KLObject* t3112;
  {
    KLObject* a3112[] = {t3113};
    t3112 = shen_tail_apply_direct(ctx, "simple-error", 1, a3112);
  }
      t3038 = t3112;
    } else {
      shen_simple_error(ctx, "No true case found for cond");
      t3038 = shen_empty_list(ctx);
    }
    }
    }
  }
    return t3038;
  }
}

static KLObject* native_kl_shen_2erecord_2dinternal_102 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t3114 = objects[0];
    KLObject* t3115 = objects[1];
    KLObject* t3116 = objects[2];
  tail_start_kl_shen_2erecord_2dinternal_102: ;
  KLObject* t3117;
  {
    Vector* tenv_2 = shen_vector(ctx, 3);
    shen_vector_set(ctx, tenv_2, 0, t3114);
    shen_vector_set(ctx, tenv_2, 1, t3115);
    shen_vector_set(ctx, tenv_2, 2, t3116);
    t3117 = shen_trap_error(ctx, trap_body_2, trap_handler_2, tenv_2);
  }
  KLObject* t3134;
  {
    KLObject* a3134[] = {t3114};
    t3134 = shen_apply_direct(ctx, "str", 1, a3134);
  }
  KLObject* t3133;
  {
    KLObject* a3133[] = {t3134, t3115, t3116};
    t3133 = shen_apply_direct(ctx, "shen.internal-symbols", 3, a3133);
  }
  KLObject* t3140 = shen_intern(ctx, "shen.internal-symbols");
  KLObject* t3141;
  {
    KLObject* a3141[] = {t3133, t3117};
    t3141 = shen_apply_direct(ctx, "union", 2, a3141);
  }
  KLObject* t3145 = shen_intern(ctx, "*property-vector*");
  KLObject* t3144;
  {
    KLObject* a3144[] = {t3145};
    t3144 = shen_apply_direct(ctx, "value", 1, a3144);
  }
  KLObject* t3138;
  {
    KLObject* a3138[] = {t3114, t3140, t3141, t3144};
    t3138 = shen_tail_apply_direct(ctx, "put", 4, a3138);
  }
    return t3138;
  }
}

static KLObject* native_kl_shen_2einternal_2dsymbols_103 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t3146 = objects[0];
    KLObject* t3147 = objects[1];
    KLObject* t3148 = objects[2];
  tail_start_kl_shen_2einternal_2dsymbols_103: ;
  KLObject* t3149;
  {
  KLObject* t3151 = shen_cons_p(ctx, t3148);
    if (!shen_is_boolean(ctx, t3151))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t3151)) {
  KLObject* t3157 = shen_hd(ctx, t3148);
  KLObject* t3153;
  {
    KLObject* a3153[] = {t3146, t3147, t3157};
    t3153 = shen_apply_direct(ctx, "shen.internal-symbols", 3, a3153);
  }
  KLObject* t3162 = shen_tl(ctx, t3148);
  KLObject* t3158;
  {
    KLObject* a3158[] = {t3146, t3147, t3162};
    t3158 = shen_apply_direct(ctx, "shen.internal-symbols", 3, a3158);
  }
  KLObject* t3152;
  {
    KLObject* a3152[] = {t3153, t3158};
    t3152 = shen_tail_apply_direct(ctx, "union", 2, a3152);
  }
      t3149 = t3152;
    } else {
  KLObject* t3163;
  {
    KLObject* a3163[] = {t3148, t3146, t3147};
    t3163 = shen_apply_direct(ctx, "shen.internal?", 3, a3163);
  }
    if (!shen_is_boolean(ctx, t3163))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t3163)) {
  KLObject* t3167;
  {
    KLObject* a3167[] = {t3146, t3148};
    t3167 = shen_apply_direct(ctx, "shen.intern-in-package", 2, a3167);
  }
  KLObject* t3170 = shen_empty_list(ctx);
  KLObject* t3171 = shen_cons(ctx, t3167, t3170);
      t3149 = t3171;
    } else {
  KLObject* t3172 = shen_true(ctx);
    if (!shen_is_boolean(ctx, t3172))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t3172)) {
  KLObject* t3173 = shen_empty_list(ctx);
      t3149 = t3173;
    } else {
      shen_simple_error(ctx, "No true case found for cond");
      t3149 = shen_empty_list(ctx);
    }
    }
    }
  }
    return t3149;
  }
}

static KLObject* native_kl_shen_2erecord_2dexternal_104 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t3174 = objects[0];
    KLObject* t3175 = objects[1];
  tail_start_kl_shen_2erecord_2dexternal_104: ;
  KLObject* t3176;
  {
    Vector* tenv_3 = shen_vector(ctx, 2);
    shen_vector_set(ctx, tenv_3, 0, t3174);
    shen_vector_set(ctx, tenv_3, 1, t3175);
    t3176 = shen_trap_error(ctx, trap_body_3, trap_handler_3, tenv_3);
  }
  KLObject* t3192 = shen_intern(ctx, "shen.external-symbols");
  KLObject* t3193;
  {
    KLObject* a3193[] = {t3175, t3176};
    t3193 = shen_apply_direct(ctx, "union", 2, a3193);
  }
  KLObject* t3197 = shen_intern(ctx, "*property-vector*");
  KLObject* t3196;
  {
    KLObject* a3196[] = {t3197};
    t3196 = shen_apply_direct(ctx, "value", 1, a3196);
  }
  KLObject* t3190;
  {
    KLObject* a3190[] = {t3174, t3192, t3193, t3196};
    t3190 = shen_tail_apply_direct(ctx, "put", 4, a3190);
  }
    return t3190;
  }
}

static KLObject* native_kl_shen_2epackage_2dsymbols_105 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t3198 = objects[0];
    KLObject* t3199 = objects[1];
    KLObject* t3200 = objects[2];
  tail_start_kl_shen_2epackage_2dsymbols_105: ;
  KLObject* t3201;
  {
  KLObject* t3203 = shen_cons_p(ctx, t3200);
    if (!shen_is_boolean(ctx, t3203))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t3203)) {
  KLObject* t3205;
  {
    Vector* caps_14 = shen_vector(ctx, 2);
    shen_vector_set(ctx, caps_14, 0, t3198);
    shen_vector_set(ctx, caps_14, 1, t3199);
    t3205 = shen_native_closure(ctx, 1, &lambda_14, caps_14);
  }
  KLObject* t3204;
  {
    KLObject* a3204[] = {t3205, t3200};
    t3204 = shen_tail_apply_direct(ctx, "map", 2, a3204);
  }
      t3201 = t3204;
    } else {
  KLObject* t3214;
  {
    KLObject* a3214[] = {t3200, t3198, t3199};
    t3214 = shen_apply_direct(ctx, "shen.internal?", 3, a3214);
  }
    if (!shen_is_boolean(ctx, t3214))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t3214)) {
  KLObject* t3218;
  {
    KLObject* a3218[] = {t3198, t3200};
    t3218 = shen_tail_apply_direct(ctx, "shen.intern-in-package", 2, a3218);
  }
      t3201 = t3218;
    } else {
  KLObject* t3221 = shen_true(ctx);
    if (!shen_is_boolean(ctx, t3221))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t3221)) {
      t3201 = t3200;
    } else {
      shen_simple_error(ctx, "No true case found for cond");
      t3201 = shen_empty_list(ctx);
    }
    }
    }
  }
    return t3201;
  }
}

static KLObject* native_kl_shen_2eintern_2din_2dpackage_106 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t3223 = objects[0];
    KLObject* t3224 = objects[1];
  tail_start_kl_shen_2eintern_2din_2dpackage_106: ;
  KLObject* t3229 = shen_string(ctx, ".");
  KLObject* t3230;
  {
    KLObject* a3230[] = {t3224};
    t3230 = shen_apply_direct(ctx, "str", 1, a3230);
  }
  KLObject* t3228;
  {
    KLObject* a3228[] = {t3229, t3230};
    t3228 = shen_apply_direct(ctx, "@s", 2, a3228);
  }
  KLObject* t3226;
  {
    KLObject* a3226[] = {t3223, t3228};
    t3226 = shen_apply_direct(ctx, "@s", 2, a3226);
  }
  KLObject* t3225;
  {
    KLObject* a3225[] = {t3226};
    t3225 = shen_tail_apply_direct(ctx, "intern", 1, a3225);
  }
    return t3225;
  }
}

static KLObject* native_kl_shen_2einternal_3f_107 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t3232 = objects[0];
    KLObject* t3233 = objects[1];
    KLObject* t3234 = objects[2];
  tail_start_kl_shen_2einternal_3f_107: ;
  KLObject* t3237;
  {
    KLObject* a3237[] = {t3232, t3234};
    t3237 = shen_apply_direct(ctx, "element?", 2, a3237);
  }
  KLObject* t3236;
  {
    KLObject* a3236[] = {t3237};
    t3236 = shen_apply_direct(ctx, "not", 1, a3236);
  }
  KLObject* t3235;
  if (!shen_is_boolean(ctx, t3236))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t3236)) {
    t3235 = t3236;
  } else {
  KLObject* t3242;
  {
    KLObject* a3242[] = {t3232};
    t3242 = shen_apply_direct(ctx, "shen.sng?", 1, a3242);
  }
  KLObject* t3241;
  {
    KLObject* a3241[] = {t3242};
    t3241 = shen_apply_direct(ctx, "not", 1, a3241);
  }
  KLObject* t3240;
  if (!shen_is_boolean(ctx, t3241))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t3241)) {
    t3240 = t3241;
  } else {
  KLObject* t3246;
  {
    KLObject* a3246[] = {t3232};
    t3246 = shen_apply_direct(ctx, "shen.dbl?", 1, a3246);
  }
  KLObject* t3245;
  {
    KLObject* a3245[] = {t3246};
    t3245 = shen_apply_direct(ctx, "not", 1, a3245);
  }
  KLObject* t3244;
  if (!shen_is_boolean(ctx, t3245))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t3245)) {
    t3244 = t3245;
  } else {
  KLObject* t3250 = shen_symbol_p(ctx, t3232);
  KLObject* t3248;
  if (!shen_is_boolean(ctx, t3250))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t3250)) {
    t3248 = t3250;
  } else {
  KLObject* t3253;
  {
    KLObject* a3253[] = {t3232};
    t3253 = shen_apply_direct(ctx, "shen.sysfunc?", 1, a3253);
  }
  KLObject* t3252;
  {
    KLObject* a3252[] = {t3253};
    t3252 = shen_apply_direct(ctx, "not", 1, a3252);
  }
  KLObject* t3251;
  if (!shen_is_boolean(ctx, t3252))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t3252)) {
    t3251 = t3252;
  } else {
  KLObject* t3257;
  {
    KLObject* a3257[] = {t3232};
    t3257 = shen_apply_direct(ctx, "variable?", 1, a3257);
  }
  KLObject* t3256;
  {
    KLObject* a3256[] = {t3257};
    t3256 = shen_apply_direct(ctx, "not", 1, a3256);
  }
  KLObject* t3255;
  if (!shen_is_boolean(ctx, t3256))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t3256)) {
    t3255 = t3256;
  } else {
  KLObject* t3262;
  {
    KLObject* a3262[] = {t3232};
    t3262 = shen_apply_direct(ctx, "str", 1, a3262);
  }
  KLObject* t3261;
  {
    KLObject* a3261[] = {t3262};
    t3261 = shen_apply_direct(ctx, "shen.internal-to-shen?", 1, a3261);
  }
  KLObject* t3260;
  {
    KLObject* a3260[] = {t3261};
    t3260 = shen_apply_direct(ctx, "not", 1, a3260);
  }
  KLObject* t3259;
  if (!shen_is_boolean(ctx, t3260))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t3260)) {
    t3259 = t3260;
  } else {
  KLObject* t3267;
  {
    KLObject* a3267[] = {t3232};
    t3267 = shen_apply_direct(ctx, "str", 1, a3267);
  }
  KLObject* t3265;
  {
    KLObject* a3265[] = {t3233, t3267};
    t3265 = shen_apply_direct(ctx, "shen.internal-to-P?", 2, a3265);
  }
  KLObject* t3264;
  {
    KLObject* a3264[] = {t3265};
    t3264 = shen_apply_direct(ctx, "not", 1, a3264);
  }
    if (!shen_is_boolean(ctx, t3264))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t3259 = t3264;
  }
    if (!shen_is_boolean(ctx, t3259))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t3255 = t3259;
  }
    if (!shen_is_boolean(ctx, t3255))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t3251 = t3255;
  }
    if (!shen_is_boolean(ctx, t3251))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t3248 = t3251;
  }
    if (!shen_is_boolean(ctx, t3248))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t3244 = t3248;
  }
    if (!shen_is_boolean(ctx, t3244))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t3240 = t3244;
  }
    if (!shen_is_boolean(ctx, t3240))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t3235 = t3240;
  }
    return t3235;
  }
}

static KLObject* native_kl_shen_2einternal_2dto_2dshen_3f_108 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t3269 = objects[0];
  tail_start_kl_shen_2einternal_2dto_2dshen_3f_108: ;
  KLObject* t3270;
  {
  KLObject* t3272;
  {
    KLObject* a3272[] = {t3269};
    t3272 = shen_apply_direct(ctx, "shen.+string?", 1, a3272);
  }
  KLObject* t3271;
  if (!shen_is_boolean(ctx, t3272))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t3272)) {
    t3271 = t3272;
  } else {
  KLObject* t3275 = shen_string(ctx, "s");
  KLObject* t3276;
  {
    KLObject* a3276[] = {t3269};
    t3276 = shen_apply_direct(ctx, "hdstr", 1, a3276);
  }
  KLObject* t3278 = shen_eq(ctx, t3275, t3276);
  KLObject* t3274;
  if (!shen_is_boolean(ctx, t3278))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t3278)) {
    t3274 = t3278;
  } else {
  KLObject* t3281;
  {
    KLObject* a3281[] = {t3269};
    t3281 = shen_apply_direct(ctx, "tlstr", 1, a3281);
  }
  KLObject* t3280;
  {
    KLObject* a3280[] = {t3281};
    t3280 = shen_apply_direct(ctx, "shen.+string?", 1, a3280);
  }
  KLObject* t3279;
  if (!shen_is_boolean(ctx, t3280))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t3280)) {
    t3279 = t3280;
  } else {
  KLObject* t3284 = shen_string(ctx, "h");
  KLObject* t3286;
  {
    KLObject* a3286[] = {t3269};
    t3286 = shen_apply_direct(ctx, "tlstr", 1, a3286);
  }
  KLObject* t3285;
  {
    KLObject* a3285[] = {t3286};
    t3285 = shen_apply_direct(ctx, "hdstr", 1, a3285);
  }
  KLObject* t3288 = shen_eq(ctx, t3284, t3285);
  KLObject* t3283;
  if (!shen_is_boolean(ctx, t3288))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t3288)) {
    t3283 = t3288;
  } else {
  KLObject* t3292;
  {
    KLObject* a3292[] = {t3269};
    t3292 = shen_apply_direct(ctx, "tlstr", 1, a3292);
  }
  KLObject* t3291;
  {
    KLObject* a3291[] = {t3292};
    t3291 = shen_apply_direct(ctx, "tlstr", 1, a3291);
  }
  KLObject* t3290;
  {
    KLObject* a3290[] = {t3291};
    t3290 = shen_apply_direct(ctx, "shen.+string?", 1, a3290);
  }
  KLObject* t3289;
  if (!shen_is_boolean(ctx, t3290))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t3290)) {
    t3289 = t3290;
  } else {
  KLObject* t3295 = shen_string(ctx, "e");
  KLObject* t3298;
  {
    KLObject* a3298[] = {t3269};
    t3298 = shen_apply_direct(ctx, "tlstr", 1, a3298);
  }
  KLObject* t3297;
  {
    KLObject* a3297[] = {t3298};
    t3297 = shen_apply_direct(ctx, "tlstr", 1, a3297);
  }
  KLObject* t3296;
  {
    KLObject* a3296[] = {t3297};
    t3296 = shen_apply_direct(ctx, "hdstr", 1, a3296);
  }
  KLObject* t3300 = shen_eq(ctx, t3295, t3296);
  KLObject* t3294;
  if (!shen_is_boolean(ctx, t3300))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t3300)) {
    t3294 = t3300;
  } else {
  KLObject* t3305;
  {
    KLObject* a3305[] = {t3269};
    t3305 = shen_apply_direct(ctx, "tlstr", 1, a3305);
  }
  KLObject* t3304;
  {
    KLObject* a3304[] = {t3305};
    t3304 = shen_apply_direct(ctx, "tlstr", 1, a3304);
  }
  KLObject* t3303;
  {
    KLObject* a3303[] = {t3304};
    t3303 = shen_apply_direct(ctx, "tlstr", 1, a3303);
  }
  KLObject* t3302;
  {
    KLObject* a3302[] = {t3303};
    t3302 = shen_apply_direct(ctx, "shen.+string?", 1, a3302);
  }
  KLObject* t3301;
  if (!shen_is_boolean(ctx, t3302))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t3302)) {
    t3301 = t3302;
  } else {
  KLObject* t3308 = shen_string(ctx, "n");
  KLObject* t3312;
  {
    KLObject* a3312[] = {t3269};
    t3312 = shen_apply_direct(ctx, "tlstr", 1, a3312);
  }
  KLObject* t3311;
  {
    KLObject* a3311[] = {t3312};
    t3311 = shen_apply_direct(ctx, "tlstr", 1, a3311);
  }
  KLObject* t3310;
  {
    KLObject* a3310[] = {t3311};
    t3310 = shen_apply_direct(ctx, "tlstr", 1, a3310);
  }
  KLObject* t3309;
  {
    KLObject* a3309[] = {t3310};
    t3309 = shen_apply_direct(ctx, "hdstr", 1, a3309);
  }
  KLObject* t3314 = shen_eq(ctx, t3308, t3309);
  KLObject* t3307;
  if (!shen_is_boolean(ctx, t3314))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t3314)) {
    t3307 = t3314;
  } else {
  KLObject* t3320;
  {
    KLObject* a3320[] = {t3269};
    t3320 = shen_apply_direct(ctx, "tlstr", 1, a3320);
  }
  KLObject* t3319;
  {
    KLObject* a3319[] = {t3320};
    t3319 = shen_apply_direct(ctx, "tlstr", 1, a3319);
  }
  KLObject* t3318;
  {
    KLObject* a3318[] = {t3319};
    t3318 = shen_apply_direct(ctx, "tlstr", 1, a3318);
  }
  KLObject* t3317;
  {
    KLObject* a3317[] = {t3318};
    t3317 = shen_apply_direct(ctx, "tlstr", 1, a3317);
  }
  KLObject* t3316;
  {
    KLObject* a3316[] = {t3317};
    t3316 = shen_apply_direct(ctx, "shen.+string?", 1, a3316);
  }
  KLObject* t3315;
  if (!shen_is_boolean(ctx, t3316))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t3316)) {
    t3315 = t3316;
  } else {
  KLObject* t3322 = shen_string(ctx, ".");
  KLObject* t3327;
  {
    KLObject* a3327[] = {t3269};
    t3327 = shen_apply_direct(ctx, "tlstr", 1, a3327);
  }
  KLObject* t3326;
  {
    KLObject* a3326[] = {t3327};
    t3326 = shen_apply_direct(ctx, "tlstr", 1, a3326);
  }
  KLObject* t3325;
  {
    KLObject* a3325[] = {t3326};
    t3325 = shen_apply_direct(ctx, "tlstr", 1, a3325);
  }
  KLObject* t3324;
  {
    KLObject* a3324[] = {t3325};
    t3324 = shen_apply_direct(ctx, "tlstr", 1, a3324);
  }
  KLObject* t3323;
  {
    KLObject* a3323[] = {t3324};
    t3323 = shen_apply_direct(ctx, "hdstr", 1, a3323);
  }
  KLObject* t3329 = shen_eq(ctx, t3322, t3323);
    if (!shen_is_boolean(ctx, t3329))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t3315 = t3329;
  }
    if (!shen_is_boolean(ctx, t3315))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t3307 = t3315;
  }
    if (!shen_is_boolean(ctx, t3307))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t3301 = t3307;
  }
    if (!shen_is_boolean(ctx, t3301))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t3294 = t3301;
  }
    if (!shen_is_boolean(ctx, t3294))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t3289 = t3294;
  }
    if (!shen_is_boolean(ctx, t3289))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t3283 = t3289;
  }
    if (!shen_is_boolean(ctx, t3283))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t3279 = t3283;
  }
    if (!shen_is_boolean(ctx, t3279))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t3274 = t3279;
  }
    if (!shen_is_boolean(ctx, t3274))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t3271 = t3274;
  }
    if (!shen_is_boolean(ctx, t3271))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t3271)) {
  KLObject* t3330 = shen_true(ctx);
      t3270 = t3330;
    } else {
  KLObject* t3331 = shen_true(ctx);
    if (!shen_is_boolean(ctx, t3331))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t3331)) {
  KLObject* t3332 = shen_false(ctx);
      t3270 = t3332;
    } else {
      shen_simple_error(ctx, "No true case found for cond");
      t3270 = shen_empty_list(ctx);
    }
    }
  }
    return t3270;
  }
}

static KLObject* native_kl_shen_2esysfunc_3f_109 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t3333 = objects[0];
  tail_start_kl_shen_2esysfunc_3f_109: ;
  KLObject* t3337 = shen_intern(ctx, "shen");
  KLObject* t3338 = shen_intern(ctx, "shen.external-symbols");
  KLObject* t3340 = shen_intern(ctx, "*property-vector*");
  KLObject* t3339;
  {
    KLObject* a3339[] = {t3340};
    t3339 = shen_apply_direct(ctx, "value", 1, a3339);
  }
  KLObject* t3336;
  {
    KLObject* a3336[] = {t3337, t3338, t3339};
    t3336 = shen_apply_direct(ctx, "get", 3, a3336);
  }
  KLObject* t3334;
  {
    KLObject* a3334[] = {t3333, t3336};
    t3334 = shen_tail_apply_direct(ctx, "element?", 2, a3334);
  }
    return t3334;
  }
}

static KLObject* native_kl_shen_2einternal_2dto_2dP_3f_110 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t3341 = objects[0];
    KLObject* t3342 = objects[1];
  tail_start_kl_shen_2einternal_2dto_2dP_3f_110: ;
  KLObject* t3343;
  {
  KLObject* t3345 = shen_string(ctx, "");
  KLObject* t3347 = shen_eq(ctx, t3345, t3341);
  KLObject* t3344;
  if (!shen_is_boolean(ctx, t3347))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t3347)) {
    t3344 = t3347;
  } else {
  KLObject* t3349;
  {
    KLObject* a3349[] = {t3342};
    t3349 = shen_apply_direct(ctx, "shen.+string?", 1, a3349);
  }
  KLObject* t3348;
  if (!shen_is_boolean(ctx, t3349))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t3349)) {
    t3348 = t3349;
  } else {
  KLObject* t3351 = shen_string(ctx, ".");
  KLObject* t3352;
  {
    KLObject* a3352[] = {t3342};
    t3352 = shen_apply_direct(ctx, "hdstr", 1, a3352);
  }
  KLObject* t3354 = shen_eq(ctx, t3351, t3352);
    if (!shen_is_boolean(ctx, t3354))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t3348 = t3354;
  }
    if (!shen_is_boolean(ctx, t3348))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t3344 = t3348;
  }
    if (!shen_is_boolean(ctx, t3344))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t3344)) {
  KLObject* t3355 = shen_true(ctx);
      t3343 = t3355;
    } else {
  KLObject* t3357;
  {
    KLObject* a3357[] = {t3341};
    t3357 = shen_apply_direct(ctx, "shen.+string?", 1, a3357);
  }
  KLObject* t3356;
  if (!shen_is_boolean(ctx, t3357))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t3357)) {
    t3356 = t3357;
  } else {
  KLObject* t3360;
  {
    KLObject* a3360[] = {t3342};
    t3360 = shen_apply_direct(ctx, "shen.+string?", 1, a3360);
  }
  KLObject* t3359;
  if (!shen_is_boolean(ctx, t3360))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t3360)) {
    t3359 = t3360;
  } else {
  KLObject* t3362;
  {
    KLObject* a3362[] = {t3341};
    t3362 = shen_apply_direct(ctx, "hdstr", 1, a3362);
  }
  KLObject* t3364;
  {
    KLObject* a3364[] = {t3342};
    t3364 = shen_apply_direct(ctx, "hdstr", 1, a3364);
  }
  KLObject* t3366 = shen_eq(ctx, t3362, t3364);
    if (!shen_is_boolean(ctx, t3366))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t3359 = t3366;
  }
    if (!shen_is_boolean(ctx, t3359))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t3356 = t3359;
  }
    if (!shen_is_boolean(ctx, t3356))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t3356)) {
  KLObject* t3367;
  {
    KLObject* a3367[] = {t3341};
    t3367 = shen_apply_direct(ctx, "tlstr", 1, a3367);
  }
  KLObject* t3369;
  {
    KLObject* a3369[] = {t3342};
    t3369 = shen_apply_direct(ctx, "tlstr", 1, a3369);
  }
  {
    KLObject* n3371_0 = t3367;
    KLObject* n3371_1 = t3369;
    t3341 = n3371_0;
    t3342 = n3371_1;
    goto tail_start_kl_shen_2einternal_2dto_2dP_3f_110;
  }
  KLObject* t3371 = NULL;
      t3343 = t3371;
    } else {
  KLObject* t3372 = shen_true(ctx);
    if (!shen_is_boolean(ctx, t3372))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t3372)) {
  KLObject* t3373 = shen_false(ctx);
      t3343 = t3373;
    } else {
      shen_simple_error(ctx, "No true case found for cond");
      t3343 = shen_empty_list(ctx);
    }
    }
    }
  }
    return t3343;
  }
}

static KLObject* native_kl_shen_2eprocess_2dapplications_111 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t3374 = objects[0];
    KLObject* t3375 = objects[1];
  tail_start_kl_shen_2eprocess_2dapplications_111: ;
  KLObject* t3376;
  {
  KLObject* t3377;
  {
    KLObject* a3377[] = {t3374, t3375};
    t3377 = shen_apply_direct(ctx, "element?", 2, a3377);
  }
    if (!shen_is_boolean(ctx, t3377))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t3377)) {
      t3376 = t3374;
    } else {
  KLObject* t3383 = shen_cons_p(ctx, t3374);
  KLObject* t3381;
  if (!shen_is_boolean(ctx, t3383))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t3383)) {
    t3381 = t3383;
  } else {
  KLObject* t3386 = shen_hd(ctx, t3374);
  KLObject* t3384;
  {
    KLObject* a3384[] = {t3386};
    t3384 = shen_apply_direct(ctx, "shen.non-application?", 1, a3384);
  }
    if (!shen_is_boolean(ctx, t3384))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t3381 = t3384;
  }
    if (!shen_is_boolean(ctx, t3381))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t3381)) {
  KLObject* t3389 = shen_hd(ctx, t3374);
  KLObject* t3387;
  {
    KLObject* a3387[] = {t3389, t3374, t3375};
    t3387 = shen_tail_apply_direct(ctx, "shen.special-case", 3, a3387);
  }
      t3376 = t3387;
    } else {
  KLObject* t3393 = shen_cons_p(ctx, t3374);
    if (!shen_is_boolean(ctx, t3393))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t3393)) {
  KLObject* t3396;
  {
    Vector* caps_15 = shen_vector(ctx, 1);
    shen_vector_set(ctx, caps_15, 0, t3375);
    t3396 = shen_native_closure(ctx, 1, &lambda_15, caps_15);
  }
  KLObject* t3395;
  {
    KLObject* a3395[] = {t3396, t3374};
    t3395 = shen_apply_direct(ctx, "map", 2, a3395);
  }
  KLObject* t3394;
  {
    KLObject* a3394[] = {t3395, t3375};
    t3394 = shen_tail_apply_direct(ctx, "shen.process-application", 2, a3394);
  }
      t3376 = t3394;
    } else {
  KLObject* t3404 = shen_true(ctx);
    if (!shen_is_boolean(ctx, t3404))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t3404)) {
      t3376 = t3374;
    } else {
      shen_simple_error(ctx, "No true case found for cond");
      t3376 = shen_empty_list(ctx);
    }
    }
    }
    }
  }
    return t3376;
  }
}

static KLObject* native_kl_shen_2enon_2dapplication_3f_112 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t3406 = objects[0];
  tail_start_kl_shen_2enon_2dapplication_3f_112: ;
  KLObject* t3407;
  {
  KLObject* t3408 = shen_intern(ctx, "define");
  KLObject* t3410 = shen_eq(ctx, t3408, t3406);
    if (!shen_is_boolean(ctx, t3410))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t3410)) {
  KLObject* t3411 = shen_true(ctx);
      t3407 = t3411;
    } else {
  KLObject* t3412 = shen_intern(ctx, "defun");
  KLObject* t3414 = shen_eq(ctx, t3412, t3406);
    if (!shen_is_boolean(ctx, t3414))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t3414)) {
  KLObject* t3415 = shen_true(ctx);
      t3407 = t3415;
    } else {
  KLObject* t3416 = shen_intern(ctx, "synonyms");
  KLObject* t3418 = shen_eq(ctx, t3416, t3406);
    if (!shen_is_boolean(ctx, t3418))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t3418)) {
  KLObject* t3419 = shen_true(ctx);
      t3407 = t3419;
    } else {
  KLObject* t3420;
  {
    KLObject* a3420[] = {t3406};
    t3420 = shen_apply_direct(ctx, "shen.special?", 1, a3420);
  }
    if (!shen_is_boolean(ctx, t3420))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t3420)) {
  KLObject* t3422 = shen_true(ctx);
      t3407 = t3422;
    } else {
  KLObject* t3423;
  {
    KLObject* a3423[] = {t3406};
    t3423 = shen_apply_direct(ctx, "shen.extraspecial?", 1, a3423);
  }
    if (!shen_is_boolean(ctx, t3423))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t3423)) {
  KLObject* t3425 = shen_true(ctx);
      t3407 = t3425;
    } else {
  KLObject* t3426 = shen_true(ctx);
    if (!shen_is_boolean(ctx, t3426))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t3426)) {
  KLObject* t3427 = shen_false(ctx);
      t3407 = t3427;
    } else {
      shen_simple_error(ctx, "No true case found for cond");
      t3407 = shen_empty_list(ctx);
    }
    }
    }
    }
    }
    }
  }
    return t3407;
  }
}

static KLObject* native_kl_shen_2especial_2dcase_113 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t3428 = objects[0];
    KLObject* t3429 = objects[1];
    KLObject* t3430 = objects[2];
  tail_start_kl_shen_2especial_2dcase_113: ;
  KLObject* t3431;
  {
  KLObject* t3433 = shen_intern(ctx, "lambda");
  KLObject* t3435 = shen_eq(ctx, t3433, t3428);
  KLObject* t3432;
  if (!shen_is_boolean(ctx, t3435))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t3435)) {
    t3432 = t3435;
  } else {
  KLObject* t3438 = shen_cons_p(ctx, t3429);
  KLObject* t3436;
  if (!shen_is_boolean(ctx, t3438))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t3438)) {
    t3436 = t3438;
  } else {
  KLObject* t3440 = shen_intern(ctx, "lambda");
  KLObject* t3442 = shen_hd(ctx, t3429);
  KLObject* t3443 = shen_eq(ctx, t3440, t3442);
  KLObject* t3439;
  if (!shen_is_boolean(ctx, t3443))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t3443)) {
    t3439 = t3443;
  } else {
  KLObject* t3446 = shen_tl(ctx, t3429);
  KLObject* t3447 = shen_cons_p(ctx, t3446);
  KLObject* t3444;
  if (!shen_is_boolean(ctx, t3447))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t3447)) {
    t3444 = t3447;
  } else {
  KLObject* t3450 = shen_tl(ctx, t3429);
  KLObject* t3451 = shen_tl(ctx, t3450);
  KLObject* t3452 = shen_cons_p(ctx, t3451);
  KLObject* t3448;
  if (!shen_is_boolean(ctx, t3452))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t3452)) {
    t3448 = t3452;
  } else {
  KLObject* t3453 = shen_empty_list(ctx);
  KLObject* t3455 = shen_tl(ctx, t3429);
  KLObject* t3456 = shen_tl(ctx, t3455);
  KLObject* t3457 = shen_tl(ctx, t3456);
  KLObject* t3458 = shen_eq(ctx, t3453, t3457);
    if (!shen_is_boolean(ctx, t3458))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t3448 = t3458;
  }
    if (!shen_is_boolean(ctx, t3448))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t3444 = t3448;
  }
    if (!shen_is_boolean(ctx, t3444))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t3439 = t3444;
  }
    if (!shen_is_boolean(ctx, t3439))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t3436 = t3439;
  }
    if (!shen_is_boolean(ctx, t3436))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t3432 = t3436;
  }
    if (!shen_is_boolean(ctx, t3432))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t3432)) {
  KLObject* t3459 = shen_intern(ctx, "lambda");
  KLObject* t3461 = shen_tl(ctx, t3429);
  KLObject* t3462 = shen_hd(ctx, t3461);
  KLObject* t3465 = shen_tl(ctx, t3429);
  KLObject* t3466 = shen_tl(ctx, t3465);
  KLObject* t3467 = shen_hd(ctx, t3466);
  KLObject* t3463;
  {
    KLObject* a3463[] = {t3467, t3430};
    t3463 = shen_apply_direct(ctx, "shen.process-applications", 2, a3463);
  }
  KLObject* t3469 = shen_empty_list(ctx);
  KLObject* t3470 = shen_cons(ctx, t3463, t3469);
  KLObject* t3471 = shen_cons(ctx, t3462, t3470);
  KLObject* t3472 = shen_cons(ctx, t3459, t3471);
      t3431 = t3472;
    } else {
  KLObject* t3474 = shen_intern(ctx, "let");
  KLObject* t3476 = shen_eq(ctx, t3474, t3428);
  KLObject* t3473;
  if (!shen_is_boolean(ctx, t3476))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t3476)) {
    t3473 = t3476;
  } else {
  KLObject* t3479 = shen_cons_p(ctx, t3429);
  KLObject* t3477;
  if (!shen_is_boolean(ctx, t3479))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t3479)) {
    t3477 = t3479;
  } else {
  KLObject* t3481 = shen_intern(ctx, "let");
  KLObject* t3483 = shen_hd(ctx, t3429);
  KLObject* t3484 = shen_eq(ctx, t3481, t3483);
  KLObject* t3480;
  if (!shen_is_boolean(ctx, t3484))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t3484)) {
    t3480 = t3484;
  } else {
  KLObject* t3487 = shen_tl(ctx, t3429);
  KLObject* t3488 = shen_cons_p(ctx, t3487);
  KLObject* t3485;
  if (!shen_is_boolean(ctx, t3488))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t3488)) {
    t3485 = t3488;
  } else {
  KLObject* t3491 = shen_tl(ctx, t3429);
  KLObject* t3492 = shen_tl(ctx, t3491);
  KLObject* t3493 = shen_cons_p(ctx, t3492);
  KLObject* t3489;
  if (!shen_is_boolean(ctx, t3493))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t3493)) {
    t3489 = t3493;
  } else {
  KLObject* t3496 = shen_tl(ctx, t3429);
  KLObject* t3497 = shen_tl(ctx, t3496);
  KLObject* t3498 = shen_tl(ctx, t3497);
  KLObject* t3499 = shen_cons_p(ctx, t3498);
  KLObject* t3494;
  if (!shen_is_boolean(ctx, t3499))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t3499)) {
    t3494 = t3499;
  } else {
  KLObject* t3500 = shen_empty_list(ctx);
  KLObject* t3502 = shen_tl(ctx, t3429);
  KLObject* t3503 = shen_tl(ctx, t3502);
  KLObject* t3504 = shen_tl(ctx, t3503);
  KLObject* t3505 = shen_tl(ctx, t3504);
  KLObject* t3506 = shen_eq(ctx, t3500, t3505);
    if (!shen_is_boolean(ctx, t3506))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t3494 = t3506;
  }
    if (!shen_is_boolean(ctx, t3494))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t3489 = t3494;
  }
    if (!shen_is_boolean(ctx, t3489))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t3485 = t3489;
  }
    if (!shen_is_boolean(ctx, t3485))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t3480 = t3485;
  }
    if (!shen_is_boolean(ctx, t3480))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t3477 = t3480;
  }
    if (!shen_is_boolean(ctx, t3477))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t3473 = t3477;
  }
    if (!shen_is_boolean(ctx, t3473))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t3473)) {
  KLObject* t3507 = shen_intern(ctx, "let");
  KLObject* t3509 = shen_tl(ctx, t3429);
  KLObject* t3510 = shen_hd(ctx, t3509);
  KLObject* t3513 = shen_tl(ctx, t3429);
  KLObject* t3514 = shen_tl(ctx, t3513);
  KLObject* t3515 = shen_hd(ctx, t3514);
  KLObject* t3511;
  {
    KLObject* a3511[] = {t3515, t3430};
    t3511 = shen_apply_direct(ctx, "shen.process-applications", 2, a3511);
  }
  KLObject* t3519 = shen_tl(ctx, t3429);
  KLObject* t3520 = shen_tl(ctx, t3519);
  KLObject* t3521 = shen_tl(ctx, t3520);
  KLObject* t3522 = shen_hd(ctx, t3521);
  KLObject* t3517;
  {
    KLObject* a3517[] = {t3522, t3430};
    t3517 = shen_apply_direct(ctx, "shen.process-applications", 2, a3517);
  }
  KLObject* t3524 = shen_empty_list(ctx);
  KLObject* t3525 = shen_cons(ctx, t3517, t3524);
  KLObject* t3526 = shen_cons(ctx, t3511, t3525);
  KLObject* t3527 = shen_cons(ctx, t3510, t3526);
  KLObject* t3528 = shen_cons(ctx, t3507, t3527);
      t3431 = t3528;
    } else {
  KLObject* t3530 = shen_intern(ctx, "defun");
  KLObject* t3532 = shen_eq(ctx, t3530, t3428);
  KLObject* t3529;
  if (!shen_is_boolean(ctx, t3532))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t3532)) {
    t3529 = t3532;
  } else {
  KLObject* t3535 = shen_cons_p(ctx, t3429);
  KLObject* t3533;
  if (!shen_is_boolean(ctx, t3535))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t3535)) {
    t3533 = t3535;
  } else {
  KLObject* t3537 = shen_intern(ctx, "defun");
  KLObject* t3539 = shen_hd(ctx, t3429);
  KLObject* t3540 = shen_eq(ctx, t3537, t3539);
  KLObject* t3536;
  if (!shen_is_boolean(ctx, t3540))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t3540)) {
    t3536 = t3540;
  } else {
  KLObject* t3543 = shen_tl(ctx, t3429);
  KLObject* t3544 = shen_cons_p(ctx, t3543);
  KLObject* t3541;
  if (!shen_is_boolean(ctx, t3544))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t3544)) {
    t3541 = t3544;
  } else {
  KLObject* t3547 = shen_tl(ctx, t3429);
  KLObject* t3548 = shen_tl(ctx, t3547);
  KLObject* t3549 = shen_cons_p(ctx, t3548);
  KLObject* t3545;
  if (!shen_is_boolean(ctx, t3549))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t3549)) {
    t3545 = t3549;
  } else {
  KLObject* t3552 = shen_tl(ctx, t3429);
  KLObject* t3553 = shen_tl(ctx, t3552);
  KLObject* t3554 = shen_tl(ctx, t3553);
  KLObject* t3555 = shen_cons_p(ctx, t3554);
  KLObject* t3550;
  if (!shen_is_boolean(ctx, t3555))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t3555)) {
    t3550 = t3555;
  } else {
  KLObject* t3556 = shen_empty_list(ctx);
  KLObject* t3558 = shen_tl(ctx, t3429);
  KLObject* t3559 = shen_tl(ctx, t3558);
  KLObject* t3560 = shen_tl(ctx, t3559);
  KLObject* t3561 = shen_tl(ctx, t3560);
  KLObject* t3562 = shen_eq(ctx, t3556, t3561);
    if (!shen_is_boolean(ctx, t3562))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t3550 = t3562;
  }
    if (!shen_is_boolean(ctx, t3550))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t3545 = t3550;
  }
    if (!shen_is_boolean(ctx, t3545))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t3541 = t3545;
  }
    if (!shen_is_boolean(ctx, t3541))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t3536 = t3541;
  }
    if (!shen_is_boolean(ctx, t3536))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t3533 = t3536;
  }
    if (!shen_is_boolean(ctx, t3533))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t3529 = t3533;
  }
    if (!shen_is_boolean(ctx, t3529))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t3529)) {
      t3431 = t3429;
    } else {
  KLObject* t3565 = shen_intern(ctx, "define");
  KLObject* t3567 = shen_eq(ctx, t3565, t3428);
  KLObject* t3564;
  if (!shen_is_boolean(ctx, t3567))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t3567)) {
    t3564 = t3567;
  } else {
  KLObject* t3570 = shen_cons_p(ctx, t3429);
  KLObject* t3568;
  if (!shen_is_boolean(ctx, t3570))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t3570)) {
    t3568 = t3570;
  } else {
  KLObject* t3572 = shen_intern(ctx, "define");
  KLObject* t3574 = shen_hd(ctx, t3429);
  KLObject* t3575 = shen_eq(ctx, t3572, t3574);
  KLObject* t3571;
  if (!shen_is_boolean(ctx, t3575))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t3575)) {
    t3571 = t3575;
  } else {
  KLObject* t3578 = shen_tl(ctx, t3429);
  KLObject* t3579 = shen_cons_p(ctx, t3578);
  KLObject* t3576;
  if (!shen_is_boolean(ctx, t3579))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t3579)) {
    t3576 = t3579;
  } else {
  KLObject* t3582 = shen_tl(ctx, t3429);
  KLObject* t3583 = shen_tl(ctx, t3582);
  KLObject* t3584 = shen_cons_p(ctx, t3583);
  KLObject* t3580;
  if (!shen_is_boolean(ctx, t3584))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t3584)) {
    t3580 = t3584;
  } else {
  KLObject* t3585 = shen_intern(ctx, "{");
  KLObject* t3587 = shen_tl(ctx, t3429);
  KLObject* t3588 = shen_tl(ctx, t3587);
  KLObject* t3589 = shen_hd(ctx, t3588);
  KLObject* t3590 = shen_eq(ctx, t3585, t3589);
    if (!shen_is_boolean(ctx, t3590))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t3580 = t3590;
  }
    if (!shen_is_boolean(ctx, t3580))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t3576 = t3580;
  }
    if (!shen_is_boolean(ctx, t3576))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t3571 = t3576;
  }
    if (!shen_is_boolean(ctx, t3571))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t3568 = t3571;
  }
    if (!shen_is_boolean(ctx, t3568))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t3564 = t3568;
  }
    if (!shen_is_boolean(ctx, t3564))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t3564)) {
  KLObject* t3591 = shen_intern(ctx, "define");
  KLObject* t3593 = shen_tl(ctx, t3429);
  KLObject* t3594 = shen_hd(ctx, t3593);
  KLObject* t3595 = shen_intern(ctx, "{");
  KLObject* t3598 = shen_tl(ctx, t3429);
  KLObject* t3599 = shen_hd(ctx, t3598);
  KLObject* t3601 = shen_tl(ctx, t3429);
  KLObject* t3602 = shen_tl(ctx, t3601);
  KLObject* t3603 = shen_tl(ctx, t3602);
  KLObject* t3596;
  {
    KLObject* a3596[] = {t3599, t3603, t3430};
    t3596 = shen_apply_direct(ctx, "shen.process-after-type", 3, a3596);
  }
  KLObject* t3605 = shen_cons(ctx, t3595, t3596);
  KLObject* t3606 = shen_cons(ctx, t3594, t3605);
  KLObject* t3607 = shen_cons(ctx, t3591, t3606);
      t3431 = t3607;
    } else {
  KLObject* t3609 = shen_intern(ctx, "define");
  KLObject* t3611 = shen_eq(ctx, t3609, t3428);
  KLObject* t3608;
  if (!shen_is_boolean(ctx, t3611))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t3611)) {
    t3608 = t3611;
  } else {
  KLObject* t3614 = shen_cons_p(ctx, t3429);
  KLObject* t3612;
  if (!shen_is_boolean(ctx, t3614))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t3614)) {
    t3612 = t3614;
  } else {
  KLObject* t3616 = shen_intern(ctx, "define");
  KLObject* t3618 = shen_hd(ctx, t3429);
  KLObject* t3619 = shen_eq(ctx, t3616, t3618);
  KLObject* t3615;
  if (!shen_is_boolean(ctx, t3619))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t3619)) {
    t3615 = t3619;
  } else {
  KLObject* t3621 = shen_tl(ctx, t3429);
  KLObject* t3622 = shen_cons_p(ctx, t3621);
    if (!shen_is_boolean(ctx, t3622))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t3615 = t3622;
  }
    if (!shen_is_boolean(ctx, t3615))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t3612 = t3615;
  }
    if (!shen_is_boolean(ctx, t3612))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t3608 = t3612;
  }
    if (!shen_is_boolean(ctx, t3608))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t3608)) {
  KLObject* t3623 = shen_intern(ctx, "define");
  KLObject* t3625 = shen_tl(ctx, t3429);
  KLObject* t3626 = shen_hd(ctx, t3625);
  KLObject* t3628;
  {
    Vector* caps_16 = shen_vector(ctx, 1);
    shen_vector_set(ctx, caps_16, 0, t3430);
    t3628 = shen_native_closure(ctx, 1, &lambda_16, caps_16);
  }
  KLObject* t3635 = shen_tl(ctx, t3429);
  KLObject* t3636 = shen_tl(ctx, t3635);
  KLObject* t3627;
  {
    KLObject* a3627[] = {t3628, t3636};
    t3627 = shen_apply_direct(ctx, "map", 2, a3627);
  }
  KLObject* t3637 = shen_cons(ctx, t3626, t3627);
  KLObject* t3638 = shen_cons(ctx, t3623, t3637);
      t3431 = t3638;
    } else {
  KLObject* t3639 = shen_intern(ctx, "synonyms");
  KLObject* t3641 = shen_eq(ctx, t3639, t3428);
    if (!shen_is_boolean(ctx, t3641))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t3641)) {
  KLObject* t3642 = shen_intern(ctx, "synonyms");
  KLObject* t3644 = shen_cons(ctx, t3642, t3429);
      t3431 = t3644;
    } else {
  KLObject* t3646 = shen_intern(ctx, "type");
  KLObject* t3648 = shen_eq(ctx, t3646, t3428);
  KLObject* t3645;
  if (!shen_is_boolean(ctx, t3648))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t3648)) {
    t3645 = t3648;
  } else {
  KLObject* t3651 = shen_cons_p(ctx, t3429);
  KLObject* t3649;
  if (!shen_is_boolean(ctx, t3651))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t3651)) {
    t3649 = t3651;
  } else {
  KLObject* t3653 = shen_intern(ctx, "type");
  KLObject* t3655 = shen_hd(ctx, t3429);
  KLObject* t3656 = shen_eq(ctx, t3653, t3655);
  KLObject* t3652;
  if (!shen_is_boolean(ctx, t3656))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t3656)) {
    t3652 = t3656;
  } else {
  KLObject* t3659 = shen_tl(ctx, t3429);
  KLObject* t3660 = shen_cons_p(ctx, t3659);
  KLObject* t3657;
  if (!shen_is_boolean(ctx, t3660))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t3660)) {
    t3657 = t3660;
  } else {
  KLObject* t3663 = shen_tl(ctx, t3429);
  KLObject* t3664 = shen_tl(ctx, t3663);
  KLObject* t3665 = shen_cons_p(ctx, t3664);
  KLObject* t3661;
  if (!shen_is_boolean(ctx, t3665))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t3665)) {
    t3661 = t3665;
  } else {
  KLObject* t3666 = shen_empty_list(ctx);
  KLObject* t3668 = shen_tl(ctx, t3429);
  KLObject* t3669 = shen_tl(ctx, t3668);
  KLObject* t3670 = shen_tl(ctx, t3669);
  KLObject* t3671 = shen_eq(ctx, t3666, t3670);
    if (!shen_is_boolean(ctx, t3671))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t3661 = t3671;
  }
    if (!shen_is_boolean(ctx, t3661))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t3657 = t3661;
  }
    if (!shen_is_boolean(ctx, t3657))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t3652 = t3657;
  }
    if (!shen_is_boolean(ctx, t3652))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t3649 = t3652;
  }
    if (!shen_is_boolean(ctx, t3649))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t3645 = t3649;
  }
    if (!shen_is_boolean(ctx, t3645))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t3645)) {
  KLObject* t3672 = shen_intern(ctx, "type");
  KLObject* t3675 = shen_tl(ctx, t3429);
  KLObject* t3676 = shen_hd(ctx, t3675);
  KLObject* t3673;
  {
    KLObject* a3673[] = {t3676, t3430};
    t3673 = shen_apply_direct(ctx, "shen.process-applications", 2, a3673);
  }
  KLObject* t3679 = shen_tl(ctx, t3429);
  KLObject* t3680 = shen_tl(ctx, t3679);
  KLObject* t3681 = shen_cons(ctx, t3673, t3680);
  KLObject* t3682 = shen_cons(ctx, t3672, t3681);
      t3431 = t3682;
    } else {
  KLObject* t3684 = shen_intern(ctx, "input+");
  KLObject* t3686 = shen_eq(ctx, t3684, t3428);
  KLObject* t3683;
  if (!shen_is_boolean(ctx, t3686))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t3686)) {
    t3683 = t3686;
  } else {
  KLObject* t3689 = shen_cons_p(ctx, t3429);
  KLObject* t3687;
  if (!shen_is_boolean(ctx, t3689))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t3689)) {
    t3687 = t3689;
  } else {
  KLObject* t3691 = shen_intern(ctx, "input+");
  KLObject* t3693 = shen_hd(ctx, t3429);
  KLObject* t3694 = shen_eq(ctx, t3691, t3693);
  KLObject* t3690;
  if (!shen_is_boolean(ctx, t3694))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t3694)) {
    t3690 = t3694;
  } else {
  KLObject* t3697 = shen_tl(ctx, t3429);
  KLObject* t3698 = shen_cons_p(ctx, t3697);
  KLObject* t3695;
  if (!shen_is_boolean(ctx, t3698))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t3698)) {
    t3695 = t3698;
  } else {
  KLObject* t3701 = shen_tl(ctx, t3429);
  KLObject* t3702 = shen_tl(ctx, t3701);
  KLObject* t3703 = shen_cons_p(ctx, t3702);
  KLObject* t3699;
  if (!shen_is_boolean(ctx, t3703))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t3703)) {
    t3699 = t3703;
  } else {
  KLObject* t3704 = shen_empty_list(ctx);
  KLObject* t3706 = shen_tl(ctx, t3429);
  KLObject* t3707 = shen_tl(ctx, t3706);
  KLObject* t3708 = shen_tl(ctx, t3707);
  KLObject* t3709 = shen_eq(ctx, t3704, t3708);
    if (!shen_is_boolean(ctx, t3709))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t3699 = t3709;
  }
    if (!shen_is_boolean(ctx, t3699))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t3695 = t3699;
  }
    if (!shen_is_boolean(ctx, t3695))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t3690 = t3695;
  }
    if (!shen_is_boolean(ctx, t3690))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t3687 = t3690;
  }
    if (!shen_is_boolean(ctx, t3687))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t3683 = t3687;
  }
    if (!shen_is_boolean(ctx, t3683))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t3683)) {
  KLObject* t3710 = shen_intern(ctx, "input+");
  KLObject* t3712 = shen_tl(ctx, t3429);
  KLObject* t3713 = shen_hd(ctx, t3712);
  KLObject* t3716 = shen_tl(ctx, t3429);
  KLObject* t3717 = shen_tl(ctx, t3716);
  KLObject* t3718 = shen_hd(ctx, t3717);
  KLObject* t3714;
  {
    KLObject* a3714[] = {t3718, t3430};
    t3714 = shen_apply_direct(ctx, "shen.process-applications", 2, a3714);
  }
  KLObject* t3720 = shen_empty_list(ctx);
  KLObject* t3721 = shen_cons(ctx, t3714, t3720);
  KLObject* t3722 = shen_cons(ctx, t3713, t3721);
  KLObject* t3723 = shen_cons(ctx, t3710, t3722);
      t3431 = t3723;
    } else {
  KLObject* t3726 = shen_cons_p(ctx, t3429);
  KLObject* t3724;
  if (!shen_is_boolean(ctx, t3726))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t3726)) {
    t3724 = t3726;
  } else {
  KLObject* t3729 = shen_hd(ctx, t3429);
  KLObject* t3727;
  {
    KLObject* a3727[] = {t3729};
    t3727 = shen_apply_direct(ctx, "shen.special?", 1, a3727);
  }
    if (!shen_is_boolean(ctx, t3727))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t3724 = t3727;
  }
    if (!shen_is_boolean(ctx, t3724))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t3724)) {
  KLObject* t3731 = shen_hd(ctx, t3429);
  KLObject* t3733;
  {
    Vector* caps_17 = shen_vector(ctx, 1);
    shen_vector_set(ctx, caps_17, 0, t3430);
    t3733 = shen_native_closure(ctx, 1, &lambda_17, caps_17);
  }
  KLObject* t3740 = shen_tl(ctx, t3429);
  KLObject* t3732;
  {
    KLObject* a3732[] = {t3733, t3740};
    t3732 = shen_apply_direct(ctx, "map", 2, a3732);
  }
  KLObject* t3741 = shen_cons(ctx, t3731, t3732);
      t3431 = t3741;
    } else {
  KLObject* t3744 = shen_cons_p(ctx, t3429);
  KLObject* t3742;
  if (!shen_is_boolean(ctx, t3744))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t3744)) {
    t3742 = t3744;
  } else {
  KLObject* t3747 = shen_hd(ctx, t3429);
  KLObject* t3745;
  {
    KLObject* a3745[] = {t3747};
    t3745 = shen_apply_direct(ctx, "shen.extraspecial?", 1, a3745);
  }
    if (!shen_is_boolean(ctx, t3745))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t3742 = t3745;
  }
    if (!shen_is_boolean(ctx, t3742))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t3742)) {
      t3431 = t3429;
    } else {
  KLObject* t3749 = shen_true(ctx);
    if (!shen_is_boolean(ctx, t3749))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t3749)) {
  KLObject* t3751 = shen_string(ctx, "partial function shen.special-case");
  KLObject* t3750;
  {
    KLObject* a3750[] = {t3751};
    t3750 = shen_tail_apply_direct(ctx, "simple-error", 1, a3750);
  }
      t3431 = t3750;
    } else {
      shen_simple_error(ctx, "No true case found for cond");
      t3431 = shen_empty_list(ctx);
    }
    }
    }
    }
    }
    }
    }
    }
    }
    }
    }
  }
    return t3431;
  }
}

static KLObject* native_kl_shen_2eprocess_2dafter_2dtype_114 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t3752 = objects[0];
    KLObject* t3753 = objects[1];
    KLObject* t3754 = objects[2];
  tail_start_kl_shen_2eprocess_2dafter_2dtype_114: ;
  KLObject* t3755;
  {
  KLObject* t3758 = shen_cons_p(ctx, t3753);
  KLObject* t3756;
  if (!shen_is_boolean(ctx, t3758))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t3758)) {
    t3756 = t3758;
  } else {
  KLObject* t3759 = shen_intern(ctx, "}");
  KLObject* t3761 = shen_hd(ctx, t3753);
  KLObject* t3762 = shen_eq(ctx, t3759, t3761);
    if (!shen_is_boolean(ctx, t3762))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t3756 = t3762;
  }
    if (!shen_is_boolean(ctx, t3756))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t3756)) {
  KLObject* t3763 = shen_intern(ctx, "}");
  KLObject* t3765;
  {
    Vector* caps_18 = shen_vector(ctx, 1);
    shen_vector_set(ctx, caps_18, 0, t3754);
    t3765 = shen_native_closure(ctx, 1, &lambda_18, caps_18);
  }
  KLObject* t3772 = shen_tl(ctx, t3753);
  KLObject* t3764;
  {
    KLObject* a3764[] = {t3765, t3772};
    t3764 = shen_apply_direct(ctx, "map", 2, a3764);
  }
  KLObject* t3773 = shen_cons(ctx, t3763, t3764);
      t3755 = t3773;
    } else {
  KLObject* t3775 = shen_cons_p(ctx, t3753);
    if (!shen_is_boolean(ctx, t3775))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t3775)) {
  KLObject* t3777 = shen_hd(ctx, t3753);
  KLObject* t3781 = shen_tl(ctx, t3753);
  KLObject* t3778;
  {
    KLObject* a3778[] = {t3752, t3781, t3754};
    t3778 = shen_apply_direct(ctx, "shen.process-after-type", 3, a3778);
  }
  KLObject* t3783 = shen_cons(ctx, t3777, t3778);
      t3755 = t3783;
    } else {
  KLObject* t3784 = shen_true(ctx);
    if (!shen_is_boolean(ctx, t3784))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t3784)) {
  KLObject* t3787 = shen_string(ctx, "missing } in ");
  KLObject* t3790 = shen_string(ctx, "\n");
  KLObject* t3791 = shen_intern(ctx, "shen.a");
  KLObject* t3788;
  {
    KLObject* a3788[] = {t3752, t3790, t3791};
    t3788 = shen_apply_direct(ctx, "shen.app", 3, a3788);
  }
  KLObject* t3786;
  {
    KLObject* a3786[] = {t3787, t3788};
    t3786 = shen_apply_direct(ctx, "cn", 2, a3786);
  }
  KLObject* t3785;
  {
    KLObject* a3785[] = {t3786};
    t3785 = shen_tail_apply_direct(ctx, "simple-error", 1, a3785);
  }
      t3755 = t3785;
    } else {
      shen_simple_error(ctx, "No true case found for cond");
      t3755 = shen_empty_list(ctx);
    }
    }
    }
  }
    return t3755;
  }
}

static KLObject* native_kl_shen_2eprocess_2dapplication_115 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t3792 = objects[0];
    KLObject* t3793 = objects[1];
  tail_start_kl_shen_2eprocess_2dapplication_115: ;
  KLObject* t3794;
  {
  KLObject* t3796 = shen_cons_p(ctx, t3792);
    if (!shen_is_boolean(ctx, t3796))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t3796)) {
  KLObject* t3799 = shen_hd(ctx, t3792);
  KLObject* t3797;
  {
    KLObject* a3797[] = {t3799};
    t3797 = shen_apply_direct(ctx, "arity", 1, a3797);
  }
  KLObject* t3802 = shen_tl(ctx, t3792);
  KLObject* t3800;
  {
    KLObject* a3800[] = {t3802};
    t3800 = shen_apply_direct(ctx, "length", 1, a3800);
  }
  KLObject* t3804;
  {
    KLObject* a3804[] = {t3792, t3793};
    t3804 = shen_apply_direct(ctx, "element?", 2, a3804);
  }
  KLObject* t3803;
  if (!shen_is_boolean(ctx, t3804))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t3804)) {
    t3803 = t3792;
  } else {
  KLObject* t3811 = shen_hd(ctx, t3792);
  KLObject* t3809;
  {
    KLObject* a3809[] = {t3811};
    t3809 = shen_apply_direct(ctx, "shen.shen-call?", 1, a3809);
  }
  KLObject* t3808;
  if (!shen_is_boolean(ctx, t3809))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t3809)) {
    t3808 = t3792;
  } else {
  KLObject* t3814;
  {
    KLObject* a3814[] = {t3792};
    t3814 = shen_apply_direct(ctx, "shen.foreign?", 1, a3814);
  }
  KLObject* t3813;
  if (!shen_is_boolean(ctx, t3814))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t3814)) {
  KLObject* t3816;
  {
    KLObject* a3816[] = {t3792};
    t3816 = shen_tail_apply_direct(ctx, "shen.unpack-foreign", 1, a3816);
  }
    t3813 = t3816;
  } else {
  KLObject* t3819;
  {
    KLObject* a3819[] = {t3792};
    t3819 = shen_apply_direct(ctx, "shen.fn-call?", 1, a3819);
  }
  KLObject* t3818;
  if (!shen_is_boolean(ctx, t3819))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t3819)) {
  KLObject* t3821;
  {
    KLObject* a3821[] = {t3792};
    t3821 = shen_tail_apply_direct(ctx, "shen.fn-call", 1, a3821);
  }
    t3818 = t3821;
  } else {
  KLObject* t3824;
  {
    KLObject* a3824[] = {t3792};
    t3824 = shen_apply_direct(ctx, "shen.zero-place?", 1, a3824);
  }
  KLObject* t3823;
  if (!shen_is_boolean(ctx, t3824))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t3824)) {
    t3823 = t3792;
  } else {
  KLObject* t3830 = shen_hd(ctx, t3792);
  KLObject* t3828;
  {
    KLObject* a3828[] = {t3830, t3797};
    t3828 = shen_apply_direct(ctx, "shen.undefined-f?", 2, a3828);
  }
  KLObject* t3827;
  if (!shen_is_boolean(ctx, t3828))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t3828)) {
  KLObject* t3833 = shen_intern(ctx, "fn");
  KLObject* t3835 = shen_hd(ctx, t3792);
  KLObject* t3836 = shen_empty_list(ctx);
  KLObject* t3837 = shen_cons(ctx, t3835, t3836);
  KLObject* t3838 = shen_cons(ctx, t3833, t3837);
  KLObject* t3840 = shen_tl(ctx, t3792);
  KLObject* t3841 = shen_cons(ctx, t3838, t3840);
  KLObject* t3832;
  {
    KLObject* a3832[] = {t3841};
    t3832 = shen_tail_apply_direct(ctx, "shen.simple-curry", 1, a3832);
  }
    t3827 = t3832;
  } else {
  KLObject* t3845 = shen_hd(ctx, t3792);
  KLObject* t3843;
  {
    KLObject* a3843[] = {t3845};
    t3843 = shen_apply_direct(ctx, "variable?", 1, a3843);
  }
  KLObject* t3842;
  if (!shen_is_boolean(ctx, t3843))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t3843)) {
  KLObject* t3846;
  {
    KLObject* a3846[] = {t3792};
    t3846 = shen_tail_apply_direct(ctx, "shen.simple-curry", 1, a3846);
  }
    t3842 = t3846;
  } else {
  KLObject* t3851 = shen_hd(ctx, t3792);
  KLObject* t3849;
  {
    KLObject* a3849[] = {t3851};
    t3849 = shen_apply_direct(ctx, "shen.application?", 1, a3849);
  }
  KLObject* t3848;
  if (!shen_is_boolean(ctx, t3849))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t3849)) {
  KLObject* t3852;
  {
    KLObject* a3852[] = {t3792};
    t3852 = shen_tail_apply_direct(ctx, "shen.simple-curry", 1, a3852);
  }
    t3848 = t3852;
  } else {
  KLObject* t3857 = shen_hd(ctx, t3792);
  KLObject* t3855;
  {
    KLObject* a3855[] = {t3857, t3797, t3800};
    t3855 = shen_apply_direct(ctx, "shen.partial-application*?", 3, a3855);
  }
  KLObject* t3854;
  if (!shen_is_boolean(ctx, t3855))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t3855)) {
  KLObject* t3864 = shen_sub(ctx, t3797, t3800);
  KLObject* t3860;
  {
    KLObject* a3860[] = {t3792, t3864};
    t3860 = shen_tail_apply_direct(ctx, "shen.lambda-function", 2, a3860);
  }
    t3854 = t3860;
  } else {
  KLObject* t3868 = shen_hd(ctx, t3792);
  KLObject* t3866;
  {
    KLObject* a3866[] = {t3868, t3797, t3800};
    t3866 = shen_apply_direct(ctx, "shen.overapplication?", 3, a3866);
  }
  KLObject* t3865;
  if (!shen_is_boolean(ctx, t3866))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t3866)) {
  KLObject* t3872 = shen_intern(ctx, "fn");
  KLObject* t3874 = shen_hd(ctx, t3792);
  KLObject* t3875 = shen_empty_list(ctx);
  KLObject* t3876 = shen_cons(ctx, t3874, t3875);
  KLObject* t3877 = shen_cons(ctx, t3872, t3876);
  KLObject* t3879 = shen_tl(ctx, t3792);
  KLObject* t3880 = shen_cons(ctx, t3877, t3879);
  KLObject* t3871;
  {
    KLObject* a3871[] = {t3880};
    t3871 = shen_tail_apply_direct(ctx, "shen.simple-curry", 1, a3871);
  }
    t3865 = t3871;
  } else {
    t3865 = t3792;
  }
    t3854 = t3865;
  }
    t3848 = t3854;
  }
    t3842 = t3848;
  }
    t3827 = t3842;
  }
    t3823 = t3827;
  }
    t3818 = t3823;
  }
    t3813 = t3818;
  }
    t3808 = t3813;
  }
    t3803 = t3808;
  }
      t3794 = t3803;
    } else {
  KLObject* t3882 = shen_true(ctx);
    if (!shen_is_boolean(ctx, t3882))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t3882)) {
  KLObject* t3884 = shen_string(ctx, "partial function shen.process-application");
  KLObject* t3883;
  {
    KLObject* a3883[] = {t3884};
    t3883 = shen_tail_apply_direct(ctx, "simple-error", 1, a3883);
  }
      t3794 = t3883;
    } else {
      shen_simple_error(ctx, "No true case found for cond");
      t3794 = shen_empty_list(ctx);
    }
    }
  }
    return t3794;
  }
}

static KLObject* native_kl_shen_2eunpack_2dforeign_116 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t3885 = objects[0];
  tail_start_kl_shen_2eunpack_2dforeign_116: ;
  KLObject* t3886;
  {
  KLObject* t3889 = shen_cons_p(ctx, t3885);
  KLObject* t3887;
  if (!shen_is_boolean(ctx, t3889))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t3889)) {
    t3887 = t3889;
  } else {
  KLObject* t3892 = shen_hd(ctx, t3885);
  KLObject* t3893 = shen_cons_p(ctx, t3892);
  KLObject* t3890;
  if (!shen_is_boolean(ctx, t3893))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t3893)) {
    t3890 = t3893;
  } else {
  KLObject* t3895 = shen_intern(ctx, "foreign");
  KLObject* t3897 = shen_hd(ctx, t3885);
  KLObject* t3898 = shen_hd(ctx, t3897);
  KLObject* t3899 = shen_eq(ctx, t3895, t3898);
  KLObject* t3894;
  if (!shen_is_boolean(ctx, t3899))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t3899)) {
    t3894 = t3899;
  } else {
  KLObject* t3902 = shen_hd(ctx, t3885);
  KLObject* t3903 = shen_tl(ctx, t3902);
  KLObject* t3904 = shen_cons_p(ctx, t3903);
  KLObject* t3900;
  if (!shen_is_boolean(ctx, t3904))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t3904)) {
    t3900 = t3904;
  } else {
  KLObject* t3905 = shen_empty_list(ctx);
  KLObject* t3907 = shen_hd(ctx, t3885);
  KLObject* t3908 = shen_tl(ctx, t3907);
  KLObject* t3909 = shen_tl(ctx, t3908);
  KLObject* t3910 = shen_eq(ctx, t3905, t3909);
    if (!shen_is_boolean(ctx, t3910))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t3900 = t3910;
  }
    if (!shen_is_boolean(ctx, t3900))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t3894 = t3900;
  }
    if (!shen_is_boolean(ctx, t3894))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t3890 = t3894;
  }
    if (!shen_is_boolean(ctx, t3890))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t3887 = t3890;
  }
    if (!shen_is_boolean(ctx, t3887))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t3887)) {
  KLObject* t3912 = shen_hd(ctx, t3885);
  KLObject* t3913 = shen_tl(ctx, t3912);
  KLObject* t3914 = shen_hd(ctx, t3913);
  KLObject* t3916 = shen_tl(ctx, t3885);
  KLObject* t3917 = shen_cons(ctx, t3914, t3916);
      t3886 = t3917;
    } else {
  KLObject* t3918 = shen_true(ctx);
    if (!shen_is_boolean(ctx, t3918))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t3918)) {
  KLObject* t3920 = shen_string(ctx, "partial function shen.unpack-foreign");
  KLObject* t3919;
  {
    KLObject* a3919[] = {t3920};
    t3919 = shen_tail_apply_direct(ctx, "simple-error", 1, a3919);
  }
      t3886 = t3919;
    } else {
      shen_simple_error(ctx, "No true case found for cond");
      t3886 = shen_empty_list(ctx);
    }
    }
  }
    return t3886;
  }
}

static KLObject* native_kl_shen_2eforeign_3f_117 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t3921 = objects[0];
  tail_start_kl_shen_2eforeign_3f_117: ;
  KLObject* t3922;
  {
  KLObject* t3925 = shen_cons_p(ctx, t3921);
  KLObject* t3923;
  if (!shen_is_boolean(ctx, t3925))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t3925)) {
    t3923 = t3925;
  } else {
  KLObject* t3928 = shen_hd(ctx, t3921);
  KLObject* t3929 = shen_cons_p(ctx, t3928);
  KLObject* t3926;
  if (!shen_is_boolean(ctx, t3929))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t3929)) {
    t3926 = t3929;
  } else {
  KLObject* t3931 = shen_intern(ctx, "foreign");
  KLObject* t3933 = shen_hd(ctx, t3921);
  KLObject* t3934 = shen_hd(ctx, t3933);
  KLObject* t3935 = shen_eq(ctx, t3931, t3934);
  KLObject* t3930;
  if (!shen_is_boolean(ctx, t3935))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t3935)) {
    t3930 = t3935;
  } else {
  KLObject* t3938 = shen_hd(ctx, t3921);
  KLObject* t3939 = shen_tl(ctx, t3938);
  KLObject* t3940 = shen_cons_p(ctx, t3939);
  KLObject* t3936;
  if (!shen_is_boolean(ctx, t3940))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t3940)) {
    t3936 = t3940;
  } else {
  KLObject* t3941 = shen_empty_list(ctx);
  KLObject* t3943 = shen_hd(ctx, t3921);
  KLObject* t3944 = shen_tl(ctx, t3943);
  KLObject* t3945 = shen_tl(ctx, t3944);
  KLObject* t3946 = shen_eq(ctx, t3941, t3945);
    if (!shen_is_boolean(ctx, t3946))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t3936 = t3946;
  }
    if (!shen_is_boolean(ctx, t3936))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t3930 = t3936;
  }
    if (!shen_is_boolean(ctx, t3930))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t3926 = t3930;
  }
    if (!shen_is_boolean(ctx, t3926))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t3923 = t3926;
  }
    if (!shen_is_boolean(ctx, t3923))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t3923)) {
  KLObject* t3947 = shen_true(ctx);
      t3922 = t3947;
    } else {
  KLObject* t3948 = shen_true(ctx);
    if (!shen_is_boolean(ctx, t3948))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t3948)) {
  KLObject* t3949 = shen_false(ctx);
      t3922 = t3949;
    } else {
      shen_simple_error(ctx, "No true case found for cond");
      t3922 = shen_empty_list(ctx);
    }
    }
  }
    return t3922;
  }
}

static KLObject* native_kl_shen_2ezero_2dplace_3f_118 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t3950 = objects[0];
  tail_start_kl_shen_2ezero_2dplace_3f_118: ;
  KLObject* t3951;
  {
  KLObject* t3954 = shen_cons_p(ctx, t3950);
  KLObject* t3952;
  if (!shen_is_boolean(ctx, t3954))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t3954)) {
    t3952 = t3954;
  } else {
  KLObject* t3955 = shen_empty_list(ctx);
  KLObject* t3957 = shen_tl(ctx, t3950);
  KLObject* t3958 = shen_eq(ctx, t3955, t3957);
    if (!shen_is_boolean(ctx, t3958))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t3952 = t3958;
  }
    if (!shen_is_boolean(ctx, t3952))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t3952)) {
  KLObject* t3959 = shen_true(ctx);
      t3951 = t3959;
    } else {
  KLObject* t3960 = shen_true(ctx);
    if (!shen_is_boolean(ctx, t3960))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t3960)) {
  KLObject* t3961 = shen_false(ctx);
      t3951 = t3961;
    } else {
      shen_simple_error(ctx, "No true case found for cond");
      t3951 = shen_empty_list(ctx);
    }
    }
  }
    return t3951;
  }
}

static KLObject* native_kl_shen_2eshen_2dcall_3f_119 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t3962 = objects[0];
  tail_start_kl_shen_2eshen_2dcall_3f_119: ;
  KLObject* t3965 = shen_symbol_p(ctx, t3962);
  KLObject* t3963;
  if (!shen_is_boolean(ctx, t3965))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t3965)) {
    t3963 = t3965;
  } else {
  KLObject* t3967;
  {
    KLObject* a3967[] = {t3962};
    t3967 = shen_apply_direct(ctx, "str", 1, a3967);
  }
  KLObject* t3966;
  {
    KLObject* a3966[] = {t3967};
    t3966 = shen_apply_direct(ctx, "shen.internal-to-shen?", 1, a3966);
  }
    if (!shen_is_boolean(ctx, t3966))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t3963 = t3966;
  }
    return t3963;
  }
}

static KLObject* native_kl_shen_2eapplication_3f_120 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t3969 = objects[0];
  tail_start_kl_shen_2eapplication_3f_120: ;
  KLObject* t3970;
  {
  KLObject* t3973 = shen_cons_p(ctx, t3969);
  KLObject* t3971;
  if (!shen_is_boolean(ctx, t3973))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t3973)) {
    t3971 = t3973;
  } else {
  KLObject* t3975 = shen_intern(ctx, "protect");
  KLObject* t3977 = shen_hd(ctx, t3969);
  KLObject* t3978 = shen_eq(ctx, t3975, t3977);
  KLObject* t3974;
  if (!shen_is_boolean(ctx, t3978))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t3978)) {
    t3974 = t3978;
  } else {
  KLObject* t3981 = shen_tl(ctx, t3969);
  KLObject* t3982 = shen_cons_p(ctx, t3981);
  KLObject* t3979;
  if (!shen_is_boolean(ctx, t3982))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t3982)) {
    t3979 = t3982;
  } else {
  KLObject* t3983 = shen_empty_list(ctx);
  KLObject* t3985 = shen_tl(ctx, t3969);
  KLObject* t3986 = shen_tl(ctx, t3985);
  KLObject* t3987 = shen_eq(ctx, t3983, t3986);
    if (!shen_is_boolean(ctx, t3987))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t3979 = t3987;
  }
    if (!shen_is_boolean(ctx, t3979))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t3974 = t3979;
  }
    if (!shen_is_boolean(ctx, t3974))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t3971 = t3974;
  }
    if (!shen_is_boolean(ctx, t3971))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t3971)) {
  KLObject* t3988 = shen_false(ctx);
      t3970 = t3988;
    } else {
  KLObject* t3991 = shen_cons_p(ctx, t3969);
  KLObject* t3989;
  if (!shen_is_boolean(ctx, t3991))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t3991)) {
    t3989 = t3991;
  } else {
  KLObject* t3993 = shen_intern(ctx, "foreign");
  KLObject* t3995 = shen_hd(ctx, t3969);
  KLObject* t3996 = shen_eq(ctx, t3993, t3995);
  KLObject* t3992;
  if (!shen_is_boolean(ctx, t3996))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t3996)) {
    t3992 = t3996;
  } else {
  KLObject* t3999 = shen_tl(ctx, t3969);
  KLObject* t4000 = shen_cons_p(ctx, t3999);
  KLObject* t3997;
  if (!shen_is_boolean(ctx, t4000))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t4000)) {
    t3997 = t4000;
  } else {
  KLObject* t4001 = shen_empty_list(ctx);
  KLObject* t4003 = shen_tl(ctx, t3969);
  KLObject* t4004 = shen_tl(ctx, t4003);
  KLObject* t4005 = shen_eq(ctx, t4001, t4004);
    if (!shen_is_boolean(ctx, t4005))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t3997 = t4005;
  }
    if (!shen_is_boolean(ctx, t3997))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t3992 = t3997;
  }
    if (!shen_is_boolean(ctx, t3992))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t3989 = t3992;
  }
    if (!shen_is_boolean(ctx, t3989))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t3989)) {
  KLObject* t4006 = shen_false(ctx);
      t3970 = t4006;
    } else {
  KLObject* t4007 = shen_true(ctx);
    if (!shen_is_boolean(ctx, t4007))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t4007)) {
  KLObject* t4009 = shen_cons_p(ctx, t3969);
      t3970 = t4009;
    } else {
      shen_simple_error(ctx, "No true case found for cond");
      t3970 = shen_empty_list(ctx);
    }
    }
    }
  }
    return t3970;
  }
}

static KLObject* native_kl_shen_2eundefined_2df_3f_121 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t4010 = objects[0];
    KLObject* t4011 = objects[1];
  tail_start_kl_shen_2eundefined_2df_3f_121: ;
  KLObject* t4012;
  {
  KLObject* t4013 = shen_number_l(ctx, -1);
  KLObject* t4015 = shen_eq(ctx, t4013, t4011);
    if (!shen_is_boolean(ctx, t4015))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t4015)) {
  KLObject* t4017;
  {
    KLObject* a4017[] = {t4010};
    t4017 = shen_apply_direct(ctx, "shen.lowercase-symbol?", 1, a4017);
  }
  KLObject* t4016;
  if (!shen_is_boolean(ctx, t4017))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t4017)) {
    t4016 = t4017;
  } else {
  KLObject* t4023 = shen_intern(ctx, "shen");
  KLObject* t4022;
  {
    KLObject* a4022[] = {t4023};
    t4022 = shen_apply_direct(ctx, "external", 1, a4022);
  }
  KLObject* t4020;
  {
    KLObject* a4020[] = {t4010, t4022};
    t4020 = shen_apply_direct(ctx, "element?", 2, a4020);
  }
  KLObject* t4019;
  {
    KLObject* a4019[] = {t4020};
    t4019 = shen_apply_direct(ctx, "not", 1, a4019);
  }
    if (!shen_is_boolean(ctx, t4019))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t4016 = t4019;
  }
      t4012 = t4016;
    } else {
  KLObject* t4024 = shen_true(ctx);
    if (!shen_is_boolean(ctx, t4024))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t4024)) {
  KLObject* t4025 = shen_false(ctx);
      t4012 = t4025;
    } else {
      shen_simple_error(ctx, "No true case found for cond");
      t4012 = shen_empty_list(ctx);
    }
    }
  }
    return t4012;
  }
}

static KLObject* native_kl_shen_2elowercase_2dsymbol_3f_122 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t4026 = objects[0];
  tail_start_kl_shen_2elowercase_2dsymbol_3f_122: ;
  KLObject* t4029 = shen_symbol_p(ctx, t4026);
  KLObject* t4027;
  if (!shen_is_boolean(ctx, t4029))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t4029)) {
    t4027 = t4029;
  } else {
  KLObject* t4031;
  {
    KLObject* a4031[] = {t4026};
    t4031 = shen_apply_direct(ctx, "variable?", 1, a4031);
  }
  KLObject* t4030;
  {
    KLObject* a4030[] = {t4031};
    t4030 = shen_apply_direct(ctx, "not", 1, a4030);
  }
    if (!shen_is_boolean(ctx, t4030))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t4027 = t4030;
  }
    return t4027;
  }
}

static KLObject* native_kl_shen_2esimple_2dcurry_123 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t4033 = objects[0];
  tail_start_kl_shen_2esimple_2dcurry_123: ;
  KLObject* t4034;
  {
  KLObject* t4037 = shen_cons_p(ctx, t4033);
  KLObject* t4035;
  if (!shen_is_boolean(ctx, t4037))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t4037)) {
    t4035 = t4037;
  } else {
  KLObject* t4040 = shen_tl(ctx, t4033);
  KLObject* t4041 = shen_cons_p(ctx, t4040);
  KLObject* t4038;
  if (!shen_is_boolean(ctx, t4041))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t4041)) {
    t4038 = t4041;
  } else {
  KLObject* t4042 = shen_empty_list(ctx);
  KLObject* t4044 = shen_tl(ctx, t4033);
  KLObject* t4045 = shen_tl(ctx, t4044);
  KLObject* t4046 = shen_eq(ctx, t4042, t4045);
    if (!shen_is_boolean(ctx, t4046))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t4038 = t4046;
  }
    if (!shen_is_boolean(ctx, t4038))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t4035 = t4038;
  }
    if (!shen_is_boolean(ctx, t4035))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t4035)) {
      t4034 = t4033;
    } else {
  KLObject* t4050 = shen_cons_p(ctx, t4033);
  KLObject* t4048;
  if (!shen_is_boolean(ctx, t4050))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t4050)) {
    t4048 = t4050;
  } else {
  KLObject* t4053 = shen_tl(ctx, t4033);
  KLObject* t4054 = shen_cons_p(ctx, t4053);
  KLObject* t4051;
  if (!shen_is_boolean(ctx, t4054))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t4054)) {
    t4051 = t4054;
  } else {
  KLObject* t4056 = shen_tl(ctx, t4033);
  KLObject* t4057 = shen_tl(ctx, t4056);
  KLObject* t4058 = shen_cons_p(ctx, t4057);
    if (!shen_is_boolean(ctx, t4058))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t4051 = t4058;
  }
    if (!shen_is_boolean(ctx, t4051))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t4048 = t4051;
  }
    if (!shen_is_boolean(ctx, t4048))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t4048)) {
  KLObject* t4060 = shen_hd(ctx, t4033);
  KLObject* t4062 = shen_tl(ctx, t4033);
  KLObject* t4063 = shen_hd(ctx, t4062);
  KLObject* t4064 = shen_empty_list(ctx);
  KLObject* t4065 = shen_cons(ctx, t4063, t4064);
  KLObject* t4066 = shen_cons(ctx, t4060, t4065);
  KLObject* t4068 = shen_tl(ctx, t4033);
  KLObject* t4069 = shen_tl(ctx, t4068);
  KLObject* t4070 = shen_cons(ctx, t4066, t4069);
  {
    KLObject* n4071_0 = t4070;
    t4033 = n4071_0;
    goto tail_start_kl_shen_2esimple_2dcurry_123;
  }
  KLObject* t4071 = NULL;
      t4034 = t4071;
    } else {
  KLObject* t4072 = shen_true(ctx);
    if (!shen_is_boolean(ctx, t4072))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t4072)) {
      t4034 = t4033;
    } else {
      shen_simple_error(ctx, "No true case found for cond");
      t4034 = shen_empty_list(ctx);
    }
    }
    }
  }
    return t4034;
  }
}

static KLObject* native_kl_function_124 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t4074 = objects[0];
  tail_start_kl_function_124: ;
  KLObject* t4075;
  {
    KLObject* a4075[] = {t4074};
    t4075 = shen_tail_apply_direct(ctx, "fn", 1, a4075);
  }
    return t4075;
  }
}

static KLObject* native_kl_fn_125 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t4077 = objects[0];
  tail_start_kl_fn_125: ;
  KLObject* t4078;
  {
  KLObject* t4079;
  {
    KLObject* a4079[] = {t4077};
    t4079 = shen_apply_direct(ctx, "arity", 1, a4079);
  }
  KLObject* t4081 = shen_number_l(ctx, 0);
  KLObject* t4082 = shen_eq(ctx, t4079, t4081);
    if (!shen_is_boolean(ctx, t4082))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t4082)) {
  KLObject* t4083;
  {
    Vector* a4083 = shen_vector(ctx, 0);
    t4083 = shen_tail_apply(ctx, t4077, a4083);
  }
      t4078 = t4083;
    } else {
  KLObject* t4085 = shen_true(ctx);
    if (!shen_is_boolean(ctx, t4085))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t4085)) {
  KLObject* t4089 = shen_intern(ctx, "shen.*lambdatable*");
  KLObject* t4088;
  {
    KLObject* a4088[] = {t4089};
    t4088 = shen_apply_direct(ctx, "value", 1, a4088);
  }
  KLObject* t4086;
  {
    KLObject* a4086[] = {t4077, t4088};
    t4086 = shen_apply_direct(ctx, "assoc", 2, a4086);
  }
  KLObject* t4091;
  {
    KLObject* a4091[] = {t4086};
    t4091 = shen_apply_direct(ctx, "empty?", 1, a4091);
  }
  KLObject* t4090;
  if (!shen_is_boolean(ctx, t4091))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t4091)) {
  KLObject* t4095 = shen_string(ctx, "fn: ");
  KLObject* t4098 = shen_string(ctx, " is undefined\n");
  KLObject* t4099 = shen_intern(ctx, "shen.a");
  KLObject* t4096;
  {
    KLObject* a4096[] = {t4077, t4098, t4099};
    t4096 = shen_apply_direct(ctx, "shen.app", 3, a4096);
  }
  KLObject* t4094;
  {
    KLObject* a4094[] = {t4095, t4096};
    t4094 = shen_apply_direct(ctx, "cn", 2, a4094);
  }
  KLObject* t4093;
  {
    KLObject* a4093[] = {t4094};
    t4093 = shen_tail_apply_direct(ctx, "simple-error", 1, a4093);
  }
    t4090 = t4093;
  } else {
  KLObject* t4101 = shen_tl(ctx, t4086);
    t4090 = t4101;
  }
      t4078 = t4090;
    } else {
      shen_simple_error(ctx, "No true case found for cond");
      t4078 = shen_empty_list(ctx);
    }
    }
  }
    return t4078;
  }
}

static KLObject* native_kl_shen_2efn_2dcall_3f_126 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t4102 = objects[0];
  tail_start_kl_shen_2efn_2dcall_3f_126: ;
  KLObject* t4103;
  {
  KLObject* t4106 = shen_cons_p(ctx, t4102);
  KLObject* t4104;
  if (!shen_is_boolean(ctx, t4106))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t4106)) {
    t4104 = t4106;
  } else {
  KLObject* t4108 = shen_intern(ctx, "fn");
  KLObject* t4110 = shen_hd(ctx, t4102);
  KLObject* t4111 = shen_eq(ctx, t4108, t4110);
  KLObject* t4107;
  if (!shen_is_boolean(ctx, t4111))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t4111)) {
    t4107 = t4111;
  } else {
  KLObject* t4114 = shen_tl(ctx, t4102);
  KLObject* t4115 = shen_cons_p(ctx, t4114);
  KLObject* t4112;
  if (!shen_is_boolean(ctx, t4115))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t4115)) {
    t4112 = t4115;
  } else {
  KLObject* t4116 = shen_empty_list(ctx);
  KLObject* t4118 = shen_tl(ctx, t4102);
  KLObject* t4119 = shen_tl(ctx, t4118);
  KLObject* t4120 = shen_eq(ctx, t4116, t4119);
    if (!shen_is_boolean(ctx, t4120))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t4112 = t4120;
  }
    if (!shen_is_boolean(ctx, t4112))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t4107 = t4112;
  }
    if (!shen_is_boolean(ctx, t4107))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t4104 = t4107;
  }
    if (!shen_is_boolean(ctx, t4104))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t4104)) {
  KLObject* t4121 = shen_true(ctx);
      t4103 = t4121;
    } else {
  KLObject* t4124 = shen_cons_p(ctx, t4102);
  KLObject* t4122;
  if (!shen_is_boolean(ctx, t4124))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t4124)) {
    t4122 = t4124;
  } else {
  KLObject* t4126 = shen_intern(ctx, "function");
  KLObject* t4128 = shen_hd(ctx, t4102);
  KLObject* t4129 = shen_eq(ctx, t4126, t4128);
  KLObject* t4125;
  if (!shen_is_boolean(ctx, t4129))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t4129)) {
    t4125 = t4129;
  } else {
  KLObject* t4132 = shen_tl(ctx, t4102);
  KLObject* t4133 = shen_cons_p(ctx, t4132);
  KLObject* t4130;
  if (!shen_is_boolean(ctx, t4133))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t4133)) {
    t4130 = t4133;
  } else {
  KLObject* t4134 = shen_empty_list(ctx);
  KLObject* t4136 = shen_tl(ctx, t4102);
  KLObject* t4137 = shen_tl(ctx, t4136);
  KLObject* t4138 = shen_eq(ctx, t4134, t4137);
    if (!shen_is_boolean(ctx, t4138))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t4130 = t4138;
  }
    if (!shen_is_boolean(ctx, t4130))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t4125 = t4130;
  }
    if (!shen_is_boolean(ctx, t4125))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t4122 = t4125;
  }
    if (!shen_is_boolean(ctx, t4122))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t4122)) {
  KLObject* t4139 = shen_true(ctx);
      t4103 = t4139;
    } else {
  KLObject* t4140 = shen_true(ctx);
    if (!shen_is_boolean(ctx, t4140))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t4140)) {
  KLObject* t4141 = shen_false(ctx);
      t4103 = t4141;
    } else {
      shen_simple_error(ctx, "No true case found for cond");
      t4103 = shen_empty_list(ctx);
    }
    }
    }
  }
    return t4103;
  }
}

static KLObject* native_kl_shen_2efn_2dcall_127 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t4142 = objects[0];
  tail_start_kl_shen_2efn_2dcall_127: ;
  KLObject* t4143;
  {
  KLObject* t4146 = shen_cons_p(ctx, t4142);
  KLObject* t4144;
  if (!shen_is_boolean(ctx, t4146))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t4146)) {
    t4144 = t4146;
  } else {
  KLObject* t4148 = shen_intern(ctx, "function");
  KLObject* t4150 = shen_hd(ctx, t4142);
  KLObject* t4151 = shen_eq(ctx, t4148, t4150);
  KLObject* t4147;
  if (!shen_is_boolean(ctx, t4151))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t4151)) {
    t4147 = t4151;
  } else {
  KLObject* t4154 = shen_tl(ctx, t4142);
  KLObject* t4155 = shen_cons_p(ctx, t4154);
  KLObject* t4152;
  if (!shen_is_boolean(ctx, t4155))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t4155)) {
    t4152 = t4155;
  } else {
  KLObject* t4156 = shen_empty_list(ctx);
  KLObject* t4158 = shen_tl(ctx, t4142);
  KLObject* t4159 = shen_tl(ctx, t4158);
  KLObject* t4160 = shen_eq(ctx, t4156, t4159);
    if (!shen_is_boolean(ctx, t4160))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t4152 = t4160;
  }
    if (!shen_is_boolean(ctx, t4152))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t4147 = t4152;
  }
    if (!shen_is_boolean(ctx, t4147))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t4144 = t4147;
  }
    if (!shen_is_boolean(ctx, t4144))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t4144)) {
  KLObject* t4161 = shen_intern(ctx, "fn");
  KLObject* t4163 = shen_tl(ctx, t4142);
  KLObject* t4164 = shen_cons(ctx, t4161, t4163);
  {
    KLObject* n4165_0 = t4164;
    t4142 = n4165_0;
    goto tail_start_kl_shen_2efn_2dcall_127;
  }
  KLObject* t4165 = NULL;
      t4143 = t4165;
    } else {
  KLObject* t4168 = shen_cons_p(ctx, t4142);
  KLObject* t4166;
  if (!shen_is_boolean(ctx, t4168))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t4168)) {
    t4166 = t4168;
  } else {
  KLObject* t4170 = shen_intern(ctx, "fn");
  KLObject* t4172 = shen_hd(ctx, t4142);
  KLObject* t4173 = shen_eq(ctx, t4170, t4172);
  KLObject* t4169;
  if (!shen_is_boolean(ctx, t4173))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t4173)) {
    t4169 = t4173;
  } else {
  KLObject* t4176 = shen_tl(ctx, t4142);
  KLObject* t4177 = shen_cons_p(ctx, t4176);
  KLObject* t4174;
  if (!shen_is_boolean(ctx, t4177))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t4177)) {
    t4174 = t4177;
  } else {
  KLObject* t4178 = shen_empty_list(ctx);
  KLObject* t4180 = shen_tl(ctx, t4142);
  KLObject* t4181 = shen_tl(ctx, t4180);
  KLObject* t4182 = shen_eq(ctx, t4178, t4181);
    if (!shen_is_boolean(ctx, t4182))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t4174 = t4182;
  }
    if (!shen_is_boolean(ctx, t4174))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t4169 = t4174;
  }
    if (!shen_is_boolean(ctx, t4169))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t4166 = t4169;
  }
    if (!shen_is_boolean(ctx, t4166))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t4166)) {
  KLObject* t4185 = shen_tl(ctx, t4142);
  KLObject* t4186 = shen_hd(ctx, t4185);
  KLObject* t4183;
  {
    KLObject* a4183[] = {t4186};
    t4183 = shen_apply_direct(ctx, "arity", 1, a4183);
  }
  KLObject* t4189 = shen_number_l(ctx, -1);
  KLObject* t4190 = shen_eq(ctx, t4183, t4189);
  KLObject* t4187;
  if (!shen_is_boolean(ctx, t4190))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t4190)) {
    t4187 = t4142;
  } else {
  KLObject* t4194 = shen_number_l(ctx, 0);
  KLObject* t4195 = shen_eq(ctx, t4183, t4194);
  KLObject* t4192;
  if (!shen_is_boolean(ctx, t4195))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t4195)) {
  KLObject* t4197 = shen_tl(ctx, t4142);
    t4192 = t4197;
  } else {
  KLObject* t4200 = shen_tl(ctx, t4142);
  KLObject* t4198;
  {
    KLObject* a4198[] = {t4200, t4183};
    t4198 = shen_tail_apply_direct(ctx, "shen.lambda-function", 2, a4198);
  }
    t4192 = t4198;
  }
    t4187 = t4192;
  }
      t4143 = t4187;
    } else {
  KLObject* t4202 = shen_true(ctx);
    if (!shen_is_boolean(ctx, t4202))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t4202)) {
  KLObject* t4204 = shen_string(ctx, "partial function shen.fn-call");
  KLObject* t4203;
  {
    KLObject* a4203[] = {t4204};
    t4203 = shen_tail_apply_direct(ctx, "simple-error", 1, a4203);
  }
      t4143 = t4203;
    } else {
      shen_simple_error(ctx, "No true case found for cond");
      t4143 = shen_empty_list(ctx);
    }
    }
    }
  }
    return t4143;
  }
}

static KLObject* native_kl_shen_2epartial_2dapplication_2a_3f_128 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t4205 = objects[0];
    KLObject* t4206 = objects[1];
    KLObject* t4207 = objects[2];
  tail_start_kl_shen_2epartial_2dapplication_2a_3f_128: ;
  KLObject* t4210 = shen_gt(ctx, t4206, t4207);
  KLObject* t4212;
  if (!shen_is_boolean(ctx, t4210))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t4210)) {
    t4212 = t4210;
  } else {
  KLObject* t4215 = shen_apply_direct(ctx, "shen.loading?", 0, NULL);
  KLObject* t4214;
  if (!shen_is_boolean(ctx, t4215))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t4215)) {
    t4214 = t4215;
  } else {
  KLObject* t4219 = shen_intern(ctx, "+");
  KLObject* t4220 = shen_intern(ctx, "-");
  KLObject* t4221 = shen_empty_list(ctx);
  KLObject* t4222 = shen_cons(ctx, t4220, t4221);
  KLObject* t4223 = shen_cons(ctx, t4219, t4222);
  KLObject* t4217;
  {
    KLObject* a4217[] = {t4205, t4223};
    t4217 = shen_apply_direct(ctx, "element?", 2, a4217);
  }
  KLObject* t4216;
  {
    KLObject* a4216[] = {t4217};
    t4216 = shen_apply_direct(ctx, "not", 1, a4216);
  }
    if (!shen_is_boolean(ctx, t4216))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t4214 = t4216;
  }
    if (!shen_is_boolean(ctx, t4214))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t4212 = t4214;
  }
  KLObject* t4211;
  if (!shen_is_boolean(ctx, t4212))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t4212)) {
  KLObject* t4226 = shen_string(ctx, "partial application of ");
  KLObject* t4229 = shen_string(ctx, "\n");
  KLObject* t4230 = shen_intern(ctx, "shen.a");
  KLObject* t4227;
  {
    KLObject* a4227[] = {t4205, t4229, t4230};
    t4227 = shen_apply_direct(ctx, "shen.app", 3, a4227);
  }
  KLObject* t4225;
  {
    KLObject* a4225[] = {t4226, t4227};
    t4225 = shen_apply_direct(ctx, "cn", 2, a4225);
  }
  KLObject* t4231 = shen_apply_direct(ctx, "stoutput", 0, NULL);
  KLObject* t4224;
  {
    KLObject* a4224[] = {t4225, t4231};
    t4224 = shen_apply_direct(ctx, "pr", 2, a4224);
  }
    t4211 = t4224;
  } else {
  KLObject* t4232 = shen_intern(ctx, "shen.skip");
    t4211 = t4232;
  }
    return t4210;
  }
}

static KLObject* native_kl_shen_2eloading_3f_129 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  (void)function_object;
  (void)arguments;
  {
  tail_start_kl_shen_2eloading_3f_129: ;
  KLObject* t4235 = shen_intern(ctx, "shen.*loading?*");
  KLObject* t4234;
  {
    KLObject* a4234[] = {t4235};
    t4234 = shen_tail_apply_direct(ctx, "value", 1, a4234);
  }
    return t4234;
  }
}

static KLObject* native_kl_shen_2eoverapplication_3f_130 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t4236 = objects[0];
    KLObject* t4237 = objects[1];
    KLObject* t4238 = objects[2];
  tail_start_kl_shen_2eoverapplication_3f_130: ;
  KLObject* t4239;
  {
  KLObject* t4240 = shen_number_l(ctx, -1);
  KLObject* t4242 = shen_eq(ctx, t4240, t4237);
    if (!shen_is_boolean(ctx, t4242))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t4242)) {
  KLObject* t4243 = shen_false(ctx);
      t4239 = t4243;
    } else {
  KLObject* t4244 = shen_true(ctx);
    if (!shen_is_boolean(ctx, t4244))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t4244)) {
  KLObject* t4247 = shen_lt(ctx, t4237, t4238);
  KLObject* t4249;
  if (!shen_is_boolean(ctx, t4247))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t4247)) {
    t4249 = t4247;
  } else {
  KLObject* t4251 = shen_apply_direct(ctx, "shen.loading?", 0, NULL);
    if (!shen_is_boolean(ctx, t4251))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t4249 = t4251;
  }
  KLObject* t4248;
  if (!shen_is_boolean(ctx, t4249))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t4249)) {
  KLObject* t4256 = shen_string(ctx, " might not like ");
  KLObject* t4260 = shen_string(ctx, " argument");
  KLObject* t4264 = shen_number_l(ctx, 1);
  KLObject* t4265 = shen_eq(ctx, t4238, t4264);
  KLObject* t4262;
  if (!shen_is_boolean(ctx, t4265))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t4265)) {
  KLObject* t4266 = shen_string(ctx, "");
    t4262 = t4266;
  } else {
  KLObject* t4267 = shen_string(ctx, "s");
    t4262 = t4267;
  }
  KLObject* t4268 = shen_string(ctx, "\n");
  KLObject* t4269 = shen_intern(ctx, "shen.a");
  KLObject* t4261;
  {
    KLObject* a4261[] = {t4262, t4268, t4269};
    t4261 = shen_apply_direct(ctx, "shen.app", 3, a4261);
  }
  KLObject* t4259;
  {
    KLObject* a4259[] = {t4260, t4261};
    t4259 = shen_apply_direct(ctx, "cn", 2, a4259);
  }
  KLObject* t4270 = shen_intern(ctx, "shen.a");
  KLObject* t4257;
  {
    KLObject* a4257[] = {t4238, t4259, t4270};
    t4257 = shen_apply_direct(ctx, "shen.app", 3, a4257);
  }
  KLObject* t4255;
  {
    KLObject* a4255[] = {t4256, t4257};
    t4255 = shen_apply_direct(ctx, "cn", 2, a4255);
  }
  KLObject* t4271 = shen_intern(ctx, "shen.a");
  KLObject* t4253;
  {
    KLObject* a4253[] = {t4236, t4255, t4271};
    t4253 = shen_apply_direct(ctx, "shen.app", 3, a4253);
  }
  KLObject* t4272 = shen_apply_direct(ctx, "stoutput", 0, NULL);
  KLObject* t4252;
  {
    KLObject* a4252[] = {t4253, t4272};
    t4252 = shen_apply_direct(ctx, "pr", 2, a4252);
  }
    t4248 = t4252;
  } else {
  KLObject* t4273 = shen_intern(ctx, "shen.skip");
    t4248 = t4273;
  }
      t4239 = t4247;
    } else {
      shen_simple_error(ctx, "No true case found for cond");
      t4239 = shen_empty_list(ctx);
    }
    }
  }
    return t4239;
  }
}

void shen_kernel_aot_install_reader (shen_context* ctx)
{
  shen_register_defun(ctx, "read-file", 1, &native_kl_read_2dfile_0);
  shen_register_defun(ctx, "shen.reader-error", 1, &native_kl_shen_2ereader_2derror_1);
  shen_register_defun(ctx, "shen.reader-error-message", 3, &native_kl_shen_2ereader_2derror_2dmessage_2);
  shen_register_defun(ctx, "it", 0, &native_kl_it_3);
  shen_register_defun(ctx, "read-file-as-bytelist", 1, &native_kl_read_2dfile_2das_2dbytelist_4);
  shen_register_defun(ctx, "shen.read-file-as-bytelist-help", 3, &native_kl_shen_2eread_2dfile_2das_2dbytelist_2dhelp_5);
  shen_register_defun(ctx, "read-file-as-string", 1, &native_kl_read_2dfile_2das_2dstring_6);
  shen_register_defun(ctx, "shen.rfas-h", 3, &native_kl_shen_2erfas_2dh_7);
  shen_register_defun(ctx, "input", 1, &native_kl_input_8);
  shen_register_defun(ctx, "shen.input-h+", 2, &native_kl_shen_2einput_2dh_2b_9);
  shen_register_defun(ctx, "shen.monotype", 1, &native_kl_shen_2emonotype_10);
  shen_register_defun(ctx, "lineread", 1, &native_kl_lineread_11);
  shen_register_defun(ctx, "read-from-string", 1, &native_kl_read_2dfrom_2dstring_12);
  shen_register_defun(ctx, "read-from-string-unprocessed", 1, &native_kl_read_2dfrom_2dstring_2dunprocessed_13);
  shen_register_defun(ctx, "shen.str->bytes", 1, &native_kl_shen_2estr_2d_3ebytes_14);
  shen_register_defun(ctx, "read", 1, &native_kl_read_15);
  shen_register_defun(ctx, "shen.my-read-byte", 1, &native_kl_shen_2emy_2dread_2dbyte_16);
  shen_register_defun(ctx, "shen.read-loop", 4, &native_kl_shen_2eread_2dloop_17);
  shen_register_defun(ctx, "shen.try-parse", 1, &native_kl_shen_2etry_2dparse_18);
  shen_register_defun(ctx, "shen.nothing-doing?", 1, &native_kl_shen_2enothing_2ddoing_3f_19);
  shen_register_defun(ctx, "shen.record-it", 1, &native_kl_shen_2erecord_2dit_20);
  shen_register_defun(ctx, "shen.bytes->string", 1, &native_kl_shen_2ebytes_2d_3estring_21);
  shen_register_defun(ctx, "shen.process-sexprs", 1, &native_kl_shen_2eprocess_2dsexprs_22);
  shen_register_defun(ctx, "shen.find-types", 1, &native_kl_shen_2efind_2dtypes_23);
  shen_register_defun(ctx, "shen.find-arities", 1, &native_kl_shen_2efind_2darities_24);
  shen_register_defun(ctx, "shen.store-arity", 2, &native_kl_shen_2estore_2darity_25);
  shen_register_defun(ctx, "shen.execute-store-arity", 2, &native_kl_shen_2eexecute_2dstore_2darity_26);
  shen_register_defun(ctx, "shen.update-lambdatable", 2, &native_kl_shen_2eupdate_2dlambdatable_27);
  shen_register_defun(ctx, "shen.lambda-function", 2, &native_kl_shen_2elambda_2dfunction_28);
  shen_register_defun(ctx, "shen.assoc->", 3, &native_kl_shen_2eassoc_2d_3e_29);
  shen_register_defun(ctx, "shen.find-arity", 3, &native_kl_shen_2efind_2darity_30);
  shen_register_defun(ctx, "shen.<s-exprs>", 1, &native_kl_shen_2e_3cs_2dexprs_3e_31);
  shen_register_defun(ctx, "shen.add-sexpr", 2, &native_kl_shen_2eadd_2dsexpr_32);
  shen_register_defun(ctx, "shen.<lsb>", 1, &native_kl_shen_2e_3clsb_3e_33);
  shen_register_defun(ctx, "shen.<rsb>", 1, &native_kl_shen_2e_3crsb_3e_34);
  shen_register_defun(ctx, "shen.<s-exprs1>", 1, &native_kl_shen_2e_3cs_2dexprs1_3e_35);
  shen_register_defun(ctx, "shen.<s-exprs2>", 1, &native_kl_shen_2e_3cs_2dexprs2_3e_36);
  shen_register_defun(ctx, "shen.cons-form", 1, &native_kl_shen_2econs_2dform_37);
  shen_register_defun(ctx, "shen.<lrb>", 1, &native_kl_shen_2e_3clrb_3e_38);
  shen_register_defun(ctx, "shen.<rrb>", 1, &native_kl_shen_2e_3crrb_3e_39);
  shen_register_defun(ctx, "shen.<lcurly>", 1, &native_kl_shen_2e_3clcurly_3e_40);
  shen_register_defun(ctx, "shen.<rcurly>", 1, &native_kl_shen_2e_3crcurly_3e_41);
  shen_register_defun(ctx, "shen.<bar>", 1, &native_kl_shen_2e_3cbar_3e_42);
  shen_register_defun(ctx, "shen.<semicolon>", 1, &native_kl_shen_2e_3csemicolon_3e_43);
  shen_register_defun(ctx, "shen.<colon>", 1, &native_kl_shen_2e_3ccolon_3e_44);
  shen_register_defun(ctx, "shen.<comma>", 1, &native_kl_shen_2e_3ccomma_3e_45);
  shen_register_defun(ctx, "shen.<equal>", 1, &native_kl_shen_2e_3cequal_3e_46);
  shen_register_defun(ctx, "shen.<comment>", 1, &native_kl_shen_2e_3ccomment_3e_47);
  shen_register_defun(ctx, "shen.<singleline>", 1, &native_kl_shen_2e_3csingleline_3e_48);
  shen_register_defun(ctx, "shen.<backslash>", 1, &native_kl_shen_2e_3cbackslash_3e_49);
  shen_register_defun(ctx, "shen.<shortnatters>", 1, &native_kl_shen_2e_3cshortnatters_3e_50);
  shen_register_defun(ctx, "shen.<shortnatter>", 1, &native_kl_shen_2e_3cshortnatter_3e_51);
  shen_register_defun(ctx, "shen.<returns>", 1, &native_kl_shen_2e_3creturns_3e_52);
  shen_register_defun(ctx, "shen.<return>", 1, &native_kl_shen_2e_3creturn_3e_53);
  shen_register_defun(ctx, "shen.return?", 1, &native_kl_shen_2ereturn_3f_54);
  shen_register_defun(ctx, "shen.<multiline>", 1, &native_kl_shen_2e_3cmultiline_3e_55);
  shen_register_defun(ctx, "shen.<times>", 1, &native_kl_shen_2e_3ctimes_3e_56);
  shen_register_defun(ctx, "shen.<longnatter>", 1, &native_kl_shen_2e_3clongnatter_3e_57);
  shen_register_defun(ctx, "shen.<atom>", 1, &native_kl_shen_2e_3catom_3e_58);
  shen_register_defun(ctx, "shen.<sym>", 1, &native_kl_shen_2e_3csym_3e_59);
  shen_register_defun(ctx, "shen.<alpha>", 1, &native_kl_shen_2e_3calpha_3e_60);
  shen_register_defun(ctx, "shen.alpha?", 1, &native_kl_shen_2ealpha_3f_61);
  shen_register_defun(ctx, "shen.lowercase?", 1, &native_kl_shen_2elowercase_3f_62);
  shen_register_defun(ctx, "shen.uppercase?", 1, &native_kl_shen_2euppercase_3f_63);
  shen_register_defun(ctx, "shen.misc?", 1, &native_kl_shen_2emisc_3f_64);
  shen_register_defun(ctx, "shen.<alphanums>", 1, &native_kl_shen_2e_3calphanums_3e_65);
  shen_register_defun(ctx, "shen.<alphanum>", 1, &native_kl_shen_2e_3calphanum_3e_66);
  shen_register_defun(ctx, "shen.<numeral>", 1, &native_kl_shen_2e_3cnumeral_3e_67);
  shen_register_defun(ctx, "shen.digit?", 1, &native_kl_shen_2edigit_3f_68);
  shen_register_defun(ctx, "shen.<str>", 1, &native_kl_shen_2e_3cstr_3e_69);
  shen_register_defun(ctx, "shen.<dbq>", 1, &native_kl_shen_2e_3cdbq_3e_70);
  shen_register_defun(ctx, "shen.<strcontents>", 1, &native_kl_shen_2e_3cstrcontents_3e_71);
  shen_register_defun(ctx, "shen.<strc>", 1, &native_kl_shen_2e_3cstrc_3e_72);
  shen_register_defun(ctx, "shen.<control>", 1, &native_kl_shen_2e_3ccontrol_3e_73);
  shen_register_defun(ctx, "shen.<notdbq>", 1, &native_kl_shen_2e_3cnotdbq_3e_74);
  shen_register_defun(ctx, "shen.<lowC>", 1, &native_kl_shen_2e_3clowC_3e_75);
  shen_register_defun(ctx, "shen.<hash>", 1, &native_kl_shen_2e_3chash_3e_76);
  shen_register_defun(ctx, "shen.<number>", 1, &native_kl_shen_2e_3cnumber_3e_77);
  shen_register_defun(ctx, "shen.<minus>", 1, &native_kl_shen_2e_3cminus_3e_78);
  shen_register_defun(ctx, "shen.<plus>", 1, &native_kl_shen_2e_3cplus_3e_79);
  shen_register_defun(ctx, "shen.<integer>", 1, &native_kl_shen_2e_3cinteger_3e_80);
  shen_register_defun(ctx, "shen.<digits>", 1, &native_kl_shen_2e_3cdigits_3e_81);
  shen_register_defun(ctx, "shen.<digit>", 1, &native_kl_shen_2e_3cdigit_3e_82);
  shen_register_defun(ctx, "shen.byte->digit", 1, &native_kl_shen_2ebyte_2d_3edigit_83);
  shen_register_defun(ctx, "shen.compute-integer", 1, &native_kl_shen_2ecompute_2dinteger_84);
  shen_register_defun(ctx, "shen.compute-integer-h", 2, &native_kl_shen_2ecompute_2dinteger_2dh_85);
  shen_register_defun(ctx, "shen.expt", 2, &native_kl_shen_2eexpt_86);
  shen_register_defun(ctx, "shen.<float>", 1, &native_kl_shen_2e_3cfloat_3e_87);
  shen_register_defun(ctx, "shen.<stop>", 1, &native_kl_shen_2e_3cstop_3e_88);
  shen_register_defun(ctx, "shen.<fraction>", 1, &native_kl_shen_2e_3cfraction_3e_89);
  shen_register_defun(ctx, "shen.compute-fraction", 1, &native_kl_shen_2ecompute_2dfraction_90);
  shen_register_defun(ctx, "shen.compute-fraction-h", 2, &native_kl_shen_2ecompute_2dfraction_2dh_91);
  shen_register_defun(ctx, "shen.<e-number>", 1, &native_kl_shen_2e_3ce_2dnumber_3e_92);
  shen_register_defun(ctx, "shen.<log10>", 1, &native_kl_shen_2e_3clog10_3e_93);
  shen_register_defun(ctx, "shen.<lowE>", 1, &native_kl_shen_2e_3clowE_3e_94);
  shen_register_defun(ctx, "shen.compute-E", 2, &native_kl_shen_2ecompute_2dE_95);
  shen_register_defun(ctx, "shen.<whitespaces>", 1, &native_kl_shen_2e_3cwhitespaces_3e_96);
  shen_register_defun(ctx, "shen.<whitespace>", 1, &native_kl_shen_2e_3cwhitespace_3e_97);
  shen_register_defun(ctx, "shen.whitespace?", 1, &native_kl_shen_2ewhitespace_3f_98);
  shen_register_defun(ctx, "shen.unpackage&macroexpand", 1, &native_kl_shen_2eunpackage_26macroexpand_99);
  shen_register_defun(ctx, "shen.packaged?", 1, &native_kl_shen_2epackaged_3f_100);
  shen_register_defun(ctx, "shen.unpackage", 1, &native_kl_shen_2eunpackage_101);
  shen_register_defun(ctx, "shen.record-internal", 3, &native_kl_shen_2erecord_2dinternal_102);
  shen_register_defun(ctx, "shen.internal-symbols", 3, &native_kl_shen_2einternal_2dsymbols_103);
  shen_register_defun(ctx, "shen.record-external", 2, &native_kl_shen_2erecord_2dexternal_104);
  shen_register_defun(ctx, "shen.package-symbols", 3, &native_kl_shen_2epackage_2dsymbols_105);
  shen_register_defun(ctx, "shen.intern-in-package", 2, &native_kl_shen_2eintern_2din_2dpackage_106);
  shen_register_defun(ctx, "shen.internal?", 3, &native_kl_shen_2einternal_3f_107);
  shen_register_defun(ctx, "shen.internal-to-shen?", 1, &native_kl_shen_2einternal_2dto_2dshen_3f_108);
  shen_register_defun(ctx, "shen.sysfunc?", 1, &native_kl_shen_2esysfunc_3f_109);
  shen_register_defun(ctx, "shen.internal-to-P?", 2, &native_kl_shen_2einternal_2dto_2dP_3f_110);
  shen_register_defun(ctx, "shen.process-applications", 2, &native_kl_shen_2eprocess_2dapplications_111);
  shen_register_defun(ctx, "shen.non-application?", 1, &native_kl_shen_2enon_2dapplication_3f_112);
  shen_register_defun(ctx, "shen.special-case", 3, &native_kl_shen_2especial_2dcase_113);
  shen_register_defun(ctx, "shen.process-after-type", 3, &native_kl_shen_2eprocess_2dafter_2dtype_114);
  shen_register_defun(ctx, "shen.process-application", 2, &native_kl_shen_2eprocess_2dapplication_115);
  shen_register_defun(ctx, "shen.unpack-foreign", 1, &native_kl_shen_2eunpack_2dforeign_116);
  shen_register_defun(ctx, "shen.foreign?", 1, &native_kl_shen_2eforeign_3f_117);
  shen_register_defun(ctx, "shen.zero-place?", 1, &native_kl_shen_2ezero_2dplace_3f_118);
  shen_register_defun(ctx, "shen.shen-call?", 1, &native_kl_shen_2eshen_2dcall_3f_119);
  shen_register_defun(ctx, "shen.application?", 1, &native_kl_shen_2eapplication_3f_120);
  shen_register_defun(ctx, "shen.undefined-f?", 2, &native_kl_shen_2eundefined_2df_3f_121);
  shen_register_defun(ctx, "shen.lowercase-symbol?", 1, &native_kl_shen_2elowercase_2dsymbol_3f_122);
  shen_register_defun(ctx, "shen.simple-curry", 1, &native_kl_shen_2esimple_2dcurry_123);
  shen_register_defun(ctx, "function", 1, &native_kl_function_124);
  shen_register_defun(ctx, "fn", 1, &native_kl_fn_125);
  shen_register_defun(ctx, "shen.fn-call?", 1, &native_kl_shen_2efn_2dcall_3f_126);
  shen_register_defun(ctx, "shen.fn-call", 1, &native_kl_shen_2efn_2dcall_127);
  shen_register_defun(ctx, "shen.partial-application*?", 3, &native_kl_shen_2epartial_2dapplication_2a_3f_128);
  shen_register_defun(ctx, "shen.loading?", 0, &native_kl_shen_2eloading_3f_129);
  shen_register_defun(ctx, "shen.overapplication?", 3, &native_kl_shen_2eoverapplication_3f_130);
}
