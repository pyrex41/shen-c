#include "rc_phase_profile.h"
/* Generated always-AOT kernel module (KL defuns -> NativeFunctions).
 * Install after tree-walker boot overwrites UserFunctions.
 * Toplevel declare/set stay on the walker. Not overlay-after-load.
 * Sidecar tests stay on the tree-walker. Not a second main. Source: sequent.kl
 */
#include "abi.h"

void shen_kernel_aot_install_sequent (shen_context* ctx);

static KLObject* lambda_0 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t1146 = objects[0];
  KLObject* t1147;
  {
    KLObject* a1147[] = {t1146};
    t1147 = shen_tail_apply_direct(ctx, "shen.rule->clause", 1, a1147);
  }
    return t1147;
  }
}

static KLObject* lambda_1 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t2013 = objects[0];
  KLObject* t2014;
  {
    KLObject* a2014[] = {t2013};
    t2014 = shen_tail_apply_direct(ctx, "shen.intern-type", 1, a2014);
  }
    return t2014;
  }
}

static KLObject* lambda_2 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t2049 = objects[0];
  KLObject* t2051 = shen_hd(ctx, t2049);
    return t2051;
  }
}

static KLObject* lambda_3 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t2056 = objects[0];
  KLObject* t2057;
  {
    KLObject* a2057[] = {t2056};
    t2057 = shen_tail_apply_direct(ctx, "shen.intern-type", 1, a2057);
  }
    return t2057;
  }
}

static KLObject* lambda_4 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t2062 = objects[0];
  KLObject* t2065;
  {
    KLObject* a2065[] = {t2062};
    t2065 = shen_apply_direct(ctx, "fn", 1, a2065);
  }
  KLObject* t2063;
  {
    KLObject* a2063[] = {t2062, t2065};
    t2063 = shen_tail_apply_direct(ctx, "shen.remember-datatype", 2, a2063);
  }
    return t2063;
  }
}

static KLObject* lambda_5 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t2078 = objects[0];
  KLObject* t2079;
  {
    KLObject* a2079[] = {t2078};
    t2079 = shen_tail_apply_direct(ctx, "shen.intern-type", 1, a2079);
  }
    return t2079;
  }
}

static KLObject* lambda_6 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t2084 = objects[0];
  KLObject* t2087;
  {
    KLObject* a2087[] = {t2084};
    t2087 = shen_apply_direct(ctx, "fn", 1, a2087);
  }
  KLObject* t2085;
  {
    KLObject* a2085[] = {t2084, t2087};
    t2085 = shen_tail_apply_direct(ctx, "shen.remember-datatype", 2, a2085);
  }
    return t2085;
  }
}

static KLObject* lambda_7 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t2096 = objects[0];
  KLObject* t2097;
  {
    KLObject* a2097[] = {t2096};
    t2097 = shen_tail_apply_direct(ctx, "shen.intern-type", 1, a2097);
  }
    return t2097;
  }
}

static KLObject* native_kl_shen_2e_3cdatatype_3e_0 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t0 = objects[0];
  tail_start_kl_shen_2e_3cdatatype_3e_0: ;
  KLObject* t3 = shen_cons_p(ctx, t0);
  KLObject* t1;
  if (!shen_is_boolean(ctx, t3))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t3)) {
  KLObject* t4;
  {
    KLObject* a4[] = {t0};
    t4 = shen_apply_direct(ctx, "head", 1, a4);
  }
  KLObject* t6;
  {
    KLObject* a6[] = {t0};
    t6 = shen_apply_direct(ctx, "tail", 1, a6);
  }
  KLObject* t8;
  {
    KLObject* a8[] = {t6};
    t8 = shen_apply_direct(ctx, "shen.<datatype-rules>", 1, a8);
  }
  KLObject* t11;
  {
    KLObject* a11[] = {t8};
    t11 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a11);
  }
  KLObject* t10;
  if (!shen_is_boolean(ctx, t11))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t11)) {
  KLObject* t13 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t10 = t13;
  } else {
  KLObject* t14;
  {
    KLObject* a14[] = {t8};
    t14 = shen_apply_direct(ctx, "shen.<-out", 1, a14);
  }
  KLObject* t16;
  {
    KLObject* a16[] = {t8};
    t16 = shen_apply_direct(ctx, "shen.in->", 1, a16);
  }
  KLObject* t20;
  {
    KLObject* a20[] = {t4, t14};
    t20 = shen_apply_direct(ctx, "shen.rules->prolog", 2, a20);
  }
  KLObject* t25;
  {
    KLObject* a25[] = {t4};
    t25 = shen_apply_direct(ctx, "fn", 1, a25);
  }
  KLObject* t23;
  {
    KLObject* a23[] = {t4, t25};
    t23 = shen_apply_direct(ctx, "shen.remember-datatype", 2, a23);
  }
  KLObject* t18;
  {
    KLObject* a18[] = {t16, t23};
    t18 = shen_apply_direct(ctx, "shen.comb", 2, a18);
  }
    t10 = t18;
  }
    t1 = t10;
  } else {
  KLObject* t27 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t1 = t27;
  }
  KLObject* t29;
  {
    KLObject* a29[] = {t1};
    t29 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a29);
  }
  KLObject* t28;
  if (!shen_is_boolean(ctx, t29))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t29)) {
  KLObject* t31 = shen_tail_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t28 = t31;
  } else {
    t28 = t1;
  }
    return t28;
  }
}

static KLObject* native_kl_shen_2eremember_2ddatatype_1 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t33 = objects[0];
    KLObject* t34 = objects[1];
  tail_start_kl_shen_2eremember_2ddatatype_1: ;
  KLObject* t36 = shen_intern(ctx, "shen.*datatypes*");
  KLObject* t41 = shen_intern(ctx, "shen.*datatypes*");
  KLObject* t40;
  {
    KLObject* a40[] = {t41};
    t40 = shen_apply_direct(ctx, "value", 1, a40);
  }
  KLObject* t37;
  {
    KLObject* a37[] = {t33, t34, t40};
    t37 = shen_apply_direct(ctx, "shen.assoc->", 3, a37);
  }
  KLObject* t35;
  {
    KLObject* a35[] = {t36, t37};
    t35 = shen_apply_direct(ctx, "set", 2, a35);
  }
  KLObject* t43 = shen_intern(ctx, "shen.*alldatatypes*");
  KLObject* t48 = shen_intern(ctx, "shen.*alldatatypes*");
  KLObject* t47;
  {
    KLObject* a47[] = {t48};
    t47 = shen_apply_direct(ctx, "value", 1, a47);
  }
  KLObject* t44;
  {
    KLObject* a44[] = {t33, t34, t47};
    t44 = shen_apply_direct(ctx, "shen.assoc->", 3, a44);
  }
  KLObject* t42;
  {
    KLObject* a42[] = {t43, t44};
    t42 = shen_apply_direct(ctx, "set", 2, a42);
  }
    return t33;
  }
}

static KLObject* native_kl_shen_2e_3cdatatype_2drules_3e_2 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t50 = objects[0];
  tail_start_kl_shen_2e_3cdatatype_2drules_3e_2: ;
  KLObject* t51;
  {
    KLObject* a51[] = {t50};
    t51 = shen_apply_direct(ctx, "shen.<datatype-rule>", 1, a51);
  }
  KLObject* t54;
  {
    KLObject* a54[] = {t51};
    t54 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a54);
  }
  KLObject* t53;
  if (!shen_is_boolean(ctx, t54))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t54)) {
  KLObject* t56 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t53 = t56;
  } else {
  KLObject* t57;
  {
    KLObject* a57[] = {t51};
    t57 = shen_apply_direct(ctx, "shen.<-out", 1, a57);
  }
  KLObject* t59;
  {
    KLObject* a59[] = {t51};
    t59 = shen_apply_direct(ctx, "shen.in->", 1, a59);
  }
  KLObject* t61;
  {
    KLObject* a61[] = {t59};
    t61 = shen_apply_direct(ctx, "shen.<datatype-rules>", 1, a61);
  }
  KLObject* t64;
  {
    KLObject* a64[] = {t61};
    t64 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a64);
  }
  KLObject* t63;
  if (!shen_is_boolean(ctx, t64))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t64)) {
  KLObject* t66 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t63 = t66;
  } else {
  KLObject* t67;
  {
    KLObject* a67[] = {t61};
    t67 = shen_apply_direct(ctx, "shen.<-out", 1, a67);
  }
  KLObject* t69;
  {
    KLObject* a69[] = {t61};
    t69 = shen_apply_direct(ctx, "shen.in->", 1, a69);
  }
  KLObject* t73;
  {
    KLObject* a73[] = {t57, t67};
    t73 = shen_apply_direct(ctx, "append", 2, a73);
  }
  KLObject* t71;
  {
    KLObject* a71[] = {t69, t73};
    t71 = shen_apply_direct(ctx, "shen.comb", 2, a71);
  }
    t63 = t71;
  }
    t53 = t63;
  }
  KLObject* t77;
  {
    KLObject* a77[] = {t53};
    t77 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a77);
  }
  KLObject* t76;
  if (!shen_is_boolean(ctx, t77))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t77)) {
  KLObject* t79;
  {
    KLObject* a79[] = {t50};
    t79 = shen_apply_direct(ctx, "<!>", 1, a79);
  }
  KLObject* t82;
  {
    KLObject* a82[] = {t79};
    t82 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a82);
  }
  KLObject* t81;
  if (!shen_is_boolean(ctx, t82))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t82)) {
  KLObject* t84 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t81 = t84;
  } else {
  KLObject* t85;
  {
    KLObject* a85[] = {t79};
    t85 = shen_apply_direct(ctx, "shen.<-out", 1, a85);
  }
  KLObject* t87;
  {
    KLObject* a87[] = {t79};
    t87 = shen_apply_direct(ctx, "shen.in->", 1, a87);
  }
  KLObject* t92;
  {
    KLObject* a92[] = {t85};
    t92 = shen_apply_direct(ctx, "empty?", 1, a92);
  }
  KLObject* t91;
  if (!shen_is_boolean(ctx, t92))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t92)) {
  KLObject* t94 = shen_empty_list(ctx);
    t91 = t94;
  } else {
  KLObject* t97 = shen_string(ctx, "datatype syntax error here:\n ");
  KLObject* t100 = shen_string(ctx, "\n ...");
  KLObject* t101 = shen_intern(ctx, "shen.r");
  KLObject* t98;
  {
    KLObject* a98[] = {t85, t100, t101};
    t98 = shen_apply_direct(ctx, "shen.app", 3, a98);
  }
  KLObject* t96;
  {
    KLObject* a96[] = {t97, t98};
    t96 = shen_apply_direct(ctx, "cn", 2, a96);
  }
  KLObject* t95;
  {
    KLObject* a95[] = {t96};
    t95 = shen_apply_direct(ctx, "simple-error", 1, a95);
  }
    t91 = t95;
  }
  KLObject* t89;
  {
    KLObject* a89[] = {t87, t91};
    t89 = shen_apply_direct(ctx, "shen.comb", 2, a89);
  }
    t81 = t89;
  }
  KLObject* t103;
  {
    KLObject* a103[] = {t81};
    t103 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a103);
  }
  KLObject* t102;
  if (!shen_is_boolean(ctx, t103))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t103)) {
  KLObject* t105 = shen_tail_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t102 = t105;
  } else {
    t102 = t81;
  }
    t76 = t102;
  } else {
    t76 = t53;
  }
    return t76;
  }
}

static KLObject* native_kl_shen_2e_3cdatatype_2drule_3e_3 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t108 = objects[0];
  tail_start_kl_shen_2e_3cdatatype_2drule_3e_3: ;
  KLObject* t109;
  {
    KLObject* a109[] = {t108};
    t109 = shen_apply_direct(ctx, "shen.<single>", 1, a109);
  }
  KLObject* t112;
  {
    KLObject* a112[] = {t109};
    t112 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a112);
  }
  KLObject* t111;
  if (!shen_is_boolean(ctx, t112))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t112)) {
  KLObject* t114 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t111 = t114;
  } else {
  KLObject* t115;
  {
    KLObject* a115[] = {t109};
    t115 = shen_apply_direct(ctx, "shen.<-out", 1, a115);
  }
  KLObject* t117;
  {
    KLObject* a117[] = {t109};
    t117 = shen_apply_direct(ctx, "shen.in->", 1, a117);
  }
  KLObject* t119;
  {
    KLObject* a119[] = {t117, t115};
    t119 = shen_apply_direct(ctx, "shen.comb", 2, a119);
  }
    t111 = t119;
  }
  KLObject* t123;
  {
    KLObject* a123[] = {t111};
    t123 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a123);
  }
  KLObject* t122;
  if (!shen_is_boolean(ctx, t123))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t123)) {
  KLObject* t125;
  {
    KLObject* a125[] = {t108};
    t125 = shen_apply_direct(ctx, "shen.<double>", 1, a125);
  }
  KLObject* t128;
  {
    KLObject* a128[] = {t125};
    t128 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a128);
  }
  KLObject* t127;
  if (!shen_is_boolean(ctx, t128))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t128)) {
  KLObject* t130 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t127 = t130;
  } else {
  KLObject* t131;
  {
    KLObject* a131[] = {t125};
    t131 = shen_apply_direct(ctx, "shen.<-out", 1, a131);
  }
  KLObject* t133;
  {
    KLObject* a133[] = {t125};
    t133 = shen_apply_direct(ctx, "shen.in->", 1, a133);
  }
  KLObject* t135;
  {
    KLObject* a135[] = {t133, t131};
    t135 = shen_apply_direct(ctx, "shen.comb", 2, a135);
  }
    t127 = t135;
  }
  KLObject* t139;
  {
    KLObject* a139[] = {t127};
    t139 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a139);
  }
  KLObject* t138;
  if (!shen_is_boolean(ctx, t139))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t139)) {
  KLObject* t141 = shen_tail_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t138 = t141;
  } else {
    t138 = t127;
  }
    t122 = t138;
  } else {
    t122 = t111;
  }
    return t122;
  }
}

static KLObject* native_kl_shen_2e_3csingle_3e_4 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t144 = objects[0];
  tail_start_kl_shen_2e_3csingle_3e_4: ;
  KLObject* t145;
  {
    KLObject* a145[] = {t144};
    t145 = shen_apply_direct(ctx, "shen.<sides>", 1, a145);
  }
  KLObject* t148;
  {
    KLObject* a148[] = {t145};
    t148 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a148);
  }
  KLObject* t147;
  if (!shen_is_boolean(ctx, t148))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t148)) {
  KLObject* t150 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t147 = t150;
  } else {
  KLObject* t151;
  {
    KLObject* a151[] = {t145};
    t151 = shen_apply_direct(ctx, "shen.<-out", 1, a151);
  }
  KLObject* t153;
  {
    KLObject* a153[] = {t145};
    t153 = shen_apply_direct(ctx, "shen.in->", 1, a153);
  }
  KLObject* t155;
  {
    KLObject* a155[] = {t153};
    t155 = shen_apply_direct(ctx, "shen.<prems>", 1, a155);
  }
  KLObject* t158;
  {
    KLObject* a158[] = {t155};
    t158 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a158);
  }
  KLObject* t157;
  if (!shen_is_boolean(ctx, t158))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t158)) {
  KLObject* t160 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t157 = t160;
  } else {
  KLObject* t161;
  {
    KLObject* a161[] = {t155};
    t161 = shen_apply_direct(ctx, "shen.<-out", 1, a161);
  }
  KLObject* t163;
  {
    KLObject* a163[] = {t155};
    t163 = shen_apply_direct(ctx, "shen.in->", 1, a163);
  }
  KLObject* t165;
  {
    KLObject* a165[] = {t163};
    t165 = shen_apply_direct(ctx, "shen.<sng>", 1, a165);
  }
  KLObject* t168;
  {
    KLObject* a168[] = {t165};
    t168 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a168);
  }
  KLObject* t167;
  if (!shen_is_boolean(ctx, t168))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t168)) {
  KLObject* t170 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t167 = t170;
  } else {
  KLObject* t171;
  {
    KLObject* a171[] = {t165};
    t171 = shen_apply_direct(ctx, "shen.in->", 1, a171);
  }
  KLObject* t173;
  {
    KLObject* a173[] = {t171};
    t173 = shen_apply_direct(ctx, "shen.<conc>", 1, a173);
  }
  KLObject* t176;
  {
    KLObject* a176[] = {t173};
    t176 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a176);
  }
  KLObject* t175;
  if (!shen_is_boolean(ctx, t176))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t176)) {
  KLObject* t178 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t175 = t178;
  } else {
  KLObject* t179;
  {
    KLObject* a179[] = {t173};
    t179 = shen_apply_direct(ctx, "shen.<-out", 1, a179);
  }
  KLObject* t181;
  {
    KLObject* a181[] = {t173};
    t181 = shen_apply_direct(ctx, "shen.in->", 1, a181);
  }
  KLObject* t183;
  {
    KLObject* a183[] = {t181};
    t183 = shen_apply_direct(ctx, "shen.<sc>", 1, a183);
  }
  KLObject* t186;
  {
    KLObject* a186[] = {t183};
    t186 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a186);
  }
  KLObject* t185;
  if (!shen_is_boolean(ctx, t186))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t186)) {
  KLObject* t188 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t185 = t188;
  } else {
  KLObject* t189;
  {
    KLObject* a189[] = {t183};
    t189 = shen_apply_direct(ctx, "shen.in->", 1, a189);
  }
  KLObject* t196 = shen_empty_list(ctx);
  KLObject* t197 = shen_cons(ctx, t179, t196);
  KLObject* t198 = shen_cons(ctx, t161, t197);
  KLObject* t199 = shen_cons(ctx, t151, t198);
  KLObject* t200 = shen_empty_list(ctx);
  KLObject* t201 = shen_cons(ctx, t199, t200);
  KLObject* t191;
  {
    KLObject* a191[] = {t189, t201};
    t191 = shen_apply_direct(ctx, "shen.comb", 2, a191);
  }
    t185 = t191;
  }
    t175 = t185;
  }
    t167 = t175;
  }
    t157 = t167;
  }
    t147 = t157;
  }
  KLObject* t203;
  {
    KLObject* a203[] = {t147};
    t203 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a203);
  }
  KLObject* t202;
  if (!shen_is_boolean(ctx, t203))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t203)) {
  KLObject* t205 = shen_tail_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t202 = t205;
  } else {
    t202 = t147;
  }
    return t202;
  }
}

static KLObject* native_kl_shen_2e_3cdouble_3e_5 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t207 = objects[0];
  tail_start_kl_shen_2e_3cdouble_3e_5: ;
  KLObject* t208;
  {
    KLObject* a208[] = {t207};
    t208 = shen_apply_direct(ctx, "shen.<sides>", 1, a208);
  }
  KLObject* t211;
  {
    KLObject* a211[] = {t208};
    t211 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a211);
  }
  KLObject* t210;
  if (!shen_is_boolean(ctx, t211))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t211)) {
  KLObject* t213 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t210 = t213;
  } else {
  KLObject* t214;
  {
    KLObject* a214[] = {t208};
    t214 = shen_apply_direct(ctx, "shen.<-out", 1, a214);
  }
  KLObject* t216;
  {
    KLObject* a216[] = {t208};
    t216 = shen_apply_direct(ctx, "shen.in->", 1, a216);
  }
  KLObject* t218;
  {
    KLObject* a218[] = {t216};
    t218 = shen_apply_direct(ctx, "shen.<formulae>", 1, a218);
  }
  KLObject* t221;
  {
    KLObject* a221[] = {t218};
    t221 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a221);
  }
  KLObject* t220;
  if (!shen_is_boolean(ctx, t221))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t221)) {
  KLObject* t223 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t220 = t223;
  } else {
  KLObject* t224;
  {
    KLObject* a224[] = {t218};
    t224 = shen_apply_direct(ctx, "shen.<-out", 1, a224);
  }
  KLObject* t226;
  {
    KLObject* a226[] = {t218};
    t226 = shen_apply_direct(ctx, "shen.in->", 1, a226);
  }
  KLObject* t228;
  {
    KLObject* a228[] = {t226};
    t228 = shen_apply_direct(ctx, "shen.<dbl>", 1, a228);
  }
  KLObject* t231;
  {
    KLObject* a231[] = {t228};
    t231 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a231);
  }
  KLObject* t230;
  if (!shen_is_boolean(ctx, t231))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t231)) {
  KLObject* t233 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t230 = t233;
  } else {
  KLObject* t234;
  {
    KLObject* a234[] = {t228};
    t234 = shen_apply_direct(ctx, "shen.in->", 1, a234);
  }
  KLObject* t236;
  {
    KLObject* a236[] = {t234};
    t236 = shen_apply_direct(ctx, "shen.<formula>", 1, a236);
  }
  KLObject* t239;
  {
    KLObject* a239[] = {t236};
    t239 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a239);
  }
  KLObject* t238;
  if (!shen_is_boolean(ctx, t239))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t239)) {
  KLObject* t241 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t238 = t241;
  } else {
  KLObject* t242;
  {
    KLObject* a242[] = {t236};
    t242 = shen_apply_direct(ctx, "shen.<-out", 1, a242);
  }
  KLObject* t244;
  {
    KLObject* a244[] = {t236};
    t244 = shen_apply_direct(ctx, "shen.in->", 1, a244);
  }
  KLObject* t246;
  {
    KLObject* a246[] = {t244};
    t246 = shen_apply_direct(ctx, "shen.<sc>", 1, a246);
  }
  KLObject* t249;
  {
    KLObject* a249[] = {t246};
    t249 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a249);
  }
  KLObject* t248;
  if (!shen_is_boolean(ctx, t249))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t249)) {
  KLObject* t251 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t248 = t251;
  } else {
  KLObject* t252;
  {
    KLObject* a252[] = {t246};
    t252 = shen_apply_direct(ctx, "shen.in->", 1, a252);
  }
  KLObject* t259 = shen_empty_list(ctx);
  KLObject* t261 = shen_empty_list(ctx);
  KLObject* t262 = shen_cons(ctx, t242, t261);
  KLObject* t263 = shen_cons(ctx, t259, t262);
  KLObject* t256;
  {
    KLObject* a256[] = {t214, t224, t263};
    t256 = shen_apply_direct(ctx, "shen.lr-rule", 3, a256);
  }
  KLObject* t254;
  {
    KLObject* a254[] = {t252, t256};
    t254 = shen_apply_direct(ctx, "shen.comb", 2, a254);
  }
    t248 = t254;
  }
    t238 = t248;
  }
    t230 = t238;
  }
    t220 = t230;
  }
    t210 = t220;
  }
  KLObject* t265;
  {
    KLObject* a265[] = {t210};
    t265 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a265);
  }
  KLObject* t264;
  if (!shen_is_boolean(ctx, t265))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t265)) {
  KLObject* t267 = shen_tail_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t264 = t267;
  } else {
    t264 = t210;
  }
    return t264;
  }
}

static KLObject* native_kl_shen_2e_3cformulae_3e_6 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t269 = objects[0];
  tail_start_kl_shen_2e_3cformulae_3e_6: ;
  KLObject* t270;
  {
    KLObject* a270[] = {t269};
    t270 = shen_apply_direct(ctx, "shen.<formula>", 1, a270);
  }
  KLObject* t273;
  {
    KLObject* a273[] = {t270};
    t273 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a273);
  }
  KLObject* t272;
  if (!shen_is_boolean(ctx, t273))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t273)) {
  KLObject* t275 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t272 = t275;
  } else {
  KLObject* t276;
  {
    KLObject* a276[] = {t270};
    t276 = shen_apply_direct(ctx, "shen.<-out", 1, a276);
  }
  KLObject* t278;
  {
    KLObject* a278[] = {t270};
    t278 = shen_apply_direct(ctx, "shen.in->", 1, a278);
  }
  KLObject* t280;
  {
    KLObject* a280[] = {t278};
    t280 = shen_apply_direct(ctx, "shen.<sc>", 1, a280);
  }
  KLObject* t283;
  {
    KLObject* a283[] = {t280};
    t283 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a283);
  }
  KLObject* t282;
  if (!shen_is_boolean(ctx, t283))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t283)) {
  KLObject* t285 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t282 = t285;
  } else {
  KLObject* t286;
  {
    KLObject* a286[] = {t280};
    t286 = shen_apply_direct(ctx, "shen.in->", 1, a286);
  }
  KLObject* t288;
  {
    KLObject* a288[] = {t286};
    t288 = shen_apply_direct(ctx, "shen.<formulae>", 1, a288);
  }
  KLObject* t291;
  {
    KLObject* a291[] = {t288};
    t291 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a291);
  }
  KLObject* t290;
  if (!shen_is_boolean(ctx, t291))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t291)) {
  KLObject* t293 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t290 = t293;
  } else {
  KLObject* t294;
  {
    KLObject* a294[] = {t288};
    t294 = shen_apply_direct(ctx, "shen.<-out", 1, a294);
  }
  KLObject* t296;
  {
    KLObject* a296[] = {t288};
    t296 = shen_apply_direct(ctx, "shen.in->", 1, a296);
  }
  KLObject* t300 = shen_empty_list(ctx);
  KLObject* t302 = shen_empty_list(ctx);
  KLObject* t303 = shen_cons(ctx, t276, t302);
  KLObject* t304 = shen_cons(ctx, t300, t303);
  KLObject* t306 = shen_cons(ctx, t304, t294);
  KLObject* t298;
  {
    KLObject* a298[] = {t296, t306};
    t298 = shen_apply_direct(ctx, "shen.comb", 2, a298);
  }
    t290 = t298;
  }
    t282 = t290;
  }
    t272 = t282;
  }
  KLObject* t308;
  {
    KLObject* a308[] = {t272};
    t308 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a308);
  }
  KLObject* t307;
  if (!shen_is_boolean(ctx, t308))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t308)) {
  KLObject* t310;
  {
    KLObject* a310[] = {t269};
    t310 = shen_apply_direct(ctx, "shen.<formula>", 1, a310);
  }
  KLObject* t313;
  {
    KLObject* a313[] = {t310};
    t313 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a313);
  }
  KLObject* t312;
  if (!shen_is_boolean(ctx, t313))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t313)) {
  KLObject* t315 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t312 = t315;
  } else {
  KLObject* t316;
  {
    KLObject* a316[] = {t310};
    t316 = shen_apply_direct(ctx, "shen.<-out", 1, a316);
  }
  KLObject* t318;
  {
    KLObject* a318[] = {t310};
    t318 = shen_apply_direct(ctx, "shen.in->", 1, a318);
  }
  KLObject* t320;
  {
    KLObject* a320[] = {t318};
    t320 = shen_apply_direct(ctx, "shen.<sc>", 1, a320);
  }
  KLObject* t323;
  {
    KLObject* a323[] = {t320};
    t323 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a323);
  }
  KLObject* t322;
  if (!shen_is_boolean(ctx, t323))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t323)) {
  KLObject* t325 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t322 = t325;
  } else {
  KLObject* t326;
  {
    KLObject* a326[] = {t320};
    t326 = shen_apply_direct(ctx, "shen.in->", 1, a326);
  }
  KLObject* t330 = shen_empty_list(ctx);
  KLObject* t332 = shen_empty_list(ctx);
  KLObject* t333 = shen_cons(ctx, t316, t332);
  KLObject* t334 = shen_cons(ctx, t330, t333);
  KLObject* t335 = shen_empty_list(ctx);
  KLObject* t336 = shen_cons(ctx, t334, t335);
  KLObject* t328;
  {
    KLObject* a328[] = {t326, t336};
    t328 = shen_apply_direct(ctx, "shen.comb", 2, a328);
  }
    t322 = t328;
  }
    t312 = t322;
  }
  KLObject* t338;
  {
    KLObject* a338[] = {t312};
    t338 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a338);
  }
  KLObject* t337;
  if (!shen_is_boolean(ctx, t338))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t338)) {
  KLObject* t340 = shen_tail_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t337 = t340;
  } else {
    t337 = t312;
  }
    t307 = t337;
  } else {
    t307 = t272;
  }
    return t307;
  }
}

static KLObject* native_kl_shen_2e_3cconc_3e_7 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t343 = objects[0];
  tail_start_kl_shen_2e_3cconc_3e_7: ;
  KLObject* t344;
  {
    KLObject* a344[] = {t343};
    t344 = shen_apply_direct(ctx, "shen.<ass>", 1, a344);
  }
  KLObject* t347;
  {
    KLObject* a347[] = {t344};
    t347 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a347);
  }
  KLObject* t346;
  if (!shen_is_boolean(ctx, t347))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t347)) {
  KLObject* t349 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t346 = t349;
  } else {
  KLObject* t350;
  {
    KLObject* a350[] = {t344};
    t350 = shen_apply_direct(ctx, "shen.<-out", 1, a350);
  }
  KLObject* t352;
  {
    KLObject* a352[] = {t344};
    t352 = shen_apply_direct(ctx, "shen.in->", 1, a352);
  }
  KLObject* t357 = shen_intern(ctx, ">>");
  KLObject* t355;
  {
    KLObject* a355[] = {t352, t357};
    t355 = shen_apply_direct(ctx, "shen.hds=?", 2, a355);
  }
  KLObject* t354;
  if (!shen_is_boolean(ctx, t355))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t355)) {
  KLObject* t358;
  {
    KLObject* a358[] = {t352};
    t358 = shen_apply_direct(ctx, "tail", 1, a358);
  }
  KLObject* t360;
  {
    KLObject* a360[] = {t358};
    t360 = shen_apply_direct(ctx, "shen.<formula>", 1, a360);
  }
  KLObject* t363;
  {
    KLObject* a363[] = {t360};
    t363 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a363);
  }
  KLObject* t362;
  if (!shen_is_boolean(ctx, t363))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t363)) {
  KLObject* t365 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t362 = t365;
  } else {
  KLObject* t366;
  {
    KLObject* a366[] = {t360};
    t366 = shen_apply_direct(ctx, "shen.<-out", 1, a366);
  }
  KLObject* t368;
  {
    KLObject* a368[] = {t360};
    t368 = shen_apply_direct(ctx, "shen.in->", 1, a368);
  }
  KLObject* t374 = shen_empty_list(ctx);
  KLObject* t375 = shen_cons(ctx, t366, t374);
  KLObject* t376 = shen_cons(ctx, t350, t375);
  KLObject* t370;
  {
    KLObject* a370[] = {t368, t376};
    t370 = shen_apply_direct(ctx, "shen.comb", 2, a370);
  }
    t362 = t370;
  }
    t354 = t362;
  } else {
  KLObject* t377 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t354 = t377;
  }
    t346 = t354;
  }
  KLObject* t379;
  {
    KLObject* a379[] = {t346};
    t379 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a379);
  }
  KLObject* t378;
  if (!shen_is_boolean(ctx, t379))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t379)) {
  KLObject* t381;
  {
    KLObject* a381[] = {t343};
    t381 = shen_apply_direct(ctx, "shen.<formula>", 1, a381);
  }
  KLObject* t384;
  {
    KLObject* a384[] = {t381};
    t384 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a384);
  }
  KLObject* t383;
  if (!shen_is_boolean(ctx, t384))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t384)) {
  KLObject* t386 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t383 = t386;
  } else {
  KLObject* t387;
  {
    KLObject* a387[] = {t381};
    t387 = shen_apply_direct(ctx, "shen.<-out", 1, a387);
  }
  KLObject* t389;
  {
    KLObject* a389[] = {t381};
    t389 = shen_apply_direct(ctx, "shen.in->", 1, a389);
  }
  KLObject* t393 = shen_empty_list(ctx);
  KLObject* t395 = shen_empty_list(ctx);
  KLObject* t396 = shen_cons(ctx, t387, t395);
  KLObject* t397 = shen_cons(ctx, t393, t396);
  KLObject* t391;
  {
    KLObject* a391[] = {t389, t397};
    t391 = shen_apply_direct(ctx, "shen.comb", 2, a391);
  }
    t383 = t391;
  }
  KLObject* t399;
  {
    KLObject* a399[] = {t383};
    t399 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a399);
  }
  KLObject* t398;
  if (!shen_is_boolean(ctx, t399))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t399)) {
  KLObject* t401 = shen_tail_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t398 = t401;
  } else {
    t398 = t383;
  }
    t378 = t398;
  } else {
    t378 = t346;
  }
    return t378;
  }
}

static KLObject* native_kl_shen_2e_3cprems_3e_8 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t404 = objects[0];
  tail_start_kl_shen_2e_3cprems_3e_8: ;
  KLObject* t405;
  {
    KLObject* a405[] = {t404};
    t405 = shen_apply_direct(ctx, "shen.<prem>", 1, a405);
  }
  KLObject* t408;
  {
    KLObject* a408[] = {t405};
    t408 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a408);
  }
  KLObject* t407;
  if (!shen_is_boolean(ctx, t408))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t408)) {
  KLObject* t410 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t407 = t410;
  } else {
  KLObject* t411;
  {
    KLObject* a411[] = {t405};
    t411 = shen_apply_direct(ctx, "shen.<-out", 1, a411);
  }
  KLObject* t413;
  {
    KLObject* a413[] = {t405};
    t413 = shen_apply_direct(ctx, "shen.in->", 1, a413);
  }
  KLObject* t415;
  {
    KLObject* a415[] = {t413};
    t415 = shen_apply_direct(ctx, "shen.<sc>", 1, a415);
  }
  KLObject* t418;
  {
    KLObject* a418[] = {t415};
    t418 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a418);
  }
  KLObject* t417;
  if (!shen_is_boolean(ctx, t418))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t418)) {
  KLObject* t420 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t417 = t420;
  } else {
  KLObject* t421;
  {
    KLObject* a421[] = {t415};
    t421 = shen_apply_direct(ctx, "shen.in->", 1, a421);
  }
  KLObject* t423;
  {
    KLObject* a423[] = {t421};
    t423 = shen_apply_direct(ctx, "shen.<prems>", 1, a423);
  }
  KLObject* t426;
  {
    KLObject* a426[] = {t423};
    t426 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a426);
  }
  KLObject* t425;
  if (!shen_is_boolean(ctx, t426))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t426)) {
  KLObject* t428 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t425 = t428;
  } else {
  KLObject* t429;
  {
    KLObject* a429[] = {t423};
    t429 = shen_apply_direct(ctx, "shen.<-out", 1, a429);
  }
  KLObject* t431;
  {
    KLObject* a431[] = {t423};
    t431 = shen_apply_direct(ctx, "shen.in->", 1, a431);
  }
  KLObject* t437 = shen_cons(ctx, t411, t429);
  KLObject* t433;
  {
    KLObject* a433[] = {t431, t437};
    t433 = shen_apply_direct(ctx, "shen.comb", 2, a433);
  }
    t425 = t433;
  }
    t417 = t425;
  }
    t407 = t417;
  }
  KLObject* t439;
  {
    KLObject* a439[] = {t407};
    t439 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a439);
  }
  KLObject* t438;
  if (!shen_is_boolean(ctx, t439))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t439)) {
  KLObject* t441;
  {
    KLObject* a441[] = {t404};
    t441 = shen_apply_direct(ctx, "<e>", 1, a441);
  }
  KLObject* t444;
  {
    KLObject* a444[] = {t441};
    t444 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a444);
  }
  KLObject* t443;
  if (!shen_is_boolean(ctx, t444))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t444)) {
  KLObject* t446 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t443 = t446;
  } else {
  KLObject* t447;
  {
    KLObject* a447[] = {t441};
    t447 = shen_apply_direct(ctx, "shen.in->", 1, a447);
  }
  KLObject* t451 = shen_empty_list(ctx);
  KLObject* t449;
  {
    KLObject* a449[] = {t447, t451};
    t449 = shen_apply_direct(ctx, "shen.comb", 2, a449);
  }
    t443 = t449;
  }
  KLObject* t453;
  {
    KLObject* a453[] = {t443};
    t453 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a453);
  }
  KLObject* t452;
  if (!shen_is_boolean(ctx, t453))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t453)) {
  KLObject* t455 = shen_tail_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t452 = t455;
  } else {
    t452 = t443;
  }
    t438 = t452;
  } else {
    t438 = t407;
  }
    return t438;
  }
}

static KLObject* native_kl_shen_2e_3cprem_3e_9 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t458 = objects[0];
  tail_start_kl_shen_2e_3cprem_3e_9: ;
  KLObject* t462 = shen_intern(ctx, "!");
  KLObject* t460;
  {
    KLObject* a460[] = {t458, t462};
    t460 = shen_apply_direct(ctx, "shen.hds=?", 2, a460);
  }
  KLObject* t459;
  if (!shen_is_boolean(ctx, t460))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t460)) {
  KLObject* t463;
  {
    KLObject* a463[] = {t458};
    t463 = shen_apply_direct(ctx, "tail", 1, a463);
  }
  KLObject* t467 = shen_intern(ctx, "!");
  KLObject* t465;
  {
    KLObject* a465[] = {t463, t467};
    t465 = shen_apply_direct(ctx, "shen.comb", 2, a465);
  }
    t459 = t465;
  } else {
  KLObject* t468 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t459 = t468;
  }
  KLObject* t470;
  {
    KLObject* a470[] = {t459};
    t470 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a470);
  }
  KLObject* t469;
  if (!shen_is_boolean(ctx, t470))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t470)) {
  KLObject* t472;
  {
    KLObject* a472[] = {t458};
    t472 = shen_apply_direct(ctx, "shen.<ass>", 1, a472);
  }
  KLObject* t475;
  {
    KLObject* a475[] = {t472};
    t475 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a475);
  }
  KLObject* t474;
  if (!shen_is_boolean(ctx, t475))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t475)) {
  KLObject* t477 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t474 = t477;
  } else {
  KLObject* t478;
  {
    KLObject* a478[] = {t472};
    t478 = shen_apply_direct(ctx, "shen.<-out", 1, a478);
  }
  KLObject* t480;
  {
    KLObject* a480[] = {t472};
    t480 = shen_apply_direct(ctx, "shen.in->", 1, a480);
  }
  KLObject* t485 = shen_intern(ctx, ">>");
  KLObject* t483;
  {
    KLObject* a483[] = {t480, t485};
    t483 = shen_apply_direct(ctx, "shen.hds=?", 2, a483);
  }
  KLObject* t482;
  if (!shen_is_boolean(ctx, t483))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t483)) {
  KLObject* t486;
  {
    KLObject* a486[] = {t480};
    t486 = shen_apply_direct(ctx, "tail", 1, a486);
  }
  KLObject* t488;
  {
    KLObject* a488[] = {t486};
    t488 = shen_apply_direct(ctx, "shen.<formula>", 1, a488);
  }
  KLObject* t491;
  {
    KLObject* a491[] = {t488};
    t491 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a491);
  }
  KLObject* t490;
  if (!shen_is_boolean(ctx, t491))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t491)) {
  KLObject* t493 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t490 = t493;
  } else {
  KLObject* t494;
  {
    KLObject* a494[] = {t488};
    t494 = shen_apply_direct(ctx, "shen.<-out", 1, a494);
  }
  KLObject* t496;
  {
    KLObject* a496[] = {t488};
    t496 = shen_apply_direct(ctx, "shen.in->", 1, a496);
  }
  KLObject* t502 = shen_empty_list(ctx);
  KLObject* t503 = shen_cons(ctx, t494, t502);
  KLObject* t504 = shen_cons(ctx, t478, t503);
  KLObject* t498;
  {
    KLObject* a498[] = {t496, t504};
    t498 = shen_apply_direct(ctx, "shen.comb", 2, a498);
  }
    t490 = t498;
  }
    t482 = t490;
  } else {
  KLObject* t505 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t482 = t505;
  }
    t474 = t482;
  }
  KLObject* t507;
  {
    KLObject* a507[] = {t474};
    t507 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a507);
  }
  KLObject* t506;
  if (!shen_is_boolean(ctx, t507))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t507)) {
  KLObject* t509;
  {
    KLObject* a509[] = {t458};
    t509 = shen_apply_direct(ctx, "shen.<formula>", 1, a509);
  }
  KLObject* t512;
  {
    KLObject* a512[] = {t509};
    t512 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a512);
  }
  KLObject* t511;
  if (!shen_is_boolean(ctx, t512))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t512)) {
  KLObject* t514 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t511 = t514;
  } else {
  KLObject* t515;
  {
    KLObject* a515[] = {t509};
    t515 = shen_apply_direct(ctx, "shen.<-out", 1, a515);
  }
  KLObject* t517;
  {
    KLObject* a517[] = {t509};
    t517 = shen_apply_direct(ctx, "shen.in->", 1, a517);
  }
  KLObject* t521 = shen_empty_list(ctx);
  KLObject* t523 = shen_empty_list(ctx);
  KLObject* t524 = shen_cons(ctx, t515, t523);
  KLObject* t525 = shen_cons(ctx, t521, t524);
  KLObject* t519;
  {
    KLObject* a519[] = {t517, t525};
    t519 = shen_apply_direct(ctx, "shen.comb", 2, a519);
  }
    t511 = t519;
  }
  KLObject* t527;
  {
    KLObject* a527[] = {t511};
    t527 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a527);
  }
  KLObject* t526;
  if (!shen_is_boolean(ctx, t527))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t527)) {
  KLObject* t529 = shen_tail_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t526 = t529;
  } else {
    t526 = t511;
  }
    t506 = t526;
  } else {
    t506 = t474;
  }
    t469 = t506;
  } else {
    t469 = t459;
  }
    return t469;
  }
}

static KLObject* native_kl_shen_2e_3cass_3e_10 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t533 = objects[0];
  tail_start_kl_shen_2e_3cass_3e_10: ;
  KLObject* t534;
  {
    KLObject* a534[] = {t533};
    t534 = shen_apply_direct(ctx, "shen.<formula>", 1, a534);
  }
  KLObject* t537;
  {
    KLObject* a537[] = {t534};
    t537 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a537);
  }
  KLObject* t536;
  if (!shen_is_boolean(ctx, t537))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t537)) {
  KLObject* t539 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t536 = t539;
  } else {
  KLObject* t540;
  {
    KLObject* a540[] = {t534};
    t540 = shen_apply_direct(ctx, "shen.<-out", 1, a540);
  }
  KLObject* t542;
  {
    KLObject* a542[] = {t534};
    t542 = shen_apply_direct(ctx, "shen.in->", 1, a542);
  }
  KLObject* t544;
  {
    KLObject* a544[] = {t542};
    t544 = shen_apply_direct(ctx, "shen.<iscomma>", 1, a544);
  }
  KLObject* t547;
  {
    KLObject* a547[] = {t544};
    t547 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a547);
  }
  KLObject* t546;
  if (!shen_is_boolean(ctx, t547))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t547)) {
  KLObject* t549 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t546 = t549;
  } else {
  KLObject* t550;
  {
    KLObject* a550[] = {t544};
    t550 = shen_apply_direct(ctx, "shen.in->", 1, a550);
  }
  KLObject* t552;
  {
    KLObject* a552[] = {t550};
    t552 = shen_apply_direct(ctx, "shen.<ass>", 1, a552);
  }
  KLObject* t555;
  {
    KLObject* a555[] = {t552};
    t555 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a555);
  }
  KLObject* t554;
  if (!shen_is_boolean(ctx, t555))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t555)) {
  KLObject* t557 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t554 = t557;
  } else {
  KLObject* t558;
  {
    KLObject* a558[] = {t552};
    t558 = shen_apply_direct(ctx, "shen.<-out", 1, a558);
  }
  KLObject* t560;
  {
    KLObject* a560[] = {t552};
    t560 = shen_apply_direct(ctx, "shen.in->", 1, a560);
  }
  KLObject* t566 = shen_cons(ctx, t540, t558);
  KLObject* t562;
  {
    KLObject* a562[] = {t560, t566};
    t562 = shen_apply_direct(ctx, "shen.comb", 2, a562);
  }
    t554 = t562;
  }
    t546 = t554;
  }
    t536 = t546;
  }
  KLObject* t568;
  {
    KLObject* a568[] = {t536};
    t568 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a568);
  }
  KLObject* t567;
  if (!shen_is_boolean(ctx, t568))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t568)) {
  KLObject* t570;
  {
    KLObject* a570[] = {t533};
    t570 = shen_apply_direct(ctx, "shen.<formula>", 1, a570);
  }
  KLObject* t573;
  {
    KLObject* a573[] = {t570};
    t573 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a573);
  }
  KLObject* t572;
  if (!shen_is_boolean(ctx, t573))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t573)) {
  KLObject* t575 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t572 = t575;
  } else {
  KLObject* t576;
  {
    KLObject* a576[] = {t570};
    t576 = shen_apply_direct(ctx, "shen.<-out", 1, a576);
  }
  KLObject* t578;
  {
    KLObject* a578[] = {t570};
    t578 = shen_apply_direct(ctx, "shen.in->", 1, a578);
  }
  KLObject* t583 = shen_empty_list(ctx);
  KLObject* t584 = shen_cons(ctx, t576, t583);
  KLObject* t580;
  {
    KLObject* a580[] = {t578, t584};
    t580 = shen_apply_direct(ctx, "shen.comb", 2, a580);
  }
    t572 = t580;
  }
  KLObject* t586;
  {
    KLObject* a586[] = {t572};
    t586 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a586);
  }
  KLObject* t585;
  if (!shen_is_boolean(ctx, t586))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t586)) {
  KLObject* t588;
  {
    KLObject* a588[] = {t533};
    t588 = shen_apply_direct(ctx, "<e>", 1, a588);
  }
  KLObject* t591;
  {
    KLObject* a591[] = {t588};
    t591 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a591);
  }
  KLObject* t590;
  if (!shen_is_boolean(ctx, t591))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t591)) {
  KLObject* t593 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t590 = t593;
  } else {
  KLObject* t594;
  {
    KLObject* a594[] = {t588};
    t594 = shen_apply_direct(ctx, "shen.in->", 1, a594);
  }
  KLObject* t598 = shen_empty_list(ctx);
  KLObject* t596;
  {
    KLObject* a596[] = {t594, t598};
    t596 = shen_apply_direct(ctx, "shen.comb", 2, a596);
  }
    t590 = t596;
  }
  KLObject* t600;
  {
    KLObject* a600[] = {t590};
    t600 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a600);
  }
  KLObject* t599;
  if (!shen_is_boolean(ctx, t600))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t600)) {
  KLObject* t602 = shen_tail_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t599 = t602;
  } else {
    t599 = t590;
  }
    t585 = t599;
  } else {
    t585 = t572;
  }
    t567 = t585;
  } else {
    t567 = t536;
  }
    return t567;
  }
}

static KLObject* native_kl_shen_2e_3ciscomma_3e_11 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t606 = objects[0];
  tail_start_kl_shen_2e_3ciscomma_3e_11: ;
  KLObject* t609 = shen_cons_p(ctx, t606);
  KLObject* t607;
  if (!shen_is_boolean(ctx, t609))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t609)) {
  KLObject* t610;
  {
    KLObject* a610[] = {t606};
    t610 = shen_apply_direct(ctx, "head", 1, a610);
  }
  KLObject* t612;
  {
    KLObject* a612[] = {t606};
    t612 = shen_apply_direct(ctx, "tail", 1, a612);
  }
  KLObject* t617 = shen_string(ctx, ",");
  KLObject* t616;
  {
    KLObject* a616[] = {t617};
    t616 = shen_apply_direct(ctx, "intern", 1, a616);
  }
  KLObject* t618 = shen_eq(ctx, t610, t616);
  KLObject* t614;
  if (!shen_is_boolean(ctx, t618))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t618)) {
  KLObject* t621 = shen_intern(ctx, "shen.skip");
  KLObject* t619;
  {
    KLObject* a619[] = {t612, t621};
    t619 = shen_apply_direct(ctx, "shen.comb", 2, a619);
  }
    t614 = t619;
  } else {
  KLObject* t622 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t614 = t622;
  }
    t607 = t614;
  } else {
  KLObject* t623 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t607 = t623;
  }
  KLObject* t625;
  {
    KLObject* a625[] = {t607};
    t625 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a625);
  }
  KLObject* t624;
  if (!shen_is_boolean(ctx, t625))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t625)) {
  KLObject* t627 = shen_tail_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t624 = t627;
  } else {
    t624 = t607;
  }
    return t624;
  }
}

static KLObject* native_kl_shen_2e_3cformula_3e_12 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t629 = objects[0];
  tail_start_kl_shen_2e_3cformula_3e_12: ;
  KLObject* t630;
  {
    KLObject* a630[] = {t629};
    t630 = shen_apply_direct(ctx, "shen.<expr>", 1, a630);
  }
  KLObject* t633;
  {
    KLObject* a633[] = {t630};
    t633 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a633);
  }
  KLObject* t632;
  if (!shen_is_boolean(ctx, t633))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t633)) {
  KLObject* t635 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t632 = t635;
  } else {
  KLObject* t636;
  {
    KLObject* a636[] = {t630};
    t636 = shen_apply_direct(ctx, "shen.<-out", 1, a636);
  }
  KLObject* t638;
  {
    KLObject* a638[] = {t630};
    t638 = shen_apply_direct(ctx, "shen.in->", 1, a638);
  }
  KLObject* t640;
  {
    KLObject* a640[] = {t638};
    t640 = shen_apply_direct(ctx, "shen.<iscolon>", 1, a640);
  }
  KLObject* t643;
  {
    KLObject* a643[] = {t640};
    t643 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a643);
  }
  KLObject* t642;
  if (!shen_is_boolean(ctx, t643))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t643)) {
  KLObject* t645 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t642 = t645;
  } else {
  KLObject* t646;
  {
    KLObject* a646[] = {t640};
    t646 = shen_apply_direct(ctx, "shen.in->", 1, a646);
  }
  KLObject* t648;
  {
    KLObject* a648[] = {t646};
    t648 = shen_apply_direct(ctx, "shen.<type>", 1, a648);
  }
  KLObject* t651;
  {
    KLObject* a651[] = {t648};
    t651 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a651);
  }
  KLObject* t650;
  if (!shen_is_boolean(ctx, t651))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t651)) {
  KLObject* t653 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t650 = t653;
  } else {
  KLObject* t654;
  {
    KLObject* a654[] = {t648};
    t654 = shen_apply_direct(ctx, "shen.<-out", 1, a654);
  }
  KLObject* t656;
  {
    KLObject* a656[] = {t648};
    t656 = shen_apply_direct(ctx, "shen.in->", 1, a656);
  }
  KLObject* t660;
  {
    KLObject* a660[] = {t636};
    t660 = shen_apply_direct(ctx, "shen.curry", 1, a660);
  }
  KLObject* t663 = shen_string(ctx, ":");
  KLObject* t662;
  {
    KLObject* a662[] = {t663};
    t662 = shen_apply_direct(ctx, "intern", 1, a662);
  }
  KLObject* t664;
  {
    KLObject* a664[] = {t654};
    t664 = shen_apply_direct(ctx, "shen.rectify-type", 1, a664);
  }
  KLObject* t666 = shen_empty_list(ctx);
  KLObject* t667 = shen_cons(ctx, t664, t666);
  KLObject* t668 = shen_cons(ctx, t662, t667);
  KLObject* t669 = shen_cons(ctx, t660, t668);
  KLObject* t658;
  {
    KLObject* a658[] = {t656, t669};
    t658 = shen_apply_direct(ctx, "shen.comb", 2, a658);
  }
    t650 = t658;
  }
    t642 = t650;
  }
    t632 = t642;
  }
  KLObject* t671;
  {
    KLObject* a671[] = {t632};
    t671 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a671);
  }
  KLObject* t670;
  if (!shen_is_boolean(ctx, t671))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t671)) {
  KLObject* t673;
  {
    KLObject* a673[] = {t629};
    t673 = shen_apply_direct(ctx, "shen.<expr>", 1, a673);
  }
  KLObject* t676;
  {
    KLObject* a676[] = {t673};
    t676 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a676);
  }
  KLObject* t675;
  if (!shen_is_boolean(ctx, t676))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t676)) {
  KLObject* t678 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t675 = t678;
  } else {
  KLObject* t679;
  {
    KLObject* a679[] = {t673};
    t679 = shen_apply_direct(ctx, "shen.<-out", 1, a679);
  }
  KLObject* t681;
  {
    KLObject* a681[] = {t673};
    t681 = shen_apply_direct(ctx, "shen.in->", 1, a681);
  }
  KLObject* t683;
  {
    KLObject* a683[] = {t681, t679};
    t683 = shen_apply_direct(ctx, "shen.comb", 2, a683);
  }
    t675 = t683;
  }
  KLObject* t687;
  {
    KLObject* a687[] = {t675};
    t687 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a687);
  }
  KLObject* t686;
  if (!shen_is_boolean(ctx, t687))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t687)) {
  KLObject* t689 = shen_tail_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t686 = t689;
  } else {
    t686 = t675;
  }
    t670 = t686;
  } else {
    t670 = t632;
  }
    return t670;
  }
}

static KLObject* native_kl_shen_2e_3ciscolon_3e_13 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t692 = objects[0];
  tail_start_kl_shen_2e_3ciscolon_3e_13: ;
  KLObject* t695 = shen_cons_p(ctx, t692);
  KLObject* t693;
  if (!shen_is_boolean(ctx, t695))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t695)) {
  KLObject* t696;
  {
    KLObject* a696[] = {t692};
    t696 = shen_apply_direct(ctx, "head", 1, a696);
  }
  KLObject* t698;
  {
    KLObject* a698[] = {t692};
    t698 = shen_apply_direct(ctx, "tail", 1, a698);
  }
  KLObject* t703 = shen_string(ctx, ":");
  KLObject* t702;
  {
    KLObject* a702[] = {t703};
    t702 = shen_apply_direct(ctx, "intern", 1, a702);
  }
  KLObject* t704 = shen_eq(ctx, t696, t702);
  KLObject* t700;
  if (!shen_is_boolean(ctx, t704))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t704)) {
  KLObject* t707 = shen_intern(ctx, "shen.skip");
  KLObject* t705;
  {
    KLObject* a705[] = {t698, t707};
    t705 = shen_apply_direct(ctx, "shen.comb", 2, a705);
  }
    t700 = t705;
  } else {
  KLObject* t708 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t700 = t708;
  }
    t693 = t700;
  } else {
  KLObject* t709 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t693 = t709;
  }
  KLObject* t711;
  {
    KLObject* a711[] = {t693};
    t711 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a711);
  }
  KLObject* t710;
  if (!shen_is_boolean(ctx, t711))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t711)) {
  KLObject* t713 = shen_tail_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t710 = t713;
  } else {
    t710 = t693;
  }
    return t710;
  }
}

static KLObject* native_kl_shen_2e_3csides_3e_14 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t715 = objects[0];
  tail_start_kl_shen_2e_3csides_3e_14: ;
  KLObject* t716;
  {
    KLObject* a716[] = {t715};
    t716 = shen_apply_direct(ctx, "shen.<side>", 1, a716);
  }
  KLObject* t719;
  {
    KLObject* a719[] = {t716};
    t719 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a719);
  }
  KLObject* t718;
  if (!shen_is_boolean(ctx, t719))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t719)) {
  KLObject* t721 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t718 = t721;
  } else {
  KLObject* t722;
  {
    KLObject* a722[] = {t716};
    t722 = shen_apply_direct(ctx, "shen.<-out", 1, a722);
  }
  KLObject* t724;
  {
    KLObject* a724[] = {t716};
    t724 = shen_apply_direct(ctx, "shen.in->", 1, a724);
  }
  KLObject* t726;
  {
    KLObject* a726[] = {t724};
    t726 = shen_apply_direct(ctx, "shen.<sides>", 1, a726);
  }
  KLObject* t729;
  {
    KLObject* a729[] = {t726};
    t729 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a729);
  }
  KLObject* t728;
  if (!shen_is_boolean(ctx, t729))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t729)) {
  KLObject* t731 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t728 = t731;
  } else {
  KLObject* t732;
  {
    KLObject* a732[] = {t726};
    t732 = shen_apply_direct(ctx, "shen.<-out", 1, a732);
  }
  KLObject* t734;
  {
    KLObject* a734[] = {t726};
    t734 = shen_apply_direct(ctx, "shen.in->", 1, a734);
  }
  KLObject* t740 = shen_cons(ctx, t722, t732);
  KLObject* t736;
  {
    KLObject* a736[] = {t734, t740};
    t736 = shen_apply_direct(ctx, "shen.comb", 2, a736);
  }
    t728 = t736;
  }
    t718 = t728;
  }
  KLObject* t742;
  {
    KLObject* a742[] = {t718};
    t742 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a742);
  }
  KLObject* t741;
  if (!shen_is_boolean(ctx, t742))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t742)) {
  KLObject* t744;
  {
    KLObject* a744[] = {t715};
    t744 = shen_apply_direct(ctx, "<e>", 1, a744);
  }
  KLObject* t747;
  {
    KLObject* a747[] = {t744};
    t747 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a747);
  }
  KLObject* t746;
  if (!shen_is_boolean(ctx, t747))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t747)) {
  KLObject* t749 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t746 = t749;
  } else {
  KLObject* t750;
  {
    KLObject* a750[] = {t744};
    t750 = shen_apply_direct(ctx, "shen.in->", 1, a750);
  }
  KLObject* t754 = shen_empty_list(ctx);
  KLObject* t752;
  {
    KLObject* a752[] = {t750, t754};
    t752 = shen_apply_direct(ctx, "shen.comb", 2, a752);
  }
    t746 = t752;
  }
  KLObject* t756;
  {
    KLObject* a756[] = {t746};
    t756 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a756);
  }
  KLObject* t755;
  if (!shen_is_boolean(ctx, t756))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t756)) {
  KLObject* t758 = shen_tail_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t755 = t758;
  } else {
    t755 = t746;
  }
    t741 = t755;
  } else {
    t741 = t718;
  }
    return t741;
  }
}

static KLObject* native_kl_shen_2e_3cside_3e_15 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t761 = objects[0];
  tail_start_kl_shen_2e_3cside_3e_15: ;
  KLObject* t765 = shen_intern(ctx, "if");
  KLObject* t763;
  {
    KLObject* a763[] = {t761, t765};
    t763 = shen_apply_direct(ctx, "shen.hds=?", 2, a763);
  }
  KLObject* t762;
  if (!shen_is_boolean(ctx, t763))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t763)) {
  KLObject* t766;
  {
    KLObject* a766[] = {t761};
    t766 = shen_apply_direct(ctx, "tail", 1, a766);
  }
  KLObject* t770 = shen_cons_p(ctx, t766);
  KLObject* t768;
  if (!shen_is_boolean(ctx, t770))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t770)) {
  KLObject* t771;
  {
    KLObject* a771[] = {t766};
    t771 = shen_apply_direct(ctx, "head", 1, a771);
  }
  KLObject* t773;
  {
    KLObject* a773[] = {t766};
    t773 = shen_apply_direct(ctx, "tail", 1, a773);
  }
  KLObject* t777 = shen_intern(ctx, "if");
  KLObject* t779 = shen_empty_list(ctx);
  KLObject* t780 = shen_cons(ctx, t771, t779);
  KLObject* t781 = shen_cons(ctx, t777, t780);
  KLObject* t775;
  {
    KLObject* a775[] = {t773, t781};
    t775 = shen_apply_direct(ctx, "shen.comb", 2, a775);
  }
    t768 = t775;
  } else {
  KLObject* t782 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t768 = t782;
  }
    t762 = t768;
  } else {
  KLObject* t783 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t762 = t783;
  }
  KLObject* t785;
  {
    KLObject* a785[] = {t762};
    t785 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a785);
  }
  KLObject* t784;
  if (!shen_is_boolean(ctx, t785))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t785)) {
  KLObject* t790 = shen_intern(ctx, "let");
  KLObject* t788;
  {
    KLObject* a788[] = {t761, t790};
    t788 = shen_apply_direct(ctx, "shen.hds=?", 2, a788);
  }
  KLObject* t787;
  if (!shen_is_boolean(ctx, t788))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t788)) {
  KLObject* t791;
  {
    KLObject* a791[] = {t761};
    t791 = shen_apply_direct(ctx, "tail", 1, a791);
  }
  KLObject* t795 = shen_cons_p(ctx, t791);
  KLObject* t793;
  if (!shen_is_boolean(ctx, t795))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t795)) {
  KLObject* t796;
  {
    KLObject* a796[] = {t791};
    t796 = shen_apply_direct(ctx, "head", 1, a796);
  }
  KLObject* t798;
  {
    KLObject* a798[] = {t791};
    t798 = shen_apply_direct(ctx, "tail", 1, a798);
  }
  KLObject* t802 = shen_cons_p(ctx, t798);
  KLObject* t800;
  if (!shen_is_boolean(ctx, t802))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t802)) {
  KLObject* t803;
  {
    KLObject* a803[] = {t798};
    t803 = shen_apply_direct(ctx, "head", 1, a803);
  }
  KLObject* t805;
  {
    KLObject* a805[] = {t798};
    t805 = shen_apply_direct(ctx, "tail", 1, a805);
  }
  KLObject* t809 = shen_intern(ctx, "let");
  KLObject* t812 = shen_empty_list(ctx);
  KLObject* t813 = shen_cons(ctx, t803, t812);
  KLObject* t814 = shen_cons(ctx, t796, t813);
  KLObject* t815 = shen_cons(ctx, t809, t814);
  KLObject* t807;
  {
    KLObject* a807[] = {t805, t815};
    t807 = shen_apply_direct(ctx, "shen.comb", 2, a807);
  }
    t800 = t807;
  } else {
  KLObject* t816 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t800 = t816;
  }
    t793 = t800;
  } else {
  KLObject* t817 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t793 = t817;
  }
    t787 = t793;
  } else {
  KLObject* t818 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t787 = t818;
  }
  KLObject* t820;
  {
    KLObject* a820[] = {t787};
    t820 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a820);
  }
  KLObject* t819;
  if (!shen_is_boolean(ctx, t820))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t820)) {
  KLObject* t825 = shen_intern(ctx, "ctxt");
  KLObject* t823;
  {
    KLObject* a823[] = {t761, t825};
    t823 = shen_apply_direct(ctx, "shen.hds=?", 2, a823);
  }
  KLObject* t822;
  if (!shen_is_boolean(ctx, t823))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t823)) {
  KLObject* t826;
  {
    KLObject* a826[] = {t761};
    t826 = shen_apply_direct(ctx, "tail", 1, a826);
  }
  KLObject* t830 = shen_cons_p(ctx, t826);
  KLObject* t828;
  if (!shen_is_boolean(ctx, t830))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t830)) {
  KLObject* t831;
  {
    KLObject* a831[] = {t826};
    t831 = shen_apply_direct(ctx, "head", 1, a831);
  }
  KLObject* t833;
  {
    KLObject* a833[] = {t826};
    t833 = shen_apply_direct(ctx, "tail", 1, a833);
  }
  KLObject* t836;
  {
    KLObject* a836[] = {t831};
    t836 = shen_apply_direct(ctx, "variable?", 1, a836);
  }
  KLObject* t835;
  if (!shen_is_boolean(ctx, t836))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t836)) {
  KLObject* t840 = shen_intern(ctx, "ctxt");
  KLObject* t842 = shen_empty_list(ctx);
  KLObject* t843 = shen_cons(ctx, t831, t842);
  KLObject* t844 = shen_cons(ctx, t840, t843);
  KLObject* t838;
  {
    KLObject* a838[] = {t833, t844};
    t838 = shen_apply_direct(ctx, "shen.comb", 2, a838);
  }
    t835 = t838;
  } else {
  KLObject* t845 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t835 = t845;
  }
    t828 = t835;
  } else {
  KLObject* t846 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t828 = t846;
  }
    t822 = t828;
  } else {
  KLObject* t847 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t822 = t847;
  }
  KLObject* t849;
  {
    KLObject* a849[] = {t822};
    t849 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a849);
  }
  KLObject* t848;
  if (!shen_is_boolean(ctx, t849))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t849)) {
  KLObject* t854 = shen_intern(ctx, "sqts");
  KLObject* t852;
  {
    KLObject* a852[] = {t761, t854};
    t852 = shen_apply_direct(ctx, "shen.hds=?", 2, a852);
  }
  KLObject* t851;
  if (!shen_is_boolean(ctx, t852))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t852)) {
  KLObject* t855;
  {
    KLObject* a855[] = {t761};
    t855 = shen_apply_direct(ctx, "tail", 1, a855);
  }
  KLObject* t859 = shen_cons_p(ctx, t855);
  KLObject* t857;
  if (!shen_is_boolean(ctx, t859))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t859)) {
  KLObject* t860;
  {
    KLObject* a860[] = {t855};
    t860 = shen_apply_direct(ctx, "head", 1, a860);
  }
  KLObject* t862;
  {
    KLObject* a862[] = {t855};
    t862 = shen_apply_direct(ctx, "tail", 1, a862);
  }
  KLObject* t865;
  {
    KLObject* a865[] = {t860};
    t865 = shen_apply_direct(ctx, "variable?", 1, a865);
  }
  KLObject* t864;
  if (!shen_is_boolean(ctx, t865))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t865)) {
  KLObject* t869 = shen_intern(ctx, "sqts");
  KLObject* t871 = shen_empty_list(ctx);
  KLObject* t872 = shen_cons(ctx, t860, t871);
  KLObject* t873 = shen_cons(ctx, t869, t872);
  KLObject* t867;
  {
    KLObject* a867[] = {t862, t873};
    t867 = shen_apply_direct(ctx, "shen.comb", 2, a867);
  }
    t864 = t867;
  } else {
  KLObject* t874 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t864 = t874;
  }
    t857 = t864;
  } else {
  KLObject* t875 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t857 = t875;
  }
    t851 = t857;
  } else {
  KLObject* t876 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t851 = t876;
  }
  KLObject* t878;
  {
    KLObject* a878[] = {t851};
    t878 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a878);
  }
  KLObject* t877;
  if (!shen_is_boolean(ctx, t878))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t878)) {
  KLObject* t880 = shen_tail_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t877 = t880;
  } else {
    t877 = t851;
  }
    t848 = t877;
  } else {
    t848 = t822;
  }
    t819 = t848;
  } else {
    t819 = t787;
  }
    t784 = t819;
  } else {
    t784 = t762;
  }
    return t784;
  }
}

static KLObject* native_kl_shen_2elr_2drule_16 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t885 = objects[0];
    KLObject* t886 = objects[1];
    KLObject* t887 = objects[2];
  tail_start_kl_shen_2elr_2drule_16: ;
  KLObject* t888;
  {
  KLObject* t891 = shen_cons_p(ctx, t887);
  KLObject* t889;
  if (!shen_is_boolean(ctx, t891))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t891)) {
    t889 = t891;
  } else {
  KLObject* t893 = shen_empty_list(ctx);
  KLObject* t895 = shen_hd(ctx, t887);
  KLObject* t896 = shen_eq(ctx, t893, t895);
  KLObject* t892;
  if (!shen_is_boolean(ctx, t896))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t896)) {
    t892 = t896;
  } else {
  KLObject* t899 = shen_tl(ctx, t887);
  KLObject* t900 = shen_cons_p(ctx, t899);
  KLObject* t897;
  if (!shen_is_boolean(ctx, t900))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t900)) {
    t897 = t900;
  } else {
  KLObject* t901 = shen_empty_list(ctx);
  KLObject* t903 = shen_tl(ctx, t887);
  KLObject* t904 = shen_tl(ctx, t903);
  KLObject* t905 = shen_eq(ctx, t901, t904);
    if (!shen_is_boolean(ctx, t905))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t897 = t905;
  }
    if (!shen_is_boolean(ctx, t897))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t892 = t897;
  }
    if (!shen_is_boolean(ctx, t892))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t889 = t892;
  }
    if (!shen_is_boolean(ctx, t889))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t889)) {
  KLObject* t907 = shen_intern(ctx, "P");
  KLObject* t906;
  {
    KLObject* a906[] = {t907};
    t906 = shen_apply_direct(ctx, "gensym", 1, a906);
  }
  KLObject* t909 = shen_tl(ctx, t887);
  KLObject* t911 = shen_empty_list(ctx);
  KLObject* t912 = shen_cons(ctx, t906, t911);
  KLObject* t913 = shen_cons(ctx, t909, t912);
  KLObject* t914;
  {
    KLObject* a914[] = {t886};
    t914 = shen_apply_direct(ctx, "shen.coll-formulae", 1, a914);
  }
  KLObject* t917 = shen_empty_list(ctx);
  KLObject* t918 = shen_cons(ctx, t906, t917);
  KLObject* t919 = shen_cons(ctx, t914, t918);
  KLObject* t922 = shen_empty_list(ctx);
  KLObject* t923 = shen_cons(ctx, t919, t922);
  KLObject* t925 = shen_empty_list(ctx);
  KLObject* t926 = shen_cons(ctx, t913, t925);
  KLObject* t927 = shen_cons(ctx, t923, t926);
  KLObject* t928 = shen_cons(ctx, t885, t927);
  KLObject* t932 = shen_empty_list(ctx);
  KLObject* t933 = shen_cons(ctx, t887, t932);
  KLObject* t934 = shen_cons(ctx, t886, t933);
  KLObject* t935 = shen_cons(ctx, t885, t934);
  KLObject* t938 = shen_empty_list(ctx);
  KLObject* t939 = shen_cons(ctx, t928, t938);
  KLObject* t940 = shen_cons(ctx, t935, t939);
      t888 = t940;
    } else {
  KLObject* t941 = shen_true(ctx);
    if (!shen_is_boolean(ctx, t941))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t941)) {
  KLObject* t943 = shen_string(ctx, "implementation error in shen.lr-rule");
  KLObject* t942;
  {
    KLObject* a942[] = {t943};
    t942 = shen_tail_apply_direct(ctx, "simple-error", 1, a942);
  }
      t888 = t942;
    } else {
      shen_simple_error(ctx, "No true case found for cond");
      t888 = shen_empty_list(ctx);
    }
    }
  }
    return t888;
  }
}

static KLObject* native_kl_shen_2ecoll_2dformulae_17 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t944 = objects[0];
  tail_start_kl_shen_2ecoll_2dformulae_17: ;
  KLObject* t945;
  {
  KLObject* t946 = shen_empty_list(ctx);
  KLObject* t948 = shen_eq(ctx, t946, t944);
    if (!shen_is_boolean(ctx, t948))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t948)) {
  KLObject* t949 = shen_empty_list(ctx);
      t945 = t949;
    } else {
  KLObject* t952 = shen_cons_p(ctx, t944);
  KLObject* t950;
  if (!shen_is_boolean(ctx, t952))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t952)) {
    t950 = t952;
  } else {
  KLObject* t955 = shen_hd(ctx, t944);
  KLObject* t956 = shen_cons_p(ctx, t955);
  KLObject* t953;
  if (!shen_is_boolean(ctx, t956))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t956)) {
    t953 = t956;
  } else {
  KLObject* t958 = shen_empty_list(ctx);
  KLObject* t960 = shen_hd(ctx, t944);
  KLObject* t961 = shen_hd(ctx, t960);
  KLObject* t962 = shen_eq(ctx, t958, t961);
  KLObject* t957;
  if (!shen_is_boolean(ctx, t962))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t962)) {
    t957 = t962;
  } else {
  KLObject* t965 = shen_hd(ctx, t944);
  KLObject* t966 = shen_tl(ctx, t965);
  KLObject* t967 = shen_cons_p(ctx, t966);
  KLObject* t963;
  if (!shen_is_boolean(ctx, t967))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t967)) {
    t963 = t967;
  } else {
  KLObject* t968 = shen_empty_list(ctx);
  KLObject* t970 = shen_hd(ctx, t944);
  KLObject* t971 = shen_tl(ctx, t970);
  KLObject* t972 = shen_tl(ctx, t971);
  KLObject* t973 = shen_eq(ctx, t968, t972);
    if (!shen_is_boolean(ctx, t973))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t963 = t973;
  }
    if (!shen_is_boolean(ctx, t963))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t957 = t963;
  }
    if (!shen_is_boolean(ctx, t957))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t953 = t957;
  }
    if (!shen_is_boolean(ctx, t953))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t950 = t953;
  }
    if (!shen_is_boolean(ctx, t950))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t950)) {
  KLObject* t975 = shen_hd(ctx, t944);
  KLObject* t976 = shen_tl(ctx, t975);
  KLObject* t977 = shen_hd(ctx, t976);
  KLObject* t980 = shen_tl(ctx, t944);
  KLObject* t978;
  {
    KLObject* a978[] = {t980};
    t978 = shen_apply_direct(ctx, "shen.coll-formulae", 1, a978);
  }
  KLObject* t981 = shen_cons(ctx, t977, t978);
      t945 = t981;
    } else {
  KLObject* t982 = shen_true(ctx);
    if (!shen_is_boolean(ctx, t982))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t982)) {
  KLObject* t984 = shen_string(ctx, "implementation error in shen.coll-formulae");
  KLObject* t983;
  {
    KLObject* a983[] = {t984};
    t983 = shen_tail_apply_direct(ctx, "simple-error", 1, a983);
  }
      t945 = t983;
    } else {
      shen_simple_error(ctx, "No true case found for cond");
      t945 = shen_empty_list(ctx);
    }
    }
    }
  }
    return t945;
  }
}

static KLObject* native_kl_shen_2e_3cexpr_3e_18 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t985 = objects[0];
  tail_start_kl_shen_2e_3cexpr_3e_18: ;
  KLObject* t988 = shen_cons_p(ctx, t985);
  KLObject* t986;
  if (!shen_is_boolean(ctx, t988))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t988)) {
  KLObject* t989;
  {
    KLObject* a989[] = {t985};
    t989 = shen_apply_direct(ctx, "head", 1, a989);
  }
  KLObject* t991;
  {
    KLObject* a991[] = {t985};
    t991 = shen_apply_direct(ctx, "tail", 1, a991);
  }
  KLObject* t995;
  {
    KLObject* a995[] = {t989};
    t995 = shen_apply_direct(ctx, "shen.key-in-sequent-calculus?", 1, a995);
  }
  KLObject* t994;
  {
    KLObject* a994[] = {t995};
    t994 = shen_apply_direct(ctx, "not", 1, a994);
  }
  KLObject* t993;
  if (!shen_is_boolean(ctx, t994))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t994)) {
  KLObject* t999;
  {
    KLObject* a999[] = {t989};
    t999 = shen_apply_direct(ctx, "macroexpand", 1, a999);
  }
  KLObject* t997;
  {
    KLObject* a997[] = {t991, t999};
    t997 = shen_apply_direct(ctx, "shen.comb", 2, a997);
  }
    t993 = t997;
  } else {
  KLObject* t1001 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t993 = t1001;
  }
    t986 = t993;
  } else {
  KLObject* t1002 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t986 = t1002;
  }
  KLObject* t1004;
  {
    KLObject* a1004[] = {t986};
    t1004 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a1004);
  }
  KLObject* t1003;
  if (!shen_is_boolean(ctx, t1004))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1004)) {
  KLObject* t1006 = shen_tail_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t1003 = t1006;
  } else {
    t1003 = t986;
  }
    return t1003;
  }
}

static KLObject* native_kl_shen_2ekey_2din_2dsequent_2dcalculus_3f_19 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t1008 = objects[0];
  tail_start_kl_shen_2ekey_2din_2dsequent_2dcalculus_3f_19: ;
  KLObject* t1012 = shen_intern(ctx, ">>");
  KLObject* t1014 = shen_string(ctx, ";");
  KLObject* t1013;
  {
    KLObject* a1013[] = {t1014};
    t1013 = shen_apply_direct(ctx, "intern", 1, a1013);
  }
  KLObject* t1016 = shen_string(ctx, ",");
  KLObject* t1015;
  {
    KLObject* a1015[] = {t1016};
    t1015 = shen_apply_direct(ctx, "intern", 1, a1015);
  }
  KLObject* t1018 = shen_string(ctx, ":");
  KLObject* t1017;
  {
    KLObject* a1017[] = {t1018};
    t1017 = shen_apply_direct(ctx, "intern", 1, a1017);
  }
  KLObject* t1019 = shen_intern(ctx, "<--");
  KLObject* t1020 = shen_empty_list(ctx);
  KLObject* t1021 = shen_cons(ctx, t1019, t1020);
  KLObject* t1022 = shen_cons(ctx, t1017, t1021);
  KLObject* t1023 = shen_cons(ctx, t1015, t1022);
  KLObject* t1024 = shen_cons(ctx, t1013, t1023);
  KLObject* t1025 = shen_cons(ctx, t1012, t1024);
  KLObject* t1010;
  {
    KLObject* a1010[] = {t1008, t1025};
    t1010 = shen_apply_direct(ctx, "element?", 2, a1010);
  }
  KLObject* t1009;
  if (!shen_is_boolean(ctx, t1010))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (shen_boolean_value(ctx, t1010)) {
    t1009 = t1010;
  } else {
  KLObject* t1027;
  {
    KLObject* a1027[] = {t1008};
    t1027 = shen_apply_direct(ctx, "shen.sng?", 1, a1027);
  }
  KLObject* t1026;
  if (!shen_is_boolean(ctx, t1027))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (shen_boolean_value(ctx, t1027)) {
    t1026 = t1027;
  } else {
  KLObject* t1029;
  {
    KLObject* a1029[] = {t1008};
    t1029 = shen_apply_direct(ctx, "shen.dbl?", 1, a1029);
  }
    if (!shen_is_boolean(ctx, t1029))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t1026 = t1029;
  }
    if (!shen_is_boolean(ctx, t1026))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t1009 = t1026;
  }
    return t1009;
  }
}

static KLObject* native_kl_shen_2e_3ctype_3e_20 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t1031 = objects[0];
  tail_start_kl_shen_2e_3ctype_3e_20: ;
  KLObject* t1032;
  {
    KLObject* a1032[] = {t1031};
    t1032 = shen_apply_direct(ctx, "shen.<expr>", 1, a1032);
  }
  KLObject* t1035;
  {
    KLObject* a1035[] = {t1032};
    t1035 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a1035);
  }
  KLObject* t1034;
  if (!shen_is_boolean(ctx, t1035))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1035)) {
  KLObject* t1037 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t1034 = t1037;
  } else {
  KLObject* t1038;
  {
    KLObject* a1038[] = {t1032};
    t1038 = shen_apply_direct(ctx, "shen.<-out", 1, a1038);
  }
  KLObject* t1040;
  {
    KLObject* a1040[] = {t1032};
    t1040 = shen_apply_direct(ctx, "shen.in->", 1, a1040);
  }
  KLObject* t1042;
  {
    KLObject* a1042[] = {t1040, t1038};
    t1042 = shen_apply_direct(ctx, "shen.comb", 2, a1042);
  }
    t1034 = t1042;
  }
  KLObject* t1046;
  {
    KLObject* a1046[] = {t1034};
    t1046 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a1046);
  }
  KLObject* t1045;
  if (!shen_is_boolean(ctx, t1046))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1046)) {
  KLObject* t1048 = shen_tail_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t1045 = t1048;
  } else {
    t1045 = t1034;
  }
    return t1045;
  }
}

static KLObject* native_kl_shen_2e_3cdbl_3e_21 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t1050 = objects[0];
  tail_start_kl_shen_2e_3cdbl_3e_21: ;
  KLObject* t1053 = shen_cons_p(ctx, t1050);
  KLObject* t1051;
  if (!shen_is_boolean(ctx, t1053))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1053)) {
  KLObject* t1054;
  {
    KLObject* a1054[] = {t1050};
    t1054 = shen_apply_direct(ctx, "head", 1, a1054);
  }
  KLObject* t1056;
  {
    KLObject* a1056[] = {t1050};
    t1056 = shen_apply_direct(ctx, "tail", 1, a1056);
  }
  KLObject* t1059;
  {
    KLObject* a1059[] = {t1054};
    t1059 = shen_apply_direct(ctx, "shen.dbl?", 1, a1059);
  }
  KLObject* t1058;
  if (!shen_is_boolean(ctx, t1059))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1059)) {
  KLObject* t1061;
  {
    KLObject* a1061[] = {t1056, t1054};
    t1061 = shen_apply_direct(ctx, "shen.comb", 2, a1061);
  }
    t1058 = t1061;
  } else {
  KLObject* t1064 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t1058 = t1064;
  }
    t1051 = t1058;
  } else {
  KLObject* t1065 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t1051 = t1065;
  }
  KLObject* t1067;
  {
    KLObject* a1067[] = {t1051};
    t1067 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a1067);
  }
  KLObject* t1066;
  if (!shen_is_boolean(ctx, t1067))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1067)) {
  KLObject* t1069 = shen_tail_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t1066 = t1069;
  } else {
    t1066 = t1051;
  }
    return t1066;
  }
}

static KLObject* native_kl_shen_2e_3csng_3e_22 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t1071 = objects[0];
  tail_start_kl_shen_2e_3csng_3e_22: ;
  KLObject* t1074 = shen_cons_p(ctx, t1071);
  KLObject* t1072;
  if (!shen_is_boolean(ctx, t1074))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1074)) {
  KLObject* t1075;
  {
    KLObject* a1075[] = {t1071};
    t1075 = shen_apply_direct(ctx, "head", 1, a1075);
  }
  KLObject* t1077;
  {
    KLObject* a1077[] = {t1071};
    t1077 = shen_apply_direct(ctx, "tail", 1, a1077);
  }
  KLObject* t1080;
  {
    KLObject* a1080[] = {t1075};
    t1080 = shen_apply_direct(ctx, "shen.sng?", 1, a1080);
  }
  KLObject* t1079;
  if (!shen_is_boolean(ctx, t1080))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1080)) {
  KLObject* t1082;
  {
    KLObject* a1082[] = {t1077, t1075};
    t1082 = shen_apply_direct(ctx, "shen.comb", 2, a1082);
  }
    t1079 = t1082;
  } else {
  KLObject* t1085 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t1079 = t1085;
  }
    t1072 = t1079;
  } else {
  KLObject* t1086 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t1072 = t1086;
  }
  KLObject* t1088;
  {
    KLObject* a1088[] = {t1072};
    t1088 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a1088);
  }
  KLObject* t1087;
  if (!shen_is_boolean(ctx, t1088))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1088)) {
  KLObject* t1090 = shen_tail_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t1087 = t1090;
  } else {
    t1087 = t1072;
  }
    return t1087;
  }
}

static KLObject* native_kl_shen_2esng_3f_23 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t1092 = objects[0];
  tail_start_kl_shen_2esng_3f_23: ;
  KLObject* t1095 = shen_symbol_p(ctx, t1092);
  KLObject* t1093;
  if (!shen_is_boolean(ctx, t1095))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t1095)) {
    t1093 = t1095;
  } else {
  KLObject* t1097;
  {
    KLObject* a1097[] = {t1092};
    t1097 = shen_apply_direct(ctx, "str", 1, a1097);
  }
  KLObject* t1096;
  {
    KLObject* a1096[] = {t1097};
    t1096 = shen_apply_direct(ctx, "shen.sng-h?", 1, a1096);
  }
    if (!shen_is_boolean(ctx, t1096))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t1093 = t1096;
  }
    return t1093;
  }
}

static KLObject* native_kl_shen_2esng_2dh_3f_24 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t1099 = objects[0];
  tail_start_kl_shen_2esng_2dh_3f_24: ;
  KLObject* t1100;
  {
  KLObject* t1101 = shen_string(ctx, "___");
  KLObject* t1103 = shen_eq(ctx, t1101, t1099);
    if (!shen_is_boolean(ctx, t1103))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t1103)) {
  KLObject* t1104 = shen_true(ctx);
      t1100 = t1104;
    } else {
  KLObject* t1106;
  {
    KLObject* a1106[] = {t1099};
    t1106 = shen_apply_direct(ctx, "shen.+string?", 1, a1106);
  }
  KLObject* t1105;
  if (!shen_is_boolean(ctx, t1106))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t1106)) {
    t1105 = t1106;
  } else {
  KLObject* t1108 = shen_string(ctx, "_");
  KLObject* t1109;
  {
    KLObject* a1109[] = {t1099};
    t1109 = shen_apply_direct(ctx, "hdstr", 1, a1109);
  }
  KLObject* t1111 = shen_eq(ctx, t1108, t1109);
    if (!shen_is_boolean(ctx, t1111))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t1105 = t1111;
  }
    if (!shen_is_boolean(ctx, t1105))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t1105)) {
  KLObject* t1112;
  {
    KLObject* a1112[] = {t1099};
    t1112 = shen_apply_direct(ctx, "tlstr", 1, a1112);
  }
  {
    KLObject* n1114_0 = t1112;
    t1099 = n1114_0;
    goto tail_start_kl_shen_2esng_2dh_3f_24;
  }
  KLObject* t1114 = NULL;
      t1100 = t1114;
    } else {
  KLObject* t1115 = shen_true(ctx);
    if (!shen_is_boolean(ctx, t1115))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t1115)) {
  KLObject* t1116 = shen_false(ctx);
      t1100 = t1116;
    } else {
      shen_simple_error(ctx, "No true case found for cond");
      t1100 = shen_empty_list(ctx);
    }
    }
    }
  }
    return t1100;
  }
}

static KLObject* native_kl_shen_2edbl_3f_25 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t1117 = objects[0];
  tail_start_kl_shen_2edbl_3f_25: ;
  KLObject* t1120 = shen_symbol_p(ctx, t1117);
  KLObject* t1118;
  if (!shen_is_boolean(ctx, t1120))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t1120)) {
    t1118 = t1120;
  } else {
  KLObject* t1122;
  {
    KLObject* a1122[] = {t1117};
    t1122 = shen_apply_direct(ctx, "str", 1, a1122);
  }
  KLObject* t1121;
  {
    KLObject* a1121[] = {t1122};
    t1121 = shen_apply_direct(ctx, "shen.dbl-h?", 1, a1121);
  }
    if (!shen_is_boolean(ctx, t1121))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t1118 = t1121;
  }
    return t1118;
  }
}

static KLObject* native_kl_shen_2edbl_2dh_3f_26 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t1124 = objects[0];
  tail_start_kl_shen_2edbl_2dh_3f_26: ;
  KLObject* t1125;
  {
  KLObject* t1126 = shen_string(ctx, "===");
  KLObject* t1128 = shen_eq(ctx, t1126, t1124);
    if (!shen_is_boolean(ctx, t1128))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t1128)) {
  KLObject* t1129 = shen_true(ctx);
      t1125 = t1129;
    } else {
  KLObject* t1131;
  {
    KLObject* a1131[] = {t1124};
    t1131 = shen_apply_direct(ctx, "shen.+string?", 1, a1131);
  }
  KLObject* t1130;
  if (!shen_is_boolean(ctx, t1131))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t1131)) {
    t1130 = t1131;
  } else {
  KLObject* t1133 = shen_string(ctx, "=");
  KLObject* t1134;
  {
    KLObject* a1134[] = {t1124};
    t1134 = shen_apply_direct(ctx, "hdstr", 1, a1134);
  }
  KLObject* t1136 = shen_eq(ctx, t1133, t1134);
    if (!shen_is_boolean(ctx, t1136))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t1130 = t1136;
  }
    if (!shen_is_boolean(ctx, t1130))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t1130)) {
  KLObject* t1137;
  {
    KLObject* a1137[] = {t1124};
    t1137 = shen_apply_direct(ctx, "tlstr", 1, a1137);
  }
  {
    KLObject* n1139_0 = t1137;
    t1124 = n1139_0;
    goto tail_start_kl_shen_2edbl_2dh_3f_26;
  }
  KLObject* t1139 = NULL;
      t1125 = t1139;
    } else {
  KLObject* t1140 = shen_true(ctx);
    if (!shen_is_boolean(ctx, t1140))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t1140)) {
  KLObject* t1141 = shen_false(ctx);
      t1125 = t1141;
    } else {
      shen_simple_error(ctx, "No true case found for cond");
      t1125 = shen_empty_list(ctx);
    }
    }
    }
  }
    return t1125;
  }
}

static KLObject* native_kl_shen_2erules_2d_3eprolog_27 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t1142 = objects[0];
    KLObject* t1143 = objects[1];
  tail_start_kl_shen_2erules_2d_3eprolog_27: ;
  KLObject* t1145;
  {
    Vector* caps_0 = shen_vector(ctx, 0);
    t1145 = shen_native_closure(ctx, 1, &lambda_0, caps_0);
  }
  KLObject* t1144;
  {
    KLObject* a1144[] = {t1145, t1143};
    t1144 = shen_apply_direct(ctx, "mapcan", 2, a1144);
  }
  KLObject* t1150 = shen_intern(ctx, "defprolog");
  KLObject* t1153 = shen_cons(ctx, t1142, t1144);
  KLObject* t1154 = shen_cons(ctx, t1150, t1153);
  KLObject* t1155;
  {
    KLObject* a1155[] = {t1154};
    t1155 = shen_tail_apply_direct(ctx, "eval", 1, a1155);
  }
    return t1155;
  }
}

static KLObject* native_kl_shen_2erule_2d_3eclause_28 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t1157 = objects[0];
  tail_start_kl_shen_2erule_2d_3eclause_28: ;
  KLObject* t1158;
  {
  KLObject* t1161 = shen_cons_p(ctx, t1157);
  KLObject* t1159;
  if (!shen_is_boolean(ctx, t1161))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t1161)) {
    t1159 = t1161;
  } else {
  KLObject* t1164 = shen_tl(ctx, t1157);
  KLObject* t1165 = shen_cons_p(ctx, t1164);
  KLObject* t1162;
  if (!shen_is_boolean(ctx, t1165))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t1165)) {
    t1162 = t1165;
  } else {
  KLObject* t1168 = shen_tl(ctx, t1157);
  KLObject* t1169 = shen_tl(ctx, t1168);
  KLObject* t1170 = shen_cons_p(ctx, t1169);
  KLObject* t1166;
  if (!shen_is_boolean(ctx, t1170))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t1170)) {
    t1166 = t1170;
  } else {
  KLObject* t1173 = shen_tl(ctx, t1157);
  KLObject* t1174 = shen_tl(ctx, t1173);
  KLObject* t1175 = shen_hd(ctx, t1174);
  KLObject* t1176 = shen_cons_p(ctx, t1175);
  KLObject* t1171;
  if (!shen_is_boolean(ctx, t1176))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t1176)) {
    t1171 = t1176;
  } else {
  KLObject* t1179 = shen_tl(ctx, t1157);
  KLObject* t1180 = shen_tl(ctx, t1179);
  KLObject* t1181 = shen_hd(ctx, t1180);
  KLObject* t1182 = shen_tl(ctx, t1181);
  KLObject* t1183 = shen_cons_p(ctx, t1182);
  KLObject* t1177;
  if (!shen_is_boolean(ctx, t1183))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t1183)) {
    t1177 = t1183;
  } else {
  KLObject* t1185 = shen_empty_list(ctx);
  KLObject* t1187 = shen_tl(ctx, t1157);
  KLObject* t1188 = shen_tl(ctx, t1187);
  KLObject* t1189 = shen_hd(ctx, t1188);
  KLObject* t1190 = shen_tl(ctx, t1189);
  KLObject* t1191 = shen_tl(ctx, t1190);
  KLObject* t1192 = shen_eq(ctx, t1185, t1191);
  KLObject* t1184;
  if (!shen_is_boolean(ctx, t1192))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t1192)) {
    t1184 = t1192;
  } else {
  KLObject* t1193 = shen_empty_list(ctx);
  KLObject* t1195 = shen_tl(ctx, t1157);
  KLObject* t1196 = shen_tl(ctx, t1195);
  KLObject* t1197 = shen_tl(ctx, t1196);
  KLObject* t1198 = shen_eq(ctx, t1193, t1197);
    if (!shen_is_boolean(ctx, t1198))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t1184 = t1198;
  }
    if (!shen_is_boolean(ctx, t1184))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t1177 = t1184;
  }
    if (!shen_is_boolean(ctx, t1177))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t1171 = t1177;
  }
    if (!shen_is_boolean(ctx, t1171))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t1166 = t1171;
  }
    if (!shen_is_boolean(ctx, t1166))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t1162 = t1166;
  }
    if (!shen_is_boolean(ctx, t1162))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t1159 = t1162;
  }
    if (!shen_is_boolean(ctx, t1159))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t1159)) {
  KLObject* t1201 = shen_tl(ctx, t1157);
  KLObject* t1202 = shen_tl(ctx, t1201);
  KLObject* t1203 = shen_hd(ctx, t1202);
  KLObject* t1204 = shen_tl(ctx, t1203);
  KLObject* t1205 = shen_hd(ctx, t1204);
  KLObject* t1199;
  {
    KLObject* a1199[] = {t1205};
    t1199 = shen_apply_direct(ctx, "shen.extract-vars", 1, a1199);
  }
  KLObject* t1209 = shen_tl(ctx, t1157);
  KLObject* t1210 = shen_tl(ctx, t1209);
  KLObject* t1211 = shen_hd(ctx, t1210);
  KLObject* t1212 = shen_tl(ctx, t1211);
  KLObject* t1213 = shen_hd(ctx, t1212);
  KLObject* t1207;
  {
    KLObject* a1207[] = {t1213};
    t1207 = shen_apply_direct(ctx, "shen.rule->head", 1, a1207);
  }
  KLObject* t1215 = shen_intern(ctx, "<--");
  KLObject* t1216 = shen_empty_list(ctx);
  KLObject* t1217 = shen_cons(ctx, t1215, t1216);
  KLObject* t1220 = shen_intern(ctx, "Assumptions");
  KLObject* t1222 = shen_hd(ctx, t1157);
  KLObject* t1224 = shen_tl(ctx, t1157);
  KLObject* t1225 = shen_hd(ctx, t1224);
  KLObject* t1227 = shen_tl(ctx, t1157);
  KLObject* t1228 = shen_tl(ctx, t1227);
  KLObject* t1229 = shen_hd(ctx, t1228);
  KLObject* t1230 = shen_hd(ctx, t1229);
  KLObject* t1218;
  {
    KLObject* a1218[] = {t1199, t1220, t1222, t1225, t1230};
    t1218 = shen_apply_direct(ctx, "shen.rule->body", 5, a1218);
  }
  KLObject* t1214;
  {
    KLObject* a1214[] = {t1217, t1218};
    t1214 = shen_apply_direct(ctx, "append", 2, a1214);
  }
  KLObject* t1206;
  {
    KLObject* a1206[] = {t1207, t1214};
    t1206 = shen_tail_apply_direct(ctx, "append", 2, a1206);
  }
      t1158 = t1206;
    } else {
  KLObject* t1231 = shen_true(ctx);
    if (!shen_is_boolean(ctx, t1231))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t1231)) {
  KLObject* t1233 = shen_string(ctx, "partial function shen.rule->clause");
  KLObject* t1232;
  {
    KLObject* a1232[] = {t1233};
    t1232 = shen_tail_apply_direct(ctx, "simple-error", 1, a1232);
  }
      t1158 = t1232;
    } else {
      shen_simple_error(ctx, "No true case found for cond");
      t1158 = shen_empty_list(ctx);
    }
    }
  }
    return t1158;
  }
}

static KLObject* native_kl_shen_2erule_2d_3ehead_29 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t1234 = objects[0];
  tail_start_kl_shen_2erule_2d_3ehead_29: ;
  KLObject* t1235;
  {
    KLObject* a1235[] = {t1234};
    t1235 = shen_apply_direct(ctx, "shen.macro-@ch", 1, a1235);
  }
  KLObject* t1237 = shen_intern(ctx, "Assumptions");
  KLObject* t1238 = shen_empty_list(ctx);
  KLObject* t1239 = shen_cons(ctx, t1237, t1238);
  KLObject* t1240 = shen_cons(ctx, t1235, t1239);
    return t1240;
  }
}

static KLObject* native_kl_shen_2emacro_2d_40ch_30 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t1241 = objects[0];
  tail_start_kl_shen_2emacro_2d_40ch_30: ;
  KLObject* t1242 = shen_intern(ctx, "shen.@ch");
  KLObject* t1244 = shen_empty_list(ctx);
  KLObject* t1245 = shen_cons(ctx, t1241, t1244);
  KLObject* t1246 = shen_cons(ctx, t1242, t1245);
    return t1246;
  }
}

static KLObject* native_kl_shen_2emacro_2d_40c_31 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t1247 = objects[0];
  tail_start_kl_shen_2emacro_2d_40c_31: ;
  KLObject* t1248 = shen_intern(ctx, "shen.@c");
  KLObject* t1250 = shen_empty_list(ctx);
  KLObject* t1251 = shen_cons(ctx, t1247, t1250);
  KLObject* t1252 = shen_cons(ctx, t1248, t1251);
    return t1252;
  }
}

static KLObject* native_kl_shen_2erule_2d_3ebody_32 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t1253 = objects[0];
    KLObject* t1254 = objects[1];
    KLObject* t1255 = objects[2];
    KLObject* t1256 = objects[3];
    KLObject* t1257 = objects[4];
  tail_start_kl_shen_2erule_2d_3ebody_32: ;
  KLObject* t1258;
  {
  KLObject* t1259 = shen_empty_list(ctx);
  KLObject* t1261 = shen_eq(ctx, t1259, t1257);
    if (!shen_is_boolean(ctx, t1261))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t1261)) {
  KLObject* t1263 = shen_empty_list(ctx);
  KLObject* t1262;
  {
    KLObject* a1262[] = {t1263, t1253, t1254, t1255, t1256};
    t1262 = shen_tail_apply_direct(ctx, "shen.side-conditions->goals", 5, a1262);
  }
      t1258 = t1262;
    } else {
  KLObject* t1269 = shen_empty_list(ctx);
  KLObject* t1271 = shen_eq(ctx, t1269, t1256);
  KLObject* t1268;
  if (!shen_is_boolean(ctx, t1271))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t1271)) {
    t1268 = t1271;
  } else {
  KLObject* t1274 = shen_cons_p(ctx, t1257);
  KLObject* t1272;
  if (!shen_is_boolean(ctx, t1274))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t1274)) {
    t1272 = t1274;
  } else {
  KLObject* t1275 = shen_empty_list(ctx);
  KLObject* t1277 = shen_tl(ctx, t1257);
  KLObject* t1278 = shen_eq(ctx, t1275, t1277);
    if (!shen_is_boolean(ctx, t1278))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t1272 = t1278;
  }
    if (!shen_is_boolean(ctx, t1272))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t1268 = t1272;
  }
    if (!shen_is_boolean(ctx, t1268))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t1268)) {
  KLObject* t1281 = shen_hd(ctx, t1257);
  KLObject* t1279;
  {
    KLObject* a1279[] = {t1281, t1253};
    t1279 = shen_apply_direct(ctx, "shen.passive-variables", 2, a1279);
  }
  KLObject* t1286 = shen_hd(ctx, t1257);
  KLObject* t1283;
  {
    KLObject* a1283[] = {t1253, t1286};
    t1283 = shen_apply_direct(ctx, "shen.remove-bystanders", 2, a1283);
  }
  KLObject* t1289 = shen_hd(ctx, t1257);
  KLObject* t1287;
  {
    KLObject* a1287[] = {t1289, t1254, t1283, t1279};
    t1287 = shen_apply_direct(ctx, "shen.specialise-member", 4, a1287);
  }
  KLObject* t1294 = shen_empty_list(ctx);
  KLObject* t1298 = shen_empty_list(ctx);
  KLObject* t1293;
  {
    KLObject* a1293[] = {t1294, t1253, t1254, t1255, t1298};
    t1293 = shen_apply_direct(ctx, "shen.side-conditions->goals", 5, a1293);
  }
  KLObject* t1299 = shen_cons(ctx, t1287, t1293);
      t1258 = t1299;
    } else {
  KLObject* t1301 = shen_cons_p(ctx, t1257);
    if (!shen_is_boolean(ctx, t1301))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t1301)) {
  KLObject* t1303 = shen_intern(ctx, "NewAssumptions");
  KLObject* t1302;
  {
    KLObject* a1302[] = {t1303};
    t1302 = shen_apply_direct(ctx, "gensym", 1, a1302);
  }
  KLObject* t1306 = shen_hd(ctx, t1257);
  KLObject* t1304;
  {
    KLObject* a1304[] = {t1306, t1253};
    t1304 = shen_apply_direct(ctx, "shen.passive-variables", 2, a1304);
  }
  KLObject* t1311 = shen_hd(ctx, t1257);
  KLObject* t1308;
  {
    KLObject* a1308[] = {t1253, t1311};
    t1308 = shen_apply_direct(ctx, "shen.remove-bystanders", 2, a1308);
  }
  KLObject* t1314 = shen_hd(ctx, t1257);
  KLObject* t1312;
  {
    KLObject* a1312[] = {t1314, t1254, t1308, t1304, t1302};
    t1312 = shen_apply_direct(ctx, "shen.specialise-consume", 5, a1312);
  }
  KLObject* t1320;
  {
    KLObject* a1320[] = {t1253, t1304};
    t1320 = shen_apply_direct(ctx, "append", 2, a1320);
  }
  KLObject* t1327 = shen_tl(ctx, t1257);
  KLObject* t1319;
  {
    KLObject* a1319[] = {t1320, t1302, t1255, t1256, t1327};
    t1319 = shen_apply_direct(ctx, "shen.rule->body", 5, a1319);
  }
  KLObject* t1328 = shen_cons(ctx, t1312, t1319);
      t1258 = t1328;
    } else {
  KLObject* t1329 = shen_true(ctx);
    if (!shen_is_boolean(ctx, t1329))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t1329)) {
  KLObject* t1331 = shen_string(ctx, "partial function shen.rule->body");
  KLObject* t1330;
  {
    KLObject* a1330[] = {t1331};
    t1330 = shen_tail_apply_direct(ctx, "simple-error", 1, a1330);
  }
      t1258 = t1330;
    } else {
      shen_simple_error(ctx, "No true case found for cond");
      t1258 = shen_empty_list(ctx);
    }
    }
    }
    }
  }
    return t1258;
  }
}

static KLObject* native_kl_shen_2especialise_2dmember_33 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t1332 = objects[0];
    KLObject* t1333 = objects[1];
    KLObject* t1334 = objects[2];
    KLObject* t1335 = objects[3];
  tail_start_kl_shen_2especialise_2dmember_33: ;
  KLObject* t1337 = shen_intern(ctx, "shen.member");
  KLObject* t1336;
  {
    KLObject* a1336[] = {t1337};
    t1336 = shen_apply_direct(ctx, "gensym", 1, a1336);
  }
  KLObject* t1338;
  {
    KLObject* a1338[] = {t1336, t1332, t1334, t1335};
    t1338 = shen_apply_direct(ctx, "shen.member-clause", 4, a1338);
  }
  KLObject* t1345;
  {
    KLObject* a1345[] = {t1334, t1335};
    t1345 = shen_apply_direct(ctx, "append", 2, a1345);
  }
  KLObject* t1348 = shen_cons(ctx, t1333, t1345);
  KLObject* t1349 = shen_cons(ctx, t1336, t1348);
    return t1349;
  }
}

static KLObject* native_kl_shen_2eremove_2dbystanders_34 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t1350 = objects[0];
    KLObject* t1351 = objects[1];
  tail_start_kl_shen_2eremove_2dbystanders_34: ;
  KLObject* t1352;
  {
  KLObject* t1353 = shen_empty_list(ctx);
  KLObject* t1355 = shen_eq(ctx, t1353, t1350);
    if (!shen_is_boolean(ctx, t1355))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t1355)) {
  KLObject* t1356 = shen_empty_list(ctx);
      t1352 = t1356;
    } else {
  KLObject* t1359 = shen_cons_p(ctx, t1350);
  KLObject* t1357;
  if (!shen_is_boolean(ctx, t1359))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t1359)) {
    t1357 = t1359;
  } else {
  KLObject* t1362 = shen_hd(ctx, t1350);
  KLObject* t1360;
  {
    KLObject* a1360[] = {t1362, t1351};
    t1360 = shen_apply_direct(ctx, "shen.occurs-check?", 2, a1360);
  }
    if (!shen_is_boolean(ctx, t1360))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t1357 = t1360;
  }
    if (!shen_is_boolean(ctx, t1357))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t1357)) {
  KLObject* t1365 = shen_hd(ctx, t1350);
  KLObject* t1368 = shen_tl(ctx, t1350);
  KLObject* t1366;
  {
    KLObject* a1366[] = {t1368, t1351};
    t1366 = shen_apply_direct(ctx, "shen.remove-bystanders", 2, a1366);
  }
  KLObject* t1370 = shen_cons(ctx, t1365, t1366);
      t1352 = t1370;
    } else {
  KLObject* t1372 = shen_cons_p(ctx, t1350);
    if (!shen_is_boolean(ctx, t1372))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t1372)) {
  KLObject* t1374 = shen_tl(ctx, t1350);
  {
    KLObject* n1376_0 = t1374;
    KLObject* n1376_1 = t1351;
    t1350 = n1376_0;
    t1351 = n1376_1;
    goto tail_start_kl_shen_2eremove_2dbystanders_34;
  }
  KLObject* t1376 = NULL;
      t1352 = t1376;
    } else {
  KLObject* t1377 = shen_true(ctx);
    if (!shen_is_boolean(ctx, t1377))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t1377)) {
  KLObject* t1379 = shen_string(ctx, "partial function shen.remove-bystanders");
  KLObject* t1378;
  {
    KLObject* a1378[] = {t1379};
    t1378 = shen_tail_apply_direct(ctx, "simple-error", 1, a1378);
  }
      t1352 = t1378;
    } else {
      shen_simple_error(ctx, "No true case found for cond");
      t1352 = shen_empty_list(ctx);
    }
    }
    }
    }
  }
    return t1352;
  }
}

static KLObject* native_kl_shen_2emember_2dclause_35 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t1380 = objects[0];
    KLObject* t1381 = objects[1];
    KLObject* t1382 = objects[2];
    KLObject* t1383 = objects[3];
  tail_start_kl_shen_2emember_2dclause_35: ;
  KLObject* t1385;
  {
    KLObject* a1385[] = {t1383};
    t1385 = shen_apply_direct(ctx, "length", 1, a1385);
  }
  KLObject* t1384;
  {
    KLObject* a1384[] = {t1385};
    t1384 = shen_apply_direct(ctx, "shen.nvars", 1, a1384);
  }
  KLObject* t1388 = shen_intern(ctx, "-");
  KLObject* t1389 = shen_intern(ctx, "cons");
  KLObject* t1390;
  {
    KLObject* a1390[] = {t1381};
    t1390 = shen_apply_direct(ctx, "shen.macro-@ch", 1, a1390);
  }
  KLObject* t1392 = shen_intern(ctx, "_");
  KLObject* t1393 = shen_empty_list(ctx);
  KLObject* t1394 = shen_cons(ctx, t1392, t1393);
  KLObject* t1395 = shen_cons(ctx, t1390, t1394);
  KLObject* t1396 = shen_cons(ctx, t1389, t1395);
  KLObject* t1397 = shen_empty_list(ctx);
  KLObject* t1398 = shen_cons(ctx, t1396, t1397);
  KLObject* t1399 = shen_cons(ctx, t1388, t1398);
  KLObject* t1400 = shen_empty_list(ctx);
  KLObject* t1401 = shen_cons(ctx, t1399, t1400);
  KLObject* t1407 = shen_intern(ctx, "<--");
  KLObject* t1408 = shen_empty_list(ctx);
  KLObject* t1409 = shen_cons(ctx, t1407, t1408);
  KLObject* t1411;
  {
    KLObject* a1411[] = {t1383, t1384};
    t1411 = shen_apply_direct(ctx, "shen.passive-bind", 2, a1411);
  }
  KLObject* t1415 = shen_string(ctx, ";");
  KLObject* t1414;
  {
    KLObject* a1414[] = {t1415};
    t1414 = shen_apply_direct(ctx, "intern", 1, a1414);
  }
  KLObject* t1416 = shen_empty_list(ctx);
  KLObject* t1417 = shen_cons(ctx, t1414, t1416);
  KLObject* t1410;
  {
    KLObject* a1410[] = {t1411, t1417};
    t1410 = shen_apply_direct(ctx, "append", 2, a1410);
  }
  KLObject* t1406;
  {
    KLObject* a1406[] = {t1409, t1410};
    t1406 = shen_apply_direct(ctx, "append", 2, a1406);
  }
  KLObject* t1404;
  {
    KLObject* a1404[] = {t1384, t1406};
    t1404 = shen_apply_direct(ctx, "append", 2, a1404);
  }
  KLObject* t1402;
  {
    KLObject* a1402[] = {t1382, t1404};
    t1402 = shen_apply_direct(ctx, "append", 2, a1402);
  }
  KLObject* t1387;
  {
    KLObject* a1387[] = {t1401, t1402};
    t1387 = shen_apply_direct(ctx, "append", 2, a1387);
  }
  KLObject* t1419 = shen_intern(ctx, "Hypotheses");
  KLObject* t1418;
  {
    KLObject* a1418[] = {t1419};
    t1418 = shen_apply_direct(ctx, "gensym", 1, a1418);
  }
  KLObject* t1420;
  {
    KLObject* a1420[] = {t1382, t1383};
    t1420 = shen_apply_direct(ctx, "append", 2, a1420);
  }
  KLObject* t1424 = shen_intern(ctx, "-");
  KLObject* t1425 = shen_intern(ctx, "cons");
  KLObject* t1426 = shen_intern(ctx, "_");
  KLObject* t1428 = shen_empty_list(ctx);
  KLObject* t1429 = shen_cons(ctx, t1418, t1428);
  KLObject* t1430 = shen_cons(ctx, t1426, t1429);
  KLObject* t1431 = shen_cons(ctx, t1425, t1430);
  KLObject* t1432 = shen_empty_list(ctx);
  KLObject* t1433 = shen_cons(ctx, t1431, t1432);
  KLObject* t1434 = shen_cons(ctx, t1424, t1433);
  KLObject* t1435 = shen_empty_list(ctx);
  KLObject* t1436 = shen_cons(ctx, t1434, t1435);
  KLObject* t1423;
  {
    KLObject* a1423[] = {t1436, t1420};
    t1423 = shen_apply_direct(ctx, "append", 2, a1423);
  }
  KLObject* t1441 = shen_cons(ctx, t1418, t1420);
  KLObject* t1442 = shen_cons(ctx, t1380, t1441);
  KLObject* t1443 = shen_empty_list(ctx);
  KLObject* t1444 = shen_cons(ctx, t1442, t1443);
  KLObject* t1448 = shen_intern(ctx, "<--");
  KLObject* t1449 = shen_empty_list(ctx);
  KLObject* t1450 = shen_cons(ctx, t1448, t1449);
  KLObject* t1454 = shen_string(ctx, ";");
  KLObject* t1453;
  {
    KLObject* a1453[] = {t1454};
    t1453 = shen_apply_direct(ctx, "intern", 1, a1453);
  }
  KLObject* t1455 = shen_empty_list(ctx);
  KLObject* t1456 = shen_cons(ctx, t1453, t1455);
  KLObject* t1451;
  {
    KLObject* a1451[] = {t1444, t1456};
    t1451 = shen_apply_direct(ctx, "append", 2, a1451);
  }
  KLObject* t1447;
  {
    KLObject* a1447[] = {t1450, t1451};
    t1447 = shen_apply_direct(ctx, "append", 2, a1447);
  }
  KLObject* t1445;
  {
    KLObject* a1445[] = {t1423, t1447};
    t1445 = shen_apply_direct(ctx, "append", 2, a1445);
  }
  KLObject* t1457 = shen_intern(ctx, "defprolog");
  KLObject* t1459;
  {
    KLObject* a1459[] = {t1387, t1445};
    t1459 = shen_apply_direct(ctx, "append", 2, a1459);
  }
  KLObject* t1462 = shen_cons(ctx, t1380, t1459);
  KLObject* t1463 = shen_cons(ctx, t1457, t1462);
  KLObject* t1464;
  {
    KLObject* a1464[] = {t1463};
    t1464 = shen_tail_apply_direct(ctx, "eval", 1, a1464);
  }
    return t1464;
  }
}

static KLObject* native_kl_shen_2envars_36 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t1466 = objects[0];
  tail_start_kl_shen_2envars_36: ;
  KLObject* t1467;
  {
  KLObject* t1468 = shen_number_l(ctx, 0);
  KLObject* t1470 = shen_eq(ctx, t1468, t1466);
    if (!shen_is_boolean(ctx, t1470))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t1470)) {
  KLObject* t1471 = shen_empty_list(ctx);
      t1467 = t1471;
    } else {
  KLObject* t1472 = shen_true(ctx);
    if (!shen_is_boolean(ctx, t1472))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t1472)) {
  KLObject* t1474 = shen_intern(ctx, "NewV");
  KLObject* t1473;
  {
    KLObject* a1473[] = {t1474};
    t1473 = shen_apply_direct(ctx, "gensym", 1, a1473);
  }
  KLObject* t1477 = shen_number_l(ctx, 1);
  KLObject* t1478 = shen_sub(ctx, t1466, t1477);
  KLObject* t1475;
  {
    KLObject* a1475[] = {t1478};
    t1475 = shen_apply_direct(ctx, "shen.nvars", 1, a1475);
  }
  KLObject* t1479 = shen_cons(ctx, t1473, t1475);
      t1467 = t1479;
    } else {
      shen_simple_error(ctx, "No true case found for cond");
      t1467 = shen_empty_list(ctx);
    }
    }
  }
    return t1467;
  }
}

static KLObject* native_kl_shen_2epassive_2dbind_37 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t1480 = objects[0];
    KLObject* t1481 = objects[1];
  tail_start_kl_shen_2epassive_2dbind_37: ;
  KLObject* t1482;
  {
  KLObject* t1484 = shen_empty_list(ctx);
  KLObject* t1486 = shen_eq(ctx, t1484, t1480);
  KLObject* t1483;
  if (!shen_is_boolean(ctx, t1486))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t1486)) {
    t1483 = t1486;
  } else {
  KLObject* t1487 = shen_empty_list(ctx);
  KLObject* t1489 = shen_eq(ctx, t1487, t1481);
    if (!shen_is_boolean(ctx, t1489))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t1483 = t1489;
  }
    if (!shen_is_boolean(ctx, t1483))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t1483)) {
  KLObject* t1490 = shen_empty_list(ctx);
      t1482 = t1490;
    } else {
  KLObject* t1493 = shen_cons_p(ctx, t1480);
  KLObject* t1491;
  if (!shen_is_boolean(ctx, t1493))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t1493)) {
    t1491 = t1493;
  } else {
  KLObject* t1495 = shen_cons_p(ctx, t1481);
    if (!shen_is_boolean(ctx, t1495))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t1491 = t1495;
  }
    if (!shen_is_boolean(ctx, t1491))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t1491)) {
  KLObject* t1496 = shen_intern(ctx, "bind");
  KLObject* t1498 = shen_hd(ctx, t1481);
  KLObject* t1500 = shen_hd(ctx, t1480);
  KLObject* t1501 = shen_empty_list(ctx);
  KLObject* t1502 = shen_cons(ctx, t1500, t1501);
  KLObject* t1503 = shen_cons(ctx, t1498, t1502);
  KLObject* t1504 = shen_cons(ctx, t1496, t1503);
  KLObject* t1507 = shen_tl(ctx, t1480);
  KLObject* t1509 = shen_tl(ctx, t1481);
  KLObject* t1505;
  {
    KLObject* a1505[] = {t1507, t1509};
    t1505 = shen_apply_direct(ctx, "shen.passive-bind", 2, a1505);
  }
  KLObject* t1510 = shen_cons(ctx, t1504, t1505);
      t1482 = t1510;
    } else {
  KLObject* t1511 = shen_true(ctx);
    if (!shen_is_boolean(ctx, t1511))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t1511)) {
  KLObject* t1513 = shen_string(ctx, "partial function shen.passive-bind");
  KLObject* t1512;
  {
    KLObject* a1512[] = {t1513};
    t1512 = shen_tail_apply_direct(ctx, "simple-error", 1, a1512);
  }
      t1482 = t1512;
    } else {
      shen_simple_error(ctx, "No true case found for cond");
      t1482 = shen_empty_list(ctx);
    }
    }
    }
  }
    return t1482;
  }
}

static KLObject* native_kl_shen_2especialise_2dconsume_38 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t1514 = objects[0];
    KLObject* t1515 = objects[1];
    KLObject* t1516 = objects[2];
    KLObject* t1517 = objects[3];
    KLObject* t1518 = objects[4];
  tail_start_kl_shen_2especialise_2dconsume_38: ;
  KLObject* t1520 = shen_intern(ctx, "shen.consume");
  KLObject* t1519;
  {
    KLObject* a1519[] = {t1520};
    t1519 = shen_apply_direct(ctx, "gensym", 1, a1519);
  }
  KLObject* t1521;
  {
    KLObject* a1521[] = {t1519, t1514, t1516, t1517, t1518};
    t1521 = shen_apply_direct(ctx, "shen.consume-clause", 5, a1521);
  }
  KLObject* t1530;
  {
    KLObject* a1530[] = {t1516, t1517};
    t1530 = shen_apply_direct(ctx, "append", 2, a1530);
  }
  KLObject* t1533 = shen_cons(ctx, t1518, t1530);
  KLObject* t1534 = shen_cons(ctx, t1515, t1533);
  KLObject* t1535 = shen_cons(ctx, t1519, t1534);
    return t1535;
  }
}

static KLObject* native_kl_shen_2econsume_2dclause_39 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t1536 = objects[0];
    KLObject* t1537 = objects[1];
    KLObject* t1538 = objects[2];
    KLObject* t1539 = objects[3];
    KLObject* t1540 = objects[4];
  tail_start_kl_shen_2econsume_2dclause_39: ;
  KLObject* t1542;
  {
    KLObject* a1542[] = {t1539};
    t1542 = shen_apply_direct(ctx, "length", 1, a1542);
  }
  KLObject* t1541;
  {
    KLObject* a1541[] = {t1542};
    t1541 = shen_apply_direct(ctx, "shen.nvars", 1, a1541);
  }
  KLObject* t1545 = shen_intern(ctx, "Assumption");
  KLObject* t1544;
  {
    KLObject* a1544[] = {t1545};
    t1544 = shen_apply_direct(ctx, "gensym", 1, a1544);
  }
  KLObject* t1546 = shen_intern(ctx, "-");
  KLObject* t1547 = shen_intern(ctx, "cons");
  KLObject* t1548;
  {
    KLObject* a1548[] = {t1537};
    t1548 = shen_apply_direct(ctx, "shen.macro-@ch", 1, a1548);
  }
  KLObject* t1551 = shen_empty_list(ctx);
  KLObject* t1552 = shen_cons(ctx, t1544, t1551);
  KLObject* t1553 = shen_cons(ctx, t1548, t1552);
  KLObject* t1554 = shen_cons(ctx, t1547, t1553);
  KLObject* t1555 = shen_empty_list(ctx);
  KLObject* t1556 = shen_cons(ctx, t1554, t1555);
  KLObject* t1557 = shen_cons(ctx, t1546, t1556);
  KLObject* t1564 = shen_intern(ctx, "<--");
  KLObject* t1565 = shen_empty_list(ctx);
  KLObject* t1566 = shen_cons(ctx, t1564, t1565);
  KLObject* t1568;
  {
    KLObject* a1568[] = {t1539, t1541};
    t1568 = shen_apply_direct(ctx, "shen.passive-bind", 2, a1568);
  }
  KLObject* t1571 = shen_intern(ctx, "bind");
  KLObject* t1574 = shen_empty_list(ctx);
  KLObject* t1575 = shen_cons(ctx, t1544, t1574);
  KLObject* t1576 = shen_cons(ctx, t1540, t1575);
  KLObject* t1577 = shen_cons(ctx, t1571, t1576);
  KLObject* t1579 = shen_string(ctx, ";");
  KLObject* t1578;
  {
    KLObject* a1578[] = {t1579};
    t1578 = shen_apply_direct(ctx, "intern", 1, a1578);
  }
  KLObject* t1580 = shen_empty_list(ctx);
  KLObject* t1581 = shen_cons(ctx, t1578, t1580);
  KLObject* t1582 = shen_cons(ctx, t1577, t1581);
  KLObject* t1567;
  {
    KLObject* a1567[] = {t1568, t1582};
    t1567 = shen_apply_direct(ctx, "append", 2, a1567);
  }
  KLObject* t1563;
  {
    KLObject* a1563[] = {t1566, t1567};
    t1563 = shen_apply_direct(ctx, "append", 2, a1563);
  }
  KLObject* t1561;
  {
    KLObject* a1561[] = {t1541, t1563};
    t1561 = shen_apply_direct(ctx, "append", 2, a1561);
  }
  KLObject* t1559;
  {
    KLObject* a1559[] = {t1538, t1561};
    t1559 = shen_apply_direct(ctx, "append", 2, a1559);
  }
  KLObject* t1583 = shen_cons(ctx, t1540, t1559);
  KLObject* t1584 = shen_cons(ctx, t1557, t1583);
  KLObject* t1586 = shen_intern(ctx, "Hypotheses");
  KLObject* t1585;
  {
    KLObject* a1585[] = {t1586};
    t1585 = shen_apply_direct(ctx, "gensym", 1, a1585);
  }
  KLObject* t1587;
  {
    KLObject* a1587[] = {t1538, t1539};
    t1587 = shen_apply_direct(ctx, "append", 2, a1587);
  }
  KLObject* t1591 = shen_intern(ctx, "Assumptions");
  KLObject* t1590;
  {
    KLObject* a1590[] = {t1591};
    t1590 = shen_apply_direct(ctx, "gensym", 1, a1590);
  }
  KLObject* t1592 = shen_intern(ctx, "-");
  KLObject* t1593 = shen_intern(ctx, "cons");
  KLObject* t1596 = shen_empty_list(ctx);
  KLObject* t1597 = shen_cons(ctx, t1585, t1596);
  KLObject* t1598 = shen_cons(ctx, t1544, t1597);
  KLObject* t1599 = shen_cons(ctx, t1593, t1598);
  KLObject* t1600 = shen_empty_list(ctx);
  KLObject* t1601 = shen_cons(ctx, t1599, t1600);
  KLObject* t1602 = shen_cons(ctx, t1592, t1601);
  KLObject* t1603 = shen_intern(ctx, "cons");
  KLObject* t1606 = shen_empty_list(ctx);
  KLObject* t1607 = shen_cons(ctx, t1540, t1606);
  KLObject* t1608 = shen_cons(ctx, t1590, t1607);
  KLObject* t1609 = shen_cons(ctx, t1603, t1608);
  KLObject* t1611 = shen_cons(ctx, t1609, t1587);
  KLObject* t1612 = shen_cons(ctx, t1602, t1611);
  KLObject* t1613 = shen_intern(ctx, "bind");
  KLObject* t1616 = shen_empty_list(ctx);
  KLObject* t1617 = shen_cons(ctx, t1544, t1616);
  KLObject* t1618 = shen_cons(ctx, t1590, t1617);
  KLObject* t1619 = shen_cons(ctx, t1613, t1618);
  KLObject* t1624 = shen_cons(ctx, t1540, t1587);
  KLObject* t1625 = shen_cons(ctx, t1585, t1624);
  KLObject* t1626 = shen_cons(ctx, t1536, t1625);
  KLObject* t1627 = shen_empty_list(ctx);
  KLObject* t1628 = shen_cons(ctx, t1626, t1627);
  KLObject* t1629 = shen_cons(ctx, t1619, t1628);
  KLObject* t1633 = shen_intern(ctx, "<--");
  KLObject* t1634 = shen_empty_list(ctx);
  KLObject* t1635 = shen_cons(ctx, t1633, t1634);
  KLObject* t1639 = shen_string(ctx, ";");
  KLObject* t1638;
  {
    KLObject* a1638[] = {t1639};
    t1638 = shen_apply_direct(ctx, "intern", 1, a1638);
  }
  KLObject* t1640 = shen_empty_list(ctx);
  KLObject* t1641 = shen_cons(ctx, t1638, t1640);
  KLObject* t1636;
  {
    KLObject* a1636[] = {t1629, t1641};
    t1636 = shen_apply_direct(ctx, "append", 2, a1636);
  }
  KLObject* t1632;
  {
    KLObject* a1632[] = {t1635, t1636};
    t1632 = shen_apply_direct(ctx, "append", 2, a1632);
  }
  KLObject* t1630;
  {
    KLObject* a1630[] = {t1612, t1632};
    t1630 = shen_apply_direct(ctx, "append", 2, a1630);
  }
  KLObject* t1642 = shen_intern(ctx, "defprolog");
  KLObject* t1644;
  {
    KLObject* a1644[] = {t1584, t1630};
    t1644 = shen_apply_direct(ctx, "append", 2, a1644);
  }
  KLObject* t1647 = shen_cons(ctx, t1536, t1644);
  KLObject* t1648 = shen_cons(ctx, t1642, t1647);
  KLObject* t1649;
  {
    KLObject* a1649[] = {t1648};
    t1649 = shen_tail_apply_direct(ctx, "eval", 1, a1649);
  }
    return t1649;
  }
}

static KLObject* native_kl_shen_2epassive_2dvariables_40 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t1651 = objects[0];
    KLObject* t1652 = objects[1];
  tail_start_kl_shen_2epassive_2dvariables_40: ;
  KLObject* t1654;
  {
    KLObject* a1654[] = {t1651};
    t1654 = shen_apply_direct(ctx, "shen.extract-vars", 1, a1654);
  }
  KLObject* t1653;
  {
    KLObject* a1653[] = {t1654, t1652};
    t1653 = shen_tail_apply_direct(ctx, "difference", 2, a1653);
  }
    return t1653;
  }
}

static KLObject* native_kl_shen_2eside_2dconditions_2d_3egoals_41 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t1657 = objects[0];
    KLObject* t1658 = objects[1];
    KLObject* t1659 = objects[2];
    KLObject* t1660 = objects[3];
    KLObject* t1661 = objects[4];
  tail_start_kl_shen_2eside_2dconditions_2d_3egoals_41: ;
  KLObject* t1662;
  {
  KLObject* t1663 = shen_empty_list(ctx);
  KLObject* t1665 = shen_eq(ctx, t1663, t1660);
    if (!shen_is_boolean(ctx, t1665))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t1665)) {
  KLObject* t1666;
  {
    KLObject* a1666[] = {t1657, t1659, t1661};
    t1666 = shen_tail_apply_direct(ctx, "shen.premises->goals", 3, a1666);
  }
      t1662 = t1666;
    } else {
  KLObject* t1672 = shen_cons_p(ctx, t1660);
  KLObject* t1670;
  if (!shen_is_boolean(ctx, t1672))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t1672)) {
    t1670 = t1672;
  } else {
  KLObject* t1675 = shen_hd(ctx, t1660);
  KLObject* t1676 = shen_cons_p(ctx, t1675);
  KLObject* t1673;
  if (!shen_is_boolean(ctx, t1676))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t1676)) {
    t1673 = t1676;
  } else {
  KLObject* t1678 = shen_intern(ctx, "if");
  KLObject* t1680 = shen_hd(ctx, t1660);
  KLObject* t1681 = shen_hd(ctx, t1680);
  KLObject* t1682 = shen_eq(ctx, t1678, t1681);
  KLObject* t1677;
  if (!shen_is_boolean(ctx, t1682))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t1682)) {
    t1677 = t1682;
  } else {
  KLObject* t1685 = shen_hd(ctx, t1660);
  KLObject* t1686 = shen_tl(ctx, t1685);
  KLObject* t1687 = shen_cons_p(ctx, t1686);
  KLObject* t1683;
  if (!shen_is_boolean(ctx, t1687))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t1687)) {
    t1683 = t1687;
  } else {
  KLObject* t1688 = shen_empty_list(ctx);
  KLObject* t1690 = shen_hd(ctx, t1660);
  KLObject* t1691 = shen_tl(ctx, t1690);
  KLObject* t1692 = shen_tl(ctx, t1691);
  KLObject* t1693 = shen_eq(ctx, t1688, t1692);
    if (!shen_is_boolean(ctx, t1693))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t1683 = t1693;
  }
    if (!shen_is_boolean(ctx, t1683))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t1677 = t1683;
  }
    if (!shen_is_boolean(ctx, t1677))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t1673 = t1677;
  }
    if (!shen_is_boolean(ctx, t1673))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t1670 = t1673;
  }
    if (!shen_is_boolean(ctx, t1670))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t1670)) {
  KLObject* t1694 = shen_intern(ctx, "when");
  KLObject* t1696 = shen_hd(ctx, t1660);
  KLObject* t1697 = shen_tl(ctx, t1696);
  KLObject* t1698 = shen_cons(ctx, t1694, t1697);
  KLObject* t1704 = shen_tl(ctx, t1660);
  KLObject* t1699;
  {
    KLObject* a1699[] = {t1657, t1658, t1659, t1704, t1661};
    t1699 = shen_apply_direct(ctx, "shen.side-conditions->goals", 5, a1699);
  }
  KLObject* t1706 = shen_cons(ctx, t1698, t1699);
      t1662 = t1706;
    } else {
  KLObject* t1709 = shen_cons_p(ctx, t1660);
  KLObject* t1707;
  if (!shen_is_boolean(ctx, t1709))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t1709)) {
    t1707 = t1709;
  } else {
  KLObject* t1712 = shen_hd(ctx, t1660);
  KLObject* t1713 = shen_cons_p(ctx, t1712);
  KLObject* t1710;
  if (!shen_is_boolean(ctx, t1713))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t1713)) {
    t1710 = t1713;
  } else {
  KLObject* t1715 = shen_intern(ctx, "let");
  KLObject* t1717 = shen_hd(ctx, t1660);
  KLObject* t1718 = shen_hd(ctx, t1717);
  KLObject* t1719 = shen_eq(ctx, t1715, t1718);
  KLObject* t1714;
  if (!shen_is_boolean(ctx, t1719))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t1719)) {
    t1714 = t1719;
  } else {
  KLObject* t1722 = shen_hd(ctx, t1660);
  KLObject* t1723 = shen_tl(ctx, t1722);
  KLObject* t1724 = shen_cons_p(ctx, t1723);
  KLObject* t1720;
  if (!shen_is_boolean(ctx, t1724))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t1724)) {
    t1720 = t1724;
  } else {
  KLObject* t1727 = shen_hd(ctx, t1660);
  KLObject* t1728 = shen_tl(ctx, t1727);
  KLObject* t1729 = shen_tl(ctx, t1728);
  KLObject* t1730 = shen_cons_p(ctx, t1729);
  KLObject* t1725;
  if (!shen_is_boolean(ctx, t1730))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t1730)) {
    t1725 = t1730;
  } else {
  KLObject* t1731 = shen_empty_list(ctx);
  KLObject* t1733 = shen_hd(ctx, t1660);
  KLObject* t1734 = shen_tl(ctx, t1733);
  KLObject* t1735 = shen_tl(ctx, t1734);
  KLObject* t1736 = shen_tl(ctx, t1735);
  KLObject* t1737 = shen_eq(ctx, t1731, t1736);
    if (!shen_is_boolean(ctx, t1737))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t1725 = t1737;
  }
    if (!shen_is_boolean(ctx, t1725))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t1720 = t1725;
  }
    if (!shen_is_boolean(ctx, t1720))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t1714 = t1720;
  }
    if (!shen_is_boolean(ctx, t1714))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t1710 = t1714;
  }
    if (!shen_is_boolean(ctx, t1710))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t1707 = t1710;
  }
    if (!shen_is_boolean(ctx, t1707))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t1707)) {
  KLObject* t1741 = shen_hd(ctx, t1660);
  KLObject* t1742 = shen_tl(ctx, t1741);
  KLObject* t1743 = shen_hd(ctx, t1742);
  KLObject* t1739;
  {
    KLObject* a1739[] = {t1743, t1658};
    t1739 = shen_apply_direct(ctx, "element?", 2, a1739);
  }
  KLObject* t1738;
  if (!shen_is_boolean(ctx, t1739))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1739)) {
  KLObject* t1745 = shen_intern(ctx, "is!");
  KLObject* t1747 = shen_hd(ctx, t1660);
  KLObject* t1748 = shen_tl(ctx, t1747);
  KLObject* t1749 = shen_cons(ctx, t1745, t1748);
  KLObject* t1755 = shen_tl(ctx, t1660);
  KLObject* t1750;
  {
    KLObject* a1750[] = {t1657, t1658, t1659, t1755, t1661};
    t1750 = shen_apply_direct(ctx, "shen.side-conditions->goals", 5, a1750);
  }
  KLObject* t1757 = shen_cons(ctx, t1749, t1750);
    t1738 = t1757;
  } else {
  KLObject* t1758 = shen_intern(ctx, "bind");
  KLObject* t1760 = shen_hd(ctx, t1660);
  KLObject* t1761 = shen_tl(ctx, t1760);
  KLObject* t1762 = shen_cons(ctx, t1758, t1761);
  KLObject* t1766 = shen_hd(ctx, t1660);
  KLObject* t1767 = shen_tl(ctx, t1766);
  KLObject* t1768 = shen_hd(ctx, t1767);
  KLObject* t1770 = shen_cons(ctx, t1768, t1658);
  KLObject* t1773 = shen_tl(ctx, t1660);
  KLObject* t1763;
  {
    KLObject* a1763[] = {t1657, t1770, t1659, t1773, t1661};
    t1763 = shen_apply_direct(ctx, "shen.side-conditions->goals", 5, a1763);
  }
  KLObject* t1775 = shen_cons(ctx, t1762, t1763);
    t1738 = t1775;
  }
      t1662 = t1738;
    } else {
  KLObject* t1778 = shen_cons_p(ctx, t1660);
  KLObject* t1776;
  if (!shen_is_boolean(ctx, t1778))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t1778)) {
    t1776 = t1778;
  } else {
  KLObject* t1781 = shen_hd(ctx, t1660);
  KLObject* t1782 = shen_cons_p(ctx, t1781);
  KLObject* t1779;
  if (!shen_is_boolean(ctx, t1782))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t1782)) {
    t1779 = t1782;
  } else {
  KLObject* t1784 = shen_intern(ctx, "ctxt");
  KLObject* t1786 = shen_hd(ctx, t1660);
  KLObject* t1787 = shen_hd(ctx, t1786);
  KLObject* t1788 = shen_eq(ctx, t1784, t1787);
  KLObject* t1783;
  if (!shen_is_boolean(ctx, t1788))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t1788)) {
    t1783 = t1788;
  } else {
  KLObject* t1791 = shen_hd(ctx, t1660);
  KLObject* t1792 = shen_tl(ctx, t1791);
  KLObject* t1793 = shen_cons_p(ctx, t1792);
  KLObject* t1789;
  if (!shen_is_boolean(ctx, t1793))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t1793)) {
    t1789 = t1793;
  } else {
  KLObject* t1794 = shen_empty_list(ctx);
  KLObject* t1796 = shen_hd(ctx, t1660);
  KLObject* t1797 = shen_tl(ctx, t1796);
  KLObject* t1798 = shen_tl(ctx, t1797);
  KLObject* t1799 = shen_eq(ctx, t1794, t1798);
    if (!shen_is_boolean(ctx, t1799))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t1789 = t1799;
  }
    if (!shen_is_boolean(ctx, t1789))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t1783 = t1789;
  }
    if (!shen_is_boolean(ctx, t1783))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t1779 = t1783;
  }
    if (!shen_is_boolean(ctx, t1779))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t1776 = t1779;
  }
    if (!shen_is_boolean(ctx, t1776))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t1776)) {
  KLObject* t1803 = shen_hd(ctx, t1660);
  KLObject* t1804 = shen_tl(ctx, t1803);
  KLObject* t1805 = shen_hd(ctx, t1804);
  KLObject* t1801;
  {
    KLObject* a1801[] = {t1805, t1658};
    t1801 = shen_apply_direct(ctx, "element?", 2, a1801);
  }
  KLObject* t1800;
  if (!shen_is_boolean(ctx, t1801))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1801)) {
  KLObject* t1808 = shen_hd(ctx, t1660);
  KLObject* t1809 = shen_tl(ctx, t1808);
  KLObject* t1810 = shen_hd(ctx, t1809);
  KLObject* t1812 = shen_cons(ctx, t1810, t1657);
  KLObject* t1816 = shen_tl(ctx, t1660);
  {
    KLObject* n1818_0 = t1812;
    KLObject* n1818_1 = t1658;
    KLObject* n1818_2 = t1659;
    KLObject* n1818_3 = t1816;
    KLObject* n1818_4 = t1661;
    t1657 = n1818_0;
    t1658 = n1818_1;
    t1659 = n1818_2;
    t1660 = n1818_3;
    t1661 = n1818_4;
    goto tail_start_kl_shen_2eside_2dconditions_2d_3egoals_41;
  }
  KLObject* t1818 = NULL;
    t1800 = t1818;
  } else {
  KLObject* t1819 = shen_intern(ctx, "bind");
  KLObject* t1821 = shen_hd(ctx, t1660);
  KLObject* t1822 = shen_tl(ctx, t1821);
  KLObject* t1823 = shen_hd(ctx, t1822);
  KLObject* t1825 = shen_empty_list(ctx);
  KLObject* t1826 = shen_cons(ctx, t1659, t1825);
  KLObject* t1827 = shen_cons(ctx, t1823, t1826);
  KLObject* t1828 = shen_cons(ctx, t1819, t1827);
  KLObject* t1831 = shen_hd(ctx, t1660);
  KLObject* t1832 = shen_tl(ctx, t1831);
  KLObject* t1833 = shen_hd(ctx, t1832);
  KLObject* t1835 = shen_cons(ctx, t1833, t1657);
  KLObject* t1837 = shen_hd(ctx, t1660);
  KLObject* t1838 = shen_tl(ctx, t1837);
  KLObject* t1839 = shen_hd(ctx, t1838);
  KLObject* t1841 = shen_cons(ctx, t1839, t1658);
  KLObject* t1843 = shen_hd(ctx, t1660);
  KLObject* t1844 = shen_tl(ctx, t1843);
  KLObject* t1845 = shen_hd(ctx, t1844);
  KLObject* t1847 = shen_tl(ctx, t1660);
  KLObject* t1829;
  {
    KLObject* a1829[] = {t1835, t1841, t1845, t1847, t1661};
    t1829 = shen_apply_direct(ctx, "shen.side-conditions->goals", 5, a1829);
  }
  KLObject* t1849 = shen_cons(ctx, t1828, t1829);
    t1800 = t1849;
  }
      t1662 = t1800;
    } else {
  KLObject* t1852 = shen_cons_p(ctx, t1660);
  KLObject* t1850;
  if (!shen_is_boolean(ctx, t1852))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t1852)) {
    t1850 = t1852;
  } else {
  KLObject* t1855 = shen_hd(ctx, t1660);
  KLObject* t1856 = shen_cons_p(ctx, t1855);
  KLObject* t1853;
  if (!shen_is_boolean(ctx, t1856))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t1856)) {
    t1853 = t1856;
  } else {
  KLObject* t1858 = shen_intern(ctx, "sqts");
  KLObject* t1860 = shen_hd(ctx, t1660);
  KLObject* t1861 = shen_hd(ctx, t1860);
  KLObject* t1862 = shen_eq(ctx, t1858, t1861);
  KLObject* t1857;
  if (!shen_is_boolean(ctx, t1862))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t1862)) {
    t1857 = t1862;
  } else {
  KLObject* t1865 = shen_hd(ctx, t1660);
  KLObject* t1866 = shen_tl(ctx, t1865);
  KLObject* t1867 = shen_cons_p(ctx, t1866);
  KLObject* t1863;
  if (!shen_is_boolean(ctx, t1867))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t1867)) {
    t1863 = t1867;
  } else {
  KLObject* t1868 = shen_empty_list(ctx);
  KLObject* t1870 = shen_hd(ctx, t1660);
  KLObject* t1871 = shen_tl(ctx, t1870);
  KLObject* t1872 = shen_tl(ctx, t1871);
  KLObject* t1873 = shen_eq(ctx, t1868, t1872);
    if (!shen_is_boolean(ctx, t1873))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t1863 = t1873;
  }
    if (!shen_is_boolean(ctx, t1863))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t1857 = t1863;
  }
    if (!shen_is_boolean(ctx, t1857))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t1853 = t1857;
  }
    if (!shen_is_boolean(ctx, t1853))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t1850 = t1853;
  }
    if (!shen_is_boolean(ctx, t1850))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t1850)) {
  KLObject* t1878 = shen_tl(ctx, t1660);
  {
    KLObject* n1880_0 = t1657;
    KLObject* n1880_1 = t1658;
    KLObject* n1880_2 = t1659;
    KLObject* n1880_3 = t1878;
    KLObject* n1880_4 = t1661;
    t1657 = n1880_0;
    t1658 = n1880_1;
    t1659 = n1880_2;
    t1660 = n1880_3;
    t1661 = n1880_4;
    goto tail_start_kl_shen_2eside_2dconditions_2d_3egoals_41;
  }
  KLObject* t1880 = NULL;
      t1662 = t1880;
    } else {
  KLObject* t1881 = shen_true(ctx);
    if (!shen_is_boolean(ctx, t1881))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t1881)) {
  KLObject* t1883 = shen_string(ctx, "partial function shen.side-conditions->goals");
  KLObject* t1882;
  {
    KLObject* a1882[] = {t1883};
    t1882 = shen_tail_apply_direct(ctx, "simple-error", 1, a1882);
  }
      t1662 = t1882;
    } else {
      shen_simple_error(ctx, "No true case found for cond");
      t1662 = shen_empty_list(ctx);
    }
    }
    }
    }
    }
    }
  }
    return t1662;
  }
}

static KLObject* native_kl_shen_2epremises_2d_3egoals_42 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t1884 = objects[0];
    KLObject* t1885 = objects[1];
    KLObject* t1886 = objects[2];
  tail_start_kl_shen_2epremises_2d_3egoals_42: ;
  KLObject* t1887;
  {
  KLObject* t1888 = shen_empty_list(ctx);
  KLObject* t1890 = shen_eq(ctx, t1888, t1886);
    if (!shen_is_boolean(ctx, t1890))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t1890)) {
  KLObject* t1892 = shen_string(ctx, ";");
  KLObject* t1891;
  {
    KLObject* a1891[] = {t1892};
    t1891 = shen_apply_direct(ctx, "intern", 1, a1891);
  }
  KLObject* t1893 = shen_empty_list(ctx);
  KLObject* t1894 = shen_cons(ctx, t1891, t1893);
      t1887 = t1894;
    } else {
  KLObject* t1897 = shen_cons_p(ctx, t1886);
  KLObject* t1895;
  if (!shen_is_boolean(ctx, t1897))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t1897)) {
    t1895 = t1897;
  } else {
  KLObject* t1898 = shen_intern(ctx, "!");
  KLObject* t1900 = shen_hd(ctx, t1886);
  KLObject* t1901 = shen_eq(ctx, t1898, t1900);
    if (!shen_is_boolean(ctx, t1901))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t1895 = t1901;
  }
    if (!shen_is_boolean(ctx, t1895))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t1895)) {
  KLObject* t1902 = shen_intern(ctx, "!");
  KLObject* t1907 = shen_tl(ctx, t1886);
  KLObject* t1903;
  {
    KLObject* a1903[] = {t1884, t1885, t1907};
    t1903 = shen_apply_direct(ctx, "shen.premises->goals", 3, a1903);
  }
  KLObject* t1908 = shen_cons(ctx, t1902, t1903);
      t1887 = t1908;
    } else {
  KLObject* t1911 = shen_cons_p(ctx, t1886);
  KLObject* t1909;
  if (!shen_is_boolean(ctx, t1911))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t1911)) {
    t1909 = t1911;
  } else {
  KLObject* t1912 = shen_intern(ctx, "fail");
  KLObject* t1914 = shen_hd(ctx, t1886);
  KLObject* t1915 = shen_eq(ctx, t1912, t1914);
    if (!shen_is_boolean(ctx, t1915))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t1909 = t1915;
  }
    if (!shen_is_boolean(ctx, t1909))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t1909)) {
  KLObject* t1916 = shen_intern(ctx, "when");
  KLObject* t1917 = shen_false(ctx);
  KLObject* t1918 = shen_empty_list(ctx);
  KLObject* t1919 = shen_cons(ctx, t1917, t1918);
  KLObject* t1920 = shen_cons(ctx, t1916, t1919);
  KLObject* t1925 = shen_tl(ctx, t1886);
  KLObject* t1921;
  {
    KLObject* a1921[] = {t1884, t1885, t1925};
    t1921 = shen_apply_direct(ctx, "shen.premises->goals", 3, a1921);
  }
  KLObject* t1926 = shen_cons(ctx, t1920, t1921);
      t1887 = t1926;
    } else {
  KLObject* t1929 = shen_cons_p(ctx, t1886);
  KLObject* t1927;
  if (!shen_is_boolean(ctx, t1929))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t1929)) {
    t1927 = t1929;
  } else {
  KLObject* t1932 = shen_hd(ctx, t1886);
  KLObject* t1933 = shen_cons_p(ctx, t1932);
  KLObject* t1930;
  if (!shen_is_boolean(ctx, t1933))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t1933)) {
    t1930 = t1933;
  } else {
  KLObject* t1936 = shen_hd(ctx, t1886);
  KLObject* t1937 = shen_tl(ctx, t1936);
  KLObject* t1938 = shen_cons_p(ctx, t1937);
  KLObject* t1934;
  if (!shen_is_boolean(ctx, t1938))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t1938)) {
    t1934 = t1938;
  } else {
  KLObject* t1939 = shen_empty_list(ctx);
  KLObject* t1941 = shen_hd(ctx, t1886);
  KLObject* t1942 = shen_tl(ctx, t1941);
  KLObject* t1943 = shen_tl(ctx, t1942);
  KLObject* t1944 = shen_eq(ctx, t1939, t1943);
    if (!shen_is_boolean(ctx, t1944))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t1934 = t1944;
  }
    if (!shen_is_boolean(ctx, t1934))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t1930 = t1934;
  }
    if (!shen_is_boolean(ctx, t1930))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t1927 = t1930;
  }
    if (!shen_is_boolean(ctx, t1927))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t1927)) {
  KLObject* t1945 = shen_intern(ctx, "shen.system-S");
  KLObject* t1948 = shen_hd(ctx, t1886);
  KLObject* t1949 = shen_tl(ctx, t1948);
  KLObject* t1950 = shen_hd(ctx, t1949);
  KLObject* t1946;
  {
    KLObject* a1946[] = {t1950};
    t1946 = shen_apply_direct(ctx, "shen.macro-@c", 1, a1946);
  }
  KLObject* t1954 = shen_hd(ctx, t1886);
  KLObject* t1955 = shen_hd(ctx, t1954);
  KLObject* t1951;
  {
    KLObject* a1951[] = {t1884, t1955, t1885};
    t1951 = shen_apply_direct(ctx, "shen.construct-context", 3, a1951);
  }
  KLObject* t1957 = shen_empty_list(ctx);
  KLObject* t1958 = shen_cons(ctx, t1951, t1957);
  KLObject* t1959 = shen_cons(ctx, t1946, t1958);
  KLObject* t1960 = shen_cons(ctx, t1945, t1959);
  KLObject* t1965 = shen_tl(ctx, t1886);
  KLObject* t1961;
  {
    KLObject* a1961[] = {t1884, t1885, t1965};
    t1961 = shen_apply_direct(ctx, "shen.premises->goals", 3, a1961);
  }
  KLObject* t1966 = shen_cons(ctx, t1960, t1961);
      t1887 = t1966;
    } else {
  KLObject* t1967 = shen_true(ctx);
    if (!shen_is_boolean(ctx, t1967))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t1967)) {
  KLObject* t1969 = shen_string(ctx, "partial function shen.premises->goals");
  KLObject* t1968;
  {
    KLObject* a1968[] = {t1969};
    t1968 = shen_tail_apply_direct(ctx, "simple-error", 1, a1968);
  }
      t1887 = t1968;
    } else {
      shen_simple_error(ctx, "No true case found for cond");
      t1887 = shen_empty_list(ctx);
    }
    }
    }
    }
    }
  }
    return t1887;
  }
}

static KLObject* native_kl_shen_2econstruct_2dcontext_43 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t1970 = objects[0];
    KLObject* t1971 = objects[1];
    KLObject* t1972 = objects[2];
  tail_start_kl_shen_2econstruct_2dcontext_43: ;
  KLObject* t1973;
  {
  KLObject* t1974 = shen_empty_list(ctx);
  KLObject* t1976 = shen_eq(ctx, t1974, t1971);
    if (!shen_is_boolean(ctx, t1976))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t1976)) {
      t1973 = t1972;
    } else {
  KLObject* t1980 = shen_cons_p(ctx, t1971);
  KLObject* t1978;
  if (!shen_is_boolean(ctx, t1980))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t1980)) {
    t1978 = t1980;
  } else {
  KLObject* t1982 = shen_empty_list(ctx);
  KLObject* t1984 = shen_tl(ctx, t1971);
  KLObject* t1985 = shen_eq(ctx, t1982, t1984);
  KLObject* t1981;
  if (!shen_is_boolean(ctx, t1985))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t1985)) {
    t1981 = t1985;
  } else {
  KLObject* t1988 = shen_hd(ctx, t1971);
  KLObject* t1986;
  {
    KLObject* a1986[] = {t1988, t1970};
    t1986 = shen_apply_direct(ctx, "element?", 2, a1986);
  }
    if (!shen_is_boolean(ctx, t1986))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t1981 = t1986;
  }
    if (!shen_is_boolean(ctx, t1981))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t1978 = t1981;
  }
    if (!shen_is_boolean(ctx, t1978))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t1978)) {
  KLObject* t1991 = shen_hd(ctx, t1971);
      t1973 = t1991;
    } else {
  KLObject* t1993 = shen_cons_p(ctx, t1971);
    if (!shen_is_boolean(ctx, t1993))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t1993)) {
  KLObject* t1994 = shen_intern(ctx, "cons");
  KLObject* t1997 = shen_hd(ctx, t1971);
  KLObject* t1995;
  {
    KLObject* a1995[] = {t1997};
    t1995 = shen_apply_direct(ctx, "shen.macro-@c", 1, a1995);
  }
  KLObject* t2001 = shen_tl(ctx, t1971);
  KLObject* t1998;
  {
    KLObject* a1998[] = {t1970, t2001, t1972};
    t1998 = shen_apply_direct(ctx, "shen.construct-context", 3, a1998);
  }
  KLObject* t2003 = shen_empty_list(ctx);
  KLObject* t2004 = shen_cons(ctx, t1998, t2003);
  KLObject* t2005 = shen_cons(ctx, t1995, t2004);
  KLObject* t2006 = shen_cons(ctx, t1994, t2005);
      t1973 = t2006;
    } else {
  KLObject* t2007 = shen_true(ctx);
    if (!shen_is_boolean(ctx, t2007))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t2007)) {
  KLObject* t2009 = shen_string(ctx, "partial function shen.construct-context");
  KLObject* t2008;
  {
    KLObject* a2008[] = {t2009};
    t2008 = shen_tail_apply_direct(ctx, "simple-error", 1, a2008);
  }
      t1973 = t2008;
    } else {
      shen_simple_error(ctx, "No true case found for cond");
      t1973 = shen_empty_list(ctx);
    }
    }
    }
    }
  }
    return t1973;
  }
}

static KLObject* native_kl_preclude_44 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t2010 = objects[0];
  tail_start_kl_preclude_44: ;
  KLObject* t2012;
  {
    Vector* caps_1 = shen_vector(ctx, 0);
    t2012 = shen_native_closure(ctx, 1, &lambda_1, caps_1);
  }
  KLObject* t2011;
  {
    KLObject* a2011[] = {t2012, t2010};
    t2011 = shen_apply_direct(ctx, "map", 2, a2011);
  }
  KLObject* t2018 = shen_intern(ctx, "shen.*datatypes*");
  KLObject* t2017;
  {
    KLObject* a2017[] = {t2018};
    t2017 = shen_apply_direct(ctx, "value", 1, a2017);
  }
  KLObject* t2019;
  {
    KLObject* a2019[] = {t2011, t2017};
    t2019 = shen_apply_direct(ctx, "shen.remove-datatypes", 2, a2019);
  }
  KLObject* t2023 = shen_intern(ctx, "shen.*datatypes*");
  KLObject* t2022;
  {
    KLObject* a2022[] = {t2023, t2019};
    t2022 = shen_apply_direct(ctx, "set", 2, a2022);
  }
  KLObject* t2025;
  {
    KLObject* a2025[] = {t2022};
    t2025 = shen_tail_apply_direct(ctx, "shen.show-datatypes", 1, a2025);
  }
    return t2025;
  }
}

static KLObject* native_kl_shen_2eremove_2ddatatypes_45 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t2027 = objects[0];
    KLObject* t2028 = objects[1];
  tail_start_kl_shen_2eremove_2ddatatypes_45: ;
  KLObject* t2029;
  {
  KLObject* t2030 = shen_empty_list(ctx);
  KLObject* t2032 = shen_eq(ctx, t2030, t2027);
    if (!shen_is_boolean(ctx, t2032))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t2032)) {
      t2029 = t2028;
    } else {
  KLObject* t2035 = shen_cons_p(ctx, t2027);
    if (!shen_is_boolean(ctx, t2035))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t2035)) {
  KLObject* t2037 = shen_tl(ctx, t2027);
  KLObject* t2040 = shen_hd(ctx, t2027);
  KLObject* t2038;
  {
    KLObject* a2038[] = {t2040, t2028};
    t2038 = shen_apply_direct(ctx, "shen.unassoc", 2, a2038);
  }
  {
    KLObject* n2042_0 = t2037;
    KLObject* n2042_1 = t2038;
    t2027 = n2042_0;
    t2028 = n2042_1;
    goto tail_start_kl_shen_2eremove_2ddatatypes_45;
  }
  KLObject* t2042 = NULL;
      t2029 = t2042;
    } else {
  KLObject* t2043 = shen_true(ctx);
    if (!shen_is_boolean(ctx, t2043))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t2043)) {
  KLObject* t2045 = shen_string(ctx, "implementation error in shen.remove-datatypes");
  KLObject* t2044;
  {
    KLObject* a2044[] = {t2045};
    t2044 = shen_tail_apply_direct(ctx, "simple-error", 1, a2044);
  }
      t2029 = t2044;
    } else {
      shen_simple_error(ctx, "No true case found for cond");
      t2029 = shen_empty_list(ctx);
    }
    }
    }
  }
    return t2029;
  }
}

static KLObject* native_kl_shen_2eshow_2ddatatypes_46 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t2046 = objects[0];
  tail_start_kl_shen_2eshow_2ddatatypes_46: ;
  KLObject* t2048;
  {
    Vector* caps_2 = shen_vector(ctx, 0);
    t2048 = shen_native_closure(ctx, 1, &lambda_2, caps_2);
  }
  KLObject* t2047;
  {
    KLObject* a2047[] = {t2048, t2046};
    t2047 = shen_tail_apply_direct(ctx, "map", 2, a2047);
  }
    return t2047;
  }
}

static KLObject* native_kl_include_47 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t2053 = objects[0];
  tail_start_kl_include_47: ;
  KLObject* t2055;
  {
    Vector* caps_3 = shen_vector(ctx, 0);
    t2055 = shen_native_closure(ctx, 1, &lambda_3, caps_3);
  }
  KLObject* t2054;
  {
    KLObject* a2054[] = {t2055, t2053};
    t2054 = shen_apply_direct(ctx, "map", 2, a2054);
  }
  KLObject* t2061;
  {
    Vector* caps_4 = shen_vector(ctx, 0);
    t2061 = shen_native_closure(ctx, 1, &lambda_4, caps_4);
  }
  KLObject* t2060;
  {
    KLObject* a2060[] = {t2061, t2054};
    t2060 = shen_apply_direct(ctx, "map", 2, a2060);
  }
  KLObject* t2069 = shen_intern(ctx, "shen.*datatypes*");
  KLObject* t2068;
  {
    KLObject* a2068[] = {t2069};
    t2068 = shen_apply_direct(ctx, "value", 1, a2068);
  }
  KLObject* t2070;
  {
    KLObject* a2070[] = {t2068};
    t2070 = shen_tail_apply_direct(ctx, "shen.show-datatypes", 1, a2070);
  }
    return t2070;
  }
}

static KLObject* native_kl_preclude_2dall_2dbut_48 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t2072 = objects[0];
  tail_start_kl_preclude_2dall_2dbut_48: ;
  KLObject* t2074 = shen_intern(ctx, "shen.*datatypes*");
  KLObject* t2075 = shen_empty_list(ctx);
  KLObject* t2073;
  {
    KLObject* a2073[] = {t2074, t2075};
    t2073 = shen_apply_direct(ctx, "set", 2, a2073);
  }
  KLObject* t2077;
  {
    Vector* caps_5 = shen_vector(ctx, 0);
    t2077 = shen_native_closure(ctx, 1, &lambda_5, caps_5);
  }
  KLObject* t2076;
  {
    KLObject* a2076[] = {t2077, t2072};
    t2076 = shen_apply_direct(ctx, "map", 2, a2076);
  }
  KLObject* t2083;
  {
    Vector* caps_6 = shen_vector(ctx, 0);
    t2083 = shen_native_closure(ctx, 1, &lambda_6, caps_6);
  }
  KLObject* t2082;
  {
    KLObject* a2082[] = {t2083, t2076};
    t2082 = shen_apply_direct(ctx, "map", 2, a2082);
  }
  KLObject* t2092 = shen_intern(ctx, "shen.*datatypes*");
  KLObject* t2091;
  {
    KLObject* a2091[] = {t2092};
    t2091 = shen_apply_direct(ctx, "value", 1, a2091);
  }
  KLObject* t2090;
  {
    KLObject* a2090[] = {t2091};
    t2090 = shen_tail_apply_direct(ctx, "shen.show-datatypes", 1, a2090);
  }
    return t2090;
  }
}

static KLObject* native_kl_include_2dall_2dbut_49 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t2093 = objects[0];
  tail_start_kl_include_2dall_2dbut_49: ;
  KLObject* t2095;
  {
    Vector* caps_7 = shen_vector(ctx, 0);
    t2095 = shen_native_closure(ctx, 1, &lambda_7, caps_7);
  }
  KLObject* t2094;
  {
    KLObject* a2094[] = {t2095, t2093};
    t2094 = shen_apply_direct(ctx, "map", 2, a2094);
  }
  KLObject* t2101 = shen_intern(ctx, "shen.*alldatatypes*");
  KLObject* t2100;
  {
    KLObject* a2100[] = {t2101};
    t2100 = shen_apply_direct(ctx, "value", 1, a2100);
  }
  KLObject* t2103 = shen_intern(ctx, "shen.*datatypes*");
  KLObject* t2104;
  {
    KLObject* a2104[] = {t2094, t2100};
    t2104 = shen_apply_direct(ctx, "shen.remove-datatypes", 2, a2104);
  }
  KLObject* t2102;
  {
    KLObject* a2102[] = {t2103, t2104};
    t2102 = shen_apply_direct(ctx, "set", 2, a2102);
  }
  KLObject* t2107;
  {
    KLObject* a2107[] = {t2102};
    t2107 = shen_tail_apply_direct(ctx, "shen.show-datatypes", 1, a2107);
  }
    return t2107;
  }
}

void shen_kernel_aot_install_sequent (shen_context* ctx)
{
  shen_register_defun(ctx, "shen.<datatype>", 1, &native_kl_shen_2e_3cdatatype_3e_0);
  shen_register_defun(ctx, "shen.remember-datatype", 2, &native_kl_shen_2eremember_2ddatatype_1);
  shen_register_defun(ctx, "shen.<datatype-rules>", 1, &native_kl_shen_2e_3cdatatype_2drules_3e_2);
  shen_register_defun(ctx, "shen.<datatype-rule>", 1, &native_kl_shen_2e_3cdatatype_2drule_3e_3);
  shen_register_defun(ctx, "shen.<single>", 1, &native_kl_shen_2e_3csingle_3e_4);
  shen_register_defun(ctx, "shen.<double>", 1, &native_kl_shen_2e_3cdouble_3e_5);
  shen_register_defun(ctx, "shen.<formulae>", 1, &native_kl_shen_2e_3cformulae_3e_6);
  shen_register_defun(ctx, "shen.<conc>", 1, &native_kl_shen_2e_3cconc_3e_7);
  shen_register_defun(ctx, "shen.<prems>", 1, &native_kl_shen_2e_3cprems_3e_8);
  shen_register_defun(ctx, "shen.<prem>", 1, &native_kl_shen_2e_3cprem_3e_9);
  shen_register_defun(ctx, "shen.<ass>", 1, &native_kl_shen_2e_3cass_3e_10);
  shen_register_defun(ctx, "shen.<iscomma>", 1, &native_kl_shen_2e_3ciscomma_3e_11);
  shen_register_defun(ctx, "shen.<formula>", 1, &native_kl_shen_2e_3cformula_3e_12);
  shen_register_defun(ctx, "shen.<iscolon>", 1, &native_kl_shen_2e_3ciscolon_3e_13);
  shen_register_defun(ctx, "shen.<sides>", 1, &native_kl_shen_2e_3csides_3e_14);
  shen_register_defun(ctx, "shen.<side>", 1, &native_kl_shen_2e_3cside_3e_15);
  shen_register_defun(ctx, "shen.lr-rule", 3, &native_kl_shen_2elr_2drule_16);
  shen_register_defun(ctx, "shen.coll-formulae", 1, &native_kl_shen_2ecoll_2dformulae_17);
  shen_register_defun(ctx, "shen.<expr>", 1, &native_kl_shen_2e_3cexpr_3e_18);
  shen_register_defun(ctx, "shen.key-in-sequent-calculus?", 1, &native_kl_shen_2ekey_2din_2dsequent_2dcalculus_3f_19);
  shen_register_defun(ctx, "shen.<type>", 1, &native_kl_shen_2e_3ctype_3e_20);
  shen_register_defun(ctx, "shen.<dbl>", 1, &native_kl_shen_2e_3cdbl_3e_21);
  shen_register_defun(ctx, "shen.<sng>", 1, &native_kl_shen_2e_3csng_3e_22);
  shen_register_defun(ctx, "shen.sng?", 1, &native_kl_shen_2esng_3f_23);
  shen_register_defun(ctx, "shen.sng-h?", 1, &native_kl_shen_2esng_2dh_3f_24);
  shen_register_defun(ctx, "shen.dbl?", 1, &native_kl_shen_2edbl_3f_25);
  shen_register_defun(ctx, "shen.dbl-h?", 1, &native_kl_shen_2edbl_2dh_3f_26);
  shen_register_defun(ctx, "shen.rules->prolog", 2, &native_kl_shen_2erules_2d_3eprolog_27);
  shen_register_defun(ctx, "shen.rule->clause", 1, &native_kl_shen_2erule_2d_3eclause_28);
  shen_register_defun(ctx, "shen.rule->head", 1, &native_kl_shen_2erule_2d_3ehead_29);
  shen_register_defun(ctx, "shen.macro-@ch", 1, &native_kl_shen_2emacro_2d_40ch_30);
  shen_register_defun(ctx, "shen.macro-@c", 1, &native_kl_shen_2emacro_2d_40c_31);
  shen_register_defun(ctx, "shen.rule->body", 5, &native_kl_shen_2erule_2d_3ebody_32);
  shen_register_defun(ctx, "shen.specialise-member", 4, &native_kl_shen_2especialise_2dmember_33);
  shen_register_defun(ctx, "shen.remove-bystanders", 2, &native_kl_shen_2eremove_2dbystanders_34);
  shen_register_defun(ctx, "shen.member-clause", 4, &native_kl_shen_2emember_2dclause_35);
  shen_register_defun(ctx, "shen.nvars", 1, &native_kl_shen_2envars_36);
  shen_register_defun(ctx, "shen.passive-bind", 2, &native_kl_shen_2epassive_2dbind_37);
  shen_register_defun(ctx, "shen.specialise-consume", 5, &native_kl_shen_2especialise_2dconsume_38);
  shen_register_defun(ctx, "shen.consume-clause", 5, &native_kl_shen_2econsume_2dclause_39);
  shen_register_defun(ctx, "shen.passive-variables", 2, &native_kl_shen_2epassive_2dvariables_40);
  shen_register_defun(ctx, "shen.side-conditions->goals", 5, &native_kl_shen_2eside_2dconditions_2d_3egoals_41);
  shen_register_defun(ctx, "shen.premises->goals", 3, &native_kl_shen_2epremises_2d_3egoals_42);
  shen_register_defun(ctx, "shen.construct-context", 3, &native_kl_shen_2econstruct_2dcontext_43);
  shen_register_defun(ctx, "preclude", 1, &native_kl_preclude_44);
  shen_register_defun(ctx, "shen.remove-datatypes", 2, &native_kl_shen_2eremove_2ddatatypes_45);
  shen_register_defun(ctx, "shen.show-datatypes", 1, &native_kl_shen_2eshow_2ddatatypes_46);
  shen_register_defun(ctx, "include", 1, &native_kl_include_47);
  shen_register_defun(ctx, "preclude-all-but", 1, &native_kl_preclude_2dall_2dbut_48);
  shen_register_defun(ctx, "include-all-but", 1, &native_kl_include_2dall_2dbut_49);
}
