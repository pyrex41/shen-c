#include "rc_phase_profile.h"
/* Generated always-AOT kernel module (KL defuns -> NativeFunctions).
 * Install after tree-walker boot overwrites UserFunctions.
 * Toplevel declare/set stay on the walker. Not overlay-after-load.
 * Sidecar tests stay on the tree-walker. Not a second main. Source: sys.kl
 */
#include "abi.h"

void shen_kernel_aot_install_sys (shen_context* ctx);

static KLObject* trap_body_0 (void* data)
{
  shen_context* ctx = &shen_root_context;
  Vector* env = (Vector*)data;
  KLObject* t19 = shen_vector_get(ctx, env, 0);
  KLObject* t22 = shen_intern(ctx, "shen.external-symbols");
  KLObject* t24 = shen_intern(ctx, "*property-vector*");
  KLObject* t23;
  {
    KLObject* a23[] = {t24};
    t23 = shen_apply_direct(ctx, "value", 1, a23);
  }
  KLObject* t20;
  {
    KLObject* a20[] = {t19, t22, t23};
    t20 = shen_apply_direct(ctx, "get", 3, a20);
  }
  return t20;
}

static KLObject* lambda_0 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  KLObject* t27 = shen_vector_get(ctx, caps, 0);
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t28 = objects[0];
  KLObject* t31 = shen_string(ctx, "package ");
  KLObject* t34 = shen_string(ctx, " does not exist.\n;");
  KLObject* t35 = shen_intern(ctx, "shen.a");
  KLObject* t32;
  {
    KLObject* a32[] = {t27, t34, t35};
    t32 = shen_apply_direct(ctx, "shen.app", 3, a32);
  }
  KLObject* t30;
  {
    KLObject* a30[] = {t31, t32};
    t30 = shen_apply_direct(ctx, "cn", 2, a30);
  }
  KLObject* t29;
  {
    KLObject* a29[] = {t30};
    t29 = shen_tail_apply_direct(ctx, "simple-error", 1, a29);
  }
    return t29;
  }
}

static KLObject* trap_handler_0 (KLObject* exception, void* data)
{
  shen_context* ctx = &shen_root_context;
  Vector* env = (Vector*)data;
  Vector* args;
  KLObject* t25 = shen_vector_get(ctx, env, 0);
  KLObject* t26;
  {
    Vector* caps_0 = shen_vector(ctx, 1);
    shen_vector_set(ctx, caps_0, 0, t25);
    t26 = shen_native_closure(ctx, 1, &lambda_0, caps_0);
  }
  args = shen_vector(ctx, 1);
  shen_vector_set(ctx, args, 0, exception);
  {
    KLObject* t36 = shen_apply(ctx, t26, args);
    return t36;
  }
}

static KLObject* trap_body_1 (void* data)
{
  shen_context* ctx = &shen_root_context;
  Vector* env = (Vector*)data;
  KLObject* t45 = shen_vector_get(ctx, env, 0);
  KLObject* t48 = shen_intern(ctx, "shen.internal-symbols");
  KLObject* t50 = shen_intern(ctx, "*property-vector*");
  KLObject* t49;
  {
    KLObject* a49[] = {t50};
    t49 = shen_apply_direct(ctx, "value", 1, a49);
  }
  KLObject* t46;
  {
    KLObject* a46[] = {t45, t48, t49};
    t46 = shen_apply_direct(ctx, "get", 3, a46);
  }
  return t46;
}

static KLObject* lambda_1 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  KLObject* t53 = shen_vector_get(ctx, caps, 0);
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t54 = objects[0];
  KLObject* t57 = shen_string(ctx, "package ");
  KLObject* t60 = shen_string(ctx, " does not exist.\n;");
  KLObject* t61 = shen_intern(ctx, "shen.a");
  KLObject* t58;
  {
    KLObject* a58[] = {t53, t60, t61};
    t58 = shen_apply_direct(ctx, "shen.app", 3, a58);
  }
  KLObject* t56;
  {
    KLObject* a56[] = {t57, t58};
    t56 = shen_apply_direct(ctx, "cn", 2, a56);
  }
  KLObject* t55;
  {
    KLObject* a55[] = {t56};
    t55 = shen_tail_apply_direct(ctx, "simple-error", 1, a55);
  }
    return t55;
  }
}

static KLObject* trap_handler_1 (KLObject* exception, void* data)
{
  shen_context* ctx = &shen_root_context;
  Vector* env = (Vector*)data;
  Vector* args;
  KLObject* t51 = shen_vector_get(ctx, env, 0);
  KLObject* t52;
  {
    Vector* caps_1 = shen_vector(ctx, 1);
    shen_vector_set(ctx, caps_1, 0, t51);
    t52 = shen_native_closure(ctx, 1, &lambda_1, caps_1);
  }
  args = shen_vector(ctx, 1);
  shen_vector_set(ctx, args, 0, exception);
  {
    KLObject* t62 = shen_apply(ctx, t52, args);
    return t62;
  }
}

static KLObject* trap_body_2 (void* data)
{
  shen_context* ctx = &shen_root_context;
  Vector* env = (Vector*)data;
  KLObject* t86 = shen_vector_get(ctx, env, 0);
  KLObject* t89 = shen_intern(ctx, "shen.source");
  KLObject* t91 = shen_intern(ctx, "*property-vector*");
  KLObject* t90;
  {
    KLObject* a90[] = {t91};
    t90 = shen_apply_direct(ctx, "value", 1, a90);
  }
  KLObject* t87;
  {
    KLObject* a87[] = {t86, t89, t90};
    t87 = shen_apply_direct(ctx, "get", 3, a87);
  }
  return t87;
}

static KLObject* lambda_2 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  KLObject* t94 = shen_vector_get(ctx, caps, 0);
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t95 = objects[0];
  KLObject* t99 = shen_string(ctx, " not found.\n");
  KLObject* t100 = shen_intern(ctx, "shen.a");
  KLObject* t97;
  {
    KLObject* a97[] = {t94, t99, t100};
    t97 = shen_apply_direct(ctx, "shen.app", 3, a97);
  }
  KLObject* t96;
  {
    KLObject* a96[] = {t97};
    t96 = shen_tail_apply_direct(ctx, "simple-error", 1, a96);
  }
    return t96;
  }
}

static KLObject* trap_handler_2 (KLObject* exception, void* data)
{
  shen_context* ctx = &shen_root_context;
  Vector* env = (Vector*)data;
  Vector* args;
  KLObject* t92 = shen_vector_get(ctx, env, 0);
  KLObject* t93;
  {
    Vector* caps_2 = shen_vector(ctx, 1);
    shen_vector_set(ctx, caps_2, 0, t92);
    t93 = shen_native_closure(ctx, 1, &lambda_2, caps_2);
  }
  args = shen_vector(ctx, 1);
  shen_vector_set(ctx, args, 0, exception);
  {
    KLObject* t101 = shen_apply(ctx, t93, args);
    return t101;
  }
}

static KLObject* trap_body_3 (void* data)
{
  shen_context* ctx = &shen_root_context;
  Vector* env = (Vector*)data;
  KLObject* t152 = shen_vector_get(ctx, env, 0);
  KLObject* t155 = shen_number_l(ctx, 0);
  KLObject* t153;
  {
    KLObject* a153[] = {t152, t155};
    t153 = shen_apply_direct(ctx, "<-address", 2, a153);
  }
  KLObject* t156 = shen_number_l(ctx, 0);
  KLObject* t157 = shen_gte(ctx, t153, t156);
  return t157;
}

static KLObject* lambda_3 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t160 = objects[0];
  KLObject* t161 = shen_false(ctx);
    return t161;
  }
}

static KLObject* trap_handler_3 (KLObject* exception, void* data)
{
  shen_context* ctx = &shen_root_context;
  Vector* env = (Vector*)data;
  Vector* args;
  KLObject* t158 = shen_vector_get(ctx, env, 0);
  KLObject* t159;
  {
    Vector* caps_3 = shen_vector(ctx, 0);
    t159 = shen_native_closure(ctx, 1, &lambda_3, caps_3);
  }
  args = shen_vector(ctx, 1);
  shen_vector_set(ctx, args, 0, exception);
  {
    KLObject* t162 = shen_apply(ctx, t159, args);
    return t162;
  }
}

static KLObject* trap_body_4 (void* data)
{
  shen_context* ctx = &shen_root_context;
  Vector* env = (Vector*)data;
  KLObject* t244 = shen_vector_get(ctx, env, 0);
  KLObject* t245;
  {
    KLObject* a245[] = {t244};
    t245 = shen_apply_direct(ctx, "str", 1, a245);
  }
  KLObject* t247;
  {
    KLObject* a247[] = {t245};
    t247 = shen_apply_direct(ctx, "shen.analyse-symbol?", 1, a247);
  }
  return t247;
}

static KLObject* lambda_4 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t251 = objects[0];
  KLObject* t252 = shen_false(ctx);
    return t252;
  }
}

static KLObject* trap_handler_4 (KLObject* exception, void* data)
{
  shen_context* ctx = &shen_root_context;
  Vector* env = (Vector*)data;
  Vector* args;
  KLObject* t249 = shen_vector_get(ctx, env, 0);
  KLObject* t250;
  {
    Vector* caps_4 = shen_vector(ctx, 0);
    t250 = shen_native_closure(ctx, 1, &lambda_4, caps_4);
  }
  args = shen_vector(ctx, 1);
  shen_vector_set(ctx, args, 0, exception);
  {
    KLObject* t253 = shen_apply(ctx, t250, args);
    return t253;
  }
}

static KLObject* trap_body_5 (void* data)
{
  shen_context* ctx = &shen_root_context;
  Vector* env = (Vector*)data;
  KLObject* t305 = shen_vector_get(ctx, env, 0);
  KLObject* t306;
  {
    KLObject* a306[] = {t305};
    t306 = shen_apply_direct(ctx, "str", 1, a306);
  }
  KLObject* t308;
  {
    KLObject* a308[] = {t306};
    t308 = shen_apply_direct(ctx, "shen.analyse-variable?", 1, a308);
  }
  return t308;
}

static KLObject* lambda_5 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t312 = objects[0];
  KLObject* t313 = shen_false(ctx);
    return t313;
  }
}

static KLObject* trap_handler_5 (KLObject* exception, void* data)
{
  shen_context* ctx = &shen_root_context;
  Vector* env = (Vector*)data;
  Vector* args;
  KLObject* t310 = shen_vector_get(ctx, env, 0);
  KLObject* t311;
  {
    Vector* caps_5 = shen_vector(ctx, 0);
    t311 = shen_native_closure(ctx, 1, &lambda_5, caps_5);
  }
  args = shen_vector(ctx, 1);
  shen_vector_set(ctx, args, 0, exception);
  {
    KLObject* t314 = shen_apply(ctx, t311, args);
    return t314;
  }
}

static KLObject* trap_body_6 (void* data)
{
  shen_context* ctx = &shen_root_context;
  Vector* env = (Vector*)data;
  KLObject* t374 = shen_vector_get(ctx, env, 0);
  KLObject* t377 = shen_absvector_p(ctx, t374);
  KLObject* t375;
  if (!shen_is_boolean(ctx, t377))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t377)) {
    t375 = t377;
  } else {
  KLObject* t378 = shen_intern(ctx, "shen.tuple");
  KLObject* t381 = shen_number_l(ctx, 0);
  KLObject* t379;
  {
    KLObject* a379[] = {t374, t381};
    t379 = shen_apply_direct(ctx, "<-address", 2, a379);
  }
  KLObject* t382 = shen_eq(ctx, t378, t379);
    if (!shen_is_boolean(ctx, t382))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t375 = t382;
  }
  return t375;
}

static KLObject* lambda_6 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t385 = objects[0];
  KLObject* t386 = shen_false(ctx);
    return t386;
  }
}

static KLObject* trap_handler_6 (KLObject* exception, void* data)
{
  shen_context* ctx = &shen_root_context;
  Vector* env = (Vector*)data;
  Vector* args;
  KLObject* t383 = shen_vector_get(ctx, env, 0);
  KLObject* t384;
  {
    Vector* caps_6 = shen_vector(ctx, 0);
    t384 = shen_native_closure(ctx, 1, &lambda_6, caps_6);
  }
  args = shen_vector(ctx, 1);
  shen_vector_set(ctx, args, 0, exception);
  {
    KLObject* t387 = shen_apply(ctx, t384, args);
    return t387;
  }
}

static KLObject* trap_body_7 (void* data)
{
  shen_context* ctx = &shen_root_context;
  Vector* env = (Vector*)data;
  KLObject* t463 = shen_vector_get(ctx, env, 0);
  KLObject* t464 = shen_vector_get(ctx, env, 1);
  KLObject* t465 = shen_vector_get(ctx, env, 2);
  KLObject* t466 = shen_vector_get(ctx, env, 3);
  KLObject* t470;
  {
    KLObject* a470[] = {t463, t465};
    t470 = shen_apply_direct(ctx, "<-vector", 2, a470);
  }
  KLObject* t467;
  {
    KLObject* a467[] = {t464, t466, t470};
    t467 = shen_apply_direct(ctx, "vector->", 3, a467);
  }
  return t467;
}

static KLObject* lambda_7 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  KLObject* t478 = shen_vector_get(ctx, caps, 0);
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t479 = objects[0];
    return t478;
  }
}

static KLObject* trap_handler_7 (KLObject* exception, void* data)
{
  shen_context* ctx = &shen_root_context;
  Vector* env = (Vector*)data;
  Vector* args;
  KLObject* t473 = shen_vector_get(ctx, env, 0);
  KLObject* t474 = shen_vector_get(ctx, env, 1);
  KLObject* t475 = shen_vector_get(ctx, env, 2);
  KLObject* t476 = shen_vector_get(ctx, env, 3);
  KLObject* t477;
  {
    Vector* caps_7 = shen_vector(ctx, 1);
    shen_vector_set(ctx, caps_7, 0, t474);
    t477 = shen_native_closure(ctx, 1, &lambda_7, caps_7);
  }
  args = shen_vector(ctx, 1);
  shen_vector_set(ctx, args, 0, exception);
  {
    KLObject* t481 = shen_apply(ctx, t477, args);
    return t481;
  }
}

static KLObject* trap_body_8 (void* data)
{
  shen_context* ctx = &shen_root_context;
  Vector* env = (Vector*)data;
  KLObject* t484 = shen_vector_get(ctx, env, 0);
  KLObject* t487 = shen_number_l(ctx, 1);
  KLObject* t485;
  {
    KLObject* a485[] = {t484, t487};
    t485 = shen_apply_direct(ctx, "<-vector", 2, a485);
  }
  return t485;
}

static KLObject* lambda_8 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t490 = objects[0];
  KLObject* t492 = shen_string(ctx, "hdv needs a non-empty vector as an argument\n");
  KLObject* t491;
  {
    KLObject* a491[] = {t492};
    t491 = shen_tail_apply_direct(ctx, "simple-error", 1, a491);
  }
    return t491;
  }
}

static KLObject* trap_handler_8 (KLObject* exception, void* data)
{
  shen_context* ctx = &shen_root_context;
  Vector* env = (Vector*)data;
  Vector* args;
  KLObject* t488 = shen_vector_get(ctx, env, 0);
  KLObject* t489;
  {
    Vector* caps_8 = shen_vector(ctx, 0);
    t489 = shen_native_closure(ctx, 1, &lambda_8, caps_8);
  }
  args = shen_vector(ctx, 1);
  shen_vector_set(ctx, args, 0, exception);
  {
    KLObject* t493 = shen_apply(ctx, t489, args);
    return t493;
  }
}

static KLObject* trap_body_9 (void* data)
{
  shen_context* ctx = &shen_root_context;
  Vector* env = (Vector*)data;
  KLObject* t701 = shen_vector_get(ctx, env, 0);
  KLObject* t702 = shen_vector_get(ctx, env, 1);
  KLObject* t703 = shen_vector_get(ctx, env, 2);
  KLObject* t704 = shen_vector_get(ctx, env, 3);
  KLObject* t705 = shen_vector_get(ctx, env, 4);
  KLObject* t706;
  {
    KLObject* a706[] = {t704, t705};
    t706 = shen_apply_direct(ctx, "<-vector", 2, a706);
  }
  return t706;
}

static KLObject* lambda_9 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t715 = objects[0];
  KLObject* t716 = shen_empty_list(ctx);
    return t716;
  }
}

static KLObject* trap_handler_9 (KLObject* exception, void* data)
{
  shen_context* ctx = &shen_root_context;
  Vector* env = (Vector*)data;
  Vector* args;
  KLObject* t709 = shen_vector_get(ctx, env, 0);
  KLObject* t710 = shen_vector_get(ctx, env, 1);
  KLObject* t711 = shen_vector_get(ctx, env, 2);
  KLObject* t712 = shen_vector_get(ctx, env, 3);
  KLObject* t713 = shen_vector_get(ctx, env, 4);
  KLObject* t714;
  {
    Vector* caps_9 = shen_vector(ctx, 0);
    t714 = shen_native_closure(ctx, 1, &lambda_9, caps_9);
  }
  args = shen_vector(ctx, 1);
  shen_vector_set(ctx, args, 0, exception);
  {
    KLObject* t717 = shen_apply(ctx, t714, args);
    return t717;
  }
}

static KLObject* trap_body_10 (void* data)
{
  shen_context* ctx = &shen_root_context;
  Vector* env = (Vector*)data;
  KLObject* t735 = shen_vector_get(ctx, env, 0);
  KLObject* t736 = shen_vector_get(ctx, env, 1);
  KLObject* t737 = shen_vector_get(ctx, env, 2);
  KLObject* t738 = shen_vector_get(ctx, env, 3);
  KLObject* t739;
  {
    KLObject* a739[] = {t737, t738};
    t739 = shen_apply_direct(ctx, "<-vector", 2, a739);
  }
  return t739;
}

static KLObject* lambda_10 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t747 = objects[0];
  KLObject* t748 = shen_empty_list(ctx);
    return t748;
  }
}

static KLObject* trap_handler_10 (KLObject* exception, void* data)
{
  shen_context* ctx = &shen_root_context;
  Vector* env = (Vector*)data;
  Vector* args;
  KLObject* t742 = shen_vector_get(ctx, env, 0);
  KLObject* t743 = shen_vector_get(ctx, env, 1);
  KLObject* t744 = shen_vector_get(ctx, env, 2);
  KLObject* t745 = shen_vector_get(ctx, env, 3);
  KLObject* t746;
  {
    Vector* caps_10 = shen_vector(ctx, 0);
    t746 = shen_native_closure(ctx, 1, &lambda_10, caps_10);
  }
  args = shen_vector(ctx, 1);
  shen_vector_set(ctx, args, 0, exception);
  {
    KLObject* t749 = shen_apply(ctx, t746, args);
    return t749;
  }
}

static KLObject* trap_body_11 (void* data)
{
  shen_context* ctx = &shen_root_context;
  Vector* env = (Vector*)data;
  KLObject* t908 = shen_vector_get(ctx, env, 0);
  KLObject* t909 = shen_vector_get(ctx, env, 1);
  KLObject* t910 = shen_vector_get(ctx, env, 2);
  KLObject* t911 = shen_vector_get(ctx, env, 3);
  KLObject* t912;
  {
    KLObject* a912[] = {t910, t911};
    t912 = shen_apply_direct(ctx, "<-vector", 2, a912);
  }
  return t912;
}

static KLObject* lambda_11 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  KLObject* t920 = shen_vector_get(ctx, caps, 0);
  KLObject* t921 = shen_vector_get(ctx, caps, 1);
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t922 = objects[0];
  KLObject* t927 = shen_string(ctx, " has no attributes: ");
  KLObject* t930 = shen_string(ctx, "\n");
  KLObject* t931 = shen_intern(ctx, "shen.s");
  KLObject* t928;
  {
    KLObject* a928[] = {t921, t930, t931};
    t928 = shen_apply_direct(ctx, "shen.app", 3, a928);
  }
  KLObject* t926;
  {
    KLObject* a926[] = {t927, t928};
    t926 = shen_apply_direct(ctx, "cn", 2, a926);
  }
  KLObject* t932 = shen_intern(ctx, "shen.a");
  KLObject* t924;
  {
    KLObject* a924[] = {t920, t926, t932};
    t924 = shen_apply_direct(ctx, "shen.app", 3, a924);
  }
  KLObject* t923;
  {
    KLObject* a923[] = {t924};
    t923 = shen_tail_apply_direct(ctx, "simple-error", 1, a923);
  }
    return t923;
  }
}

static KLObject* trap_handler_11 (KLObject* exception, void* data)
{
  shen_context* ctx = &shen_root_context;
  Vector* env = (Vector*)data;
  Vector* args;
  KLObject* t915 = shen_vector_get(ctx, env, 0);
  KLObject* t916 = shen_vector_get(ctx, env, 1);
  KLObject* t917 = shen_vector_get(ctx, env, 2);
  KLObject* t918 = shen_vector_get(ctx, env, 3);
  KLObject* t919;
  {
    Vector* caps_11 = shen_vector(ctx, 2);
    shen_vector_set(ctx, caps_11, 0, t915);
    shen_vector_set(ctx, caps_11, 1, t916);
    t919 = shen_native_closure(ctx, 1, &lambda_11, caps_11);
  }
  args = shen_vector(ctx, 1);
  shen_vector_set(ctx, args, 0, exception);
  {
    KLObject* t933 = shen_apply(ctx, t919, args);
    return t933;
  }
}

static KLObject* lambda_12 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t973 = objects[0];
  KLObject* t974;
  {
    KLObject* a974[] = {t973};
    t974 = shen_tail_apply_direct(ctx, "string->n", 1, a974);
  }
    return t974;
  }
}

static KLObject* trap_body_12 (void* data)
{
  shen_context* ctx = &shen_root_context;
  Vector* env = (Vector*)data;
  KLObject* t1497 = shen_vector_get(ctx, env, 0);
  KLObject* t1498;
  {
    KLObject* a1498[] = {t1497};
    t1498 = shen_apply_direct(ctx, "value", 1, a1498);
  }
  return t1498;
}

static KLObject* lambda_13 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t1502 = objects[0];
  KLObject* t1503 = shen_intern(ctx, "shen.this-symbol-is-unbound");
    return t1503;
  }
}

static KLObject* trap_handler_12 (KLObject* exception, void* data)
{
  shen_context* ctx = &shen_root_context;
  Vector* env = (Vector*)data;
  Vector* args;
  KLObject* t1500 = shen_vector_get(ctx, env, 0);
  KLObject* t1501;
  {
    Vector* caps_13 = shen_vector(ctx, 0);
    t1501 = shen_native_closure(ctx, 1, &lambda_13, caps_13);
  }
  args = shen_vector(ctx, 1);
  shen_vector_set(ctx, args, 0, exception);
  {
    KLObject* t1504 = shen_apply(ctx, t1501, args);
    return t1504;
  }
}

static KLObject* trap_body_13 (void* data)
{
  shen_context* ctx = &shen_root_context;
  Vector* env = (Vector*)data;
  KLObject* t1600 = shen_vector_get(ctx, env, 0);
  KLObject* t1601;
  {
    KLObject* a1601[] = {t1600};
    t1601 = shen_apply_direct(ctx, "external", 1, a1601);
  }
  KLObject* t1603 = shen_true(ctx);
  return t1603;
}

static KLObject* lambda_14 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t1606 = objects[0];
  KLObject* t1607 = shen_false(ctx);
    return t1607;
  }
}

static KLObject* trap_handler_13 (KLObject* exception, void* data)
{
  shen_context* ctx = &shen_root_context;
  Vector* env = (Vector*)data;
  Vector* args;
  KLObject* t1604 = shen_vector_get(ctx, env, 0);
  KLObject* t1605;
  {
    Vector* caps_14 = shen_vector(ctx, 0);
    t1605 = shen_native_closure(ctx, 1, &lambda_14, caps_14);
  }
  args = shen_vector(ctx, 1);
  shen_vector_set(ctx, args, 0, exception);
  {
    KLObject* t1608 = shen_apply(ctx, t1605, args);
    return t1608;
  }
}

static KLObject* native_kl_thaw_0 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t0 = objects[0];
  tail_start_kl_thaw_0: ;
  KLObject* t1;
  {
    Vector* a1 = shen_vector(ctx, 0);
    t1 = shen_tail_apply(ctx, t0, a1);
  }
    return t1;
  }
}

static KLObject* native_kl_eval_1 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t3 = objects[0];
  tail_start_kl_eval_1: ;
  KLObject* t6;
  {
    KLObject* a6[] = {t3};
    t6 = shen_apply_direct(ctx, "macroexpand", 1, a6);
  }
  KLObject* t8;
  {
    KLObject* a8[] = {t3};
    t8 = shen_apply_direct(ctx, "shen.find-types", 1, a8);
  }
  KLObject* t5;
  {
    KLObject* a5[] = {t6, t8};
    t5 = shen_apply_direct(ctx, "shen.process-applications", 2, a5);
  }
  KLObject* t4;
  {
    KLObject* a4[] = {t5};
    t4 = sp_boehm_phase_1(ctx, "shen.shen->kl", 1, a4);
  }
  KLObject* t10 = shen_eval_kl(ctx, t4);
    return t10;
  }
}

static KLObject* native_kl_external_2 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t11 = objects[0];
  tail_start_kl_external_2: ;
  KLObject* t12;
  {
  KLObject* t13 = shen_intern(ctx, "null");
  KLObject* t15 = shen_eq(ctx, t13, t11);
    if (!shen_is_boolean(ctx, t15))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t15)) {
  KLObject* t16 = shen_empty_list(ctx);
      t12 = t16;
    } else {
  KLObject* t17 = shen_true(ctx);
    if (!shen_is_boolean(ctx, t17))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t17)) {
  KLObject* t18;
  {
    Vector* tenv_0 = shen_vector(ctx, 1);
    shen_vector_set(ctx, tenv_0, 0, t11);
    t18 = shen_trap_error(ctx, trap_body_0, trap_handler_0, tenv_0);
  }
      t12 = t18;
    } else {
      shen_simple_error(ctx, "No true case found for cond");
      t12 = shen_empty_list(ctx);
    }
    }
  }
    return t12;
  }
}

static KLObject* native_kl_internal_3 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t37 = objects[0];
  tail_start_kl_internal_3: ;
  KLObject* t38;
  {
  KLObject* t39 = shen_intern(ctx, "null");
  KLObject* t41 = shen_eq(ctx, t39, t37);
    if (!shen_is_boolean(ctx, t41))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t41)) {
  KLObject* t42 = shen_empty_list(ctx);
      t38 = t42;
    } else {
  KLObject* t43 = shen_true(ctx);
    if (!shen_is_boolean(ctx, t43))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t43)) {
  KLObject* t44;
  {
    Vector* tenv_1 = shen_vector(ctx, 1);
    shen_vector_set(ctx, tenv_1, 0, t37);
    t44 = shen_trap_error(ctx, trap_body_1, trap_handler_1, tenv_1);
  }
      t38 = t44;
    } else {
      shen_simple_error(ctx, "No true case found for cond");
      t38 = shen_empty_list(ctx);
    }
    }
  }
    return t38;
  }
}

static KLObject* native_kl_fail_2dif_4 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t63 = objects[0];
    KLObject* t64 = objects[1];
  tail_start_kl_fail_2dif_4: ;
  KLObject* t66;
  {
    Vector* a66 = shen_vector(ctx, 1);
    shen_vector_set(ctx, a66, 0, t64);
    t66 = shen_apply(ctx, t63, a66);
  }
  KLObject* t65;
  if (!shen_is_boolean(ctx, t66))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t66)) {
  KLObject* t69 = shen_tail_apply_direct(ctx, "fail", 0, NULL);
    t65 = t69;
  } else {
    t65 = t64;
  }
    return t65;
  }
}

static KLObject* native_kl__40s_5 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t71 = objects[0];
    KLObject* t72 = objects[1];
  tail_start_kl__40s_5: ;
  KLObject* t73;
  {
    KLObject* a73[] = {t71, t72};
    t73 = shen_tail_apply_direct(ctx, "cn", 2, a73);
  }
    return t73;
  }
}

static KLObject* native_kl_tc_3f_6 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  (void)function_object;
  (void)arguments;
  {
  tail_start_kl_tc_3f_6: ;
  KLObject* t77 = shen_intern(ctx, "shen.*tc*");
  KLObject* t76;
  {
    KLObject* a76[] = {t77};
    t76 = shen_tail_apply_direct(ctx, "value", 1, a76);
  }
    return t76;
  }
}

static KLObject* native_kl_occurs_3f_7 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  (void)function_object;
  (void)arguments;
  {
  tail_start_kl_occurs_3f_7: ;
  KLObject* t79 = shen_intern(ctx, "shen.*occurs*");
  KLObject* t78;
  {
    KLObject* a78[] = {t79};
    t78 = shen_tail_apply_direct(ctx, "value", 1, a78);
  }
    return t78;
  }
}

static KLObject* native_kl_factorise_3f_8 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  (void)function_object;
  (void)arguments;
  {
  tail_start_kl_factorise_3f_8: ;
  KLObject* t81 = shen_intern(ctx, "shen.*factorise?*");
  KLObject* t80;
  {
    KLObject* a80[] = {t81};
    t80 = shen_tail_apply_direct(ctx, "value", 1, a80);
  }
    return t80;
  }
}

static KLObject* native_kl_tracked_9 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  (void)function_object;
  (void)arguments;
  {
  tail_start_kl_tracked_9: ;
  KLObject* t83 = shen_intern(ctx, "shen.*tracking*");
  KLObject* t82;
  {
    KLObject* a82[] = {t83};
    t82 = shen_tail_apply_direct(ctx, "value", 1, a82);
  }
    return t82;
  }
}

static KLObject* native_kl_ps_10 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t84 = objects[0];
  tail_start_kl_ps_10: ;
  KLObject* t85;
  {
    Vector* tenv_2 = shen_vector(ctx, 1);
    shen_vector_set(ctx, tenv_2, 0, t84);
    t85 = shen_trap_error(ctx, trap_body_2, trap_handler_2, tenv_2);
  }
    return t85;
  }
}

static KLObject* native_kl_stinput_11 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  (void)function_object;
  (void)arguments;
  {
  tail_start_kl_stinput_11: ;
  KLObject* t103 = shen_intern(ctx, "*stinput*");
  KLObject* t102;
  {
    KLObject* a102[] = {t103};
    t102 = shen_tail_apply_direct(ctx, "value", 1, a102);
  }
    return t102;
  }
}

static KLObject* native_kl_vector_12 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t104 = objects[0];
  tail_start_kl_vector_12: ;
  KLObject* t107 = shen_number_l(ctx, 1);
  KLObject* t108 = shen_add(ctx, t104, t107);
  KLObject* t105;
  {
    KLObject* a105[] = {t108};
    t105 = shen_apply_direct(ctx, "absvector", 1, a105);
  }
  KLObject* t111 = shen_number_l(ctx, 0);
  KLObject* t109;
  {
    KLObject* a109[] = {t105, t111, t104};
    t109 = shen_apply_direct(ctx, "address->", 3, a109);
  }
  KLObject* t115 = shen_number_l(ctx, 0);
  KLObject* t116 = shen_eq(ctx, t104, t115);
  KLObject* t113;
  if (!shen_is_boolean(ctx, t116))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t116)) {
    t113 = t109;
  } else {
  KLObject* t120 = shen_number_l(ctx, 1);
  KLObject* t122 = shen_apply_direct(ctx, "fail", 0, NULL);
  KLObject* t118;
  {
    KLObject* a118[] = {t109, t120, t104, t122};
    t118 = shen_apply_direct(ctx, "shen.fillvector", 4, a118);
  }
    t113 = t118;
  }
    return t113;
  }
}

static KLObject* native_kl_shen_2efillvector_13 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t124 = objects[0];
    KLObject* t125 = objects[1];
    KLObject* t126 = objects[2];
    KLObject* t127 = objects[3];
  tail_start_kl_shen_2efillvector_13: ;
  KLObject* t128;
  {
  KLObject* t131 = shen_eq(ctx, t125, t126);
    if (!shen_is_boolean(ctx, t131))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t131)) {
  KLObject* t132;
  {
    KLObject* a132[] = {t124, t126, t127};
    t132 = shen_tail_apply_direct(ctx, "address->", 3, a132);
  }
      t128 = t132;
    } else {
  KLObject* t136 = shen_true(ctx);
    if (!shen_is_boolean(ctx, t136))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t136)) {
  KLObject* t137;
  {
    KLObject* a137[] = {t124, t125, t127};
    t137 = shen_apply_direct(ctx, "address->", 3, a137);
  }
  KLObject* t141 = shen_number_l(ctx, 1);
  KLObject* t143 = shen_add(ctx, t141, t125);
  {
    KLObject* n146_0 = t137;
    KLObject* n146_1 = t143;
    KLObject* n146_2 = t126;
    KLObject* n146_3 = t127;
    t124 = n146_0;
    t125 = n146_1;
    t126 = n146_2;
    t127 = n146_3;
    goto tail_start_kl_shen_2efillvector_13;
  }
  KLObject* t146 = NULL;
      t128 = t146;
    } else {
      shen_simple_error(ctx, "No true case found for cond");
      t128 = shen_empty_list(ctx);
    }
    }
  }
    return t128;
  }
}

static KLObject* native_kl_vector_3f_14 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t147 = objects[0];
  tail_start_kl_vector_3f_14: ;
  KLObject* t150 = shen_absvector_p(ctx, t147);
  KLObject* t148;
  if (!shen_is_boolean(ctx, t150))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t150)) {
    t148 = t150;
  } else {
  KLObject* t151;
  {
    Vector* tenv_3 = shen_vector(ctx, 1);
    shen_vector_set(ctx, tenv_3, 0, t147);
    t151 = shen_trap_error(ctx, trap_body_3, trap_handler_3, tenv_3);
  }
    if (!shen_is_boolean(ctx, t151))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t148 = t151;
  }
    return t148;
  }
}

static KLObject* native_kl_vector_2d_3e_15 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t163 = objects[0];
    KLObject* t164 = objects[1];
    KLObject* t165 = objects[2];
  tail_start_kl_vector_2d_3e_15: ;
  KLObject* t168 = shen_number_l(ctx, 0);
  KLObject* t169 = shen_eq(ctx, t164, t168);
  KLObject* t166;
  if (!shen_is_boolean(ctx, t169))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t169)) {
  KLObject* t171 = shen_string(ctx, "cannot access 0th element of a vector\n");
  KLObject* t170;
  {
    KLObject* a170[] = {t171};
    t170 = shen_tail_apply_direct(ctx, "simple-error", 1, a170);
  }
    t166 = t170;
  } else {
  KLObject* t172;
  {
    KLObject* a172[] = {t163, t164, t165};
    t172 = shen_tail_apply_direct(ctx, "address->", 3, a172);
  }
    t166 = t172;
  }
    return t166;
  }
}

static KLObject* native_kl__3c_2dvector_16 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t176 = objects[0];
    KLObject* t177 = objects[1];
  tail_start_kl__3c_2dvector_16: ;
  KLObject* t180 = shen_number_l(ctx, 0);
  KLObject* t181 = shen_eq(ctx, t177, t180);
  KLObject* t178;
  if (!shen_is_boolean(ctx, t181))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t181)) {
  KLObject* t183 = shen_string(ctx, "cannot access 0th element of a vector\n");
  KLObject* t182;
  {
    KLObject* a182[] = {t183};
    t182 = shen_tail_apply_direct(ctx, "simple-error", 1, a182);
  }
    t178 = t182;
  } else {
  KLObject* t184;
  {
    KLObject* a184[] = {t176, t177};
    t184 = shen_apply_direct(ctx, "<-address", 2, a184);
  }
  KLObject* t189 = shen_apply_direct(ctx, "fail", 0, NULL);
  KLObject* t190 = shen_eq(ctx, t184, t189);
  KLObject* t187;
  if (!shen_is_boolean(ctx, t190))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t190)) {
  KLObject* t192 = shen_string(ctx, "vector element not found\n");
  KLObject* t191;
  {
    KLObject* a191[] = {t192};
    t191 = shen_tail_apply_direct(ctx, "simple-error", 1, a191);
  }
    t187 = t191;
  } else {
    t187 = t184;
  }
    t178 = t187;
  }
    return t178;
  }
}

static KLObject* native_kl_shen_2eposint_3f_17 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t194 = objects[0];
  tail_start_kl_shen_2eposint_3f_17: ;
  KLObject* t196;
  {
    KLObject* a196[] = {t194};
    t196 = shen_apply_direct(ctx, "integer?", 1, a196);
  }
  KLObject* t195;
  if (!shen_is_boolean(ctx, t196))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t196)) {
    t195 = t196;
  } else {
  KLObject* t199 = shen_number_l(ctx, 0);
  KLObject* t200 = shen_gte(ctx, t194, t199);
    if (!shen_is_boolean(ctx, t200))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t195 = t200;
  }
    return t195;
  }
}

static KLObject* native_kl_limit_18 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t201 = objects[0];
  tail_start_kl_limit_18: ;
  KLObject* t204 = shen_number_l(ctx, 0);
  KLObject* t202;
  {
    KLObject* a202[] = {t201, t204};
    t202 = shen_tail_apply_direct(ctx, "<-address", 2, a202);
  }
    return t202;
  }
}

static KLObject* native_kl_symbol_3f_19 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t205 = objects[0];
  tail_start_kl_symbol_3f_19: ;
  KLObject* t206;
  {
  KLObject* t208;
  {
    KLObject* a208[] = {t205};
    t208 = shen_apply_direct(ctx, "boolean?", 1, a208);
  }
  KLObject* t207;
  if (!shen_is_boolean(ctx, t208))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (shen_boolean_value(ctx, t208)) {
    t207 = t208;
  } else {
  KLObject* t212 = shen_number_p(ctx, t205);
  KLObject* t210;
  if (!shen_is_boolean(ctx, t212))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (shen_boolean_value(ctx, t212)) {
    t210 = t212;
  } else {
  KLObject* t215 = shen_string_p(ctx, t205);
  KLObject* t213;
  if (!shen_is_boolean(ctx, t215))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (shen_boolean_value(ctx, t215)) {
    t213 = t215;
  } else {
  KLObject* t218 = shen_cons_p(ctx, t205);
  KLObject* t216;
  if (!shen_is_boolean(ctx, t218))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (shen_boolean_value(ctx, t218)) {
    t216 = t218;
  } else {
  KLObject* t220;
  {
    KLObject* a220[] = {t205};
    t220 = shen_apply_direct(ctx, "empty?", 1, a220);
  }
  KLObject* t219;
  if (!shen_is_boolean(ctx, t220))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (shen_boolean_value(ctx, t220)) {
    t219 = t220;
  } else {
  KLObject* t222;
  {
    KLObject* a222[] = {t205};
    t222 = shen_apply_direct(ctx, "vector?", 1, a222);
  }
    if (!shen_is_boolean(ctx, t222))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t219 = t222;
  }
    if (!shen_is_boolean(ctx, t219))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t216 = t219;
  }
    if (!shen_is_boolean(ctx, t216))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t213 = t216;
  }
    if (!shen_is_boolean(ctx, t213))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t210 = t213;
  }
    if (!shen_is_boolean(ctx, t210))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t207 = t210;
  }
    if (!shen_is_boolean(ctx, t207))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t207)) {
  KLObject* t224 = shen_false(ctx);
      t206 = t224;
    } else {
  KLObject* t227 = shen_intern(ctx, "{");
  KLObject* t228 = shen_intern(ctx, "}");
  KLObject* t230 = shen_string(ctx, ":");
  KLObject* t229;
  {
    KLObject* a229[] = {t230};
    t229 = shen_apply_direct(ctx, "intern", 1, a229);
  }
  KLObject* t232 = shen_string(ctx, ";");
  KLObject* t231;
  {
    KLObject* a231[] = {t232};
    t231 = shen_apply_direct(ctx, "intern", 1, a231);
  }
  KLObject* t234 = shen_string(ctx, ",");
  KLObject* t233;
  {
    KLObject* a233[] = {t234};
    t233 = shen_apply_direct(ctx, "intern", 1, a233);
  }
  KLObject* t235 = shen_empty_list(ctx);
  KLObject* t236 = shen_cons(ctx, t233, t235);
  KLObject* t237 = shen_cons(ctx, t231, t236);
  KLObject* t238 = shen_cons(ctx, t229, t237);
  KLObject* t239 = shen_cons(ctx, t228, t238);
  KLObject* t240 = shen_cons(ctx, t227, t239);
  KLObject* t225;
  {
    KLObject* a225[] = {t205, t240};
    t225 = shen_apply_direct(ctx, "element?", 2, a225);
  }
    if (!shen_is_boolean(ctx, t225))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t225)) {
  KLObject* t241 = shen_true(ctx);
      t206 = t241;
    } else {
  KLObject* t242 = shen_true(ctx);
    if (!shen_is_boolean(ctx, t242))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t242)) {
  KLObject* t243;
  {
    Vector* tenv_4 = shen_vector(ctx, 1);
    shen_vector_set(ctx, tenv_4, 0, t205);
    t243 = shen_trap_error(ctx, trap_body_4, trap_handler_4, tenv_4);
  }
      t206 = t243;
    } else {
      shen_simple_error(ctx, "No true case found for cond");
      t206 = shen_empty_list(ctx);
    }
    }
    }
  }
    return t206;
  }
}

static KLObject* native_kl_shen_2eanalyse_2dsymbol_3f_20 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t254 = objects[0];
  tail_start_kl_shen_2eanalyse_2dsymbol_3f_20: ;
  KLObject* t255;
  {
  KLObject* t256;
  {
    KLObject* a256[] = {t254};
    t256 = shen_apply_direct(ctx, "shen.+string?", 1, a256);
  }
    if (!shen_is_boolean(ctx, t256))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t256)) {
  KLObject* t261;
  {
    KLObject* a261[] = {t254};
    t261 = shen_apply_direct(ctx, "hdstr", 1, a261);
  }
  KLObject* t260;
  {
    KLObject* a260[] = {t261};
    t260 = shen_apply_direct(ctx, "string->n", 1, a260);
  }
  KLObject* t259;
  {
    KLObject* a259[] = {t260};
    t259 = shen_apply_direct(ctx, "shen.alpha?", 1, a259);
  }
  KLObject* t258;
  if (!shen_is_boolean(ctx, t259))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t259)) {
    t258 = t259;
  } else {
  KLObject* t264;
  {
    KLObject* a264[] = {t254};
    t264 = shen_apply_direct(ctx, "tlstr", 1, a264);
  }
  KLObject* t263;
  {
    KLObject* a263[] = {t264};
    t263 = shen_apply_direct(ctx, "shen.alphanums?", 1, a263);
  }
    if (!shen_is_boolean(ctx, t263))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t258 = t263;
  }
      t255 = t258;
    } else {
  KLObject* t266 = shen_true(ctx);
    if (!shen_is_boolean(ctx, t266))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t266)) {
  KLObject* t268 = shen_string(ctx, "implementation error in shen.analyse-symbol?");
  KLObject* t267;
  {
    KLObject* a267[] = {t268};
    t267 = shen_tail_apply_direct(ctx, "simple-error", 1, a267);
  }
      t255 = t267;
    } else {
      shen_simple_error(ctx, "No true case found for cond");
      t255 = shen_empty_list(ctx);
    }
    }
  }
    return t255;
  }
}

static KLObject* native_kl_shen_2ealphanums_3f_21 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t269 = objects[0];
  tail_start_kl_shen_2ealphanums_3f_21: ;
  KLObject* t270;
  {
  KLObject* t271 = shen_string(ctx, "");
  KLObject* t273 = shen_eq(ctx, t271, t269);
    if (!shen_is_boolean(ctx, t273))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t273)) {
  KLObject* t274 = shen_true(ctx);
      t270 = t274;
    } else {
  KLObject* t275;
  {
    KLObject* a275[] = {t269};
    t275 = shen_apply_direct(ctx, "shen.+string?", 1, a275);
  }
    if (!shen_is_boolean(ctx, t275))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t275)) {
  KLObject* t278;
  {
    KLObject* a278[] = {t269};
    t278 = shen_apply_direct(ctx, "hdstr", 1, a278);
  }
  KLObject* t277;
  {
    KLObject* a277[] = {t278};
    t277 = shen_apply_direct(ctx, "string->n", 1, a277);
  }
  KLObject* t282;
  {
    KLObject* a282[] = {t277};
    t282 = shen_apply_direct(ctx, "shen.alpha?", 1, a282);
  }
  KLObject* t281;
  if (!shen_is_boolean(ctx, t282))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (shen_boolean_value(ctx, t282)) {
    t281 = t282;
  } else {
  KLObject* t284;
  {
    KLObject* a284[] = {t277};
    t284 = shen_apply_direct(ctx, "shen.digit?", 1, a284);
  }
    if (!shen_is_boolean(ctx, t284))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t281 = t284;
  }
  KLObject* t280;
  if (!shen_is_boolean(ctx, t281))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t281)) {
    t280 = t281;
  } else {
  KLObject* t287;
  {
    KLObject* a287[] = {t269};
    t287 = shen_apply_direct(ctx, "tlstr", 1, a287);
  }
  KLObject* t286;
  {
    KLObject* a286[] = {t287};
    t286 = shen_apply_direct(ctx, "shen.alphanums?", 1, a286);
  }
    if (!shen_is_boolean(ctx, t286))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t280 = t286;
  }
      t270 = t280;
    } else {
  KLObject* t289 = shen_true(ctx);
    if (!shen_is_boolean(ctx, t289))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t289)) {
  KLObject* t291 = shen_string(ctx, "implementation error in shen.alphanums?");
  KLObject* t290;
  {
    KLObject* a290[] = {t291};
    t290 = shen_tail_apply_direct(ctx, "simple-error", 1, a290);
  }
      t270 = t290;
    } else {
      shen_simple_error(ctx, "No true case found for cond");
      t270 = shen_empty_list(ctx);
    }
    }
    }
  }
    return t270;
  }
}

static KLObject* native_kl_variable_3f_22 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t292 = objects[0];
  tail_start_kl_variable_3f_22: ;
  KLObject* t293;
  {
  KLObject* t295;
  {
    KLObject* a295[] = {t292};
    t295 = shen_apply_direct(ctx, "boolean?", 1, a295);
  }
  KLObject* t294;
  if (!shen_is_boolean(ctx, t295))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (shen_boolean_value(ctx, t295)) {
    t294 = t295;
  } else {
  KLObject* t299 = shen_number_p(ctx, t292);
  KLObject* t297;
  if (!shen_is_boolean(ctx, t299))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (shen_boolean_value(ctx, t299)) {
    t297 = t299;
  } else {
  KLObject* t301 = shen_string_p(ctx, t292);
    if (!shen_is_boolean(ctx, t301))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t297 = t301;
  }
    if (!shen_is_boolean(ctx, t297))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t294 = t297;
  }
    if (!shen_is_boolean(ctx, t294))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t294)) {
  KLObject* t302 = shen_false(ctx);
      t293 = t302;
    } else {
  KLObject* t303 = shen_true(ctx);
    if (!shen_is_boolean(ctx, t303))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t303)) {
  KLObject* t304;
  {
    Vector* tenv_5 = shen_vector(ctx, 1);
    shen_vector_set(ctx, tenv_5, 0, t292);
    t304 = shen_trap_error(ctx, trap_body_5, trap_handler_5, tenv_5);
  }
      t293 = t304;
    } else {
      shen_simple_error(ctx, "No true case found for cond");
      t293 = shen_empty_list(ctx);
    }
    }
  }
    return t293;
  }
}

static KLObject* native_kl_shen_2eanalyse_2dvariable_3f_23 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t315 = objects[0];
  tail_start_kl_shen_2eanalyse_2dvariable_3f_23: ;
  KLObject* t316;
  {
  KLObject* t317;
  {
    KLObject* a317[] = {t315};
    t317 = shen_apply_direct(ctx, "shen.+string?", 1, a317);
  }
    if (!shen_is_boolean(ctx, t317))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t317)) {
  KLObject* t322;
  {
    KLObject* a322[] = {t315};
    t322 = shen_apply_direct(ctx, "hdstr", 1, a322);
  }
  KLObject* t321;
  {
    KLObject* a321[] = {t322};
    t321 = shen_apply_direct(ctx, "string->n", 1, a321);
  }
  KLObject* t320;
  {
    KLObject* a320[] = {t321};
    t320 = shen_apply_direct(ctx, "shen.uppercase?", 1, a320);
  }
  KLObject* t319;
  if (!shen_is_boolean(ctx, t320))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t320)) {
    t319 = t320;
  } else {
  KLObject* t325;
  {
    KLObject* a325[] = {t315};
    t325 = shen_apply_direct(ctx, "tlstr", 1, a325);
  }
  KLObject* t324;
  {
    KLObject* a324[] = {t325};
    t324 = shen_apply_direct(ctx, "shen.alphanums?", 1, a324);
  }
    if (!shen_is_boolean(ctx, t324))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t319 = t324;
  }
      t316 = t319;
    } else {
  KLObject* t327 = shen_true(ctx);
    if (!shen_is_boolean(ctx, t327))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t327)) {
  KLObject* t329 = shen_string(ctx, "implementation error in shen.analyse-variable?");
  KLObject* t328;
  {
    KLObject* a328[] = {t329};
    t328 = shen_tail_apply_direct(ctx, "simple-error", 1, a328);
  }
      t316 = t328;
    } else {
      shen_simple_error(ctx, "No true case found for cond");
      t316 = shen_empty_list(ctx);
    }
    }
  }
    return t316;
  }
}

static KLObject* native_kl_gensym_24 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t330 = objects[0];
  tail_start_kl_gensym_24: ;
  KLObject* t334 = shen_intern(ctx, "shen.*gensym*");
  KLObject* t335 = shen_number_l(ctx, 1);
  KLObject* t337 = shen_intern(ctx, "shen.*gensym*");
  KLObject* t336;
  {
    KLObject* a336[] = {t337};
    t336 = shen_apply_direct(ctx, "value", 1, a336);
  }
  KLObject* t338 = shen_add(ctx, t335, t336);
  KLObject* t333;
  {
    KLObject* a333[] = {t334, t338};
    t333 = shen_apply_direct(ctx, "set", 2, a333);
  }
  KLObject* t331;
  {
    KLObject* a331[] = {t330, t333};
    t331 = shen_tail_apply_direct(ctx, "concat", 2, a331);
  }
    return t331;
  }
}

static KLObject* native_kl_concat_25 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t339 = objects[0];
    KLObject* t340 = objects[1];
  tail_start_kl_concat_25: ;
  KLObject* t343;
  {
    KLObject* a343[] = {t339};
    t343 = shen_apply_direct(ctx, "str", 1, a343);
  }
  KLObject* t345;
  {
    KLObject* a345[] = {t340};
    t345 = shen_apply_direct(ctx, "str", 1, a345);
  }
  KLObject* t342;
  {
    KLObject* a342[] = {t343, t345};
    t342 = shen_apply_direct(ctx, "cn", 2, a342);
  }
  KLObject* t341;
  {
    KLObject* a341[] = {t342};
    t341 = shen_tail_apply_direct(ctx, "intern", 1, a341);
  }
    return t341;
  }
}

static KLObject* native_kl__40p_26 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t347 = objects[0];
    KLObject* t348 = objects[1];
  tail_start_kl__40p_26: ;
  KLObject* t350 = shen_number_l(ctx, 3);
  KLObject* t349;
  {
    KLObject* a349[] = {t350};
    t349 = shen_apply_direct(ctx, "absvector", 1, a349);
  }
  KLObject* t353 = shen_number_l(ctx, 0);
  KLObject* t354 = shen_intern(ctx, "shen.tuple");
  KLObject* t351;
  {
    KLObject* a351[] = {t349, t353, t354};
    t351 = shen_apply_direct(ctx, "address->", 3, a351);
  }
  KLObject* t357 = shen_number_l(ctx, 1);
  KLObject* t355;
  {
    KLObject* a355[] = {t349, t357, t347};
    t355 = shen_apply_direct(ctx, "address->", 3, a355);
  }
  KLObject* t361 = shen_number_l(ctx, 2);
  KLObject* t359;
  {
    KLObject* a359[] = {t349, t361, t348};
    t359 = shen_apply_direct(ctx, "address->", 3, a359);
  }
    return t349;
  }
}

static KLObject* native_kl_fst_27 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t364 = objects[0];
  tail_start_kl_fst_27: ;
  KLObject* t367 = shen_number_l(ctx, 1);
  KLObject* t365;
  {
    KLObject* a365[] = {t364, t367};
    t365 = shen_tail_apply_direct(ctx, "<-address", 2, a365);
  }
    return t365;
  }
}

static KLObject* native_kl_snd_28 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t368 = objects[0];
  tail_start_kl_snd_28: ;
  KLObject* t371 = shen_number_l(ctx, 2);
  KLObject* t369;
  {
    KLObject* a369[] = {t368, t371};
    t369 = shen_tail_apply_direct(ctx, "<-address", 2, a369);
  }
    return t369;
  }
}

static KLObject* native_kl_tuple_3f_29 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t372 = objects[0];
  tail_start_kl_tuple_3f_29: ;
  KLObject* t373;
  {
    Vector* tenv_6 = shen_vector(ctx, 1);
    shen_vector_set(ctx, tenv_6, 0, t372);
    t373 = shen_trap_error(ctx, trap_body_6, trap_handler_6, tenv_6);
  }
    return t373;
  }
}

static KLObject* native_kl_append_30 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t388 = objects[0];
    KLObject* t389 = objects[1];
  tail_start_kl_append_30: ;
  KLObject* t390;
  {
  KLObject* t391 = shen_empty_list(ctx);
  KLObject* t393 = shen_eq(ctx, t391, t388);
    if (!shen_is_boolean(ctx, t393))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t393)) {
      t390 = t389;
    } else {
  KLObject* t396 = shen_cons_p(ctx, t388);
    if (!shen_is_boolean(ctx, t396))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t396)) {
  KLObject* t398 = shen_hd(ctx, t388);
  KLObject* t401 = shen_tl(ctx, t388);
  KLObject* t399;
  {
    KLObject* a399[] = {t401, t389};
    t399 = shen_apply_direct(ctx, "append", 2, a399);
  }
  KLObject* t403 = shen_cons(ctx, t398, t399);
      t390 = t403;
    } else {
  KLObject* t404 = shen_true(ctx);
    if (!shen_is_boolean(ctx, t404))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t404)) {
  KLObject* t406 = shen_string(ctx, "attempt to append a non-list");
  KLObject* t405;
  {
    KLObject* a405[] = {t406};
    t405 = shen_tail_apply_direct(ctx, "simple-error", 1, a405);
  }
      t390 = t405;
    } else {
      shen_simple_error(ctx, "No true case found for cond");
      t390 = shen_empty_list(ctx);
    }
    }
    }
  }
    return t390;
  }
}

static KLObject* native_kl__40v_31 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t407 = objects[0];
    KLObject* t408 = objects[1];
  tail_start_kl__40v_31: ;
  KLObject* t409;
  {
    KLObject* a409[] = {t408};
    t409 = shen_apply_direct(ctx, "limit", 1, a409);
  }
  KLObject* t413 = shen_number_l(ctx, 1);
  KLObject* t414 = shen_add(ctx, t409, t413);
  KLObject* t411;
  {
    KLObject* a411[] = {t414};
    t411 = shen_apply_direct(ctx, "vector", 1, a411);
  }
  KLObject* t417 = shen_number_l(ctx, 1);
  KLObject* t415;
  {
    KLObject* a415[] = {t411, t417, t407};
    t415 = shen_apply_direct(ctx, "vector->", 3, a415);
  }
  KLObject* t421 = shen_number_l(ctx, 0);
  KLObject* t422 = shen_eq(ctx, t409, t421);
  KLObject* t419;
  if (!shen_is_boolean(ctx, t422))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t422)) {
    t419 = t415;
  } else {
  KLObject* t426 = shen_number_l(ctx, 1);
  KLObject* t424;
  {
    KLObject* a424[] = {t408, t426, t409, t415};
    t424 = shen_tail_apply_direct(ctx, "shen.@v-help", 4, a424);
  }
    t419 = t424;
  }
    return t419;
  }
}

static KLObject* native_kl_shen_2e_40v_2dhelp_32 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t429 = objects[0];
    KLObject* t430 = objects[1];
    KLObject* t431 = objects[2];
    KLObject* t432 = objects[3];
  tail_start_kl_shen_2e_40v_2dhelp_32: ;
  KLObject* t433;
  {
  KLObject* t436 = shen_eq(ctx, t430, t431);
    if (!shen_is_boolean(ctx, t436))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t436)) {
  KLObject* t442 = shen_number_l(ctx, 1);
  KLObject* t443 = shen_add(ctx, t431, t442);
  KLObject* t437;
  {
    KLObject* a437[] = {t429, t432, t431, t443};
    t437 = shen_tail_apply_direct(ctx, "shen.copyfromvector", 4, a437);
  }
      t433 = t437;
    } else {
  KLObject* t444 = shen_true(ctx);
    if (!shen_is_boolean(ctx, t444))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t444)) {
  KLObject* t447 = shen_number_l(ctx, 1);
  KLObject* t448 = shen_add(ctx, t430, t447);
  KLObject* t455 = shen_number_l(ctx, 1);
  KLObject* t456 = shen_add(ctx, t430, t455);
  KLObject* t450;
  {
    KLObject* a450[] = {t429, t432, t430, t456};
    t450 = shen_apply_direct(ctx, "shen.copyfromvector", 4, a450);
  }
  {
    KLObject* n457_0 = t429;
    KLObject* n457_1 = t448;
    KLObject* n457_2 = t431;
    KLObject* n457_3 = t450;
    t429 = n457_0;
    t430 = n457_1;
    t431 = n457_2;
    t432 = n457_3;
    goto tail_start_kl_shen_2e_40v_2dhelp_32;
  }
  KLObject* t457 = NULL;
      t433 = t457;
    } else {
      shen_simple_error(ctx, "No true case found for cond");
      t433 = shen_empty_list(ctx);
    }
    }
  }
    return t433;
  }
}

static KLObject* native_kl_shen_2ecopyfromvector_33 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t458 = objects[0];
    KLObject* t459 = objects[1];
    KLObject* t460 = objects[2];
    KLObject* t461 = objects[3];
  tail_start_kl_shen_2ecopyfromvector_33: ;
  KLObject* t462;
  {
    Vector* tenv_7 = shen_vector(ctx, 4);
    shen_vector_set(ctx, tenv_7, 0, t458);
    shen_vector_set(ctx, tenv_7, 1, t459);
    shen_vector_set(ctx, tenv_7, 2, t460);
    shen_vector_set(ctx, tenv_7, 3, t461);
    t462 = shen_trap_error(ctx, trap_body_7, trap_handler_7, tenv_7);
  }
    return t462;
  }
}

static KLObject* native_kl_hdv_34 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t482 = objects[0];
  tail_start_kl_hdv_34: ;
  KLObject* t483;
  {
    Vector* tenv_8 = shen_vector(ctx, 1);
    shen_vector_set(ctx, tenv_8, 0, t482);
    t483 = shen_trap_error(ctx, trap_body_8, trap_handler_8, tenv_8);
  }
    return t483;
  }
}

static KLObject* native_kl_tlv_35 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t494 = objects[0];
  tail_start_kl_tlv_35: ;
  KLObject* t495;
  {
    KLObject* a495[] = {t494};
    t495 = shen_apply_direct(ctx, "limit", 1, a495);
  }
  KLObject* t499 = shen_number_l(ctx, 0);
  KLObject* t500 = shen_eq(ctx, t495, t499);
  KLObject* t497;
  if (!shen_is_boolean(ctx, t500))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t500)) {
  KLObject* t502 = shen_string(ctx, "cannot take the tail of the empty vector\n");
  KLObject* t501;
  {
    KLObject* a501[] = {t502};
    t501 = shen_tail_apply_direct(ctx, "simple-error", 1, a501);
  }
    t497 = t501;
  } else {
  KLObject* t505 = shen_number_l(ctx, 1);
  KLObject* t506 = shen_eq(ctx, t495, t505);
  KLObject* t503;
  if (!shen_is_boolean(ctx, t506))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t506)) {
  KLObject* t508 = shen_number_l(ctx, 0);
  KLObject* t507;
  {
    KLObject* a507[] = {t508};
    t507 = shen_tail_apply_direct(ctx, "vector", 1, a507);
  }
    t503 = t507;
  } else {
  KLObject* t511 = shen_number_l(ctx, 1);
  KLObject* t512 = shen_sub(ctx, t495, t511);
  KLObject* t509;
  {
    KLObject* a509[] = {t512};
    t509 = shen_apply_direct(ctx, "vector", 1, a509);
  }
  KLObject* t515 = shen_number_l(ctx, 2);
  KLObject* t519 = shen_number_l(ctx, 1);
  KLObject* t520 = shen_sub(ctx, t495, t519);
  KLObject* t517;
  {
    KLObject* a517[] = {t520};
    t517 = shen_apply_direct(ctx, "vector", 1, a517);
  }
  KLObject* t513;
  {
    KLObject* a513[] = {t494, t515, t495, t517};
    t513 = shen_tail_apply_direct(ctx, "shen.tlv-help", 4, a513);
  }
    t503 = t513;
  }
    t497 = t503;
  }
    return t497;
  }
}

static KLObject* native_kl_shen_2etlv_2dhelp_36 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t521 = objects[0];
    KLObject* t522 = objects[1];
    KLObject* t523 = objects[2];
    KLObject* t524 = objects[3];
  tail_start_kl_shen_2etlv_2dhelp_36: ;
  KLObject* t525;
  {
  KLObject* t528 = shen_eq(ctx, t522, t523);
    if (!shen_is_boolean(ctx, t528))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t528)) {
  KLObject* t534 = shen_number_l(ctx, 1);
  KLObject* t535 = shen_sub(ctx, t523, t534);
  KLObject* t529;
  {
    KLObject* a529[] = {t521, t524, t523, t535};
    t529 = shen_tail_apply_direct(ctx, "shen.copyfromvector", 4, a529);
  }
      t525 = t529;
    } else {
  KLObject* t536 = shen_true(ctx);
    if (!shen_is_boolean(ctx, t536))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t536)) {
  KLObject* t539 = shen_number_l(ctx, 1);
  KLObject* t540 = shen_add(ctx, t522, t539);
  KLObject* t547 = shen_number_l(ctx, 1);
  KLObject* t548 = shen_sub(ctx, t522, t547);
  KLObject* t542;
  {
    KLObject* a542[] = {t521, t524, t522, t548};
    t542 = shen_apply_direct(ctx, "shen.copyfromvector", 4, a542);
  }
  {
    KLObject* n549_0 = t521;
    KLObject* n549_1 = t540;
    KLObject* n549_2 = t523;
    KLObject* n549_3 = t542;
    t521 = n549_0;
    t522 = n549_1;
    t523 = n549_2;
    t524 = n549_3;
    goto tail_start_kl_shen_2etlv_2dhelp_36;
  }
  KLObject* t549 = NULL;
      t525 = t549;
    } else {
      shen_simple_error(ctx, "No true case found for cond");
      t525 = shen_empty_list(ctx);
    }
    }
  }
    return t525;
  }
}

static KLObject* native_kl_assoc_37 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t550 = objects[0];
    KLObject* t551 = objects[1];
  tail_start_kl_assoc_37: ;
  KLObject* t552;
  {
  KLObject* t553 = shen_empty_list(ctx);
  KLObject* t555 = shen_eq(ctx, t553, t551);
    if (!shen_is_boolean(ctx, t555))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t555)) {
  KLObject* t556 = shen_empty_list(ctx);
      t552 = t556;
    } else {
  KLObject* t559 = shen_cons_p(ctx, t551);
  KLObject* t557;
  if (!shen_is_boolean(ctx, t559))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t559)) {
    t557 = t559;
  } else {
  KLObject* t562 = shen_hd(ctx, t551);
  KLObject* t563 = shen_cons_p(ctx, t562);
  KLObject* t560;
  if (!shen_is_boolean(ctx, t563))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t563)) {
    t560 = t563;
  } else {
  KLObject* t566 = shen_hd(ctx, t551);
  KLObject* t567 = shen_hd(ctx, t566);
  KLObject* t568 = shen_eq(ctx, t550, t567);
    if (!shen_is_boolean(ctx, t568))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t560 = t568;
  }
    if (!shen_is_boolean(ctx, t560))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t557 = t560;
  }
    if (!shen_is_boolean(ctx, t557))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t557)) {
  KLObject* t570 = shen_hd(ctx, t551);
      t552 = t570;
    } else {
  KLObject* t572 = shen_cons_p(ctx, t551);
    if (!shen_is_boolean(ctx, t572))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t572)) {
  KLObject* t575 = shen_tl(ctx, t551);
  {
    KLObject* n576_0 = t550;
    KLObject* n576_1 = t575;
    t550 = n576_0;
    t551 = n576_1;
    goto tail_start_kl_assoc_37;
  }
  KLObject* t576 = NULL;
      t552 = t576;
    } else {
  KLObject* t577 = shen_true(ctx);
    if (!shen_is_boolean(ctx, t577))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t577)) {
  KLObject* t579 = shen_string(ctx, "attempt to search a non-list with assoc\n");
  KLObject* t578;
  {
    KLObject* a578[] = {t579};
    t578 = shen_tail_apply_direct(ctx, "simple-error", 1, a578);
  }
      t552 = t578;
    } else {
      shen_simple_error(ctx, "No true case found for cond");
      t552 = shen_empty_list(ctx);
    }
    }
    }
    }
  }
    return t552;
  }
}

static KLObject* native_kl_boolean_3f_38 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t580 = objects[0];
  tail_start_kl_boolean_3f_38: ;
  KLObject* t581;
  {
  KLObject* t582 = shen_true(ctx);
  KLObject* t584 = shen_eq(ctx, t582, t580);
    if (!shen_is_boolean(ctx, t584))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t584)) {
  KLObject* t585 = shen_true(ctx);
      t581 = t585;
    } else {
  KLObject* t586 = shen_false(ctx);
  KLObject* t588 = shen_eq(ctx, t586, t580);
    if (!shen_is_boolean(ctx, t588))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t588)) {
  KLObject* t589 = shen_true(ctx);
      t581 = t589;
    } else {
  KLObject* t590 = shen_true(ctx);
    if (!shen_is_boolean(ctx, t590))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t590)) {
  KLObject* t591 = shen_false(ctx);
      t581 = t591;
    } else {
      shen_simple_error(ctx, "No true case found for cond");
      t581 = shen_empty_list(ctx);
    }
    }
    }
  }
    return t581;
  }
}

static KLObject* native_kl_nl_39 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t592 = objects[0];
  tail_start_kl_nl_39: ;
  KLObject* t593;
  {
  KLObject* t594 = shen_number_l(ctx, 0);
  KLObject* t596 = shen_eq(ctx, t594, t592);
    if (!shen_is_boolean(ctx, t596))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t596)) {
  KLObject* t597 = shen_number_l(ctx, 0);
      t593 = t597;
    } else {
  KLObject* t598 = shen_true(ctx);
    if (!shen_is_boolean(ctx, t598))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t598)) {
  KLObject* t600 = shen_string(ctx, "\n");
  KLObject* t601 = shen_apply_direct(ctx, "stoutput", 0, NULL);
  KLObject* t599;
  {
    KLObject* a599[] = {t600, t601};
    t599 = shen_apply_direct(ctx, "pr", 2, a599);
  }
  KLObject* t603 = shen_number_l(ctx, 1);
  KLObject* t604 = shen_sub(ctx, t592, t603);
  {
    KLObject* n605_0 = t604;
    t592 = n605_0;
    goto tail_start_kl_nl_39;
  }
  KLObject* t605 = NULL;
      t593 = t605;
    } else {
      shen_simple_error(ctx, "No true case found for cond");
      t593 = shen_empty_list(ctx);
    }
    }
  }
    return t593;
  }
}

static KLObject* native_kl_difference_40 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t606 = objects[0];
    KLObject* t607 = objects[1];
  tail_start_kl_difference_40: ;
  KLObject* t608;
  {
  KLObject* t609 = shen_empty_list(ctx);
  KLObject* t611 = shen_eq(ctx, t609, t606);
    if (!shen_is_boolean(ctx, t611))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t611)) {
  KLObject* t612 = shen_empty_list(ctx);
      t608 = t612;
    } else {
  KLObject* t614 = shen_cons_p(ctx, t606);
    if (!shen_is_boolean(ctx, t614))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t614)) {
  KLObject* t618 = shen_hd(ctx, t606);
  KLObject* t616;
  {
    KLObject* a616[] = {t618, t607};
    t616 = shen_apply_direct(ctx, "element?", 2, a616);
  }
  KLObject* t615;
  if (!shen_is_boolean(ctx, t616))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t616)) {
  KLObject* t621 = shen_tl(ctx, t606);
  {
    KLObject* n623_0 = t621;
    KLObject* n623_1 = t607;
    t606 = n623_0;
    t607 = n623_1;
    goto tail_start_kl_difference_40;
  }
  KLObject* t623 = NULL;
    t615 = t623;
  } else {
  KLObject* t625 = shen_hd(ctx, t606);
  KLObject* t628 = shen_tl(ctx, t606);
  KLObject* t626;
  {
    KLObject* a626[] = {t628, t607};
    t626 = shen_apply_direct(ctx, "difference", 2, a626);
  }
  KLObject* t630 = shen_cons(ctx, t625, t626);
    t615 = t630;
  }
      t608 = t615;
    } else {
  KLObject* t631 = shen_true(ctx);
    if (!shen_is_boolean(ctx, t631))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t631)) {
  KLObject* t633 = shen_string(ctx, "attempt to find the difference with a non-list\n");
  KLObject* t632;
  {
    KLObject* a632[] = {t633};
    t632 = shen_tail_apply_direct(ctx, "simple-error", 1, a632);
  }
      t608 = t632;
    } else {
      shen_simple_error(ctx, "No true case found for cond");
      t608 = shen_empty_list(ctx);
    }
    }
    }
  }
    return t608;
  }
}

static KLObject* native_kl_do_41 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t634 = objects[0];
    KLObject* t635 = objects[1];
  tail_start_kl_do_41: ;
    return t635;
  }
}

static KLObject* native_kl_element_3f_42 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t637 = objects[0];
    KLObject* t638 = objects[1];
  tail_start_kl_element_3f_42: ;
  KLObject* t639;
  {
  KLObject* t640 = shen_empty_list(ctx);
  KLObject* t642 = shen_eq(ctx, t640, t638);
    if (!shen_is_boolean(ctx, t642))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t642)) {
  KLObject* t643 = shen_false(ctx);
      t639 = t643;
    } else {
  KLObject* t646 = shen_cons_p(ctx, t638);
  KLObject* t644;
  if (!shen_is_boolean(ctx, t646))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t646)) {
    t644 = t646;
  } else {
  KLObject* t649 = shen_hd(ctx, t638);
  KLObject* t650 = shen_eq(ctx, t637, t649);
    if (!shen_is_boolean(ctx, t650))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t644 = t650;
  }
    if (!shen_is_boolean(ctx, t644))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t644)) {
  KLObject* t651 = shen_true(ctx);
      t639 = t651;
    } else {
  KLObject* t653 = shen_cons_p(ctx, t638);
    if (!shen_is_boolean(ctx, t653))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t653)) {
  KLObject* t656 = shen_tl(ctx, t638);
  {
    KLObject* n657_0 = t637;
    KLObject* n657_1 = t656;
    t637 = n657_0;
    t638 = n657_1;
    goto tail_start_kl_element_3f_42;
  }
  KLObject* t657 = NULL;
      t639 = t657;
    } else {
  KLObject* t658 = shen_true(ctx);
    if (!shen_is_boolean(ctx, t658))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t658)) {
  KLObject* t660 = shen_string(ctx, "attempt to find an element in a non-list\n");
  KLObject* t659;
  {
    KLObject* a659[] = {t660};
    t659 = shen_tail_apply_direct(ctx, "simple-error", 1, a659);
  }
      t639 = t659;
    } else {
      shen_simple_error(ctx, "No true case found for cond");
      t639 = shen_empty_list(ctx);
    }
    }
    }
    }
  }
    return t639;
  }
}

static KLObject* native_kl_empty_3f_43 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t661 = objects[0];
  tail_start_kl_empty_3f_43: ;
  KLObject* t662;
  {
  KLObject* t663 = shen_empty_list(ctx);
  KLObject* t665 = shen_eq(ctx, t663, t661);
    if (!shen_is_boolean(ctx, t665))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t665)) {
  KLObject* t666 = shen_true(ctx);
      t662 = t666;
    } else {
  KLObject* t667 = shen_true(ctx);
    if (!shen_is_boolean(ctx, t667))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t667)) {
  KLObject* t668 = shen_false(ctx);
      t662 = t668;
    } else {
      shen_simple_error(ctx, "No true case found for cond");
      t662 = shen_empty_list(ctx);
    }
    }
  }
    return t662;
  }
}

static KLObject* native_kl_fix_44 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t669 = objects[0];
    KLObject* t670 = objects[1];
  tail_start_kl_fix_44: ;
  KLObject* t674;
  {
    Vector* a674 = shen_vector(ctx, 1);
    shen_vector_set(ctx, a674, 0, t670);
    t674 = shen_apply(ctx, t669, a674);
  }
  KLObject* t671;
  {
    KLObject* a671[] = {t669, t670, t674};
    t671 = shen_tail_apply_direct(ctx, "shen.fix-help", 3, a671);
  }
    return t671;
  }
}

static KLObject* native_kl_shen_2efix_2dhelp_45 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t677 = objects[0];
    KLObject* t678 = objects[1];
    KLObject* t679 = objects[2];
  tail_start_kl_shen_2efix_2dhelp_45: ;
  KLObject* t680;
  {
  KLObject* t683 = shen_eq(ctx, t678, t679);
    if (!shen_is_boolean(ctx, t683))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t683)) {
      t680 = t679;
    } else {
  KLObject* t685 = shen_true(ctx);
    if (!shen_is_boolean(ctx, t685))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t685)) {
  KLObject* t688;
  {
    Vector* a688 = shen_vector(ctx, 1);
    shen_vector_set(ctx, a688, 0, t679);
    t688 = shen_apply(ctx, t677, a688);
  }
  {
    KLObject* n691_0 = t677;
    KLObject* n691_1 = t679;
    KLObject* n691_2 = t688;
    t677 = n691_0;
    t678 = n691_1;
    t679 = n691_2;
    goto tail_start_kl_shen_2efix_2dhelp_45;
  }
  KLObject* t691 = NULL;
      t680 = t691;
    } else {
      shen_simple_error(ctx, "No true case found for cond");
      t680 = shen_empty_list(ctx);
    }
    }
  }
    return t680;
  }
}

static KLObject* native_kl_put_46 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t692 = objects[0];
    KLObject* t693 = objects[1];
    KLObject* t694 = objects[2];
    KLObject* t695 = objects[3];
  tail_start_kl_put_46: ;
  KLObject* t698;
  {
    KLObject* a698[] = {t695};
    t698 = shen_apply_direct(ctx, "limit", 1, a698);
  }
  KLObject* t696;
  {
    KLObject* a696[] = {t692, t698};
    t696 = shen_apply_direct(ctx, "hash", 2, a696);
  }
  KLObject* t700;
  {
    Vector* tenv_9 = shen_vector(ctx, 5);
    shen_vector_set(ctx, tenv_9, 0, t692);
    shen_vector_set(ctx, tenv_9, 1, t693);
    shen_vector_set(ctx, tenv_9, 2, t694);
    shen_vector_set(ctx, tenv_9, 3, t695);
    shen_vector_set(ctx, tenv_9, 4, t696);
    t700 = shen_trap_error(ctx, trap_body_9, trap_handler_9, tenv_9);
  }
  KLObject* t721;
  {
    KLObject* a721[] = {t692, t693, t694, t700};
    t721 = shen_apply_direct(ctx, "shen.change-pointer-value", 4, a721);
  }
  KLObject* t718;
  {
    KLObject* a718[] = {t695, t696, t721};
    t718 = shen_apply_direct(ctx, "vector->", 3, a718);
  }
    return t694;
  }
}

static KLObject* native_kl_unput_47 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t727 = objects[0];
    KLObject* t728 = objects[1];
    KLObject* t729 = objects[2];
  tail_start_kl_unput_47: ;
  KLObject* t732;
  {
    KLObject* a732[] = {t729};
    t732 = shen_apply_direct(ctx, "limit", 1, a732);
  }
  KLObject* t730;
  {
    KLObject* a730[] = {t727, t732};
    t730 = shen_apply_direct(ctx, "hash", 2, a730);
  }
  KLObject* t734;
  {
    Vector* tenv_10 = shen_vector(ctx, 4);
    shen_vector_set(ctx, tenv_10, 0, t727);
    shen_vector_set(ctx, tenv_10, 1, t728);
    shen_vector_set(ctx, tenv_10, 2, t729);
    shen_vector_set(ctx, tenv_10, 3, t730);
    t734 = shen_trap_error(ctx, trap_body_10, trap_handler_10, tenv_10);
  }
  KLObject* t753;
  {
    KLObject* a753[] = {t727, t728, t734};
    t753 = shen_apply_direct(ctx, "shen.remove-pointer", 3, a753);
  }
  KLObject* t750;
  {
    KLObject* a750[] = {t729, t730, t753};
    t750 = shen_apply_direct(ctx, "vector->", 3, a750);
  }
    return t727;
  }
}

static KLObject* native_kl_shen_2eremove_2dpointer_48 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t758 = objects[0];
    KLObject* t759 = objects[1];
    KLObject* t760 = objects[2];
  tail_start_kl_shen_2eremove_2dpointer_48: ;
  KLObject* t761;
  {
  KLObject* t762 = shen_empty_list(ctx);
  KLObject* t764 = shen_eq(ctx, t762, t760);
    if (!shen_is_boolean(ctx, t764))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t764)) {
  KLObject* t765 = shen_empty_list(ctx);
      t761 = t765;
    } else {
  KLObject* t768 = shen_cons_p(ctx, t760);
  KLObject* t766;
  if (!shen_is_boolean(ctx, t768))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t768)) {
    t766 = t768;
  } else {
  KLObject* t771 = shen_hd(ctx, t760);
  KLObject* t772 = shen_cons_p(ctx, t771);
  KLObject* t769;
  if (!shen_is_boolean(ctx, t772))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t772)) {
    t769 = t772;
  } else {
  KLObject* t775 = shen_hd(ctx, t760);
  KLObject* t776 = shen_hd(ctx, t775);
  KLObject* t777 = shen_cons_p(ctx, t776);
  KLObject* t773;
  if (!shen_is_boolean(ctx, t777))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t777)) {
    t773 = t777;
  } else {
  KLObject* t780 = shen_hd(ctx, t760);
  KLObject* t781 = shen_hd(ctx, t780);
  KLObject* t782 = shen_tl(ctx, t781);
  KLObject* t783 = shen_cons_p(ctx, t782);
  KLObject* t778;
  if (!shen_is_boolean(ctx, t783))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t783)) {
    t778 = t783;
  } else {
  KLObject* t785 = shen_empty_list(ctx);
  KLObject* t787 = shen_hd(ctx, t760);
  KLObject* t788 = shen_hd(ctx, t787);
  KLObject* t789 = shen_tl(ctx, t788);
  KLObject* t790 = shen_tl(ctx, t789);
  KLObject* t791 = shen_eq(ctx, t785, t790);
  KLObject* t784;
  if (!shen_is_boolean(ctx, t791))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t791)) {
    t784 = t791;
  } else {
  KLObject* t795 = shen_hd(ctx, t760);
  KLObject* t796 = shen_hd(ctx, t795);
  KLObject* t797 = shen_tl(ctx, t796);
  KLObject* t798 = shen_hd(ctx, t797);
  KLObject* t799 = shen_eq(ctx, t759, t798);
  KLObject* t792;
  if (!shen_is_boolean(ctx, t799))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t799)) {
    t792 = t799;
  } else {
  KLObject* t802 = shen_hd(ctx, t760);
  KLObject* t803 = shen_hd(ctx, t802);
  KLObject* t804 = shen_hd(ctx, t803);
  KLObject* t805 = shen_eq(ctx, t758, t804);
    if (!shen_is_boolean(ctx, t805))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t792 = t805;
  }
    if (!shen_is_boolean(ctx, t792))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t784 = t792;
  }
    if (!shen_is_boolean(ctx, t784))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t778 = t784;
  }
    if (!shen_is_boolean(ctx, t778))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t773 = t778;
  }
    if (!shen_is_boolean(ctx, t773))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t769 = t773;
  }
    if (!shen_is_boolean(ctx, t769))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t766 = t769;
  }
    if (!shen_is_boolean(ctx, t766))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t766)) {
  KLObject* t807 = shen_tl(ctx, t760);
      t761 = t807;
    } else {
  KLObject* t809 = shen_cons_p(ctx, t760);
    if (!shen_is_boolean(ctx, t809))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t809)) {
  KLObject* t811 = shen_hd(ctx, t760);
  KLObject* t816 = shen_tl(ctx, t760);
  KLObject* t812;
  {
    KLObject* a812[] = {t758, t759, t816};
    t812 = shen_apply_direct(ctx, "shen.remove-pointer", 3, a812);
  }
  KLObject* t817 = shen_cons(ctx, t811, t812);
      t761 = t817;
    } else {
  KLObject* t818 = shen_true(ctx);
    if (!shen_is_boolean(ctx, t818))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t818)) {
  KLObject* t820 = shen_string(ctx, "implementation error in shen.remove-pointer");
  KLObject* t819;
  {
    KLObject* a819[] = {t820};
    t819 = shen_tail_apply_direct(ctx, "simple-error", 1, a819);
  }
      t761 = t819;
    } else {
      shen_simple_error(ctx, "No true case found for cond");
      t761 = shen_empty_list(ctx);
    }
    }
    }
    }
  }
    return t761;
  }
}

static KLObject* native_kl_shen_2echange_2dpointer_2dvalue_49 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t821 = objects[0];
    KLObject* t822 = objects[1];
    KLObject* t823 = objects[2];
    KLObject* t824 = objects[3];
  tail_start_kl_shen_2echange_2dpointer_2dvalue_49: ;
  KLObject* t825;
  {
  KLObject* t826 = shen_empty_list(ctx);
  KLObject* t828 = shen_eq(ctx, t826, t824);
    if (!shen_is_boolean(ctx, t828))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t828)) {
  KLObject* t831 = shen_empty_list(ctx);
  KLObject* t832 = shen_cons(ctx, t822, t831);
  KLObject* t833 = shen_cons(ctx, t821, t832);
  KLObject* t835 = shen_cons(ctx, t833, t823);
  KLObject* t836 = shen_empty_list(ctx);
  KLObject* t837 = shen_cons(ctx, t835, t836);
      t825 = t837;
    } else {
  KLObject* t840 = shen_cons_p(ctx, t824);
  KLObject* t838;
  if (!shen_is_boolean(ctx, t840))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t840)) {
    t838 = t840;
  } else {
  KLObject* t843 = shen_hd(ctx, t824);
  KLObject* t844 = shen_cons_p(ctx, t843);
  KLObject* t841;
  if (!shen_is_boolean(ctx, t844))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t844)) {
    t841 = t844;
  } else {
  KLObject* t847 = shen_hd(ctx, t824);
  KLObject* t848 = shen_hd(ctx, t847);
  KLObject* t849 = shen_cons_p(ctx, t848);
  KLObject* t845;
  if (!shen_is_boolean(ctx, t849))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t849)) {
    t845 = t849;
  } else {
  KLObject* t852 = shen_hd(ctx, t824);
  KLObject* t853 = shen_hd(ctx, t852);
  KLObject* t854 = shen_tl(ctx, t853);
  KLObject* t855 = shen_cons_p(ctx, t854);
  KLObject* t850;
  if (!shen_is_boolean(ctx, t855))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t855)) {
    t850 = t855;
  } else {
  KLObject* t857 = shen_empty_list(ctx);
  KLObject* t859 = shen_hd(ctx, t824);
  KLObject* t860 = shen_hd(ctx, t859);
  KLObject* t861 = shen_tl(ctx, t860);
  KLObject* t862 = shen_tl(ctx, t861);
  KLObject* t863 = shen_eq(ctx, t857, t862);
  KLObject* t856;
  if (!shen_is_boolean(ctx, t863))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t863)) {
    t856 = t863;
  } else {
  KLObject* t867 = shen_hd(ctx, t824);
  KLObject* t868 = shen_hd(ctx, t867);
  KLObject* t869 = shen_tl(ctx, t868);
  KLObject* t870 = shen_hd(ctx, t869);
  KLObject* t871 = shen_eq(ctx, t822, t870);
  KLObject* t864;
  if (!shen_is_boolean(ctx, t871))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t871)) {
    t864 = t871;
  } else {
  KLObject* t874 = shen_hd(ctx, t824);
  KLObject* t875 = shen_hd(ctx, t874);
  KLObject* t876 = shen_hd(ctx, t875);
  KLObject* t877 = shen_eq(ctx, t821, t876);
    if (!shen_is_boolean(ctx, t877))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t864 = t877;
  }
    if (!shen_is_boolean(ctx, t864))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t856 = t864;
  }
    if (!shen_is_boolean(ctx, t856))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t850 = t856;
  }
    if (!shen_is_boolean(ctx, t850))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t845 = t850;
  }
    if (!shen_is_boolean(ctx, t845))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t841 = t845;
  }
    if (!shen_is_boolean(ctx, t841))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t838 = t841;
  }
    if (!shen_is_boolean(ctx, t838))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t838)) {
  KLObject* t879 = shen_hd(ctx, t824);
  KLObject* t880 = shen_hd(ctx, t879);
  KLObject* t882 = shen_cons(ctx, t880, t823);
  KLObject* t884 = shen_tl(ctx, t824);
  KLObject* t885 = shen_cons(ctx, t882, t884);
      t825 = t885;
    } else {
  KLObject* t887 = shen_cons_p(ctx, t824);
    if (!shen_is_boolean(ctx, t887))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t887)) {
  KLObject* t889 = shen_hd(ctx, t824);
  KLObject* t895 = shen_tl(ctx, t824);
  KLObject* t890;
  {
    KLObject* a890[] = {t821, t822, t823, t895};
    t890 = shen_apply_direct(ctx, "shen.change-pointer-value", 4, a890);
  }
  KLObject* t896 = shen_cons(ctx, t889, t890);
      t825 = t896;
    } else {
  KLObject* t897 = shen_true(ctx);
    if (!shen_is_boolean(ctx, t897))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t897)) {
  KLObject* t899 = shen_string(ctx, "implementation error in shen.change-pointer-value");
  KLObject* t898;
  {
    KLObject* a898[] = {t899};
    t898 = shen_tail_apply_direct(ctx, "simple-error", 1, a898);
  }
      t825 = t898;
    } else {
      shen_simple_error(ctx, "No true case found for cond");
      t825 = shen_empty_list(ctx);
    }
    }
    }
    }
  }
    return t825;
  }
}

static KLObject* native_kl_get_50 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t900 = objects[0];
    KLObject* t901 = objects[1];
    KLObject* t902 = objects[2];
  tail_start_kl_get_50: ;
  KLObject* t905;
  {
    KLObject* a905[] = {t902};
    t905 = shen_apply_direct(ctx, "limit", 1, a905);
  }
  KLObject* t903;
  {
    KLObject* a903[] = {t900, t905};
    t903 = shen_apply_direct(ctx, "hash", 2, a903);
  }
  KLObject* t907;
  {
    Vector* tenv_11 = shen_vector(ctx, 4);
    shen_vector_set(ctx, tenv_11, 0, t900);
    shen_vector_set(ctx, tenv_11, 1, t901);
    shen_vector_set(ctx, tenv_11, 2, t902);
    shen_vector_set(ctx, tenv_11, 3, t903);
    t907 = shen_trap_error(ctx, trap_body_11, trap_handler_11, tenv_11);
  }
  KLObject* t937 = shen_empty_list(ctx);
  KLObject* t938 = shen_cons(ctx, t901, t937);
  KLObject* t939 = shen_cons(ctx, t900, t938);
  KLObject* t934;
  {
    KLObject* a934[] = {t939, t907};
    t934 = shen_apply_direct(ctx, "assoc", 2, a934);
  }
  KLObject* t942;
  {
    KLObject* a942[] = {t934};
    t942 = shen_apply_direct(ctx, "empty?", 1, a942);
  }
  KLObject* t941;
  if (!shen_is_boolean(ctx, t942))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t942)) {
  KLObject* t946 = shen_string(ctx, "attribute ");
  KLObject* t950 = shen_string(ctx, " not found for ");
  KLObject* t953 = shen_string(ctx, "\n");
  KLObject* t954 = shen_intern(ctx, "shen.s");
  KLObject* t951;
  {
    KLObject* a951[] = {t900, t953, t954};
    t951 = shen_apply_direct(ctx, "shen.app", 3, a951);
  }
  KLObject* t949;
  {
    KLObject* a949[] = {t950, t951};
    t949 = shen_apply_direct(ctx, "cn", 2, a949);
  }
  KLObject* t955 = shen_intern(ctx, "shen.s");
  KLObject* t947;
  {
    KLObject* a947[] = {t901, t949, t955};
    t947 = shen_apply_direct(ctx, "shen.app", 3, a947);
  }
  KLObject* t945;
  {
    KLObject* a945[] = {t946, t947};
    t945 = shen_apply_direct(ctx, "cn", 2, a945);
  }
  KLObject* t944;
  {
    KLObject* a944[] = {t945};
    t944 = shen_tail_apply_direct(ctx, "simple-error", 1, a944);
  }
    t941 = t944;
  } else {
  KLObject* t957 = shen_tl(ctx, t934);
    t941 = t957;
  }
    return t941;
  }
}

static KLObject* native_kl_hash_51 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t958 = objects[0];
    KLObject* t959 = objects[1];
  tail_start_kl_hash_51: ;
  KLObject* t961;
  {
    KLObject* a961[] = {t958};
    t961 = shen_apply_direct(ctx, "shen.hashkey", 1, a961);
  }
  KLObject* t960;
  {
    KLObject* a960[] = {t961, t959};
    t960 = shen_apply_direct(ctx, "shen.mod", 2, a960);
  }
  KLObject* t966 = shen_number_l(ctx, 0);
  KLObject* t967 = shen_eq(ctx, t960, t966);
  KLObject* t964;
  if (!shen_is_boolean(ctx, t967))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t967)) {
  KLObject* t968 = shen_number_l(ctx, 1);
    t964 = t968;
  } else {
    t964 = t960;
  }
    return t964;
  }
}

static KLObject* native_kl_shen_2ehashkey_52 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t970 = objects[0];
  tail_start_kl_shen_2ehashkey_52: ;
  KLObject* t972;
  {
    Vector* caps_12 = shen_vector(ctx, 0);
    t972 = shen_native_closure(ctx, 1, &lambda_12, caps_12);
  }
  KLObject* t976;
  {
    KLObject* a976[] = {t970};
    t976 = shen_apply_direct(ctx, "explode", 1, a976);
  }
  KLObject* t971;
  {
    KLObject* a971[] = {t972, t976};
    t971 = shen_apply_direct(ctx, "map", 2, a971);
  }
  KLObject* t980 = shen_number_l(ctx, 1);
  KLObject* t978;
  {
    KLObject* a978[] = {t971, t980};
    t978 = shen_tail_apply_direct(ctx, "shen.prodbutzero", 2, a978);
  }
    return t978;
  }
}

static KLObject* native_kl_shen_2eprodbutzero_53 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t981 = objects[0];
    KLObject* t982 = objects[1];
  tail_start_kl_shen_2eprodbutzero_53: ;
  KLObject* t983;
  {
  KLObject* t984 = shen_empty_list(ctx);
  KLObject* t986 = shen_eq(ctx, t984, t981);
    if (!shen_is_boolean(ctx, t986))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t986)) {
      t983 = t982;
    } else {
  KLObject* t990 = shen_cons_p(ctx, t981);
  KLObject* t988;
  if (!shen_is_boolean(ctx, t990))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t990)) {
    t988 = t990;
  } else {
  KLObject* t991 = shen_number_l(ctx, 0);
  KLObject* t993 = shen_hd(ctx, t981);
  KLObject* t994 = shen_eq(ctx, t991, t993);
    if (!shen_is_boolean(ctx, t994))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t988 = t994;
  }
    if (!shen_is_boolean(ctx, t988))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t988)) {
  KLObject* t996 = shen_tl(ctx, t981);
  {
    KLObject* n998_0 = t996;
    KLObject* n998_1 = t982;
    t981 = n998_0;
    t982 = n998_1;
    goto tail_start_kl_shen_2eprodbutzero_53;
  }
  KLObject* t998 = NULL;
      t983 = t998;
    } else {
  KLObject* t1000 = shen_cons_p(ctx, t981);
    if (!shen_is_boolean(ctx, t1000))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t1000)) {
  KLObject* t1003 = shen_number_l(ctx, 10000000000);
  KLObject* t1004 = shen_gt(ctx, t982, t1003);
  KLObject* t1001;
  if (!shen_is_boolean(ctx, t1004))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1004)) {
  KLObject* t1006 = shen_tl(ctx, t981);
  KLObject* t1009 = shen_hd(ctx, t981);
  KLObject* t1010 = shen_add(ctx, t982, t1009);
  {
    KLObject* n1011_0 = t1006;
    KLObject* n1011_1 = t1010;
    t981 = n1011_0;
    t982 = n1011_1;
    goto tail_start_kl_shen_2eprodbutzero_53;
  }
  KLObject* t1011 = NULL;
    t1001 = t1011;
  } else {
  KLObject* t1013 = shen_tl(ctx, t981);
  KLObject* t1016 = shen_hd(ctx, t981);
  KLObject* t1017 = shen_mul(ctx, t982, t1016);
  {
    KLObject* n1018_0 = t1013;
    KLObject* n1018_1 = t1017;
    t981 = n1018_0;
    t982 = n1018_1;
    goto tail_start_kl_shen_2eprodbutzero_53;
  }
  KLObject* t1018 = NULL;
    t1001 = t1018;
  }
      t983 = t1001;
    } else {
  KLObject* t1019 = shen_true(ctx);
    if (!shen_is_boolean(ctx, t1019))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t1019)) {
  KLObject* t1021 = shen_string(ctx, "partial function shen.prodbutzero");
  KLObject* t1020;
  {
    KLObject* a1020[] = {t1021};
    t1020 = shen_tail_apply_direct(ctx, "simple-error", 1, a1020);
  }
      t983 = t1020;
    } else {
      shen_simple_error(ctx, "No true case found for cond");
      t983 = shen_empty_list(ctx);
    }
    }
    }
    }
  }
    return t983;
  }
}

static KLObject* native_kl_shen_2emod_54 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t1022 = objects[0];
    KLObject* t1023 = objects[1];
  tail_start_kl_shen_2emod_54: ;
  KLObject* t1029 = shen_empty_list(ctx);
  KLObject* t1030 = shen_cons(ctx, t1023, t1029);
  KLObject* t1026;
  {
    KLObject* a1026[] = {t1022, t1030};
    t1026 = shen_apply_direct(ctx, "shen.multiples", 2, a1026);
  }
  KLObject* t1024;
  {
    KLObject* a1024[] = {t1022, t1026};
    t1024 = shen_tail_apply_direct(ctx, "shen.modh", 2, a1024);
  }
    return t1024;
  }
}

static KLObject* native_kl_shen_2emultiples_55 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t1031 = objects[0];
    KLObject* t1032 = objects[1];
  tail_start_kl_shen_2emultiples_55: ;
  KLObject* t1033;
  {
  KLObject* t1036 = shen_cons_p(ctx, t1032);
  KLObject* t1034;
  if (!shen_is_boolean(ctx, t1036))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t1036)) {
    t1034 = t1036;
  } else {
  KLObject* t1038 = shen_hd(ctx, t1032);
  KLObject* t1040 = shen_gt(ctx, t1038, t1031);
    if (!shen_is_boolean(ctx, t1040))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t1034 = t1040;
  }
    if (!shen_is_boolean(ctx, t1034))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t1034)) {
  KLObject* t1042 = shen_tl(ctx, t1032);
      t1033 = t1042;
    } else {
  KLObject* t1044 = shen_cons_p(ctx, t1032);
    if (!shen_is_boolean(ctx, t1044))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t1044)) {
  KLObject* t1046 = shen_number_l(ctx, 2);
  KLObject* t1048 = shen_hd(ctx, t1032);
  KLObject* t1049 = shen_mul(ctx, t1046, t1048);
  KLObject* t1051 = shen_cons(ctx, t1049, t1032);
  {
    KLObject* n1052_0 = t1031;
    KLObject* n1052_1 = t1051;
    t1031 = n1052_0;
    t1032 = n1052_1;
    goto tail_start_kl_shen_2emultiples_55;
  }
  KLObject* t1052 = NULL;
      t1033 = t1052;
    } else {
  KLObject* t1053 = shen_true(ctx);
    if (!shen_is_boolean(ctx, t1053))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t1053)) {
  KLObject* t1055 = shen_string(ctx, "implementation error in shen.multiples");
  KLObject* t1054;
  {
    KLObject* a1054[] = {t1055};
    t1054 = shen_tail_apply_direct(ctx, "simple-error", 1, a1054);
  }
      t1033 = t1054;
    } else {
      shen_simple_error(ctx, "No true case found for cond");
      t1033 = shen_empty_list(ctx);
    }
    }
    }
  }
    return t1033;
  }
}

static KLObject* native_kl_shen_2emodh_56 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t1056 = objects[0];
    KLObject* t1057 = objects[1];
  tail_start_kl_shen_2emodh_56: ;
  KLObject* t1058;
  {
  KLObject* t1059 = shen_number_l(ctx, 0);
  KLObject* t1061 = shen_eq(ctx, t1059, t1056);
    if (!shen_is_boolean(ctx, t1061))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t1061)) {
  KLObject* t1062 = shen_number_l(ctx, 0);
      t1058 = t1062;
    } else {
  KLObject* t1063 = shen_empty_list(ctx);
  KLObject* t1065 = shen_eq(ctx, t1063, t1057);
    if (!shen_is_boolean(ctx, t1065))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t1065)) {
      t1058 = t1056;
    } else {
  KLObject* t1069 = shen_cons_p(ctx, t1057);
  KLObject* t1067;
  if (!shen_is_boolean(ctx, t1069))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t1069)) {
    t1067 = t1069;
  } else {
  KLObject* t1071 = shen_hd(ctx, t1057);
  KLObject* t1073 = shen_gt(ctx, t1071, t1056);
    if (!shen_is_boolean(ctx, t1073))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t1067 = t1073;
  }
    if (!shen_is_boolean(ctx, t1067))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t1067)) {
  KLObject* t1077 = shen_tl(ctx, t1057);
  KLObject* t1075;
  {
    KLObject* a1075[] = {t1077};
    t1075 = shen_apply_direct(ctx, "empty?", 1, a1075);
  }
  KLObject* t1074;
  if (!shen_is_boolean(ctx, t1075))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1075)) {
    t1074 = t1056;
  } else {
  KLObject* t1081 = shen_tl(ctx, t1057);
  {
    KLObject* n1082_0 = t1056;
    KLObject* n1082_1 = t1081;
    t1056 = n1082_0;
    t1057 = n1082_1;
    goto tail_start_kl_shen_2emodh_56;
  }
  KLObject* t1082 = NULL;
    t1074 = t1082;
  }
      t1058 = t1074;
    } else {
  KLObject* t1084 = shen_cons_p(ctx, t1057);
    if (!shen_is_boolean(ctx, t1084))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t1084)) {
  KLObject* t1087 = shen_hd(ctx, t1057);
  KLObject* t1088 = shen_sub(ctx, t1056, t1087);
  {
    KLObject* n1090_0 = t1088;
    KLObject* n1090_1 = t1057;
    t1056 = n1090_0;
    t1057 = n1090_1;
    goto tail_start_kl_shen_2emodh_56;
  }
  KLObject* t1090 = NULL;
      t1058 = t1090;
    } else {
  KLObject* t1091 = shen_true(ctx);
    if (!shen_is_boolean(ctx, t1091))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t1091)) {
  KLObject* t1093 = shen_string(ctx, "implementation error in shen.modh");
  KLObject* t1092;
  {
    KLObject* a1092[] = {t1093};
    t1092 = shen_tail_apply_direct(ctx, "simple-error", 1, a1092);
  }
      t1058 = t1092;
    } else {
      shen_simple_error(ctx, "No true case found for cond");
      t1058 = shen_empty_list(ctx);
    }
    }
    }
    }
    }
  }
    return t1058;
  }
}

static KLObject* native_kl_sum_57 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t1094 = objects[0];
  tail_start_kl_sum_57: ;
  KLObject* t1095;
  {
  KLObject* t1096 = shen_empty_list(ctx);
  KLObject* t1098 = shen_eq(ctx, t1096, t1094);
    if (!shen_is_boolean(ctx, t1098))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t1098)) {
  KLObject* t1099 = shen_number_l(ctx, 0);
      t1095 = t1099;
    } else {
  KLObject* t1101 = shen_cons_p(ctx, t1094);
    if (!shen_is_boolean(ctx, t1101))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t1101)) {
  KLObject* t1103 = shen_hd(ctx, t1094);
  KLObject* t1106 = shen_tl(ctx, t1094);
  KLObject* t1104;
  {
    KLObject* a1104[] = {t1106};
    t1104 = shen_apply_direct(ctx, "sum", 1, a1104);
  }
  KLObject* t1107 = shen_add(ctx, t1103, t1104);
      t1095 = t1107;
    } else {
  KLObject* t1108 = shen_true(ctx);
    if (!shen_is_boolean(ctx, t1108))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t1108)) {
  KLObject* t1110 = shen_string(ctx, "attempt to sum a non-list\n");
  KLObject* t1109;
  {
    KLObject* a1109[] = {t1110};
    t1109 = shen_tail_apply_direct(ctx, "simple-error", 1, a1109);
  }
      t1095 = t1109;
    } else {
      shen_simple_error(ctx, "No true case found for cond");
      t1095 = shen_empty_list(ctx);
    }
    }
    }
  }
    return t1095;
  }
}

static KLObject* native_kl_head_58 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t1111 = objects[0];
  tail_start_kl_head_58: ;
  KLObject* t1112;
  {
  KLObject* t1114 = shen_cons_p(ctx, t1111);
    if (!shen_is_boolean(ctx, t1114))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t1114)) {
  KLObject* t1116 = shen_hd(ctx, t1111);
      t1112 = t1116;
    } else {
  KLObject* t1117 = shen_true(ctx);
    if (!shen_is_boolean(ctx, t1117))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t1117)) {
  KLObject* t1119 = shen_string(ctx, "head expects a non-empty list\n");
  KLObject* t1118;
  {
    KLObject* a1118[] = {t1119};
    t1118 = shen_tail_apply_direct(ctx, "simple-error", 1, a1118);
  }
      t1112 = t1118;
    } else {
      shen_simple_error(ctx, "No true case found for cond");
      t1112 = shen_empty_list(ctx);
    }
    }
  }
    return t1112;
  }
}

static KLObject* native_kl_tail_59 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t1120 = objects[0];
  tail_start_kl_tail_59: ;
  KLObject* t1121;
  {
  KLObject* t1123 = shen_cons_p(ctx, t1120);
    if (!shen_is_boolean(ctx, t1123))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t1123)) {
  KLObject* t1125 = shen_tl(ctx, t1120);
      t1121 = t1125;
    } else {
  KLObject* t1126 = shen_true(ctx);
    if (!shen_is_boolean(ctx, t1126))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t1126)) {
  KLObject* t1128 = shen_string(ctx, "tail expects a non-empty list\n");
  KLObject* t1127;
  {
    KLObject* a1127[] = {t1128};
    t1127 = shen_tail_apply_direct(ctx, "simple-error", 1, a1127);
  }
      t1121 = t1127;
    } else {
      shen_simple_error(ctx, "No true case found for cond");
      t1121 = shen_empty_list(ctx);
    }
    }
  }
    return t1121;
  }
}

static KLObject* native_kl_hdstr_60 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t1129 = objects[0];
  tail_start_kl_hdstr_60: ;
  KLObject* t1132 = shen_number_l(ctx, 0);
  KLObject* t1130;
  {
    KLObject* a1130[] = {t1129, t1132};
    t1130 = shen_tail_apply_direct(ctx, "pos", 2, a1130);
  }
    return t1130;
  }
}

static KLObject* native_kl_intersection_61 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t1133 = objects[0];
    KLObject* t1134 = objects[1];
  tail_start_kl_intersection_61: ;
  KLObject* t1135;
  {
  KLObject* t1136 = shen_empty_list(ctx);
  KLObject* t1138 = shen_eq(ctx, t1136, t1133);
    if (!shen_is_boolean(ctx, t1138))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t1138)) {
  KLObject* t1139 = shen_empty_list(ctx);
      t1135 = t1139;
    } else {
  KLObject* t1141 = shen_cons_p(ctx, t1133);
    if (!shen_is_boolean(ctx, t1141))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t1141)) {
  KLObject* t1145 = shen_hd(ctx, t1133);
  KLObject* t1143;
  {
    KLObject* a1143[] = {t1145, t1134};
    t1143 = shen_apply_direct(ctx, "element?", 2, a1143);
  }
  KLObject* t1142;
  if (!shen_is_boolean(ctx, t1143))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1143)) {
  KLObject* t1148 = shen_hd(ctx, t1133);
  KLObject* t1151 = shen_tl(ctx, t1133);
  KLObject* t1149;
  {
    KLObject* a1149[] = {t1151, t1134};
    t1149 = shen_apply_direct(ctx, "intersection", 2, a1149);
  }
  KLObject* t1153 = shen_cons(ctx, t1148, t1149);
    t1142 = t1153;
  } else {
  KLObject* t1155 = shen_tl(ctx, t1133);
  {
    KLObject* n1157_0 = t1155;
    KLObject* n1157_1 = t1134;
    t1133 = n1157_0;
    t1134 = n1157_1;
    goto tail_start_kl_intersection_61;
  }
  KLObject* t1157 = NULL;
    t1142 = t1157;
  }
      t1135 = t1142;
    } else {
  KLObject* t1158 = shen_true(ctx);
    if (!shen_is_boolean(ctx, t1158))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t1158)) {
  KLObject* t1160 = shen_string(ctx, "attempt to find the intersection with a non-list\n");
  KLObject* t1159;
  {
    KLObject* a1159[] = {t1160};
    t1159 = shen_tail_apply_direct(ctx, "simple-error", 1, a1159);
  }
      t1135 = t1159;
    } else {
      shen_simple_error(ctx, "No true case found for cond");
      t1135 = shen_empty_list(ctx);
    }
    }
    }
  }
    return t1135;
  }
}

static KLObject* native_kl_reverse_62 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t1161 = objects[0];
  tail_start_kl_reverse_62: ;
  KLObject* t1164 = shen_empty_list(ctx);
  KLObject* t1162;
  {
    KLObject* a1162[] = {t1161, t1164};
    t1162 = shen_tail_apply_direct(ctx, "shen.reverse-help", 2, a1162);
  }
    return t1162;
  }
}

static KLObject* native_kl_shen_2ereverse_2dhelp_63 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t1165 = objects[0];
    KLObject* t1166 = objects[1];
  tail_start_kl_shen_2ereverse_2dhelp_63: ;
  KLObject* t1167;
  {
  KLObject* t1168 = shen_empty_list(ctx);
  KLObject* t1170 = shen_eq(ctx, t1168, t1165);
    if (!shen_is_boolean(ctx, t1170))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t1170)) {
      t1167 = t1166;
    } else {
  KLObject* t1173 = shen_cons_p(ctx, t1165);
    if (!shen_is_boolean(ctx, t1173))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t1173)) {
  KLObject* t1175 = shen_tl(ctx, t1165);
  KLObject* t1177 = shen_hd(ctx, t1165);
  KLObject* t1179 = shen_cons(ctx, t1177, t1166);
  {
    KLObject* n1180_0 = t1175;
    KLObject* n1180_1 = t1179;
    t1165 = n1180_0;
    t1166 = n1180_1;
    goto tail_start_kl_shen_2ereverse_2dhelp_63;
  }
  KLObject* t1180 = NULL;
      t1167 = t1180;
    } else {
  KLObject* t1181 = shen_true(ctx);
    if (!shen_is_boolean(ctx, t1181))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t1181)) {
  KLObject* t1183 = shen_string(ctx, "attempt to reverse a non-list\n");
  KLObject* t1182;
  {
    KLObject* a1182[] = {t1183};
    t1182 = shen_tail_apply_direct(ctx, "simple-error", 1, a1182);
  }
      t1167 = t1182;
    } else {
      shen_simple_error(ctx, "No true case found for cond");
      t1167 = shen_empty_list(ctx);
    }
    }
    }
  }
    return t1167;
  }
}

static KLObject* native_kl_union_64 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t1184 = objects[0];
    KLObject* t1185 = objects[1];
  tail_start_kl_union_64: ;
  KLObject* t1186;
  {
  KLObject* t1187 = shen_empty_list(ctx);
  KLObject* t1189 = shen_eq(ctx, t1187, t1184);
    if (!shen_is_boolean(ctx, t1189))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t1189)) {
      t1186 = t1185;
    } else {
  KLObject* t1192 = shen_cons_p(ctx, t1184);
    if (!shen_is_boolean(ctx, t1192))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t1192)) {
  KLObject* t1196 = shen_hd(ctx, t1184);
  KLObject* t1194;
  {
    KLObject* a1194[] = {t1196, t1185};
    t1194 = shen_apply_direct(ctx, "element?", 2, a1194);
  }
  KLObject* t1193;
  if (!shen_is_boolean(ctx, t1194))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1194)) {
  KLObject* t1199 = shen_tl(ctx, t1184);
  {
    KLObject* n1201_0 = t1199;
    KLObject* n1201_1 = t1185;
    t1184 = n1201_0;
    t1185 = n1201_1;
    goto tail_start_kl_union_64;
  }
  KLObject* t1201 = NULL;
    t1193 = t1201;
  } else {
  KLObject* t1203 = shen_hd(ctx, t1184);
  KLObject* t1206 = shen_tl(ctx, t1184);
  KLObject* t1204;
  {
    KLObject* a1204[] = {t1206, t1185};
    t1204 = shen_apply_direct(ctx, "union", 2, a1204);
  }
  KLObject* t1208 = shen_cons(ctx, t1203, t1204);
    t1193 = t1208;
  }
      t1186 = t1193;
    } else {
  KLObject* t1209 = shen_true(ctx);
    if (!shen_is_boolean(ctx, t1209))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t1209)) {
  KLObject* t1211 = shen_string(ctx, "attempt to find the union with a non-list\n");
  KLObject* t1210;
  {
    KLObject* a1210[] = {t1211};
    t1210 = shen_tail_apply_direct(ctx, "simple-error", 1, a1210);
  }
      t1186 = t1210;
    } else {
      shen_simple_error(ctx, "No true case found for cond");
      t1186 = shen_empty_list(ctx);
    }
    }
    }
  }
    return t1186;
  }
}

static KLObject* native_kl_y_2dor_2dn_3f_65 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t1212 = objects[0];
  tail_start_kl_y_2dor_2dn_3f_65: ;
  KLObject* t1214;
  {
    KLObject* a1214[] = {t1212};
    t1214 = shen_apply_direct(ctx, "shen.proc-nl", 1, a1214);
  }
  KLObject* t1216 = shen_apply_direct(ctx, "stoutput", 0, NULL);
  KLObject* t1213;
  {
    KLObject* a1213[] = {t1214, t1216};
    t1213 = shen_apply_direct(ctx, "pr", 2, a1213);
  }
  KLObject* t1218 = shen_string(ctx, " (y/n) ");
  KLObject* t1219 = shen_apply_direct(ctx, "stoutput", 0, NULL);
  KLObject* t1217;
  {
    KLObject* a1217[] = {t1218, t1219};
    t1217 = shen_apply_direct(ctx, "pr", 2, a1217);
  }
  KLObject* t1222 = shen_apply_direct(ctx, "stinput", 0, NULL);
  KLObject* t1221;
  {
    KLObject* a1221[] = {t1222};
    t1221 = shen_apply_direct(ctx, "read", 1, a1221);
  }
  KLObject* t1223 = shen_string(ctx, "");
  KLObject* t1224 = shen_intern(ctx, "shen.s");
  KLObject* t1220;
  {
    KLObject* a1220[] = {t1221, t1223, t1224};
    t1220 = shen_apply_direct(ctx, "shen.app", 3, a1220);
  }
  KLObject* t1226 = shen_string(ctx, "y");
  KLObject* t1228 = shen_eq(ctx, t1226, t1220);
  KLObject* t1225;
  if (!shen_is_boolean(ctx, t1228))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1228)) {
  KLObject* t1229 = shen_true(ctx);
    t1225 = t1229;
  } else {
  KLObject* t1231 = shen_string(ctx, "n");
  KLObject* t1233 = shen_eq(ctx, t1231, t1220);
  KLObject* t1230;
  if (!shen_is_boolean(ctx, t1233))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1233)) {
  KLObject* t1234 = shen_false(ctx);
    t1230 = t1234;
  } else {
  KLObject* t1236 = shen_string(ctx, "please answer y or n\n");
  KLObject* t1237 = shen_apply_direct(ctx, "stoutput", 0, NULL);
  KLObject* t1235;
  {
    KLObject* a1235[] = {t1236, t1237};
    t1235 = shen_apply_direct(ctx, "pr", 2, a1235);
  }
  {
    KLObject* n1239_0 = t1212;
    t1212 = n1239_0;
    goto tail_start_kl_y_2dor_2dn_3f_65;
  }
  KLObject* t1239 = NULL;
    t1230 = t1239;
  }
    t1225 = t1230;
  }
    return t1225;
  }
}

static KLObject* native_kl_not_66 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t1240 = objects[0];
  tail_start_kl_not_66: ;
  KLObject* t1241;
  if (!shen_is_boolean(ctx, t1240))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1240)) {
  KLObject* t1243 = shen_false(ctx);
    t1241 = t1243;
  } else {
  KLObject* t1244 = shen_true(ctx);
    t1241 = t1244;
  }
    return t1241;
  }
}

static KLObject* native_kl_abort_67 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  (void)function_object;
  (void)arguments;
  {
  tail_start_kl_abort_67: ;
  KLObject* t1246 = shen_string(ctx, "");
  KLObject* t1245;
  {
    KLObject* a1245[] = {t1246};
    t1245 = shen_tail_apply_direct(ctx, "simple-error", 1, a1245);
  }
    return t1245;
  }
}

static KLObject* native_kl_subst_68 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t1247 = objects[0];
    KLObject* t1248 = objects[1];
    KLObject* t1249 = objects[2];
  tail_start_kl_subst_68: ;
  KLObject* t1250;
  {
  KLObject* t1253 = shen_eq(ctx, t1248, t1249);
    if (!shen_is_boolean(ctx, t1253))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t1253)) {
      t1250 = t1247;
    } else {
  KLObject* t1256 = shen_cons_p(ctx, t1249);
    if (!shen_is_boolean(ctx, t1256))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t1256)) {
  KLObject* t1261 = shen_hd(ctx, t1249);
  KLObject* t1257;
  {
    KLObject* a1257[] = {t1247, t1248, t1261};
    t1257 = shen_apply_direct(ctx, "subst", 3, a1257);
  }
  KLObject* t1266 = shen_tl(ctx, t1249);
  KLObject* t1262;
  {
    KLObject* a1262[] = {t1247, t1248, t1266};
    t1262 = shen_apply_direct(ctx, "subst", 3, a1262);
  }
  KLObject* t1267 = shen_cons(ctx, t1257, t1262);
      t1250 = t1267;
    } else {
  KLObject* t1268 = shen_true(ctx);
    if (!shen_is_boolean(ctx, t1268))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t1268)) {
      t1250 = t1249;
    } else {
      shen_simple_error(ctx, "No true case found for cond");
      t1250 = shen_empty_list(ctx);
    }
    }
    }
  }
    return t1250;
  }
}

static KLObject* native_kl_explode_69 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t1270 = objects[0];
  tail_start_kl_explode_69: ;
  KLObject* t1274 = shen_string(ctx, "");
  KLObject* t1275 = shen_intern(ctx, "shen.a");
  KLObject* t1272;
  {
    KLObject* a1272[] = {t1270, t1274, t1275};
    t1272 = shen_apply_direct(ctx, "shen.app", 3, a1272);
  }
  KLObject* t1271;
  {
    KLObject* a1271[] = {t1272};
    t1271 = shen_tail_apply_direct(ctx, "shen.explode-h", 1, a1271);
  }
    return t1271;
  }
}

static KLObject* native_kl_shen_2eexplode_2dh_70 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t1276 = objects[0];
  tail_start_kl_shen_2eexplode_2dh_70: ;
  KLObject* t1277;
  {
  KLObject* t1278 = shen_string(ctx, "");
  KLObject* t1280 = shen_eq(ctx, t1278, t1276);
    if (!shen_is_boolean(ctx, t1280))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t1280)) {
  KLObject* t1281 = shen_empty_list(ctx);
      t1277 = t1281;
    } else {
  KLObject* t1282;
  {
    KLObject* a1282[] = {t1276};
    t1282 = shen_apply_direct(ctx, "shen.+string?", 1, a1282);
  }
    if (!shen_is_boolean(ctx, t1282))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t1282)) {
  KLObject* t1284;
  {
    KLObject* a1284[] = {t1276};
    t1284 = shen_apply_direct(ctx, "hdstr", 1, a1284);
  }
  KLObject* t1287;
  {
    KLObject* a1287[] = {t1276};
    t1287 = shen_apply_direct(ctx, "tlstr", 1, a1287);
  }
  KLObject* t1286;
  {
    KLObject* a1286[] = {t1287};
    t1286 = shen_apply_direct(ctx, "shen.explode-h", 1, a1286);
  }
  KLObject* t1289 = shen_cons(ctx, t1284, t1286);
      t1277 = t1289;
    } else {
  KLObject* t1290 = shen_true(ctx);
    if (!shen_is_boolean(ctx, t1290))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t1290)) {
  KLObject* t1292 = shen_string(ctx, "implementation error in explode-h");
  KLObject* t1291;
  {
    KLObject* a1291[] = {t1292};
    t1291 = shen_tail_apply_direct(ctx, "simple-error", 1, a1291);
  }
      t1277 = t1291;
    } else {
      shen_simple_error(ctx, "No true case found for cond");
      t1277 = shen_empty_list(ctx);
    }
    }
    }
  }
    return t1277;
  }
}

static KLObject* native_kl_cd_71 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t1293 = objects[0];
  tail_start_kl_cd_71: ;
  KLObject* t1295 = shen_intern(ctx, "*home-directory*");
  KLObject* t1298 = shen_string(ctx, "");
  KLObject* t1299 = shen_eq(ctx, t1293, t1298);
  KLObject* t1296;
  if (!shen_is_boolean(ctx, t1299))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1299)) {
  KLObject* t1300 = shen_string(ctx, "");
    t1296 = t1300;
  } else {
  KLObject* t1303 = shen_string(ctx, "/");
  KLObject* t1304 = shen_intern(ctx, "shen.a");
  KLObject* t1301;
  {
    KLObject* a1301[] = {t1293, t1303, t1304};
    t1301 = shen_apply_direct(ctx, "shen.app", 3, a1301);
  }
    t1296 = t1301;
  }
  KLObject* t1294;
  {
    KLObject* a1294[] = {t1295, t1296};
    t1294 = shen_tail_apply_direct(ctx, "set", 2, a1294);
  }
    return t1294;
  }
}

static KLObject* native_kl_map_72 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t1305 = objects[0];
    KLObject* t1306 = objects[1];
  tail_start_kl_map_72: ;
  KLObject* t1310 = shen_empty_list(ctx);
  KLObject* t1307;
  {
    KLObject* a1307[] = {t1305, t1306, t1310};
    t1307 = shen_tail_apply_direct(ctx, "shen.map-h", 3, a1307);
  }
    return t1307;
  }
}

static KLObject* native_kl_shen_2emap_2dh_73 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t1311 = objects[0];
    KLObject* t1312 = objects[1];
    KLObject* t1313 = objects[2];
  tail_start_kl_shen_2emap_2dh_73: ;
  KLObject* t1314;
  {
  KLObject* t1315 = shen_empty_list(ctx);
  KLObject* t1317 = shen_eq(ctx, t1315, t1312);
    if (!shen_is_boolean(ctx, t1317))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t1317)) {
  KLObject* t1318;
  {
    KLObject* a1318[] = {t1313};
    t1318 = shen_tail_apply_direct(ctx, "reverse", 1, a1318);
  }
      t1314 = t1318;
    } else {
  KLObject* t1321 = shen_cons_p(ctx, t1312);
    if (!shen_is_boolean(ctx, t1321))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t1321)) {
  KLObject* t1324 = shen_tl(ctx, t1312);
  KLObject* t1328 = shen_hd(ctx, t1312);
  KLObject* t1325;
  {
    Vector* a1325 = shen_vector(ctx, 1);
    shen_vector_set(ctx, a1325, 0, t1328);
    t1325 = shen_apply(ctx, t1311, a1325);
  }
  KLObject* t1330 = shen_cons(ctx, t1325, t1313);
  {
    KLObject* n1331_0 = t1311;
    KLObject* n1331_1 = t1324;
    KLObject* n1331_2 = t1330;
    t1311 = n1331_0;
    t1312 = n1331_1;
    t1313 = n1331_2;
    goto tail_start_kl_shen_2emap_2dh_73;
  }
  KLObject* t1331 = NULL;
      t1314 = t1331;
    } else {
  KLObject* t1332 = shen_true(ctx);
    if (!shen_is_boolean(ctx, t1332))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t1332)) {
  KLObject* t1334 = shen_string(ctx, "partial function shen.map-h");
  KLObject* t1333;
  {
    KLObject* a1333[] = {t1334};
    t1333 = shen_tail_apply_direct(ctx, "simple-error", 1, a1333);
  }
      t1314 = t1333;
    } else {
      shen_simple_error(ctx, "No true case found for cond");
      t1314 = shen_empty_list(ctx);
    }
    }
    }
  }
    return t1314;
  }
}

static KLObject* native_kl_length_74 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t1335 = objects[0];
  tail_start_kl_length_74: ;
  KLObject* t1338 = shen_number_l(ctx, 0);
  KLObject* t1336;
  {
    KLObject* a1336[] = {t1335, t1338};
    t1336 = shen_tail_apply_direct(ctx, "shen.length-h", 2, a1336);
  }
    return t1336;
  }
}

static KLObject* native_kl_shen_2elength_2dh_75 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t1339 = objects[0];
    KLObject* t1340 = objects[1];
  tail_start_kl_shen_2elength_2dh_75: ;
  KLObject* t1341;
  {
  KLObject* t1342 = shen_empty_list(ctx);
  KLObject* t1344 = shen_eq(ctx, t1342, t1339);
    if (!shen_is_boolean(ctx, t1344))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t1344)) {
      t1341 = t1340;
    } else {
  KLObject* t1346 = shen_true(ctx);
    if (!shen_is_boolean(ctx, t1346))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t1346)) {
  KLObject* t1348 = shen_tl(ctx, t1339);
  KLObject* t1350 = shen_number_l(ctx, 1);
  KLObject* t1351 = shen_add(ctx, t1340, t1350);
  {
    KLObject* n1352_0 = t1348;
    KLObject* n1352_1 = t1351;
    t1339 = n1352_0;
    t1340 = n1352_1;
    goto tail_start_kl_shen_2elength_2dh_75;
  }
  KLObject* t1352 = NULL;
      t1341 = t1352;
    } else {
      shen_simple_error(ctx, "No true case found for cond");
      t1341 = shen_empty_list(ctx);
    }
    }
  }
    return t1341;
  }
}

static KLObject* native_kl_occurrences_76 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t1353 = objects[0];
    KLObject* t1354 = objects[1];
  tail_start_kl_occurrences_76: ;
  KLObject* t1355;
  {
  KLObject* t1358 = shen_eq(ctx, t1353, t1354);
    if (!shen_is_boolean(ctx, t1358))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t1358)) {
  KLObject* t1359 = shen_number_l(ctx, 1);
      t1355 = t1359;
    } else {
  KLObject* t1361 = shen_cons_p(ctx, t1354);
    if (!shen_is_boolean(ctx, t1361))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t1361)) {
  KLObject* t1365 = shen_hd(ctx, t1354);
  KLObject* t1362;
  {
    KLObject* a1362[] = {t1353, t1365};
    t1362 = shen_apply_direct(ctx, "occurrences", 2, a1362);
  }
  KLObject* t1369 = shen_tl(ctx, t1354);
  KLObject* t1366;
  {
    KLObject* a1366[] = {t1353, t1369};
    t1366 = shen_apply_direct(ctx, "occurrences", 2, a1366);
  }
  KLObject* t1370 = shen_add(ctx, t1362, t1366);
      t1355 = t1370;
    } else {
  KLObject* t1371 = shen_true(ctx);
    if (!shen_is_boolean(ctx, t1371))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t1371)) {
  KLObject* t1372 = shen_number_l(ctx, 0);
      t1355 = t1372;
    } else {
      shen_simple_error(ctx, "No true case found for cond");
      t1355 = shen_empty_list(ctx);
    }
    }
    }
  }
    return t1355;
  }
}

static KLObject* native_kl_nth_77 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t1373 = objects[0];
    KLObject* t1374 = objects[1];
  tail_start_kl_nth_77: ;
  KLObject* t1375;
  {
  KLObject* t1377 = shen_number_l(ctx, 1);
  KLObject* t1379 = shen_eq(ctx, t1377, t1373);
  KLObject* t1376;
  if (!shen_is_boolean(ctx, t1379))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t1379)) {
    t1376 = t1379;
  } else {
  KLObject* t1381 = shen_cons_p(ctx, t1374);
    if (!shen_is_boolean(ctx, t1381))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t1376 = t1381;
  }
    if (!shen_is_boolean(ctx, t1376))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t1376)) {
  KLObject* t1383 = shen_hd(ctx, t1374);
      t1375 = t1383;
    } else {
  KLObject* t1385 = shen_cons_p(ctx, t1374);
    if (!shen_is_boolean(ctx, t1385))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t1385)) {
  KLObject* t1387 = shen_number_l(ctx, 1);
  KLObject* t1388 = shen_sub(ctx, t1373, t1387);
  KLObject* t1390 = shen_tl(ctx, t1374);
  {
    KLObject* n1391_0 = t1388;
    KLObject* n1391_1 = t1390;
    t1373 = n1391_0;
    t1374 = n1391_1;
    goto tail_start_kl_nth_77;
  }
  KLObject* t1391 = NULL;
      t1375 = t1391;
    } else {
  KLObject* t1392 = shen_true(ctx);
    if (!shen_is_boolean(ctx, t1392))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t1392)) {
  KLObject* t1395 = shen_string(ctx, "nth applied to ");
  KLObject* t1399 = shen_string(ctx, ", ");
  KLObject* t1402 = shen_string(ctx, "\n");
  KLObject* t1403 = shen_intern(ctx, "shen.a");
  KLObject* t1400;
  {
    KLObject* a1400[] = {t1374, t1402, t1403};
    t1400 = shen_apply_direct(ctx, "shen.app", 3, a1400);
  }
  KLObject* t1398;
  {
    KLObject* a1398[] = {t1399, t1400};
    t1398 = shen_apply_direct(ctx, "cn", 2, a1398);
  }
  KLObject* t1404 = shen_intern(ctx, "shen.a");
  KLObject* t1396;
  {
    KLObject* a1396[] = {t1373, t1398, t1404};
    t1396 = shen_apply_direct(ctx, "shen.app", 3, a1396);
  }
  KLObject* t1394;
  {
    KLObject* a1394[] = {t1395, t1396};
    t1394 = shen_apply_direct(ctx, "cn", 2, a1394);
  }
  KLObject* t1393;
  {
    KLObject* a1393[] = {t1394};
    t1393 = shen_tail_apply_direct(ctx, "simple-error", 1, a1393);
  }
      t1375 = t1393;
    } else {
      shen_simple_error(ctx, "No true case found for cond");
      t1375 = shen_empty_list(ctx);
    }
    }
    }
  }
    return t1375;
  }
}

static KLObject* native_kl_integer_3f_78 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t1405 = objects[0];
  tail_start_kl_integer_3f_78: ;
  KLObject* t1408 = shen_number_p(ctx, t1405);
  KLObject* t1406;
  if (!shen_is_boolean(ctx, t1408))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t1408)) {
    t1406 = t1408;
  } else {
  KLObject* t1409;
  {
    KLObject* a1409[] = {t1405};
    t1409 = shen_apply_direct(ctx, "shen.abs", 1, a1409);
  }
  KLObject* t1415 = shen_number_l(ctx, 1);
  KLObject* t1413;
  {
    KLObject* a1413[] = {t1409, t1415};
    t1413 = shen_apply_direct(ctx, "shen.magless", 2, a1413);
  }
  KLObject* t1411;
  {
    KLObject* a1411[] = {t1409, t1413};
    t1411 = shen_apply_direct(ctx, "shen.integer-test?", 2, a1411);
  }
    if (!shen_is_boolean(ctx, t1411))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t1406 = t1411;
  }
    return t1406;
  }
}

static KLObject* native_kl_shen_2eabs_79 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t1416 = objects[0];
  tail_start_kl_shen_2eabs_79: ;
  KLObject* t1419 = shen_number_l(ctx, 0);
  KLObject* t1420 = shen_gt(ctx, t1416, t1419);
  KLObject* t1417;
  if (!shen_is_boolean(ctx, t1420))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1420)) {
    t1417 = t1416;
  } else {
  KLObject* t1422 = shen_number_l(ctx, 0);
  KLObject* t1424 = shen_sub(ctx, t1422, t1416);
    t1417 = t1424;
  }
    return t1417;
  }
}

static KLObject* native_kl_shen_2emagless_80 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t1425 = objects[0];
    KLObject* t1426 = objects[1];
  tail_start_kl_shen_2emagless_80: ;
  KLObject* t1428 = shen_number_l(ctx, 2);
  KLObject* t1429 = shen_mul(ctx, t1426, t1428);
  KLObject* t1433 = shen_gt(ctx, t1429, t1425);
  KLObject* t1430;
  if (!shen_is_boolean(ctx, t1433))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1433)) {
    t1430 = t1426;
  } else {
  {
    KLObject* n1437_0 = t1425;
    KLObject* n1437_1 = t1429;
    t1425 = n1437_0;
    t1426 = n1437_1;
    goto tail_start_kl_shen_2emagless_80;
  }
  KLObject* t1437 = NULL;
    t1430 = t1437;
  }
    return t1430;
  }
}

static KLObject* native_kl_shen_2einteger_2dtest_3f_81 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t1438 = objects[0];
    KLObject* t1439 = objects[1];
  tail_start_kl_shen_2einteger_2dtest_3f_81: ;
  KLObject* t1440;
  {
  KLObject* t1441 = shen_number_l(ctx, 0);
  KLObject* t1443 = shen_eq(ctx, t1441, t1438);
    if (!shen_is_boolean(ctx, t1443))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t1443)) {
  KLObject* t1444 = shen_true(ctx);
      t1440 = t1444;
    } else {
  KLObject* t1445 = shen_number_l(ctx, 1);
  KLObject* t1447 = shen_gt(ctx, t1445, t1438);
    if (!shen_is_boolean(ctx, t1447))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t1447)) {
  KLObject* t1448 = shen_false(ctx);
      t1440 = t1448;
    } else {
  KLObject* t1449 = shen_true(ctx);
    if (!shen_is_boolean(ctx, t1449))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t1449)) {
  KLObject* t1452 = shen_sub(ctx, t1438, t1439);
  KLObject* t1454 = shen_number_l(ctx, 0);
  KLObject* t1456 = shen_gt(ctx, t1454, t1452);
  KLObject* t1453;
  if (!shen_is_boolean(ctx, t1456))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1456)) {
  KLObject* t1457;
  {
    KLObject* a1457[] = {t1438};
    t1457 = shen_tail_apply_direct(ctx, "integer?", 1, a1457);
  }
    t1453 = t1457;
  } else {
  {
    KLObject* n1461_0 = t1452;
    KLObject* n1461_1 = t1439;
    t1438 = n1461_0;
    t1439 = n1461_1;
    goto tail_start_kl_shen_2einteger_2dtest_3f_81;
  }
  KLObject* t1461 = NULL;
    t1453 = t1461;
  }
      t1440 = t1453;
    } else {
      shen_simple_error(ctx, "No true case found for cond");
      t1440 = shen_empty_list(ctx);
    }
    }
    }
  }
    return t1440;
  }
}

static KLObject* native_kl_mapcan_82 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t1462 = objects[0];
    KLObject* t1463 = objects[1];
  tail_start_kl_mapcan_82: ;
  KLObject* t1464;
  {
  KLObject* t1465 = shen_empty_list(ctx);
  KLObject* t1467 = shen_eq(ctx, t1465, t1463);
    if (!shen_is_boolean(ctx, t1467))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t1467)) {
  KLObject* t1468 = shen_empty_list(ctx);
      t1464 = t1468;
    } else {
  KLObject* t1470 = shen_cons_p(ctx, t1463);
    if (!shen_is_boolean(ctx, t1470))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t1470)) {
  KLObject* t1475 = shen_hd(ctx, t1463);
  KLObject* t1472;
  {
    Vector* a1472 = shen_vector(ctx, 1);
    shen_vector_set(ctx, a1472, 0, t1475);
    t1472 = shen_apply(ctx, t1462, a1472);
  }
  KLObject* t1479 = shen_tl(ctx, t1463);
  KLObject* t1476;
  {
    KLObject* a1476[] = {t1462, t1479};
    t1476 = shen_apply_direct(ctx, "mapcan", 2, a1476);
  }
  KLObject* t1471;
  {
    KLObject* a1471[] = {t1472, t1476};
    t1471 = shen_tail_apply_direct(ctx, "append", 2, a1471);
  }
      t1464 = t1471;
    } else {
  KLObject* t1480 = shen_true(ctx);
    if (!shen_is_boolean(ctx, t1480))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t1480)) {
  KLObject* t1482 = shen_string(ctx, "attempt to mapcan over a non-list\n");
  KLObject* t1481;
  {
    KLObject* a1481[] = {t1482};
    t1481 = shen_tail_apply_direct(ctx, "simple-error", 1, a1481);
  }
      t1464 = t1481;
    } else {
      shen_simple_error(ctx, "No true case found for cond");
      t1464 = shen_empty_list(ctx);
    }
    }
    }
  }
    return t1464;
  }
}

static KLObject* native_kl__3d_3d_83 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t1483 = objects[0];
    KLObject* t1484 = objects[1];
  tail_start_kl__3d_3d_83: ;
  KLObject* t1485;
  {
  KLObject* t1488 = shen_eq(ctx, t1483, t1484);
    if (!shen_is_boolean(ctx, t1488))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t1488)) {
  KLObject* t1489 = shen_true(ctx);
      t1485 = t1489;
    } else {
  KLObject* t1490 = shen_true(ctx);
    if (!shen_is_boolean(ctx, t1490))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t1490)) {
  KLObject* t1491 = shen_false(ctx);
      t1485 = t1491;
    } else {
      shen_simple_error(ctx, "No true case found for cond");
      t1485 = shen_empty_list(ctx);
    }
    }
  }
    return t1485;
  }
}

static KLObject* native_kl_bound_3f_84 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t1492 = objects[0];
  tail_start_kl_bound_3f_84: ;
  KLObject* t1495 = shen_symbol_p(ctx, t1492);
  KLObject* t1493;
  if (!shen_is_boolean(ctx, t1495))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t1495)) {
    t1493 = t1495;
  } else {
  KLObject* t1496;
  {
    Vector* tenv_12 = shen_vector(ctx, 1);
    shen_vector_set(ctx, tenv_12, 0, t1492);
    t1496 = shen_trap_error(ctx, trap_body_12, trap_handler_12, tenv_12);
  }
  KLObject* t1507 = shen_intern(ctx, "shen.this-symbol-is-unbound");
  KLObject* t1508 = shen_eq(ctx, t1496, t1507);
  KLObject* t1505;
  if (!shen_is_boolean(ctx, t1508))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1508)) {
  KLObject* t1509 = shen_false(ctx);
    t1505 = t1509;
  } else {
  KLObject* t1510 = shen_true(ctx);
    t1505 = t1510;
  }
    if (!shen_is_boolean(ctx, t1505))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t1493 = t1505;
  }
    return t1493;
  }
}

static KLObject* native_kl_shen_2estring_2d_3ebytes_85 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t1511 = objects[0];
  tail_start_kl_shen_2estring_2d_3ebytes_85: ;
  KLObject* t1512;
  {
  KLObject* t1513 = shen_string(ctx, "");
  KLObject* t1515 = shen_eq(ctx, t1513, t1511);
    if (!shen_is_boolean(ctx, t1515))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t1515)) {
  KLObject* t1516 = shen_empty_list(ctx);
      t1512 = t1516;
    } else {
  KLObject* t1517 = shen_true(ctx);
    if (!shen_is_boolean(ctx, t1517))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t1517)) {
  KLObject* t1521 = shen_number_l(ctx, 0);
  KLObject* t1519;
  {
    KLObject* a1519[] = {t1511, t1521};
    t1519 = shen_apply_direct(ctx, "pos", 2, a1519);
  }
  KLObject* t1518;
  {
    KLObject* a1518[] = {t1519};
    t1518 = shen_apply_direct(ctx, "string->n", 1, a1518);
  }
  KLObject* t1523;
  {
    KLObject* a1523[] = {t1511};
    t1523 = shen_apply_direct(ctx, "tlstr", 1, a1523);
  }
  KLObject* t1522;
  {
    KLObject* a1522[] = {t1523};
    t1522 = shen_apply_direct(ctx, "shen.string->bytes", 1, a1522);
  }
  KLObject* t1525 = shen_cons(ctx, t1518, t1522);
      t1512 = t1525;
    } else {
      shen_simple_error(ctx, "No true case found for cond");
      t1512 = shen_empty_list(ctx);
    }
    }
  }
    return t1512;
  }
}

static KLObject* native_kl_maxinferences_86 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t1526 = objects[0];
  tail_start_kl_maxinferences_86: ;
  KLObject* t1529 = shen_number_l(ctx, 0);
  KLObject* t1530 = shen_lt(ctx, t1526, t1529);
  KLObject* t1527;
  if (!shen_is_boolean(ctx, t1530))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1530)) {
  KLObject* t1532 = shen_intern(ctx, "shen.*maxinferences*");
  KLObject* t1531;
  {
    KLObject* a1531[] = {t1532};
    t1531 = shen_tail_apply_direct(ctx, "value", 1, a1531);
  }
    t1527 = t1531;
  } else {
  KLObject* t1534;
  {
    KLObject* a1534[] = {t1526};
    t1534 = shen_apply_direct(ctx, "integer?", 1, a1534);
  }
  KLObject* t1533;
  if (!shen_is_boolean(ctx, t1534))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1534)) {
  KLObject* t1537 = shen_intern(ctx, "shen.*maxinferences*");
  KLObject* t1536;
  {
    KLObject* a1536[] = {t1537, t1526};
    t1536 = shen_tail_apply_direct(ctx, "set", 2, a1536);
  }
    t1533 = t1536;
  } else {
  KLObject* t1540 = shen_string(ctx, "maxinferences expects an integer value\n");
  KLObject* t1539;
  {
    KLObject* a1539[] = {t1540};
    t1539 = shen_tail_apply_direct(ctx, "simple-error", 1, a1539);
  }
    t1533 = t1539;
  }
    t1527 = t1533;
  }
    return t1527;
  }
}

static KLObject* native_kl_inferences_87 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  (void)function_object;
  (void)arguments;
  {
  tail_start_kl_inferences_87: ;
  KLObject* t1542 = shen_intern(ctx, "shen.*infs*");
  KLObject* t1541;
  {
    KLObject* a1541[] = {t1542};
    t1541 = shen_tail_apply_direct(ctx, "value", 1, a1541);
  }
    return t1541;
  }
}

static KLObject* native_kl_protect_88 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t1543 = objects[0];
  tail_start_kl_protect_88: ;
    return t1543;
  }
}

static KLObject* native_kl_stoutput_89 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  (void)function_object;
  (void)arguments;
  {
  tail_start_kl_stoutput_89: ;
  KLObject* t1546 = shen_intern(ctx, "*stoutput*");
  KLObject* t1545;
  {
    KLObject* a1545[] = {t1546};
    t1545 = shen_tail_apply_direct(ctx, "value", 1, a1545);
  }
    return t1545;
  }
}

static KLObject* native_kl_string_2d_3esymbol_90 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t1547 = objects[0];
  tail_start_kl_string_2d_3esymbol_90: ;
  KLObject* t1548;
  {
    KLObject* a1548[] = {t1547};
    t1548 = shen_apply_direct(ctx, "intern", 1, a1548);
  }
  KLObject* t1552 = shen_symbol_p(ctx, t1548);
  KLObject* t1550;
  if (!shen_is_boolean(ctx, t1552))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1552)) {
    t1550 = t1548;
  } else {
  KLObject* t1556 = shen_string(ctx, "cannot intern ");
  KLObject* t1559 = shen_string(ctx, " to a symbol");
  KLObject* t1560 = shen_intern(ctx, "shen.s");
  KLObject* t1557;
  {
    KLObject* a1557[] = {t1547, t1559, t1560};
    t1557 = shen_apply_direct(ctx, "shen.app", 3, a1557);
  }
  KLObject* t1555;
  {
    KLObject* a1555[] = {t1556, t1557};
    t1555 = shen_apply_direct(ctx, "cn", 2, a1555);
  }
  KLObject* t1554;
  {
    KLObject* a1554[] = {t1555};
    t1554 = shen_tail_apply_direct(ctx, "simple-error", 1, a1554);
  }
    t1550 = t1554;
  }
    return t1550;
  }
}

static KLObject* native_kl_optimise_91 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t1561 = objects[0];
  tail_start_kl_optimise_91: ;
  KLObject* t1562;
  {
  KLObject* t1563 = shen_intern(ctx, "+");
  KLObject* t1565 = shen_eq(ctx, t1563, t1561);
    if (!shen_is_boolean(ctx, t1565))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t1565)) {
  KLObject* t1567 = shen_intern(ctx, "shen.*optimise*");
  KLObject* t1568 = shen_true(ctx);
  KLObject* t1566;
  {
    KLObject* a1566[] = {t1567, t1568};
    t1566 = shen_tail_apply_direct(ctx, "set", 2, a1566);
  }
      t1562 = t1566;
    } else {
  KLObject* t1569 = shen_intern(ctx, "-");
  KLObject* t1571 = shen_eq(ctx, t1569, t1561);
    if (!shen_is_boolean(ctx, t1571))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t1571)) {
  KLObject* t1573 = shen_intern(ctx, "shen.*optimise*");
  KLObject* t1574 = shen_false(ctx);
  KLObject* t1572;
  {
    KLObject* a1572[] = {t1573, t1574};
    t1572 = shen_tail_apply_direct(ctx, "set", 2, a1572);
  }
      t1562 = t1572;
    } else {
  KLObject* t1575 = shen_true(ctx);
    if (!shen_is_boolean(ctx, t1575))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t1575)) {
  KLObject* t1577 = shen_string(ctx, "optimise expects a + or a -.\n");
  KLObject* t1576;
  {
    KLObject* a1576[] = {t1577};
    t1576 = shen_tail_apply_direct(ctx, "simple-error", 1, a1576);
  }
      t1562 = t1576;
    } else {
      shen_simple_error(ctx, "No true case found for cond");
      t1562 = shen_empty_list(ctx);
    }
    }
    }
  }
    return t1562;
  }
}

static KLObject* native_kl_os_92 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  (void)function_object;
  (void)arguments;
  {
  tail_start_kl_os_92: ;
  KLObject* t1579 = shen_intern(ctx, "*os*");
  KLObject* t1578;
  {
    KLObject* a1578[] = {t1579};
    t1578 = shen_tail_apply_direct(ctx, "value", 1, a1578);
  }
    return t1578;
  }
}

static KLObject* native_kl_language_93 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  (void)function_object;
  (void)arguments;
  {
  tail_start_kl_language_93: ;
  KLObject* t1581 = shen_intern(ctx, "*language*");
  KLObject* t1580;
  {
    KLObject* a1580[] = {t1581};
    t1580 = shen_tail_apply_direct(ctx, "value", 1, a1580);
  }
    return t1580;
  }
}

static KLObject* native_kl_version_94 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  (void)function_object;
  (void)arguments;
  {
  tail_start_kl_version_94: ;
  KLObject* t1583 = shen_intern(ctx, "*version*");
  KLObject* t1582;
  {
    KLObject* a1582[] = {t1583};
    t1582 = shen_tail_apply_direct(ctx, "value", 1, a1582);
  }
    return t1582;
  }
}

static KLObject* native_kl_port_95 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  (void)function_object;
  (void)arguments;
  {
  tail_start_kl_port_95: ;
  KLObject* t1585 = shen_intern(ctx, "*port*");
  KLObject* t1584;
  {
    KLObject* a1584[] = {t1585};
    t1584 = shen_tail_apply_direct(ctx, "value", 1, a1584);
  }
    return t1584;
  }
}

static KLObject* native_kl_porters_96 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  (void)function_object;
  (void)arguments;
  {
  tail_start_kl_porters_96: ;
  KLObject* t1587 = shen_intern(ctx, "*porters*");
  KLObject* t1586;
  {
    KLObject* a1586[] = {t1587};
    t1586 = shen_tail_apply_direct(ctx, "value", 1, a1586);
  }
    return t1586;
  }
}

static KLObject* native_kl_implementation_97 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  (void)function_object;
  (void)arguments;
  {
  tail_start_kl_implementation_97: ;
  KLObject* t1589 = shen_intern(ctx, "*implementation*");
  KLObject* t1588;
  {
    KLObject* a1588[] = {t1589};
    t1588 = shen_tail_apply_direct(ctx, "value", 1, a1588);
  }
    return t1588;
  }
}

static KLObject* native_kl_release_98 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  (void)function_object;
  (void)arguments;
  {
  tail_start_kl_release_98: ;
  KLObject* t1591 = shen_intern(ctx, "*release*");
  KLObject* t1590;
  {
    KLObject* a1590[] = {t1591};
    t1590 = shen_tail_apply_direct(ctx, "value", 1, a1590);
  }
    return t1590;
  }
}

static KLObject* native_kl_package_3f_99 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t1592 = objects[0];
  tail_start_kl_package_3f_99: ;
  KLObject* t1593;
  {
  KLObject* t1594 = shen_intern(ctx, "null");
  KLObject* t1596 = shen_eq(ctx, t1594, t1592);
    if (!shen_is_boolean(ctx, t1596))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t1596)) {
  KLObject* t1597 = shen_true(ctx);
      t1593 = t1597;
    } else {
  KLObject* t1598 = shen_true(ctx);
    if (!shen_is_boolean(ctx, t1598))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t1598)) {
  KLObject* t1599;
  {
    Vector* tenv_13 = shen_vector(ctx, 1);
    shen_vector_set(ctx, tenv_13, 0, t1592);
    t1599 = shen_trap_error(ctx, trap_body_13, trap_handler_13, tenv_13);
  }
      t1593 = t1599;
    } else {
      shen_simple_error(ctx, "No true case found for cond");
      t1593 = shen_empty_list(ctx);
    }
    }
  }
    return t1593;
  }
}

static KLObject* native_kl_fail_100 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  (void)function_object;
  (void)arguments;
  {
  tail_start_kl_fail_100: ;
  KLObject* t1609 = shen_intern(ctx, "shen.fail!");
    return t1609;
  }
}

static KLObject* native_kl_userdefs_101 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  (void)function_object;
  (void)arguments;
  {
  tail_start_kl_userdefs_101: ;
  KLObject* t1611 = shen_intern(ctx, "shen.*userdefs*");
  KLObject* t1610;
  {
    KLObject* a1610[] = {t1611};
    t1610 = shen_tail_apply_direct(ctx, "value", 1, a1610);
  }
    return t1610;
  }
}

static KLObject* native_kl_optimise_3f_102 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  (void)function_object;
  (void)arguments;
  {
  tail_start_kl_optimise_3f_102: ;
  KLObject* t1613 = shen_intern(ctx, "shen.*optimise*");
  KLObject* t1612;
  {
    KLObject* a1612[] = {t1613};
    t1612 = shen_tail_apply_direct(ctx, "value", 1, a1612);
  }
    return t1612;
  }
}

static KLObject* native_kl_hush_3f_103 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  (void)function_object;
  (void)arguments;
  {
  tail_start_kl_hush_3f_103: ;
  KLObject* t1615 = shen_intern(ctx, "*hush*");
  KLObject* t1614;
  {
    KLObject* a1614[] = {t1615};
    t1614 = shen_tail_apply_direct(ctx, "value", 1, a1614);
  }
    return t1614;
  }
}

static KLObject* native_kl_system_2dS_3f_104 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  (void)function_object;
  (void)arguments;
  {
  tail_start_kl_system_2dS_3f_104: ;
  KLObject* t1617 = shen_intern(ctx, "shen.*shen-type-theory-enabled?*");
  KLObject* t1616;
  {
    KLObject* a1616[] = {t1617};
    t1616 = shen_tail_apply_direct(ctx, "value", 1, a1616);
  }
    return t1616;
  }
}

static KLObject* native_kl_enable_2dtype_2dtheory_105 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t1618 = objects[0];
  tail_start_kl_enable_2dtype_2dtheory_105: ;
  KLObject* t1619;
  {
  KLObject* t1620 = shen_intern(ctx, "+");
  KLObject* t1622 = shen_eq(ctx, t1620, t1618);
    if (!shen_is_boolean(ctx, t1622))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t1622)) {
  KLObject* t1624 = shen_intern(ctx, "shen.*shen-type-theory-enabled?*");
  KLObject* t1625 = shen_true(ctx);
  KLObject* t1623;
  {
    KLObject* a1623[] = {t1624, t1625};
    t1623 = shen_tail_apply_direct(ctx, "set", 2, a1623);
  }
      t1619 = t1623;
    } else {
  KLObject* t1626 = shen_intern(ctx, "-");
  KLObject* t1628 = shen_eq(ctx, t1626, t1618);
    if (!shen_is_boolean(ctx, t1628))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t1628)) {
  KLObject* t1630 = shen_intern(ctx, "shen.*shen-type-theory-enabled?*");
  KLObject* t1631 = shen_false(ctx);
  KLObject* t1629;
  {
    KLObject* a1629[] = {t1630, t1631};
    t1629 = shen_tail_apply_direct(ctx, "set", 2, a1629);
  }
      t1619 = t1629;
    } else {
  KLObject* t1632 = shen_true(ctx);
    if (!shen_is_boolean(ctx, t1632))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t1632)) {
  KLObject* t1634 = shen_string(ctx, "enable-type-theory expects a + or a -\n");
  KLObject* t1633;
  {
    KLObject* a1633[] = {t1634};
    t1633 = shen_tail_apply_direct(ctx, "simple-error", 1, a1633);
  }
      t1619 = t1633;
    } else {
      shen_simple_error(ctx, "No true case found for cond");
      t1619 = shen_empty_list(ctx);
    }
    }
    }
  }
    return t1619;
  }
}

static KLObject* native_kl_hush_106 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t1635 = objects[0];
  tail_start_kl_hush_106: ;
  KLObject* t1636;
  {
  KLObject* t1637 = shen_intern(ctx, "+");
  KLObject* t1639 = shen_eq(ctx, t1637, t1635);
    if (!shen_is_boolean(ctx, t1639))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t1639)) {
  KLObject* t1641 = shen_intern(ctx, "*hush*");
  KLObject* t1642 = shen_true(ctx);
  KLObject* t1640;
  {
    KLObject* a1640[] = {t1641, t1642};
    t1640 = shen_tail_apply_direct(ctx, "set", 2, a1640);
  }
      t1636 = t1640;
    } else {
  KLObject* t1643 = shen_intern(ctx, "-");
  KLObject* t1645 = shen_eq(ctx, t1643, t1635);
    if (!shen_is_boolean(ctx, t1645))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t1645)) {
  KLObject* t1647 = shen_intern(ctx, "*hush*");
  KLObject* t1648 = shen_false(ctx);
  KLObject* t1646;
  {
    KLObject* a1646[] = {t1647, t1648};
    t1646 = shen_tail_apply_direct(ctx, "set", 2, a1646);
  }
      t1636 = t1646;
    } else {
  KLObject* t1649 = shen_true(ctx);
    if (!shen_is_boolean(ctx, t1649))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t1649)) {
  KLObject* t1651 = shen_string(ctx, "hush expects a + or a -\n");
  KLObject* t1650;
  {
    KLObject* a1650[] = {t1651};
    t1650 = shen_tail_apply_direct(ctx, "simple-error", 1, a1650);
  }
      t1636 = t1650;
    } else {
      shen_simple_error(ctx, "No true case found for cond");
      t1636 = shen_empty_list(ctx);
    }
    }
    }
  }
    return t1636;
  }
}

static KLObject* native_kl_tc_107 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t1652 = objects[0];
  tail_start_kl_tc_107: ;
  KLObject* t1653;
  {
  KLObject* t1654 = shen_intern(ctx, "+");
  KLObject* t1656 = shen_eq(ctx, t1654, t1652);
    if (!shen_is_boolean(ctx, t1656))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t1656)) {
  KLObject* t1658 = shen_intern(ctx, "shen.*tc*");
  KLObject* t1659 = shen_true(ctx);
  KLObject* t1657;
  {
    KLObject* a1657[] = {t1658, t1659};
    t1657 = shen_tail_apply_direct(ctx, "set", 2, a1657);
  }
      t1653 = t1657;
    } else {
  KLObject* t1660 = shen_intern(ctx, "-");
  KLObject* t1662 = shen_eq(ctx, t1660, t1652);
    if (!shen_is_boolean(ctx, t1662))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t1662)) {
  KLObject* t1664 = shen_intern(ctx, "shen.*tc*");
  KLObject* t1665 = shen_false(ctx);
  KLObject* t1663;
  {
    KLObject* a1663[] = {t1664, t1665};
    t1663 = shen_tail_apply_direct(ctx, "set", 2, a1663);
  }
      t1653 = t1663;
    } else {
  KLObject* t1666 = shen_true(ctx);
    if (!shen_is_boolean(ctx, t1666))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t1666)) {
  KLObject* t1668 = shen_string(ctx, "tc expects a + or -");
  KLObject* t1667;
  {
    KLObject* a1667[] = {t1668};
    t1667 = shen_tail_apply_direct(ctx, "simple-error", 1, a1667);
  }
      t1653 = t1667;
    } else {
      shen_simple_error(ctx, "No true case found for cond");
      t1653 = shen_empty_list(ctx);
    }
    }
    }
  }
    return t1653;
  }
}

static KLObject* native_kl_destroy_108 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t1669 = objects[0];
  tail_start_kl_destroy_108: ;
  KLObject* t1671 = shen_intern(ctx, "shen.*sigf*");
  KLObject* t1675 = shen_intern(ctx, "shen.*sigf*");
  KLObject* t1674;
  {
    KLObject* a1674[] = {t1675};
    t1674 = shen_apply_direct(ctx, "value", 1, a1674);
  }
  KLObject* t1672;
  {
    KLObject* a1672[] = {t1669, t1674};
    t1672 = shen_apply_direct(ctx, "shen.unassoc", 2, a1672);
  }
  KLObject* t1670;
  {
    KLObject* a1670[] = {t1671, t1672};
    t1670 = shen_apply_direct(ctx, "set", 2, a1670);
  }
    return t1669;
  }
}

static KLObject* native_kl_shen_2eunassoc_109 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t1677 = objects[0];
    KLObject* t1678 = objects[1];
  tail_start_kl_shen_2eunassoc_109: ;
  KLObject* t1679;
  {
  KLObject* t1680 = shen_empty_list(ctx);
  KLObject* t1682 = shen_eq(ctx, t1680, t1678);
    if (!shen_is_boolean(ctx, t1682))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t1682)) {
  KLObject* t1683 = shen_empty_list(ctx);
      t1679 = t1683;
    } else {
  KLObject* t1686 = shen_cons_p(ctx, t1678);
  KLObject* t1684;
  if (!shen_is_boolean(ctx, t1686))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t1686)) {
    t1684 = t1686;
  } else {
  KLObject* t1689 = shen_hd(ctx, t1678);
  KLObject* t1690 = shen_cons_p(ctx, t1689);
  KLObject* t1687;
  if (!shen_is_boolean(ctx, t1690))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t1690)) {
    t1687 = t1690;
  } else {
  KLObject* t1693 = shen_hd(ctx, t1678);
  KLObject* t1694 = shen_hd(ctx, t1693);
  KLObject* t1695 = shen_eq(ctx, t1677, t1694);
    if (!shen_is_boolean(ctx, t1695))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t1687 = t1695;
  }
    if (!shen_is_boolean(ctx, t1687))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t1684 = t1687;
  }
    if (!shen_is_boolean(ctx, t1684))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t1684)) {
  KLObject* t1697 = shen_tl(ctx, t1678);
      t1679 = t1697;
    } else {
  KLObject* t1699 = shen_cons_p(ctx, t1678);
    if (!shen_is_boolean(ctx, t1699))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t1699)) {
  KLObject* t1701 = shen_hd(ctx, t1678);
  KLObject* t1705 = shen_tl(ctx, t1678);
  KLObject* t1702;
  {
    KLObject* a1702[] = {t1677, t1705};
    t1702 = shen_apply_direct(ctx, "shen.unassoc", 2, a1702);
  }
  KLObject* t1706 = shen_cons(ctx, t1701, t1702);
      t1679 = t1706;
    } else {
  KLObject* t1707 = shen_true(ctx);
    if (!shen_is_boolean(ctx, t1707))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t1707)) {
  KLObject* t1709 = shen_string(ctx, "implementation error in shen.unassoc");
  KLObject* t1708;
  {
    KLObject* a1708[] = {t1709};
    t1708 = shen_tail_apply_direct(ctx, "simple-error", 1, a1708);
  }
      t1679 = t1708;
    } else {
      shen_simple_error(ctx, "No true case found for cond");
      t1679 = shen_empty_list(ctx);
    }
    }
    }
    }
  }
    return t1679;
  }
}

static KLObject* native_kl_in_2dpackage_110 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t1710 = objects[0];
  tail_start_kl_in_2dpackage_110: ;
  KLObject* t1712;
  {
    KLObject* a1712[] = {t1710};
    t1712 = shen_apply_direct(ctx, "package?", 1, a1712);
  }
  KLObject* t1711;
  if (!shen_is_boolean(ctx, t1712))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1712)) {
  KLObject* t1715 = shen_intern(ctx, "shen.*package*");
  KLObject* t1714;
  {
    KLObject* a1714[] = {t1715, t1710};
    t1714 = shen_tail_apply_direct(ctx, "set", 2, a1714);
  }
    t1711 = t1714;
  } else {
  KLObject* t1719 = shen_string(ctx, "package ");
  KLObject* t1722 = shen_string(ctx, " does not exist\n");
  KLObject* t1723 = shen_intern(ctx, "shen.a");
  KLObject* t1720;
  {
    KLObject* a1720[] = {t1710, t1722, t1723};
    t1720 = shen_apply_direct(ctx, "shen.app", 3, a1720);
  }
  KLObject* t1718;
  {
    KLObject* a1718[] = {t1719, t1720};
    t1718 = shen_apply_direct(ctx, "cn", 2, a1718);
  }
  KLObject* t1717;
  {
    KLObject* a1717[] = {t1718};
    t1717 = shen_tail_apply_direct(ctx, "simple-error", 1, a1717);
  }
    t1711 = t1717;
  }
    return t1711;
  }
}

static KLObject* native_kl_write_2dto_2dfile_111 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t1724 = objects[0];
    KLObject* t1725 = objects[1];
  tail_start_kl_write_2dto_2dfile_111: ;
  KLObject* t1728 = shen_intern(ctx, "out");
  KLObject* t1726;
  {
    KLObject* a1726[] = {t1724, t1728};
    t1726 = shen_apply_direct(ctx, "open", 2, a1726);
  }
  KLObject* t1731 = shen_string_p(ctx, t1725);
  KLObject* t1729;
  if (!shen_is_boolean(ctx, t1731))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1731)) {
    t1729 = t1725;
  } else {
  KLObject* t1735 = shen_string(ctx, "");
  KLObject* t1736 = shen_intern(ctx, "shen.s");
  KLObject* t1733;
  {
    KLObject* a1733[] = {t1725, t1735, t1736};
    t1733 = shen_apply_direct(ctx, "shen.app", 3, a1733);
  }
    t1729 = t1733;
  }
  KLObject* t1737;
  {
    KLObject* a1737[] = {t1729, t1726};
    t1737 = shen_apply_direct(ctx, "pr", 2, a1737);
  }
  KLObject* t1740;
  {
    KLObject* a1740[] = {t1726};
    t1740 = shen_apply_direct(ctx, "close", 1, a1740);
  }
    return t1725;
  }
}

static KLObject* native_kl_fresh_112 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  (void)function_object;
  (void)arguments;
  {
  tail_start_kl_fresh_112: ;
  KLObject* t1745 = shen_intern(ctx, "shen.t");
  KLObject* t1744;
  {
    KLObject* a1744[] = {t1745};
    t1744 = shen_apply_direct(ctx, "gensym", 1, a1744);
  }
  KLObject* t1743;
  {
    KLObject* a1743[] = {t1744};
    t1743 = shen_tail_apply_direct(ctx, "shen.freshterm", 1, a1743);
  }
    return t1743;
  }
}

static KLObject* native_kl_update_2dlambda_2dtable_113 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t1746 = objects[0];
    KLObject* t1747 = objects[1];
  tail_start_kl_update_2dlambda_2dtable_113: ;
  KLObject* t1750 = shen_intern(ctx, "arity");
  KLObject* t1753 = shen_intern(ctx, "*property-vector*");
  KLObject* t1752;
  {
    KLObject* a1752[] = {t1753};
    t1752 = shen_apply_direct(ctx, "value", 1, a1752);
  }
  KLObject* t1748;
  {
    KLObject* a1748[] = {t1746, t1750, t1747, t1752};
    t1748 = shen_apply_direct(ctx, "put", 4, a1748);
  }
  KLObject* t1754;
  {
    KLObject* a1754[] = {t1746};
    t1754 = shen_apply_direct(ctx, "shen.lambda-entry", 1, a1754);
  }
  KLObject* t1757 = shen_intern(ctx, "shen.*lambdatable*");
  KLObject* t1760 = shen_intern(ctx, "shen.*lambdatable*");
  KLObject* t1759;
  {
    KLObject* a1759[] = {t1760};
    t1759 = shen_apply_direct(ctx, "value", 1, a1759);
  }
  KLObject* t1761 = shen_cons(ctx, t1754, t1759);
  KLObject* t1756;
  {
    KLObject* a1756[] = {t1757, t1761};
    t1756 = shen_apply_direct(ctx, "set", 2, a1756);
  }
    return t1746;
  }
}

static KLObject* native_kl_specialise_114 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t1763 = objects[0];
    KLObject* t1764 = objects[1];
  tail_start_kl_specialise_114: ;
  KLObject* t1765;
  {
  KLObject* t1766 = shen_number_l(ctx, 0);
  KLObject* t1768 = shen_eq(ctx, t1766, t1764);
    if (!shen_is_boolean(ctx, t1768))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t1768)) {
  KLObject* t1770 = shen_intern(ctx, "shen.*special*");
  KLObject* t1774 = shen_intern(ctx, "shen.*special*");
  KLObject* t1773;
  {
    KLObject* a1773[] = {t1774};
    t1773 = shen_apply_direct(ctx, "value", 1, a1773);
  }
  KLObject* t1771;
  {
    KLObject* a1771[] = {t1763, t1773};
    t1771 = shen_apply_direct(ctx, "remove", 2, a1771);
  }
  KLObject* t1769;
  {
    KLObject* a1769[] = {t1770, t1771};
    t1769 = shen_apply_direct(ctx, "set", 2, a1769);
  }
  KLObject* t1776 = shen_intern(ctx, "shen.*extraspecial*");
  KLObject* t1780 = shen_intern(ctx, "shen.*extraspecial*");
  KLObject* t1779;
  {
    KLObject* a1779[] = {t1780};
    t1779 = shen_apply_direct(ctx, "value", 1, a1779);
  }
  KLObject* t1777;
  {
    KLObject* a1777[] = {t1763, t1779};
    t1777 = shen_apply_direct(ctx, "remove", 2, a1777);
  }
  KLObject* t1775;
  {
    KLObject* a1775[] = {t1776, t1777};
    t1775 = shen_apply_direct(ctx, "set", 2, a1775);
  }
      t1765 = t1763;
    } else {
  KLObject* t1782 = shen_number_l(ctx, 1);
  KLObject* t1784 = shen_eq(ctx, t1782, t1764);
    if (!shen_is_boolean(ctx, t1784))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t1784)) {
  KLObject* t1786 = shen_intern(ctx, "shen.*special*");
  KLObject* t1790 = shen_intern(ctx, "shen.*special*");
  KLObject* t1789;
  {
    KLObject* a1789[] = {t1790};
    t1789 = shen_apply_direct(ctx, "value", 1, a1789);
  }
  KLObject* t1787;
  {
    KLObject* a1787[] = {t1763, t1789};
    t1787 = shen_apply_direct(ctx, "adjoin", 2, a1787);
  }
  KLObject* t1785;
  {
    KLObject* a1785[] = {t1786, t1787};
    t1785 = shen_apply_direct(ctx, "set", 2, a1785);
  }
  KLObject* t1792 = shen_intern(ctx, "shen.*extraspecial*");
  KLObject* t1796 = shen_intern(ctx, "shen.*extraspecial*");
  KLObject* t1795;
  {
    KLObject* a1795[] = {t1796};
    t1795 = shen_apply_direct(ctx, "value", 1, a1795);
  }
  KLObject* t1793;
  {
    KLObject* a1793[] = {t1763, t1795};
    t1793 = shen_apply_direct(ctx, "remove", 2, a1793);
  }
  KLObject* t1791;
  {
    KLObject* a1791[] = {t1792, t1793};
    t1791 = shen_apply_direct(ctx, "set", 2, a1791);
  }
      t1765 = t1763;
    } else {
  KLObject* t1798 = shen_number_l(ctx, 2);
  KLObject* t1800 = shen_eq(ctx, t1798, t1764);
    if (!shen_is_boolean(ctx, t1800))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t1800)) {
  KLObject* t1802 = shen_intern(ctx, "shen.*special*");
  KLObject* t1806 = shen_intern(ctx, "shen.*special*");
  KLObject* t1805;
  {
    KLObject* a1805[] = {t1806};
    t1805 = shen_apply_direct(ctx, "value", 1, a1805);
  }
  KLObject* t1803;
  {
    KLObject* a1803[] = {t1763, t1805};
    t1803 = shen_apply_direct(ctx, "remove", 2, a1803);
  }
  KLObject* t1801;
  {
    KLObject* a1801[] = {t1802, t1803};
    t1801 = shen_apply_direct(ctx, "set", 2, a1801);
  }
  KLObject* t1808 = shen_intern(ctx, "shen.*extraspecial*");
  KLObject* t1812 = shen_intern(ctx, "shen.*extraspecial*");
  KLObject* t1811;
  {
    KLObject* a1811[] = {t1812};
    t1811 = shen_apply_direct(ctx, "value", 1, a1811);
  }
  KLObject* t1809;
  {
    KLObject* a1809[] = {t1763, t1811};
    t1809 = shen_apply_direct(ctx, "adjoin", 2, a1809);
  }
  KLObject* t1807;
  {
    KLObject* a1807[] = {t1808, t1809};
    t1807 = shen_apply_direct(ctx, "set", 2, a1807);
  }
      t1765 = t1763;
    } else {
  KLObject* t1814 = shen_true(ctx);
    if (!shen_is_boolean(ctx, t1814))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t1814)) {
  KLObject* t1816 = shen_string(ctx, "specialise requires values of 0, 1 or 2\n");
  KLObject* t1815;
  {
    KLObject* a1815[] = {t1816};
    t1815 = shen_tail_apply_direct(ctx, "simple-error", 1, a1815);
  }
      t1765 = t1815;
    } else {
      shen_simple_error(ctx, "No true case found for cond");
      t1765 = shen_empty_list(ctx);
    }
    }
    }
    }
  }
    return t1765;
  }
}

static KLObject* native_kl_absolute_115 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t1817 = objects[0];
  tail_start_kl_absolute_115: ;
  KLObject* t1819 = shen_intern(ctx, "*absolute*");
  KLObject* t1822 = shen_intern(ctx, "*absolute*");
  KLObject* t1821;
  {
    KLObject* a1821[] = {t1822};
    t1821 = shen_apply_direct(ctx, "value", 1, a1821);
  }
  KLObject* t1823 = shen_cons(ctx, t1817, t1821);
  KLObject* t1818;
  {
    KLObject* a1818[] = {t1819, t1823};
    t1818 = shen_tail_apply_direct(ctx, "set", 2, a1818);
  }
    return t1818;
  }
}

static KLObject* native_kl_unabsolute_116 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t1824 = objects[0];
  tail_start_kl_unabsolute_116: ;
  KLObject* t1826 = shen_intern(ctx, "*absolute*");
  KLObject* t1830 = shen_intern(ctx, "*absolute*");
  KLObject* t1829;
  {
    KLObject* a1829[] = {t1830};
    t1829 = shen_apply_direct(ctx, "value", 1, a1829);
  }
  KLObject* t1827;
  {
    KLObject* a1827[] = {t1824, t1829};
    t1827 = shen_apply_direct(ctx, "remove", 2, a1827);
  }
  KLObject* t1825;
  {
    KLObject* a1825[] = {t1826, t1827};
    t1825 = shen_tail_apply_direct(ctx, "set", 2, a1825);
  }
    return t1825;
  }
}

void shen_kernel_aot_install_sys (shen_context* ctx)
{
  shen_register_defun(ctx, "thaw", 1, &native_kl_thaw_0);
  shen_register_defun(ctx, "eval", 1, &native_kl_eval_1);
  shen_register_defun(ctx, "external", 1, &native_kl_external_2);
  shen_register_defun(ctx, "internal", 1, &native_kl_internal_3);
  shen_register_defun(ctx, "fail-if", 2, &native_kl_fail_2dif_4);
  shen_register_defun(ctx, "@s", 2, &native_kl__40s_5);
  shen_register_defun(ctx, "tc?", 0, &native_kl_tc_3f_6);
  shen_register_defun(ctx, "occurs?", 0, &native_kl_occurs_3f_7);
  shen_register_defun(ctx, "factorise?", 0, &native_kl_factorise_3f_8);
  shen_register_defun(ctx, "tracked", 0, &native_kl_tracked_9);
  shen_register_defun(ctx, "ps", 1, &native_kl_ps_10);
  shen_register_defun(ctx, "stinput", 0, &native_kl_stinput_11);
  shen_register_defun(ctx, "vector", 1, &native_kl_vector_12);
  shen_register_defun(ctx, "shen.fillvector", 4, &native_kl_shen_2efillvector_13);
  shen_register_defun(ctx, "vector?", 1, &native_kl_vector_3f_14);
  shen_register_defun(ctx, "vector->", 3, &native_kl_vector_2d_3e_15);
  shen_register_defun(ctx, "<-vector", 2, &native_kl__3c_2dvector_16);
  shen_register_defun(ctx, "shen.posint?", 1, &native_kl_shen_2eposint_3f_17);
  shen_register_defun(ctx, "limit", 1, &native_kl_limit_18);
  shen_register_defun(ctx, "symbol?", 1, &native_kl_symbol_3f_19);
  shen_register_defun(ctx, "shen.analyse-symbol?", 1, &native_kl_shen_2eanalyse_2dsymbol_3f_20);
  shen_register_defun(ctx, "shen.alphanums?", 1, &native_kl_shen_2ealphanums_3f_21);
  shen_register_defun(ctx, "variable?", 1, &native_kl_variable_3f_22);
  shen_register_defun(ctx, "shen.analyse-variable?", 1, &native_kl_shen_2eanalyse_2dvariable_3f_23);
  shen_register_defun(ctx, "gensym", 1, &native_kl_gensym_24);
  shen_register_defun(ctx, "concat", 2, &native_kl_concat_25);
  shen_register_defun(ctx, "@p", 2, &native_kl__40p_26);
  shen_register_defun(ctx, "fst", 1, &native_kl_fst_27);
  shen_register_defun(ctx, "snd", 1, &native_kl_snd_28);
  shen_register_defun(ctx, "tuple?", 1, &native_kl_tuple_3f_29);
  shen_register_defun(ctx, "append", 2, &native_kl_append_30);
  shen_register_defun(ctx, "@v", 2, &native_kl__40v_31);
  shen_register_defun(ctx, "shen.@v-help", 4, &native_kl_shen_2e_40v_2dhelp_32);
  shen_register_defun(ctx, "shen.copyfromvector", 4, &native_kl_shen_2ecopyfromvector_33);
  shen_register_defun(ctx, "hdv", 1, &native_kl_hdv_34);
  shen_register_defun(ctx, "tlv", 1, &native_kl_tlv_35);
  shen_register_defun(ctx, "shen.tlv-help", 4, &native_kl_shen_2etlv_2dhelp_36);
  shen_register_defun(ctx, "assoc", 2, &native_kl_assoc_37);
  shen_register_defun(ctx, "boolean?", 1, &native_kl_boolean_3f_38);
  shen_register_defun(ctx, "nl", 1, &native_kl_nl_39);
  shen_register_defun(ctx, "difference", 2, &native_kl_difference_40);
  shen_register_defun(ctx, "do", 2, &native_kl_do_41);
  shen_register_defun(ctx, "element?", 2, &native_kl_element_3f_42);
  shen_register_defun(ctx, "empty?", 1, &native_kl_empty_3f_43);
  shen_register_defun(ctx, "fix", 2, &native_kl_fix_44);
  shen_register_defun(ctx, "shen.fix-help", 3, &native_kl_shen_2efix_2dhelp_45);
  shen_register_defun(ctx, "put", 4, &native_kl_put_46);
  shen_register_defun(ctx, "unput", 3, &native_kl_unput_47);
  shen_register_defun(ctx, "shen.remove-pointer", 3, &native_kl_shen_2eremove_2dpointer_48);
  shen_register_defun(ctx, "shen.change-pointer-value", 4, &native_kl_shen_2echange_2dpointer_2dvalue_49);
  shen_register_defun(ctx, "get", 3, &native_kl_get_50);
  shen_register_defun(ctx, "hash", 2, &native_kl_hash_51);
  shen_register_defun(ctx, "shen.hashkey", 1, &native_kl_shen_2ehashkey_52);
  shen_register_defun(ctx, "shen.prodbutzero", 2, &native_kl_shen_2eprodbutzero_53);
  shen_register_defun(ctx, "shen.mod", 2, &native_kl_shen_2emod_54);
  shen_register_defun(ctx, "shen.multiples", 2, &native_kl_shen_2emultiples_55);
  shen_register_defun(ctx, "shen.modh", 2, &native_kl_shen_2emodh_56);
  shen_register_defun(ctx, "sum", 1, &native_kl_sum_57);
  shen_register_defun(ctx, "head", 1, &native_kl_head_58);
  shen_register_defun(ctx, "tail", 1, &native_kl_tail_59);
  shen_register_defun(ctx, "hdstr", 1, &native_kl_hdstr_60);
  shen_register_defun(ctx, "intersection", 2, &native_kl_intersection_61);
  shen_register_defun(ctx, "reverse", 1, &native_kl_reverse_62);
  shen_register_defun(ctx, "shen.reverse-help", 2, &native_kl_shen_2ereverse_2dhelp_63);
  shen_register_defun(ctx, "union", 2, &native_kl_union_64);
  shen_register_defun(ctx, "y-or-n?", 1, &native_kl_y_2dor_2dn_3f_65);
  shen_register_defun(ctx, "not", 1, &native_kl_not_66);
  shen_register_defun(ctx, "abort", 0, &native_kl_abort_67);
  shen_register_defun(ctx, "subst", 3, &native_kl_subst_68);
  shen_register_defun(ctx, "explode", 1, &native_kl_explode_69);
  shen_register_defun(ctx, "shen.explode-h", 1, &native_kl_shen_2eexplode_2dh_70);
  shen_register_defun(ctx, "cd", 1, &native_kl_cd_71);
  shen_register_defun(ctx, "map", 2, &native_kl_map_72);
  shen_register_defun(ctx, "shen.map-h", 3, &native_kl_shen_2emap_2dh_73);
  shen_register_defun(ctx, "length", 1, &native_kl_length_74);
  shen_register_defun(ctx, "shen.length-h", 2, &native_kl_shen_2elength_2dh_75);
  shen_register_defun(ctx, "occurrences", 2, &native_kl_occurrences_76);
  shen_register_defun(ctx, "nth", 2, &native_kl_nth_77);
  shen_register_defun(ctx, "integer?", 1, &native_kl_integer_3f_78);
  shen_register_defun(ctx, "shen.abs", 1, &native_kl_shen_2eabs_79);
  shen_register_defun(ctx, "shen.magless", 2, &native_kl_shen_2emagless_80);
  shen_register_defun(ctx, "shen.integer-test?", 2, &native_kl_shen_2einteger_2dtest_3f_81);
  shen_register_defun(ctx, "mapcan", 2, &native_kl_mapcan_82);
  shen_register_defun(ctx, "==", 2, &native_kl__3d_3d_83);
  shen_register_defun(ctx, "bound?", 1, &native_kl_bound_3f_84);
  shen_register_defun(ctx, "shen.string->bytes", 1, &native_kl_shen_2estring_2d_3ebytes_85);
  shen_register_defun(ctx, "maxinferences", 1, &native_kl_maxinferences_86);
  shen_register_defun(ctx, "inferences", 0, &native_kl_inferences_87);
  shen_register_defun(ctx, "protect", 1, &native_kl_protect_88);
  shen_register_defun(ctx, "stoutput", 0, &native_kl_stoutput_89);
  shen_register_defun(ctx, "string->symbol", 1, &native_kl_string_2d_3esymbol_90);
  shen_register_defun(ctx, "optimise", 1, &native_kl_optimise_91);
  shen_register_defun(ctx, "os", 0, &native_kl_os_92);
  shen_register_defun(ctx, "language", 0, &native_kl_language_93);
  shen_register_defun(ctx, "version", 0, &native_kl_version_94);
  shen_register_defun(ctx, "port", 0, &native_kl_port_95);
  shen_register_defun(ctx, "porters", 0, &native_kl_porters_96);
  shen_register_defun(ctx, "implementation", 0, &native_kl_implementation_97);
  shen_register_defun(ctx, "release", 0, &native_kl_release_98);
  shen_register_defun(ctx, "package?", 1, &native_kl_package_3f_99);
  shen_register_defun(ctx, "fail", 0, &native_kl_fail_100);
  shen_register_defun(ctx, "userdefs", 0, &native_kl_userdefs_101);
  shen_register_defun(ctx, "optimise?", 0, &native_kl_optimise_3f_102);
  shen_register_defun(ctx, "hush?", 0, &native_kl_hush_3f_103);
  shen_register_defun(ctx, "system-S?", 0, &native_kl_system_2dS_3f_104);
  shen_register_defun(ctx, "enable-type-theory", 1, &native_kl_enable_2dtype_2dtheory_105);
  shen_register_defun(ctx, "hush", 1, &native_kl_hush_106);
  shen_register_defun(ctx, "tc", 1, &native_kl_tc_107);
  shen_register_defun(ctx, "destroy", 1, &native_kl_destroy_108);
  shen_register_defun(ctx, "shen.unassoc", 2, &native_kl_shen_2eunassoc_109);
  shen_register_defun(ctx, "in-package", 1, &native_kl_in_2dpackage_110);
  shen_register_defun(ctx, "write-to-file", 2, &native_kl_write_2dto_2dfile_111);
  shen_register_defun(ctx, "fresh", 0, &native_kl_fresh_112);
  shen_register_defun(ctx, "update-lambda-table", 2, &native_kl_update_2dlambda_2dtable_113);
  shen_register_defun(ctx, "specialise", 2, &native_kl_specialise_114);
  shen_register_defun(ctx, "absolute", 1, &native_kl_absolute_115);
  shen_register_defun(ctx, "unabsolute", 1, &native_kl_unabsolute_116);
}
