#include "rc_phase_profile.h"
/* Generated always-AOT kernel module (KL defuns -> NativeFunctions).
 * Install after tree-walker boot overwrites UserFunctions.
 * Toplevel declare/set stay on the walker. Not overlay-after-load.
 * Sidecar tests stay on the tree-walker. Not a second main. Source: t-star.kl
 */
#include "abi.h"

void shen_kernel_aot_install_t_star (shen_context* ctx);

static KLObject* lambda_5 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  KLObject* t73 = shen_vector_get(ctx, caps, 0);
  KLObject* t74 = shen_vector_get(ctx, caps, 1);
  KLObject* t75 = shen_vector_get(ctx, caps, 2);
  KLObject* t76 = shen_vector_get(ctx, caps, 3);
  KLObject* t77 = shen_vector_get(ctx, caps, 4);
  (void)arguments;
  KLObject* t78;
  {
    KLObject* a78[] = {t73, t74, t75, t76, t77};
    t78 = shen_tail_apply_direct(ctx, "return", 5, a78);
  }
    return t78;
}

static KLObject* lambda_4 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  KLObject* t57 = shen_vector_get(ctx, caps, 0);
  KLObject* t58 = shen_vector_get(ctx, caps, 1);
  KLObject* t59 = shen_vector_get(ctx, caps, 2);
  KLObject* t60 = shen_vector_get(ctx, caps, 3);
  KLObject* t61 = shen_vector_get(ctx, caps, 4);
  KLObject* t62 = shen_vector_get(ctx, caps, 5);
  (void)arguments;
  KLObject* t65;
  {
    KLObject* a65[] = {t57, t58};
    t65 = shen_apply_direct(ctx, "shen.deref", 2, a65);
  }
  KLObject* t64;
  {
    KLObject* a64[] = {t65};
    t64 = shen_apply_direct(ctx, "receive", 1, a64);
  }
  KLObject* t72;
  {
    Vector* caps_5 = shen_vector(ctx, 5);
    shen_vector_set(ctx, caps_5, 0, t59);
    shen_vector_set(ctx, caps_5, 1, t58);
    shen_vector_set(ctx, caps_5, 2, t60);
    shen_vector_set(ctx, caps_5, 3, t61);
    shen_vector_set(ctx, caps_5, 4, t62);
    t72 = shen_native_closure(ctx, 0, &lambda_5, caps_5);
  }
  KLObject* t63;
  {
    KLObject* a63[] = {t64, t59, t58, t60, t61, t72};
    t63 = shen_tail_apply_direct(ctx, "shen.toplevel-forms", 6, a63);
  }
    return t63;
}

static KLObject* lambda_3 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  KLObject* t31 = shen_vector_get(ctx, caps, 0);
  KLObject* t32 = shen_vector_get(ctx, caps, 1);
  KLObject* t33 = shen_vector_get(ctx, caps, 2);
  KLObject* t34 = shen_vector_get(ctx, caps, 3);
  KLObject* t35 = shen_vector_get(ctx, caps, 4);
  KLObject* t36 = shen_vector_get(ctx, caps, 5);
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t37 = objects[0];
  KLObject* t38;
  {
    KLObject* a38[] = {t31};
    t38 = shen_apply_direct(ctx, "shen.newpv", 1, a38);
  }
  KLObject* t42 = shen_apply_direct(ctx, "shen.incinfs", 0, NULL);
  KLObject* t45;
  {
    KLObject* a45[] = {t32, t31};
    t45 = shen_apply_direct(ctx, "shen.deref", 2, a45);
  }
  KLObject* t44;
  {
    KLObject* a44[] = {t45};
    t44 = shen_apply_direct(ctx, "receive", 1, a44);
  }
  KLObject* t49;
  {
    KLObject* a49[] = {t33, t31};
    t49 = shen_apply_direct(ctx, "shen.deref", 2, a49);
  }
  KLObject* t48;
  {
    KLObject* a48[] = {t49};
    t48 = shen_apply_direct(ctx, "receive", 1, a48);
  }
  KLObject* t56;
  {
    Vector* caps_4 = shen_vector(ctx, 6);
    shen_vector_set(ctx, caps_4, 0, t36);
    shen_vector_set(ctx, caps_4, 1, t31);
    shen_vector_set(ctx, caps_4, 2, t38);
    shen_vector_set(ctx, caps_4, 3, t34);
    shen_vector_set(ctx, caps_4, 4, t35);
    shen_vector_set(ctx, caps_4, 5, t37);
    t56 = shen_native_closure(ctx, 0, &lambda_4, caps_4);
  }
  KLObject* t43;
  {
    KLObject* a43[] = {t44, t48, t38, t31, t34, t35, t56};
    t43 = shen_apply_direct(ctx, "shen.insert-prolog-variables", 7, a43);
  }
  KLObject* t40;
  {
    KLObject* a40[] = {t31, t43};
    t40 = shen_tail_apply_direct(ctx, "shen.gc", 2, a40);
  }
    return t40;
  }
}

static KLObject* lambda_2 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  KLObject* t24 = shen_vector_get(ctx, caps, 0);
  KLObject* t25 = shen_vector_get(ctx, caps, 1);
  KLObject* t26 = shen_vector_get(ctx, caps, 2);
  KLObject* t27 = shen_vector_get(ctx, caps, 3);
  KLObject* t28 = shen_vector_get(ctx, caps, 4);
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t29 = objects[0];
  KLObject* t30;
  {
    Vector* caps_3 = shen_vector(ctx, 6);
    shen_vector_set(ctx, caps_3, 0, t24);
    shen_vector_set(ctx, caps_3, 1, t25);
    shen_vector_set(ctx, caps_3, 2, t26);
    shen_vector_set(ctx, caps_3, 3, t27);
    shen_vector_set(ctx, caps_3, 4, t29);
    shen_vector_set(ctx, caps_3, 5, t28);
    t30 = shen_native_closure(ctx, 1, &lambda_3, caps_3);
  }
    return t30;
  }
}

static KLObject* lambda_1 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  KLObject* t18 = shen_vector_get(ctx, caps, 0);
  KLObject* t19 = shen_vector_get(ctx, caps, 1);
  KLObject* t20 = shen_vector_get(ctx, caps, 2);
  KLObject* t21 = shen_vector_get(ctx, caps, 3);
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t22 = objects[0];
  KLObject* t23;
  {
    Vector* caps_2 = shen_vector(ctx, 5);
    shen_vector_set(ctx, caps_2, 0, t18);
    shen_vector_set(ctx, caps_2, 1, t19);
    shen_vector_set(ctx, caps_2, 2, t20);
    shen_vector_set(ctx, caps_2, 3, t22);
    shen_vector_set(ctx, caps_2, 4, t21);
    t23 = shen_native_closure(ctx, 1, &lambda_2, caps_2);
  }
    return t23;
  }
}

static KLObject* lambda_0 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  KLObject* t13 = shen_vector_get(ctx, caps, 0);
  KLObject* t14 = shen_vector_get(ctx, caps, 1);
  KLObject* t15 = shen_vector_get(ctx, caps, 2);
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t16 = objects[0];
  KLObject* t17;
  {
    Vector* caps_1 = shen_vector(ctx, 4);
    shen_vector_set(ctx, caps_1, 0, t16);
    shen_vector_set(ctx, caps_1, 1, t13);
    shen_vector_set(ctx, caps_1, 2, t14);
    shen_vector_set(ctx, caps_1, 3, t15);
    t17 = shen_native_closure(ctx, 1, &lambda_1, caps_1);
  }
    return t17;
  }
}

static KLObject* lambda_6 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  (void)arguments;
  KLObject* t93 = shen_true(ctx);
    return t93;
}

static KLObject* lambda_9 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  KLObject* t230 = shen_vector_get(ctx, caps, 0);
  KLObject* t231 = shen_vector_get(ctx, caps, 1);
  KLObject* t232 = shen_vector_get(ctx, caps, 2);
  KLObject* t233 = shen_vector_get(ctx, caps, 3);
  KLObject* t234 = shen_vector_get(ctx, caps, 4);
  KLObject* t235 = shen_vector_get(ctx, caps, 5);
  KLObject* t236 = shen_vector_get(ctx, caps, 6);
  (void)arguments;
  KLObject* t238 = shen_intern(ctx, "define");
  KLObject* t241 = shen_cons(ctx, t230, t231);
  KLObject* t242 = shen_cons(ctx, t238, t241);
  KLObject* t237;
  {
    KLObject* a237[] = {t242, t232, t233, t234, t235, t236};
    t237 = shen_tail_apply_direct(ctx, "shen.t*", 6, a237);
  }
    return t237;
}

static KLObject* lambda_8 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  KLObject* t215 = shen_vector_get(ctx, caps, 0);
  KLObject* t216 = shen_vector_get(ctx, caps, 1);
  KLObject* t217 = shen_vector_get(ctx, caps, 2);
  KLObject* t218 = shen_vector_get(ctx, caps, 3);
  KLObject* t219 = shen_vector_get(ctx, caps, 4);
  KLObject* t220 = shen_vector_get(ctx, caps, 5);
  KLObject* t221 = shen_vector_get(ctx, caps, 6);
  (void)arguments;
  KLObject* t224 = shen_intern(ctx, "shen.*spy*");
  KLObject* t223;
  {
    KLObject* a223[] = {t224};
    t223 = shen_apply_direct(ctx, "value", 1, a223);
  }
  KLObject* t229;
  {
    Vector* caps_9 = shen_vector(ctx, 7);
    shen_vector_set(ctx, caps_9, 0, t215);
    shen_vector_set(ctx, caps_9, 1, t219);
    shen_vector_set(ctx, caps_9, 2, t220);
    shen_vector_set(ctx, caps_9, 3, t216);
    shen_vector_set(ctx, caps_9, 4, t217);
    shen_vector_set(ctx, caps_9, 5, t218);
    shen_vector_set(ctx, caps_9, 6, t221);
    t229 = shen_native_closure(ctx, 0, &lambda_9, caps_9);
  }
  KLObject* t222;
  {
    KLObject* a222[] = {t223, t215, t216, t217, t218, t229};
    t222 = shen_tail_apply_direct(ctx, "shen.signal-def", 6, a222);
  }
    return t222;
}

static KLObject* lambda_7 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  KLObject* t203 = shen_vector_get(ctx, caps, 0);
  KLObject* t204 = shen_vector_get(ctx, caps, 1);
  KLObject* t205 = shen_vector_get(ctx, caps, 2);
  KLObject* t206 = shen_vector_get(ctx, caps, 3);
  KLObject* t207 = shen_vector_get(ctx, caps, 4);
  KLObject* t208 = shen_vector_get(ctx, caps, 5);
  KLObject* t209 = shen_vector_get(ctx, caps, 6);
  (void)arguments;
  KLObject* t214;
  {
    Vector* caps_8 = shen_vector(ctx, 7);
    shen_vector_set(ctx, caps_8, 0, t206);
    shen_vector_set(ctx, caps_8, 1, t203);
    shen_vector_set(ctx, caps_8, 2, t204);
    shen_vector_set(ctx, caps_8, 3, t205);
    shen_vector_set(ctx, caps_8, 4, t207);
    shen_vector_set(ctx, caps_8, 5, t208);
    shen_vector_set(ctx, caps_8, 6, t209);
    t214 = shen_native_closure(ctx, 0, &lambda_8, caps_8);
  }
  KLObject* t210;
  {
    KLObject* a210[] = {t203, t204, t205, t214};
    t210 = shen_tail_apply_direct(ctx, "shen.cut", 4, a210);
  }
    return t210;
}

static KLObject* lambda_10 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t352 = objects[0];
  KLObject* t353;
  {
    KLObject* a353[] = {t352};
    t353 = shen_tail_apply_direct(ctx, "shen.demod", 1, a353);
  }
    return t353;
  }
}

static KLObject* trap_body_0 (void* data)
{
  shen_context* ctx = &shen_root_context;
  Vector* env = (Vector*)data;
  KLObject* t349 = shen_vector_get(ctx, env, 0);
  KLObject* t351;
  {
    Vector* caps_10 = shen_vector(ctx, 0);
    t351 = shen_native_closure(ctx, 1, &lambda_10, caps_10);
  }
  KLObject* t350;
  {
    KLObject* a350[] = {t351, t349};
    t350 = shen_apply_direct(ctx, "shen.walk", 2, a350);
  }
  KLObject* t359 = shen_eq(ctx, t350, t349);
  KLObject* t356;
  if (!shen_is_boolean(ctx, t359))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t359)) {
    t356 = t349;
  } else {
  KLObject* t361;
  {
    KLObject* a361[] = {t350};
    t361 = shen_apply_direct(ctx, "shen.demodulate", 1, a361);
  }
    t356 = t361;
  }
  return t356;
}

static KLObject* lambda_11 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  KLObject* t365 = shen_vector_get(ctx, caps, 0);
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t366 = objects[0];
    return t365;
  }
}

static KLObject* trap_handler_0 (KLObject* exception, void* data)
{
  shen_context* ctx = &shen_root_context;
  Vector* env = (Vector*)data;
  Vector* args;
  KLObject* t363 = shen_vector_get(ctx, env, 0);
  KLObject* t364;
  {
    Vector* caps_11 = shen_vector(ctx, 1);
    shen_vector_set(ctx, caps_11, 0, t363);
    t364 = shen_native_closure(ctx, 1, &lambda_11, caps_11);
  }
  args = shen_vector(ctx, 1);
  shen_vector_set(ctx, args, 0, exception);
  {
    KLObject* t368 = shen_apply(ctx, t364, args);
    return t368;
  }
}

static KLObject* lambda_12 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t521 = objects[0];
  KLObject* t522;
  {
    KLObject* a522[] = {t521};
    t522 = shen_tail_apply_direct(ctx, "shen.curry-type", 1, a522);
  }
    return t522;
  }
}

static KLObject* lambda_13 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t584 = objects[0];
  KLObject* t585;
  {
    KLObject* a585[] = {t584};
    t585 = shen_tail_apply_direct(ctx, "shen.curry", 1, a585);
  }
    return t585;
  }
}

static KLObject* lambda_16 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  KLObject* t753 = shen_vector_get(ctx, caps, 0);
  KLObject* t754 = shen_vector_get(ctx, caps, 1);
  KLObject* t755 = shen_vector_get(ctx, caps, 2);
  KLObject* t756 = shen_vector_get(ctx, caps, 3);
  KLObject* t757 = shen_vector_get(ctx, caps, 4);
  KLObject* t758 = shen_vector_get(ctx, caps, 5);
  KLObject* t759 = shen_vector_get(ctx, caps, 6);
  (void)arguments;
  KLObject* t760;
  {
    KLObject* a760[] = {t753, t754, t755, t756, t757, t758, t759};
    t760 = shen_tail_apply_direct(ctx, "shen.system-S-h", 7, a760);
  }
    return t760;
}

static KLObject* lambda_15 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  KLObject* t741 = shen_vector_get(ctx, caps, 0);
  KLObject* t742 = shen_vector_get(ctx, caps, 1);
  KLObject* t743 = shen_vector_get(ctx, caps, 2);
  KLObject* t744 = shen_vector_get(ctx, caps, 3);
  KLObject* t745 = shen_vector_get(ctx, caps, 4);
  KLObject* t746 = shen_vector_get(ctx, caps, 5);
  KLObject* t747 = shen_vector_get(ctx, caps, 6);
  (void)arguments;
  KLObject* t752;
  {
    Vector* caps_16 = shen_vector(ctx, 7);
    shen_vector_set(ctx, caps_16, 0, t744);
    shen_vector_set(ctx, caps_16, 1, t745);
    shen_vector_set(ctx, caps_16, 2, t746);
    shen_vector_set(ctx, caps_16, 3, t741);
    shen_vector_set(ctx, caps_16, 4, t742);
    shen_vector_set(ctx, caps_16, 5, t743);
    shen_vector_set(ctx, caps_16, 6, t747);
    t752 = shen_native_closure(ctx, 0, &lambda_16, caps_16);
  }
  KLObject* t748;
  {
    KLObject* a748[] = {t741, t742, t743, t752};
    t748 = shen_tail_apply_direct(ctx, "shen.cut", 4, a748);
  }
    return t748;
}

static KLObject* lambda_14 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  KLObject* t728 = shen_vector_get(ctx, caps, 0);
  KLObject* t729 = shen_vector_get(ctx, caps, 1);
  KLObject* t730 = shen_vector_get(ctx, caps, 2);
  KLObject* t731 = shen_vector_get(ctx, caps, 3);
  KLObject* t732 = shen_vector_get(ctx, caps, 4);
  KLObject* t733 = shen_vector_get(ctx, caps, 5);
  KLObject* t734 = shen_vector_get(ctx, caps, 6);
  (void)arguments;
  KLObject* t736 = shen_apply_direct(ctx, "shen.type-theory-enabled?", 0, NULL);
  KLObject* t740;
  {
    Vector* caps_15 = shen_vector(ctx, 7);
    shen_vector_set(ctx, caps_15, 0, t728);
    shen_vector_set(ctx, caps_15, 1, t729);
    shen_vector_set(ctx, caps_15, 2, t730);
    shen_vector_set(ctx, caps_15, 3, t731);
    shen_vector_set(ctx, caps_15, 4, t732);
    shen_vector_set(ctx, caps_15, 5, t733);
    shen_vector_set(ctx, caps_15, 6, t734);
    t740 = shen_native_closure(ctx, 0, &lambda_15, caps_15);
  }
  KLObject* t735;
  {
    KLObject* a735[] = {t736, t728, t729, t730, t740};
    t735 = shen_tail_apply_direct(ctx, "when", 5, a735);
  }
    return t735;
}

static KLObject* lambda_17 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  KLObject* t788 = shen_vector_get(ctx, caps, 0);
  KLObject* t789 = shen_vector_get(ctx, caps, 1);
  KLObject* t790 = shen_vector_get(ctx, caps, 2);
  KLObject* t791 = shen_vector_get(ctx, caps, 3);
  KLObject* t792 = shen_vector_get(ctx, caps, 4);
  KLObject* t793 = shen_vector_get(ctx, caps, 5);
  (void)arguments;
  KLObject* t794;
  {
    KLObject* a794[] = {t788, t789, t790, t791, t792, t793};
    t794 = shen_tail_apply_direct(ctx, "shen.show", 6, a794);
  }
    return t794;
}

static KLObject* lambda_18 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t965 = objects[0];
  KLObject* t967 = shen_string(ctx, " ");
  KLObject* t968 = shen_apply_direct(ctx, "stoutput", 0, NULL);
  KLObject* t966;
  {
    KLObject* a966[] = {t967, t968};
    t966 = shen_apply_direct(ctx, "pr", 2, a966);
  }
  KLObject* t969;
  {
    KLObject* a969[] = {t965};
    t969 = shen_tail_apply_direct(ctx, "shen.prterm", 1, a969);
  }
    return t969;
  }
}

static KLObject* lambda_19 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  KLObject* t1098 = shen_vector_get(ctx, caps, 0);
  KLObject* t1099 = shen_vector_get(ctx, caps, 1);
  KLObject* t1100 = shen_vector_get(ctx, caps, 2);
  KLObject* t1101 = shen_vector_get(ctx, caps, 3);
  KLObject* t1102 = shen_vector_get(ctx, caps, 4);
  KLObject* t1103 = shen_vector_get(ctx, caps, 5);
  KLObject* t1104 = shen_vector_get(ctx, caps, 6);
  (void)arguments;
  KLObject* t1108 = shen_string(ctx, ":");
  KLObject* t1107;
  {
    KLObject* a1107[] = {t1108};
    t1107 = shen_apply_direct(ctx, "intern", 1, a1107);
  }
  KLObject* t1110 = shen_empty_list(ctx);
  KLObject* t1111 = shen_cons(ctx, t1099, t1110);
  KLObject* t1112 = shen_cons(ctx, t1107, t1111);
  KLObject* t1113 = shen_cons(ctx, t1098, t1112);
  KLObject* t1105;
  {
    KLObject* a1105[] = {t1113, t1100, t1101, t1102, t1103, t1104};
    t1105 = shen_tail_apply_direct(ctx, "shen.show", 6, a1105);
  }
    return t1105;
}

static KLObject* lambda_20 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  KLObject* t1138 = shen_vector_get(ctx, caps, 0);
  KLObject* t1139 = shen_vector_get(ctx, caps, 1);
  KLObject* t1140 = shen_vector_get(ctx, caps, 2);
  KLObject* t1141 = shen_vector_get(ctx, caps, 3);
  KLObject* t1142 = shen_vector_get(ctx, caps, 4);
  KLObject* t1143 = shen_vector_get(ctx, caps, 5);
  (void)arguments;
  KLObject* t1144;
  {
    KLObject* a1144[] = {t1138, t1139, t1140, t1141, t1142, t1143};
    t1144 = shen_tail_apply_direct(ctx, "shen.primitive", 6, a1144);
  }
    return t1144;
}

static KLObject* lambda_22 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  KLObject* t1269 = shen_vector_get(ctx, caps, 0);
  KLObject* t1270 = shen_vector_get(ctx, caps, 1);
  KLObject* t1271 = shen_vector_get(ctx, caps, 2);
  KLObject* t1272 = shen_vector_get(ctx, caps, 3);
  KLObject* t1273 = shen_vector_get(ctx, caps, 4);
  KLObject* t1274 = shen_vector_get(ctx, caps, 5);
  KLObject* t1275 = shen_vector_get(ctx, caps, 6);
  (void)arguments;
  KLObject* t1278 = shen_empty_list(ctx);
  KLObject* t1279 = shen_cons(ctx, t1269, t1278);
  KLObject* t1276;
  {
    KLObject* a1276[] = {t1279, t1270, t1271, t1272, t1273, t1274, t1275};
    t1276 = shen_tail_apply_direct(ctx, "shen.system-S-h", 7, a1276);
  }
    return t1276;
}

static KLObject* lambda_21 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  KLObject* t1257 = shen_vector_get(ctx, caps, 0);
  KLObject* t1258 = shen_vector_get(ctx, caps, 1);
  KLObject* t1259 = shen_vector_get(ctx, caps, 2);
  KLObject* t1260 = shen_vector_get(ctx, caps, 3);
  KLObject* t1261 = shen_vector_get(ctx, caps, 4);
  KLObject* t1262 = shen_vector_get(ctx, caps, 5);
  KLObject* t1263 = shen_vector_get(ctx, caps, 6);
  (void)arguments;
  KLObject* t1268;
  {
    Vector* caps_22 = shen_vector(ctx, 7);
    shen_vector_set(ctx, caps_22, 0, t1260);
    shen_vector_set(ctx, caps_22, 1, t1261);
    shen_vector_set(ctx, caps_22, 2, t1262);
    shen_vector_set(ctx, caps_22, 3, t1257);
    shen_vector_set(ctx, caps_22, 4, t1258);
    shen_vector_set(ctx, caps_22, 5, t1259);
    shen_vector_set(ctx, caps_22, 6, t1263);
    t1268 = shen_native_closure(ctx, 0, &lambda_22, caps_22);
  }
  KLObject* t1264;
  {
    KLObject* a1264[] = {t1257, t1258, t1259, t1268};
    t1264 = shen_tail_apply_direct(ctx, "shen.cut", 4, a1264);
  }
    return t1264;
}

static KLObject* lambda_24 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  KLObject* t1411 = shen_vector_get(ctx, caps, 0);
  KLObject* t1412 = shen_vector_get(ctx, caps, 1);
  KLObject* t1413 = shen_vector_get(ctx, caps, 2);
  KLObject* t1414 = shen_vector_get(ctx, caps, 3);
  KLObject* t1415 = shen_vector_get(ctx, caps, 4);
  KLObject* t1416 = shen_vector_get(ctx, caps, 5);
  KLObject* t1417 = shen_vector_get(ctx, caps, 6);
  (void)arguments;
  KLObject* t1418;
  {
    KLObject* a1418[] = {t1411, t1412, t1413, t1414, t1415, t1416, t1417};
    t1418 = shen_tail_apply_direct(ctx, "shen.system-S-h", 7, a1418);
  }
    return t1418;
}

static KLObject* lambda_23 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  KLObject* t1389 = shen_vector_get(ctx, caps, 0);
  KLObject* t1390 = shen_vector_get(ctx, caps, 1);
  KLObject* t1391 = shen_vector_get(ctx, caps, 2);
  KLObject* t1392 = shen_vector_get(ctx, caps, 3);
  KLObject* t1393 = shen_vector_get(ctx, caps, 4);
  KLObject* t1394 = shen_vector_get(ctx, caps, 5);
  KLObject* t1395 = shen_vector_get(ctx, caps, 6);
  KLObject* t1396 = shen_vector_get(ctx, caps, 7);
  KLObject* t1397 = shen_vector_get(ctx, caps, 8);
  (void)arguments;
  KLObject* t1401 = shen_intern(ctx, "-->");
  KLObject* t1403 = shen_empty_list(ctx);
  KLObject* t1404 = shen_cons(ctx, t1391, t1403);
  KLObject* t1405 = shen_cons(ctx, t1401, t1404);
  KLObject* t1406 = shen_cons(ctx, t1390, t1405);
  KLObject* t1410;
  {
    Vector* caps_24 = shen_vector(ctx, 7);
    shen_vector_set(ctx, caps_24, 0, t1395);
    shen_vector_set(ctx, caps_24, 1, t1390);
    shen_vector_set(ctx, caps_24, 2, t1396);
    shen_vector_set(ctx, caps_24, 3, t1392);
    shen_vector_set(ctx, caps_24, 4, t1393);
    shen_vector_set(ctx, caps_24, 5, t1394);
    shen_vector_set(ctx, caps_24, 6, t1397);
    t1410 = shen_native_closure(ctx, 0, &lambda_24, caps_24);
  }
  KLObject* t1398;
  {
    KLObject* a1398[] = {t1389, t1406, t1392, t1393, t1394, t1410};
    t1398 = shen_tail_apply_direct(ctx, "shen.lookupsig", 6, a1398);
  }
    return t1398;
}

static KLObject* lambda_25 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  KLObject* t1481 = shen_vector_get(ctx, caps, 0);
  KLObject* t1482 = shen_vector_get(ctx, caps, 1);
  KLObject* t1483 = shen_vector_get(ctx, caps, 2);
  KLObject* t1484 = shen_vector_get(ctx, caps, 3);
  KLObject* t1485 = shen_vector_get(ctx, caps, 4);
  KLObject* t1486 = shen_vector_get(ctx, caps, 5);
  KLObject* t1487 = shen_vector_get(ctx, caps, 6);
  (void)arguments;
  KLObject* t1488;
  {
    KLObject* a1488[] = {t1481, t1482, t1483, t1484, t1485, t1486, t1487};
    t1488 = shen_tail_apply_direct(ctx, "shen.system-S-h", 7, a1488);
  }
    return t1488;
}

static KLObject* lambda_27 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  KLObject* t1568 = shen_vector_get(ctx, caps, 0);
  KLObject* t1569 = shen_vector_get(ctx, caps, 1);
  KLObject* t1570 = shen_vector_get(ctx, caps, 2);
  KLObject* t1571 = shen_vector_get(ctx, caps, 3);
  KLObject* t1572 = shen_vector_get(ctx, caps, 4);
  KLObject* t1573 = shen_vector_get(ctx, caps, 5);
  KLObject* t1574 = shen_vector_get(ctx, caps, 6);
  (void)arguments;
  KLObject* t1577 = shen_intern(ctx, "list");
  KLObject* t1579 = shen_empty_list(ctx);
  KLObject* t1580 = shen_cons(ctx, t1569, t1579);
  KLObject* t1581 = shen_cons(ctx, t1577, t1580);
  KLObject* t1575;
  {
    KLObject* a1575[] = {t1568, t1581, t1570, t1571, t1572, t1573, t1574};
    t1575 = shen_tail_apply_direct(ctx, "shen.system-S-h", 7, a1575);
  }
    return t1575;
}

static KLObject* lambda_26 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  KLObject* t1551 = shen_vector_get(ctx, caps, 0);
  KLObject* t1552 = shen_vector_get(ctx, caps, 1);
  KLObject* t1553 = shen_vector_get(ctx, caps, 2);
  KLObject* t1554 = shen_vector_get(ctx, caps, 3);
  KLObject* t1555 = shen_vector_get(ctx, caps, 4);
  KLObject* t1556 = shen_vector_get(ctx, caps, 5);
  KLObject* t1557 = shen_vector_get(ctx, caps, 6);
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t1558 = objects[0];
  KLObject* t1559 = shen_apply_direct(ctx, "shen.incinfs", 0, NULL);
  KLObject* t1567;
  {
    Vector* caps_27 = shen_vector(ctx, 7);
    shen_vector_set(ctx, caps_27, 0, t1556);
    shen_vector_set(ctx, caps_27, 1, t1558);
    shen_vector_set(ctx, caps_27, 2, t1552);
    shen_vector_set(ctx, caps_27, 3, t1553);
    shen_vector_set(ctx, caps_27, 4, t1554);
    shen_vector_set(ctx, caps_27, 5, t1555);
    shen_vector_set(ctx, caps_27, 6, t1557);
    t1567 = shen_native_closure(ctx, 0, &lambda_27, caps_27);
  }
  KLObject* t1560;
  {
    KLObject* a1560[] = {t1551, t1558, t1552, t1553, t1554, t1555, t1567};
    t1560 = shen_tail_apply_direct(ctx, "shen.system-S-h", 7, a1560);
  }
    return t1560;
  }
}

static KLObject* lambda_29 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  KLObject* t1603 = shen_vector_get(ctx, caps, 0);
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t1604 = objects[0];
  KLObject* t1605;
  {
    Vector* a1605 = shen_vector(ctx, 1);
    shen_vector_set(ctx, a1605, 0, t1604);
    t1605 = shen_tail_apply(ctx, t1603, a1605);
  }
    return t1605;
  }
}

static KLObject* lambda_30 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  KLObject* t1618 = shen_vector_get(ctx, caps, 0);
  KLObject* t1619 = shen_vector_get(ctx, caps, 1);
  (void)arguments;
  KLObject* t1620;
  {
    Vector* a1620 = shen_vector(ctx, 1);
    shen_vector_set(ctx, a1620, 0, t1619);
    t1620 = shen_tail_apply(ctx, t1618, a1620);
  }
    return t1620;
}

static KLObject* lambda_31 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  KLObject* t1652 = shen_vector_get(ctx, caps, 0);
  KLObject* t1653 = shen_vector_get(ctx, caps, 1);
  (void)arguments;
  KLObject* t1654;
  {
    Vector* a1654 = shen_vector(ctx, 1);
    shen_vector_set(ctx, a1654, 0, t1653);
    t1654 = shen_tail_apply(ctx, t1652, a1654);
  }
    return t1654;
}

static KLObject* lambda_28 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  KLObject* t1595 = shen_vector_get(ctx, caps, 0);
  KLObject* t1596 = shen_vector_get(ctx, caps, 1);
  KLObject* t1597 = shen_vector_get(ctx, caps, 2);
  (void)arguments;
  KLObject* t1600 = shen_tl(ctx, t1595);
  KLObject* t1598;
  {
    KLObject* a1598[] = {t1600, t1596};
    t1598 = shen_apply_direct(ctx, "shen.lazyderef", 2, a1598);
  }
  KLObject* t1602;
  {
    Vector* caps_29 = shen_vector(ctx, 1);
    shen_vector_set(ctx, caps_29, 0, t1597);
    t1602 = shen_native_closure(ctx, 1, &lambda_29, caps_29);
  }
  KLObject* t1610 = shen_cons_p(ctx, t1598);
  KLObject* t1608;
  if (!shen_is_boolean(ctx, t1610))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1610)) {
  KLObject* t1612 = shen_hd(ctx, t1598);
  KLObject* t1615 = shen_tl(ctx, t1598);
  KLObject* t1613;
  {
    KLObject* a1613[] = {t1615, t1596};
    t1613 = shen_apply_direct(ctx, "shen.lazyderef", 2, a1613);
  }
  KLObject* t1617;
  {
    Vector* caps_30 = shen_vector(ctx, 2);
    shen_vector_set(ctx, caps_30, 0, t1602);
    shen_vector_set(ctx, caps_30, 1, t1612);
    t1617 = shen_native_closure(ctx, 0, &lambda_30, caps_30);
  }
  KLObject* t1625 = shen_empty_list(ctx);
  KLObject* t1626 = shen_eq(ctx, t1613, t1625);
  KLObject* t1623;
  if (!shen_is_boolean(ctx, t1626))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1626)) {
  KLObject* t1627;
  {
    KLObject* a1627[] = {t1617};
    t1627 = shen_tail_apply_direct(ctx, "thaw", 1, a1627);
  }
    t1623 = t1627;
  } else {
  KLObject* t1630;
  {
    KLObject* a1630[] = {t1613};
    t1630 = shen_apply_direct(ctx, "shen.pvar?", 1, a1630);
  }
  KLObject* t1629;
  if (!shen_is_boolean(ctx, t1630))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1630)) {
  KLObject* t1634 = shen_empty_list(ctx);
  KLObject* t1632;
  {
    KLObject* a1632[] = {t1613, t1634, t1596, t1617};
    t1632 = shen_tail_apply_direct(ctx, "shen.bind!", 4, a1632);
  }
    t1629 = t1632;
  } else {
  KLObject* t1637 = shen_false(ctx);
    t1629 = t1637;
  }
    t1623 = t1629;
  }
    t1608 = t1623;
  } else {
  KLObject* t1639;
  {
    KLObject* a1639[] = {t1598};
    t1639 = shen_apply_direct(ctx, "shen.pvar?", 1, a1639);
  }
  KLObject* t1638;
  if (!shen_is_boolean(ctx, t1639))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1639)) {
  KLObject* t1641;
  {
    KLObject* a1641[] = {t1596};
    t1641 = shen_apply_direct(ctx, "shen.newpv", 1, a1641);
  }
  KLObject* t1648 = shen_empty_list(ctx);
  KLObject* t1649 = shen_cons(ctx, t1641, t1648);
  KLObject* t1651;
  {
    Vector* caps_31 = shen_vector(ctx, 2);
    shen_vector_set(ctx, caps_31, 0, t1602);
    shen_vector_set(ctx, caps_31, 1, t1641);
    t1651 = shen_native_closure(ctx, 0, &lambda_31, caps_31);
  }
  KLObject* t1645;
  {
    KLObject* a1645[] = {t1598, t1649, t1596, t1651};
    t1645 = shen_apply_direct(ctx, "shen.bind!", 4, a1645);
  }
  KLObject* t1643;
  {
    KLObject* a1643[] = {t1596, t1645};
    t1643 = shen_tail_apply_direct(ctx, "shen.gc", 2, a1643);
  }
    t1638 = t1643;
  } else {
  KLObject* t1657 = shen_false(ctx);
    t1638 = t1657;
  }
    t1608 = t1638;
  }
    return t1608;
}

static KLObject* lambda_32 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  KLObject* t1689 = shen_vector_get(ctx, caps, 0);
  KLObject* t1690 = shen_vector_get(ctx, caps, 1);
  (void)arguments;
  KLObject* t1691;
  {
    Vector* a1691 = shen_vector(ctx, 1);
    shen_vector_set(ctx, a1691, 0, t1690);
    t1691 = shen_tail_apply(ctx, t1689, a1691);
  }
    return t1691;
}

static KLObject* lambda_35 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  KLObject* t1779 = shen_vector_get(ctx, caps, 0);
  KLObject* t1780 = shen_vector_get(ctx, caps, 1);
  KLObject* t1781 = shen_vector_get(ctx, caps, 2);
  KLObject* t1782 = shen_vector_get(ctx, caps, 3);
  KLObject* t1783 = shen_vector_get(ctx, caps, 4);
  KLObject* t1784 = shen_vector_get(ctx, caps, 5);
  KLObject* t1785 = shen_vector_get(ctx, caps, 6);
  (void)arguments;
  KLObject* t1786;
  {
    KLObject* a1786[] = {t1779, t1780, t1781, t1782, t1783, t1784, t1785};
    t1786 = shen_tail_apply_direct(ctx, "shen.system-S-h", 7, a1786);
  }
    return t1786;
}

static KLObject* lambda_34 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  KLObject* t1761 = shen_vector_get(ctx, caps, 0);
  KLObject* t1762 = shen_vector_get(ctx, caps, 1);
  KLObject* t1763 = shen_vector_get(ctx, caps, 2);
  KLObject* t1764 = shen_vector_get(ctx, caps, 3);
  KLObject* t1765 = shen_vector_get(ctx, caps, 4);
  KLObject* t1766 = shen_vector_get(ctx, caps, 5);
  KLObject* t1767 = shen_vector_get(ctx, caps, 6);
  KLObject* t1768 = shen_vector_get(ctx, caps, 7);
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t1769 = objects[0];
  KLObject* t1770 = shen_apply_direct(ctx, "shen.incinfs", 0, NULL);
  KLObject* t1778;
  {
    Vector* caps_35 = shen_vector(ctx, 7);
    shen_vector_set(ctx, caps_35, 0, t1767);
    shen_vector_set(ctx, caps_35, 1, t1769);
    shen_vector_set(ctx, caps_35, 2, t1763);
    shen_vector_set(ctx, caps_35, 3, t1764);
    shen_vector_set(ctx, caps_35, 4, t1765);
    shen_vector_set(ctx, caps_35, 5, t1766);
    shen_vector_set(ctx, caps_35, 6, t1768);
    t1778 = shen_native_closure(ctx, 0, &lambda_35, caps_35);
  }
  KLObject* t1771;
  {
    KLObject* a1771[] = {t1761, t1762, t1763, t1764, t1765, t1766, t1778};
    t1771 = shen_tail_apply_direct(ctx, "shen.system-S-h", 7, a1771);
  }
    return t1771;
  }
}

static KLObject* lambda_33 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  KLObject* t1752 = shen_vector_get(ctx, caps, 0);
  KLObject* t1753 = shen_vector_get(ctx, caps, 1);
  KLObject* t1754 = shen_vector_get(ctx, caps, 2);
  KLObject* t1755 = shen_vector_get(ctx, caps, 3);
  KLObject* t1756 = shen_vector_get(ctx, caps, 4);
  KLObject* t1757 = shen_vector_get(ctx, caps, 5);
  KLObject* t1758 = shen_vector_get(ctx, caps, 6);
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t1759 = objects[0];
  KLObject* t1760;
  {
    Vector* caps_34 = shen_vector(ctx, 8);
    shen_vector_set(ctx, caps_34, 0, t1752);
    shen_vector_set(ctx, caps_34, 1, t1759);
    shen_vector_set(ctx, caps_34, 2, t1753);
    shen_vector_set(ctx, caps_34, 3, t1754);
    shen_vector_set(ctx, caps_34, 4, t1755);
    shen_vector_set(ctx, caps_34, 5, t1756);
    shen_vector_set(ctx, caps_34, 6, t1757);
    shen_vector_set(ctx, caps_34, 7, t1758);
    t1760 = shen_native_closure(ctx, 1, &lambda_34, caps_34);
  }
    return t1760;
  }
}

static KLObject* lambda_36 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  KLObject* t1804 = shen_vector_get(ctx, caps, 0);
  KLObject* t1805 = shen_vector_get(ctx, caps, 1);
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t1806 = objects[0];
  KLObject* t1808;
  {
    Vector* a1808 = shen_vector(ctx, 1);
    shen_vector_set(ctx, a1808, 0, t1805);
    t1808 = shen_apply(ctx, t1804, a1808);
  }
  KLObject* t1807;
  {
    Vector* a1807 = shen_vector(ctx, 1);
    shen_vector_set(ctx, a1807, 0, t1806);
    t1807 = shen_tail_apply(ctx, t1808, a1807);
  }
    return t1807;
  }
}

static KLObject* lambda_38 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  KLObject* t1828 = shen_vector_get(ctx, caps, 0);
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t1829 = objects[0];
  KLObject* t1830;
  {
    Vector* a1830 = shen_vector(ctx, 1);
    shen_vector_set(ctx, a1830, 0, t1829);
    t1830 = shen_tail_apply(ctx, t1828, a1830);
  }
    return t1830;
  }
}

static KLObject* lambda_39 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  KLObject* t1843 = shen_vector_get(ctx, caps, 0);
  KLObject* t1844 = shen_vector_get(ctx, caps, 1);
  (void)arguments;
  KLObject* t1845;
  {
    Vector* a1845 = shen_vector(ctx, 1);
    shen_vector_set(ctx, a1845, 0, t1844);
    t1845 = shen_tail_apply(ctx, t1843, a1845);
  }
    return t1845;
}

static KLObject* lambda_40 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  KLObject* t1877 = shen_vector_get(ctx, caps, 0);
  KLObject* t1878 = shen_vector_get(ctx, caps, 1);
  (void)arguments;
  KLObject* t1879;
  {
    Vector* a1879 = shen_vector(ctx, 1);
    shen_vector_set(ctx, a1879, 0, t1878);
    t1879 = shen_tail_apply(ctx, t1877, a1879);
  }
    return t1879;
}

static KLObject* lambda_37 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  KLObject* t1820 = shen_vector_get(ctx, caps, 0);
  KLObject* t1821 = shen_vector_get(ctx, caps, 1);
  KLObject* t1822 = shen_vector_get(ctx, caps, 2);
  (void)arguments;
  KLObject* t1825 = shen_tl(ctx, t1820);
  KLObject* t1823;
  {
    KLObject* a1823[] = {t1825, t1821};
    t1823 = shen_apply_direct(ctx, "shen.lazyderef", 2, a1823);
  }
  KLObject* t1827;
  {
    Vector* caps_38 = shen_vector(ctx, 1);
    shen_vector_set(ctx, caps_38, 0, t1822);
    t1827 = shen_native_closure(ctx, 1, &lambda_38, caps_38);
  }
  KLObject* t1835 = shen_cons_p(ctx, t1823);
  KLObject* t1833;
  if (!shen_is_boolean(ctx, t1835))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1835)) {
  KLObject* t1837 = shen_hd(ctx, t1823);
  KLObject* t1840 = shen_tl(ctx, t1823);
  KLObject* t1838;
  {
    KLObject* a1838[] = {t1840, t1821};
    t1838 = shen_apply_direct(ctx, "shen.lazyderef", 2, a1838);
  }
  KLObject* t1842;
  {
    Vector* caps_39 = shen_vector(ctx, 2);
    shen_vector_set(ctx, caps_39, 0, t1827);
    shen_vector_set(ctx, caps_39, 1, t1837);
    t1842 = shen_native_closure(ctx, 0, &lambda_39, caps_39);
  }
  KLObject* t1850 = shen_empty_list(ctx);
  KLObject* t1851 = shen_eq(ctx, t1838, t1850);
  KLObject* t1848;
  if (!shen_is_boolean(ctx, t1851))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1851)) {
  KLObject* t1852;
  {
    KLObject* a1852[] = {t1842};
    t1852 = shen_tail_apply_direct(ctx, "thaw", 1, a1852);
  }
    t1848 = t1852;
  } else {
  KLObject* t1855;
  {
    KLObject* a1855[] = {t1838};
    t1855 = shen_apply_direct(ctx, "shen.pvar?", 1, a1855);
  }
  KLObject* t1854;
  if (!shen_is_boolean(ctx, t1855))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1855)) {
  KLObject* t1859 = shen_empty_list(ctx);
  KLObject* t1857;
  {
    KLObject* a1857[] = {t1838, t1859, t1821, t1842};
    t1857 = shen_tail_apply_direct(ctx, "shen.bind!", 4, a1857);
  }
    t1854 = t1857;
  } else {
  KLObject* t1862 = shen_false(ctx);
    t1854 = t1862;
  }
    t1848 = t1854;
  }
    t1833 = t1848;
  } else {
  KLObject* t1864;
  {
    KLObject* a1864[] = {t1823};
    t1864 = shen_apply_direct(ctx, "shen.pvar?", 1, a1864);
  }
  KLObject* t1863;
  if (!shen_is_boolean(ctx, t1864))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1864)) {
  KLObject* t1866;
  {
    KLObject* a1866[] = {t1821};
    t1866 = shen_apply_direct(ctx, "shen.newpv", 1, a1866);
  }
  KLObject* t1873 = shen_empty_list(ctx);
  KLObject* t1874 = shen_cons(ctx, t1866, t1873);
  KLObject* t1876;
  {
    Vector* caps_40 = shen_vector(ctx, 2);
    shen_vector_set(ctx, caps_40, 0, t1827);
    shen_vector_set(ctx, caps_40, 1, t1866);
    t1876 = shen_native_closure(ctx, 0, &lambda_40, caps_40);
  }
  KLObject* t1870;
  {
    KLObject* a1870[] = {t1823, t1874, t1821, t1876};
    t1870 = shen_apply_direct(ctx, "shen.bind!", 4, a1870);
  }
  KLObject* t1868;
  {
    KLObject* a1868[] = {t1821, t1870};
    t1868 = shen_tail_apply_direct(ctx, "shen.gc", 2, a1868);
  }
    t1863 = t1868;
  } else {
  KLObject* t1882 = shen_false(ctx);
    t1863 = t1882;
  }
    t1833 = t1863;
  }
    return t1833;
}

static KLObject* lambda_41 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  KLObject* t1914 = shen_vector_get(ctx, caps, 0);
  KLObject* t1915 = shen_vector_get(ctx, caps, 1);
  (void)arguments;
  KLObject* t1916;
  {
    Vector* a1916 = shen_vector(ctx, 1);
    shen_vector_set(ctx, a1916, 0, t1915);
    t1916 = shen_tail_apply(ctx, t1914, a1916);
  }
    return t1916;
}

static KLObject* lambda_42 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  KLObject* t1942 = shen_vector_get(ctx, caps, 0);
  KLObject* t1943 = shen_vector_get(ctx, caps, 1);
  KLObject* t1944 = shen_vector_get(ctx, caps, 2);
  (void)arguments;
  KLObject* t1946;
  {
    Vector* a1946 = shen_vector(ctx, 1);
    shen_vector_set(ctx, a1946, 0, t1943);
    t1946 = shen_apply(ctx, t1942, a1946);
  }
  KLObject* t1945;
  {
    Vector* a1945 = shen_vector(ctx, 1);
    shen_vector_set(ctx, a1945, 0, t1944);
    t1945 = shen_tail_apply(ctx, t1946, a1945);
  }
    return t1945;
}

static KLObject* lambda_44 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  KLObject* t2025 = shen_vector_get(ctx, caps, 0);
  KLObject* t2026 = shen_vector_get(ctx, caps, 1);
  KLObject* t2027 = shen_vector_get(ctx, caps, 2);
  KLObject* t2028 = shen_vector_get(ctx, caps, 3);
  KLObject* t2029 = shen_vector_get(ctx, caps, 4);
  KLObject* t2030 = shen_vector_get(ctx, caps, 5);
  KLObject* t2031 = shen_vector_get(ctx, caps, 6);
  (void)arguments;
  KLObject* t2034 = shen_intern(ctx, "vector");
  KLObject* t2036 = shen_empty_list(ctx);
  KLObject* t2037 = shen_cons(ctx, t2026, t2036);
  KLObject* t2038 = shen_cons(ctx, t2034, t2037);
  KLObject* t2032;
  {
    KLObject* a2032[] = {t2025, t2038, t2027, t2028, t2029, t2030, t2031};
    t2032 = shen_tail_apply_direct(ctx, "shen.system-S-h", 7, a2032);
  }
    return t2032;
}

static KLObject* lambda_43 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  KLObject* t2008 = shen_vector_get(ctx, caps, 0);
  KLObject* t2009 = shen_vector_get(ctx, caps, 1);
  KLObject* t2010 = shen_vector_get(ctx, caps, 2);
  KLObject* t2011 = shen_vector_get(ctx, caps, 3);
  KLObject* t2012 = shen_vector_get(ctx, caps, 4);
  KLObject* t2013 = shen_vector_get(ctx, caps, 5);
  KLObject* t2014 = shen_vector_get(ctx, caps, 6);
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t2015 = objects[0];
  KLObject* t2016 = shen_apply_direct(ctx, "shen.incinfs", 0, NULL);
  KLObject* t2024;
  {
    Vector* caps_44 = shen_vector(ctx, 7);
    shen_vector_set(ctx, caps_44, 0, t2013);
    shen_vector_set(ctx, caps_44, 1, t2015);
    shen_vector_set(ctx, caps_44, 2, t2009);
    shen_vector_set(ctx, caps_44, 3, t2010);
    shen_vector_set(ctx, caps_44, 4, t2011);
    shen_vector_set(ctx, caps_44, 5, t2012);
    shen_vector_set(ctx, caps_44, 6, t2014);
    t2024 = shen_native_closure(ctx, 0, &lambda_44, caps_44);
  }
  KLObject* t2017;
  {
    KLObject* a2017[] = {t2008, t2015, t2009, t2010, t2011, t2012, t2024};
    t2017 = shen_tail_apply_direct(ctx, "shen.system-S-h", 7, a2017);
  }
    return t2017;
  }
}

static KLObject* lambda_46 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  KLObject* t2060 = shen_vector_get(ctx, caps, 0);
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t2061 = objects[0];
  KLObject* t2062;
  {
    Vector* a2062 = shen_vector(ctx, 1);
    shen_vector_set(ctx, a2062, 0, t2061);
    t2062 = shen_tail_apply(ctx, t2060, a2062);
  }
    return t2062;
  }
}

static KLObject* lambda_47 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  KLObject* t2075 = shen_vector_get(ctx, caps, 0);
  KLObject* t2076 = shen_vector_get(ctx, caps, 1);
  (void)arguments;
  KLObject* t2077;
  {
    Vector* a2077 = shen_vector(ctx, 1);
    shen_vector_set(ctx, a2077, 0, t2076);
    t2077 = shen_tail_apply(ctx, t2075, a2077);
  }
    return t2077;
}

static KLObject* lambda_48 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  KLObject* t2109 = shen_vector_get(ctx, caps, 0);
  KLObject* t2110 = shen_vector_get(ctx, caps, 1);
  (void)arguments;
  KLObject* t2111;
  {
    Vector* a2111 = shen_vector(ctx, 1);
    shen_vector_set(ctx, a2111, 0, t2110);
    t2111 = shen_tail_apply(ctx, t2109, a2111);
  }
    return t2111;
}

static KLObject* lambda_45 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  KLObject* t2052 = shen_vector_get(ctx, caps, 0);
  KLObject* t2053 = shen_vector_get(ctx, caps, 1);
  KLObject* t2054 = shen_vector_get(ctx, caps, 2);
  (void)arguments;
  KLObject* t2057 = shen_tl(ctx, t2052);
  KLObject* t2055;
  {
    KLObject* a2055[] = {t2057, t2053};
    t2055 = shen_apply_direct(ctx, "shen.lazyderef", 2, a2055);
  }
  KLObject* t2059;
  {
    Vector* caps_46 = shen_vector(ctx, 1);
    shen_vector_set(ctx, caps_46, 0, t2054);
    t2059 = shen_native_closure(ctx, 1, &lambda_46, caps_46);
  }
  KLObject* t2067 = shen_cons_p(ctx, t2055);
  KLObject* t2065;
  if (!shen_is_boolean(ctx, t2067))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t2067)) {
  KLObject* t2069 = shen_hd(ctx, t2055);
  KLObject* t2072 = shen_tl(ctx, t2055);
  KLObject* t2070;
  {
    KLObject* a2070[] = {t2072, t2053};
    t2070 = shen_apply_direct(ctx, "shen.lazyderef", 2, a2070);
  }
  KLObject* t2074;
  {
    Vector* caps_47 = shen_vector(ctx, 2);
    shen_vector_set(ctx, caps_47, 0, t2059);
    shen_vector_set(ctx, caps_47, 1, t2069);
    t2074 = shen_native_closure(ctx, 0, &lambda_47, caps_47);
  }
  KLObject* t2082 = shen_empty_list(ctx);
  KLObject* t2083 = shen_eq(ctx, t2070, t2082);
  KLObject* t2080;
  if (!shen_is_boolean(ctx, t2083))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t2083)) {
  KLObject* t2084;
  {
    KLObject* a2084[] = {t2074};
    t2084 = shen_tail_apply_direct(ctx, "thaw", 1, a2084);
  }
    t2080 = t2084;
  } else {
  KLObject* t2087;
  {
    KLObject* a2087[] = {t2070};
    t2087 = shen_apply_direct(ctx, "shen.pvar?", 1, a2087);
  }
  KLObject* t2086;
  if (!shen_is_boolean(ctx, t2087))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t2087)) {
  KLObject* t2091 = shen_empty_list(ctx);
  KLObject* t2089;
  {
    KLObject* a2089[] = {t2070, t2091, t2053, t2074};
    t2089 = shen_tail_apply_direct(ctx, "shen.bind!", 4, a2089);
  }
    t2086 = t2089;
  } else {
  KLObject* t2094 = shen_false(ctx);
    t2086 = t2094;
  }
    t2080 = t2086;
  }
    t2065 = t2080;
  } else {
  KLObject* t2096;
  {
    KLObject* a2096[] = {t2055};
    t2096 = shen_apply_direct(ctx, "shen.pvar?", 1, a2096);
  }
  KLObject* t2095;
  if (!shen_is_boolean(ctx, t2096))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t2096)) {
  KLObject* t2098;
  {
    KLObject* a2098[] = {t2053};
    t2098 = shen_apply_direct(ctx, "shen.newpv", 1, a2098);
  }
  KLObject* t2105 = shen_empty_list(ctx);
  KLObject* t2106 = shen_cons(ctx, t2098, t2105);
  KLObject* t2108;
  {
    Vector* caps_48 = shen_vector(ctx, 2);
    shen_vector_set(ctx, caps_48, 0, t2059);
    shen_vector_set(ctx, caps_48, 1, t2098);
    t2108 = shen_native_closure(ctx, 0, &lambda_48, caps_48);
  }
  KLObject* t2102;
  {
    KLObject* a2102[] = {t2055, t2106, t2053, t2108};
    t2102 = shen_apply_direct(ctx, "shen.bind!", 4, a2102);
  }
  KLObject* t2100;
  {
    KLObject* a2100[] = {t2053, t2102};
    t2100 = shen_tail_apply_direct(ctx, "shen.gc", 2, a2100);
  }
    t2095 = t2100;
  } else {
  KLObject* t2114 = shen_false(ctx);
    t2095 = t2114;
  }
    t2065 = t2095;
  }
    return t2065;
}

static KLObject* lambda_49 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  KLObject* t2146 = shen_vector_get(ctx, caps, 0);
  KLObject* t2147 = shen_vector_get(ctx, caps, 1);
  (void)arguments;
  KLObject* t2148;
  {
    Vector* a2148 = shen_vector(ctx, 1);
    shen_vector_set(ctx, a2148, 0, t2147);
    t2148 = shen_tail_apply(ctx, t2146, a2148);
  }
    return t2148;
}

static KLObject* lambda_51 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  KLObject* t2225 = shen_vector_get(ctx, caps, 0);
  KLObject* t2226 = shen_vector_get(ctx, caps, 1);
  KLObject* t2227 = shen_vector_get(ctx, caps, 2);
  KLObject* t2228 = shen_vector_get(ctx, caps, 3);
  KLObject* t2229 = shen_vector_get(ctx, caps, 4);
  KLObject* t2230 = shen_vector_get(ctx, caps, 5);
  (void)arguments;
  KLObject* t2233 = shen_intern(ctx, "string");
  KLObject* t2231;
  {
    KLObject* a2231[] = {t2225, t2233, t2226, t2227, t2228, t2229, t2230};
    t2231 = shen_tail_apply_direct(ctx, "shen.system-S-h", 7, a2231);
  }
    return t2231;
}

static KLObject* lambda_50 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  KLObject* t2209 = shen_vector_get(ctx, caps, 0);
  KLObject* t2210 = shen_vector_get(ctx, caps, 1);
  KLObject* t2211 = shen_vector_get(ctx, caps, 2);
  KLObject* t2212 = shen_vector_get(ctx, caps, 3);
  KLObject* t2213 = shen_vector_get(ctx, caps, 4);
  KLObject* t2214 = shen_vector_get(ctx, caps, 5);
  KLObject* t2215 = shen_vector_get(ctx, caps, 6);
  (void)arguments;
  KLObject* t2216 = shen_apply_direct(ctx, "shen.incinfs", 0, NULL);
  KLObject* t2219 = shen_intern(ctx, "string");
  KLObject* t2224;
  {
    Vector* caps_51 = shen_vector(ctx, 6);
    shen_vector_set(ctx, caps_51, 0, t2214);
    shen_vector_set(ctx, caps_51, 1, t2210);
    shen_vector_set(ctx, caps_51, 2, t2211);
    shen_vector_set(ctx, caps_51, 3, t2212);
    shen_vector_set(ctx, caps_51, 4, t2213);
    shen_vector_set(ctx, caps_51, 5, t2215);
    t2224 = shen_native_closure(ctx, 0, &lambda_51, caps_51);
  }
  KLObject* t2217;
  {
    KLObject* a2217[] = {t2209, t2219, t2210, t2211, t2212, t2213, t2224};
    t2217 = shen_tail_apply_direct(ctx, "shen.system-S-h", 7, a2217);
  }
    return t2217;
}

static KLObject* lambda_55 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  KLObject* t2375 = shen_vector_get(ctx, caps, 0);
  KLObject* t2376 = shen_vector_get(ctx, caps, 1);
  KLObject* t2377 = shen_vector_get(ctx, caps, 2);
  KLObject* t2378 = shen_vector_get(ctx, caps, 3);
  KLObject* t2379 = shen_vector_get(ctx, caps, 4);
  KLObject* t2380 = shen_vector_get(ctx, caps, 5);
  KLObject* t2381 = shen_vector_get(ctx, caps, 6);
  KLObject* t2382 = shen_vector_get(ctx, caps, 7);
  KLObject* t2383 = shen_vector_get(ctx, caps, 8);
  (void)arguments;
  KLObject* t2389 = shen_string(ctx, ":");
  KLObject* t2388;
  {
    KLObject* a2388[] = {t2389};
    t2388 = shen_apply_direct(ctx, "intern", 1, a2388);
  }
  KLObject* t2391 = shen_empty_list(ctx);
  KLObject* t2392 = shen_cons(ctx, t2378, t2391);
  KLObject* t2393 = shen_cons(ctx, t2388, t2392);
  KLObject* t2394 = shen_cons(ctx, t2377, t2393);
  KLObject* t2396 = shen_cons(ctx, t2394, t2379);
  KLObject* t2384;
  {
    KLObject* a2384[] = {t2375, t2376, t2396, t2380, t2381, t2382, t2383};
    t2384 = shen_tail_apply_direct(ctx, "shen.system-S-h", 7, a2384);
  }
    return t2384;
}

static KLObject* lambda_54 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  KLObject* t2348 = shen_vector_get(ctx, caps, 0);
  KLObject* t2349 = shen_vector_get(ctx, caps, 1);
  KLObject* t2350 = shen_vector_get(ctx, caps, 2);
  KLObject* t2351 = shen_vector_get(ctx, caps, 3);
  KLObject* t2352 = shen_vector_get(ctx, caps, 4);
  KLObject* t2353 = shen_vector_get(ctx, caps, 5);
  KLObject* t2354 = shen_vector_get(ctx, caps, 6);
  KLObject* t2355 = shen_vector_get(ctx, caps, 7);
  KLObject* t2356 = shen_vector_get(ctx, caps, 8);
  KLObject* t2357 = shen_vector_get(ctx, caps, 9);
  KLObject* t2358 = shen_vector_get(ctx, caps, 10);
  (void)arguments;
  KLObject* t2362;
  {
    KLObject* a2362[] = {t2349, t2350};
    t2362 = shen_apply_direct(ctx, "shen.lazyderef", 2, a2362);
  }
  KLObject* t2365;
  {
    KLObject* a2365[] = {t2351, t2350};
    t2365 = shen_apply_direct(ctx, "shen.deref", 2, a2365);
  }
  KLObject* t2368;
  {
    KLObject* a2368[] = {t2352, t2350};
    t2368 = shen_apply_direct(ctx, "shen.deref", 2, a2368);
  }
  KLObject* t2361;
  {
    KLObject* a2361[] = {t2362, t2365, t2368};
    t2361 = shen_apply_direct(ctx, "shen.beta", 3, a2361);
  }
  KLObject* t2374;
  {
    Vector* caps_55 = shen_vector(ctx, 9);
    shen_vector_set(ctx, caps_55, 0, t2348);
    shen_vector_set(ctx, caps_55, 1, t2355);
    shen_vector_set(ctx, caps_55, 2, t2351);
    shen_vector_set(ctx, caps_55, 3, t2356);
    shen_vector_set(ctx, caps_55, 4, t2357);
    shen_vector_set(ctx, caps_55, 5, t2350);
    shen_vector_set(ctx, caps_55, 6, t2353);
    shen_vector_set(ctx, caps_55, 7, t2354);
    shen_vector_set(ctx, caps_55, 8, t2358);
    t2374 = shen_native_closure(ctx, 0, &lambda_55, caps_55);
  }
  KLObject* t2359;
  {
    KLObject* a2359[] = {t2348, t2361, t2350, t2353, t2354, t2374};
    t2359 = shen_tail_apply_direct(ctx, "bind", 6, a2359);
  }
    return t2359;
}

static KLObject* lambda_53 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  KLObject* t2320 = shen_vector_get(ctx, caps, 0);
  KLObject* t2321 = shen_vector_get(ctx, caps, 1);
  KLObject* t2322 = shen_vector_get(ctx, caps, 2);
  KLObject* t2323 = shen_vector_get(ctx, caps, 3);
  KLObject* t2324 = shen_vector_get(ctx, caps, 4);
  KLObject* t2325 = shen_vector_get(ctx, caps, 5);
  KLObject* t2326 = shen_vector_get(ctx, caps, 6);
  KLObject* t2327 = shen_vector_get(ctx, caps, 7);
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t2328 = objects[0];
  KLObject* t2329;
  {
    KLObject* a2329[] = {t2320};
    t2329 = shen_apply_direct(ctx, "shen.newpv", 1, a2329);
  }
  KLObject* t2333;
  {
    KLObject* a2333[] = {t2320};
    t2333 = shen_apply_direct(ctx, "shen.newpv", 1, a2333);
  }
  KLObject* t2337 = shen_apply_direct(ctx, "shen.incinfs", 0, NULL);
  KLObject* t2341;
  {
    KLObject* a2341[] = {t2321, t2320};
    t2341 = shen_apply_direct(ctx, "shen.lazyderef", 2, a2341);
  }
  KLObject* t2340;
  {
    KLObject* a2340[] = {t2341};
    t2340 = shen_apply_direct(ctx, "shen.freshterm", 1, a2340);
  }
  KLObject* t2347;
  {
    Vector* caps_54 = shen_vector(ctx, 11);
    shen_vector_set(ctx, caps_54, 0, t2329);
    shen_vector_set(ctx, caps_54, 1, t2321);
    shen_vector_set(ctx, caps_54, 2, t2320);
    shen_vector_set(ctx, caps_54, 3, t2333);
    shen_vector_set(ctx, caps_54, 4, t2324);
    shen_vector_set(ctx, caps_54, 5, t2322);
    shen_vector_set(ctx, caps_54, 6, t2323);
    shen_vector_set(ctx, caps_54, 7, t2328);
    shen_vector_set(ctx, caps_54, 8, t2325);
    shen_vector_set(ctx, caps_54, 9, t2326);
    shen_vector_set(ctx, caps_54, 10, t2327);
    t2347 = shen_native_closure(ctx, 0, &lambda_54, caps_54);
  }
  KLObject* t2338;
  {
    KLObject* a2338[] = {t2333, t2340, t2320, t2322, t2323, t2347};
    t2338 = shen_apply_direct(ctx, "bind", 6, a2338);
  }
  KLObject* t2335;
  {
    KLObject* a2335[] = {t2320, t2338};
    t2335 = shen_apply_direct(ctx, "shen.gc", 2, a2335);
  }
  KLObject* t2331;
  {
    KLObject* a2331[] = {t2320, t2335};
    t2331 = shen_tail_apply_direct(ctx, "shen.gc", 2, a2331);
  }
    return t2331;
  }
}

static KLObject* lambda_52 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  KLObject* t2311 = shen_vector_get(ctx, caps, 0);
  KLObject* t2312 = shen_vector_get(ctx, caps, 1);
  KLObject* t2313 = shen_vector_get(ctx, caps, 2);
  KLObject* t2314 = shen_vector_get(ctx, caps, 3);
  KLObject* t2315 = shen_vector_get(ctx, caps, 4);
  KLObject* t2316 = shen_vector_get(ctx, caps, 5);
  KLObject* t2317 = shen_vector_get(ctx, caps, 6);
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t2318 = objects[0];
  KLObject* t2319;
  {
    Vector* caps_53 = shen_vector(ctx, 8);
    shen_vector_set(ctx, caps_53, 0, t2311);
    shen_vector_set(ctx, caps_53, 1, t2312);
    shen_vector_set(ctx, caps_53, 2, t2313);
    shen_vector_set(ctx, caps_53, 3, t2314);
    shen_vector_set(ctx, caps_53, 4, t2315);
    shen_vector_set(ctx, caps_53, 5, t2318);
    shen_vector_set(ctx, caps_53, 6, t2316);
    shen_vector_set(ctx, caps_53, 7, t2317);
    t2319 = shen_native_closure(ctx, 1, &lambda_53, caps_53);
  }
    return t2319;
  }
}

static KLObject* lambda_56 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  KLObject* t2411 = shen_vector_get(ctx, caps, 0);
  KLObject* t2412 = shen_vector_get(ctx, caps, 1);
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t2413 = objects[0];
  KLObject* t2415;
  {
    Vector* a2415 = shen_vector(ctx, 1);
    shen_vector_set(ctx, a2415, 0, t2412);
    t2415 = shen_apply(ctx, t2411, a2415);
  }
  KLObject* t2414;
  {
    Vector* a2414 = shen_vector(ctx, 1);
    shen_vector_set(ctx, a2414, 0, t2413);
    t2414 = shen_tail_apply(ctx, t2415, a2414);
  }
    return t2414;
  }
}

static KLObject* lambda_58 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  KLObject* t2435 = shen_vector_get(ctx, caps, 0);
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t2436 = objects[0];
  KLObject* t2437;
  {
    Vector* a2437 = shen_vector(ctx, 1);
    shen_vector_set(ctx, a2437, 0, t2436);
    t2437 = shen_tail_apply(ctx, t2435, a2437);
  }
    return t2437;
  }
}

static KLObject* lambda_59 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  KLObject* t2450 = shen_vector_get(ctx, caps, 0);
  KLObject* t2451 = shen_vector_get(ctx, caps, 1);
  (void)arguments;
  KLObject* t2452;
  {
    Vector* a2452 = shen_vector(ctx, 1);
    shen_vector_set(ctx, a2452, 0, t2451);
    t2452 = shen_tail_apply(ctx, t2450, a2452);
  }
    return t2452;
}

static KLObject* lambda_60 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  KLObject* t2484 = shen_vector_get(ctx, caps, 0);
  KLObject* t2485 = shen_vector_get(ctx, caps, 1);
  (void)arguments;
  KLObject* t2486;
  {
    Vector* a2486 = shen_vector(ctx, 1);
    shen_vector_set(ctx, a2486, 0, t2485);
    t2486 = shen_tail_apply(ctx, t2484, a2486);
  }
    return t2486;
}

static KLObject* lambda_57 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  KLObject* t2427 = shen_vector_get(ctx, caps, 0);
  KLObject* t2428 = shen_vector_get(ctx, caps, 1);
  KLObject* t2429 = shen_vector_get(ctx, caps, 2);
  (void)arguments;
  KLObject* t2432 = shen_tl(ctx, t2427);
  KLObject* t2430;
  {
    KLObject* a2430[] = {t2432, t2428};
    t2430 = shen_apply_direct(ctx, "shen.lazyderef", 2, a2430);
  }
  KLObject* t2434;
  {
    Vector* caps_58 = shen_vector(ctx, 1);
    shen_vector_set(ctx, caps_58, 0, t2429);
    t2434 = shen_native_closure(ctx, 1, &lambda_58, caps_58);
  }
  KLObject* t2442 = shen_cons_p(ctx, t2430);
  KLObject* t2440;
  if (!shen_is_boolean(ctx, t2442))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t2442)) {
  KLObject* t2444 = shen_hd(ctx, t2430);
  KLObject* t2447 = shen_tl(ctx, t2430);
  KLObject* t2445;
  {
    KLObject* a2445[] = {t2447, t2428};
    t2445 = shen_apply_direct(ctx, "shen.lazyderef", 2, a2445);
  }
  KLObject* t2449;
  {
    Vector* caps_59 = shen_vector(ctx, 2);
    shen_vector_set(ctx, caps_59, 0, t2434);
    shen_vector_set(ctx, caps_59, 1, t2444);
    t2449 = shen_native_closure(ctx, 0, &lambda_59, caps_59);
  }
  KLObject* t2457 = shen_empty_list(ctx);
  KLObject* t2458 = shen_eq(ctx, t2445, t2457);
  KLObject* t2455;
  if (!shen_is_boolean(ctx, t2458))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t2458)) {
  KLObject* t2459;
  {
    KLObject* a2459[] = {t2449};
    t2459 = shen_tail_apply_direct(ctx, "thaw", 1, a2459);
  }
    t2455 = t2459;
  } else {
  KLObject* t2462;
  {
    KLObject* a2462[] = {t2445};
    t2462 = shen_apply_direct(ctx, "shen.pvar?", 1, a2462);
  }
  KLObject* t2461;
  if (!shen_is_boolean(ctx, t2462))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t2462)) {
  KLObject* t2466 = shen_empty_list(ctx);
  KLObject* t2464;
  {
    KLObject* a2464[] = {t2445, t2466, t2428, t2449};
    t2464 = shen_tail_apply_direct(ctx, "shen.bind!", 4, a2464);
  }
    t2461 = t2464;
  } else {
  KLObject* t2469 = shen_false(ctx);
    t2461 = t2469;
  }
    t2455 = t2461;
  }
    t2440 = t2455;
  } else {
  KLObject* t2471;
  {
    KLObject* a2471[] = {t2430};
    t2471 = shen_apply_direct(ctx, "shen.pvar?", 1, a2471);
  }
  KLObject* t2470;
  if (!shen_is_boolean(ctx, t2471))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t2471)) {
  KLObject* t2473;
  {
    KLObject* a2473[] = {t2428};
    t2473 = shen_apply_direct(ctx, "shen.newpv", 1, a2473);
  }
  KLObject* t2480 = shen_empty_list(ctx);
  KLObject* t2481 = shen_cons(ctx, t2473, t2480);
  KLObject* t2483;
  {
    Vector* caps_60 = shen_vector(ctx, 2);
    shen_vector_set(ctx, caps_60, 0, t2434);
    shen_vector_set(ctx, caps_60, 1, t2473);
    t2483 = shen_native_closure(ctx, 0, &lambda_60, caps_60);
  }
  KLObject* t2477;
  {
    KLObject* a2477[] = {t2430, t2481, t2428, t2483};
    t2477 = shen_apply_direct(ctx, "shen.bind!", 4, a2477);
  }
  KLObject* t2475;
  {
    KLObject* a2475[] = {t2428, t2477};
    t2475 = shen_tail_apply_direct(ctx, "shen.gc", 2, a2475);
  }
    t2470 = t2475;
  } else {
  KLObject* t2489 = shen_false(ctx);
    t2470 = t2489;
  }
    t2440 = t2470;
  }
    return t2440;
}

static KLObject* lambda_61 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  KLObject* t2521 = shen_vector_get(ctx, caps, 0);
  KLObject* t2522 = shen_vector_get(ctx, caps, 1);
  (void)arguments;
  KLObject* t2523;
  {
    Vector* a2523 = shen_vector(ctx, 1);
    shen_vector_set(ctx, a2523, 0, t2522);
    t2523 = shen_tail_apply(ctx, t2521, a2523);
  }
    return t2523;
}

static KLObject* lambda_62 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  KLObject* t2549 = shen_vector_get(ctx, caps, 0);
  KLObject* t2550 = shen_vector_get(ctx, caps, 1);
  KLObject* t2551 = shen_vector_get(ctx, caps, 2);
  (void)arguments;
  KLObject* t2553;
  {
    Vector* a2553 = shen_vector(ctx, 1);
    shen_vector_set(ctx, a2553, 0, t2550);
    t2553 = shen_apply(ctx, t2549, a2553);
  }
  KLObject* t2552;
  {
    Vector* a2552 = shen_vector(ctx, 1);
    shen_vector_set(ctx, a2552, 0, t2551);
    t2552 = shen_tail_apply(ctx, t2553, a2552);
  }
    return t2552;
}

static KLObject* lambda_65 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  KLObject* t2689 = shen_vector_get(ctx, caps, 0);
  KLObject* t2690 = shen_vector_get(ctx, caps, 1);
  KLObject* t2691 = shen_vector_get(ctx, caps, 2);
  KLObject* t2692 = shen_vector_get(ctx, caps, 3);
  KLObject* t2693 = shen_vector_get(ctx, caps, 4);
  KLObject* t2694 = shen_vector_get(ctx, caps, 5);
  KLObject* t2695 = shen_vector_get(ctx, caps, 6);
  KLObject* t2696 = shen_vector_get(ctx, caps, 7);
  KLObject* t2697 = shen_vector_get(ctx, caps, 8);
  (void)arguments;
  KLObject* t2703 = shen_string(ctx, ":");
  KLObject* t2702;
  {
    KLObject* a2702[] = {t2703};
    t2702 = shen_apply_direct(ctx, "intern", 1, a2702);
  }
  KLObject* t2705 = shen_empty_list(ctx);
  KLObject* t2706 = shen_cons(ctx, t2692, t2705);
  KLObject* t2707 = shen_cons(ctx, t2702, t2706);
  KLObject* t2708 = shen_cons(ctx, t2691, t2707);
  KLObject* t2710 = shen_cons(ctx, t2708, t2693);
  KLObject* t2698;
  {
    KLObject* a2698[] = {t2689, t2690, t2710, t2694, t2695, t2696, t2697};
    t2698 = shen_tail_apply_direct(ctx, "shen.system-S-h", 7, a2698);
  }
    return t2698;
}

static KLObject* lambda_64 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  KLObject* t2662 = shen_vector_get(ctx, caps, 0);
  KLObject* t2663 = shen_vector_get(ctx, caps, 1);
  KLObject* t2664 = shen_vector_get(ctx, caps, 2);
  KLObject* t2665 = shen_vector_get(ctx, caps, 3);
  KLObject* t2666 = shen_vector_get(ctx, caps, 4);
  KLObject* t2667 = shen_vector_get(ctx, caps, 5);
  KLObject* t2668 = shen_vector_get(ctx, caps, 6);
  KLObject* t2669 = shen_vector_get(ctx, caps, 7);
  KLObject* t2670 = shen_vector_get(ctx, caps, 8);
  KLObject* t2671 = shen_vector_get(ctx, caps, 9);
  KLObject* t2672 = shen_vector_get(ctx, caps, 10);
  (void)arguments;
  KLObject* t2676;
  {
    KLObject* a2676[] = {t2663, t2664};
    t2676 = shen_apply_direct(ctx, "shen.lazyderef", 2, a2676);
  }
  KLObject* t2679;
  {
    KLObject* a2679[] = {t2665, t2664};
    t2679 = shen_apply_direct(ctx, "shen.lazyderef", 2, a2679);
  }
  KLObject* t2682;
  {
    KLObject* a2682[] = {t2666, t2664};
    t2682 = shen_apply_direct(ctx, "shen.lazyderef", 2, a2682);
  }
  KLObject* t2675;
  {
    KLObject* a2675[] = {t2676, t2679, t2682};
    t2675 = shen_apply_direct(ctx, "shen.beta", 3, a2675);
  }
  KLObject* t2688;
  {
    Vector* caps_65 = shen_vector(ctx, 9);
    shen_vector_set(ctx, caps_65, 0, t2662);
    shen_vector_set(ctx, caps_65, 1, t2669);
    shen_vector_set(ctx, caps_65, 2, t2665);
    shen_vector_set(ctx, caps_65, 3, t2670);
    shen_vector_set(ctx, caps_65, 4, t2671);
    shen_vector_set(ctx, caps_65, 5, t2664);
    shen_vector_set(ctx, caps_65, 6, t2667);
    shen_vector_set(ctx, caps_65, 7, t2668);
    shen_vector_set(ctx, caps_65, 8, t2672);
    t2688 = shen_native_closure(ctx, 0, &lambda_65, caps_65);
  }
  KLObject* t2673;
  {
    KLObject* a2673[] = {t2662, t2675, t2664, t2667, t2668, t2688};
    t2673 = shen_tail_apply_direct(ctx, "bind", 6, a2673);
  }
    return t2673;
}

static KLObject* lambda_63 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  KLObject* t2641 = shen_vector_get(ctx, caps, 0);
  KLObject* t2642 = shen_vector_get(ctx, caps, 1);
  KLObject* t2643 = shen_vector_get(ctx, caps, 2);
  KLObject* t2644 = shen_vector_get(ctx, caps, 3);
  KLObject* t2645 = shen_vector_get(ctx, caps, 4);
  KLObject* t2646 = shen_vector_get(ctx, caps, 5);
  KLObject* t2647 = shen_vector_get(ctx, caps, 6);
  KLObject* t2648 = shen_vector_get(ctx, caps, 7);
  KLObject* t2649 = shen_vector_get(ctx, caps, 8);
  KLObject* t2650 = shen_vector_get(ctx, caps, 9);
  KLObject* t2651 = shen_vector_get(ctx, caps, 10);
  (void)arguments;
  KLObject* t2655;
  {
    KLObject* a2655[] = {t2642, t2643};
    t2655 = shen_apply_direct(ctx, "shen.lazyderef", 2, a2655);
  }
  KLObject* t2654;
  {
    KLObject* a2654[] = {t2655};
    t2654 = shen_apply_direct(ctx, "shen.freshterm", 1, a2654);
  }
  KLObject* t2661;
  {
    Vector* caps_64 = shen_vector(ctx, 11);
    shen_vector_set(ctx, caps_64, 0, t2646);
    shen_vector_set(ctx, caps_64, 1, t2642);
    shen_vector_set(ctx, caps_64, 2, t2643);
    shen_vector_set(ctx, caps_64, 3, t2641);
    shen_vector_set(ctx, caps_64, 4, t2647);
    shen_vector_set(ctx, caps_64, 5, t2644);
    shen_vector_set(ctx, caps_64, 6, t2645);
    shen_vector_set(ctx, caps_64, 7, t2648);
    shen_vector_set(ctx, caps_64, 8, t2649);
    shen_vector_set(ctx, caps_64, 9, t2650);
    shen_vector_set(ctx, caps_64, 10, t2651);
    t2661 = shen_native_closure(ctx, 0, &lambda_64, caps_64);
  }
  KLObject* t2652;
  {
    KLObject* a2652[] = {t2641, t2654, t2643, t2644, t2645, t2661};
    t2652 = shen_tail_apply_direct(ctx, "bind", 6, a2652);
  }
    return t2652;
}

static KLObject* lambda_68 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  KLObject* t2810 = shen_vector_get(ctx, caps, 0);
  KLObject* t2811 = shen_vector_get(ctx, caps, 1);
  KLObject* t2812 = shen_vector_get(ctx, caps, 2);
  KLObject* t2813 = shen_vector_get(ctx, caps, 3);
  KLObject* t2814 = shen_vector_get(ctx, caps, 4);
  KLObject* t2815 = shen_vector_get(ctx, caps, 5);
  (void)arguments;
  KLObject* t2818 = shen_intern(ctx, "string");
  KLObject* t2816;
  {
    KLObject* a2816[] = {t2810, t2818, t2811, t2812, t2813, t2814, t2815};
    t2816 = shen_tail_apply_direct(ctx, "shen.system-S-h", 7, a2816);
  }
    return t2816;
}

static KLObject* lambda_67 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  KLObject* t2789 = shen_vector_get(ctx, caps, 0);
  KLObject* t2790 = shen_vector_get(ctx, caps, 1);
  KLObject* t2791 = shen_vector_get(ctx, caps, 2);
  KLObject* t2792 = shen_vector_get(ctx, caps, 3);
  KLObject* t2793 = shen_vector_get(ctx, caps, 4);
  KLObject* t2794 = shen_vector_get(ctx, caps, 5);
  KLObject* t2795 = shen_vector_get(ctx, caps, 6);
  (void)arguments;
  KLObject* t2798;
  {
    KLObject* a2798[] = {t2789, t2790};
    t2798 = shen_apply_direct(ctx, "shen.lazyderef", 2, a2798);
  }
  KLObject* t2801 = shen_intern(ctx, "in");
  KLObject* t2802 = shen_intern(ctx, "out");
  KLObject* t2803 = shen_empty_list(ctx);
  KLObject* t2804 = shen_cons(ctx, t2802, t2803);
  KLObject* t2805 = shen_cons(ctx, t2801, t2804);
  KLObject* t2797;
  {
    KLObject* a2797[] = {t2798, t2805};
    t2797 = shen_apply_direct(ctx, "element?", 2, a2797);
  }
  KLObject* t2809;
  {
    Vector* caps_68 = shen_vector(ctx, 6);
    shen_vector_set(ctx, caps_68, 0, t2793);
    shen_vector_set(ctx, caps_68, 1, t2794);
    shen_vector_set(ctx, caps_68, 2, t2790);
    shen_vector_set(ctx, caps_68, 3, t2791);
    shen_vector_set(ctx, caps_68, 4, t2792);
    shen_vector_set(ctx, caps_68, 5, t2795);
    t2809 = shen_native_closure(ctx, 0, &lambda_68, caps_68);
  }
  KLObject* t2796;
  {
    KLObject* a2796[] = {t2797, t2790, t2791, t2792, t2809};
    t2796 = shen_tail_apply_direct(ctx, "when", 5, a2796);
  }
    return t2796;
}

static KLObject* lambda_66 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  KLObject* t2773 = shen_vector_get(ctx, caps, 0);
  KLObject* t2774 = shen_vector_get(ctx, caps, 1);
  KLObject* t2775 = shen_vector_get(ctx, caps, 2);
  KLObject* t2776 = shen_vector_get(ctx, caps, 3);
  KLObject* t2777 = shen_vector_get(ctx, caps, 4);
  KLObject* t2778 = shen_vector_get(ctx, caps, 5);
  KLObject* t2779 = shen_vector_get(ctx, caps, 6);
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t2780 = objects[0];
  KLObject* t2781 = shen_apply_direct(ctx, "shen.incinfs", 0, NULL);
  KLObject* t2788;
  {
    Vector* caps_67 = shen_vector(ctx, 7);
    shen_vector_set(ctx, caps_67, 0, t2780);
    shen_vector_set(ctx, caps_67, 1, t2774);
    shen_vector_set(ctx, caps_67, 2, t2775);
    shen_vector_set(ctx, caps_67, 3, t2776);
    shen_vector_set(ctx, caps_67, 4, t2777);
    shen_vector_set(ctx, caps_67, 5, t2778);
    shen_vector_set(ctx, caps_67, 6, t2779);
    t2788 = shen_native_closure(ctx, 0, &lambda_67, caps_67);
  }
  KLObject* t2782;
  {
    KLObject* a2782[] = {t2773, t2780, t2774, t2775, t2776, t2788};
    t2782 = shen_tail_apply_direct(ctx, "is!", 6, a2782);
  }
    return t2782;
  }
}

static KLObject* lambda_70 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  KLObject* t2840 = shen_vector_get(ctx, caps, 0);
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t2841 = objects[0];
  KLObject* t2842;
  {
    Vector* a2842 = shen_vector(ctx, 1);
    shen_vector_set(ctx, a2842, 0, t2841);
    t2842 = shen_tail_apply(ctx, t2840, a2842);
  }
    return t2842;
  }
}

static KLObject* lambda_71 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  KLObject* t2855 = shen_vector_get(ctx, caps, 0);
  KLObject* t2856 = shen_vector_get(ctx, caps, 1);
  (void)arguments;
  KLObject* t2857;
  {
    Vector* a2857 = shen_vector(ctx, 1);
    shen_vector_set(ctx, a2857, 0, t2856);
    t2857 = shen_tail_apply(ctx, t2855, a2857);
  }
    return t2857;
}

static KLObject* lambda_72 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  KLObject* t2889 = shen_vector_get(ctx, caps, 0);
  KLObject* t2890 = shen_vector_get(ctx, caps, 1);
  (void)arguments;
  KLObject* t2891;
  {
    Vector* a2891 = shen_vector(ctx, 1);
    shen_vector_set(ctx, a2891, 0, t2890);
    t2891 = shen_tail_apply(ctx, t2889, a2891);
  }
    return t2891;
}

static KLObject* lambda_69 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  KLObject* t2832 = shen_vector_get(ctx, caps, 0);
  KLObject* t2833 = shen_vector_get(ctx, caps, 1);
  KLObject* t2834 = shen_vector_get(ctx, caps, 2);
  (void)arguments;
  KLObject* t2837 = shen_tl(ctx, t2832);
  KLObject* t2835;
  {
    KLObject* a2835[] = {t2837, t2833};
    t2835 = shen_apply_direct(ctx, "shen.lazyderef", 2, a2835);
  }
  KLObject* t2839;
  {
    Vector* caps_70 = shen_vector(ctx, 1);
    shen_vector_set(ctx, caps_70, 0, t2834);
    t2839 = shen_native_closure(ctx, 1, &lambda_70, caps_70);
  }
  KLObject* t2847 = shen_cons_p(ctx, t2835);
  KLObject* t2845;
  if (!shen_is_boolean(ctx, t2847))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t2847)) {
  KLObject* t2849 = shen_hd(ctx, t2835);
  KLObject* t2852 = shen_tl(ctx, t2835);
  KLObject* t2850;
  {
    KLObject* a2850[] = {t2852, t2833};
    t2850 = shen_apply_direct(ctx, "shen.lazyderef", 2, a2850);
  }
  KLObject* t2854;
  {
    Vector* caps_71 = shen_vector(ctx, 2);
    shen_vector_set(ctx, caps_71, 0, t2839);
    shen_vector_set(ctx, caps_71, 1, t2849);
    t2854 = shen_native_closure(ctx, 0, &lambda_71, caps_71);
  }
  KLObject* t2862 = shen_empty_list(ctx);
  KLObject* t2863 = shen_eq(ctx, t2850, t2862);
  KLObject* t2860;
  if (!shen_is_boolean(ctx, t2863))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t2863)) {
  KLObject* t2864;
  {
    KLObject* a2864[] = {t2854};
    t2864 = shen_tail_apply_direct(ctx, "thaw", 1, a2864);
  }
    t2860 = t2864;
  } else {
  KLObject* t2867;
  {
    KLObject* a2867[] = {t2850};
    t2867 = shen_apply_direct(ctx, "shen.pvar?", 1, a2867);
  }
  KLObject* t2866;
  if (!shen_is_boolean(ctx, t2867))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t2867)) {
  KLObject* t2871 = shen_empty_list(ctx);
  KLObject* t2869;
  {
    KLObject* a2869[] = {t2850, t2871, t2833, t2854};
    t2869 = shen_tail_apply_direct(ctx, "shen.bind!", 4, a2869);
  }
    t2866 = t2869;
  } else {
  KLObject* t2874 = shen_false(ctx);
    t2866 = t2874;
  }
    t2860 = t2866;
  }
    t2845 = t2860;
  } else {
  KLObject* t2876;
  {
    KLObject* a2876[] = {t2835};
    t2876 = shen_apply_direct(ctx, "shen.pvar?", 1, a2876);
  }
  KLObject* t2875;
  if (!shen_is_boolean(ctx, t2876))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t2876)) {
  KLObject* t2878;
  {
    KLObject* a2878[] = {t2833};
    t2878 = shen_apply_direct(ctx, "shen.newpv", 1, a2878);
  }
  KLObject* t2885 = shen_empty_list(ctx);
  KLObject* t2886 = shen_cons(ctx, t2878, t2885);
  KLObject* t2888;
  {
    Vector* caps_72 = shen_vector(ctx, 2);
    shen_vector_set(ctx, caps_72, 0, t2839);
    shen_vector_set(ctx, caps_72, 1, t2878);
    t2888 = shen_native_closure(ctx, 0, &lambda_72, caps_72);
  }
  KLObject* t2882;
  {
    KLObject* a2882[] = {t2835, t2886, t2833, t2888};
    t2882 = shen_apply_direct(ctx, "shen.bind!", 4, a2882);
  }
  KLObject* t2880;
  {
    KLObject* a2880[] = {t2833, t2882};
    t2880 = shen_tail_apply_direct(ctx, "shen.gc", 2, a2880);
  }
    t2875 = t2880;
  } else {
  KLObject* t2894 = shen_false(ctx);
    t2875 = t2894;
  }
    t2845 = t2875;
  }
    return t2845;
}

static KLObject* lambda_73 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  KLObject* t2926 = shen_vector_get(ctx, caps, 0);
  KLObject* t2927 = shen_vector_get(ctx, caps, 1);
  (void)arguments;
  KLObject* t2928;
  {
    Vector* a2928 = shen_vector(ctx, 1);
    shen_vector_set(ctx, a2928, 0, t2927);
    t2928 = shen_tail_apply(ctx, t2926, a2928);
  }
    return t2928;
}

static KLObject* lambda_75 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  KLObject* t3009 = shen_vector_get(ctx, caps, 0);
  KLObject* t3010 = shen_vector_get(ctx, caps, 1);
  KLObject* t3011 = shen_vector_get(ctx, caps, 2);
  KLObject* t3012 = shen_vector_get(ctx, caps, 3);
  KLObject* t3013 = shen_vector_get(ctx, caps, 4);
  KLObject* t3014 = shen_vector_get(ctx, caps, 5);
  KLObject* t3015 = shen_vector_get(ctx, caps, 6);
  (void)arguments;
  KLObject* t3016;
  {
    KLObject* a3016[] = {t3009, t3010, t3011, t3012, t3013, t3014, t3015};
    t3016 = shen_tail_apply_direct(ctx, "shen.system-S-h", 7, a3016);
  }
    return t3016;
}

static KLObject* lambda_74 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  KLObject* t2991 = shen_vector_get(ctx, caps, 0);
  KLObject* t2992 = shen_vector_get(ctx, caps, 1);
  KLObject* t2993 = shen_vector_get(ctx, caps, 2);
  KLObject* t2994 = shen_vector_get(ctx, caps, 3);
  KLObject* t2995 = shen_vector_get(ctx, caps, 4);
  KLObject* t2996 = shen_vector_get(ctx, caps, 5);
  KLObject* t2997 = shen_vector_get(ctx, caps, 6);
  KLObject* t2998 = shen_vector_get(ctx, caps, 7);
  (void)arguments;
  KLObject* t3001;
  {
    KLObject* a3001[] = {t2991, t2992};
    t3001 = shen_apply_direct(ctx, "shen.deref", 2, a3001);
  }
  KLObject* t3000;
  {
    KLObject* a3000[] = {t3001};
    t3000 = shen_apply_direct(ctx, "shen.rectify-type", 1, a3000);
  }
  KLObject* t3008;
  {
    Vector* caps_75 = shen_vector(ctx, 7);
    shen_vector_set(ctx, caps_75, 0, t2996);
    shen_vector_set(ctx, caps_75, 1, t2993);
    shen_vector_set(ctx, caps_75, 2, t2997);
    shen_vector_set(ctx, caps_75, 3, t2992);
    shen_vector_set(ctx, caps_75, 4, t2994);
    shen_vector_set(ctx, caps_75, 5, t2995);
    shen_vector_set(ctx, caps_75, 6, t2998);
    t3008 = shen_native_closure(ctx, 0, &lambda_75, caps_75);
  }
  KLObject* t2999;
  {
    KLObject* a2999[] = {t3000, t2993, t2992, t2994, t2995, t3008};
    t2999 = shen_tail_apply_direct(ctx, "is!", 6, a2999);
  }
    return t2999;
}

static KLObject* lambda_76 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  KLObject* t3089 = shen_vector_get(ctx, caps, 0);
  KLObject* t3090 = shen_vector_get(ctx, caps, 1);
  KLObject* t3091 = shen_vector_get(ctx, caps, 2);
  KLObject* t3092 = shen_vector_get(ctx, caps, 3);
  KLObject* t3093 = shen_vector_get(ctx, caps, 4);
  KLObject* t3094 = shen_vector_get(ctx, caps, 5);
  (void)arguments;
  KLObject* t3097 = shen_intern(ctx, "stream");
  KLObject* t3098 = shen_intern(ctx, "in");
  KLObject* t3099 = shen_empty_list(ctx);
  KLObject* t3100 = shen_cons(ctx, t3098, t3099);
  KLObject* t3101 = shen_cons(ctx, t3097, t3100);
  KLObject* t3095;
  {
    KLObject* a3095[] = {t3089, t3101, t3090, t3091, t3092, t3093, t3094};
    t3095 = shen_tail_apply_direct(ctx, "shen.system-S-h", 7, a3095);
  }
    return t3095;
}

static KLObject* lambda_78 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  KLObject* t3189 = shen_vector_get(ctx, caps, 0);
  KLObject* t3190 = shen_vector_get(ctx, caps, 1);
  KLObject* t3191 = shen_vector_get(ctx, caps, 2);
  KLObject* t3192 = shen_vector_get(ctx, caps, 3);
  KLObject* t3193 = shen_vector_get(ctx, caps, 4);
  KLObject* t3194 = shen_vector_get(ctx, caps, 5);
  KLObject* t3195 = shen_vector_get(ctx, caps, 6);
  (void)arguments;
  KLObject* t3196;
  {
    KLObject* a3196[] = {t3189, t3190, t3191, t3192, t3193, t3194, t3195};
    t3196 = shen_tail_apply_direct(ctx, "shen.system-S-h", 7, a3196);
  }
    return t3196;
}

static KLObject* lambda_77 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  KLObject* t3169 = shen_vector_get(ctx, caps, 0);
  KLObject* t3170 = shen_vector_get(ctx, caps, 1);
  KLObject* t3171 = shen_vector_get(ctx, caps, 2);
  KLObject* t3172 = shen_vector_get(ctx, caps, 3);
  KLObject* t3173 = shen_vector_get(ctx, caps, 4);
  KLObject* t3174 = shen_vector_get(ctx, caps, 5);
  KLObject* t3175 = shen_vector_get(ctx, caps, 6);
  KLObject* t3176 = shen_vector_get(ctx, caps, 7);
  (void)arguments;
  KLObject* t3178 = shen_intern(ctx, "value");
  KLObject* t3180 = shen_empty_list(ctx);
  KLObject* t3181 = shen_cons(ctx, t3169, t3180);
  KLObject* t3182 = shen_cons(ctx, t3178, t3181);
  KLObject* t3188;
  {
    Vector* caps_78 = shen_vector(ctx, 7);
    shen_vector_set(ctx, caps_78, 0, t3175);
    shen_vector_set(ctx, caps_78, 1, t3170);
    shen_vector_set(ctx, caps_78, 2, t3171);
    shen_vector_set(ctx, caps_78, 3, t3172);
    shen_vector_set(ctx, caps_78, 4, t3173);
    shen_vector_set(ctx, caps_78, 5, t3174);
    shen_vector_set(ctx, caps_78, 6, t3176);
    t3188 = shen_native_closure(ctx, 0, &lambda_78, caps_78);
  }
  KLObject* t3177;
  {
    KLObject* a3177[] = {t3182, t3170, t3171, t3172, t3173, t3174, t3188};
    t3177 = shen_tail_apply_direct(ctx, "shen.system-S-h", 7, a3177);
  }
    return t3177;
}

static KLObject* lambda_80 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  KLObject* t3242 = shen_vector_get(ctx, caps, 0);
  KLObject* t3243 = shen_vector_get(ctx, caps, 1);
  KLObject* t3244 = shen_vector_get(ctx, caps, 2);
  KLObject* t3245 = shen_vector_get(ctx, caps, 3);
  KLObject* t3246 = shen_vector_get(ctx, caps, 4);
  KLObject* t3247 = shen_vector_get(ctx, caps, 5);
  KLObject* t3248 = shen_vector_get(ctx, caps, 6);
  (void)arguments;
  KLObject* t3249;
  {
    KLObject* a3249[] = {t3242, t3243, t3244, t3245, t3246, t3247, t3248};
    t3249 = shen_tail_apply_direct(ctx, "shen.system-S-h", 7, a3249);
  }
    return t3249;
}

static KLObject* lambda_79 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  KLObject* t3230 = shen_vector_get(ctx, caps, 0);
  KLObject* t3231 = shen_vector_get(ctx, caps, 1);
  KLObject* t3232 = shen_vector_get(ctx, caps, 2);
  KLObject* t3233 = shen_vector_get(ctx, caps, 3);
  KLObject* t3234 = shen_vector_get(ctx, caps, 4);
  KLObject* t3235 = shen_vector_get(ctx, caps, 5);
  KLObject* t3236 = shen_vector_get(ctx, caps, 6);
  (void)arguments;
  KLObject* t3241;
  {
    Vector* caps_80 = shen_vector(ctx, 7);
    shen_vector_set(ctx, caps_80, 0, t3233);
    shen_vector_set(ctx, caps_80, 1, t3234);
    shen_vector_set(ctx, caps_80, 2, t3235);
    shen_vector_set(ctx, caps_80, 3, t3230);
    shen_vector_set(ctx, caps_80, 4, t3231);
    shen_vector_set(ctx, caps_80, 5, t3232);
    shen_vector_set(ctx, caps_80, 6, t3236);
    t3241 = shen_native_closure(ctx, 0, &lambda_80, caps_80);
  }
  KLObject* t3237;
  {
    KLObject* a3237[] = {t3230, t3231, t3232, t3241};
    t3237 = shen_tail_apply_direct(ctx, "shen.cut", 4, a3237);
  }
    return t3237;
}

static KLObject* lambda_81 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  KLObject* t3369 = shen_vector_get(ctx, caps, 0);
  KLObject* t3370 = shen_vector_get(ctx, caps, 1);
  KLObject* t3371 = shen_vector_get(ctx, caps, 2);
  KLObject* t3372 = shen_vector_get(ctx, caps, 3);
  KLObject* t3373 = shen_vector_get(ctx, caps, 4);
  (void)arguments;
  KLObject* t3374 = shen_apply_direct(ctx, "shen.incinfs", 0, NULL);
  KLObject* t3376;
  {
    KLObject* a3376[] = {t3369, t3370};
    t3376 = shen_apply_direct(ctx, "shen.lazyderef", 2, a3376);
  }
  KLObject* t3379 = shen_number_p(ctx, t3376);
  KLObject* t3375;
  {
    KLObject* a3375[] = {t3379, t3370, t3371, t3372, t3373};
    t3375 = shen_tail_apply_direct(ctx, "when", 5, a3375);
  }
    return t3375;
}

static KLObject* lambda_82 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  KLObject* t3411 = shen_vector_get(ctx, caps, 0);
  KLObject* t3412 = shen_vector_get(ctx, caps, 1);
  KLObject* t3413 = shen_vector_get(ctx, caps, 2);
  KLObject* t3414 = shen_vector_get(ctx, caps, 3);
  KLObject* t3415 = shen_vector_get(ctx, caps, 4);
  (void)arguments;
  KLObject* t3416 = shen_apply_direct(ctx, "shen.incinfs", 0, NULL);
  KLObject* t3419;
  {
    KLObject* a3419[] = {t3411, t3412};
    t3419 = shen_apply_direct(ctx, "shen.lazyderef", 2, a3419);
  }
  KLObject* t3418;
  {
    KLObject* a3418[] = {t3419};
    t3418 = shen_apply_direct(ctx, "boolean?", 1, a3418);
  }
  KLObject* t3417;
  {
    KLObject* a3417[] = {t3418, t3412, t3413, t3414, t3415};
    t3417 = shen_tail_apply_direct(ctx, "when", 5, a3417);
  }
    return t3417;
}

static KLObject* lambda_83 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  KLObject* t3453 = shen_vector_get(ctx, caps, 0);
  KLObject* t3454 = shen_vector_get(ctx, caps, 1);
  KLObject* t3455 = shen_vector_get(ctx, caps, 2);
  KLObject* t3456 = shen_vector_get(ctx, caps, 3);
  KLObject* t3457 = shen_vector_get(ctx, caps, 4);
  (void)arguments;
  KLObject* t3458 = shen_apply_direct(ctx, "shen.incinfs", 0, NULL);
  KLObject* t3460;
  {
    KLObject* a3460[] = {t3453, t3454};
    t3460 = shen_apply_direct(ctx, "shen.lazyderef", 2, a3460);
  }
  KLObject* t3463 = shen_string_p(ctx, t3460);
  KLObject* t3459;
  {
    KLObject* a3459[] = {t3463, t3454, t3455, t3456, t3457};
    t3459 = shen_tail_apply_direct(ctx, "when", 5, a3459);
  }
    return t3459;
}

static KLObject* lambda_84 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  KLObject* t3495 = shen_vector_get(ctx, caps, 0);
  KLObject* t3496 = shen_vector_get(ctx, caps, 1);
  KLObject* t3497 = shen_vector_get(ctx, caps, 2);
  KLObject* t3498 = shen_vector_get(ctx, caps, 3);
  KLObject* t3499 = shen_vector_get(ctx, caps, 4);
  (void)arguments;
  KLObject* t3500 = shen_apply_direct(ctx, "shen.incinfs", 0, NULL);
  KLObject* t3502;
  {
    KLObject* a3502[] = {t3495, t3496};
    t3502 = shen_apply_direct(ctx, "shen.lazyderef", 2, a3502);
  }
  KLObject* t3505 = shen_symbol_p(ctx, t3502);
  KLObject* t3501;
  {
    KLObject* a3501[] = {t3505, t3496, t3497, t3498, t3499};
    t3501 = shen_tail_apply_direct(ctx, "when", 5, a3501);
  }
    return t3501;
}

static KLObject* lambda_85 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  KLObject* t3544 = shen_vector_get(ctx, caps, 0);
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t3545 = objects[0];
  KLObject* t3546 = shen_apply_direct(ctx, "shen.incinfs", 0, NULL);
  KLObject* t3547;
  {
    KLObject* a3547[] = {t3544};
    t3547 = shen_tail_apply_direct(ctx, "thaw", 1, a3547);
  }
    return t3547;
  }
}

static KLObject* lambda_87 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  KLObject* t3565 = shen_vector_get(ctx, caps, 0);
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t3566 = objects[0];
  KLObject* t3567;
  {
    Vector* a3567 = shen_vector(ctx, 1);
    shen_vector_set(ctx, a3567, 0, t3566);
    t3567 = shen_tail_apply(ctx, t3565, a3567);
  }
    return t3567;
  }
}

static KLObject* lambda_88 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  KLObject* t3580 = shen_vector_get(ctx, caps, 0);
  KLObject* t3581 = shen_vector_get(ctx, caps, 1);
  (void)arguments;
  KLObject* t3582;
  {
    Vector* a3582 = shen_vector(ctx, 1);
    shen_vector_set(ctx, a3582, 0, t3581);
    t3582 = shen_tail_apply(ctx, t3580, a3582);
  }
    return t3582;
}

static KLObject* lambda_89 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  KLObject* t3614 = shen_vector_get(ctx, caps, 0);
  KLObject* t3615 = shen_vector_get(ctx, caps, 1);
  (void)arguments;
  KLObject* t3616;
  {
    Vector* a3616 = shen_vector(ctx, 1);
    shen_vector_set(ctx, a3616, 0, t3615);
    t3616 = shen_tail_apply(ctx, t3614, a3616);
  }
    return t3616;
}

static KLObject* lambda_86 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  KLObject* t3557 = shen_vector_get(ctx, caps, 0);
  KLObject* t3558 = shen_vector_get(ctx, caps, 1);
  KLObject* t3559 = shen_vector_get(ctx, caps, 2);
  (void)arguments;
  KLObject* t3562 = shen_tl(ctx, t3557);
  KLObject* t3560;
  {
    KLObject* a3560[] = {t3562, t3558};
    t3560 = shen_apply_direct(ctx, "shen.lazyderef", 2, a3560);
  }
  KLObject* t3564;
  {
    Vector* caps_87 = shen_vector(ctx, 1);
    shen_vector_set(ctx, caps_87, 0, t3559);
    t3564 = shen_native_closure(ctx, 1, &lambda_87, caps_87);
  }
  KLObject* t3572 = shen_cons_p(ctx, t3560);
  KLObject* t3570;
  if (!shen_is_boolean(ctx, t3572))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t3572)) {
  KLObject* t3574 = shen_hd(ctx, t3560);
  KLObject* t3577 = shen_tl(ctx, t3560);
  KLObject* t3575;
  {
    KLObject* a3575[] = {t3577, t3558};
    t3575 = shen_apply_direct(ctx, "shen.lazyderef", 2, a3575);
  }
  KLObject* t3579;
  {
    Vector* caps_88 = shen_vector(ctx, 2);
    shen_vector_set(ctx, caps_88, 0, t3564);
    shen_vector_set(ctx, caps_88, 1, t3574);
    t3579 = shen_native_closure(ctx, 0, &lambda_88, caps_88);
  }
  KLObject* t3587 = shen_empty_list(ctx);
  KLObject* t3588 = shen_eq(ctx, t3575, t3587);
  KLObject* t3585;
  if (!shen_is_boolean(ctx, t3588))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t3588)) {
  KLObject* t3589;
  {
    KLObject* a3589[] = {t3579};
    t3589 = shen_tail_apply_direct(ctx, "thaw", 1, a3589);
  }
    t3585 = t3589;
  } else {
  KLObject* t3592;
  {
    KLObject* a3592[] = {t3575};
    t3592 = shen_apply_direct(ctx, "shen.pvar?", 1, a3592);
  }
  KLObject* t3591;
  if (!shen_is_boolean(ctx, t3592))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t3592)) {
  KLObject* t3596 = shen_empty_list(ctx);
  KLObject* t3594;
  {
    KLObject* a3594[] = {t3575, t3596, t3558, t3579};
    t3594 = shen_tail_apply_direct(ctx, "shen.bind!", 4, a3594);
  }
    t3591 = t3594;
  } else {
  KLObject* t3599 = shen_false(ctx);
    t3591 = t3599;
  }
    t3585 = t3591;
  }
    t3570 = t3585;
  } else {
  KLObject* t3601;
  {
    KLObject* a3601[] = {t3560};
    t3601 = shen_apply_direct(ctx, "shen.pvar?", 1, a3601);
  }
  KLObject* t3600;
  if (!shen_is_boolean(ctx, t3601))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t3601)) {
  KLObject* t3603;
  {
    KLObject* a3603[] = {t3558};
    t3603 = shen_apply_direct(ctx, "shen.newpv", 1, a3603);
  }
  KLObject* t3610 = shen_empty_list(ctx);
  KLObject* t3611 = shen_cons(ctx, t3603, t3610);
  KLObject* t3613;
  {
    Vector* caps_89 = shen_vector(ctx, 2);
    shen_vector_set(ctx, caps_89, 0, t3564);
    shen_vector_set(ctx, caps_89, 1, t3603);
    t3613 = shen_native_closure(ctx, 0, &lambda_89, caps_89);
  }
  KLObject* t3607;
  {
    KLObject* a3607[] = {t3560, t3611, t3558, t3613};
    t3607 = shen_apply_direct(ctx, "shen.bind!", 4, a3607);
  }
  KLObject* t3605;
  {
    KLObject* a3605[] = {t3558, t3607};
    t3605 = shen_tail_apply_direct(ctx, "shen.gc", 2, a3605);
  }
    t3600 = t3605;
  } else {
  KLObject* t3619 = shen_false(ctx);
    t3600 = t3619;
  }
    t3570 = t3600;
  }
    return t3570;
}

static KLObject* lambda_90 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  KLObject* t3651 = shen_vector_get(ctx, caps, 0);
  KLObject* t3652 = shen_vector_get(ctx, caps, 1);
  (void)arguments;
  KLObject* t3653;
  {
    Vector* a3653 = shen_vector(ctx, 1);
    shen_vector_set(ctx, a3653, 0, t3652);
    t3653 = shen_tail_apply(ctx, t3651, a3653);
  }
    return t3653;
}

static KLObject* lambda_92 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  KLObject* t3746 = shen_vector_get(ctx, caps, 0);
  KLObject* t3747 = shen_vector_get(ctx, caps, 1);
  KLObject* t3748 = shen_vector_get(ctx, caps, 2);
  KLObject* t3749 = shen_vector_get(ctx, caps, 3);
  KLObject* t3750 = shen_vector_get(ctx, caps, 4);
  KLObject* t3751 = shen_vector_get(ctx, caps, 5);
  (void)arguments;
  KLObject* t3752;
  {
    KLObject* a3752[] = {t3746, t3747, t3748, t3749, t3750, t3751};
    t3752 = shen_tail_apply_direct(ctx, "is!", 6, a3752);
  }
    return t3752;
}

static KLObject* lambda_91 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  KLObject* t3726 = shen_vector_get(ctx, caps, 0);
  KLObject* t3727 = shen_vector_get(ctx, caps, 1);
  KLObject* t3728 = shen_vector_get(ctx, caps, 2);
  KLObject* t3729 = shen_vector_get(ctx, caps, 3);
  KLObject* t3730 = shen_vector_get(ctx, caps, 4);
  KLObject* t3731 = shen_vector_get(ctx, caps, 5);
  KLObject* t3732 = shen_vector_get(ctx, caps, 6);
  KLObject* t3733 = shen_vector_get(ctx, caps, 7);
  (void)arguments;
  KLObject* t3735;
  {
    KLObject* a3735[] = {t3726, t3727};
    t3735 = shen_apply_direct(ctx, "shen.deref", 2, a3735);
  }
  KLObject* t3738;
  {
    KLObject* a3738[] = {t3728, t3727};
    t3738 = shen_apply_direct(ctx, "shen.deref", 2, a3738);
  }
  KLObject* t3741 = shen_eq(ctx, t3735, t3738);
  KLObject* t3745;
  {
    Vector* caps_92 = shen_vector(ctx, 6);
    shen_vector_set(ctx, caps_92, 0, t3731);
    shen_vector_set(ctx, caps_92, 1, t3732);
    shen_vector_set(ctx, caps_92, 2, t3727);
    shen_vector_set(ctx, caps_92, 3, t3729);
    shen_vector_set(ctx, caps_92, 4, t3730);
    shen_vector_set(ctx, caps_92, 5, t3733);
    t3745 = shen_native_closure(ctx, 0, &lambda_92, caps_92);
  }
  KLObject* t3734;
  {
    KLObject* a3734[] = {t3741, t3727, t3729, t3730, t3745};
    t3734 = shen_tail_apply_direct(ctx, "when", 5, a3734);
  }
    return t3734;
}

static KLObject* lambda_93 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  KLObject* t3971 = shen_vector_get(ctx, caps, 0);
  KLObject* t3972 = shen_vector_get(ctx, caps, 1);
  KLObject* t3973 = shen_vector_get(ctx, caps, 2);
  KLObject* t3974 = shen_vector_get(ctx, caps, 3);
  KLObject* t3975 = shen_vector_get(ctx, caps, 4);
  (void)arguments;
  KLObject* t3978 = shen_empty_list(ctx);
  KLObject* t3976;
  {
    KLObject* a3976[] = {t3971, t3978, t3972, t3973, t3974, t3975};
    t3976 = shen_tail_apply_direct(ctx, "bind", 6, a3976);
  }
    return t3976;
}

static KLObject* lambda_95 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  KLObject* t4132 = shen_vector_get(ctx, caps, 0);
  KLObject* t4133 = shen_vector_get(ctx, caps, 1);
  KLObject* t4134 = shen_vector_get(ctx, caps, 2);
  KLObject* t4135 = shen_vector_get(ctx, caps, 3);
  KLObject* t4136 = shen_vector_get(ctx, caps, 4);
  KLObject* t4137 = shen_vector_get(ctx, caps, 5);
  KLObject* t4138 = shen_vector_get(ctx, caps, 6);
  KLObject* t4139 = shen_vector_get(ctx, caps, 7);
  KLObject* t4140 = shen_vector_get(ctx, caps, 8);
  KLObject* t4141 = shen_vector_get(ctx, caps, 9);
  (void)arguments;
  KLObject* t4146 = shen_empty_list(ctx);
  KLObject* t4147 = shen_cons(ctx, t4134, t4146);
  KLObject* t4148 = shen_cons(ctx, t4133, t4147);
  KLObject* t4149 = shen_cons(ctx, t4132, t4148);
  KLObject* t4152 = shen_intern(ctx, "list");
  KLObject* t4154 = shen_empty_list(ctx);
  KLObject* t4155 = shen_cons(ctx, t4134, t4154);
  KLObject* t4156 = shen_cons(ctx, t4152, t4155);
  KLObject* t4157 = shen_empty_list(ctx);
  KLObject* t4158 = shen_cons(ctx, t4156, t4157);
  KLObject* t4159 = shen_cons(ctx, t4133, t4158);
  KLObject* t4160 = shen_cons(ctx, t4135, t4159);
  KLObject* t4162 = shen_cons(ctx, t4160, t4136);
  KLObject* t4163 = shen_cons(ctx, t4149, t4162);
  KLObject* t4165 = shen_true(ctx);
  KLObject* t4142;
  {
    KLObject* a4142[] = {t4163, t4137, t4165, t4138, t4139, t4140, t4141};
    t4142 = shen_tail_apply_direct(ctx, "shen.l-rules", 7, a4142);
  }
    return t4142;
}

static KLObject* lambda_94 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  KLObject* t4117 = shen_vector_get(ctx, caps, 0);
  KLObject* t4118 = shen_vector_get(ctx, caps, 1);
  KLObject* t4119 = shen_vector_get(ctx, caps, 2);
  KLObject* t4120 = shen_vector_get(ctx, caps, 3);
  KLObject* t4121 = shen_vector_get(ctx, caps, 4);
  KLObject* t4122 = shen_vector_get(ctx, caps, 5);
  KLObject* t4123 = shen_vector_get(ctx, caps, 6);
  KLObject* t4124 = shen_vector_get(ctx, caps, 7);
  KLObject* t4125 = shen_vector_get(ctx, caps, 8);
  KLObject* t4126 = shen_vector_get(ctx, caps, 9);
  (void)arguments;
  KLObject* t4131;
  {
    Vector* caps_95 = shen_vector(ctx, 10);
    shen_vector_set(ctx, caps_95, 0, t4120);
    shen_vector_set(ctx, caps_95, 1, t4121);
    shen_vector_set(ctx, caps_95, 2, t4122);
    shen_vector_set(ctx, caps_95, 3, t4123);
    shen_vector_set(ctx, caps_95, 4, t4124);
    shen_vector_set(ctx, caps_95, 5, t4125);
    shen_vector_set(ctx, caps_95, 6, t4117);
    shen_vector_set(ctx, caps_95, 7, t4118);
    shen_vector_set(ctx, caps_95, 8, t4119);
    shen_vector_set(ctx, caps_95, 9, t4126);
    t4131 = shen_native_closure(ctx, 0, &lambda_95, caps_95);
  }
  KLObject* t4127;
  {
    KLObject* a4127[] = {t4117, t4118, t4119, t4131};
    t4127 = shen_tail_apply_direct(ctx, "shen.cut", 4, a4127);
  }
    return t4127;
}

static KLObject* lambda_97 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  KLObject* t4341 = shen_vector_get(ctx, caps, 0);
  KLObject* t4342 = shen_vector_get(ctx, caps, 1);
  KLObject* t4343 = shen_vector_get(ctx, caps, 2);
  KLObject* t4344 = shen_vector_get(ctx, caps, 3);
  KLObject* t4345 = shen_vector_get(ctx, caps, 4);
  KLObject* t4346 = shen_vector_get(ctx, caps, 5);
  KLObject* t4347 = shen_vector_get(ctx, caps, 6);
  KLObject* t4348 = shen_vector_get(ctx, caps, 7);
  KLObject* t4349 = shen_vector_get(ctx, caps, 8);
  KLObject* t4350 = shen_vector_get(ctx, caps, 9);
  KLObject* t4351 = shen_vector_get(ctx, caps, 10);
  (void)arguments;
  KLObject* t4356 = shen_empty_list(ctx);
  KLObject* t4357 = shen_cons(ctx, t4343, t4356);
  KLObject* t4358 = shen_cons(ctx, t4342, t4357);
  KLObject* t4359 = shen_cons(ctx, t4341, t4358);
  KLObject* t4363 = shen_empty_list(ctx);
  KLObject* t4364 = shen_cons(ctx, t4345, t4363);
  KLObject* t4365 = shen_cons(ctx, t4342, t4364);
  KLObject* t4366 = shen_cons(ctx, t4344, t4365);
  KLObject* t4368 = shen_cons(ctx, t4366, t4346);
  KLObject* t4369 = shen_cons(ctx, t4359, t4368);
  KLObject* t4371 = shen_true(ctx);
  KLObject* t4352;
  {
    KLObject* a4352[] = {t4369, t4347, t4371, t4348, t4349, t4350, t4351};
    t4352 = shen_tail_apply_direct(ctx, "shen.l-rules", 7, a4352);
  }
    return t4352;
}

static KLObject* lambda_96 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  KLObject* t4325 = shen_vector_get(ctx, caps, 0);
  KLObject* t4326 = shen_vector_get(ctx, caps, 1);
  KLObject* t4327 = shen_vector_get(ctx, caps, 2);
  KLObject* t4328 = shen_vector_get(ctx, caps, 3);
  KLObject* t4329 = shen_vector_get(ctx, caps, 4);
  KLObject* t4330 = shen_vector_get(ctx, caps, 5);
  KLObject* t4331 = shen_vector_get(ctx, caps, 6);
  KLObject* t4332 = shen_vector_get(ctx, caps, 7);
  KLObject* t4333 = shen_vector_get(ctx, caps, 8);
  KLObject* t4334 = shen_vector_get(ctx, caps, 9);
  KLObject* t4335 = shen_vector_get(ctx, caps, 10);
  (void)arguments;
  KLObject* t4340;
  {
    Vector* caps_97 = shen_vector(ctx, 11);
    shen_vector_set(ctx, caps_97, 0, t4328);
    shen_vector_set(ctx, caps_97, 1, t4329);
    shen_vector_set(ctx, caps_97, 2, t4330);
    shen_vector_set(ctx, caps_97, 3, t4331);
    shen_vector_set(ctx, caps_97, 4, t4332);
    shen_vector_set(ctx, caps_97, 5, t4333);
    shen_vector_set(ctx, caps_97, 6, t4334);
    shen_vector_set(ctx, caps_97, 7, t4325);
    shen_vector_set(ctx, caps_97, 8, t4326);
    shen_vector_set(ctx, caps_97, 9, t4327);
    shen_vector_set(ctx, caps_97, 10, t4335);
    t4340 = shen_native_closure(ctx, 0, &lambda_97, caps_97);
  }
  KLObject* t4336;
  {
    KLObject* a4336[] = {t4325, t4326, t4327, t4340};
    t4336 = shen_tail_apply_direct(ctx, "shen.cut", 4, a4336);
  }
    return t4336;
}

static KLObject* lambda_99 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  KLObject* t4513 = shen_vector_get(ctx, caps, 0);
  KLObject* t4514 = shen_vector_get(ctx, caps, 1);
  KLObject* t4515 = shen_vector_get(ctx, caps, 2);
  KLObject* t4516 = shen_vector_get(ctx, caps, 3);
  KLObject* t4517 = shen_vector_get(ctx, caps, 4);
  KLObject* t4518 = shen_vector_get(ctx, caps, 5);
  KLObject* t4519 = shen_vector_get(ctx, caps, 6);
  KLObject* t4520 = shen_vector_get(ctx, caps, 7);
  KLObject* t4521 = shen_vector_get(ctx, caps, 8);
  (void)arguments;
  KLObject* t4525 = shen_intern(ctx, "string");
  KLObject* t4526 = shen_empty_list(ctx);
  KLObject* t4527 = shen_cons(ctx, t4525, t4526);
  KLObject* t4528 = shen_cons(ctx, t4514, t4527);
  KLObject* t4529 = shen_cons(ctx, t4513, t4528);
  KLObject* t4532 = shen_intern(ctx, "string");
  KLObject* t4533 = shen_empty_list(ctx);
  KLObject* t4534 = shen_cons(ctx, t4532, t4533);
  KLObject* t4535 = shen_cons(ctx, t4514, t4534);
  KLObject* t4536 = shen_cons(ctx, t4515, t4535);
  KLObject* t4538 = shen_cons(ctx, t4536, t4516);
  KLObject* t4539 = shen_cons(ctx, t4529, t4538);
  KLObject* t4541 = shen_true(ctx);
  KLObject* t4522;
  {
    KLObject* a4522[] = {t4539, t4517, t4541, t4518, t4519, t4520, t4521};
    t4522 = shen_tail_apply_direct(ctx, "shen.l-rules", 7, a4522);
  }
    return t4522;
}

static KLObject* lambda_98 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  KLObject* t4499 = shen_vector_get(ctx, caps, 0);
  KLObject* t4500 = shen_vector_get(ctx, caps, 1);
  KLObject* t4501 = shen_vector_get(ctx, caps, 2);
  KLObject* t4502 = shen_vector_get(ctx, caps, 3);
  KLObject* t4503 = shen_vector_get(ctx, caps, 4);
  KLObject* t4504 = shen_vector_get(ctx, caps, 5);
  KLObject* t4505 = shen_vector_get(ctx, caps, 6);
  KLObject* t4506 = shen_vector_get(ctx, caps, 7);
  KLObject* t4507 = shen_vector_get(ctx, caps, 8);
  (void)arguments;
  KLObject* t4512;
  {
    Vector* caps_99 = shen_vector(ctx, 9);
    shen_vector_set(ctx, caps_99, 0, t4502);
    shen_vector_set(ctx, caps_99, 1, t4503);
    shen_vector_set(ctx, caps_99, 2, t4504);
    shen_vector_set(ctx, caps_99, 3, t4505);
    shen_vector_set(ctx, caps_99, 4, t4506);
    shen_vector_set(ctx, caps_99, 5, t4499);
    shen_vector_set(ctx, caps_99, 6, t4500);
    shen_vector_set(ctx, caps_99, 7, t4501);
    shen_vector_set(ctx, caps_99, 8, t4507);
    t4512 = shen_native_closure(ctx, 0, &lambda_99, caps_99);
  }
  KLObject* t4508;
  {
    KLObject* a4508[] = {t4499, t4500, t4501, t4512};
    t4508 = shen_tail_apply_direct(ctx, "shen.cut", 4, a4508);
  }
    return t4508;
}

static KLObject* lambda_101 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  KLObject* t4704 = shen_vector_get(ctx, caps, 0);
  KLObject* t4705 = shen_vector_get(ctx, caps, 1);
  KLObject* t4706 = shen_vector_get(ctx, caps, 2);
  KLObject* t4707 = shen_vector_get(ctx, caps, 3);
  KLObject* t4708 = shen_vector_get(ctx, caps, 4);
  KLObject* t4709 = shen_vector_get(ctx, caps, 5);
  KLObject* t4710 = shen_vector_get(ctx, caps, 6);
  KLObject* t4711 = shen_vector_get(ctx, caps, 7);
  KLObject* t4712 = shen_vector_get(ctx, caps, 8);
  KLObject* t4713 = shen_vector_get(ctx, caps, 9);
  (void)arguments;
  KLObject* t4718 = shen_empty_list(ctx);
  KLObject* t4719 = shen_cons(ctx, t4706, t4718);
  KLObject* t4720 = shen_cons(ctx, t4705, t4719);
  KLObject* t4721 = shen_cons(ctx, t4704, t4720);
  KLObject* t4724 = shen_intern(ctx, "vector");
  KLObject* t4726 = shen_empty_list(ctx);
  KLObject* t4727 = shen_cons(ctx, t4706, t4726);
  KLObject* t4728 = shen_cons(ctx, t4724, t4727);
  KLObject* t4729 = shen_empty_list(ctx);
  KLObject* t4730 = shen_cons(ctx, t4728, t4729);
  KLObject* t4731 = shen_cons(ctx, t4705, t4730);
  KLObject* t4732 = shen_cons(ctx, t4707, t4731);
  KLObject* t4734 = shen_cons(ctx, t4732, t4708);
  KLObject* t4735 = shen_cons(ctx, t4721, t4734);
  KLObject* t4737 = shen_true(ctx);
  KLObject* t4714;
  {
    KLObject* a4714[] = {t4735, t4709, t4737, t4710, t4711, t4712, t4713};
    t4714 = shen_tail_apply_direct(ctx, "shen.l-rules", 7, a4714);
  }
    return t4714;
}

static KLObject* lambda_100 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  KLObject* t4689 = shen_vector_get(ctx, caps, 0);
  KLObject* t4690 = shen_vector_get(ctx, caps, 1);
  KLObject* t4691 = shen_vector_get(ctx, caps, 2);
  KLObject* t4692 = shen_vector_get(ctx, caps, 3);
  KLObject* t4693 = shen_vector_get(ctx, caps, 4);
  KLObject* t4694 = shen_vector_get(ctx, caps, 5);
  KLObject* t4695 = shen_vector_get(ctx, caps, 6);
  KLObject* t4696 = shen_vector_get(ctx, caps, 7);
  KLObject* t4697 = shen_vector_get(ctx, caps, 8);
  KLObject* t4698 = shen_vector_get(ctx, caps, 9);
  (void)arguments;
  KLObject* t4703;
  {
    Vector* caps_101 = shen_vector(ctx, 10);
    shen_vector_set(ctx, caps_101, 0, t4692);
    shen_vector_set(ctx, caps_101, 1, t4693);
    shen_vector_set(ctx, caps_101, 2, t4694);
    shen_vector_set(ctx, caps_101, 3, t4695);
    shen_vector_set(ctx, caps_101, 4, t4696);
    shen_vector_set(ctx, caps_101, 5, t4697);
    shen_vector_set(ctx, caps_101, 6, t4689);
    shen_vector_set(ctx, caps_101, 7, t4690);
    shen_vector_set(ctx, caps_101, 8, t4691);
    shen_vector_set(ctx, caps_101, 9, t4698);
    t4703 = shen_native_closure(ctx, 0, &lambda_101, caps_101);
  }
  KLObject* t4699;
  {
    KLObject* a4699[] = {t4689, t4690, t4691, t4703};
    t4699 = shen_tail_apply_direct(ctx, "shen.cut", 4, a4699);
  }
    return t4699;
}

static KLObject* lambda_104 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  KLObject* t4804 = shen_vector_get(ctx, caps, 0);
  KLObject* t4805 = shen_vector_get(ctx, caps, 1);
  KLObject* t4806 = shen_vector_get(ctx, caps, 2);
  KLObject* t4807 = shen_vector_get(ctx, caps, 3);
  KLObject* t4808 = shen_vector_get(ctx, caps, 4);
  KLObject* t4809 = shen_vector_get(ctx, caps, 5);
  KLObject* t4810 = shen_vector_get(ctx, caps, 6);
  (void)arguments;
  KLObject* t4811;
  {
    KLObject* a4811[] = {t4804, t4805, t4806, t4807, t4808, t4809, t4810};
    t4811 = shen_tail_apply_direct(ctx, "shen.l-rules", 7, a4811);
  }
    return t4811;
}

static KLObject* lambda_103 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  KLObject* t4787 = shen_vector_get(ctx, caps, 0);
  KLObject* t4788 = shen_vector_get(ctx, caps, 1);
  KLObject* t4789 = shen_vector_get(ctx, caps, 2);
  KLObject* t4790 = shen_vector_get(ctx, caps, 3);
  KLObject* t4791 = shen_vector_get(ctx, caps, 4);
  KLObject* t4792 = shen_vector_get(ctx, caps, 5);
  KLObject* t4793 = shen_vector_get(ctx, caps, 6);
  KLObject* t4794 = shen_vector_get(ctx, caps, 7);
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t4795 = objects[0];
  KLObject* t4796 = shen_apply_direct(ctx, "shen.incinfs", 0, NULL);
  KLObject* t4803;
  {
    Vector* caps_104 = shen_vector(ctx, 7);
    shen_vector_set(ctx, caps_104, 0, t4792);
    shen_vector_set(ctx, caps_104, 1, t4795);
    shen_vector_set(ctx, caps_104, 2, t4793);
    shen_vector_set(ctx, caps_104, 3, t4789);
    shen_vector_set(ctx, caps_104, 4, t4790);
    shen_vector_set(ctx, caps_104, 5, t4791);
    shen_vector_set(ctx, caps_104, 6, t4794);
    t4803 = shen_native_closure(ctx, 0, &lambda_104, caps_104);
  }
  KLObject* t4797;
  {
    KLObject* a4797[] = {t4787, t4788, t4789, t4790, t4791, t4803};
    t4797 = shen_tail_apply_direct(ctx, "bind", 6, a4797);
  }
    return t4797;
  }
}

static KLObject* lambda_102 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  KLObject* t4778 = shen_vector_get(ctx, caps, 0);
  KLObject* t4779 = shen_vector_get(ctx, caps, 1);
  KLObject* t4780 = shen_vector_get(ctx, caps, 2);
  KLObject* t4781 = shen_vector_get(ctx, caps, 3);
  KLObject* t4782 = shen_vector_get(ctx, caps, 4);
  KLObject* t4783 = shen_vector_get(ctx, caps, 5);
  KLObject* t4784 = shen_vector_get(ctx, caps, 6);
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t4785 = objects[0];
  KLObject* t4786;
  {
    Vector* caps_103 = shen_vector(ctx, 8);
    shen_vector_set(ctx, caps_103, 0, t4785);
    shen_vector_set(ctx, caps_103, 1, t4778);
    shen_vector_set(ctx, caps_103, 2, t4779);
    shen_vector_set(ctx, caps_103, 3, t4780);
    shen_vector_set(ctx, caps_103, 4, t4781);
    shen_vector_set(ctx, caps_103, 5, t4782);
    shen_vector_set(ctx, caps_103, 6, t4783);
    shen_vector_set(ctx, caps_103, 7, t4784);
    t4786 = shen_native_closure(ctx, 1, &lambda_103, caps_103);
  }
    return t4786;
  }
}

static KLObject* lambda_105 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  KLObject* t4849 = shen_vector_get(ctx, caps, 0);
  KLObject* t4850 = shen_vector_get(ctx, caps, 1);
  KLObject* t4851 = shen_vector_get(ctx, caps, 2);
  (void)arguments;
  KLObject* t4853;
  {
    Vector* a4853 = shen_vector(ctx, 1);
    shen_vector_set(ctx, a4853, 0, t4850);
    t4853 = shen_apply(ctx, t4849, a4853);
  }
  KLObject* t4852;
  {
    Vector* a4852 = shen_vector(ctx, 1);
    shen_vector_set(ctx, a4852, 0, t4851);
    t4852 = shen_tail_apply(ctx, t4853, a4852);
  }
    return t4852;
}

static KLObject* lambda_111 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  KLObject* t5030 = shen_vector_get(ctx, caps, 0);
  KLObject* t5031 = shen_vector_get(ctx, caps, 1);
  KLObject* t5032 = shen_vector_get(ctx, caps, 2);
  KLObject* t5033 = shen_vector_get(ctx, caps, 3);
  KLObject* t5034 = shen_vector_get(ctx, caps, 4);
  KLObject* t5035 = shen_vector_get(ctx, caps, 5);
  (void)arguments;
  KLObject* t5036;
  {
    KLObject* a5036[] = {t5030, t5031, t5032, t5033, t5034, t5035};
    t5036 = shen_tail_apply_direct(ctx, "is", 6, a5036);
  }
    return t5036;
}

static KLObject* lambda_110 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  KLObject* t5012 = shen_vector_get(ctx, caps, 0);
  KLObject* t5013 = shen_vector_get(ctx, caps, 1);
  KLObject* t5014 = shen_vector_get(ctx, caps, 2);
  KLObject* t5015 = shen_vector_get(ctx, caps, 3);
  KLObject* t5016 = shen_vector_get(ctx, caps, 4);
  KLObject* t5017 = shen_vector_get(ctx, caps, 5);
  KLObject* t5018 = shen_vector_get(ctx, caps, 6);
  KLObject* t5019 = shen_vector_get(ctx, caps, 7);
  KLObject* t5020 = shen_vector_get(ctx, caps, 8);
  (void)arguments;
  KLObject* t5025 = shen_number_l(ctx, 1);
  KLObject* t5029;
  {
    Vector* caps_111 = shen_vector(ctx, 6);
    shen_vector_set(ctx, caps_111, 0, t5018);
    shen_vector_set(ctx, caps_111, 1, t5019);
    shen_vector_set(ctx, caps_111, 2, t5015);
    shen_vector_set(ctx, caps_111, 3, t5016);
    shen_vector_set(ctx, caps_111, 4, t5017);
    shen_vector_set(ctx, caps_111, 5, t5020);
    t5029 = shen_native_closure(ctx, 0, &lambda_111, caps_111);
  }
  KLObject* t5021;
  {
    KLObject* a5021[] = {t5012, t5013, t5014, t5025, t5015, t5016, t5017, t5029};
    t5021 = shen_tail_apply_direct(ctx, "shen.t*-rules", 8, a5021);
  }
    return t5021;
}

static KLObject* lambda_109 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  KLObject* t4993 = shen_vector_get(ctx, caps, 0);
  KLObject* t4994 = shen_vector_get(ctx, caps, 1);
  KLObject* t4995 = shen_vector_get(ctx, caps, 2);
  KLObject* t4996 = shen_vector_get(ctx, caps, 3);
  KLObject* t4997 = shen_vector_get(ctx, caps, 4);
  KLObject* t4998 = shen_vector_get(ctx, caps, 5);
  KLObject* t4999 = shen_vector_get(ctx, caps, 6);
  KLObject* t5000 = shen_vector_get(ctx, caps, 7);
  KLObject* t5001 = shen_vector_get(ctx, caps, 8);
  (void)arguments;
  KLObject* t5005;
  {
    KLObject* a5005[] = {t4994, t4995};
    t5005 = shen_apply_direct(ctx, "shen.deref", 2, a5005);
  }
  KLObject* t5004;
  {
    KLObject* a5004[] = {t5005};
    t5004 = shen_apply_direct(ctx, "shen.freshen-sig", 1, a5004);
  }
  KLObject* t5011;
  {
    Vector* caps_110 = shen_vector(ctx, 9);
    shen_vector_set(ctx, caps_110, 0, t4998);
    shen_vector_set(ctx, caps_110, 1, t4999);
    shen_vector_set(ctx, caps_110, 2, t4993);
    shen_vector_set(ctx, caps_110, 3, t4995);
    shen_vector_set(ctx, caps_110, 4, t4996);
    shen_vector_set(ctx, caps_110, 5, t4997);
    shen_vector_set(ctx, caps_110, 6, t4994);
    shen_vector_set(ctx, caps_110, 7, t5000);
    shen_vector_set(ctx, caps_110, 8, t5001);
    t5011 = shen_native_closure(ctx, 0, &lambda_110, caps_110);
  }
  KLObject* t5002;
  {
    KLObject* a5002[] = {t4993, t5004, t4995, t4996, t4997, t5011};
    t5002 = shen_tail_apply_direct(ctx, "bind", 6, a5002);
  }
    return t5002;
}

static KLObject* lambda_108 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  KLObject* t4973 = shen_vector_get(ctx, caps, 0);
  KLObject* t4974 = shen_vector_get(ctx, caps, 1);
  KLObject* t4975 = shen_vector_get(ctx, caps, 2);
  KLObject* t4976 = shen_vector_get(ctx, caps, 3);
  KLObject* t4977 = shen_vector_get(ctx, caps, 4);
  KLObject* t4978 = shen_vector_get(ctx, caps, 5);
  KLObject* t4979 = shen_vector_get(ctx, caps, 6);
  KLObject* t4980 = shen_vector_get(ctx, caps, 7);
  KLObject* t4981 = shen_vector_get(ctx, caps, 8);
  KLObject* t4982 = shen_vector_get(ctx, caps, 9);
  (void)arguments;
  KLObject* t4986;
  {
    KLObject* a4986[] = {t4974, t4975};
    t4986 = shen_apply_direct(ctx, "shen.lazyderef", 2, a4986);
  }
  KLObject* t4985;
  {
    KLObject* a4985[] = {t4986};
    t4985 = shen_apply_direct(ctx, "snd", 1, a4985);
  }
  KLObject* t4992;
  {
    Vector* caps_109 = shen_vector(ctx, 9);
    shen_vector_set(ctx, caps_109, 0, t4978);
    shen_vector_set(ctx, caps_109, 1, t4979);
    shen_vector_set(ctx, caps_109, 2, t4975);
    shen_vector_set(ctx, caps_109, 3, t4976);
    shen_vector_set(ctx, caps_109, 4, t4977);
    shen_vector_set(ctx, caps_109, 5, t4980);
    shen_vector_set(ctx, caps_109, 6, t4973);
    shen_vector_set(ctx, caps_109, 7, t4981);
    shen_vector_set(ctx, caps_109, 8, t4982);
    t4992 = shen_native_closure(ctx, 0, &lambda_109, caps_109);
  }
  KLObject* t4983;
  {
    KLObject* a4983[] = {t4973, t4985, t4975, t4976, t4977, t4992};
    t4983 = shen_tail_apply_direct(ctx, "bind", 6, a4983);
  }
    return t4983;
}

static KLObject* lambda_107 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  KLObject* t4953 = shen_vector_get(ctx, caps, 0);
  KLObject* t4954 = shen_vector_get(ctx, caps, 1);
  KLObject* t4955 = shen_vector_get(ctx, caps, 2);
  KLObject* t4956 = shen_vector_get(ctx, caps, 3);
  KLObject* t4957 = shen_vector_get(ctx, caps, 4);
  KLObject* t4958 = shen_vector_get(ctx, caps, 5);
  KLObject* t4959 = shen_vector_get(ctx, caps, 6);
  KLObject* t4960 = shen_vector_get(ctx, caps, 7);
  KLObject* t4961 = shen_vector_get(ctx, caps, 8);
  KLObject* t4962 = shen_vector_get(ctx, caps, 9);
  (void)arguments;
  KLObject* t4966;
  {
    KLObject* a4966[] = {t4954, t4955};
    t4966 = shen_apply_direct(ctx, "shen.lazyderef", 2, a4966);
  }
  KLObject* t4965;
  {
    KLObject* a4965[] = {t4966};
    t4965 = shen_apply_direct(ctx, "fst", 1, a4965);
  }
  KLObject* t4972;
  {
    Vector* caps_108 = shen_vector(ctx, 10);
    shen_vector_set(ctx, caps_108, 0, t4958);
    shen_vector_set(ctx, caps_108, 1, t4954);
    shen_vector_set(ctx, caps_108, 2, t4955);
    shen_vector_set(ctx, caps_108, 3, t4956);
    shen_vector_set(ctx, caps_108, 4, t4957);
    shen_vector_set(ctx, caps_108, 5, t4959);
    shen_vector_set(ctx, caps_108, 6, t4953);
    shen_vector_set(ctx, caps_108, 7, t4960);
    shen_vector_set(ctx, caps_108, 8, t4961);
    shen_vector_set(ctx, caps_108, 9, t4962);
    t4972 = shen_native_closure(ctx, 0, &lambda_108, caps_108);
  }
  KLObject* t4963;
  {
    KLObject* a4963[] = {t4953, t4965, t4955, t4956, t4957, t4972};
    t4963 = shen_tail_apply_direct(ctx, "bind", 6, a4963);
  }
    return t4963;
}

static KLObject* lambda_106 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  KLObject* t4932 = shen_vector_get(ctx, caps, 0);
  KLObject* t4933 = shen_vector_get(ctx, caps, 1);
  KLObject* t4934 = shen_vector_get(ctx, caps, 2);
  KLObject* t4935 = shen_vector_get(ctx, caps, 3);
  KLObject* t4936 = shen_vector_get(ctx, caps, 4);
  KLObject* t4937 = shen_vector_get(ctx, caps, 5);
  KLObject* t4938 = shen_vector_get(ctx, caps, 6);
  KLObject* t4939 = shen_vector_get(ctx, caps, 7);
  KLObject* t4940 = shen_vector_get(ctx, caps, 8);
  KLObject* t4941 = shen_vector_get(ctx, caps, 9);
  KLObject* t4942 = shen_vector_get(ctx, caps, 10);
  (void)arguments;
  KLObject* t4948 = shen_cons(ctx, t4933, t4934);
  KLObject* t4945;
  {
    KLObject* a4945[] = {t4948};
    t4945 = shen_apply_direct(ctx, "shen.sigxrules", 1, a4945);
  }
  KLObject* t4952;
  {
    Vector* caps_107 = shen_vector(ctx, 10);
    shen_vector_set(ctx, caps_107, 0, t4938);
    shen_vector_set(ctx, caps_107, 1, t4932);
    shen_vector_set(ctx, caps_107, 2, t4935);
    shen_vector_set(ctx, caps_107, 3, t4936);
    shen_vector_set(ctx, caps_107, 4, t4937);
    shen_vector_set(ctx, caps_107, 5, t4939);
    shen_vector_set(ctx, caps_107, 6, t4940);
    shen_vector_set(ctx, caps_107, 7, t4933);
    shen_vector_set(ctx, caps_107, 8, t4941);
    shen_vector_set(ctx, caps_107, 9, t4942);
    t4952 = shen_native_closure(ctx, 0, &lambda_107, caps_107);
  }
  KLObject* t4943;
  {
    KLObject* a4943[] = {t4932, t4945, t4935, t4936, t4937, t4952};
    t4943 = shen_tail_apply_direct(ctx, "bind", 6, a4943);
  }
    return t4943;
}

static KLObject* lambda_112 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t5058 = objects[0];
  KLObject* t5059;
  {
    KLObject* a5059[] = {t5058};
    t5059 = shen_tail_apply_direct(ctx, "shen.<sig*rules>", 1, a5059);
  }
    return t5059;
  }
}

static KLObject* lambda_113 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t5120 = objects[0];
  KLObject* t5124 = shen_intern(ctx, "&");
  KLObject* t5123;
  {
    KLObject* a5123[] = {t5124, t5120};
    t5123 = shen_apply_direct(ctx, "concat", 2, a5123);
  }
  KLObject* t5122;
  {
    KLObject* a5122[] = {t5123};
    t5122 = shen_apply_direct(ctx, "shen.freshterm", 1, a5122);
  }
  KLObject* t5126 = shen_cons(ctx, t5120, t5122);
    return t5126;
  }
}

static KLObject* lambda_116 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  KLObject* t5684 = shen_vector_get(ctx, caps, 0);
  KLObject* t5685 = shen_vector_get(ctx, caps, 1);
  KLObject* t5686 = shen_vector_get(ctx, caps, 2);
  KLObject* t5687 = shen_vector_get(ctx, caps, 3);
  KLObject* t5688 = shen_vector_get(ctx, caps, 4);
  KLObject* t5689 = shen_vector_get(ctx, caps, 5);
  KLObject* t5690 = shen_vector_get(ctx, caps, 6);
  KLObject* t5691 = shen_vector_get(ctx, caps, 7);
  (void)arguments;
  KLObject* t5697 = shen_number_l(ctx, 1);
  KLObject* t5698 = shen_add(ctx, t5687, t5697);
  KLObject* t5692;
  {
    KLObject* a5692[] = {t5684, t5685, t5686, t5698, t5688, t5689, t5690, t5691};
    t5692 = shen_tail_apply_direct(ctx, "shen.t*-rules", 8, a5692);
  }
    return t5692;
}

static KLObject* lambda_115 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  KLObject* t5671 = shen_vector_get(ctx, caps, 0);
  KLObject* t5672 = shen_vector_get(ctx, caps, 1);
  KLObject* t5673 = shen_vector_get(ctx, caps, 2);
  KLObject* t5674 = shen_vector_get(ctx, caps, 3);
  KLObject* t5675 = shen_vector_get(ctx, caps, 4);
  KLObject* t5676 = shen_vector_get(ctx, caps, 5);
  KLObject* t5677 = shen_vector_get(ctx, caps, 6);
  KLObject* t5678 = shen_vector_get(ctx, caps, 7);
  (void)arguments;
  KLObject* t5683;
  {
    Vector* caps_116 = shen_vector(ctx, 8);
    shen_vector_set(ctx, caps_116, 0, t5674);
    shen_vector_set(ctx, caps_116, 1, t5675);
    shen_vector_set(ctx, caps_116, 2, t5676);
    shen_vector_set(ctx, caps_116, 3, t5677);
    shen_vector_set(ctx, caps_116, 4, t5671);
    shen_vector_set(ctx, caps_116, 5, t5672);
    shen_vector_set(ctx, caps_116, 6, t5673);
    shen_vector_set(ctx, caps_116, 7, t5678);
    t5683 = shen_native_closure(ctx, 0, &lambda_116, caps_116);
  }
  KLObject* t5679;
  {
    KLObject* a5679[] = {t5671, t5672, t5673, t5683};
    t5679 = shen_tail_apply_direct(ctx, "shen.cut", 4, a5679);
  }
    return t5679;
}

static KLObject* lambda_114 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  KLObject* t5646 = shen_vector_get(ctx, caps, 0);
  KLObject* t5647 = shen_vector_get(ctx, caps, 1);
  KLObject* t5648 = shen_vector_get(ctx, caps, 2);
  KLObject* t5649 = shen_vector_get(ctx, caps, 3);
  KLObject* t5650 = shen_vector_get(ctx, caps, 4);
  KLObject* t5651 = shen_vector_get(ctx, caps, 5);
  KLObject* t5652 = shen_vector_get(ctx, caps, 6);
  KLObject* t5653 = shen_vector_get(ctx, caps, 7);
  KLObject* t5654 = shen_vector_get(ctx, caps, 8);
  (void)arguments;
  KLObject* t5659;
  {
    KLObject* a5659[] = {t5648, t5649};
    t5659 = shen_apply_direct(ctx, "shen.lazyderef", 2, a5659);
  }
  KLObject* t5658;
  {
    KLObject* a5658[] = {t5659};
    t5658 = shen_apply_direct(ctx, "fst", 1, a5658);
  }
  KLObject* t5663;
  {
    KLObject* a5663[] = {t5648, t5649};
    t5663 = shen_apply_direct(ctx, "shen.lazyderef", 2, a5663);
  }
  KLObject* t5662;
  {
    KLObject* a5662[] = {t5663};
    t5662 = shen_apply_direct(ctx, "snd", 1, a5662);
  }
  KLObject* t5670;
  {
    Vector* caps_115 = shen_vector(ctx, 8);
    shen_vector_set(ctx, caps_115, 0, t5649);
    shen_vector_set(ctx, caps_115, 1, t5651);
    shen_vector_set(ctx, caps_115, 2, t5652);
    shen_vector_set(ctx, caps_115, 3, t5646);
    shen_vector_set(ctx, caps_115, 4, t5653);
    shen_vector_set(ctx, caps_115, 5, t5650);
    shen_vector_set(ctx, caps_115, 6, t5647);
    shen_vector_set(ctx, caps_115, 7, t5654);
    t5670 = shen_native_closure(ctx, 0, &lambda_115, caps_115);
  }
  KLObject* t5655;
  {
    KLObject* a5655[] = {t5646, t5647, t5658, t5662, t5650, t5649, t5651, t5652, t5670};
    t5655 = shen_tail_apply_direct(ctx, "shen.t*-rule", 9, a5655);
  }
    return t5655;
}

static KLObject* lambda_117 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t5723 = objects[0];
  KLObject* t5725;
  {
    KLObject* a5725[] = {t5723};
    t5725 = shen_apply_direct(ctx, "shen.freshterm", 1, a5725);
  }
  KLObject* t5727 = shen_cons(ctx, t5723, t5725);
    return t5727;
  }
}

static KLObject* lambda_118 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  KLObject* t5879 = shen_vector_get(ctx, caps, 0);
  KLObject* t5880 = shen_vector_get(ctx, caps, 1);
  KLObject* t5881 = shen_vector_get(ctx, caps, 2);
  KLObject* t5882 = shen_vector_get(ctx, caps, 3);
  KLObject* t5883 = shen_vector_get(ctx, caps, 4);
  KLObject* t5884 = shen_vector_get(ctx, caps, 5);
  (void)arguments;
  KLObject* t5888 = shen_empty_list(ctx);
  KLObject* t5885;
  {
    KLObject* a5885[] = {t5879, t5880, t5888, t5881, t5882, t5883, t5884};
    t5885 = shen_tail_apply_direct(ctx, "shen.t*-correct", 7, a5885);
  }
    return t5885;
}

static KLObject* lambda_122 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  KLObject* t5977 = shen_vector_get(ctx, caps, 0);
  KLObject* t5978 = shen_vector_get(ctx, caps, 1);
  KLObject* t5979 = shen_vector_get(ctx, caps, 2);
  KLObject* t5980 = shen_vector_get(ctx, caps, 3);
  KLObject* t5981 = shen_vector_get(ctx, caps, 4);
  KLObject* t5982 = shen_vector_get(ctx, caps, 5);
  KLObject* t5983 = shen_vector_get(ctx, caps, 6);
  (void)arguments;
  KLObject* t5984;
  {
    KLObject* a5984[] = {t5977, t5978, t5979, t5980, t5981, t5982, t5983};
    t5984 = shen_tail_apply_direct(ctx, "shen.t*-correct", 7, a5984);
  }
    return t5984;
}

static KLObject* lambda_121 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  KLObject* t5960 = shen_vector_get(ctx, caps, 0);
  KLObject* t5961 = shen_vector_get(ctx, caps, 1);
  KLObject* t5962 = shen_vector_get(ctx, caps, 2);
  KLObject* t5963 = shen_vector_get(ctx, caps, 3);
  KLObject* t5964 = shen_vector_get(ctx, caps, 4);
  KLObject* t5965 = shen_vector_get(ctx, caps, 5);
  KLObject* t5966 = shen_vector_get(ctx, caps, 6);
  KLObject* t5967 = shen_vector_get(ctx, caps, 7);
  KLObject* t5968 = shen_vector_get(ctx, caps, 8);
  (void)arguments;
  KLObject* t5976;
  {
    Vector* caps_122 = shen_vector(ctx, 7);
    shen_vector_set(ctx, caps_122, 0, t5966);
    shen_vector_set(ctx, caps_122, 1, t5967);
    shen_vector_set(ctx, caps_122, 2, t5962);
    shen_vector_set(ctx, caps_122, 3, t5963);
    shen_vector_set(ctx, caps_122, 4, t5964);
    shen_vector_set(ctx, caps_122, 5, t5965);
    shen_vector_set(ctx, caps_122, 6, t5968);
    t5976 = shen_native_closure(ctx, 0, &lambda_122, caps_122);
  }
  KLObject* t5969;
  {
    KLObject* a5969[] = {t5960, t5961, t5962, t5963, t5964, t5965, t5976};
    t5969 = shen_tail_apply_direct(ctx, "shen.myassume", 7, a5969);
  }
    return t5969;
}

static KLObject* lambda_120 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  KLObject* t5946 = shen_vector_get(ctx, caps, 0);
  KLObject* t5947 = shen_vector_get(ctx, caps, 1);
  KLObject* t5948 = shen_vector_get(ctx, caps, 2);
  KLObject* t5949 = shen_vector_get(ctx, caps, 3);
  KLObject* t5950 = shen_vector_get(ctx, caps, 4);
  KLObject* t5951 = shen_vector_get(ctx, caps, 5);
  KLObject* t5952 = shen_vector_get(ctx, caps, 6);
  KLObject* t5953 = shen_vector_get(ctx, caps, 7);
  KLObject* t5954 = shen_vector_get(ctx, caps, 8);
  (void)arguments;
  KLObject* t5959;
  {
    Vector* caps_121 = shen_vector(ctx, 9);
    shen_vector_set(ctx, caps_121, 0, t5949);
    shen_vector_set(ctx, caps_121, 1, t5950);
    shen_vector_set(ctx, caps_121, 2, t5951);
    shen_vector_set(ctx, caps_121, 3, t5946);
    shen_vector_set(ctx, caps_121, 4, t5947);
    shen_vector_set(ctx, caps_121, 5, t5948);
    shen_vector_set(ctx, caps_121, 6, t5952);
    shen_vector_set(ctx, caps_121, 7, t5953);
    shen_vector_set(ctx, caps_121, 8, t5954);
    t5959 = shen_native_closure(ctx, 0, &lambda_121, caps_121);
  }
  KLObject* t5955;
  {
    KLObject* a5955[] = {t5946, t5947, t5948, t5959};
    t5955 = shen_tail_apply_direct(ctx, "shen.cut", 4, a5955);
  }
    return t5955;
}

static KLObject* lambda_119 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  KLObject* t5927 = shen_vector_get(ctx, caps, 0);
  KLObject* t5928 = shen_vector_get(ctx, caps, 1);
  KLObject* t5929 = shen_vector_get(ctx, caps, 2);
  KLObject* t5930 = shen_vector_get(ctx, caps, 3);
  KLObject* t5931 = shen_vector_get(ctx, caps, 4);
  KLObject* t5932 = shen_vector_get(ctx, caps, 5);
  KLObject* t5933 = shen_vector_get(ctx, caps, 6);
  KLObject* t5934 = shen_vector_get(ctx, caps, 7);
  KLObject* t5935 = shen_vector_get(ctx, caps, 8);
  KLObject* t5936 = shen_vector_get(ctx, caps, 9);
  (void)arguments;
  KLObject* t5945;
  {
    Vector* caps_120 = shen_vector(ctx, 9);
    shen_vector_set(ctx, caps_120, 0, t5931);
    shen_vector_set(ctx, caps_120, 1, t5932);
    shen_vector_set(ctx, caps_120, 2, t5933);
    shen_vector_set(ctx, caps_120, 3, t5927);
    shen_vector_set(ctx, caps_120, 4, t5928);
    shen_vector_set(ctx, caps_120, 5, t5934);
    shen_vector_set(ctx, caps_120, 6, t5935);
    shen_vector_set(ctx, caps_120, 7, t5930);
    shen_vector_set(ctx, caps_120, 8, t5936);
    t5945 = shen_native_closure(ctx, 0, &lambda_120, caps_120);
  }
  KLObject* t5937;
  {
    KLObject* a5937[] = {t5927, t5928, t5929, t5930, t5931, t5932, t5933, t5945};
    t5937 = shen_tail_apply_direct(ctx, "shen.t*-integrity", 8, a5937);
  }
    return t5937;
}

static KLObject* lambda_123 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  KLObject* t6023 = shen_vector_get(ctx, caps, 0);
  (void)arguments;
  KLObject* t6024 = shen_apply_direct(ctx, "shen.incinfs", 0, NULL);
  KLObject* t6025;
  {
    KLObject* a6025[] = {t6023};
    t6025 = shen_tail_apply_direct(ctx, "thaw", 1, a6025);
  }
    return t6025;
}

static KLObject* lambda_130 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  KLObject* t6191 = shen_vector_get(ctx, caps, 0);
  KLObject* t6192 = shen_vector_get(ctx, caps, 1);
  KLObject* t6193 = shen_vector_get(ctx, caps, 2);
  KLObject* t6194 = shen_vector_get(ctx, caps, 3);
  KLObject* t6195 = shen_vector_get(ctx, caps, 4);
  KLObject* t6196 = shen_vector_get(ctx, caps, 5);
  KLObject* t6197 = shen_vector_get(ctx, caps, 6);
  (void)arguments;
  KLObject* t6198;
  {
    KLObject* a6198[] = {t6191, t6192, t6193, t6194, t6195, t6196, t6197};
    t6198 = shen_tail_apply_direct(ctx, "shen.myassume", 7, a6198);
  }
    return t6198;
}

static KLObject* lambda_129 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  KLObject* t6175 = shen_vector_get(ctx, caps, 0);
  KLObject* t6176 = shen_vector_get(ctx, caps, 1);
  KLObject* t6177 = shen_vector_get(ctx, caps, 2);
  KLObject* t6178 = shen_vector_get(ctx, caps, 3);
  KLObject* t6179 = shen_vector_get(ctx, caps, 4);
  KLObject* t6180 = shen_vector_get(ctx, caps, 5);
  KLObject* t6181 = shen_vector_get(ctx, caps, 6);
  KLObject* t6182 = shen_vector_get(ctx, caps, 7);
  (void)arguments;
  KLObject* t6186 = shen_string(ctx, ":");
  KLObject* t6185;
  {
    KLObject* a6185[] = {t6186};
    t6185 = shen_apply_direct(ctx, "intern", 1, a6185);
  }
  KLObject* t6190;
  {
    Vector* caps_130 = shen_vector(ctx, 7);
    shen_vector_set(ctx, caps_130, 0, t6179);
    shen_vector_set(ctx, caps_130, 1, t6180);
    shen_vector_set(ctx, caps_130, 2, t6181);
    shen_vector_set(ctx, caps_130, 3, t6176);
    shen_vector_set(ctx, caps_130, 4, t6177);
    shen_vector_set(ctx, caps_130, 5, t6178);
    shen_vector_set(ctx, caps_130, 6, t6182);
    t6190 = shen_native_closure(ctx, 0, &lambda_130, caps_130);
  }
  KLObject* t6183;
  {
    KLObject* a6183[] = {t6175, t6185, t6176, t6177, t6178, t6190};
    t6183 = shen_tail_apply_direct(ctx, "bind", 6, a6183);
  }
    return t6183;
}

static KLObject* lambda_128 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  KLObject* t6158 = shen_vector_get(ctx, caps, 0);
  KLObject* t6159 = shen_vector_get(ctx, caps, 1);
  KLObject* t6160 = shen_vector_get(ctx, caps, 2);
  KLObject* t6161 = shen_vector_get(ctx, caps, 3);
  KLObject* t6162 = shen_vector_get(ctx, caps, 4);
  KLObject* t6163 = shen_vector_get(ctx, caps, 5);
  KLObject* t6164 = shen_vector_get(ctx, caps, 6);
  KLObject* t6165 = shen_vector_get(ctx, caps, 7);
  KLObject* t6166 = shen_vector_get(ctx, caps, 8);
  KLObject* t6167 = shen_vector_get(ctx, caps, 9);
  (void)arguments;
  KLObject* t6174;
  {
    Vector* caps_129 = shen_vector(ctx, 8);
    shen_vector_set(ctx, caps_129, 0, t6163);
    shen_vector_set(ctx, caps_129, 1, t6160);
    shen_vector_set(ctx, caps_129, 2, t6161);
    shen_vector_set(ctx, caps_129, 3, t6162);
    shen_vector_set(ctx, caps_129, 4, t6164);
    shen_vector_set(ctx, caps_129, 5, t6165);
    shen_vector_set(ctx, caps_129, 6, t6166);
    shen_vector_set(ctx, caps_129, 7, t6167);
    t6174 = shen_native_closure(ctx, 0, &lambda_129, caps_129);
  }
  KLObject* t6168;
  {
    KLObject* a6168[] = {t6158, t6159, t6160, t6161, t6162, t6174};
    t6168 = shen_tail_apply_direct(ctx, "is!", 6, a6168);
  }
    return t6168;
}

static KLObject* lambda_127 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  KLObject* t6138 = shen_vector_get(ctx, caps, 0);
  KLObject* t6139 = shen_vector_get(ctx, caps, 1);
  KLObject* t6140 = shen_vector_get(ctx, caps, 2);
  KLObject* t6141 = shen_vector_get(ctx, caps, 3);
  KLObject* t6142 = shen_vector_get(ctx, caps, 4);
  KLObject* t6143 = shen_vector_get(ctx, caps, 5);
  KLObject* t6144 = shen_vector_get(ctx, caps, 6);
  KLObject* t6145 = shen_vector_get(ctx, caps, 7);
  KLObject* t6146 = shen_vector_get(ctx, caps, 8);
  KLObject* t6147 = shen_vector_get(ctx, caps, 9);
  KLObject* t6148 = shen_vector_get(ctx, caps, 10);
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t6149 = objects[0];
  KLObject* t6150 = shen_apply_direct(ctx, "shen.incinfs", 0, NULL);
  KLObject* t6157;
  {
    Vector* caps_128 = shen_vector(ctx, 10);
    shen_vector_set(ctx, caps_128, 0, t6143);
    shen_vector_set(ctx, caps_128, 1, t6144);
    shen_vector_set(ctx, caps_128, 2, t6140);
    shen_vector_set(ctx, caps_128, 3, t6141);
    shen_vector_set(ctx, caps_128, 4, t6142);
    shen_vector_set(ctx, caps_128, 5, t6145);
    shen_vector_set(ctx, caps_128, 6, t6146);
    shen_vector_set(ctx, caps_128, 7, t6147);
    shen_vector_set(ctx, caps_128, 8, t6149);
    shen_vector_set(ctx, caps_128, 9, t6148);
    t6157 = shen_native_closure(ctx, 0, &lambda_128, caps_128);
  }
  KLObject* t6151;
  {
    KLObject* a6151[] = {t6138, t6139, t6140, t6141, t6142, t6157};
    t6151 = shen_tail_apply_direct(ctx, "is!", 6, a6151);
  }
    return t6151;
  }
}

static KLObject* lambda_126 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  KLObject* t6126 = shen_vector_get(ctx, caps, 0);
  KLObject* t6127 = shen_vector_get(ctx, caps, 1);
  KLObject* t6128 = shen_vector_get(ctx, caps, 2);
  KLObject* t6129 = shen_vector_get(ctx, caps, 3);
  KLObject* t6130 = shen_vector_get(ctx, caps, 4);
  KLObject* t6131 = shen_vector_get(ctx, caps, 5);
  KLObject* t6132 = shen_vector_get(ctx, caps, 6);
  KLObject* t6133 = shen_vector_get(ctx, caps, 7);
  KLObject* t6134 = shen_vector_get(ctx, caps, 8);
  KLObject* t6135 = shen_vector_get(ctx, caps, 9);
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t6136 = objects[0];
  KLObject* t6137;
  {
    Vector* caps_127 = shen_vector(ctx, 11);
    shen_vector_set(ctx, caps_127, 0, t6126);
    shen_vector_set(ctx, caps_127, 1, t6136);
    shen_vector_set(ctx, caps_127, 2, t6127);
    shen_vector_set(ctx, caps_127, 3, t6128);
    shen_vector_set(ctx, caps_127, 4, t6129);
    shen_vector_set(ctx, caps_127, 5, t6130);
    shen_vector_set(ctx, caps_127, 6, t6131);
    shen_vector_set(ctx, caps_127, 7, t6132);
    shen_vector_set(ctx, caps_127, 8, t6133);
    shen_vector_set(ctx, caps_127, 9, t6134);
    shen_vector_set(ctx, caps_127, 10, t6135);
    t6137 = shen_native_closure(ctx, 1, &lambda_127, caps_127);
  }
    return t6137;
  }
}

static KLObject* lambda_125 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  KLObject* t6115 = shen_vector_get(ctx, caps, 0);
  KLObject* t6116 = shen_vector_get(ctx, caps, 1);
  KLObject* t6117 = shen_vector_get(ctx, caps, 2);
  KLObject* t6118 = shen_vector_get(ctx, caps, 3);
  KLObject* t6119 = shen_vector_get(ctx, caps, 4);
  KLObject* t6120 = shen_vector_get(ctx, caps, 5);
  KLObject* t6121 = shen_vector_get(ctx, caps, 6);
  KLObject* t6122 = shen_vector_get(ctx, caps, 7);
  KLObject* t6123 = shen_vector_get(ctx, caps, 8);
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t6124 = objects[0];
  KLObject* t6125;
  {
    Vector* caps_126 = shen_vector(ctx, 10);
    shen_vector_set(ctx, caps_126, 0, t6115);
    shen_vector_set(ctx, caps_126, 1, t6116);
    shen_vector_set(ctx, caps_126, 2, t6117);
    shen_vector_set(ctx, caps_126, 3, t6118);
    shen_vector_set(ctx, caps_126, 4, t6119);
    shen_vector_set(ctx, caps_126, 5, t6120);
    shen_vector_set(ctx, caps_126, 6, t6124);
    shen_vector_set(ctx, caps_126, 7, t6121);
    shen_vector_set(ctx, caps_126, 8, t6122);
    shen_vector_set(ctx, caps_126, 9, t6123);
    t6125 = shen_native_closure(ctx, 1, &lambda_126, caps_126);
  }
    return t6125;
  }
}

static KLObject* lambda_124 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  KLObject* t6105 = shen_vector_get(ctx, caps, 0);
  KLObject* t6106 = shen_vector_get(ctx, caps, 1);
  KLObject* t6107 = shen_vector_get(ctx, caps, 2);
  KLObject* t6108 = shen_vector_get(ctx, caps, 3);
  KLObject* t6109 = shen_vector_get(ctx, caps, 4);
  KLObject* t6110 = shen_vector_get(ctx, caps, 5);
  KLObject* t6111 = shen_vector_get(ctx, caps, 6);
  KLObject* t6112 = shen_vector_get(ctx, caps, 7);
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t6113 = objects[0];
  KLObject* t6114;
  {
    Vector* caps_125 = shen_vector(ctx, 9);
    shen_vector_set(ctx, caps_125, 0, t6105);
    shen_vector_set(ctx, caps_125, 1, t6106);
    shen_vector_set(ctx, caps_125, 2, t6107);
    shen_vector_set(ctx, caps_125, 3, t6108);
    shen_vector_set(ctx, caps_125, 4, t6109);
    shen_vector_set(ctx, caps_125, 5, t6113);
    shen_vector_set(ctx, caps_125, 6, t6110);
    shen_vector_set(ctx, caps_125, 7, t6111);
    shen_vector_set(ctx, caps_125, 8, t6112);
    t6114 = shen_native_closure(ctx, 1, &lambda_125, caps_125);
  }
    return t6114;
  }
}

static KLObject* lambda_133 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  KLObject* t6223 = shen_vector_get(ctx, caps, 0);
  KLObject* t6224 = shen_vector_get(ctx, caps, 1);
  KLObject* t6225 = shen_vector_get(ctx, caps, 2);
  KLObject* t6226 = shen_vector_get(ctx, caps, 3);
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t6227 = objects[0];
  KLObject* t6229 = shen_tl(ctx, t6223);
  KLObject* t6233;
  {
    Vector* a6233 = shen_vector(ctx, 1);
    shen_vector_set(ctx, a6233, 0, t6225);
    t6233 = shen_apply(ctx, t6224, a6233);
  }
  KLObject* t6232;
  {
    Vector* a6232 = shen_vector(ctx, 1);
    shen_vector_set(ctx, a6232, 0, t6226);
    t6232 = shen_apply(ctx, t6233, a6232);
  }
  KLObject* t6231;
  {
    Vector* a6231 = shen_vector(ctx, 1);
    shen_vector_set(ctx, a6231, 0, t6227);
    t6231 = shen_apply(ctx, t6232, a6231);
  }
  KLObject* t6230;
  {
    Vector* a6230 = shen_vector(ctx, 1);
    shen_vector_set(ctx, a6230, 0, t6229);
    t6230 = shen_tail_apply(ctx, t6231, a6230);
  }
    return t6230;
  }
}

static KLObject* lambda_132 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  KLObject* t6218 = shen_vector_get(ctx, caps, 0);
  KLObject* t6219 = shen_vector_get(ctx, caps, 1);
  KLObject* t6220 = shen_vector_get(ctx, caps, 2);
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t6221 = objects[0];
  KLObject* t6222;
  {
    Vector* caps_133 = shen_vector(ctx, 4);
    shen_vector_set(ctx, caps_133, 0, t6218);
    shen_vector_set(ctx, caps_133, 1, t6219);
    shen_vector_set(ctx, caps_133, 2, t6220);
    shen_vector_set(ctx, caps_133, 3, t6221);
    t6222 = shen_native_closure(ctx, 1, &lambda_133, caps_133);
  }
    return t6222;
  }
}

static KLObject* lambda_131 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  KLObject* t6214 = shen_vector_get(ctx, caps, 0);
  KLObject* t6215 = shen_vector_get(ctx, caps, 1);
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t6216 = objects[0];
  KLObject* t6217;
  {
    Vector* caps_132 = shen_vector(ctx, 3);
    shen_vector_set(ctx, caps_132, 0, t6214);
    shen_vector_set(ctx, caps_132, 1, t6215);
    shen_vector_set(ctx, caps_132, 2, t6216);
    t6217 = shen_native_closure(ctx, 1, &lambda_132, caps_132);
  }
    return t6217;
  }
}

static KLObject* lambda_135 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  KLObject* t6253 = shen_vector_get(ctx, caps, 0);
  KLObject* t6254 = shen_vector_get(ctx, caps, 1);
  KLObject* t6255 = shen_vector_get(ctx, caps, 2);
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t6256 = objects[0];
  KLObject* t6259;
  {
    Vector* a6259 = shen_vector(ctx, 1);
    shen_vector_set(ctx, a6259, 0, t6254);
    t6259 = shen_apply(ctx, t6253, a6259);
  }
  KLObject* t6258;
  {
    Vector* a6258 = shen_vector(ctx, 1);
    shen_vector_set(ctx, a6258, 0, t6255);
    t6258 = shen_apply(ctx, t6259, a6258);
  }
  KLObject* t6257;
  {
    Vector* a6257 = shen_vector(ctx, 1);
    shen_vector_set(ctx, a6257, 0, t6256);
    t6257 = shen_tail_apply(ctx, t6258, a6257);
  }
    return t6257;
  }
}

static KLObject* lambda_134 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  KLObject* t6249 = shen_vector_get(ctx, caps, 0);
  KLObject* t6250 = shen_vector_get(ctx, caps, 1);
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t6251 = objects[0];
  KLObject* t6252;
  {
    Vector* caps_135 = shen_vector(ctx, 3);
    shen_vector_set(ctx, caps_135, 0, t6249);
    shen_vector_set(ctx, caps_135, 1, t6250);
    shen_vector_set(ctx, caps_135, 2, t6251);
    t6252 = shen_native_closure(ctx, 1, &lambda_135, caps_135);
  }
    return t6252;
  }
}

static KLObject* lambda_136 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  KLObject* t6274 = shen_vector_get(ctx, caps, 0);
  KLObject* t6275 = shen_vector_get(ctx, caps, 1);
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t6276 = objects[0];
  KLObject* t6278;
  {
    Vector* a6278 = shen_vector(ctx, 1);
    shen_vector_set(ctx, a6278, 0, t6275);
    t6278 = shen_apply(ctx, t6274, a6278);
  }
  KLObject* t6277;
  {
    Vector* a6277 = shen_vector(ctx, 1);
    shen_vector_set(ctx, a6277, 0, t6276);
    t6277 = shen_tail_apply(ctx, t6278, a6277);
  }
    return t6277;
  }
}

static KLObject* lambda_137 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  KLObject* t6292 = shen_vector_get(ctx, caps, 0);
  KLObject* t6293 = shen_vector_get(ctx, caps, 1);
  (void)arguments;
  KLObject* t6294;
  {
    Vector* a6294 = shen_vector(ctx, 1);
    shen_vector_set(ctx, a6294, 0, t6293);
    t6294 = shen_tail_apply(ctx, t6292, a6294);
  }
    return t6294;
}

static KLObject* lambda_138 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  KLObject* t6326 = shen_vector_get(ctx, caps, 0);
  KLObject* t6327 = shen_vector_get(ctx, caps, 1);
  (void)arguments;
  KLObject* t6328;
  {
    Vector* a6328 = shen_vector(ctx, 1);
    shen_vector_set(ctx, a6328, 0, t6327);
    t6328 = shen_tail_apply(ctx, t6326, a6328);
  }
    return t6328;
}

static KLObject* lambda_139 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  KLObject* t6352 = shen_vector_get(ctx, caps, 0);
  KLObject* t6353 = shen_vector_get(ctx, caps, 1);
  KLObject* t6354 = shen_vector_get(ctx, caps, 2);
  (void)arguments;
  KLObject* t6356;
  {
    Vector* a6356 = shen_vector(ctx, 1);
    shen_vector_set(ctx, a6356, 0, t6353);
    t6356 = shen_apply(ctx, t6352, a6356);
  }
  KLObject* t6355;
  {
    Vector* a6355 = shen_vector(ctx, 1);
    shen_vector_set(ctx, a6355, 0, t6354);
    t6355 = shen_tail_apply(ctx, t6356, a6355);
  }
    return t6355;
}

static KLObject* lambda_140 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  KLObject* t6387 = shen_vector_get(ctx, caps, 0);
  KLObject* t6388 = shen_vector_get(ctx, caps, 1);
  KLObject* t6389 = shen_vector_get(ctx, caps, 2);
  KLObject* t6390 = shen_vector_get(ctx, caps, 3);
  (void)arguments;
  KLObject* t6393;
  {
    Vector* a6393 = shen_vector(ctx, 1);
    shen_vector_set(ctx, a6393, 0, t6388);
    t6393 = shen_apply(ctx, t6387, a6393);
  }
  KLObject* t6392;
  {
    Vector* a6392 = shen_vector(ctx, 1);
    shen_vector_set(ctx, a6392, 0, t6389);
    t6392 = shen_apply(ctx, t6393, a6392);
  }
  KLObject* t6391;
  {
    Vector* a6391 = shen_vector(ctx, 1);
    shen_vector_set(ctx, a6391, 0, t6390);
    t6391 = shen_tail_apply(ctx, t6392, a6391);
  }
    return t6391;
}

static KLObject* lambda_141 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  KLObject* t6431 = shen_vector_get(ctx, caps, 0);
  KLObject* t6432 = shen_vector_get(ctx, caps, 1);
  KLObject* t6433 = shen_vector_get(ctx, caps, 2);
  KLObject* t6434 = shen_vector_get(ctx, caps, 3);
  KLObject* t6435 = shen_vector_get(ctx, caps, 4);
  (void)arguments;
  KLObject* t6439;
  {
    Vector* a6439 = shen_vector(ctx, 1);
    shen_vector_set(ctx, a6439, 0, t6432);
    t6439 = shen_apply(ctx, t6431, a6439);
  }
  KLObject* t6438;
  {
    Vector* a6438 = shen_vector(ctx, 1);
    shen_vector_set(ctx, a6438, 0, t6433);
    t6438 = shen_apply(ctx, t6439, a6438);
  }
  KLObject* t6437;
  {
    Vector* a6437 = shen_vector(ctx, 1);
    shen_vector_set(ctx, a6437, 0, t6434);
    t6437 = shen_apply(ctx, t6438, a6437);
  }
  KLObject* t6436;
  {
    Vector* a6436 = shen_vector(ctx, 1);
    shen_vector_set(ctx, a6436, 0, t6435);
    t6436 = shen_tail_apply(ctx, t6437, a6436);
  }
    return t6436;
}

static KLObject* lambda_142 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  KLObject* t6512 = shen_vector_get(ctx, caps, 0);
  (void)arguments;
  KLObject* t6513 = shen_apply_direct(ctx, "shen.incinfs", 0, NULL);
  KLObject* t6514;
  {
    KLObject* a6514[] = {t6512};
    t6514 = shen_tail_apply_direct(ctx, "thaw", 1, a6514);
  }
    return t6514;
}

static KLObject* lambda_148 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  KLObject* t6613 = shen_vector_get(ctx, caps, 0);
  KLObject* t6614 = shen_vector_get(ctx, caps, 1);
  KLObject* t6615 = shen_vector_get(ctx, caps, 2);
  KLObject* t6616 = shen_vector_get(ctx, caps, 3);
  KLObject* t6617 = shen_vector_get(ctx, caps, 4);
  KLObject* t6618 = shen_vector_get(ctx, caps, 5);
  (void)arguments;
  KLObject* t6619;
  {
    KLObject* a6619[] = {t6613, t6614, t6615, t6616, t6617, t6618};
    t6619 = shen_tail_apply_direct(ctx, "shen.p-hyps", 6, a6619);
  }
    return t6619;
}

static KLObject* lambda_147 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  KLObject* t6598 = shen_vector_get(ctx, caps, 0);
  KLObject* t6599 = shen_vector_get(ctx, caps, 1);
  KLObject* t6600 = shen_vector_get(ctx, caps, 2);
  KLObject* t6601 = shen_vector_get(ctx, caps, 3);
  KLObject* t6602 = shen_vector_get(ctx, caps, 4);
  KLObject* t6603 = shen_vector_get(ctx, caps, 5);
  KLObject* t6604 = shen_vector_get(ctx, caps, 6);
  (void)arguments;
  KLObject* t6608 = shen_string(ctx, ":");
  KLObject* t6607;
  {
    KLObject* a6607[] = {t6608};
    t6607 = shen_apply_direct(ctx, "intern", 1, a6607);
  }
  KLObject* t6612;
  {
    Vector* caps_148 = shen_vector(ctx, 6);
    shen_vector_set(ctx, caps_148, 0, t6602);
    shen_vector_set(ctx, caps_148, 1, t6603);
    shen_vector_set(ctx, caps_148, 2, t6599);
    shen_vector_set(ctx, caps_148, 3, t6600);
    shen_vector_set(ctx, caps_148, 4, t6601);
    shen_vector_set(ctx, caps_148, 5, t6604);
    t6612 = shen_native_closure(ctx, 0, &lambda_148, caps_148);
  }
  KLObject* t6605;
  {
    KLObject* a6605[] = {t6598, t6607, t6599, t6600, t6601, t6612};
    t6605 = shen_tail_apply_direct(ctx, "bind", 6, a6605);
  }
    return t6605;
}

static KLObject* lambda_146 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  KLObject* t6581 = shen_vector_get(ctx, caps, 0);
  KLObject* t6582 = shen_vector_get(ctx, caps, 1);
  KLObject* t6583 = shen_vector_get(ctx, caps, 2);
  KLObject* t6584 = shen_vector_get(ctx, caps, 3);
  KLObject* t6585 = shen_vector_get(ctx, caps, 4);
  KLObject* t6586 = shen_vector_get(ctx, caps, 5);
  KLObject* t6587 = shen_vector_get(ctx, caps, 6);
  KLObject* t6588 = shen_vector_get(ctx, caps, 7);
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t6589 = objects[0];
  KLObject* t6590 = shen_apply_direct(ctx, "shen.incinfs", 0, NULL);
  KLObject* t6597;
  {
    Vector* caps_147 = shen_vector(ctx, 7);
    shen_vector_set(ctx, caps_147, 0, t6586);
    shen_vector_set(ctx, caps_147, 1, t6583);
    shen_vector_set(ctx, caps_147, 2, t6584);
    shen_vector_set(ctx, caps_147, 3, t6585);
    shen_vector_set(ctx, caps_147, 4, t6587);
    shen_vector_set(ctx, caps_147, 5, t6589);
    shen_vector_set(ctx, caps_147, 6, t6588);
    t6597 = shen_native_closure(ctx, 0, &lambda_147, caps_147);
  }
  KLObject* t6591;
  {
    KLObject* a6591[] = {t6581, t6582, t6583, t6584, t6585, t6597};
    t6591 = shen_tail_apply_direct(ctx, "bind", 6, a6591);
  }
    return t6591;
  }
}

static KLObject* lambda_145 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  KLObject* t6571 = shen_vector_get(ctx, caps, 0);
  KLObject* t6572 = shen_vector_get(ctx, caps, 1);
  KLObject* t6573 = shen_vector_get(ctx, caps, 2);
  KLObject* t6574 = shen_vector_get(ctx, caps, 3);
  KLObject* t6575 = shen_vector_get(ctx, caps, 4);
  KLObject* t6576 = shen_vector_get(ctx, caps, 5);
  KLObject* t6577 = shen_vector_get(ctx, caps, 6);
  KLObject* t6578 = shen_vector_get(ctx, caps, 7);
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t6579 = objects[0];
  KLObject* t6580;
  {
    Vector* caps_146 = shen_vector(ctx, 8);
    shen_vector_set(ctx, caps_146, 0, t6571);
    shen_vector_set(ctx, caps_146, 1, t6572);
    shen_vector_set(ctx, caps_146, 2, t6573);
    shen_vector_set(ctx, caps_146, 3, t6574);
    shen_vector_set(ctx, caps_146, 4, t6575);
    shen_vector_set(ctx, caps_146, 5, t6576);
    shen_vector_set(ctx, caps_146, 6, t6577);
    shen_vector_set(ctx, caps_146, 7, t6578);
    t6580 = shen_native_closure(ctx, 1, &lambda_146, caps_146);
  }
    return t6580;
  }
}

static KLObject* lambda_144 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  KLObject* t6562 = shen_vector_get(ctx, caps, 0);
  KLObject* t6563 = shen_vector_get(ctx, caps, 1);
  KLObject* t6564 = shen_vector_get(ctx, caps, 2);
  KLObject* t6565 = shen_vector_get(ctx, caps, 3);
  KLObject* t6566 = shen_vector_get(ctx, caps, 4);
  KLObject* t6567 = shen_vector_get(ctx, caps, 5);
  KLObject* t6568 = shen_vector_get(ctx, caps, 6);
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t6569 = objects[0];
  KLObject* t6570;
  {
    Vector* caps_145 = shen_vector(ctx, 8);
    shen_vector_set(ctx, caps_145, 0, t6562);
    shen_vector_set(ctx, caps_145, 1, t6563);
    shen_vector_set(ctx, caps_145, 2, t6564);
    shen_vector_set(ctx, caps_145, 3, t6565);
    shen_vector_set(ctx, caps_145, 4, t6566);
    shen_vector_set(ctx, caps_145, 5, t6569);
    shen_vector_set(ctx, caps_145, 6, t6567);
    shen_vector_set(ctx, caps_145, 7, t6568);
    t6570 = shen_native_closure(ctx, 1, &lambda_145, caps_145);
  }
    return t6570;
  }
}

static KLObject* lambda_143 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  KLObject* t6554 = shen_vector_get(ctx, caps, 0);
  KLObject* t6555 = shen_vector_get(ctx, caps, 1);
  KLObject* t6556 = shen_vector_get(ctx, caps, 2);
  KLObject* t6557 = shen_vector_get(ctx, caps, 3);
  KLObject* t6558 = shen_vector_get(ctx, caps, 4);
  KLObject* t6559 = shen_vector_get(ctx, caps, 5);
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t6560 = objects[0];
  KLObject* t6561;
  {
    Vector* caps_144 = shen_vector(ctx, 7);
    shen_vector_set(ctx, caps_144, 0, t6560);
    shen_vector_set(ctx, caps_144, 1, t6554);
    shen_vector_set(ctx, caps_144, 2, t6555);
    shen_vector_set(ctx, caps_144, 3, t6556);
    shen_vector_set(ctx, caps_144, 4, t6557);
    shen_vector_set(ctx, caps_144, 5, t6558);
    shen_vector_set(ctx, caps_144, 6, t6559);
    t6561 = shen_native_closure(ctx, 1, &lambda_144, caps_144);
  }
    return t6561;
  }
}

static KLObject* lambda_151 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  KLObject* t6643 = shen_vector_get(ctx, caps, 0);
  KLObject* t6644 = shen_vector_get(ctx, caps, 1);
  KLObject* t6645 = shen_vector_get(ctx, caps, 2);
  KLObject* t6646 = shen_vector_get(ctx, caps, 3);
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t6647 = objects[0];
  KLObject* t6649 = shen_tl(ctx, t6643);
  KLObject* t6653;
  {
    Vector* a6653 = shen_vector(ctx, 1);
    shen_vector_set(ctx, a6653, 0, t6645);
    t6653 = shen_apply(ctx, t6644, a6653);
  }
  KLObject* t6652;
  {
    Vector* a6652 = shen_vector(ctx, 1);
    shen_vector_set(ctx, a6652, 0, t6646);
    t6652 = shen_apply(ctx, t6653, a6652);
  }
  KLObject* t6651;
  {
    Vector* a6651 = shen_vector(ctx, 1);
    shen_vector_set(ctx, a6651, 0, t6647);
    t6651 = shen_apply(ctx, t6652, a6651);
  }
  KLObject* t6650;
  {
    Vector* a6650 = shen_vector(ctx, 1);
    shen_vector_set(ctx, a6650, 0, t6649);
    t6650 = shen_tail_apply(ctx, t6651, a6650);
  }
    return t6650;
  }
}

static KLObject* lambda_150 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  KLObject* t6638 = shen_vector_get(ctx, caps, 0);
  KLObject* t6639 = shen_vector_get(ctx, caps, 1);
  KLObject* t6640 = shen_vector_get(ctx, caps, 2);
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t6641 = objects[0];
  KLObject* t6642;
  {
    Vector* caps_151 = shen_vector(ctx, 4);
    shen_vector_set(ctx, caps_151, 0, t6638);
    shen_vector_set(ctx, caps_151, 1, t6639);
    shen_vector_set(ctx, caps_151, 2, t6640);
    shen_vector_set(ctx, caps_151, 3, t6641);
    t6642 = shen_native_closure(ctx, 1, &lambda_151, caps_151);
  }
    return t6642;
  }
}

static KLObject* lambda_149 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  KLObject* t6634 = shen_vector_get(ctx, caps, 0);
  KLObject* t6635 = shen_vector_get(ctx, caps, 1);
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t6636 = objects[0];
  KLObject* t6637;
  {
    Vector* caps_150 = shen_vector(ctx, 3);
    shen_vector_set(ctx, caps_150, 0, t6634);
    shen_vector_set(ctx, caps_150, 1, t6635);
    shen_vector_set(ctx, caps_150, 2, t6636);
    t6637 = shen_native_closure(ctx, 1, &lambda_150, caps_150);
  }
    return t6637;
  }
}

static KLObject* lambda_153 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  KLObject* t6673 = shen_vector_get(ctx, caps, 0);
  KLObject* t6674 = shen_vector_get(ctx, caps, 1);
  KLObject* t6675 = shen_vector_get(ctx, caps, 2);
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t6676 = objects[0];
  KLObject* t6679;
  {
    Vector* a6679 = shen_vector(ctx, 1);
    shen_vector_set(ctx, a6679, 0, t6674);
    t6679 = shen_apply(ctx, t6673, a6679);
  }
  KLObject* t6678;
  {
    Vector* a6678 = shen_vector(ctx, 1);
    shen_vector_set(ctx, a6678, 0, t6675);
    t6678 = shen_apply(ctx, t6679, a6678);
  }
  KLObject* t6677;
  {
    Vector* a6677 = shen_vector(ctx, 1);
    shen_vector_set(ctx, a6677, 0, t6676);
    t6677 = shen_tail_apply(ctx, t6678, a6677);
  }
    return t6677;
  }
}

static KLObject* lambda_152 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  KLObject* t6669 = shen_vector_get(ctx, caps, 0);
  KLObject* t6670 = shen_vector_get(ctx, caps, 1);
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t6671 = objects[0];
  KLObject* t6672;
  {
    Vector* caps_153 = shen_vector(ctx, 3);
    shen_vector_set(ctx, caps_153, 0, t6669);
    shen_vector_set(ctx, caps_153, 1, t6670);
    shen_vector_set(ctx, caps_153, 2, t6671);
    t6672 = shen_native_closure(ctx, 1, &lambda_153, caps_153);
  }
    return t6672;
  }
}

static KLObject* lambda_154 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  KLObject* t6694 = shen_vector_get(ctx, caps, 0);
  KLObject* t6695 = shen_vector_get(ctx, caps, 1);
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t6696 = objects[0];
  KLObject* t6698;
  {
    Vector* a6698 = shen_vector(ctx, 1);
    shen_vector_set(ctx, a6698, 0, t6695);
    t6698 = shen_apply(ctx, t6694, a6698);
  }
  KLObject* t6697;
  {
    Vector* a6697 = shen_vector(ctx, 1);
    shen_vector_set(ctx, a6697, 0, t6696);
    t6697 = shen_tail_apply(ctx, t6698, a6697);
  }
    return t6697;
  }
}

static KLObject* lambda_155 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  KLObject* t6712 = shen_vector_get(ctx, caps, 0);
  KLObject* t6713 = shen_vector_get(ctx, caps, 1);
  (void)arguments;
  KLObject* t6714;
  {
    Vector* a6714 = shen_vector(ctx, 1);
    shen_vector_set(ctx, a6714, 0, t6713);
    t6714 = shen_tail_apply(ctx, t6712, a6714);
  }
    return t6714;
}

static KLObject* lambda_156 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  KLObject* t6746 = shen_vector_get(ctx, caps, 0);
  KLObject* t6747 = shen_vector_get(ctx, caps, 1);
  (void)arguments;
  KLObject* t6748;
  {
    Vector* a6748 = shen_vector(ctx, 1);
    shen_vector_set(ctx, a6748, 0, t6747);
    t6748 = shen_tail_apply(ctx, t6746, a6748);
  }
    return t6748;
}

static KLObject* lambda_157 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  KLObject* t6772 = shen_vector_get(ctx, caps, 0);
  KLObject* t6773 = shen_vector_get(ctx, caps, 1);
  KLObject* t6774 = shen_vector_get(ctx, caps, 2);
  (void)arguments;
  KLObject* t6776;
  {
    Vector* a6776 = shen_vector(ctx, 1);
    shen_vector_set(ctx, a6776, 0, t6773);
    t6776 = shen_apply(ctx, t6772, a6776);
  }
  KLObject* t6775;
  {
    Vector* a6775 = shen_vector(ctx, 1);
    shen_vector_set(ctx, a6775, 0, t6774);
    t6775 = shen_tail_apply(ctx, t6776, a6775);
  }
    return t6775;
}

static KLObject* lambda_158 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  KLObject* t6807 = shen_vector_get(ctx, caps, 0);
  KLObject* t6808 = shen_vector_get(ctx, caps, 1);
  KLObject* t6809 = shen_vector_get(ctx, caps, 2);
  KLObject* t6810 = shen_vector_get(ctx, caps, 3);
  (void)arguments;
  KLObject* t6813;
  {
    Vector* a6813 = shen_vector(ctx, 1);
    shen_vector_set(ctx, a6813, 0, t6808);
    t6813 = shen_apply(ctx, t6807, a6813);
  }
  KLObject* t6812;
  {
    Vector* a6812 = shen_vector(ctx, 1);
    shen_vector_set(ctx, a6812, 0, t6809);
    t6812 = shen_apply(ctx, t6813, a6812);
  }
  KLObject* t6811;
  {
    Vector* a6811 = shen_vector(ctx, 1);
    shen_vector_set(ctx, a6811, 0, t6810);
    t6811 = shen_tail_apply(ctx, t6812, a6811);
  }
    return t6811;
}

static KLObject* lambda_159 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  KLObject* t6851 = shen_vector_get(ctx, caps, 0);
  KLObject* t6852 = shen_vector_get(ctx, caps, 1);
  KLObject* t6853 = shen_vector_get(ctx, caps, 2);
  KLObject* t6854 = shen_vector_get(ctx, caps, 3);
  KLObject* t6855 = shen_vector_get(ctx, caps, 4);
  (void)arguments;
  KLObject* t6859;
  {
    Vector* a6859 = shen_vector(ctx, 1);
    shen_vector_set(ctx, a6859, 0, t6852);
    t6859 = shen_apply(ctx, t6851, a6859);
  }
  KLObject* t6858;
  {
    Vector* a6858 = shen_vector(ctx, 1);
    shen_vector_set(ctx, a6858, 0, t6853);
    t6858 = shen_apply(ctx, t6859, a6858);
  }
  KLObject* t6857;
  {
    Vector* a6857 = shen_vector(ctx, 1);
    shen_vector_set(ctx, a6857, 0, t6854);
    t6857 = shen_apply(ctx, t6858, a6857);
  }
  KLObject* t6856;
  {
    Vector* a6856 = shen_vector(ctx, 1);
    shen_vector_set(ctx, a6856, 0, t6855);
    t6856 = shen_tail_apply(ctx, t6857, a6856);
  }
    return t6856;
}

static KLObject* lambda_163 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  KLObject* t6978 = shen_vector_get(ctx, caps, 0);
  KLObject* t6979 = shen_vector_get(ctx, caps, 1);
  KLObject* t6980 = shen_vector_get(ctx, caps, 2);
  KLObject* t6981 = shen_vector_get(ctx, caps, 3);
  KLObject* t6982 = shen_vector_get(ctx, caps, 4);
  KLObject* t6983 = shen_vector_get(ctx, caps, 5);
  KLObject* t6984 = shen_vector_get(ctx, caps, 6);
  KLObject* t6985 = shen_vector_get(ctx, caps, 7);
  (void)arguments;
  KLObject* t6991 = shen_string(ctx, ":");
  KLObject* t6990;
  {
    KLObject* a6990[] = {t6991};
    t6990 = shen_apply_direct(ctx, "intern", 1, a6990);
  }
  KLObject* t6992 = shen_intern(ctx, "verified");
  KLObject* t6993 = shen_empty_list(ctx);
  KLObject* t6994 = shen_cons(ctx, t6992, t6993);
  KLObject* t6995 = shen_cons(ctx, t6990, t6994);
  KLObject* t6996 = shen_cons(ctx, t6980, t6995);
  KLObject* t6998 = shen_cons(ctx, t6996, t6981);
  KLObject* t6986;
  {
    KLObject* a6986[] = {t6978, t6979, t6998, t6982, t6983, t6984, t6985};
    t6986 = shen_tail_apply_direct(ctx, "shen.t*-correct", 7, a6986);
  }
    return t6986;
}

static KLObject* lambda_162 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  KLObject* t6965 = shen_vector_get(ctx, caps, 0);
  KLObject* t6966 = shen_vector_get(ctx, caps, 1);
  KLObject* t6967 = shen_vector_get(ctx, caps, 2);
  KLObject* t6968 = shen_vector_get(ctx, caps, 3);
  KLObject* t6969 = shen_vector_get(ctx, caps, 4);
  KLObject* t6970 = shen_vector_get(ctx, caps, 5);
  KLObject* t6971 = shen_vector_get(ctx, caps, 6);
  KLObject* t6972 = shen_vector_get(ctx, caps, 7);
  (void)arguments;
  KLObject* t6977;
  {
    Vector* caps_163 = shen_vector(ctx, 8);
    shen_vector_set(ctx, caps_163, 0, t6968);
    shen_vector_set(ctx, caps_163, 1, t6969);
    shen_vector_set(ctx, caps_163, 2, t6970);
    shen_vector_set(ctx, caps_163, 3, t6971);
    shen_vector_set(ctx, caps_163, 4, t6965);
    shen_vector_set(ctx, caps_163, 5, t6966);
    shen_vector_set(ctx, caps_163, 6, t6967);
    shen_vector_set(ctx, caps_163, 7, t6972);
    t6977 = shen_native_closure(ctx, 0, &lambda_163, caps_163);
  }
  KLObject* t6973;
  {
    KLObject* a6973[] = {t6965, t6966, t6967, t6977};
    t6973 = shen_tail_apply_direct(ctx, "shen.cut", 4, a6973);
  }
    return t6973;
}

static KLObject* lambda_161 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  KLObject* t6949 = shen_vector_get(ctx, caps, 0);
  KLObject* t6950 = shen_vector_get(ctx, caps, 1);
  KLObject* t6951 = shen_vector_get(ctx, caps, 2);
  KLObject* t6952 = shen_vector_get(ctx, caps, 3);
  KLObject* t6953 = shen_vector_get(ctx, caps, 4);
  KLObject* t6954 = shen_vector_get(ctx, caps, 5);
  KLObject* t6955 = shen_vector_get(ctx, caps, 6);
  KLObject* t6956 = shen_vector_get(ctx, caps, 7);
  (void)arguments;
  KLObject* t6959 = shen_intern(ctx, "boolean");
  KLObject* t6964;
  {
    Vector* caps_162 = shen_vector(ctx, 8);
    shen_vector_set(ctx, caps_162, 0, t6951);
    shen_vector_set(ctx, caps_162, 1, t6952);
    shen_vector_set(ctx, caps_162, 2, t6953);
    shen_vector_set(ctx, caps_162, 3, t6954);
    shen_vector_set(ctx, caps_162, 4, t6955);
    shen_vector_set(ctx, caps_162, 5, t6949);
    shen_vector_set(ctx, caps_162, 6, t6950);
    shen_vector_set(ctx, caps_162, 7, t6956);
    t6964 = shen_native_closure(ctx, 0, &lambda_162, caps_162);
  }
  KLObject* t6957;
  {
    KLObject* a6957[] = {t6949, t6959, t6950, t6951, t6952, t6953, t6964};
    t6957 = shen_tail_apply_direct(ctx, "shen.system-S-h", 7, a6957);
  }
    return t6957;
}

static KLObject* lambda_160 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  KLObject* t6932 = shen_vector_get(ctx, caps, 0);
  KLObject* t6933 = shen_vector_get(ctx, caps, 1);
  KLObject* t6934 = shen_vector_get(ctx, caps, 2);
  KLObject* t6935 = shen_vector_get(ctx, caps, 3);
  KLObject* t6936 = shen_vector_get(ctx, caps, 4);
  KLObject* t6937 = shen_vector_get(ctx, caps, 5);
  KLObject* t6938 = shen_vector_get(ctx, caps, 6);
  KLObject* t6939 = shen_vector_get(ctx, caps, 7);
  KLObject* t6940 = shen_vector_get(ctx, caps, 8);
  (void)arguments;
  KLObject* t6943;
  {
    KLObject* a6943[] = {t6933};
    t6943 = shen_apply_direct(ctx, "shen.curry", 1, a6943);
  }
  KLObject* t6948;
  {
    Vector* caps_161 = shen_vector(ctx, 8);
    shen_vector_set(ctx, caps_161, 0, t6932);
    shen_vector_set(ctx, caps_161, 1, t6937);
    shen_vector_set(ctx, caps_161, 2, t6934);
    shen_vector_set(ctx, caps_161, 3, t6935);
    shen_vector_set(ctx, caps_161, 4, t6936);
    shen_vector_set(ctx, caps_161, 5, t6938);
    shen_vector_set(ctx, caps_161, 6, t6939);
    shen_vector_set(ctx, caps_161, 7, t6940);
    t6948 = shen_native_closure(ctx, 0, &lambda_161, caps_161);
  }
  KLObject* t6941;
  {
    KLObject* a6941[] = {t6932, t6943, t6934, t6935, t6936, t6948};
    t6941 = shen_tail_apply_direct(ctx, "bind", 6, a6941);
  }
    return t6941;
}

static KLObject* lambda_164 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  KLObject* t7130 = shen_vector_get(ctx, caps, 0);
  KLObject* t7131 = shen_vector_get(ctx, caps, 1);
  KLObject* t7132 = shen_vector_get(ctx, caps, 2);
  KLObject* t7133 = shen_vector_get(ctx, caps, 3);
  KLObject* t7134 = shen_vector_get(ctx, caps, 4);
  KLObject* t7135 = shen_vector_get(ctx, caps, 5);
  KLObject* t7136 = shen_vector_get(ctx, caps, 6);
  KLObject* t7137 = shen_vector_get(ctx, caps, 7);
  (void)arguments;
  KLObject* t7138;
  {
    KLObject* a7138[] = {t7130, t7131, t7132, t7133, t7134, t7135, t7136, t7137};
    t7138 = shen_tail_apply_direct(ctx, "shen.t*-integrity", 8, a7138);
  }
    return t7138;
}

static KLObject* native_kl_shen_2etypecheck_0 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t0 = objects[0];
    KLObject* t1 = objects[1];
  tail_start_kl_shen_2etypecheck_0: ;
  KLObject* t2;
  {
    KLObject* a2[] = {t1};
    t2 = shen_apply_direct(ctx, "shen.extract-vars", 1, a2);
  }
  KLObject* t4;
  {
    KLObject* a4[] = {t1};
    t4 = shen_apply_direct(ctx, "shen.rectify-type", 1, a4);
  }
  KLObject* t6;
  {
    KLObject* a6[] = {t0};
    t6 = shen_apply_direct(ctx, "shen.curry", 1, a6);
  }
  KLObject* t12;
  {
    Vector* caps_0 = shen_vector(ctx, 3);
    shen_vector_set(ctx, caps_0, 0, t2);
    shen_vector_set(ctx, caps_0, 1, t4);
    shen_vector_set(ctx, caps_0, 2, t6);
    t12 = shen_native_closure(ctx, 1, &lambda_0, caps_0);
  }
  KLObject* t84 = shen_apply_direct(ctx, "shen.prolog-vector", 0, NULL);
  KLObject* t11;
  {
    Vector* a11 = shen_vector(ctx, 1);
    shen_vector_set(ctx, a11, 0, t84);
    t11 = shen_apply(ctx, t12, a11);
  }
  KLObject* t86 = shen_true(ctx);
  KLObject* t88 = shen_number_l(ctx, 0);
  KLObject* t90 = shen_number_l(ctx, 0);
  KLObject* t89;
  {
    KLObject* a89[] = {t90};
    t89 = shen_apply_direct(ctx, "vector", 1, a89);
  }
  KLObject* t87;
  {
    KLObject* a87[] = {t88, t89};
    t87 = shen_apply_direct(ctx, "@v", 2, a87);
  }
  KLObject* t85;
  {
    KLObject* a85[] = {t86, t87};
    t85 = shen_apply_direct(ctx, "@v", 2, a85);
  }
  KLObject* t10;
  {
    Vector* a10 = shen_vector(ctx, 1);
    shen_vector_set(ctx, a10, 0, t85);
    t10 = shen_apply(ctx, t11, a10);
  }
  KLObject* t91 = shen_number_l(ctx, 0);
  KLObject* t9;
  {
    Vector* a9 = shen_vector(ctx, 1);
    shen_vector_set(ctx, a9, 0, t91);
    t9 = shen_apply(ctx, t10, a9);
  }
  KLObject* t92;
  {
    Vector* caps_6 = shen_vector(ctx, 0);
    t92 = shen_native_closure(ctx, 0, &lambda_6, caps_6);
  }
  KLObject* t8;
  {
    Vector* a8 = shen_vector(ctx, 1);
    shen_vector_set(ctx, a8, 0, t92);
    t8 = shen_tail_apply(ctx, t9, a8);
  }
    return t8;
  }
}

static KLObject* native_kl_shen_2einsert_2dprolog_2dvariables_1 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t94 = objects[0];
    KLObject* t95 = objects[1];
    KLObject* t96 = objects[2];
    KLObject* t97 = objects[3];
    KLObject* t98 = objects[4];
    KLObject* t99 = objects[5];
    KLObject* t100 = objects[6];
  tail_start_kl_shen_2einsert_2dprolog_2dvariables_1: ;
  KLObject* t102;
  {
    KLObject* a102[] = {t98};
    t102 = shen_apply_direct(ctx, "shen.unlocked?", 1, a102);
  }
  KLObject* t101;
  if (!shen_is_boolean(ctx, t102))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t102)) {
  KLObject* t104;
  {
    KLObject* a104[] = {t94, t97};
    t104 = shen_apply_direct(ctx, "shen.lazyderef", 2, a104);
  }
  KLObject* t109 = shen_empty_list(ctx);
  KLObject* t110 = shen_eq(ctx, t104, t109);
  KLObject* t107;
  if (!shen_is_boolean(ctx, t110))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t110)) {
  KLObject* t111 = shen_apply_direct(ctx, "shen.incinfs", 0, NULL);
  KLObject* t112;
  {
    KLObject* a112[] = {t95, t96, t97, t98, t99, t100};
    t112 = shen_apply_direct(ctx, "is!", 6, a112);
  }
    t107 = t112;
  } else {
  KLObject* t119 = shen_false(ctx);
    t107 = t119;
  }
    t101 = t107;
  } else {
  KLObject* t120 = shen_false(ctx);
    t101 = t120;
  }
  KLObject* t123 = shen_false(ctx);
  KLObject* t124 = shen_eq(ctx, t101, t123);
  KLObject* t121;
  if (!shen_is_boolean(ctx, t124))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t124)) {
  KLObject* t126;
  {
    KLObject* a126[] = {t98};
    t126 = shen_apply_direct(ctx, "shen.unlocked?", 1, a126);
  }
  KLObject* t125;
  if (!shen_is_boolean(ctx, t126))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t126)) {
  KLObject* t128;
  {
    KLObject* a128[] = {t94, t97};
    t128 = shen_apply_direct(ctx, "shen.lazyderef", 2, a128);
  }
  KLObject* t133 = shen_cons_p(ctx, t128);
  KLObject* t131;
  if (!shen_is_boolean(ctx, t133))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t133)) {
  KLObject* t135 = shen_hd(ctx, t128);
  KLObject* t137 = shen_tl(ctx, t128);
  KLObject* t138;
  {
    KLObject* a138[] = {t97};
    t138 = shen_apply_direct(ctx, "shen.newpv", 1, a138);
  }
  KLObject* t142 = shen_apply_direct(ctx, "shen.incinfs", 0, NULL);
  KLObject* t146;
  {
    KLObject* a146[] = {t138, t97};
    t146 = shen_apply_direct(ctx, "shen.deref", 2, a146);
  }
  KLObject* t145;
  {
    KLObject* a145[] = {t146, t135, t95};
    t145 = shen_apply_direct(ctx, "subst", 3, a145);
  }
  KLObject* t143;
  {
    KLObject* a143[] = {t137, t145, t96, t97, t98, t99, t100};
    t143 = shen_apply_direct(ctx, "shen.insert-prolog-variables", 7, a143);
  }
  KLObject* t140;
  {
    KLObject* a140[] = {t97, t143};
    t140 = shen_tail_apply_direct(ctx, "shen.gc", 2, a140);
  }
    t131 = t140;
  } else {
  KLObject* t156 = shen_false(ctx);
    t131 = t156;
  }
    t125 = t131;
  } else {
  KLObject* t157 = shen_false(ctx);
    t125 = t157;
  }
    t121 = t125;
  } else {
    t121 = t101;
  }
    return t121;
  }
}

static KLObject* native_kl_shen_2etoplevel_2dforms_2 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t159 = objects[0];
    KLObject* t160 = objects[1];
    KLObject* t161 = objects[2];
    KLObject* t162 = objects[3];
    KLObject* t163 = objects[4];
    KLObject* t164 = objects[5];
  tail_start_kl_shen_2etoplevel_2dforms_2: ;
  KLObject* t166 = shen_number_l(ctx, 1);
  KLObject* t167 = shen_add(ctx, t163, t166);
  KLObject* t169;
  {
    KLObject* a169[] = {t162};
    t169 = shen_apply_direct(ctx, "shen.unlocked?", 1, a169);
  }
  KLObject* t168;
  if (!shen_is_boolean(ctx, t169))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t169)) {
  KLObject* t171;
  {
    KLObject* a171[] = {t159, t161};
    t171 = shen_apply_direct(ctx, "shen.lazyderef", 2, a171);
  }
  KLObject* t176 = shen_cons_p(ctx, t171);
  KLObject* t174;
  if (!shen_is_boolean(ctx, t176))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t176)) {
  KLObject* t179 = shen_hd(ctx, t171);
  KLObject* t177;
  {
    KLObject* a177[] = {t179, t161};
    t177 = shen_apply_direct(ctx, "shen.lazyderef", 2, a177);
  }
  KLObject* t183 = shen_intern(ctx, "define");
  KLObject* t184 = shen_eq(ctx, t177, t183);
  KLObject* t181;
  if (!shen_is_boolean(ctx, t184))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t184)) {
  KLObject* t187 = shen_tl(ctx, t171);
  KLObject* t185;
  {
    KLObject* a185[] = {t187, t161};
    t185 = shen_apply_direct(ctx, "shen.lazyderef", 2, a185);
  }
  KLObject* t191 = shen_cons_p(ctx, t185);
  KLObject* t189;
  if (!shen_is_boolean(ctx, t191))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t191)) {
  KLObject* t193 = shen_hd(ctx, t185);
  KLObject* t195 = shen_tl(ctx, t185);
  KLObject* t196 = shen_apply_direct(ctx, "shen.incinfs", 0, NULL);
  KLObject* t198 = shen_apply_direct(ctx, "shen.type-theory-enabled?", 0, NULL);
  KLObject* t202;
  {
    Vector* caps_7 = shen_vector(ctx, 7);
    shen_vector_set(ctx, caps_7, 0, t161);
    shen_vector_set(ctx, caps_7, 1, t162);
    shen_vector_set(ctx, caps_7, 2, t167);
    shen_vector_set(ctx, caps_7, 3, t193);
    shen_vector_set(ctx, caps_7, 4, t195);
    shen_vector_set(ctx, caps_7, 5, t160);
    shen_vector_set(ctx, caps_7, 6, t164);
    t202 = shen_native_closure(ctx, 0, &lambda_7, caps_7);
  }
  KLObject* t197;
  {
    KLObject* a197[] = {t198, t161, t162, t167, t202};
    t197 = shen_apply_direct(ctx, "when", 5, a197);
  }
    t189 = t197;
  } else {
  KLObject* t248 = shen_false(ctx);
    t189 = t248;
  }
    t181 = t189;
  } else {
  KLObject* t249 = shen_false(ctx);
    t181 = t249;
  }
    t174 = t181;
  } else {
  KLObject* t250 = shen_false(ctx);
    t174 = t250;
  }
    t168 = t174;
  } else {
  KLObject* t251 = shen_false(ctx);
    t168 = t251;
  }
  KLObject* t254 = shen_false(ctx);
  KLObject* t255 = shen_eq(ctx, t168, t254);
  KLObject* t252;
  if (!shen_is_boolean(ctx, t255))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t255)) {
  KLObject* t257;
  {
    KLObject* a257[] = {t162};
    t257 = shen_apply_direct(ctx, "shen.unlocked?", 1, a257);
  }
  KLObject* t256;
  if (!shen_is_boolean(ctx, t257))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t257)) {
  KLObject* t259 = shen_apply_direct(ctx, "shen.incinfs", 0, NULL);
  KLObject* t263 = shen_string(ctx, ":");
  KLObject* t262;
  {
    KLObject* a262[] = {t263};
    t262 = shen_apply_direct(ctx, "intern", 1, a262);
  }
  KLObject* t265 = shen_empty_list(ctx);
  KLObject* t266 = shen_cons(ctx, t160, t265);
  KLObject* t267 = shen_cons(ctx, t262, t266);
  KLObject* t268 = shen_cons(ctx, t159, t267);
  KLObject* t269 = shen_empty_list(ctx);
  KLObject* t260;
  {
    KLObject* a260[] = {t268, t269, t161, t162, t167, t164};
    t260 = shen_apply_direct(ctx, "shen.system-S", 6, a260);
  }
    t256 = t260;
  } else {
  KLObject* t274 = shen_false(ctx);
    t256 = t274;
  }
  KLObject* t277 = shen_false(ctx);
  KLObject* t278 = shen_eq(ctx, t256, t277);
  KLObject* t275;
  if (!shen_is_boolean(ctx, t278))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t278)) {
  KLObject* t279;
  {
    KLObject* a279[] = {t162, t167};
    t279 = shen_tail_apply_direct(ctx, "shen.unlock", 2, a279);
  }
    t275 = t279;
  } else {
    t275 = t256;
  }
    t252 = t275;
  } else {
    t252 = t168;
  }
    return t252;
  }
}

static KLObject* native_kl_shen_2esignal_2ddef_3 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t284 = objects[0];
    KLObject* t285 = objects[1];
    KLObject* t286 = objects[2];
    KLObject* t287 = objects[3];
    KLObject* t288 = objects[4];
    KLObject* t289 = objects[5];
  tail_start_kl_shen_2esignal_2ddef_3: ;
  KLObject* t291;
  {
    KLObject* a291[] = {t287};
    t291 = shen_apply_direct(ctx, "shen.unlocked?", 1, a291);
  }
  KLObject* t290;
  if (!shen_is_boolean(ctx, t291))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t291)) {
  KLObject* t293;
  {
    KLObject* a293[] = {t284, t286};
    t293 = shen_apply_direct(ctx, "shen.lazyderef", 2, a293);
  }
  KLObject* t298 = shen_false(ctx);
  KLObject* t299 = shen_eq(ctx, t293, t298);
  KLObject* t296;
  if (!shen_is_boolean(ctx, t299))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t299)) {
  KLObject* t300 = shen_apply_direct(ctx, "shen.incinfs", 0, NULL);
  KLObject* t301;
  {
    KLObject* a301[] = {t289};
    t301 = shen_apply_direct(ctx, "thaw", 1, a301);
  }
    t296 = t301;
  } else {
  KLObject* t303 = shen_false(ctx);
    t296 = t303;
  }
    t290 = t296;
  } else {
  KLObject* t304 = shen_false(ctx);
    t290 = t304;
  }
  KLObject* t307 = shen_false(ctx);
  KLObject* t308 = shen_eq(ctx, t290, t307);
  KLObject* t305;
  if (!shen_is_boolean(ctx, t308))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t308)) {
  KLObject* t310;
  {
    KLObject* a310[] = {t287};
    t310 = shen_apply_direct(ctx, "shen.unlocked?", 1, a310);
  }
  KLObject* t309;
  if (!shen_is_boolean(ctx, t310))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t310)) {
  KLObject* t312;
  {
    KLObject* a312[] = {t284, t286};
    t312 = shen_apply_direct(ctx, "shen.lazyderef", 2, a312);
  }
  KLObject* t317 = shen_true(ctx);
  KLObject* t318 = shen_eq(ctx, t312, t317);
  KLObject* t315;
  if (!shen_is_boolean(ctx, t318))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t318)) {
  KLObject* t319;
  {
    KLObject* a319[] = {t286};
    t319 = shen_apply_direct(ctx, "shen.newpv", 1, a319);
  }
  KLObject* t323 = shen_apply_direct(ctx, "shen.incinfs", 0, NULL);
  KLObject* t328 = shen_string(ctx, "\ntypechecking (fn ");
  KLObject* t330;
  {
    KLObject* a330[] = {t285, t286};
    t330 = shen_apply_direct(ctx, "shen.deref", 2, a330);
  }
  KLObject* t333 = shen_string(ctx, ")\n");
  KLObject* t334 = shen_intern(ctx, "shen.a");
  KLObject* t329;
  {
    KLObject* a329[] = {t330, t333, t334};
    t329 = shen_apply_direct(ctx, "shen.app", 3, a329);
  }
  KLObject* t327;
  {
    KLObject* a327[] = {t328, t329};
    t327 = shen_apply_direct(ctx, "cn", 2, a327);
  }
  KLObject* t335 = shen_apply_direct(ctx, "stoutput", 0, NULL);
  KLObject* t326;
  {
    KLObject* a326[] = {t327, t335};
    t326 = shen_apply_direct(ctx, "pr", 2, a326);
  }
  KLObject* t324;
  {
    KLObject* a324[] = {t319, t326, t286, t287, t288, t289};
    t324 = shen_apply_direct(ctx, "is", 6, a324);
  }
  KLObject* t321;
  {
    KLObject* a321[] = {t286, t324};
    t321 = shen_tail_apply_direct(ctx, "shen.gc", 2, a321);
  }
    t315 = t321;
  } else {
  KLObject* t340 = shen_false(ctx);
    t315 = t340;
  }
    t309 = t315;
  } else {
  KLObject* t341 = shen_false(ctx);
    t309 = t341;
  }
    t305 = t309;
  } else {
    t305 = t290;
  }
    return t305;
  }
}

static KLObject* native_kl_shen_2erectify_2dtype_4 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t343 = objects[0];
  tail_start_kl_shen_2erectify_2dtype_4: ;
  KLObject* t345;
  {
    KLObject* a345[] = {t343};
    t345 = shen_apply_direct(ctx, "shen.curry-type", 1, a345);
  }
  KLObject* t344;
  {
    KLObject* a344[] = {t345};
    t344 = shen_tail_apply_direct(ctx, "shen.demodulate", 1, a344);
  }
    return t344;
  }
}

static KLObject* native_kl_shen_2edemodulate_5 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t347 = objects[0];
  tail_start_kl_shen_2edemodulate_5: ;
  KLObject* t348;
  {
    Vector* tenv_0 = shen_vector(ctx, 1);
    shen_vector_set(ctx, tenv_0, 0, t347);
    t348 = shen_trap_error(ctx, trap_body_0, trap_handler_0, tenv_0);
  }
    return t348;
  }
}

static KLObject* native_kl_shen_2ecurry_2dtype_6 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t369 = objects[0];
  tail_start_kl_shen_2ecurry_2dtype_6: ;
  KLObject* t370;
  {
  KLObject* t373 = shen_cons_p(ctx, t369);
  KLObject* t371;
  if (!shen_is_boolean(ctx, t373))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t373)) {
    t371 = t373;
  } else {
  KLObject* t376 = shen_tl(ctx, t369);
  KLObject* t377 = shen_cons_p(ctx, t376);
  KLObject* t374;
  if (!shen_is_boolean(ctx, t377))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t377)) {
    t374 = t377;
  } else {
  KLObject* t379 = shen_intern(ctx, "-->");
  KLObject* t381 = shen_tl(ctx, t369);
  KLObject* t382 = shen_hd(ctx, t381);
  KLObject* t383 = shen_eq(ctx, t379, t382);
  KLObject* t378;
  if (!shen_is_boolean(ctx, t383))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t383)) {
    t378 = t383;
  } else {
  KLObject* t386 = shen_tl(ctx, t369);
  KLObject* t387 = shen_tl(ctx, t386);
  KLObject* t388 = shen_cons_p(ctx, t387);
  KLObject* t384;
  if (!shen_is_boolean(ctx, t388))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t388)) {
    t384 = t388;
  } else {
  KLObject* t391 = shen_tl(ctx, t369);
  KLObject* t392 = shen_tl(ctx, t391);
  KLObject* t393 = shen_tl(ctx, t392);
  KLObject* t394 = shen_cons_p(ctx, t393);
  KLObject* t389;
  if (!shen_is_boolean(ctx, t394))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t394)) {
    t389 = t394;
  } else {
  KLObject* t395 = shen_intern(ctx, "-->");
  KLObject* t397 = shen_tl(ctx, t369);
  KLObject* t398 = shen_tl(ctx, t397);
  KLObject* t399 = shen_tl(ctx, t398);
  KLObject* t400 = shen_hd(ctx, t399);
  KLObject* t401 = shen_eq(ctx, t395, t400);
    if (!shen_is_boolean(ctx, t401))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t389 = t401;
  }
    if (!shen_is_boolean(ctx, t389))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t384 = t389;
  }
    if (!shen_is_boolean(ctx, t384))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t378 = t384;
  }
    if (!shen_is_boolean(ctx, t378))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t374 = t378;
  }
    if (!shen_is_boolean(ctx, t374))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t371 = t374;
  }
    if (!shen_is_boolean(ctx, t371))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t371)) {
  KLObject* t403 = shen_hd(ctx, t369);
  KLObject* t404 = shen_intern(ctx, "-->");
  KLObject* t406 = shen_tl(ctx, t369);
  KLObject* t407 = shen_tl(ctx, t406);
  KLObject* t408 = shen_empty_list(ctx);
  KLObject* t409 = shen_cons(ctx, t407, t408);
  KLObject* t410 = shen_cons(ctx, t404, t409);
  KLObject* t411 = shen_cons(ctx, t403, t410);
  {
    KLObject* n412_0 = t411;
    t369 = n412_0;
    goto tail_start_kl_shen_2ecurry_2dtype_6;
  }
  KLObject* t412 = NULL;
      t370 = t412;
    } else {
  KLObject* t415 = shen_cons_p(ctx, t369);
  KLObject* t413;
  if (!shen_is_boolean(ctx, t415))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t415)) {
    t413 = t415;
  } else {
  KLObject* t418 = shen_hd(ctx, t369);
  KLObject* t419 = shen_cons_p(ctx, t418);
  KLObject* t416;
  if (!shen_is_boolean(ctx, t419))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t419)) {
    t416 = t419;
  } else {
  KLObject* t421 = shen_intern(ctx, "list");
  KLObject* t423 = shen_hd(ctx, t369);
  KLObject* t424 = shen_hd(ctx, t423);
  KLObject* t425 = shen_eq(ctx, t421, t424);
  KLObject* t420;
  if (!shen_is_boolean(ctx, t425))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t425)) {
    t420 = t425;
  } else {
  KLObject* t428 = shen_hd(ctx, t369);
  KLObject* t429 = shen_tl(ctx, t428);
  KLObject* t430 = shen_cons_p(ctx, t429);
  KLObject* t426;
  if (!shen_is_boolean(ctx, t430))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t430)) {
    t426 = t430;
  } else {
  KLObject* t432 = shen_empty_list(ctx);
  KLObject* t434 = shen_hd(ctx, t369);
  KLObject* t435 = shen_tl(ctx, t434);
  KLObject* t436 = shen_tl(ctx, t435);
  KLObject* t437 = shen_eq(ctx, t432, t436);
  KLObject* t431;
  if (!shen_is_boolean(ctx, t437))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t437)) {
    t431 = t437;
  } else {
  KLObject* t440 = shen_tl(ctx, t369);
  KLObject* t441 = shen_cons_p(ctx, t440);
  KLObject* t438;
  if (!shen_is_boolean(ctx, t441))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t441)) {
    t438 = t441;
  } else {
  KLObject* t443 = shen_intern(ctx, "==>");
  KLObject* t445 = shen_tl(ctx, t369);
  KLObject* t446 = shen_hd(ctx, t445);
  KLObject* t447 = shen_eq(ctx, t443, t446);
  KLObject* t442;
  if (!shen_is_boolean(ctx, t447))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t447)) {
    t442 = t447;
  } else {
  KLObject* t450 = shen_tl(ctx, t369);
  KLObject* t451 = shen_tl(ctx, t450);
  KLObject* t452 = shen_cons_p(ctx, t451);
  KLObject* t448;
  if (!shen_is_boolean(ctx, t452))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t452)) {
    t448 = t452;
  } else {
  KLObject* t453 = shen_empty_list(ctx);
  KLObject* t455 = shen_tl(ctx, t369);
  KLObject* t456 = shen_tl(ctx, t455);
  KLObject* t457 = shen_tl(ctx, t456);
  KLObject* t458 = shen_eq(ctx, t453, t457);
    if (!shen_is_boolean(ctx, t458))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t448 = t458;
  }
    if (!shen_is_boolean(ctx, t448))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t442 = t448;
  }
    if (!shen_is_boolean(ctx, t442))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t438 = t442;
  }
    if (!shen_is_boolean(ctx, t438))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t431 = t438;
  }
    if (!shen_is_boolean(ctx, t431))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t426 = t431;
  }
    if (!shen_is_boolean(ctx, t426))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t420 = t426;
  }
    if (!shen_is_boolean(ctx, t420))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t416 = t420;
  }
    if (!shen_is_boolean(ctx, t416))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t413 = t416;
  }
    if (!shen_is_boolean(ctx, t413))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t413)) {
  KLObject* t460 = shen_hd(ctx, t369);
  KLObject* t461 = shen_intern(ctx, "-->");
  KLObject* t462 = shen_intern(ctx, "str");
  KLObject* t464 = shen_hd(ctx, t369);
  KLObject* t466 = shen_tl(ctx, t369);
  KLObject* t467 = shen_tl(ctx, t466);
  KLObject* t468 = shen_cons(ctx, t464, t467);
  KLObject* t469 = shen_cons(ctx, t462, t468);
  KLObject* t470 = shen_empty_list(ctx);
  KLObject* t471 = shen_cons(ctx, t469, t470);
  KLObject* t472 = shen_cons(ctx, t461, t471);
  KLObject* t473 = shen_cons(ctx, t460, t472);
  {
    KLObject* n474_0 = t473;
    t369 = n474_0;
    goto tail_start_kl_shen_2ecurry_2dtype_6;
  }
  KLObject* t474 = NULL;
      t370 = t474;
    } else {
  KLObject* t477 = shen_cons_p(ctx, t369);
  KLObject* t475;
  if (!shen_is_boolean(ctx, t477))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t477)) {
    t475 = t477;
  } else {
  KLObject* t480 = shen_tl(ctx, t369);
  KLObject* t481 = shen_cons_p(ctx, t480);
  KLObject* t478;
  if (!shen_is_boolean(ctx, t481))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t481)) {
    t478 = t481;
  } else {
  KLObject* t483 = shen_intern(ctx, "*");
  KLObject* t485 = shen_tl(ctx, t369);
  KLObject* t486 = shen_hd(ctx, t485);
  KLObject* t487 = shen_eq(ctx, t483, t486);
  KLObject* t482;
  if (!shen_is_boolean(ctx, t487))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t487)) {
    t482 = t487;
  } else {
  KLObject* t490 = shen_tl(ctx, t369);
  KLObject* t491 = shen_tl(ctx, t490);
  KLObject* t492 = shen_cons_p(ctx, t491);
  KLObject* t488;
  if (!shen_is_boolean(ctx, t492))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t492)) {
    t488 = t492;
  } else {
  KLObject* t495 = shen_tl(ctx, t369);
  KLObject* t496 = shen_tl(ctx, t495);
  KLObject* t497 = shen_tl(ctx, t496);
  KLObject* t498 = shen_cons_p(ctx, t497);
  KLObject* t493;
  if (!shen_is_boolean(ctx, t498))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t498)) {
    t493 = t498;
  } else {
  KLObject* t499 = shen_intern(ctx, "*");
  KLObject* t501 = shen_tl(ctx, t369);
  KLObject* t502 = shen_tl(ctx, t501);
  KLObject* t503 = shen_tl(ctx, t502);
  KLObject* t504 = shen_hd(ctx, t503);
  KLObject* t505 = shen_eq(ctx, t499, t504);
    if (!shen_is_boolean(ctx, t505))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t493 = t505;
  }
    if (!shen_is_boolean(ctx, t493))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t488 = t493;
  }
    if (!shen_is_boolean(ctx, t488))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t482 = t488;
  }
    if (!shen_is_boolean(ctx, t482))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t478 = t482;
  }
    if (!shen_is_boolean(ctx, t478))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t475 = t478;
  }
    if (!shen_is_boolean(ctx, t475))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t475)) {
  KLObject* t507 = shen_hd(ctx, t369);
  KLObject* t508 = shen_intern(ctx, "*");
  KLObject* t510 = shen_tl(ctx, t369);
  KLObject* t511 = shen_tl(ctx, t510);
  KLObject* t512 = shen_empty_list(ctx);
  KLObject* t513 = shen_cons(ctx, t511, t512);
  KLObject* t514 = shen_cons(ctx, t508, t513);
  KLObject* t515 = shen_cons(ctx, t507, t514);
  {
    KLObject* n516_0 = t515;
    t369 = n516_0;
    goto tail_start_kl_shen_2ecurry_2dtype_6;
  }
  KLObject* t516 = NULL;
      t370 = t516;
    } else {
  KLObject* t518 = shen_cons_p(ctx, t369);
    if (!shen_is_boolean(ctx, t518))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t518)) {
  KLObject* t520;
  {
    Vector* caps_12 = shen_vector(ctx, 0);
    t520 = shen_native_closure(ctx, 1, &lambda_12, caps_12);
  }
  KLObject* t519;
  {
    KLObject* a519[] = {t520, t369};
    t519 = shen_tail_apply_direct(ctx, "map", 2, a519);
  }
      t370 = t519;
    } else {
  KLObject* t525 = shen_true(ctx);
    if (!shen_is_boolean(ctx, t525))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t525)) {
      t370 = t369;
    } else {
      shen_simple_error(ctx, "No true case found for cond");
      t370 = shen_empty_list(ctx);
    }
    }
    }
    }
    }
  }
    return t370;
  }
}

static KLObject* native_kl_shen_2ecurry_7 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t527 = objects[0];
  tail_start_kl_shen_2ecurry_7: ;
  KLObject* t528;
  {
  KLObject* t531 = shen_cons_p(ctx, t527);
  KLObject* t529;
  if (!shen_is_boolean(ctx, t531))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t531)) {
    t529 = t531;
  } else {
  KLObject* t533 = shen_intern(ctx, "define");
  KLObject* t535 = shen_hd(ctx, t527);
  KLObject* t536 = shen_eq(ctx, t533, t535);
  KLObject* t532;
  if (!shen_is_boolean(ctx, t536))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t536)) {
    t532 = t536;
  } else {
  KLObject* t538 = shen_tl(ctx, t527);
  KLObject* t539 = shen_cons_p(ctx, t538);
    if (!shen_is_boolean(ctx, t539))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t532 = t539;
  }
    if (!shen_is_boolean(ctx, t532))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t529 = t532;
  }
    if (!shen_is_boolean(ctx, t529))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t529)) {
      t528 = t527;
    } else {
  KLObject* t543 = shen_cons_p(ctx, t527);
  KLObject* t541;
  if (!shen_is_boolean(ctx, t543))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t543)) {
    t541 = t543;
  } else {
  KLObject* t545 = shen_intern(ctx, "type");
  KLObject* t547 = shen_hd(ctx, t527);
  KLObject* t548 = shen_eq(ctx, t545, t547);
  KLObject* t544;
  if (!shen_is_boolean(ctx, t548))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t548)) {
    t544 = t548;
  } else {
  KLObject* t551 = shen_tl(ctx, t527);
  KLObject* t552 = shen_cons_p(ctx, t551);
  KLObject* t549;
  if (!shen_is_boolean(ctx, t552))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t552)) {
    t549 = t552;
  } else {
  KLObject* t555 = shen_tl(ctx, t527);
  KLObject* t556 = shen_tl(ctx, t555);
  KLObject* t557 = shen_cons_p(ctx, t556);
  KLObject* t553;
  if (!shen_is_boolean(ctx, t557))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t557)) {
    t553 = t557;
  } else {
  KLObject* t558 = shen_empty_list(ctx);
  KLObject* t560 = shen_tl(ctx, t527);
  KLObject* t561 = shen_tl(ctx, t560);
  KLObject* t562 = shen_tl(ctx, t561);
  KLObject* t563 = shen_eq(ctx, t558, t562);
    if (!shen_is_boolean(ctx, t563))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t553 = t563;
  }
    if (!shen_is_boolean(ctx, t553))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t549 = t553;
  }
    if (!shen_is_boolean(ctx, t549))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t544 = t549;
  }
    if (!shen_is_boolean(ctx, t544))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t541 = t544;
  }
    if (!shen_is_boolean(ctx, t541))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t541)) {
  KLObject* t564 = shen_intern(ctx, "type");
  KLObject* t567 = shen_tl(ctx, t527);
  KLObject* t568 = shen_hd(ctx, t567);
  KLObject* t565;
  {
    KLObject* a565[] = {t568};
    t565 = shen_apply_direct(ctx, "shen.curry", 1, a565);
  }
  KLObject* t570 = shen_tl(ctx, t527);
  KLObject* t571 = shen_tl(ctx, t570);
  KLObject* t572 = shen_cons(ctx, t565, t571);
  KLObject* t573 = shen_cons(ctx, t564, t572);
      t528 = t573;
    } else {
  KLObject* t576 = shen_cons_p(ctx, t527);
  KLObject* t574;
  if (!shen_is_boolean(ctx, t576))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t576)) {
    t574 = t576;
  } else {
  KLObject* t579 = shen_hd(ctx, t527);
  KLObject* t577;
  {
    KLObject* a577[] = {t579};
    t577 = shen_apply_direct(ctx, "shen.special?", 1, a577);
  }
    if (!shen_is_boolean(ctx, t577))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t574 = t577;
  }
    if (!shen_is_boolean(ctx, t574))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t574)) {
  KLObject* t581 = shen_hd(ctx, t527);
  KLObject* t583;
  {
    Vector* caps_13 = shen_vector(ctx, 0);
    t583 = shen_native_closure(ctx, 1, &lambda_13, caps_13);
  }
  KLObject* t588 = shen_tl(ctx, t527);
  KLObject* t582;
  {
    KLObject* a582[] = {t583, t588};
    t582 = shen_apply_direct(ctx, "map", 2, a582);
  }
  KLObject* t589 = shen_cons(ctx, t581, t582);
      t528 = t589;
    } else {
  KLObject* t592 = shen_cons_p(ctx, t527);
  KLObject* t590;
  if (!shen_is_boolean(ctx, t592))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t592)) {
    t590 = t592;
  } else {
  KLObject* t595 = shen_hd(ctx, t527);
  KLObject* t593;
  {
    KLObject* a593[] = {t595};
    t593 = shen_apply_direct(ctx, "shen.extraspecial?", 1, a593);
  }
    if (!shen_is_boolean(ctx, t593))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t590 = t593;
  }
    if (!shen_is_boolean(ctx, t590))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t590)) {
      t528 = t527;
    } else {
  KLObject* t599 = shen_cons_p(ctx, t527);
  KLObject* t597;
  if (!shen_is_boolean(ctx, t599))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t599)) {
    t597 = t599;
  } else {
  KLObject* t602 = shen_tl(ctx, t527);
  KLObject* t603 = shen_cons_p(ctx, t602);
  KLObject* t600;
  if (!shen_is_boolean(ctx, t603))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t603)) {
    t600 = t603;
  } else {
  KLObject* t605 = shen_tl(ctx, t527);
  KLObject* t606 = shen_tl(ctx, t605);
  KLObject* t607 = shen_cons_p(ctx, t606);
    if (!shen_is_boolean(ctx, t607))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t600 = t607;
  }
    if (!shen_is_boolean(ctx, t600))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t597 = t600;
  }
    if (!shen_is_boolean(ctx, t597))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t597)) {
  KLObject* t609 = shen_hd(ctx, t527);
  KLObject* t611 = shen_tl(ctx, t527);
  KLObject* t612 = shen_hd(ctx, t611);
  KLObject* t613 = shen_empty_list(ctx);
  KLObject* t614 = shen_cons(ctx, t612, t613);
  KLObject* t615 = shen_cons(ctx, t609, t614);
  KLObject* t617 = shen_tl(ctx, t527);
  KLObject* t618 = shen_tl(ctx, t617);
  KLObject* t619 = shen_cons(ctx, t615, t618);
  {
    KLObject* n620_0 = t619;
    t527 = n620_0;
    goto tail_start_kl_shen_2ecurry_7;
  }
  KLObject* t620 = NULL;
      t528 = t620;
    } else {
  KLObject* t623 = shen_cons_p(ctx, t527);
  KLObject* t621;
  if (!shen_is_boolean(ctx, t623))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t623)) {
    t621 = t623;
  } else {
  KLObject* t626 = shen_tl(ctx, t527);
  KLObject* t627 = shen_cons_p(ctx, t626);
  KLObject* t624;
  if (!shen_is_boolean(ctx, t627))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t627)) {
    t624 = t627;
  } else {
  KLObject* t628 = shen_empty_list(ctx);
  KLObject* t630 = shen_tl(ctx, t527);
  KLObject* t631 = shen_tl(ctx, t630);
  KLObject* t632 = shen_eq(ctx, t628, t631);
    if (!shen_is_boolean(ctx, t632))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t624 = t632;
  }
    if (!shen_is_boolean(ctx, t624))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t621 = t624;
  }
    if (!shen_is_boolean(ctx, t621))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t621)) {
  KLObject* t635 = shen_hd(ctx, t527);
  KLObject* t633;
  {
    KLObject* a633[] = {t635};
    t633 = shen_apply_direct(ctx, "shen.curry", 1, a633);
  }
  KLObject* t638 = shen_tl(ctx, t527);
  KLObject* t639 = shen_hd(ctx, t638);
  KLObject* t636;
  {
    KLObject* a636[] = {t639};
    t636 = shen_apply_direct(ctx, "shen.curry", 1, a636);
  }
  KLObject* t640 = shen_empty_list(ctx);
  KLObject* t641 = shen_cons(ctx, t636, t640);
  KLObject* t642 = shen_cons(ctx, t633, t641);
      t528 = t642;
    } else {
  KLObject* t643 = shen_true(ctx);
    if (!shen_is_boolean(ctx, t643))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t643)) {
      t528 = t527;
    } else {
      shen_simple_error(ctx, "No true case found for cond");
      t528 = shen_empty_list(ctx);
    }
    }
    }
    }
    }
    }
    }
  }
    return t528;
  }
}

static KLObject* native_kl_shen_2especial_3f_8 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t645 = objects[0];
  tail_start_kl_shen_2especial_3f_8: ;
  KLObject* t649 = shen_intern(ctx, "shen.*special*");
  KLObject* t648;
  {
    KLObject* a648[] = {t649};
    t648 = shen_apply_direct(ctx, "value", 1, a648);
  }
  KLObject* t646;
  {
    KLObject* a646[] = {t645, t648};
    t646 = shen_tail_apply_direct(ctx, "element?", 2, a646);
  }
    return t646;
  }
}

static KLObject* native_kl_shen_2eextraspecial_3f_9 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t650 = objects[0];
  tail_start_kl_shen_2eextraspecial_3f_9: ;
  KLObject* t654 = shen_intern(ctx, "shen.*extraspecial*");
  KLObject* t653;
  {
    KLObject* a653[] = {t654};
    t653 = shen_apply_direct(ctx, "value", 1, a653);
  }
  KLObject* t651;
  {
    KLObject* a651[] = {t650, t653};
    t651 = shen_tail_apply_direct(ctx, "element?", 2, a651);
  }
    return t651;
  }
}

static KLObject* native_kl_shen_2esystem_2dS_10 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t655 = objects[0];
    KLObject* t656 = objects[1];
    KLObject* t657 = objects[2];
    KLObject* t658 = objects[3];
    KLObject* t659 = objects[4];
    KLObject* t660 = objects[5];
  tail_start_kl_shen_2esystem_2dS_10: ;
  KLObject* t662 = shen_number_l(ctx, 1);
  KLObject* t663 = shen_add(ctx, t659, t662);
  KLObject* t665;
  {
    KLObject* a665[] = {t658};
    t665 = shen_apply_direct(ctx, "shen.unlocked?", 1, a665);
  }
  KLObject* t664;
  if (!shen_is_boolean(ctx, t665))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t665)) {
  KLObject* t667 = shen_apply_direct(ctx, "shen.incinfs", 0, NULL);
  KLObject* t669 = shen_apply_direct(ctx, "shen.maxinfexceeded?", 0, NULL);
  KLObject* t668;
  {
    KLObject* a668[] = {t669, t657, t658, t663, t660};
    t668 = shen_apply_direct(ctx, "when", 5, a668);
  }
    t664 = t668;
  } else {
  KLObject* t674 = shen_false(ctx);
    t664 = t674;
  }
  KLObject* t677 = shen_false(ctx);
  KLObject* t678 = shen_eq(ctx, t664, t677);
  KLObject* t675;
  if (!shen_is_boolean(ctx, t678))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t678)) {
  KLObject* t680;
  {
    KLObject* a680[] = {t658};
    t680 = shen_apply_direct(ctx, "shen.unlocked?", 1, a680);
  }
  KLObject* t679;
  if (!shen_is_boolean(ctx, t680))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t680)) {
  KLObject* t682;
  {
    KLObject* a682[] = {t655, t657};
    t682 = shen_apply_direct(ctx, "shen.lazyderef", 2, a682);
  }
  KLObject* t687 = shen_cons_p(ctx, t682);
  KLObject* t685;
  if (!shen_is_boolean(ctx, t687))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t687)) {
  KLObject* t689 = shen_hd(ctx, t682);
  KLObject* t692 = shen_tl(ctx, t682);
  KLObject* t690;
  {
    KLObject* a690[] = {t692, t657};
    t690 = shen_apply_direct(ctx, "shen.lazyderef", 2, a690);
  }
  KLObject* t696 = shen_cons_p(ctx, t690);
  KLObject* t694;
  if (!shen_is_boolean(ctx, t696))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t696)) {
  KLObject* t698 = shen_hd(ctx, t690);
  KLObject* t701 = shen_tl(ctx, t690);
  KLObject* t699;
  {
    KLObject* a699[] = {t701, t657};
    t699 = shen_apply_direct(ctx, "shen.lazyderef", 2, a699);
  }
  KLObject* t705 = shen_cons_p(ctx, t699);
  KLObject* t703;
  if (!shen_is_boolean(ctx, t705))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t705)) {
  KLObject* t707 = shen_hd(ctx, t699);
  KLObject* t710 = shen_tl(ctx, t699);
  KLObject* t708;
  {
    KLObject* a708[] = {t710, t657};
    t708 = shen_apply_direct(ctx, "shen.lazyderef", 2, a708);
  }
  KLObject* t714 = shen_empty_list(ctx);
  KLObject* t715 = shen_eq(ctx, t708, t714);
  KLObject* t712;
  if (!shen_is_boolean(ctx, t715))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t715)) {
  KLObject* t716 = shen_apply_direct(ctx, "shen.incinfs", 0, NULL);
  KLObject* t718;
  {
    KLObject* a718[] = {t698, t657};
    t718 = shen_apply_direct(ctx, "shen.deref", 2, a718);
  }
  KLObject* t722 = shen_string(ctx, ":");
  KLObject* t721;
  {
    KLObject* a721[] = {t722};
    t721 = shen_apply_direct(ctx, "intern", 1, a721);
  }
  KLObject* t723 = shen_eq(ctx, t718, t721);
  KLObject* t727;
  {
    Vector* caps_14 = shen_vector(ctx, 7);
    shen_vector_set(ctx, caps_14, 0, t657);
    shen_vector_set(ctx, caps_14, 1, t658);
    shen_vector_set(ctx, caps_14, 2, t663);
    shen_vector_set(ctx, caps_14, 3, t689);
    shen_vector_set(ctx, caps_14, 4, t707);
    shen_vector_set(ctx, caps_14, 5, t656);
    shen_vector_set(ctx, caps_14, 6, t660);
    t727 = shen_native_closure(ctx, 0, &lambda_14, caps_14);
  }
  KLObject* t717;
  {
    KLObject* a717[] = {t723, t657, t658, t663, t727};
    t717 = shen_apply_direct(ctx, "when", 5, a717);
  }
    t712 = t717;
  } else {
  KLObject* t768 = shen_false(ctx);
    t712 = t768;
  }
    t703 = t712;
  } else {
  KLObject* t769 = shen_false(ctx);
    t703 = t769;
  }
    t694 = t703;
  } else {
  KLObject* t770 = shen_false(ctx);
    t694 = t770;
  }
    t685 = t694;
  } else {
  KLObject* t771 = shen_false(ctx);
    t685 = t771;
  }
    t679 = t685;
  } else {
  KLObject* t772 = shen_false(ctx);
    t679 = t772;
  }
  KLObject* t775 = shen_false(ctx);
  KLObject* t776 = shen_eq(ctx, t679, t775);
  KLObject* t773;
  if (!shen_is_boolean(ctx, t776))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t776)) {
  KLObject* t778;
  {
    KLObject* a778[] = {t658};
    t778 = shen_apply_direct(ctx, "shen.unlocked?", 1, a778);
  }
  KLObject* t777;
  if (!shen_is_boolean(ctx, t778))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t778)) {
  KLObject* t780 = shen_apply_direct(ctx, "shen.incinfs", 0, NULL);
  KLObject* t783 = shen_intern(ctx, "shen.*spy*");
  KLObject* t782;
  {
    KLObject* a782[] = {t783};
    t782 = shen_apply_direct(ctx, "value", 1, a782);
  }
  KLObject* t787;
  {
    Vector* caps_17 = shen_vector(ctx, 6);
    shen_vector_set(ctx, caps_17, 0, t655);
    shen_vector_set(ctx, caps_17, 1, t656);
    shen_vector_set(ctx, caps_17, 2, t657);
    shen_vector_set(ctx, caps_17, 3, t658);
    shen_vector_set(ctx, caps_17, 4, t663);
    shen_vector_set(ctx, caps_17, 5, t660);
    t787 = shen_native_closure(ctx, 0, &lambda_17, caps_17);
  }
  KLObject* t781;
  {
    KLObject* a781[] = {t782, t657, t658, t663, t787};
    t781 = shen_apply_direct(ctx, "when", 5, a781);
  }
    t777 = t781;
  } else {
  KLObject* t801 = shen_false(ctx);
    t777 = t801;
  }
  KLObject* t804 = shen_false(ctx);
  KLObject* t805 = shen_eq(ctx, t777, t804);
  KLObject* t802;
  if (!shen_is_boolean(ctx, t805))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t805)) {
  KLObject* t807;
  {
    KLObject* a807[] = {t658};
    t807 = shen_apply_direct(ctx, "shen.unlocked?", 1, a807);
  }
  KLObject* t806;
  if (!shen_is_boolean(ctx, t807))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t807)) {
  KLObject* t809 = shen_apply_direct(ctx, "shen.incinfs", 0, NULL);
  KLObject* t814 = shen_intern(ctx, "shen.*datatypes*");
  KLObject* t813;
  {
    KLObject* a813[] = {t814};
    t813 = shen_apply_direct(ctx, "value", 1, a813);
  }
  KLObject* t810;
  {
    KLObject* a810[] = {t655, t656, t813, t657, t658, t663, t660};
    t810 = shen_apply_direct(ctx, "shen.search-user-datatypes", 7, a810);
  }
    t806 = t810;
  } else {
  KLObject* t819 = shen_false(ctx);
    t806 = t819;
  }
  KLObject* t822 = shen_false(ctx);
  KLObject* t823 = shen_eq(ctx, t806, t822);
  KLObject* t820;
  if (!shen_is_boolean(ctx, t823))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t823)) {
  KLObject* t824;
  {
    KLObject* a824[] = {t658, t663};
    t824 = shen_tail_apply_direct(ctx, "shen.unlock", 2, a824);
  }
    t820 = t824;
  } else {
    t820 = t806;
  }
    t802 = t820;
  } else {
    t802 = t777;
  }
    t773 = t802;
  } else {
    t773 = t679;
  }
    t675 = t773;
  } else {
    t675 = t664;
  }
    return t675;
  }
}

static KLObject* native_kl_shen_2eshow_11 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t831 = objects[0];
    KLObject* t832 = objects[1];
    KLObject* t833 = objects[2];
    KLObject* t834 = objects[3];
    KLObject* t835 = objects[4];
    KLObject* t836 = objects[5];
  tail_start_kl_shen_2eshow_11: ;
  KLObject* t837 = shen_apply_direct(ctx, "shen.line", 0, NULL);
  KLObject* t839;
  {
    KLObject* a839[] = {t831, t833};
    t839 = shen_apply_direct(ctx, "shen.deref", 2, a839);
  }
  KLObject* t838;
  {
    KLObject* a838[] = {t839};
    t838 = shen_apply_direct(ctx, "shen.show-p", 1, a838);
  }
  KLObject* t843 = shen_number_l(ctx, 2);
  KLObject* t842;
  {
    KLObject* a842[] = {t843};
    t842 = shen_apply_direct(ctx, "nl", 1, a842);
  }
  KLObject* t845;
  {
    KLObject* a845[] = {t832, t833};
    t845 = shen_apply_direct(ctx, "shen.deref", 2, a845);
  }
  KLObject* t848 = shen_number_l(ctx, 1);
  KLObject* t844;
  {
    KLObject* a844[] = {t845, t848};
    t844 = shen_apply_direct(ctx, "shen.show-assumptions", 2, a844);
  }
  KLObject* t849 = shen_apply_direct(ctx, "shen.pause-for-user", 0, NULL);
  KLObject* t850 = shen_false(ctx);
    return t850;
  }
}

static KLObject* native_kl_shen_2eline_12 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  (void)function_object;
  (void)arguments;
  {
  tail_start_kl_shen_2eline_12: ;
  KLObject* t851 = shen_apply_direct(ctx, "inferences", 0, NULL);
  KLObject* t854 = shen_string(ctx, "____________________________________________________________ ");
  KLObject* t858 = shen_string(ctx, " inference");
  KLObject* t861 = shen_number_l(ctx, 1);
  KLObject* t863 = shen_eq(ctx, t861, t851);
  KLObject* t860;
  if (!shen_is_boolean(ctx, t863))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t863)) {
  KLObject* t864 = shen_string(ctx, "");
    t860 = t864;
  } else {
  KLObject* t865 = shen_string(ctx, "s");
    t860 = t865;
  }
  KLObject* t866 = shen_string(ctx, " \n?- ");
  KLObject* t867 = shen_intern(ctx, "shen.a");
  KLObject* t859;
  {
    KLObject* a859[] = {t860, t866, t867};
    t859 = shen_apply_direct(ctx, "shen.app", 3, a859);
  }
  KLObject* t857;
  {
    KLObject* a857[] = {t858, t859};
    t857 = shen_apply_direct(ctx, "cn", 2, a857);
  }
  KLObject* t868 = shen_intern(ctx, "shen.a");
  KLObject* t855;
  {
    KLObject* a855[] = {t851, t857, t868};
    t855 = shen_apply_direct(ctx, "shen.app", 3, a855);
  }
  KLObject* t853;
  {
    KLObject* a853[] = {t854, t855};
    t853 = shen_apply_direct(ctx, "cn", 2, a853);
  }
  KLObject* t869 = shen_apply_direct(ctx, "stoutput", 0, NULL);
  KLObject* t852;
  {
    KLObject* a852[] = {t853, t869};
    t852 = shen_tail_apply_direct(ctx, "pr", 2, a852);
  }
    return t852;
  }
}

static KLObject* native_kl_shen_2eshow_2dp_13 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t870 = objects[0];
  tail_start_kl_shen_2eshow_2dp_13: ;
  KLObject* t871;
  {
  KLObject* t874 = shen_cons_p(ctx, t870);
  KLObject* t872;
  if (!shen_is_boolean(ctx, t874))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t874)) {
    t872 = t874;
  } else {
  KLObject* t877 = shen_tl(ctx, t870);
  KLObject* t878 = shen_cons_p(ctx, t877);
  KLObject* t875;
  if (!shen_is_boolean(ctx, t878))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t878)) {
    t875 = t878;
  } else {
  KLObject* t881 = shen_tl(ctx, t870);
  KLObject* t882 = shen_tl(ctx, t881);
  KLObject* t883 = shen_cons_p(ctx, t882);
  KLObject* t879;
  if (!shen_is_boolean(ctx, t883))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t883)) {
    t879 = t883;
  } else {
  KLObject* t885 = shen_empty_list(ctx);
  KLObject* t887 = shen_tl(ctx, t870);
  KLObject* t888 = shen_tl(ctx, t887);
  KLObject* t889 = shen_tl(ctx, t888);
  KLObject* t890 = shen_eq(ctx, t885, t889);
  KLObject* t884;
  if (!shen_is_boolean(ctx, t890))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t890)) {
    t884 = t890;
  } else {
  KLObject* t892 = shen_tl(ctx, t870);
  KLObject* t893 = shen_hd(ctx, t892);
  KLObject* t895 = shen_string(ctx, ":");
  KLObject* t894;
  {
    KLObject* a894[] = {t895};
    t894 = shen_apply_direct(ctx, "intern", 1, a894);
  }
  KLObject* t896 = shen_eq(ctx, t893, t894);
    if (!shen_is_boolean(ctx, t896))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t884 = t896;
  }
    if (!shen_is_boolean(ctx, t884))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t879 = t884;
  }
    if (!shen_is_boolean(ctx, t879))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t875 = t879;
  }
    if (!shen_is_boolean(ctx, t875))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t872 = t875;
  }
    if (!shen_is_boolean(ctx, t872))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t872)) {
  KLObject* t899 = shen_hd(ctx, t870);
  KLObject* t897;
  {
    KLObject* a897[] = {t899};
    t897 = shen_apply_direct(ctx, "shen.prterm", 1, a897);
  }
  KLObject* t901 = shen_string(ctx, " : ");
  KLObject* t902 = shen_apply_direct(ctx, "stoutput", 0, NULL);
  KLObject* t900;
  {
    KLObject* a900[] = {t901, t902};
    t900 = shen_apply_direct(ctx, "pr", 2, a900);
  }
  KLObject* t906 = shen_tl(ctx, t870);
  KLObject* t907 = shen_tl(ctx, t906);
  KLObject* t908 = shen_hd(ctx, t907);
  KLObject* t909 = shen_string(ctx, "");
  KLObject* t910 = shen_intern(ctx, "shen.r");
  KLObject* t904;
  {
    KLObject* a904[] = {t908, t909, t910};
    t904 = shen_apply_direct(ctx, "shen.app", 3, a904);
  }
  KLObject* t911 = shen_apply_direct(ctx, "stoutput", 0, NULL);
  KLObject* t903;
  {
    KLObject* a903[] = {t904, t911};
    t903 = shen_tail_apply_direct(ctx, "pr", 2, a903);
  }
      t871 = t903;
    } else {
  KLObject* t912 = shen_true(ctx);
    if (!shen_is_boolean(ctx, t912))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t912)) {
  KLObject* t913;
  {
    KLObject* a913[] = {t870};
    t913 = shen_tail_apply_direct(ctx, "shen.prterm", 1, a913);
  }
      t871 = t913;
    } else {
      shen_simple_error(ctx, "No true case found for cond");
      t871 = shen_empty_list(ctx);
    }
    }
  }
    return t871;
  }
}

static KLObject* native_kl_shen_2eprterm_14 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t915 = objects[0];
  tail_start_kl_shen_2eprterm_14: ;
  KLObject* t916;
  {
  KLObject* t919 = shen_cons_p(ctx, t915);
  KLObject* t917;
  if (!shen_is_boolean(ctx, t919))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t919)) {
    t917 = t919;
  } else {
  KLObject* t921 = shen_intern(ctx, "cons");
  KLObject* t923 = shen_hd(ctx, t915);
  KLObject* t924 = shen_eq(ctx, t921, t923);
  KLObject* t920;
  if (!shen_is_boolean(ctx, t924))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t924)) {
    t920 = t924;
  } else {
  KLObject* t927 = shen_tl(ctx, t915);
  KLObject* t928 = shen_cons_p(ctx, t927);
  KLObject* t925;
  if (!shen_is_boolean(ctx, t928))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t928)) {
    t925 = t928;
  } else {
  KLObject* t931 = shen_tl(ctx, t915);
  KLObject* t932 = shen_tl(ctx, t931);
  KLObject* t933 = shen_cons_p(ctx, t932);
  KLObject* t929;
  if (!shen_is_boolean(ctx, t933))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t933)) {
    t929 = t933;
  } else {
  KLObject* t934 = shen_empty_list(ctx);
  KLObject* t936 = shen_tl(ctx, t915);
  KLObject* t937 = shen_tl(ctx, t936);
  KLObject* t938 = shen_tl(ctx, t937);
  KLObject* t939 = shen_eq(ctx, t934, t938);
    if (!shen_is_boolean(ctx, t939))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t929 = t939;
  }
    if (!shen_is_boolean(ctx, t929))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t925 = t929;
  }
    if (!shen_is_boolean(ctx, t925))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t920 = t925;
  }
    if (!shen_is_boolean(ctx, t920))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t917 = t920;
  }
    if (!shen_is_boolean(ctx, t917))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t917)) {
  KLObject* t941 = shen_string(ctx, "[");
  KLObject* t942 = shen_apply_direct(ctx, "stoutput", 0, NULL);
  KLObject* t940;
  {
    KLObject* a940[] = {t941, t942};
    t940 = shen_apply_direct(ctx, "pr", 2, a940);
  }
  KLObject* t945 = shen_tl(ctx, t915);
  KLObject* t946 = shen_hd(ctx, t945);
  KLObject* t943;
  {
    KLObject* a943[] = {t946};
    t943 = shen_apply_direct(ctx, "shen.prterm", 1, a943);
  }
  KLObject* t949 = shen_tl(ctx, t915);
  KLObject* t950 = shen_tl(ctx, t949);
  KLObject* t951 = shen_hd(ctx, t950);
  KLObject* t947;
  {
    KLObject* a947[] = {t951};
    t947 = shen_apply_direct(ctx, "shen.prtl", 1, a947);
  }
  KLObject* t953 = shen_string(ctx, "]");
  KLObject* t954 = shen_apply_direct(ctx, "stoutput", 0, NULL);
  KLObject* t952;
  {
    KLObject* a952[] = {t953, t954};
    t952 = shen_tail_apply_direct(ctx, "pr", 2, a952);
  }
      t916 = t952;
    } else {
  KLObject* t956 = shen_cons_p(ctx, t915);
    if (!shen_is_boolean(ctx, t956))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t956)) {
  KLObject* t958 = shen_string(ctx, "(");
  KLObject* t959 = shen_apply_direct(ctx, "stoutput", 0, NULL);
  KLObject* t957;
  {
    KLObject* a957[] = {t958, t959};
    t957 = shen_apply_direct(ctx, "pr", 2, a957);
  }
  KLObject* t962 = shen_hd(ctx, t915);
  KLObject* t960;
  {
    KLObject* a960[] = {t962};
    t960 = shen_apply_direct(ctx, "shen.prterm", 1, a960);
  }
  KLObject* t964;
  {
    Vector* caps_18 = shen_vector(ctx, 0);
    t964 = shen_native_closure(ctx, 1, &lambda_18, caps_18);
  }
  KLObject* t972 = shen_tl(ctx, t915);
  KLObject* t963;
  {
    KLObject* a963[] = {t964, t972};
    t963 = shen_apply_direct(ctx, "map", 2, a963);
  }
  KLObject* t974 = shen_string(ctx, ")");
  KLObject* t975 = shen_apply_direct(ctx, "stoutput", 0, NULL);
  KLObject* t973;
  {
    KLObject* a973[] = {t974, t975};
    t973 = shen_tail_apply_direct(ctx, "pr", 2, a973);
  }
      t916 = t973;
    } else {
  KLObject* t976 = shen_true(ctx);
    if (!shen_is_boolean(ctx, t976))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t976)) {
  KLObject* t977;
  {
    KLObject* a977[] = {t915};
    t977 = shen_tail_apply_direct(ctx, "print", 1, a977);
  }
      t916 = t977;
    } else {
      shen_simple_error(ctx, "No true case found for cond");
      t916 = shen_empty_list(ctx);
    }
    }
    }
  }
    return t916;
  }
}

static KLObject* native_kl_shen_2eprtl_15 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t979 = objects[0];
  tail_start_kl_shen_2eprtl_15: ;
  KLObject* t980;
  {
  KLObject* t981 = shen_empty_list(ctx);
  KLObject* t983 = shen_eq(ctx, t981, t979);
    if (!shen_is_boolean(ctx, t983))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t983)) {
  KLObject* t984 = shen_string(ctx, "");
      t980 = t984;
    } else {
  KLObject* t987 = shen_cons_p(ctx, t979);
  KLObject* t985;
  if (!shen_is_boolean(ctx, t987))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t987)) {
    t985 = t987;
  } else {
  KLObject* t989 = shen_intern(ctx, "cons");
  KLObject* t991 = shen_hd(ctx, t979);
  KLObject* t992 = shen_eq(ctx, t989, t991);
  KLObject* t988;
  if (!shen_is_boolean(ctx, t992))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t992)) {
    t988 = t992;
  } else {
  KLObject* t995 = shen_tl(ctx, t979);
  KLObject* t996 = shen_cons_p(ctx, t995);
  KLObject* t993;
  if (!shen_is_boolean(ctx, t996))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t996)) {
    t993 = t996;
  } else {
  KLObject* t999 = shen_tl(ctx, t979);
  KLObject* t1000 = shen_tl(ctx, t999);
  KLObject* t1001 = shen_cons_p(ctx, t1000);
  KLObject* t997;
  if (!shen_is_boolean(ctx, t1001))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t1001)) {
    t997 = t1001;
  } else {
  KLObject* t1002 = shen_empty_list(ctx);
  KLObject* t1004 = shen_tl(ctx, t979);
  KLObject* t1005 = shen_tl(ctx, t1004);
  KLObject* t1006 = shen_tl(ctx, t1005);
  KLObject* t1007 = shen_eq(ctx, t1002, t1006);
    if (!shen_is_boolean(ctx, t1007))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t997 = t1007;
  }
    if (!shen_is_boolean(ctx, t997))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t993 = t997;
  }
    if (!shen_is_boolean(ctx, t993))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t988 = t993;
  }
    if (!shen_is_boolean(ctx, t988))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t985 = t988;
  }
    if (!shen_is_boolean(ctx, t985))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t985)) {
  KLObject* t1009 = shen_string(ctx, " ");
  KLObject* t1010 = shen_apply_direct(ctx, "stoutput", 0, NULL);
  KLObject* t1008;
  {
    KLObject* a1008[] = {t1009, t1010};
    t1008 = shen_apply_direct(ctx, "pr", 2, a1008);
  }
  KLObject* t1013 = shen_tl(ctx, t979);
  KLObject* t1014 = shen_hd(ctx, t1013);
  KLObject* t1011;
  {
    KLObject* a1011[] = {t1014};
    t1011 = shen_apply_direct(ctx, "shen.prterm", 1, a1011);
  }
  KLObject* t1016 = shen_tl(ctx, t979);
  KLObject* t1017 = shen_tl(ctx, t1016);
  KLObject* t1018 = shen_hd(ctx, t1017);
  {
    KLObject* n1019_0 = t1018;
    t979 = n1019_0;
    goto tail_start_kl_shen_2eprtl_15;
  }
  KLObject* t1019 = NULL;
      t980 = t1019;
    } else {
  KLObject* t1020 = shen_true(ctx);
    if (!shen_is_boolean(ctx, t1020))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t1020)) {
  KLObject* t1022 = shen_string(ctx, " | ");
  KLObject* t1023 = shen_apply_direct(ctx, "stoutput", 0, NULL);
  KLObject* t1021;
  {
    KLObject* a1021[] = {t1022, t1023};
    t1021 = shen_apply_direct(ctx, "pr", 2, a1021);
  }
  KLObject* t1024;
  {
    KLObject* a1024[] = {t979};
    t1024 = shen_tail_apply_direct(ctx, "shen.prterm", 1, a1024);
  }
      t980 = t1024;
    } else {
      shen_simple_error(ctx, "No true case found for cond");
      t980 = shen_empty_list(ctx);
    }
    }
    }
  }
    return t980;
  }
}

static KLObject* native_kl_shen_2eshow_2dassumptions_16 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t1026 = objects[0];
    KLObject* t1027 = objects[1];
  tail_start_kl_shen_2eshow_2dassumptions_16: ;
  KLObject* t1028;
  {
  KLObject* t1029 = shen_empty_list(ctx);
  KLObject* t1031 = shen_eq(ctx, t1029, t1026);
    if (!shen_is_boolean(ctx, t1031))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t1031)) {
  KLObject* t1033 = shen_string(ctx, "\n> ");
  KLObject* t1034 = shen_apply_direct(ctx, "stoutput", 0, NULL);
  KLObject* t1032;
  {
    KLObject* a1032[] = {t1033, t1034};
    t1032 = shen_tail_apply_direct(ctx, "pr", 2, a1032);
  }
      t1028 = t1032;
    } else {
  KLObject* t1036 = shen_cons_p(ctx, t1026);
    if (!shen_is_boolean(ctx, t1036))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t1036)) {
  KLObject* t1040 = shen_string(ctx, ". ");
  KLObject* t1041 = shen_intern(ctx, "shen.a");
  KLObject* t1038;
  {
    KLObject* a1038[] = {t1027, t1040, t1041};
    t1038 = shen_apply_direct(ctx, "shen.app", 3, a1038);
  }
  KLObject* t1042 = shen_apply_direct(ctx, "stoutput", 0, NULL);
  KLObject* t1037;
  {
    KLObject* a1037[] = {t1038, t1042};
    t1037 = shen_apply_direct(ctx, "pr", 2, a1037);
  }
  KLObject* t1045 = shen_hd(ctx, t1026);
  KLObject* t1043;
  {
    KLObject* a1043[] = {t1045};
    t1043 = shen_apply_direct(ctx, "shen.show-p", 1, a1043);
  }
  KLObject* t1047 = shen_number_l(ctx, 1);
  KLObject* t1046;
  {
    KLObject* a1046[] = {t1047};
    t1046 = shen_apply_direct(ctx, "nl", 1, a1046);
  }
  KLObject* t1049 = shen_tl(ctx, t1026);
  KLObject* t1051 = shen_number_l(ctx, 1);
  KLObject* t1052 = shen_add(ctx, t1027, t1051);
  {
    KLObject* n1053_0 = t1049;
    KLObject* n1053_1 = t1052;
    t1026 = n1053_0;
    t1027 = n1053_1;
    goto tail_start_kl_shen_2eshow_2dassumptions_16;
  }
  KLObject* t1053 = NULL;
      t1028 = t1053;
    } else {
  KLObject* t1054 = shen_true(ctx);
    if (!shen_is_boolean(ctx, t1054))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t1054)) {
  KLObject* t1056 = shen_string(ctx, "implementation error in shen.show-assumptions");
  KLObject* t1055;
  {
    KLObject* a1055[] = {t1056};
    t1055 = shen_tail_apply_direct(ctx, "simple-error", 1, a1055);
  }
      t1028 = t1055;
    } else {
      shen_simple_error(ctx, "No true case found for cond");
      t1028 = shen_empty_list(ctx);
    }
    }
    }
  }
    return t1028;
  }
}

static KLObject* native_kl_shen_2epause_2dfor_2duser_17 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  (void)function_object;
  (void)arguments;
  {
  tail_start_kl_shen_2epause_2dfor_2duser_17: ;
  KLObject* t1058 = shen_apply_direct(ctx, "stinput", 0, NULL);
  KLObject* t1057;
  {
    KLObject* a1057[] = {t1058};
    t1057 = shen_apply_direct(ctx, "read-byte", 1, a1057);
  }
  KLObject* t1061 = shen_number_l(ctx, 94);
  KLObject* t1062 = shen_eq(ctx, t1057, t1061);
  KLObject* t1059;
  if (!shen_is_boolean(ctx, t1062))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1062)) {
  KLObject* t1064 = shen_string(ctx, "input aborted\n");
  KLObject* t1063;
  {
    KLObject* a1063[] = {t1064};
    t1063 = shen_tail_apply_direct(ctx, "simple-error", 1, a1063);
  }
    t1059 = t1063;
  } else {
  KLObject* t1066 = shen_number_l(ctx, 1);
  KLObject* t1065;
  {
    KLObject* a1065[] = {t1066};
    t1065 = shen_tail_apply_direct(ctx, "nl", 1, a1065);
  }
    t1059 = t1065;
  }
    return t1059;
  }
}

static KLObject* native_kl_shen_2etype_2dtheory_2denabled_3f_18 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  (void)function_object;
  (void)arguments;
  {
  tail_start_kl_shen_2etype_2dtheory_2denabled_3f_18: ;
  KLObject* t1068 = shen_intern(ctx, "shen.*shen-type-theory-enabled?*");
  KLObject* t1067;
  {
    KLObject* a1067[] = {t1068};
    t1067 = shen_tail_apply_direct(ctx, "value", 1, a1067);
  }
    return t1067;
  }
}

static KLObject* native_kl_shen_2emaxinfexceeded_3f_19 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  (void)function_object;
  (void)arguments;
  {
  tail_start_kl_shen_2emaxinfexceeded_3f_19: ;
  KLObject* t1070 = shen_apply_direct(ctx, "inferences", 0, NULL);
  KLObject* t1072 = shen_intern(ctx, "shen.*maxinferences*");
  KLObject* t1071;
  {
    KLObject* a1071[] = {t1072};
    t1071 = shen_apply_direct(ctx, "value", 1, a1071);
  }
  KLObject* t1073 = shen_gt(ctx, t1070, t1071);
  KLObject* t1069;
  if (!shen_is_boolean(ctx, t1073))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1073)) {
  KLObject* t1075 = shen_string(ctx, "maximum inferences exceeded");
  KLObject* t1074;
  {
    KLObject* a1074[] = {t1075};
    t1074 = shen_tail_apply_direct(ctx, "simple-error", 1, a1074);
  }
    t1069 = t1074;
  } else {
  KLObject* t1076 = shen_false(ctx);
    t1069 = t1076;
  }
    return t1069;
  }
}

static KLObject* native_kl_shen_2esystem_2dS_2dh_20 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t1077 = objects[0];
    KLObject* t1078 = objects[1];
    KLObject* t1079 = objects[2];
    KLObject* t1080 = objects[3];
    KLObject* t1081 = objects[4];
    KLObject* t1082 = objects[5];
    KLObject* t1083 = objects[6];
  tail_start_kl_shen_2esystem_2dS_2dh_20: ;
  KLObject* t1085 = shen_number_l(ctx, 1);
  KLObject* t1086 = shen_add(ctx, t1082, t1085);
  KLObject* t1088;
  {
    KLObject* a1088[] = {t1081};
    t1088 = shen_apply_direct(ctx, "shen.unlocked?", 1, a1088);
  }
  KLObject* t1087;
  if (!shen_is_boolean(ctx, t1088))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1088)) {
  KLObject* t1090 = shen_apply_direct(ctx, "shen.incinfs", 0, NULL);
  KLObject* t1093 = shen_intern(ctx, "shen.*spy*");
  KLObject* t1092;
  {
    KLObject* a1092[] = {t1093};
    t1092 = shen_apply_direct(ctx, "value", 1, a1092);
  }
  KLObject* t1097;
  {
    Vector* caps_19 = shen_vector(ctx, 7);
    shen_vector_set(ctx, caps_19, 0, t1077);
    shen_vector_set(ctx, caps_19, 1, t1078);
    shen_vector_set(ctx, caps_19, 2, t1079);
    shen_vector_set(ctx, caps_19, 3, t1080);
    shen_vector_set(ctx, caps_19, 4, t1081);
    shen_vector_set(ctx, caps_19, 5, t1086);
    shen_vector_set(ctx, caps_19, 6, t1083);
    t1097 = shen_native_closure(ctx, 0, &lambda_19, caps_19);
  }
  KLObject* t1091;
  {
    KLObject* a1091[] = {t1092, t1080, t1081, t1086, t1097};
    t1091 = shen_apply_direct(ctx, "when", 5, a1091);
  }
    t1087 = t1091;
  } else {
  KLObject* t1119 = shen_false(ctx);
    t1087 = t1119;
  }
  KLObject* t1122 = shen_false(ctx);
  KLObject* t1123 = shen_eq(ctx, t1087, t1122);
  KLObject* t1120;
  if (!shen_is_boolean(ctx, t1123))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1123)) {
  KLObject* t1125;
  {
    KLObject* a1125[] = {t1081};
    t1125 = shen_apply_direct(ctx, "shen.unlocked?", 1, a1125);
  }
  KLObject* t1124;
  if (!shen_is_boolean(ctx, t1125))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1125)) {
  KLObject* t1127 = shen_apply_direct(ctx, "shen.incinfs", 0, NULL);
  KLObject* t1130;
  {
    KLObject* a1130[] = {t1077, t1080};
    t1130 = shen_apply_direct(ctx, "shen.lazyderef", 2, a1130);
  }
  KLObject* t1133 = shen_cons_p(ctx, t1130);
  KLObject* t1129;
  {
    KLObject* a1129[] = {t1133};
    t1129 = shen_apply_direct(ctx, "not", 1, a1129);
  }
  KLObject* t1137;
  {
    Vector* caps_20 = shen_vector(ctx, 6);
    shen_vector_set(ctx, caps_20, 0, t1077);
    shen_vector_set(ctx, caps_20, 1, t1078);
    shen_vector_set(ctx, caps_20, 2, t1080);
    shen_vector_set(ctx, caps_20, 3, t1081);
    shen_vector_set(ctx, caps_20, 4, t1086);
    shen_vector_set(ctx, caps_20, 5, t1083);
    t1137 = shen_native_closure(ctx, 0, &lambda_20, caps_20);
  }
  KLObject* t1128;
  {
    KLObject* a1128[] = {t1129, t1080, t1081, t1086, t1137};
    t1128 = shen_apply_direct(ctx, "when", 5, a1128);
  }
    t1124 = t1128;
  } else {
  KLObject* t1151 = shen_false(ctx);
    t1124 = t1151;
  }
  KLObject* t1154 = shen_false(ctx);
  KLObject* t1155 = shen_eq(ctx, t1124, t1154);
  KLObject* t1152;
  if (!shen_is_boolean(ctx, t1155))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1155)) {
  KLObject* t1157;
  {
    KLObject* a1157[] = {t1081};
    t1157 = shen_apply_direct(ctx, "shen.unlocked?", 1, a1157);
  }
  KLObject* t1156;
  if (!shen_is_boolean(ctx, t1157))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1157)) {
  KLObject* t1159 = shen_apply_direct(ctx, "shen.incinfs", 0, NULL);
  KLObject* t1160;
  {
    KLObject* a1160[] = {t1077, t1078, t1079, t1080, t1081, t1086, t1083};
    t1160 = shen_apply_direct(ctx, "shen.by-hypothesis", 7, a1160);
  }
    t1156 = t1160;
  } else {
  KLObject* t1168 = shen_false(ctx);
    t1156 = t1168;
  }
  KLObject* t1171 = shen_false(ctx);
  KLObject* t1172 = shen_eq(ctx, t1156, t1171);
  KLObject* t1169;
  if (!shen_is_boolean(ctx, t1172))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1172)) {
  KLObject* t1174;
  {
    KLObject* a1174[] = {t1081};
    t1174 = shen_apply_direct(ctx, "shen.unlocked?", 1, a1174);
  }
  KLObject* t1173;
  if (!shen_is_boolean(ctx, t1174))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1174)) {
  KLObject* t1176;
  {
    KLObject* a1176[] = {t1077, t1080};
    t1176 = shen_apply_direct(ctx, "shen.lazyderef", 2, a1176);
  }
  KLObject* t1181 = shen_cons_p(ctx, t1176);
  KLObject* t1179;
  if (!shen_is_boolean(ctx, t1181))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1181)) {
  KLObject* t1183 = shen_hd(ctx, t1176);
  KLObject* t1186 = shen_tl(ctx, t1176);
  KLObject* t1184;
  {
    KLObject* a1184[] = {t1186, t1080};
    t1184 = shen_apply_direct(ctx, "shen.lazyderef", 2, a1184);
  }
  KLObject* t1190 = shen_empty_list(ctx);
  KLObject* t1191 = shen_eq(ctx, t1184, t1190);
  KLObject* t1188;
  if (!shen_is_boolean(ctx, t1191))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1191)) {
  KLObject* t1192 = shen_apply_direct(ctx, "shen.incinfs", 0, NULL);
  KLObject* t1195 = shen_intern(ctx, "-->");
  KLObject* t1197 = shen_empty_list(ctx);
  KLObject* t1198 = shen_cons(ctx, t1078, t1197);
  KLObject* t1199 = shen_cons(ctx, t1195, t1198);
  KLObject* t1193;
  {
    KLObject* a1193[] = {t1183, t1199, t1080, t1081, t1086, t1083};
    t1193 = shen_apply_direct(ctx, "shen.lookupsig", 6, a1193);
  }
    t1188 = t1193;
  } else {
  KLObject* t1204 = shen_false(ctx);
    t1188 = t1204;
  }
    t1179 = t1188;
  } else {
  KLObject* t1205 = shen_false(ctx);
    t1179 = t1205;
  }
    t1173 = t1179;
  } else {
  KLObject* t1206 = shen_false(ctx);
    t1173 = t1206;
  }
  KLObject* t1209 = shen_false(ctx);
  KLObject* t1210 = shen_eq(ctx, t1173, t1209);
  KLObject* t1207;
  if (!shen_is_boolean(ctx, t1210))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1210)) {
  KLObject* t1212;
  {
    KLObject* a1212[] = {t1081};
    t1212 = shen_apply_direct(ctx, "shen.unlocked?", 1, a1212);
  }
  KLObject* t1211;
  if (!shen_is_boolean(ctx, t1212))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1212)) {
  KLObject* t1214;
  {
    KLObject* a1214[] = {t1077, t1080};
    t1214 = shen_apply_direct(ctx, "shen.lazyderef", 2, a1214);
  }
  KLObject* t1219 = shen_cons_p(ctx, t1214);
  KLObject* t1217;
  if (!shen_is_boolean(ctx, t1219))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1219)) {
  KLObject* t1222 = shen_hd(ctx, t1214);
  KLObject* t1220;
  {
    KLObject* a1220[] = {t1222, t1080};
    t1220 = shen_apply_direct(ctx, "shen.lazyderef", 2, a1220);
  }
  KLObject* t1226 = shen_intern(ctx, "fn");
  KLObject* t1227 = shen_eq(ctx, t1220, t1226);
  KLObject* t1224;
  if (!shen_is_boolean(ctx, t1227))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1227)) {
  KLObject* t1230 = shen_tl(ctx, t1214);
  KLObject* t1228;
  {
    KLObject* a1228[] = {t1230, t1080};
    t1228 = shen_apply_direct(ctx, "shen.lazyderef", 2, a1228);
  }
  KLObject* t1234 = shen_cons_p(ctx, t1228);
  KLObject* t1232;
  if (!shen_is_boolean(ctx, t1234))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1234)) {
  KLObject* t1236 = shen_hd(ctx, t1228);
  KLObject* t1239 = shen_tl(ctx, t1228);
  KLObject* t1237;
  {
    KLObject* a1237[] = {t1239, t1080};
    t1237 = shen_apply_direct(ctx, "shen.lazyderef", 2, a1237);
  }
  KLObject* t1243 = shen_empty_list(ctx);
  KLObject* t1244 = shen_eq(ctx, t1237, t1243);
  KLObject* t1241;
  if (!shen_is_boolean(ctx, t1244))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1244)) {
  KLObject* t1245 = shen_apply_direct(ctx, "shen.incinfs", 0, NULL);
  KLObject* t1248;
  {
    KLObject* a1248[] = {t1236, t1080};
    t1248 = shen_apply_direct(ctx, "shen.deref", 2, a1248);
  }
  KLObject* t1247;
  {
    KLObject* a1247[] = {t1248};
    t1247 = shen_apply_direct(ctx, "arity", 1, a1247);
  }
  KLObject* t1251 = shen_number_l(ctx, 0);
  KLObject* t1252 = shen_eq(ctx, t1247, t1251);
  KLObject* t1256;
  {
    Vector* caps_21 = shen_vector(ctx, 7);
    shen_vector_set(ctx, caps_21, 0, t1080);
    shen_vector_set(ctx, caps_21, 1, t1081);
    shen_vector_set(ctx, caps_21, 2, t1086);
    shen_vector_set(ctx, caps_21, 3, t1236);
    shen_vector_set(ctx, caps_21, 4, t1078);
    shen_vector_set(ctx, caps_21, 5, t1079);
    shen_vector_set(ctx, caps_21, 6, t1083);
    t1256 = shen_native_closure(ctx, 0, &lambda_21, caps_21);
  }
  KLObject* t1246;
  {
    KLObject* a1246[] = {t1252, t1080, t1081, t1086, t1256};
    t1246 = shen_apply_direct(ctx, "when", 5, a1246);
  }
    t1241 = t1246;
  } else {
  KLObject* t1286 = shen_false(ctx);
    t1241 = t1286;
  }
    t1232 = t1241;
  } else {
  KLObject* t1287 = shen_false(ctx);
    t1232 = t1287;
  }
    t1224 = t1232;
  } else {
  KLObject* t1288 = shen_false(ctx);
    t1224 = t1288;
  }
    t1217 = t1224;
  } else {
  KLObject* t1289 = shen_false(ctx);
    t1217 = t1289;
  }
    t1211 = t1217;
  } else {
  KLObject* t1290 = shen_false(ctx);
    t1211 = t1290;
  }
  KLObject* t1293 = shen_false(ctx);
  KLObject* t1294 = shen_eq(ctx, t1211, t1293);
  KLObject* t1291;
  if (!shen_is_boolean(ctx, t1294))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1294)) {
  KLObject* t1296;
  {
    KLObject* a1296[] = {t1081};
    t1296 = shen_apply_direct(ctx, "shen.unlocked?", 1, a1296);
  }
  KLObject* t1295;
  if (!shen_is_boolean(ctx, t1296))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1296)) {
  KLObject* t1298;
  {
    KLObject* a1298[] = {t1077, t1080};
    t1298 = shen_apply_direct(ctx, "shen.lazyderef", 2, a1298);
  }
  KLObject* t1303 = shen_cons_p(ctx, t1298);
  KLObject* t1301;
  if (!shen_is_boolean(ctx, t1303))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1303)) {
  KLObject* t1306 = shen_hd(ctx, t1298);
  KLObject* t1304;
  {
    KLObject* a1304[] = {t1306, t1080};
    t1304 = shen_apply_direct(ctx, "shen.lazyderef", 2, a1304);
  }
  KLObject* t1310 = shen_intern(ctx, "fn");
  KLObject* t1311 = shen_eq(ctx, t1304, t1310);
  KLObject* t1308;
  if (!shen_is_boolean(ctx, t1311))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1311)) {
  KLObject* t1314 = shen_tl(ctx, t1298);
  KLObject* t1312;
  {
    KLObject* a1312[] = {t1314, t1080};
    t1312 = shen_apply_direct(ctx, "shen.lazyderef", 2, a1312);
  }
  KLObject* t1318 = shen_cons_p(ctx, t1312);
  KLObject* t1316;
  if (!shen_is_boolean(ctx, t1318))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1318)) {
  KLObject* t1320 = shen_hd(ctx, t1312);
  KLObject* t1323 = shen_tl(ctx, t1312);
  KLObject* t1321;
  {
    KLObject* a1321[] = {t1323, t1080};
    t1321 = shen_apply_direct(ctx, "shen.lazyderef", 2, a1321);
  }
  KLObject* t1327 = shen_empty_list(ctx);
  KLObject* t1328 = shen_eq(ctx, t1321, t1327);
  KLObject* t1325;
  if (!shen_is_boolean(ctx, t1328))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1328)) {
  KLObject* t1329 = shen_apply_direct(ctx, "shen.incinfs", 0, NULL);
  KLObject* t1330;
  {
    KLObject* a1330[] = {t1320, t1078, t1080, t1081, t1086, t1083};
    t1330 = shen_apply_direct(ctx, "shen.lookupsig", 6, a1330);
  }
    t1325 = t1330;
  } else {
  KLObject* t1337 = shen_false(ctx);
    t1325 = t1337;
  }
    t1316 = t1325;
  } else {
  KLObject* t1338 = shen_false(ctx);
    t1316 = t1338;
  }
    t1308 = t1316;
  } else {
  KLObject* t1339 = shen_false(ctx);
    t1308 = t1339;
  }
    t1301 = t1308;
  } else {
  KLObject* t1340 = shen_false(ctx);
    t1301 = t1340;
  }
    t1295 = t1301;
  } else {
  KLObject* t1341 = shen_false(ctx);
    t1295 = t1341;
  }
  KLObject* t1344 = shen_false(ctx);
  KLObject* t1345 = shen_eq(ctx, t1295, t1344);
  KLObject* t1342;
  if (!shen_is_boolean(ctx, t1345))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1345)) {
  KLObject* t1347;
  {
    KLObject* a1347[] = {t1081};
    t1347 = shen_apply_direct(ctx, "shen.unlocked?", 1, a1347);
  }
  KLObject* t1346;
  if (!shen_is_boolean(ctx, t1347))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1347)) {
  KLObject* t1349;
  {
    KLObject* a1349[] = {t1077, t1080};
    t1349 = shen_apply_direct(ctx, "shen.lazyderef", 2, a1349);
  }
  KLObject* t1354 = shen_cons_p(ctx, t1349);
  KLObject* t1352;
  if (!shen_is_boolean(ctx, t1354))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1354)) {
  KLObject* t1356 = shen_hd(ctx, t1349);
  KLObject* t1359 = shen_tl(ctx, t1349);
  KLObject* t1357;
  {
    KLObject* a1357[] = {t1359, t1080};
    t1357 = shen_apply_direct(ctx, "shen.lazyderef", 2, a1357);
  }
  KLObject* t1363 = shen_cons_p(ctx, t1357);
  KLObject* t1361;
  if (!shen_is_boolean(ctx, t1363))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1363)) {
  KLObject* t1365 = shen_hd(ctx, t1357);
  KLObject* t1368 = shen_tl(ctx, t1357);
  KLObject* t1366;
  {
    KLObject* a1366[] = {t1368, t1080};
    t1366 = shen_apply_direct(ctx, "shen.lazyderef", 2, a1366);
  }
  KLObject* t1372 = shen_empty_list(ctx);
  KLObject* t1373 = shen_eq(ctx, t1366, t1372);
  KLObject* t1370;
  if (!shen_is_boolean(ctx, t1373))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1373)) {
  KLObject* t1374;
  {
    KLObject* a1374[] = {t1080};
    t1374 = shen_apply_direct(ctx, "shen.newpv", 1, a1374);
  }
  KLObject* t1378 = shen_apply_direct(ctx, "shen.incinfs", 0, NULL);
  KLObject* t1381;
  {
    KLObject* a1381[] = {t1356, t1080};
    t1381 = shen_apply_direct(ctx, "shen.lazyderef", 2, a1381);
  }
  KLObject* t1384 = shen_cons_p(ctx, t1381);
  KLObject* t1380;
  {
    KLObject* a1380[] = {t1384};
    t1380 = shen_apply_direct(ctx, "not", 1, a1380);
  }
  KLObject* t1388;
  {
    Vector* caps_23 = shen_vector(ctx, 9);
    shen_vector_set(ctx, caps_23, 0, t1356);
    shen_vector_set(ctx, caps_23, 1, t1374);
    shen_vector_set(ctx, caps_23, 2, t1078);
    shen_vector_set(ctx, caps_23, 3, t1080);
    shen_vector_set(ctx, caps_23, 4, t1081);
    shen_vector_set(ctx, caps_23, 5, t1086);
    shen_vector_set(ctx, caps_23, 6, t1365);
    shen_vector_set(ctx, caps_23, 7, t1079);
    shen_vector_set(ctx, caps_23, 8, t1083);
    t1388 = shen_native_closure(ctx, 0, &lambda_23, caps_23);
  }
  KLObject* t1379;
  {
    KLObject* a1379[] = {t1380, t1080, t1081, t1086, t1388};
    t1379 = shen_apply_direct(ctx, "when", 5, a1379);
  }
  KLObject* t1376;
  {
    KLObject* a1376[] = {t1080, t1379};
    t1376 = shen_apply_direct(ctx, "shen.gc", 2, a1376);
  }
    t1370 = t1376;
  } else {
  KLObject* t1426 = shen_false(ctx);
    t1370 = t1426;
  }
    t1361 = t1370;
  } else {
  KLObject* t1427 = shen_false(ctx);
    t1361 = t1427;
  }
    t1352 = t1361;
  } else {
  KLObject* t1428 = shen_false(ctx);
    t1352 = t1428;
  }
    t1346 = t1352;
  } else {
  KLObject* t1429 = shen_false(ctx);
    t1346 = t1429;
  }
  KLObject* t1432 = shen_false(ctx);
  KLObject* t1433 = shen_eq(ctx, t1346, t1432);
  KLObject* t1430;
  if (!shen_is_boolean(ctx, t1433))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1433)) {
  KLObject* t1435;
  {
    KLObject* a1435[] = {t1081};
    t1435 = shen_apply_direct(ctx, "shen.unlocked?", 1, a1435);
  }
  KLObject* t1434;
  if (!shen_is_boolean(ctx, t1435))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1435)) {
  KLObject* t1437;
  {
    KLObject* a1437[] = {t1077, t1080};
    t1437 = shen_apply_direct(ctx, "shen.lazyderef", 2, a1437);
  }
  KLObject* t1442 = shen_cons_p(ctx, t1437);
  KLObject* t1440;
  if (!shen_is_boolean(ctx, t1442))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1442)) {
  KLObject* t1444 = shen_hd(ctx, t1437);
  KLObject* t1447 = shen_tl(ctx, t1437);
  KLObject* t1445;
  {
    KLObject* a1445[] = {t1447, t1080};
    t1445 = shen_apply_direct(ctx, "shen.lazyderef", 2, a1445);
  }
  KLObject* t1451 = shen_cons_p(ctx, t1445);
  KLObject* t1449;
  if (!shen_is_boolean(ctx, t1451))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1451)) {
  KLObject* t1453 = shen_hd(ctx, t1445);
  KLObject* t1456 = shen_tl(ctx, t1445);
  KLObject* t1454;
  {
    KLObject* a1454[] = {t1456, t1080};
    t1454 = shen_apply_direct(ctx, "shen.lazyderef", 2, a1454);
  }
  KLObject* t1460 = shen_empty_list(ctx);
  KLObject* t1461 = shen_eq(ctx, t1454, t1460);
  KLObject* t1458;
  if (!shen_is_boolean(ctx, t1461))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1461)) {
  KLObject* t1462;
  {
    KLObject* a1462[] = {t1080};
    t1462 = shen_apply_direct(ctx, "shen.newpv", 1, a1462);
  }
  KLObject* t1466 = shen_apply_direct(ctx, "shen.incinfs", 0, NULL);
  KLObject* t1470 = shen_intern(ctx, "-->");
  KLObject* t1472 = shen_empty_list(ctx);
  KLObject* t1473 = shen_cons(ctx, t1078, t1472);
  KLObject* t1474 = shen_cons(ctx, t1470, t1473);
  KLObject* t1475 = shen_cons(ctx, t1462, t1474);
  KLObject* t1480;
  {
    Vector* caps_25 = shen_vector(ctx, 7);
    shen_vector_set(ctx, caps_25, 0, t1453);
    shen_vector_set(ctx, caps_25, 1, t1462);
    shen_vector_set(ctx, caps_25, 2, t1079);
    shen_vector_set(ctx, caps_25, 3, t1080);
    shen_vector_set(ctx, caps_25, 4, t1081);
    shen_vector_set(ctx, caps_25, 5, t1086);
    shen_vector_set(ctx, caps_25, 6, t1083);
    t1480 = shen_native_closure(ctx, 0, &lambda_25, caps_25);
  }
  KLObject* t1467;
  {
    KLObject* a1467[] = {t1444, t1475, t1079, t1080, t1081, t1086, t1480};
    t1467 = shen_apply_direct(ctx, "shen.system-S-h", 7, a1467);
  }
  KLObject* t1464;
  {
    KLObject* a1464[] = {t1080, t1467};
    t1464 = shen_apply_direct(ctx, "shen.gc", 2, a1464);
  }
    t1458 = t1464;
  } else {
  KLObject* t1496 = shen_false(ctx);
    t1458 = t1496;
  }
    t1449 = t1458;
  } else {
  KLObject* t1497 = shen_false(ctx);
    t1449 = t1497;
  }
    t1440 = t1449;
  } else {
  KLObject* t1498 = shen_false(ctx);
    t1440 = t1498;
  }
    t1434 = t1440;
  } else {
  KLObject* t1499 = shen_false(ctx);
    t1434 = t1499;
  }
  KLObject* t1502 = shen_false(ctx);
  KLObject* t1503 = shen_eq(ctx, t1434, t1502);
  KLObject* t1500;
  if (!shen_is_boolean(ctx, t1503))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1503)) {
  KLObject* t1505;
  {
    KLObject* a1505[] = {t1081};
    t1505 = shen_apply_direct(ctx, "shen.unlocked?", 1, a1505);
  }
  KLObject* t1504;
  if (!shen_is_boolean(ctx, t1505))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1505)) {
  KLObject* t1507;
  {
    KLObject* a1507[] = {t1077, t1080};
    t1507 = shen_apply_direct(ctx, "shen.lazyderef", 2, a1507);
  }
  KLObject* t1512 = shen_cons_p(ctx, t1507);
  KLObject* t1510;
  if (!shen_is_boolean(ctx, t1512))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1512)) {
  KLObject* t1515 = shen_hd(ctx, t1507);
  KLObject* t1513;
  {
    KLObject* a1513[] = {t1515, t1080};
    t1513 = shen_apply_direct(ctx, "shen.lazyderef", 2, a1513);
  }
  KLObject* t1519 = shen_intern(ctx, "cons");
  KLObject* t1520 = shen_eq(ctx, t1513, t1519);
  KLObject* t1517;
  if (!shen_is_boolean(ctx, t1520))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1520)) {
  KLObject* t1523 = shen_tl(ctx, t1507);
  KLObject* t1521;
  {
    KLObject* a1521[] = {t1523, t1080};
    t1521 = shen_apply_direct(ctx, "shen.lazyderef", 2, a1521);
  }
  KLObject* t1527 = shen_cons_p(ctx, t1521);
  KLObject* t1525;
  if (!shen_is_boolean(ctx, t1527))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1527)) {
  KLObject* t1529 = shen_hd(ctx, t1521);
  KLObject* t1532 = shen_tl(ctx, t1521);
  KLObject* t1530;
  {
    KLObject* a1530[] = {t1532, t1080};
    t1530 = shen_apply_direct(ctx, "shen.lazyderef", 2, a1530);
  }
  KLObject* t1536 = shen_cons_p(ctx, t1530);
  KLObject* t1534;
  if (!shen_is_boolean(ctx, t1536))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1536)) {
  KLObject* t1538 = shen_hd(ctx, t1530);
  KLObject* t1541 = shen_tl(ctx, t1530);
  KLObject* t1539;
  {
    KLObject* a1539[] = {t1541, t1080};
    t1539 = shen_apply_direct(ctx, "shen.lazyderef", 2, a1539);
  }
  KLObject* t1545 = shen_empty_list(ctx);
  KLObject* t1546 = shen_eq(ctx, t1539, t1545);
  KLObject* t1543;
  if (!shen_is_boolean(ctx, t1546))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1546)) {
  KLObject* t1547;
  {
    KLObject* a1547[] = {t1078, t1080};
    t1547 = shen_apply_direct(ctx, "shen.lazyderef", 2, a1547);
  }
  KLObject* t1550;
  {
    Vector* caps_26 = shen_vector(ctx, 7);
    shen_vector_set(ctx, caps_26, 0, t1529);
    shen_vector_set(ctx, caps_26, 1, t1079);
    shen_vector_set(ctx, caps_26, 2, t1080);
    shen_vector_set(ctx, caps_26, 3, t1081);
    shen_vector_set(ctx, caps_26, 4, t1086);
    shen_vector_set(ctx, caps_26, 5, t1538);
    shen_vector_set(ctx, caps_26, 6, t1083);
    t1550 = shen_native_closure(ctx, 1, &lambda_26, caps_26);
  }
  KLObject* t1589 = shen_cons_p(ctx, t1547);
  KLObject* t1587;
  if (!shen_is_boolean(ctx, t1589))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1589)) {
  KLObject* t1592 = shen_hd(ctx, t1547);
  KLObject* t1590;
  {
    KLObject* a1590[] = {t1592, t1080};
    t1590 = shen_apply_direct(ctx, "shen.lazyderef", 2, a1590);
  }
  KLObject* t1594;
  {
    Vector* caps_28 = shen_vector(ctx, 3);
    shen_vector_set(ctx, caps_28, 0, t1547);
    shen_vector_set(ctx, caps_28, 1, t1080);
    shen_vector_set(ctx, caps_28, 2, t1550);
    t1594 = shen_native_closure(ctx, 0, &lambda_28, caps_28);
  }
  KLObject* t1660 = shen_intern(ctx, "list");
  KLObject* t1661 = shen_eq(ctx, t1590, t1660);
  KLObject* t1658;
  if (!shen_is_boolean(ctx, t1661))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1661)) {
  KLObject* t1662;
  {
    KLObject* a1662[] = {t1594};
    t1662 = shen_apply_direct(ctx, "thaw", 1, a1662);
  }
    t1658 = t1662;
  } else {
  KLObject* t1665;
  {
    KLObject* a1665[] = {t1590};
    t1665 = shen_apply_direct(ctx, "shen.pvar?", 1, a1665);
  }
  KLObject* t1664;
  if (!shen_is_boolean(ctx, t1665))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1665)) {
  KLObject* t1669 = shen_intern(ctx, "list");
  KLObject* t1667;
  {
    KLObject* a1667[] = {t1590, t1669, t1080, t1594};
    t1667 = shen_apply_direct(ctx, "shen.bind!", 4, a1667);
  }
    t1664 = t1667;
  } else {
  KLObject* t1672 = shen_false(ctx);
    t1664 = t1672;
  }
    t1658 = t1664;
  }
    t1587 = t1658;
  } else {
  KLObject* t1674;
  {
    KLObject* a1674[] = {t1547};
    t1674 = shen_apply_direct(ctx, "shen.pvar?", 1, a1674);
  }
  KLObject* t1673;
  if (!shen_is_boolean(ctx, t1674))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1674)) {
  KLObject* t1676;
  {
    KLObject* a1676[] = {t1080};
    t1676 = shen_apply_direct(ctx, "shen.newpv", 1, a1676);
  }
  KLObject* t1682 = shen_intern(ctx, "list");
  KLObject* t1684 = shen_empty_list(ctx);
  KLObject* t1685 = shen_cons(ctx, t1676, t1684);
  KLObject* t1686 = shen_cons(ctx, t1682, t1685);
  KLObject* t1688;
  {
    Vector* caps_32 = shen_vector(ctx, 2);
    shen_vector_set(ctx, caps_32, 0, t1550);
    shen_vector_set(ctx, caps_32, 1, t1676);
    t1688 = shen_native_closure(ctx, 0, &lambda_32, caps_32);
  }
  KLObject* t1680;
  {
    KLObject* a1680[] = {t1547, t1686, t1080, t1688};
    t1680 = shen_apply_direct(ctx, "shen.bind!", 4, a1680);
  }
  KLObject* t1678;
  {
    KLObject* a1678[] = {t1080, t1680};
    t1678 = shen_apply_direct(ctx, "shen.gc", 2, a1678);
  }
    t1673 = t1678;
  } else {
  KLObject* t1694 = shen_false(ctx);
    t1673 = t1694;
  }
    t1587 = t1673;
  }
    t1543 = t1587;
  } else {
  KLObject* t1695 = shen_false(ctx);
    t1543 = t1695;
  }
    t1534 = t1543;
  } else {
  KLObject* t1696 = shen_false(ctx);
    t1534 = t1696;
  }
    t1525 = t1534;
  } else {
  KLObject* t1697 = shen_false(ctx);
    t1525 = t1697;
  }
    t1517 = t1525;
  } else {
  KLObject* t1698 = shen_false(ctx);
    t1517 = t1698;
  }
    t1510 = t1517;
  } else {
  KLObject* t1699 = shen_false(ctx);
    t1510 = t1699;
  }
    t1504 = t1510;
  } else {
  KLObject* t1700 = shen_false(ctx);
    t1504 = t1700;
  }
  KLObject* t1703 = shen_false(ctx);
  KLObject* t1704 = shen_eq(ctx, t1504, t1703);
  KLObject* t1701;
  if (!shen_is_boolean(ctx, t1704))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1704)) {
  KLObject* t1706;
  {
    KLObject* a1706[] = {t1081};
    t1706 = shen_apply_direct(ctx, "shen.unlocked?", 1, a1706);
  }
  KLObject* t1705;
  if (!shen_is_boolean(ctx, t1706))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1706)) {
  KLObject* t1708;
  {
    KLObject* a1708[] = {t1077, t1080};
    t1708 = shen_apply_direct(ctx, "shen.lazyderef", 2, a1708);
  }
  KLObject* t1713 = shen_cons_p(ctx, t1708);
  KLObject* t1711;
  if (!shen_is_boolean(ctx, t1713))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1713)) {
  KLObject* t1716 = shen_hd(ctx, t1708);
  KLObject* t1714;
  {
    KLObject* a1714[] = {t1716, t1080};
    t1714 = shen_apply_direct(ctx, "shen.lazyderef", 2, a1714);
  }
  KLObject* t1720 = shen_intern(ctx, "@p");
  KLObject* t1721 = shen_eq(ctx, t1714, t1720);
  KLObject* t1718;
  if (!shen_is_boolean(ctx, t1721))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1721)) {
  KLObject* t1724 = shen_tl(ctx, t1708);
  KLObject* t1722;
  {
    KLObject* a1722[] = {t1724, t1080};
    t1722 = shen_apply_direct(ctx, "shen.lazyderef", 2, a1722);
  }
  KLObject* t1728 = shen_cons_p(ctx, t1722);
  KLObject* t1726;
  if (!shen_is_boolean(ctx, t1728))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1728)) {
  KLObject* t1730 = shen_hd(ctx, t1722);
  KLObject* t1733 = shen_tl(ctx, t1722);
  KLObject* t1731;
  {
    KLObject* a1731[] = {t1733, t1080};
    t1731 = shen_apply_direct(ctx, "shen.lazyderef", 2, a1731);
  }
  KLObject* t1737 = shen_cons_p(ctx, t1731);
  KLObject* t1735;
  if (!shen_is_boolean(ctx, t1737))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1737)) {
  KLObject* t1739 = shen_hd(ctx, t1731);
  KLObject* t1742 = shen_tl(ctx, t1731);
  KLObject* t1740;
  {
    KLObject* a1740[] = {t1742, t1080};
    t1740 = shen_apply_direct(ctx, "shen.lazyderef", 2, a1740);
  }
  KLObject* t1746 = shen_empty_list(ctx);
  KLObject* t1747 = shen_eq(ctx, t1740, t1746);
  KLObject* t1744;
  if (!shen_is_boolean(ctx, t1747))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1747)) {
  KLObject* t1748;
  {
    KLObject* a1748[] = {t1078, t1080};
    t1748 = shen_apply_direct(ctx, "shen.lazyderef", 2, a1748);
  }
  KLObject* t1751;
  {
    Vector* caps_33 = shen_vector(ctx, 7);
    shen_vector_set(ctx, caps_33, 0, t1730);
    shen_vector_set(ctx, caps_33, 1, t1079);
    shen_vector_set(ctx, caps_33, 2, t1080);
    shen_vector_set(ctx, caps_33, 3, t1081);
    shen_vector_set(ctx, caps_33, 4, t1086);
    shen_vector_set(ctx, caps_33, 5, t1739);
    shen_vector_set(ctx, caps_33, 6, t1083);
    t1751 = shen_native_closure(ctx, 1, &lambda_33, caps_33);
  }
  KLObject* t1796 = shen_cons_p(ctx, t1748);
  KLObject* t1794;
  if (!shen_is_boolean(ctx, t1796))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1796)) {
  KLObject* t1798 = shen_hd(ctx, t1748);
  KLObject* t1801 = shen_tl(ctx, t1748);
  KLObject* t1799;
  {
    KLObject* a1799[] = {t1801, t1080};
    t1799 = shen_apply_direct(ctx, "shen.lazyderef", 2, a1799);
  }
  KLObject* t1803;
  {
    Vector* caps_36 = shen_vector(ctx, 2);
    shen_vector_set(ctx, caps_36, 0, t1751);
    shen_vector_set(ctx, caps_36, 1, t1798);
    t1803 = shen_native_closure(ctx, 1, &lambda_36, caps_36);
  }
  KLObject* t1814 = shen_cons_p(ctx, t1799);
  KLObject* t1812;
  if (!shen_is_boolean(ctx, t1814))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1814)) {
  KLObject* t1817 = shen_hd(ctx, t1799);
  KLObject* t1815;
  {
    KLObject* a1815[] = {t1817, t1080};
    t1815 = shen_apply_direct(ctx, "shen.lazyderef", 2, a1815);
  }
  KLObject* t1819;
  {
    Vector* caps_37 = shen_vector(ctx, 3);
    shen_vector_set(ctx, caps_37, 0, t1799);
    shen_vector_set(ctx, caps_37, 1, t1080);
    shen_vector_set(ctx, caps_37, 2, t1803);
    t1819 = shen_native_closure(ctx, 0, &lambda_37, caps_37);
  }
  KLObject* t1885 = shen_intern(ctx, "*");
  KLObject* t1886 = shen_eq(ctx, t1815, t1885);
  KLObject* t1883;
  if (!shen_is_boolean(ctx, t1886))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1886)) {
  KLObject* t1887;
  {
    KLObject* a1887[] = {t1819};
    t1887 = shen_apply_direct(ctx, "thaw", 1, a1887);
  }
    t1883 = t1887;
  } else {
  KLObject* t1890;
  {
    KLObject* a1890[] = {t1815};
    t1890 = shen_apply_direct(ctx, "shen.pvar?", 1, a1890);
  }
  KLObject* t1889;
  if (!shen_is_boolean(ctx, t1890))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1890)) {
  KLObject* t1894 = shen_intern(ctx, "*");
  KLObject* t1892;
  {
    KLObject* a1892[] = {t1815, t1894, t1080, t1819};
    t1892 = shen_apply_direct(ctx, "shen.bind!", 4, a1892);
  }
    t1889 = t1892;
  } else {
  KLObject* t1897 = shen_false(ctx);
    t1889 = t1897;
  }
    t1883 = t1889;
  }
    t1812 = t1883;
  } else {
  KLObject* t1899;
  {
    KLObject* a1899[] = {t1799};
    t1899 = shen_apply_direct(ctx, "shen.pvar?", 1, a1899);
  }
  KLObject* t1898;
  if (!shen_is_boolean(ctx, t1899))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1899)) {
  KLObject* t1901;
  {
    KLObject* a1901[] = {t1080};
    t1901 = shen_apply_direct(ctx, "shen.newpv", 1, a1901);
  }
  KLObject* t1907 = shen_intern(ctx, "*");
  KLObject* t1909 = shen_empty_list(ctx);
  KLObject* t1910 = shen_cons(ctx, t1901, t1909);
  KLObject* t1911 = shen_cons(ctx, t1907, t1910);
  KLObject* t1913;
  {
    Vector* caps_41 = shen_vector(ctx, 2);
    shen_vector_set(ctx, caps_41, 0, t1803);
    shen_vector_set(ctx, caps_41, 1, t1901);
    t1913 = shen_native_closure(ctx, 0, &lambda_41, caps_41);
  }
  KLObject* t1905;
  {
    KLObject* a1905[] = {t1799, t1911, t1080, t1913};
    t1905 = shen_apply_direct(ctx, "shen.bind!", 4, a1905);
  }
  KLObject* t1903;
  {
    KLObject* a1903[] = {t1080, t1905};
    t1903 = shen_apply_direct(ctx, "shen.gc", 2, a1903);
  }
    t1898 = t1903;
  } else {
  KLObject* t1919 = shen_false(ctx);
    t1898 = t1919;
  }
    t1812 = t1898;
  }
    t1794 = t1812;
  } else {
  KLObject* t1921;
  {
    KLObject* a1921[] = {t1748};
    t1921 = shen_apply_direct(ctx, "shen.pvar?", 1, a1921);
  }
  KLObject* t1920;
  if (!shen_is_boolean(ctx, t1921))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1921)) {
  KLObject* t1923;
  {
    KLObject* a1923[] = {t1080};
    t1923 = shen_apply_direct(ctx, "shen.newpv", 1, a1923);
  }
  KLObject* t1927;
  {
    KLObject* a1927[] = {t1080};
    t1927 = shen_apply_direct(ctx, "shen.newpv", 1, a1927);
  }
  KLObject* t1934 = shen_intern(ctx, "*");
  KLObject* t1936 = shen_empty_list(ctx);
  KLObject* t1937 = shen_cons(ctx, t1927, t1936);
  KLObject* t1938 = shen_cons(ctx, t1934, t1937);
  KLObject* t1939 = shen_cons(ctx, t1923, t1938);
  KLObject* t1941;
  {
    Vector* caps_42 = shen_vector(ctx, 3);
    shen_vector_set(ctx, caps_42, 0, t1751);
    shen_vector_set(ctx, caps_42, 1, t1923);
    shen_vector_set(ctx, caps_42, 2, t1927);
    t1941 = shen_native_closure(ctx, 0, &lambda_42, caps_42);
  }
  KLObject* t1931;
  {
    KLObject* a1931[] = {t1748, t1939, t1080, t1941};
    t1931 = shen_apply_direct(ctx, "shen.bind!", 4, a1931);
  }
  KLObject* t1929;
  {
    KLObject* a1929[] = {t1080, t1931};
    t1929 = shen_apply_direct(ctx, "shen.gc", 2, a1929);
  }
  KLObject* t1925;
  {
    KLObject* a1925[] = {t1080, t1929};
    t1925 = shen_apply_direct(ctx, "shen.gc", 2, a1925);
  }
    t1920 = t1925;
  } else {
  KLObject* t1950 = shen_false(ctx);
    t1920 = t1950;
  }
    t1794 = t1920;
  }
    t1744 = t1794;
  } else {
  KLObject* t1951 = shen_false(ctx);
    t1744 = t1951;
  }
    t1735 = t1744;
  } else {
  KLObject* t1952 = shen_false(ctx);
    t1735 = t1952;
  }
    t1726 = t1735;
  } else {
  KLObject* t1953 = shen_false(ctx);
    t1726 = t1953;
  }
    t1718 = t1726;
  } else {
  KLObject* t1954 = shen_false(ctx);
    t1718 = t1954;
  }
    t1711 = t1718;
  } else {
  KLObject* t1955 = shen_false(ctx);
    t1711 = t1955;
  }
    t1705 = t1711;
  } else {
  KLObject* t1956 = shen_false(ctx);
    t1705 = t1956;
  }
  KLObject* t1959 = shen_false(ctx);
  KLObject* t1960 = shen_eq(ctx, t1705, t1959);
  KLObject* t1957;
  if (!shen_is_boolean(ctx, t1960))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1960)) {
  KLObject* t1962;
  {
    KLObject* a1962[] = {t1081};
    t1962 = shen_apply_direct(ctx, "shen.unlocked?", 1, a1962);
  }
  KLObject* t1961;
  if (!shen_is_boolean(ctx, t1962))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1962)) {
  KLObject* t1964;
  {
    KLObject* a1964[] = {t1077, t1080};
    t1964 = shen_apply_direct(ctx, "shen.lazyderef", 2, a1964);
  }
  KLObject* t1969 = shen_cons_p(ctx, t1964);
  KLObject* t1967;
  if (!shen_is_boolean(ctx, t1969))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1969)) {
  KLObject* t1972 = shen_hd(ctx, t1964);
  KLObject* t1970;
  {
    KLObject* a1970[] = {t1972, t1080};
    t1970 = shen_apply_direct(ctx, "shen.lazyderef", 2, a1970);
  }
  KLObject* t1976 = shen_intern(ctx, "@v");
  KLObject* t1977 = shen_eq(ctx, t1970, t1976);
  KLObject* t1974;
  if (!shen_is_boolean(ctx, t1977))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1977)) {
  KLObject* t1980 = shen_tl(ctx, t1964);
  KLObject* t1978;
  {
    KLObject* a1978[] = {t1980, t1080};
    t1978 = shen_apply_direct(ctx, "shen.lazyderef", 2, a1978);
  }
  KLObject* t1984 = shen_cons_p(ctx, t1978);
  KLObject* t1982;
  if (!shen_is_boolean(ctx, t1984))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1984)) {
  KLObject* t1986 = shen_hd(ctx, t1978);
  KLObject* t1989 = shen_tl(ctx, t1978);
  KLObject* t1987;
  {
    KLObject* a1987[] = {t1989, t1080};
    t1987 = shen_apply_direct(ctx, "shen.lazyderef", 2, a1987);
  }
  KLObject* t1993 = shen_cons_p(ctx, t1987);
  KLObject* t1991;
  if (!shen_is_boolean(ctx, t1993))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1993)) {
  KLObject* t1995 = shen_hd(ctx, t1987);
  KLObject* t1998 = shen_tl(ctx, t1987);
  KLObject* t1996;
  {
    KLObject* a1996[] = {t1998, t1080};
    t1996 = shen_apply_direct(ctx, "shen.lazyderef", 2, a1996);
  }
  KLObject* t2002 = shen_empty_list(ctx);
  KLObject* t2003 = shen_eq(ctx, t1996, t2002);
  KLObject* t2000;
  if (!shen_is_boolean(ctx, t2003))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t2003)) {
  KLObject* t2004;
  {
    KLObject* a2004[] = {t1078, t1080};
    t2004 = shen_apply_direct(ctx, "shen.lazyderef", 2, a2004);
  }
  KLObject* t2007;
  {
    Vector* caps_43 = shen_vector(ctx, 7);
    shen_vector_set(ctx, caps_43, 0, t1986);
    shen_vector_set(ctx, caps_43, 1, t1079);
    shen_vector_set(ctx, caps_43, 2, t1080);
    shen_vector_set(ctx, caps_43, 3, t1081);
    shen_vector_set(ctx, caps_43, 4, t1086);
    shen_vector_set(ctx, caps_43, 5, t1995);
    shen_vector_set(ctx, caps_43, 6, t1083);
    t2007 = shen_native_closure(ctx, 1, &lambda_43, caps_43);
  }
  KLObject* t2046 = shen_cons_p(ctx, t2004);
  KLObject* t2044;
  if (!shen_is_boolean(ctx, t2046))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t2046)) {
  KLObject* t2049 = shen_hd(ctx, t2004);
  KLObject* t2047;
  {
    KLObject* a2047[] = {t2049, t1080};
    t2047 = shen_apply_direct(ctx, "shen.lazyderef", 2, a2047);
  }
  KLObject* t2051;
  {
    Vector* caps_45 = shen_vector(ctx, 3);
    shen_vector_set(ctx, caps_45, 0, t2004);
    shen_vector_set(ctx, caps_45, 1, t1080);
    shen_vector_set(ctx, caps_45, 2, t2007);
    t2051 = shen_native_closure(ctx, 0, &lambda_45, caps_45);
  }
  KLObject* t2117 = shen_intern(ctx, "vector");
  KLObject* t2118 = shen_eq(ctx, t2047, t2117);
  KLObject* t2115;
  if (!shen_is_boolean(ctx, t2118))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t2118)) {
  KLObject* t2119;
  {
    KLObject* a2119[] = {t2051};
    t2119 = shen_apply_direct(ctx, "thaw", 1, a2119);
  }
    t2115 = t2119;
  } else {
  KLObject* t2122;
  {
    KLObject* a2122[] = {t2047};
    t2122 = shen_apply_direct(ctx, "shen.pvar?", 1, a2122);
  }
  KLObject* t2121;
  if (!shen_is_boolean(ctx, t2122))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t2122)) {
  KLObject* t2126 = shen_intern(ctx, "vector");
  KLObject* t2124;
  {
    KLObject* a2124[] = {t2047, t2126, t1080, t2051};
    t2124 = shen_apply_direct(ctx, "shen.bind!", 4, a2124);
  }
    t2121 = t2124;
  } else {
  KLObject* t2129 = shen_false(ctx);
    t2121 = t2129;
  }
    t2115 = t2121;
  }
    t2044 = t2115;
  } else {
  KLObject* t2131;
  {
    KLObject* a2131[] = {t2004};
    t2131 = shen_apply_direct(ctx, "shen.pvar?", 1, a2131);
  }
  KLObject* t2130;
  if (!shen_is_boolean(ctx, t2131))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t2131)) {
  KLObject* t2133;
  {
    KLObject* a2133[] = {t1080};
    t2133 = shen_apply_direct(ctx, "shen.newpv", 1, a2133);
  }
  KLObject* t2139 = shen_intern(ctx, "vector");
  KLObject* t2141 = shen_empty_list(ctx);
  KLObject* t2142 = shen_cons(ctx, t2133, t2141);
  KLObject* t2143 = shen_cons(ctx, t2139, t2142);
  KLObject* t2145;
  {
    Vector* caps_49 = shen_vector(ctx, 2);
    shen_vector_set(ctx, caps_49, 0, t2007);
    shen_vector_set(ctx, caps_49, 1, t2133);
    t2145 = shen_native_closure(ctx, 0, &lambda_49, caps_49);
  }
  KLObject* t2137;
  {
    KLObject* a2137[] = {t2004, t2143, t1080, t2145};
    t2137 = shen_apply_direct(ctx, "shen.bind!", 4, a2137);
  }
  KLObject* t2135;
  {
    KLObject* a2135[] = {t1080, t2137};
    t2135 = shen_apply_direct(ctx, "shen.gc", 2, a2135);
  }
    t2130 = t2135;
  } else {
  KLObject* t2151 = shen_false(ctx);
    t2130 = t2151;
  }
    t2044 = t2130;
  }
    t2000 = t2044;
  } else {
  KLObject* t2152 = shen_false(ctx);
    t2000 = t2152;
  }
    t1991 = t2000;
  } else {
  KLObject* t2153 = shen_false(ctx);
    t1991 = t2153;
  }
    t1982 = t1991;
  } else {
  KLObject* t2154 = shen_false(ctx);
    t1982 = t2154;
  }
    t1974 = t1982;
  } else {
  KLObject* t2155 = shen_false(ctx);
    t1974 = t2155;
  }
    t1967 = t1974;
  } else {
  KLObject* t2156 = shen_false(ctx);
    t1967 = t2156;
  }
    t1961 = t1967;
  } else {
  KLObject* t2157 = shen_false(ctx);
    t1961 = t2157;
  }
  KLObject* t2160 = shen_false(ctx);
  KLObject* t2161 = shen_eq(ctx, t1961, t2160);
  KLObject* t2158;
  if (!shen_is_boolean(ctx, t2161))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t2161)) {
  KLObject* t2163;
  {
    KLObject* a2163[] = {t1081};
    t2163 = shen_apply_direct(ctx, "shen.unlocked?", 1, a2163);
  }
  KLObject* t2162;
  if (!shen_is_boolean(ctx, t2163))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t2163)) {
  KLObject* t2165;
  {
    KLObject* a2165[] = {t1077, t1080};
    t2165 = shen_apply_direct(ctx, "shen.lazyderef", 2, a2165);
  }
  KLObject* t2170 = shen_cons_p(ctx, t2165);
  KLObject* t2168;
  if (!shen_is_boolean(ctx, t2170))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t2170)) {
  KLObject* t2173 = shen_hd(ctx, t2165);
  KLObject* t2171;
  {
    KLObject* a2171[] = {t2173, t1080};
    t2171 = shen_apply_direct(ctx, "shen.lazyderef", 2, a2171);
  }
  KLObject* t2177 = shen_intern(ctx, "@s");
  KLObject* t2178 = shen_eq(ctx, t2171, t2177);
  KLObject* t2175;
  if (!shen_is_boolean(ctx, t2178))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t2178)) {
  KLObject* t2181 = shen_tl(ctx, t2165);
  KLObject* t2179;
  {
    KLObject* a2179[] = {t2181, t1080};
    t2179 = shen_apply_direct(ctx, "shen.lazyderef", 2, a2179);
  }
  KLObject* t2185 = shen_cons_p(ctx, t2179);
  KLObject* t2183;
  if (!shen_is_boolean(ctx, t2185))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t2185)) {
  KLObject* t2187 = shen_hd(ctx, t2179);
  KLObject* t2190 = shen_tl(ctx, t2179);
  KLObject* t2188;
  {
    KLObject* a2188[] = {t2190, t1080};
    t2188 = shen_apply_direct(ctx, "shen.lazyderef", 2, a2188);
  }
  KLObject* t2194 = shen_cons_p(ctx, t2188);
  KLObject* t2192;
  if (!shen_is_boolean(ctx, t2194))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t2194)) {
  KLObject* t2196 = shen_hd(ctx, t2188);
  KLObject* t2199 = shen_tl(ctx, t2188);
  KLObject* t2197;
  {
    KLObject* a2197[] = {t2199, t1080};
    t2197 = shen_apply_direct(ctx, "shen.lazyderef", 2, a2197);
  }
  KLObject* t2203 = shen_empty_list(ctx);
  KLObject* t2204 = shen_eq(ctx, t2197, t2203);
  KLObject* t2201;
  if (!shen_is_boolean(ctx, t2204))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t2204)) {
  KLObject* t2205;
  {
    KLObject* a2205[] = {t1078, t1080};
    t2205 = shen_apply_direct(ctx, "shen.lazyderef", 2, a2205);
  }
  KLObject* t2208;
  {
    Vector* caps_50 = shen_vector(ctx, 7);
    shen_vector_set(ctx, caps_50, 0, t2187);
    shen_vector_set(ctx, caps_50, 1, t1079);
    shen_vector_set(ctx, caps_50, 2, t1080);
    shen_vector_set(ctx, caps_50, 3, t1081);
    shen_vector_set(ctx, caps_50, 4, t1086);
    shen_vector_set(ctx, caps_50, 5, t2196);
    shen_vector_set(ctx, caps_50, 6, t1083);
    t2208 = shen_native_closure(ctx, 0, &lambda_50, caps_50);
  }
  KLObject* t2241 = shen_intern(ctx, "string");
  KLObject* t2242 = shen_eq(ctx, t2205, t2241);
  KLObject* t2239;
  if (!shen_is_boolean(ctx, t2242))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t2242)) {
  KLObject* t2243;
  {
    KLObject* a2243[] = {t2208};
    t2243 = shen_apply_direct(ctx, "thaw", 1, a2243);
  }
    t2239 = t2243;
  } else {
  KLObject* t2246;
  {
    KLObject* a2246[] = {t2205};
    t2246 = shen_apply_direct(ctx, "shen.pvar?", 1, a2246);
  }
  KLObject* t2245;
  if (!shen_is_boolean(ctx, t2246))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t2246)) {
  KLObject* t2250 = shen_intern(ctx, "string");
  KLObject* t2248;
  {
    KLObject* a2248[] = {t2205, t2250, t1080, t2208};
    t2248 = shen_apply_direct(ctx, "shen.bind!", 4, a2248);
  }
    t2245 = t2248;
  } else {
  KLObject* t2253 = shen_false(ctx);
    t2245 = t2253;
  }
    t2239 = t2245;
  }
    t2201 = t2239;
  } else {
  KLObject* t2254 = shen_false(ctx);
    t2201 = t2254;
  }
    t2192 = t2201;
  } else {
  KLObject* t2255 = shen_false(ctx);
    t2192 = t2255;
  }
    t2183 = t2192;
  } else {
  KLObject* t2256 = shen_false(ctx);
    t2183 = t2256;
  }
    t2175 = t2183;
  } else {
  KLObject* t2257 = shen_false(ctx);
    t2175 = t2257;
  }
    t2168 = t2175;
  } else {
  KLObject* t2258 = shen_false(ctx);
    t2168 = t2258;
  }
    t2162 = t2168;
  } else {
  KLObject* t2259 = shen_false(ctx);
    t2162 = t2259;
  }
  KLObject* t2262 = shen_false(ctx);
  KLObject* t2263 = shen_eq(ctx, t2162, t2262);
  KLObject* t2260;
  if (!shen_is_boolean(ctx, t2263))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t2263)) {
  KLObject* t2265;
  {
    KLObject* a2265[] = {t1081};
    t2265 = shen_apply_direct(ctx, "shen.unlocked?", 1, a2265);
  }
  KLObject* t2264;
  if (!shen_is_boolean(ctx, t2265))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t2265)) {
  KLObject* t2267;
  {
    KLObject* a2267[] = {t1077, t1080};
    t2267 = shen_apply_direct(ctx, "shen.lazyderef", 2, a2267);
  }
  KLObject* t2272 = shen_cons_p(ctx, t2267);
  KLObject* t2270;
  if (!shen_is_boolean(ctx, t2272))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t2272)) {
  KLObject* t2275 = shen_hd(ctx, t2267);
  KLObject* t2273;
  {
    KLObject* a2273[] = {t2275, t1080};
    t2273 = shen_apply_direct(ctx, "shen.lazyderef", 2, a2273);
  }
  KLObject* t2279 = shen_intern(ctx, "lambda");
  KLObject* t2280 = shen_eq(ctx, t2273, t2279);
  KLObject* t2277;
  if (!shen_is_boolean(ctx, t2280))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t2280)) {
  KLObject* t2283 = shen_tl(ctx, t2267);
  KLObject* t2281;
  {
    KLObject* a2281[] = {t2283, t1080};
    t2281 = shen_apply_direct(ctx, "shen.lazyderef", 2, a2281);
  }
  KLObject* t2287 = shen_cons_p(ctx, t2281);
  KLObject* t2285;
  if (!shen_is_boolean(ctx, t2287))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t2287)) {
  KLObject* t2289 = shen_hd(ctx, t2281);
  KLObject* t2292 = shen_tl(ctx, t2281);
  KLObject* t2290;
  {
    KLObject* a2290[] = {t2292, t1080};
    t2290 = shen_apply_direct(ctx, "shen.lazyderef", 2, a2290);
  }
  KLObject* t2296 = shen_cons_p(ctx, t2290);
  KLObject* t2294;
  if (!shen_is_boolean(ctx, t2296))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t2296)) {
  KLObject* t2298 = shen_hd(ctx, t2290);
  KLObject* t2301 = shen_tl(ctx, t2290);
  KLObject* t2299;
  {
    KLObject* a2299[] = {t2301, t1080};
    t2299 = shen_apply_direct(ctx, "shen.lazyderef", 2, a2299);
  }
  KLObject* t2305 = shen_empty_list(ctx);
  KLObject* t2306 = shen_eq(ctx, t2299, t2305);
  KLObject* t2303;
  if (!shen_is_boolean(ctx, t2306))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t2306)) {
  KLObject* t2307;
  {
    KLObject* a2307[] = {t1078, t1080};
    t2307 = shen_apply_direct(ctx, "shen.lazyderef", 2, a2307);
  }
  KLObject* t2310;
  {
    Vector* caps_52 = shen_vector(ctx, 7);
    shen_vector_set(ctx, caps_52, 0, t1080);
    shen_vector_set(ctx, caps_52, 1, t2289);
    shen_vector_set(ctx, caps_52, 2, t1081);
    shen_vector_set(ctx, caps_52, 3, t1086);
    shen_vector_set(ctx, caps_52, 4, t2298);
    shen_vector_set(ctx, caps_52, 5, t1079);
    shen_vector_set(ctx, caps_52, 6, t1083);
    t2310 = shen_native_closure(ctx, 1, &lambda_52, caps_52);
  }
  KLObject* t2403 = shen_cons_p(ctx, t2307);
  KLObject* t2401;
  if (!shen_is_boolean(ctx, t2403))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t2403)) {
  KLObject* t2405 = shen_hd(ctx, t2307);
  KLObject* t2408 = shen_tl(ctx, t2307);
  KLObject* t2406;
  {
    KLObject* a2406[] = {t2408, t1080};
    t2406 = shen_apply_direct(ctx, "shen.lazyderef", 2, a2406);
  }
  KLObject* t2410;
  {
    Vector* caps_56 = shen_vector(ctx, 2);
    shen_vector_set(ctx, caps_56, 0, t2310);
    shen_vector_set(ctx, caps_56, 1, t2405);
    t2410 = shen_native_closure(ctx, 1, &lambda_56, caps_56);
  }
  KLObject* t2421 = shen_cons_p(ctx, t2406);
  KLObject* t2419;
  if (!shen_is_boolean(ctx, t2421))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t2421)) {
  KLObject* t2424 = shen_hd(ctx, t2406);
  KLObject* t2422;
  {
    KLObject* a2422[] = {t2424, t1080};
    t2422 = shen_apply_direct(ctx, "shen.lazyderef", 2, a2422);
  }
  KLObject* t2426;
  {
    Vector* caps_57 = shen_vector(ctx, 3);
    shen_vector_set(ctx, caps_57, 0, t2406);
    shen_vector_set(ctx, caps_57, 1, t1080);
    shen_vector_set(ctx, caps_57, 2, t2410);
    t2426 = shen_native_closure(ctx, 0, &lambda_57, caps_57);
  }
  KLObject* t2492 = shen_intern(ctx, "-->");
  KLObject* t2493 = shen_eq(ctx, t2422, t2492);
  KLObject* t2490;
  if (!shen_is_boolean(ctx, t2493))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t2493)) {
  KLObject* t2494;
  {
    KLObject* a2494[] = {t2426};
    t2494 = shen_apply_direct(ctx, "thaw", 1, a2494);
  }
    t2490 = t2494;
  } else {
  KLObject* t2497;
  {
    KLObject* a2497[] = {t2422};
    t2497 = shen_apply_direct(ctx, "shen.pvar?", 1, a2497);
  }
  KLObject* t2496;
  if (!shen_is_boolean(ctx, t2497))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t2497)) {
  KLObject* t2501 = shen_intern(ctx, "-->");
  KLObject* t2499;
  {
    KLObject* a2499[] = {t2422, t2501, t1080, t2426};
    t2499 = shen_apply_direct(ctx, "shen.bind!", 4, a2499);
  }
    t2496 = t2499;
  } else {
  KLObject* t2504 = shen_false(ctx);
    t2496 = t2504;
  }
    t2490 = t2496;
  }
    t2419 = t2490;
  } else {
  KLObject* t2506;
  {
    KLObject* a2506[] = {t2406};
    t2506 = shen_apply_direct(ctx, "shen.pvar?", 1, a2506);
  }
  KLObject* t2505;
  if (!shen_is_boolean(ctx, t2506))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t2506)) {
  KLObject* t2508;
  {
    KLObject* a2508[] = {t1080};
    t2508 = shen_apply_direct(ctx, "shen.newpv", 1, a2508);
  }
  KLObject* t2514 = shen_intern(ctx, "-->");
  KLObject* t2516 = shen_empty_list(ctx);
  KLObject* t2517 = shen_cons(ctx, t2508, t2516);
  KLObject* t2518 = shen_cons(ctx, t2514, t2517);
  KLObject* t2520;
  {
    Vector* caps_61 = shen_vector(ctx, 2);
    shen_vector_set(ctx, caps_61, 0, t2410);
    shen_vector_set(ctx, caps_61, 1, t2508);
    t2520 = shen_native_closure(ctx, 0, &lambda_61, caps_61);
  }
  KLObject* t2512;
  {
    KLObject* a2512[] = {t2406, t2518, t1080, t2520};
    t2512 = shen_apply_direct(ctx, "shen.bind!", 4, a2512);
  }
  KLObject* t2510;
  {
    KLObject* a2510[] = {t1080, t2512};
    t2510 = shen_apply_direct(ctx, "shen.gc", 2, a2510);
  }
    t2505 = t2510;
  } else {
  KLObject* t2526 = shen_false(ctx);
    t2505 = t2526;
  }
    t2419 = t2505;
  }
    t2401 = t2419;
  } else {
  KLObject* t2528;
  {
    KLObject* a2528[] = {t2307};
    t2528 = shen_apply_direct(ctx, "shen.pvar?", 1, a2528);
  }
  KLObject* t2527;
  if (!shen_is_boolean(ctx, t2528))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t2528)) {
  KLObject* t2530;
  {
    KLObject* a2530[] = {t1080};
    t2530 = shen_apply_direct(ctx, "shen.newpv", 1, a2530);
  }
  KLObject* t2534;
  {
    KLObject* a2534[] = {t1080};
    t2534 = shen_apply_direct(ctx, "shen.newpv", 1, a2534);
  }
  KLObject* t2541 = shen_intern(ctx, "-->");
  KLObject* t2543 = shen_empty_list(ctx);
  KLObject* t2544 = shen_cons(ctx, t2534, t2543);
  KLObject* t2545 = shen_cons(ctx, t2541, t2544);
  KLObject* t2546 = shen_cons(ctx, t2530, t2545);
  KLObject* t2548;
  {
    Vector* caps_62 = shen_vector(ctx, 3);
    shen_vector_set(ctx, caps_62, 0, t2310);
    shen_vector_set(ctx, caps_62, 1, t2530);
    shen_vector_set(ctx, caps_62, 2, t2534);
    t2548 = shen_native_closure(ctx, 0, &lambda_62, caps_62);
  }
  KLObject* t2538;
  {
    KLObject* a2538[] = {t2307, t2546, t1080, t2548};
    t2538 = shen_apply_direct(ctx, "shen.bind!", 4, a2538);
  }
  KLObject* t2536;
  {
    KLObject* a2536[] = {t1080, t2538};
    t2536 = shen_apply_direct(ctx, "shen.gc", 2, a2536);
  }
  KLObject* t2532;
  {
    KLObject* a2532[] = {t1080, t2536};
    t2532 = shen_apply_direct(ctx, "shen.gc", 2, a2532);
  }
    t2527 = t2532;
  } else {
  KLObject* t2557 = shen_false(ctx);
    t2527 = t2557;
  }
    t2401 = t2527;
  }
    t2303 = t2401;
  } else {
  KLObject* t2558 = shen_false(ctx);
    t2303 = t2558;
  }
    t2294 = t2303;
  } else {
  KLObject* t2559 = shen_false(ctx);
    t2294 = t2559;
  }
    t2285 = t2294;
  } else {
  KLObject* t2560 = shen_false(ctx);
    t2285 = t2560;
  }
    t2277 = t2285;
  } else {
  KLObject* t2561 = shen_false(ctx);
    t2277 = t2561;
  }
    t2270 = t2277;
  } else {
  KLObject* t2562 = shen_false(ctx);
    t2270 = t2562;
  }
    t2264 = t2270;
  } else {
  KLObject* t2563 = shen_false(ctx);
    t2264 = t2563;
  }
  KLObject* t2566 = shen_false(ctx);
  KLObject* t2567 = shen_eq(ctx, t2264, t2566);
  KLObject* t2564;
  if (!shen_is_boolean(ctx, t2567))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t2567)) {
  KLObject* t2569;
  {
    KLObject* a2569[] = {t1081};
    t2569 = shen_apply_direct(ctx, "shen.unlocked?", 1, a2569);
  }
  KLObject* t2568;
  if (!shen_is_boolean(ctx, t2569))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t2569)) {
  KLObject* t2571;
  {
    KLObject* a2571[] = {t1077, t1080};
    t2571 = shen_apply_direct(ctx, "shen.lazyderef", 2, a2571);
  }
  KLObject* t2576 = shen_cons_p(ctx, t2571);
  KLObject* t2574;
  if (!shen_is_boolean(ctx, t2576))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t2576)) {
  KLObject* t2579 = shen_hd(ctx, t2571);
  KLObject* t2577;
  {
    KLObject* a2577[] = {t2579, t1080};
    t2577 = shen_apply_direct(ctx, "shen.lazyderef", 2, a2577);
  }
  KLObject* t2583 = shen_intern(ctx, "let");
  KLObject* t2584 = shen_eq(ctx, t2577, t2583);
  KLObject* t2581;
  if (!shen_is_boolean(ctx, t2584))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t2584)) {
  KLObject* t2587 = shen_tl(ctx, t2571);
  KLObject* t2585;
  {
    KLObject* a2585[] = {t2587, t1080};
    t2585 = shen_apply_direct(ctx, "shen.lazyderef", 2, a2585);
  }
  KLObject* t2591 = shen_cons_p(ctx, t2585);
  KLObject* t2589;
  if (!shen_is_boolean(ctx, t2591))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t2591)) {
  KLObject* t2593 = shen_hd(ctx, t2585);
  KLObject* t2596 = shen_tl(ctx, t2585);
  KLObject* t2594;
  {
    KLObject* a2594[] = {t2596, t1080};
    t2594 = shen_apply_direct(ctx, "shen.lazyderef", 2, a2594);
  }
  KLObject* t2600 = shen_cons_p(ctx, t2594);
  KLObject* t2598;
  if (!shen_is_boolean(ctx, t2600))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t2600)) {
  KLObject* t2602 = shen_hd(ctx, t2594);
  KLObject* t2605 = shen_tl(ctx, t2594);
  KLObject* t2603;
  {
    KLObject* a2603[] = {t2605, t1080};
    t2603 = shen_apply_direct(ctx, "shen.lazyderef", 2, a2603);
  }
  KLObject* t2609 = shen_cons_p(ctx, t2603);
  KLObject* t2607;
  if (!shen_is_boolean(ctx, t2609))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t2609)) {
  KLObject* t2611 = shen_hd(ctx, t2603);
  KLObject* t2614 = shen_tl(ctx, t2603);
  KLObject* t2612;
  {
    KLObject* a2612[] = {t2614, t1080};
    t2612 = shen_apply_direct(ctx, "shen.lazyderef", 2, a2612);
  }
  KLObject* t2618 = shen_empty_list(ctx);
  KLObject* t2619 = shen_eq(ctx, t2612, t2618);
  KLObject* t2616;
  if (!shen_is_boolean(ctx, t2619))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t2619)) {
  KLObject* t2620;
  {
    KLObject* a2620[] = {t1080};
    t2620 = shen_apply_direct(ctx, "shen.newpv", 1, a2620);
  }
  KLObject* t2624;
  {
    KLObject* a2624[] = {t1080};
    t2624 = shen_apply_direct(ctx, "shen.newpv", 1, a2624);
  }
  KLObject* t2628;
  {
    KLObject* a2628[] = {t1080};
    t2628 = shen_apply_direct(ctx, "shen.newpv", 1, a2628);
  }
  KLObject* t2632 = shen_apply_direct(ctx, "shen.incinfs", 0, NULL);
  KLObject* t2640;
  {
    Vector* caps_63 = shen_vector(ctx, 11);
    shen_vector_set(ctx, caps_63, 0, t2624);
    shen_vector_set(ctx, caps_63, 1, t2593);
    shen_vector_set(ctx, caps_63, 2, t1080);
    shen_vector_set(ctx, caps_63, 3, t1081);
    shen_vector_set(ctx, caps_63, 4, t1086);
    shen_vector_set(ctx, caps_63, 5, t2620);
    shen_vector_set(ctx, caps_63, 6, t2611);
    shen_vector_set(ctx, caps_63, 7, t1078);
    shen_vector_set(ctx, caps_63, 8, t2628);
    shen_vector_set(ctx, caps_63, 9, t1079);
    shen_vector_set(ctx, caps_63, 10, t1083);
    t2640 = shen_native_closure(ctx, 0, &lambda_63, caps_63);
  }
  KLObject* t2633;
  {
    KLObject* a2633[] = {t2602, t2628, t1079, t1080, t1081, t1086, t2640};
    t2633 = shen_apply_direct(ctx, "shen.system-S-h", 7, a2633);
  }
  KLObject* t2630;
  {
    KLObject* a2630[] = {t1080, t2633};
    t2630 = shen_apply_direct(ctx, "shen.gc", 2, a2630);
  }
  KLObject* t2626;
  {
    KLObject* a2626[] = {t1080, t2630};
    t2626 = shen_apply_direct(ctx, "shen.gc", 2, a2626);
  }
  KLObject* t2622;
  {
    KLObject* a2622[] = {t1080, t2626};
    t2622 = shen_apply_direct(ctx, "shen.gc", 2, a2622);
  }
    t2616 = t2622;
  } else {
  KLObject* t2715 = shen_false(ctx);
    t2616 = t2715;
  }
    t2607 = t2616;
  } else {
  KLObject* t2716 = shen_false(ctx);
    t2607 = t2716;
  }
    t2598 = t2607;
  } else {
  KLObject* t2717 = shen_false(ctx);
    t2598 = t2717;
  }
    t2589 = t2598;
  } else {
  KLObject* t2718 = shen_false(ctx);
    t2589 = t2718;
  }
    t2581 = t2589;
  } else {
  KLObject* t2719 = shen_false(ctx);
    t2581 = t2719;
  }
    t2574 = t2581;
  } else {
  KLObject* t2720 = shen_false(ctx);
    t2574 = t2720;
  }
    t2568 = t2574;
  } else {
  KLObject* t2721 = shen_false(ctx);
    t2568 = t2721;
  }
  KLObject* t2724 = shen_false(ctx);
  KLObject* t2725 = shen_eq(ctx, t2568, t2724);
  KLObject* t2722;
  if (!shen_is_boolean(ctx, t2725))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t2725)) {
  KLObject* t2727;
  {
    KLObject* a2727[] = {t1081};
    t2727 = shen_apply_direct(ctx, "shen.unlocked?", 1, a2727);
  }
  KLObject* t2726;
  if (!shen_is_boolean(ctx, t2727))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t2727)) {
  KLObject* t2729;
  {
    KLObject* a2729[] = {t1077, t1080};
    t2729 = shen_apply_direct(ctx, "shen.lazyderef", 2, a2729);
  }
  KLObject* t2734 = shen_cons_p(ctx, t2729);
  KLObject* t2732;
  if (!shen_is_boolean(ctx, t2734))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t2734)) {
  KLObject* t2737 = shen_hd(ctx, t2729);
  KLObject* t2735;
  {
    KLObject* a2735[] = {t2737, t1080};
    t2735 = shen_apply_direct(ctx, "shen.lazyderef", 2, a2735);
  }
  KLObject* t2741 = shen_intern(ctx, "open");
  KLObject* t2742 = shen_eq(ctx, t2735, t2741);
  KLObject* t2739;
  if (!shen_is_boolean(ctx, t2742))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t2742)) {
  KLObject* t2745 = shen_tl(ctx, t2729);
  KLObject* t2743;
  {
    KLObject* a2743[] = {t2745, t1080};
    t2743 = shen_apply_direct(ctx, "shen.lazyderef", 2, a2743);
  }
  KLObject* t2749 = shen_cons_p(ctx, t2743);
  KLObject* t2747;
  if (!shen_is_boolean(ctx, t2749))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t2749)) {
  KLObject* t2751 = shen_hd(ctx, t2743);
  KLObject* t2754 = shen_tl(ctx, t2743);
  KLObject* t2752;
  {
    KLObject* a2752[] = {t2754, t1080};
    t2752 = shen_apply_direct(ctx, "shen.lazyderef", 2, a2752);
  }
  KLObject* t2758 = shen_cons_p(ctx, t2752);
  KLObject* t2756;
  if (!shen_is_boolean(ctx, t2758))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t2758)) {
  KLObject* t2760 = shen_hd(ctx, t2752);
  KLObject* t2763 = shen_tl(ctx, t2752);
  KLObject* t2761;
  {
    KLObject* a2761[] = {t2763, t1080};
    t2761 = shen_apply_direct(ctx, "shen.lazyderef", 2, a2761);
  }
  KLObject* t2767 = shen_empty_list(ctx);
  KLObject* t2768 = shen_eq(ctx, t2761, t2767);
  KLObject* t2765;
  if (!shen_is_boolean(ctx, t2768))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t2768)) {
  KLObject* t2769;
  {
    KLObject* a2769[] = {t1078, t1080};
    t2769 = shen_apply_direct(ctx, "shen.lazyderef", 2, a2769);
  }
  KLObject* t2772;
  {
    Vector* caps_66 = shen_vector(ctx, 7);
    shen_vector_set(ctx, caps_66, 0, t2760);
    shen_vector_set(ctx, caps_66, 1, t1080);
    shen_vector_set(ctx, caps_66, 2, t1081);
    shen_vector_set(ctx, caps_66, 3, t1086);
    shen_vector_set(ctx, caps_66, 4, t2751);
    shen_vector_set(ctx, caps_66, 5, t1079);
    shen_vector_set(ctx, caps_66, 6, t1083);
    t2772 = shen_native_closure(ctx, 1, &lambda_66, caps_66);
  }
  KLObject* t2826 = shen_cons_p(ctx, t2769);
  KLObject* t2824;
  if (!shen_is_boolean(ctx, t2826))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t2826)) {
  KLObject* t2829 = shen_hd(ctx, t2769);
  KLObject* t2827;
  {
    KLObject* a2827[] = {t2829, t1080};
    t2827 = shen_apply_direct(ctx, "shen.lazyderef", 2, a2827);
  }
  KLObject* t2831;
  {
    Vector* caps_69 = shen_vector(ctx, 3);
    shen_vector_set(ctx, caps_69, 0, t2769);
    shen_vector_set(ctx, caps_69, 1, t1080);
    shen_vector_set(ctx, caps_69, 2, t2772);
    t2831 = shen_native_closure(ctx, 0, &lambda_69, caps_69);
  }
  KLObject* t2897 = shen_intern(ctx, "stream");
  KLObject* t2898 = shen_eq(ctx, t2827, t2897);
  KLObject* t2895;
  if (!shen_is_boolean(ctx, t2898))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t2898)) {
  KLObject* t2899;
  {
    KLObject* a2899[] = {t2831};
    t2899 = shen_apply_direct(ctx, "thaw", 1, a2899);
  }
    t2895 = t2899;
  } else {
  KLObject* t2902;
  {
    KLObject* a2902[] = {t2827};
    t2902 = shen_apply_direct(ctx, "shen.pvar?", 1, a2902);
  }
  KLObject* t2901;
  if (!shen_is_boolean(ctx, t2902))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t2902)) {
  KLObject* t2906 = shen_intern(ctx, "stream");
  KLObject* t2904;
  {
    KLObject* a2904[] = {t2827, t2906, t1080, t2831};
    t2904 = shen_apply_direct(ctx, "shen.bind!", 4, a2904);
  }
    t2901 = t2904;
  } else {
  KLObject* t2909 = shen_false(ctx);
    t2901 = t2909;
  }
    t2895 = t2901;
  }
    t2824 = t2895;
  } else {
  KLObject* t2911;
  {
    KLObject* a2911[] = {t2769};
    t2911 = shen_apply_direct(ctx, "shen.pvar?", 1, a2911);
  }
  KLObject* t2910;
  if (!shen_is_boolean(ctx, t2911))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t2911)) {
  KLObject* t2913;
  {
    KLObject* a2913[] = {t1080};
    t2913 = shen_apply_direct(ctx, "shen.newpv", 1, a2913);
  }
  KLObject* t2919 = shen_intern(ctx, "stream");
  KLObject* t2921 = shen_empty_list(ctx);
  KLObject* t2922 = shen_cons(ctx, t2913, t2921);
  KLObject* t2923 = shen_cons(ctx, t2919, t2922);
  KLObject* t2925;
  {
    Vector* caps_73 = shen_vector(ctx, 2);
    shen_vector_set(ctx, caps_73, 0, t2772);
    shen_vector_set(ctx, caps_73, 1, t2913);
    t2925 = shen_native_closure(ctx, 0, &lambda_73, caps_73);
  }
  KLObject* t2917;
  {
    KLObject* a2917[] = {t2769, t2923, t1080, t2925};
    t2917 = shen_apply_direct(ctx, "shen.bind!", 4, a2917);
  }
  KLObject* t2915;
  {
    KLObject* a2915[] = {t1080, t2917};
    t2915 = shen_apply_direct(ctx, "shen.gc", 2, a2915);
  }
    t2910 = t2915;
  } else {
  KLObject* t2931 = shen_false(ctx);
    t2910 = t2931;
  }
    t2824 = t2910;
  }
    t2765 = t2824;
  } else {
  KLObject* t2932 = shen_false(ctx);
    t2765 = t2932;
  }
    t2756 = t2765;
  } else {
  KLObject* t2933 = shen_false(ctx);
    t2756 = t2933;
  }
    t2747 = t2756;
  } else {
  KLObject* t2934 = shen_false(ctx);
    t2747 = t2934;
  }
    t2739 = t2747;
  } else {
  KLObject* t2935 = shen_false(ctx);
    t2739 = t2935;
  }
    t2732 = t2739;
  } else {
  KLObject* t2936 = shen_false(ctx);
    t2732 = t2936;
  }
    t2726 = t2732;
  } else {
  KLObject* t2937 = shen_false(ctx);
    t2726 = t2937;
  }
  KLObject* t2940 = shen_false(ctx);
  KLObject* t2941 = shen_eq(ctx, t2726, t2940);
  KLObject* t2938;
  if (!shen_is_boolean(ctx, t2941))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t2941)) {
  KLObject* t2943;
  {
    KLObject* a2943[] = {t1081};
    t2943 = shen_apply_direct(ctx, "shen.unlocked?", 1, a2943);
  }
  KLObject* t2942;
  if (!shen_is_boolean(ctx, t2943))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t2943)) {
  KLObject* t2945;
  {
    KLObject* a2945[] = {t1077, t1080};
    t2945 = shen_apply_direct(ctx, "shen.lazyderef", 2, a2945);
  }
  KLObject* t2950 = shen_cons_p(ctx, t2945);
  KLObject* t2948;
  if (!shen_is_boolean(ctx, t2950))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t2950)) {
  KLObject* t2953 = shen_hd(ctx, t2945);
  KLObject* t2951;
  {
    KLObject* a2951[] = {t2953, t1080};
    t2951 = shen_apply_direct(ctx, "shen.lazyderef", 2, a2951);
  }
  KLObject* t2957 = shen_intern(ctx, "type");
  KLObject* t2958 = shen_eq(ctx, t2951, t2957);
  KLObject* t2955;
  if (!shen_is_boolean(ctx, t2958))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t2958)) {
  KLObject* t2961 = shen_tl(ctx, t2945);
  KLObject* t2959;
  {
    KLObject* a2959[] = {t2961, t1080};
    t2959 = shen_apply_direct(ctx, "shen.lazyderef", 2, a2959);
  }
  KLObject* t2965 = shen_cons_p(ctx, t2959);
  KLObject* t2963;
  if (!shen_is_boolean(ctx, t2965))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t2965)) {
  KLObject* t2967 = shen_hd(ctx, t2959);
  KLObject* t2970 = shen_tl(ctx, t2959);
  KLObject* t2968;
  {
    KLObject* a2968[] = {t2970, t1080};
    t2968 = shen_apply_direct(ctx, "shen.lazyderef", 2, a2968);
  }
  KLObject* t2974 = shen_cons_p(ctx, t2968);
  KLObject* t2972;
  if (!shen_is_boolean(ctx, t2974))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t2974)) {
  KLObject* t2976 = shen_hd(ctx, t2968);
  KLObject* t2979 = shen_tl(ctx, t2968);
  KLObject* t2977;
  {
    KLObject* a2977[] = {t2979, t1080};
    t2977 = shen_apply_direct(ctx, "shen.lazyderef", 2, a2977);
  }
  KLObject* t2983 = shen_empty_list(ctx);
  KLObject* t2984 = shen_eq(ctx, t2977, t2983);
  KLObject* t2981;
  if (!shen_is_boolean(ctx, t2984))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t2984)) {
  KLObject* t2985 = shen_apply_direct(ctx, "shen.incinfs", 0, NULL);
  KLObject* t2990;
  {
    Vector* caps_74 = shen_vector(ctx, 8);
    shen_vector_set(ctx, caps_74, 0, t2976);
    shen_vector_set(ctx, caps_74, 1, t1080);
    shen_vector_set(ctx, caps_74, 2, t1078);
    shen_vector_set(ctx, caps_74, 3, t1081);
    shen_vector_set(ctx, caps_74, 4, t1086);
    shen_vector_set(ctx, caps_74, 5, t2967);
    shen_vector_set(ctx, caps_74, 6, t1079);
    shen_vector_set(ctx, caps_74, 7, t1083);
    t2990 = shen_native_closure(ctx, 0, &lambda_74, caps_74);
  }
  KLObject* t2986;
  {
    KLObject* a2986[] = {t1080, t1081, t1086, t2990};
    t2986 = shen_apply_direct(ctx, "shen.cut", 4, a2986);
  }
    t2981 = t2986;
  } else {
  KLObject* t3024 = shen_false(ctx);
    t2981 = t3024;
  }
    t2972 = t2981;
  } else {
  KLObject* t3025 = shen_false(ctx);
    t2972 = t3025;
  }
    t2963 = t2972;
  } else {
  KLObject* t3026 = shen_false(ctx);
    t2963 = t3026;
  }
    t2955 = t2963;
  } else {
  KLObject* t3027 = shen_false(ctx);
    t2955 = t3027;
  }
    t2948 = t2955;
  } else {
  KLObject* t3028 = shen_false(ctx);
    t2948 = t3028;
  }
    t2942 = t2948;
  } else {
  KLObject* t3029 = shen_false(ctx);
    t2942 = t3029;
  }
  KLObject* t3032 = shen_false(ctx);
  KLObject* t3033 = shen_eq(ctx, t2942, t3032);
  KLObject* t3030;
  if (!shen_is_boolean(ctx, t3033))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t3033)) {
  KLObject* t3035;
  {
    KLObject* a3035[] = {t1081};
    t3035 = shen_apply_direct(ctx, "shen.unlocked?", 1, a3035);
  }
  KLObject* t3034;
  if (!shen_is_boolean(ctx, t3035))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t3035)) {
  KLObject* t3037;
  {
    KLObject* a3037[] = {t1077, t1080};
    t3037 = shen_apply_direct(ctx, "shen.lazyderef", 2, a3037);
  }
  KLObject* t3042 = shen_cons_p(ctx, t3037);
  KLObject* t3040;
  if (!shen_is_boolean(ctx, t3042))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t3042)) {
  KLObject* t3045 = shen_hd(ctx, t3037);
  KLObject* t3043;
  {
    KLObject* a3043[] = {t3045, t1080};
    t3043 = shen_apply_direct(ctx, "shen.lazyderef", 2, a3043);
  }
  KLObject* t3049 = shen_intern(ctx, "shen.input-h+");
  KLObject* t3050 = shen_eq(ctx, t3043, t3049);
  KLObject* t3047;
  if (!shen_is_boolean(ctx, t3050))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t3050)) {
  KLObject* t3053 = shen_tl(ctx, t3037);
  KLObject* t3051;
  {
    KLObject* a3051[] = {t3053, t1080};
    t3051 = shen_apply_direct(ctx, "shen.lazyderef", 2, a3051);
  }
  KLObject* t3057 = shen_cons_p(ctx, t3051);
  KLObject* t3055;
  if (!shen_is_boolean(ctx, t3057))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t3057)) {
  KLObject* t3059 = shen_hd(ctx, t3051);
  KLObject* t3062 = shen_tl(ctx, t3051);
  KLObject* t3060;
  {
    KLObject* a3060[] = {t3062, t1080};
    t3060 = shen_apply_direct(ctx, "shen.lazyderef", 2, a3060);
  }
  KLObject* t3066 = shen_cons_p(ctx, t3060);
  KLObject* t3064;
  if (!shen_is_boolean(ctx, t3066))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t3066)) {
  KLObject* t3068 = shen_hd(ctx, t3060);
  KLObject* t3071 = shen_tl(ctx, t3060);
  KLObject* t3069;
  {
    KLObject* a3069[] = {t3071, t1080};
    t3069 = shen_apply_direct(ctx, "shen.lazyderef", 2, a3069);
  }
  KLObject* t3075 = shen_empty_list(ctx);
  KLObject* t3076 = shen_eq(ctx, t3069, t3075);
  KLObject* t3073;
  if (!shen_is_boolean(ctx, t3076))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t3076)) {
  KLObject* t3077 = shen_apply_direct(ctx, "shen.incinfs", 0, NULL);
  KLObject* t3082;
  {
    KLObject* a3082[] = {t3059, t1080};
    t3082 = shen_apply_direct(ctx, "shen.deref", 2, a3082);
  }
  KLObject* t3081;
  {
    KLObject* a3081[] = {t3082};
    t3081 = shen_apply_direct(ctx, "shen.rdecons", 1, a3081);
  }
  KLObject* t3080;
  {
    KLObject* a3080[] = {t3081};
    t3080 = shen_apply_direct(ctx, "shen.rectify-type", 1, a3080);
  }
  KLObject* t3088;
  {
    Vector* caps_76 = shen_vector(ctx, 6);
    shen_vector_set(ctx, caps_76, 0, t3068);
    shen_vector_set(ctx, caps_76, 1, t1079);
    shen_vector_set(ctx, caps_76, 2, t1080);
    shen_vector_set(ctx, caps_76, 3, t1081);
    shen_vector_set(ctx, caps_76, 4, t1086);
    shen_vector_set(ctx, caps_76, 5, t1083);
    t3088 = shen_native_closure(ctx, 0, &lambda_76, caps_76);
  }
  KLObject* t3078;
  {
    KLObject* a3078[] = {t1078, t3080, t1080, t1081, t1086, t3088};
    t3078 = shen_apply_direct(ctx, "is", 6, a3078);
  }
    t3073 = t3078;
  } else {
  KLObject* t3107 = shen_false(ctx);
    t3073 = t3107;
  }
    t3064 = t3073;
  } else {
  KLObject* t3108 = shen_false(ctx);
    t3064 = t3108;
  }
    t3055 = t3064;
  } else {
  KLObject* t3109 = shen_false(ctx);
    t3055 = t3109;
  }
    t3047 = t3055;
  } else {
  KLObject* t3110 = shen_false(ctx);
    t3047 = t3110;
  }
    t3040 = t3047;
  } else {
  KLObject* t3111 = shen_false(ctx);
    t3040 = t3111;
  }
    t3034 = t3040;
  } else {
  KLObject* t3112 = shen_false(ctx);
    t3034 = t3112;
  }
  KLObject* t3115 = shen_false(ctx);
  KLObject* t3116 = shen_eq(ctx, t3034, t3115);
  KLObject* t3113;
  if (!shen_is_boolean(ctx, t3116))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t3116)) {
  KLObject* t3118;
  {
    KLObject* a3118[] = {t1081};
    t3118 = shen_apply_direct(ctx, "shen.unlocked?", 1, a3118);
  }
  KLObject* t3117;
  if (!shen_is_boolean(ctx, t3118))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t3118)) {
  KLObject* t3120;
  {
    KLObject* a3120[] = {t1077, t1080};
    t3120 = shen_apply_direct(ctx, "shen.lazyderef", 2, a3120);
  }
  KLObject* t3125 = shen_cons_p(ctx, t3120);
  KLObject* t3123;
  if (!shen_is_boolean(ctx, t3125))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t3125)) {
  KLObject* t3128 = shen_hd(ctx, t3120);
  KLObject* t3126;
  {
    KLObject* a3126[] = {t3128, t1080};
    t3126 = shen_apply_direct(ctx, "shen.lazyderef", 2, a3126);
  }
  KLObject* t3132 = shen_intern(ctx, "set");
  KLObject* t3133 = shen_eq(ctx, t3126, t3132);
  KLObject* t3130;
  if (!shen_is_boolean(ctx, t3133))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t3133)) {
  KLObject* t3136 = shen_tl(ctx, t3120);
  KLObject* t3134;
  {
    KLObject* a3134[] = {t3136, t1080};
    t3134 = shen_apply_direct(ctx, "shen.lazyderef", 2, a3134);
  }
  KLObject* t3140 = shen_cons_p(ctx, t3134);
  KLObject* t3138;
  if (!shen_is_boolean(ctx, t3140))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t3140)) {
  KLObject* t3142 = shen_hd(ctx, t3134);
  KLObject* t3145 = shen_tl(ctx, t3134);
  KLObject* t3143;
  {
    KLObject* a3143[] = {t3145, t1080};
    t3143 = shen_apply_direct(ctx, "shen.lazyderef", 2, a3143);
  }
  KLObject* t3149 = shen_cons_p(ctx, t3143);
  KLObject* t3147;
  if (!shen_is_boolean(ctx, t3149))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t3149)) {
  KLObject* t3151 = shen_hd(ctx, t3143);
  KLObject* t3154 = shen_tl(ctx, t3143);
  KLObject* t3152;
  {
    KLObject* a3152[] = {t3154, t1080};
    t3152 = shen_apply_direct(ctx, "shen.lazyderef", 2, a3152);
  }
  KLObject* t3158 = shen_empty_list(ctx);
  KLObject* t3159 = shen_eq(ctx, t3152, t3158);
  KLObject* t3156;
  if (!shen_is_boolean(ctx, t3159))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t3159)) {
  KLObject* t3160 = shen_apply_direct(ctx, "shen.incinfs", 0, NULL);
  KLObject* t3163 = shen_intern(ctx, "symbol");
  KLObject* t3168;
  {
    Vector* caps_77 = shen_vector(ctx, 8);
    shen_vector_set(ctx, caps_77, 0, t3142);
    shen_vector_set(ctx, caps_77, 1, t1078);
    shen_vector_set(ctx, caps_77, 2, t1079);
    shen_vector_set(ctx, caps_77, 3, t1080);
    shen_vector_set(ctx, caps_77, 4, t1081);
    shen_vector_set(ctx, caps_77, 5, t1086);
    shen_vector_set(ctx, caps_77, 6, t3151);
    shen_vector_set(ctx, caps_77, 7, t1083);
    t3168 = shen_native_closure(ctx, 0, &lambda_77, caps_77);
  }
  KLObject* t3161;
  {
    KLObject* a3161[] = {t3142, t3163, t1079, t1080, t1081, t1086, t3168};
    t3161 = shen_apply_direct(ctx, "shen.system-S-h", 7, a3161);
  }
    t3156 = t3161;
  } else {
  KLObject* t3204 = shen_false(ctx);
    t3156 = t3204;
  }
    t3147 = t3156;
  } else {
  KLObject* t3205 = shen_false(ctx);
    t3147 = t3205;
  }
    t3138 = t3147;
  } else {
  KLObject* t3206 = shen_false(ctx);
    t3138 = t3206;
  }
    t3130 = t3138;
  } else {
  KLObject* t3207 = shen_false(ctx);
    t3130 = t3207;
  }
    t3123 = t3130;
  } else {
  KLObject* t3208 = shen_false(ctx);
    t3123 = t3208;
  }
    t3117 = t3123;
  } else {
  KLObject* t3209 = shen_false(ctx);
    t3117 = t3209;
  }
  KLObject* t3212 = shen_false(ctx);
  KLObject* t3213 = shen_eq(ctx, t3117, t3212);
  KLObject* t3210;
  if (!shen_is_boolean(ctx, t3213))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t3213)) {
  KLObject* t3215;
  {
    KLObject* a3215[] = {t1081};
    t3215 = shen_apply_direct(ctx, "shen.unlocked?", 1, a3215);
  }
  KLObject* t3214;
  if (!shen_is_boolean(ctx, t3215))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t3215)) {
  KLObject* t3217;
  {
    KLObject* a3217[] = {t1080};
    t3217 = shen_apply_direct(ctx, "shen.newpv", 1, a3217);
  }
  KLObject* t3221 = shen_apply_direct(ctx, "shen.incinfs", 0, NULL);
  KLObject* t3225 = shen_false(ctx);
  KLObject* t3229;
  {
    Vector* caps_79 = shen_vector(ctx, 7);
    shen_vector_set(ctx, caps_79, 0, t1080);
    shen_vector_set(ctx, caps_79, 1, t1081);
    shen_vector_set(ctx, caps_79, 2, t1086);
    shen_vector_set(ctx, caps_79, 3, t1077);
    shen_vector_set(ctx, caps_79, 4, t1078);
    shen_vector_set(ctx, caps_79, 5, t3217);
    shen_vector_set(ctx, caps_79, 6, t1083);
    t3229 = shen_native_closure(ctx, 0, &lambda_79, caps_79);
  }
  KLObject* t3222;
  {
    KLObject* a3222[] = {t1079, t3217, t3225, t1080, t1081, t1086, t3229};
    t3222 = shen_apply_direct(ctx, "shen.l-rules", 7, a3222);
  }
  KLObject* t3219;
  {
    KLObject* a3219[] = {t1080, t3222};
    t3219 = shen_apply_direct(ctx, "shen.gc", 2, a3219);
  }
    t3214 = t3219;
  } else {
  KLObject* t3257 = shen_false(ctx);
    t3214 = t3257;
  }
  KLObject* t3260 = shen_false(ctx);
  KLObject* t3261 = shen_eq(ctx, t3214, t3260);
  KLObject* t3258;
  if (!shen_is_boolean(ctx, t3261))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t3261)) {
  KLObject* t3263;
  {
    KLObject* a3263[] = {t1081};
    t3263 = shen_apply_direct(ctx, "shen.unlocked?", 1, a3263);
  }
  KLObject* t3262;
  if (!shen_is_boolean(ctx, t3263))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t3263)) {
  KLObject* t3265 = shen_apply_direct(ctx, "shen.incinfs", 0, NULL);
  KLObject* t3269 = shen_string(ctx, ":");
  KLObject* t3268;
  {
    KLObject* a3268[] = {t3269};
    t3268 = shen_apply_direct(ctx, "intern", 1, a3268);
  }
  KLObject* t3271 = shen_empty_list(ctx);
  KLObject* t3272 = shen_cons(ctx, t1078, t3271);
  KLObject* t3273 = shen_cons(ctx, t3268, t3272);
  KLObject* t3274 = shen_cons(ctx, t1077, t3273);
  KLObject* t3277 = shen_intern(ctx, "shen.*datatypes*");
  KLObject* t3276;
  {
    KLObject* a3276[] = {t3277};
    t3276 = shen_apply_direct(ctx, "value", 1, a3276);
  }
  KLObject* t3266;
  {
    KLObject* a3266[] = {t3274, t1079, t3276, t1080, t1081, t1086, t1083};
    t3266 = shen_apply_direct(ctx, "shen.search-user-datatypes", 7, a3266);
  }
    t3262 = t3266;
  } else {
  KLObject* t3282 = shen_false(ctx);
    t3262 = t3282;
  }
  KLObject* t3285 = shen_false(ctx);
  KLObject* t3286 = shen_eq(ctx, t3262, t3285);
  KLObject* t3283;
  if (!shen_is_boolean(ctx, t3286))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t3286)) {
  KLObject* t3287;
  {
    KLObject* a3287[] = {t1081, t1086};
    t3287 = shen_tail_apply_direct(ctx, "shen.unlock", 2, a3287);
  }
    t3283 = t3287;
  } else {
    t3283 = t3262;
  }
    t3258 = t3283;
  } else {
    t3258 = t3214;
  }
    t3210 = t3258;
  } else {
    t3210 = t3117;
  }
    t3113 = t3210;
  } else {
    t3113 = t3034;
  }
    t3030 = t3113;
  } else {
    t3030 = t2942;
  }
    t2938 = t3030;
  } else {
    t2938 = t2726;
  }
    t2722 = t2938;
  } else {
    t2722 = t2568;
  }
    t2564 = t2722;
  } else {
    t2564 = t2264;
  }
    t2260 = t2564;
  } else {
    t2260 = t2162;
  }
    t2158 = t2260;
  } else {
    t2158 = t1961;
  }
    t1957 = t2158;
  } else {
    t1957 = t1705;
  }
    t1701 = t1957;
  } else {
    t1701 = t1504;
  }
    t1500 = t1701;
  } else {
    t1500 = t1434;
  }
    t1430 = t1500;
  } else {
    t1430 = t1346;
  }
    t1342 = t1430;
  } else {
    t1342 = t1295;
  }
    t1291 = t1342;
  } else {
    t1291 = t1211;
  }
    t1207 = t1291;
  } else {
    t1207 = t1173;
  }
    t1169 = t1207;
  } else {
    t1169 = t1156;
  }
    t1152 = t1169;
  } else {
    t1152 = t1124;
  }
    t1120 = t1152;
  } else {
    t1120 = t1087;
  }
    return t1120;
  }
}

static KLObject* native_kl_shen_2erdecons_21 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t3310 = objects[0];
  tail_start_kl_shen_2erdecons_21: ;
  KLObject* t3311;
  {
  KLObject* t3314 = shen_cons_p(ctx, t3310);
  KLObject* t3312;
  if (!shen_is_boolean(ctx, t3314))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t3314)) {
    t3312 = t3314;
  } else {
  KLObject* t3316 = shen_intern(ctx, "cons");
  KLObject* t3318 = shen_hd(ctx, t3310);
  KLObject* t3319 = shen_eq(ctx, t3316, t3318);
  KLObject* t3315;
  if (!shen_is_boolean(ctx, t3319))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t3319)) {
    t3315 = t3319;
  } else {
  KLObject* t3322 = shen_tl(ctx, t3310);
  KLObject* t3323 = shen_cons_p(ctx, t3322);
  KLObject* t3320;
  if (!shen_is_boolean(ctx, t3323))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t3323)) {
    t3320 = t3323;
  } else {
  KLObject* t3326 = shen_tl(ctx, t3310);
  KLObject* t3327 = shen_tl(ctx, t3326);
  KLObject* t3328 = shen_cons_p(ctx, t3327);
  KLObject* t3324;
  if (!shen_is_boolean(ctx, t3328))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t3328)) {
    t3324 = t3328;
  } else {
  KLObject* t3329 = shen_empty_list(ctx);
  KLObject* t3331 = shen_tl(ctx, t3310);
  KLObject* t3332 = shen_tl(ctx, t3331);
  KLObject* t3333 = shen_tl(ctx, t3332);
  KLObject* t3334 = shen_eq(ctx, t3329, t3333);
    if (!shen_is_boolean(ctx, t3334))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t3324 = t3334;
  }
    if (!shen_is_boolean(ctx, t3324))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t3320 = t3324;
  }
    if (!shen_is_boolean(ctx, t3320))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t3315 = t3320;
  }
    if (!shen_is_boolean(ctx, t3315))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t3312 = t3315;
  }
    if (!shen_is_boolean(ctx, t3312))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t3312)) {
  KLObject* t3337 = shen_tl(ctx, t3310);
  KLObject* t3338 = shen_hd(ctx, t3337);
  KLObject* t3335;
  {
    KLObject* a3335[] = {t3338};
    t3335 = shen_apply_direct(ctx, "shen.rdecons", 1, a3335);
  }
  KLObject* t3341 = shen_tl(ctx, t3310);
  KLObject* t3342 = shen_tl(ctx, t3341);
  KLObject* t3343 = shen_hd(ctx, t3342);
  KLObject* t3339;
  {
    KLObject* a3339[] = {t3343};
    t3339 = shen_apply_direct(ctx, "shen.rdecons", 1, a3339);
  }
  KLObject* t3344 = shen_cons(ctx, t3335, t3339);
      t3311 = t3344;
    } else {
  KLObject* t3346 = shen_cons_p(ctx, t3310);
    if (!shen_is_boolean(ctx, t3346))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t3346)) {
  KLObject* t3349 = shen_hd(ctx, t3310);
  KLObject* t3347;
  {
    KLObject* a3347[] = {t3349};
    t3347 = shen_apply_direct(ctx, "shen.rdecons", 1, a3347);
  }
  KLObject* t3352 = shen_tl(ctx, t3310);
  KLObject* t3350;
  {
    KLObject* a3350[] = {t3352};
    t3350 = shen_apply_direct(ctx, "shen.rdecons", 1, a3350);
  }
  KLObject* t3353 = shen_cons(ctx, t3347, t3350);
      t3311 = t3353;
    } else {
  KLObject* t3354 = shen_true(ctx);
    if (!shen_is_boolean(ctx, t3354))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t3354)) {
      t3311 = t3310;
    } else {
      shen_simple_error(ctx, "No true case found for cond");
      t3311 = shen_empty_list(ctx);
    }
    }
    }
  }
    return t3311;
  }
}

static KLObject* native_kl_shen_2eprimitive_22 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t3356 = objects[0];
    KLObject* t3357 = objects[1];
    KLObject* t3358 = objects[2];
    KLObject* t3359 = objects[3];
    KLObject* t3360 = objects[4];
    KLObject* t3361 = objects[5];
  tail_start_kl_shen_2eprimitive_22: ;
  KLObject* t3363;
  {
    KLObject* a3363[] = {t3359};
    t3363 = shen_apply_direct(ctx, "shen.unlocked?", 1, a3363);
  }
  KLObject* t3362;
  if (!shen_is_boolean(ctx, t3363))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t3363)) {
  KLObject* t3365;
  {
    KLObject* a3365[] = {t3357, t3358};
    t3365 = shen_apply_direct(ctx, "shen.lazyderef", 2, a3365);
  }
  KLObject* t3368;
  {
    Vector* caps_81 = shen_vector(ctx, 5);
    shen_vector_set(ctx, caps_81, 0, t3356);
    shen_vector_set(ctx, caps_81, 1, t3358);
    shen_vector_set(ctx, caps_81, 2, t3359);
    shen_vector_set(ctx, caps_81, 3, t3360);
    shen_vector_set(ctx, caps_81, 4, t3361);
    t3368 = shen_native_closure(ctx, 0, &lambda_81, caps_81);
  }
  KLObject* t3386 = shen_intern(ctx, "number");
  KLObject* t3387 = shen_eq(ctx, t3365, t3386);
  KLObject* t3384;
  if (!shen_is_boolean(ctx, t3387))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t3387)) {
  KLObject* t3388;
  {
    KLObject* a3388[] = {t3368};
    t3388 = shen_apply_direct(ctx, "thaw", 1, a3388);
  }
    t3384 = t3388;
  } else {
  KLObject* t3391;
  {
    KLObject* a3391[] = {t3365};
    t3391 = shen_apply_direct(ctx, "shen.pvar?", 1, a3391);
  }
  KLObject* t3390;
  if (!shen_is_boolean(ctx, t3391))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t3391)) {
  KLObject* t3395 = shen_intern(ctx, "number");
  KLObject* t3393;
  {
    KLObject* a3393[] = {t3365, t3395, t3358, t3368};
    t3393 = shen_apply_direct(ctx, "shen.bind!", 4, a3393);
  }
    t3390 = t3393;
  } else {
  KLObject* t3398 = shen_false(ctx);
    t3390 = t3398;
  }
    t3384 = t3390;
  }
    t3362 = t3384;
  } else {
  KLObject* t3399 = shen_false(ctx);
    t3362 = t3399;
  }
  KLObject* t3402 = shen_false(ctx);
  KLObject* t3403 = shen_eq(ctx, t3362, t3402);
  KLObject* t3400;
  if (!shen_is_boolean(ctx, t3403))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t3403)) {
  KLObject* t3405;
  {
    KLObject* a3405[] = {t3359};
    t3405 = shen_apply_direct(ctx, "shen.unlocked?", 1, a3405);
  }
  KLObject* t3404;
  if (!shen_is_boolean(ctx, t3405))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t3405)) {
  KLObject* t3407;
  {
    KLObject* a3407[] = {t3357, t3358};
    t3407 = shen_apply_direct(ctx, "shen.lazyderef", 2, a3407);
  }
  KLObject* t3410;
  {
    Vector* caps_82 = shen_vector(ctx, 5);
    shen_vector_set(ctx, caps_82, 0, t3356);
    shen_vector_set(ctx, caps_82, 1, t3358);
    shen_vector_set(ctx, caps_82, 2, t3359);
    shen_vector_set(ctx, caps_82, 3, t3360);
    shen_vector_set(ctx, caps_82, 4, t3361);
    t3410 = shen_native_closure(ctx, 0, &lambda_82, caps_82);
  }
  KLObject* t3428 = shen_intern(ctx, "boolean");
  KLObject* t3429 = shen_eq(ctx, t3407, t3428);
  KLObject* t3426;
  if (!shen_is_boolean(ctx, t3429))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t3429)) {
  KLObject* t3430;
  {
    KLObject* a3430[] = {t3410};
    t3430 = shen_apply_direct(ctx, "thaw", 1, a3430);
  }
    t3426 = t3430;
  } else {
  KLObject* t3433;
  {
    KLObject* a3433[] = {t3407};
    t3433 = shen_apply_direct(ctx, "shen.pvar?", 1, a3433);
  }
  KLObject* t3432;
  if (!shen_is_boolean(ctx, t3433))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t3433)) {
  KLObject* t3437 = shen_intern(ctx, "boolean");
  KLObject* t3435;
  {
    KLObject* a3435[] = {t3407, t3437, t3358, t3410};
    t3435 = shen_apply_direct(ctx, "shen.bind!", 4, a3435);
  }
    t3432 = t3435;
  } else {
  KLObject* t3440 = shen_false(ctx);
    t3432 = t3440;
  }
    t3426 = t3432;
  }
    t3404 = t3426;
  } else {
  KLObject* t3441 = shen_false(ctx);
    t3404 = t3441;
  }
  KLObject* t3444 = shen_false(ctx);
  KLObject* t3445 = shen_eq(ctx, t3404, t3444);
  KLObject* t3442;
  if (!shen_is_boolean(ctx, t3445))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t3445)) {
  KLObject* t3447;
  {
    KLObject* a3447[] = {t3359};
    t3447 = shen_apply_direct(ctx, "shen.unlocked?", 1, a3447);
  }
  KLObject* t3446;
  if (!shen_is_boolean(ctx, t3447))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t3447)) {
  KLObject* t3449;
  {
    KLObject* a3449[] = {t3357, t3358};
    t3449 = shen_apply_direct(ctx, "shen.lazyderef", 2, a3449);
  }
  KLObject* t3452;
  {
    Vector* caps_83 = shen_vector(ctx, 5);
    shen_vector_set(ctx, caps_83, 0, t3356);
    shen_vector_set(ctx, caps_83, 1, t3358);
    shen_vector_set(ctx, caps_83, 2, t3359);
    shen_vector_set(ctx, caps_83, 3, t3360);
    shen_vector_set(ctx, caps_83, 4, t3361);
    t3452 = shen_native_closure(ctx, 0, &lambda_83, caps_83);
  }
  KLObject* t3470 = shen_intern(ctx, "string");
  KLObject* t3471 = shen_eq(ctx, t3449, t3470);
  KLObject* t3468;
  if (!shen_is_boolean(ctx, t3471))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t3471)) {
  KLObject* t3472;
  {
    KLObject* a3472[] = {t3452};
    t3472 = shen_apply_direct(ctx, "thaw", 1, a3472);
  }
    t3468 = t3472;
  } else {
  KLObject* t3475;
  {
    KLObject* a3475[] = {t3449};
    t3475 = shen_apply_direct(ctx, "shen.pvar?", 1, a3475);
  }
  KLObject* t3474;
  if (!shen_is_boolean(ctx, t3475))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t3475)) {
  KLObject* t3479 = shen_intern(ctx, "string");
  KLObject* t3477;
  {
    KLObject* a3477[] = {t3449, t3479, t3358, t3452};
    t3477 = shen_apply_direct(ctx, "shen.bind!", 4, a3477);
  }
    t3474 = t3477;
  } else {
  KLObject* t3482 = shen_false(ctx);
    t3474 = t3482;
  }
    t3468 = t3474;
  }
    t3446 = t3468;
  } else {
  KLObject* t3483 = shen_false(ctx);
    t3446 = t3483;
  }
  KLObject* t3486 = shen_false(ctx);
  KLObject* t3487 = shen_eq(ctx, t3446, t3486);
  KLObject* t3484;
  if (!shen_is_boolean(ctx, t3487))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t3487)) {
  KLObject* t3489;
  {
    KLObject* a3489[] = {t3359};
    t3489 = shen_apply_direct(ctx, "shen.unlocked?", 1, a3489);
  }
  KLObject* t3488;
  if (!shen_is_boolean(ctx, t3489))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t3489)) {
  KLObject* t3491;
  {
    KLObject* a3491[] = {t3357, t3358};
    t3491 = shen_apply_direct(ctx, "shen.lazyderef", 2, a3491);
  }
  KLObject* t3494;
  {
    Vector* caps_84 = shen_vector(ctx, 5);
    shen_vector_set(ctx, caps_84, 0, t3356);
    shen_vector_set(ctx, caps_84, 1, t3358);
    shen_vector_set(ctx, caps_84, 2, t3359);
    shen_vector_set(ctx, caps_84, 3, t3360);
    shen_vector_set(ctx, caps_84, 4, t3361);
    t3494 = shen_native_closure(ctx, 0, &lambda_84, caps_84);
  }
  KLObject* t3512 = shen_intern(ctx, "symbol");
  KLObject* t3513 = shen_eq(ctx, t3491, t3512);
  KLObject* t3510;
  if (!shen_is_boolean(ctx, t3513))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t3513)) {
  KLObject* t3514;
  {
    KLObject* a3514[] = {t3494};
    t3514 = shen_apply_direct(ctx, "thaw", 1, a3514);
  }
    t3510 = t3514;
  } else {
  KLObject* t3517;
  {
    KLObject* a3517[] = {t3491};
    t3517 = shen_apply_direct(ctx, "shen.pvar?", 1, a3517);
  }
  KLObject* t3516;
  if (!shen_is_boolean(ctx, t3517))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t3517)) {
  KLObject* t3521 = shen_intern(ctx, "symbol");
  KLObject* t3519;
  {
    KLObject* a3519[] = {t3491, t3521, t3358, t3494};
    t3519 = shen_apply_direct(ctx, "shen.bind!", 4, a3519);
  }
    t3516 = t3519;
  } else {
  KLObject* t3524 = shen_false(ctx);
    t3516 = t3524;
  }
    t3510 = t3516;
  }
    t3488 = t3510;
  } else {
  KLObject* t3525 = shen_false(ctx);
    t3488 = t3525;
  }
  KLObject* t3528 = shen_false(ctx);
  KLObject* t3529 = shen_eq(ctx, t3488, t3528);
  KLObject* t3526;
  if (!shen_is_boolean(ctx, t3529))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t3529)) {
  KLObject* t3531;
  {
    KLObject* a3531[] = {t3359};
    t3531 = shen_apply_direct(ctx, "shen.unlocked?", 1, a3531);
  }
  KLObject* t3530;
  if (!shen_is_boolean(ctx, t3531))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t3531)) {
  KLObject* t3533;
  {
    KLObject* a3533[] = {t3356, t3358};
    t3533 = shen_apply_direct(ctx, "shen.lazyderef", 2, a3533);
  }
  KLObject* t3538 = shen_empty_list(ctx);
  KLObject* t3539 = shen_eq(ctx, t3533, t3538);
  KLObject* t3536;
  if (!shen_is_boolean(ctx, t3539))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t3539)) {
  KLObject* t3540;
  {
    KLObject* a3540[] = {t3357, t3358};
    t3540 = shen_apply_direct(ctx, "shen.lazyderef", 2, a3540);
  }
  KLObject* t3543;
  {
    Vector* caps_85 = shen_vector(ctx, 1);
    shen_vector_set(ctx, caps_85, 0, t3361);
    t3543 = shen_native_closure(ctx, 1, &lambda_85, caps_85);
  }
  KLObject* t3551 = shen_cons_p(ctx, t3540);
  KLObject* t3549;
  if (!shen_is_boolean(ctx, t3551))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t3551)) {
  KLObject* t3554 = shen_hd(ctx, t3540);
  KLObject* t3552;
  {
    KLObject* a3552[] = {t3554, t3358};
    t3552 = shen_apply_direct(ctx, "shen.lazyderef", 2, a3552);
  }
  KLObject* t3556;
  {
    Vector* caps_86 = shen_vector(ctx, 3);
    shen_vector_set(ctx, caps_86, 0, t3540);
    shen_vector_set(ctx, caps_86, 1, t3358);
    shen_vector_set(ctx, caps_86, 2, t3543);
    t3556 = shen_native_closure(ctx, 0, &lambda_86, caps_86);
  }
  KLObject* t3622 = shen_intern(ctx, "list");
  KLObject* t3623 = shen_eq(ctx, t3552, t3622);
  KLObject* t3620;
  if (!shen_is_boolean(ctx, t3623))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t3623)) {
  KLObject* t3624;
  {
    KLObject* a3624[] = {t3556};
    t3624 = shen_tail_apply_direct(ctx, "thaw", 1, a3624);
  }
    t3620 = t3624;
  } else {
  KLObject* t3627;
  {
    KLObject* a3627[] = {t3552};
    t3627 = shen_apply_direct(ctx, "shen.pvar?", 1, a3627);
  }
  KLObject* t3626;
  if (!shen_is_boolean(ctx, t3627))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t3627)) {
  KLObject* t3631 = shen_intern(ctx, "list");
  KLObject* t3629;
  {
    KLObject* a3629[] = {t3552, t3631, t3358, t3556};
    t3629 = shen_tail_apply_direct(ctx, "shen.bind!", 4, a3629);
  }
    t3626 = t3629;
  } else {
  KLObject* t3634 = shen_false(ctx);
    t3626 = t3634;
  }
    t3620 = t3626;
  }
    t3549 = t3620;
  } else {
  KLObject* t3636;
  {
    KLObject* a3636[] = {t3540};
    t3636 = shen_apply_direct(ctx, "shen.pvar?", 1, a3636);
  }
  KLObject* t3635;
  if (!shen_is_boolean(ctx, t3636))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t3636)) {
  KLObject* t3638;
  {
    KLObject* a3638[] = {t3358};
    t3638 = shen_apply_direct(ctx, "shen.newpv", 1, a3638);
  }
  KLObject* t3644 = shen_intern(ctx, "list");
  KLObject* t3646 = shen_empty_list(ctx);
  KLObject* t3647 = shen_cons(ctx, t3638, t3646);
  KLObject* t3648 = shen_cons(ctx, t3644, t3647);
  KLObject* t3650;
  {
    Vector* caps_90 = shen_vector(ctx, 2);
    shen_vector_set(ctx, caps_90, 0, t3543);
    shen_vector_set(ctx, caps_90, 1, t3638);
    t3650 = shen_native_closure(ctx, 0, &lambda_90, caps_90);
  }
  KLObject* t3642;
  {
    KLObject* a3642[] = {t3540, t3648, t3358, t3650};
    t3642 = shen_apply_direct(ctx, "shen.bind!", 4, a3642);
  }
  KLObject* t3640;
  {
    KLObject* a3640[] = {t3358, t3642};
    t3640 = shen_tail_apply_direct(ctx, "shen.gc", 2, a3640);
  }
    t3635 = t3640;
  } else {
  KLObject* t3656 = shen_false(ctx);
    t3635 = t3656;
  }
    t3549 = t3635;
  }
    t3536 = t3549;
  } else {
  KLObject* t3657 = shen_false(ctx);
    t3536 = t3657;
  }
    t3530 = t3536;
  } else {
  KLObject* t3658 = shen_false(ctx);
    t3530 = t3658;
  }
    t3526 = t3530;
  } else {
    t3526 = t3488;
  }
    t3484 = t3526;
  } else {
    t3484 = t3446;
  }
    t3442 = t3484;
  } else {
    t3442 = t3404;
  }
    t3400 = t3442;
  } else {
    t3400 = t3362;
  }
    return t3400;
  }
}

static KLObject* native_kl_shen_2eby_2dhypothesis_23 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t3663 = objects[0];
    KLObject* t3664 = objects[1];
    KLObject* t3665 = objects[2];
    KLObject* t3666 = objects[3];
    KLObject* t3667 = objects[4];
    KLObject* t3668 = objects[5];
    KLObject* t3669 = objects[6];
  tail_start_kl_shen_2eby_2dhypothesis_23: ;
  KLObject* t3671;
  {
    KLObject* a3671[] = {t3667};
    t3671 = shen_apply_direct(ctx, "shen.unlocked?", 1, a3671);
  }
  KLObject* t3670;
  if (!shen_is_boolean(ctx, t3671))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t3671)) {
  KLObject* t3673;
  {
    KLObject* a3673[] = {t3665, t3666};
    t3673 = shen_apply_direct(ctx, "shen.lazyderef", 2, a3673);
  }
  KLObject* t3678 = shen_cons_p(ctx, t3673);
  KLObject* t3676;
  if (!shen_is_boolean(ctx, t3678))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t3678)) {
  KLObject* t3681 = shen_hd(ctx, t3673);
  KLObject* t3679;
  {
    KLObject* a3679[] = {t3681, t3666};
    t3679 = shen_apply_direct(ctx, "shen.lazyderef", 2, a3679);
  }
  KLObject* t3685 = shen_cons_p(ctx, t3679);
  KLObject* t3683;
  if (!shen_is_boolean(ctx, t3685))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t3685)) {
  KLObject* t3687 = shen_hd(ctx, t3679);
  KLObject* t3690 = shen_tl(ctx, t3679);
  KLObject* t3688;
  {
    KLObject* a3688[] = {t3690, t3666};
    t3688 = shen_apply_direct(ctx, "shen.lazyderef", 2, a3688);
  }
  KLObject* t3694 = shen_cons_p(ctx, t3688);
  KLObject* t3692;
  if (!shen_is_boolean(ctx, t3694))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t3694)) {
  KLObject* t3696 = shen_hd(ctx, t3688);
  KLObject* t3699 = shen_tl(ctx, t3688);
  KLObject* t3697;
  {
    KLObject* a3697[] = {t3699, t3666};
    t3697 = shen_apply_direct(ctx, "shen.lazyderef", 2, a3697);
  }
  KLObject* t3703 = shen_cons_p(ctx, t3697);
  KLObject* t3701;
  if (!shen_is_boolean(ctx, t3703))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t3703)) {
  KLObject* t3705 = shen_hd(ctx, t3697);
  KLObject* t3708 = shen_tl(ctx, t3697);
  KLObject* t3706;
  {
    KLObject* a3706[] = {t3708, t3666};
    t3706 = shen_apply_direct(ctx, "shen.lazyderef", 2, a3706);
  }
  KLObject* t3712 = shen_empty_list(ctx);
  KLObject* t3713 = shen_eq(ctx, t3706, t3712);
  KLObject* t3710;
  if (!shen_is_boolean(ctx, t3713))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t3713)) {
  KLObject* t3714 = shen_apply_direct(ctx, "shen.incinfs", 0, NULL);
  KLObject* t3716;
  {
    KLObject* a3716[] = {t3696, t3666};
    t3716 = shen_apply_direct(ctx, "shen.deref", 2, a3716);
  }
  KLObject* t3720 = shen_string(ctx, ":");
  KLObject* t3719;
  {
    KLObject* a3719[] = {t3720};
    t3719 = shen_apply_direct(ctx, "intern", 1, a3719);
  }
  KLObject* t3721 = shen_eq(ctx, t3716, t3719);
  KLObject* t3725;
  {
    Vector* caps_91 = shen_vector(ctx, 8);
    shen_vector_set(ctx, caps_91, 0, t3663);
    shen_vector_set(ctx, caps_91, 1, t3666);
    shen_vector_set(ctx, caps_91, 2, t3687);
    shen_vector_set(ctx, caps_91, 3, t3667);
    shen_vector_set(ctx, caps_91, 4, t3668);
    shen_vector_set(ctx, caps_91, 5, t3664);
    shen_vector_set(ctx, caps_91, 6, t3705);
    shen_vector_set(ctx, caps_91, 7, t3669);
    t3725 = shen_native_closure(ctx, 0, &lambda_91, caps_91);
  }
  KLObject* t3715;
  {
    KLObject* a3715[] = {t3721, t3666, t3667, t3668, t3725};
    t3715 = shen_apply_direct(ctx, "when", 5, a3715);
  }
    t3710 = t3715;
  } else {
  KLObject* t3759 = shen_false(ctx);
    t3710 = t3759;
  }
    t3701 = t3710;
  } else {
  KLObject* t3760 = shen_false(ctx);
    t3701 = t3760;
  }
    t3692 = t3701;
  } else {
  KLObject* t3761 = shen_false(ctx);
    t3692 = t3761;
  }
    t3683 = t3692;
  } else {
  KLObject* t3762 = shen_false(ctx);
    t3683 = t3762;
  }
    t3676 = t3683;
  } else {
  KLObject* t3763 = shen_false(ctx);
    t3676 = t3763;
  }
    t3670 = t3676;
  } else {
  KLObject* t3764 = shen_false(ctx);
    t3670 = t3764;
  }
  KLObject* t3767 = shen_false(ctx);
  KLObject* t3768 = shen_eq(ctx, t3670, t3767);
  KLObject* t3765;
  if (!shen_is_boolean(ctx, t3768))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t3768)) {
  KLObject* t3770;
  {
    KLObject* a3770[] = {t3667};
    t3770 = shen_apply_direct(ctx, "shen.unlocked?", 1, a3770);
  }
  KLObject* t3769;
  if (!shen_is_boolean(ctx, t3770))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t3770)) {
  KLObject* t3772;
  {
    KLObject* a3772[] = {t3665, t3666};
    t3772 = shen_apply_direct(ctx, "shen.lazyderef", 2, a3772);
  }
  KLObject* t3777 = shen_cons_p(ctx, t3772);
  KLObject* t3775;
  if (!shen_is_boolean(ctx, t3777))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t3777)) {
  KLObject* t3779 = shen_tl(ctx, t3772);
  KLObject* t3780 = shen_apply_direct(ctx, "shen.incinfs", 0, NULL);
  {
    KLObject* n3788_0 = t3663;
    KLObject* n3788_1 = t3664;
    KLObject* n3788_2 = t3779;
    KLObject* n3788_3 = t3666;
    KLObject* n3788_4 = t3667;
    KLObject* n3788_5 = t3668;
    KLObject* n3788_6 = t3669;
    t3663 = n3788_0;
    t3664 = n3788_1;
    t3665 = n3788_2;
    t3666 = n3788_3;
    t3667 = n3788_4;
    t3668 = n3788_5;
    t3669 = n3788_6;
    goto tail_start_kl_shen_2eby_2dhypothesis_23;
  }
  KLObject* t3788 = NULL;
    t3775 = t3788;
  } else {
  KLObject* t3789 = shen_false(ctx);
    t3775 = t3789;
  }
    t3769 = t3775;
  } else {
  KLObject* t3790 = shen_false(ctx);
    t3769 = t3790;
  }
    t3765 = t3769;
  } else {
    t3765 = t3670;
  }
    return t3765;
  }
}

static KLObject* native_kl_shen_2elookupsig_24 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t3792 = objects[0];
    KLObject* t3793 = objects[1];
    KLObject* t3794 = objects[2];
    KLObject* t3795 = objects[3];
    KLObject* t3796 = objects[4];
    KLObject* t3797 = objects[5];
  tail_start_kl_shen_2elookupsig_24: ;
  KLObject* t3799;
  {
    KLObject* a3799[] = {t3795};
    t3799 = shen_apply_direct(ctx, "shen.unlocked?", 1, a3799);
  }
  KLObject* t3798;
  if (!shen_is_boolean(ctx, t3799))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t3799)) {
  KLObject* t3801 = shen_apply_direct(ctx, "shen.incinfs", 0, NULL);
  KLObject* t3806 = shen_intern(ctx, "shen.*sigf*");
  KLObject* t3805;
  {
    KLObject* a3805[] = {t3806};
    t3805 = shen_apply_direct(ctx, "value", 1, a3805);
  }
  KLObject* t3803;
  {
    KLObject* a3803[] = {t3792, t3805};
    t3803 = shen_apply_direct(ctx, "assoc", 2, a3803);
  }
  KLObject* t3802;
  {
    KLObject* a3802[] = {t3803, t3793, t3794, t3795, t3796, t3797};
    t3802 = shen_tail_apply_direct(ctx, "shen.sigf", 6, a3802);
  }
    t3798 = t3802;
  } else {
  KLObject* t3812 = shen_false(ctx);
    t3798 = t3812;
  }
    return t3798;
  }
}

static KLObject* native_kl_shen_2esigf_25 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t3813 = objects[0];
    KLObject* t3814 = objects[1];
    KLObject* t3815 = objects[2];
    KLObject* t3816 = objects[3];
    KLObject* t3817 = objects[4];
    KLObject* t3818 = objects[5];
  tail_start_kl_shen_2esigf_25: ;
  KLObject* t3819;
  {
  KLObject* t3821 = shen_cons_p(ctx, t3813);
    if (!shen_is_boolean(ctx, t3821))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t3821)) {
  KLObject* t3828 = shen_tl(ctx, t3813);
  KLObject* t3826;
  {
    Vector* a3826 = shen_vector(ctx, 1);
    shen_vector_set(ctx, a3826, 0, t3814);
    t3826 = shen_apply(ctx, t3828, a3826);
  }
  KLObject* t3825;
  {
    Vector* a3825 = shen_vector(ctx, 1);
    shen_vector_set(ctx, a3825, 0, t3815);
    t3825 = shen_apply(ctx, t3826, a3825);
  }
  KLObject* t3824;
  {
    Vector* a3824 = shen_vector(ctx, 1);
    shen_vector_set(ctx, a3824, 0, t3816);
    t3824 = shen_apply(ctx, t3825, a3824);
  }
  KLObject* t3823;
  {
    Vector* a3823 = shen_vector(ctx, 1);
    shen_vector_set(ctx, a3823, 0, t3817);
    t3823 = shen_apply(ctx, t3824, a3823);
  }
  KLObject* t3822;
  {
    Vector* a3822 = shen_vector(ctx, 1);
    shen_vector_set(ctx, a3822, 0, t3818);
    t3822 = shen_tail_apply(ctx, t3823, a3822);
  }
      t3819 = t3822;
    } else {
  KLObject* t3834 = shen_true(ctx);
    if (!shen_is_boolean(ctx, t3834))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t3834)) {
  KLObject* t3835 = shen_false(ctx);
      t3819 = t3835;
    } else {
      shen_simple_error(ctx, "No true case found for cond");
      t3819 = shen_empty_list(ctx);
    }
    }
  }
    return t3819;
  }
}

static KLObject* native_kl_shen_2efreshterm_26 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t3836 = objects[0];
  tail_start_kl_shen_2efreshterm_26: ;
  KLObject* t3838 = shen_number_l(ctx, 3);
  KLObject* t3837;
  {
    KLObject* a3837[] = {t3838};
    t3837 = shen_apply_direct(ctx, "absvector", 1, a3837);
  }
  KLObject* t3841 = shen_number_l(ctx, 0);
  KLObject* t3842 = shen_intern(ctx, "shen.print-freshterm");
  KLObject* t3839;
  {
    KLObject* a3839[] = {t3837, t3841, t3842};
    t3839 = shen_apply_direct(ctx, "address->", 3, a3839);
  }
  KLObject* t3845 = shen_number_l(ctx, 1);
  KLObject* t3843;
  {
    KLObject* a3843[] = {t3839, t3845, t3836};
    t3843 = shen_apply_direct(ctx, "address->", 3, a3843);
  }
  KLObject* t3849 = shen_number_l(ctx, 2);
  KLObject* t3851 = shen_intern(ctx, "shen.*gensym*");
  KLObject* t3852 = shen_number_l(ctx, 1);
  KLObject* t3854 = shen_intern(ctx, "shen.*gensym*");
  KLObject* t3853;
  {
    KLObject* a3853[] = {t3854};
    t3853 = shen_apply_direct(ctx, "value", 1, a3853);
  }
  KLObject* t3855 = shen_add(ctx, t3852, t3853);
  KLObject* t3850;
  {
    KLObject* a3850[] = {t3851, t3855};
    t3850 = shen_apply_direct(ctx, "set", 2, a3850);
  }
  KLObject* t3847;
  {
    KLObject* a3847[] = {t3843, t3849, t3850};
    t3847 = shen_apply_direct(ctx, "address->", 3, a3847);
  }
    return t3847;
  }
}

static KLObject* native_kl_shen_2eprint_2dfreshterm_27 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t3857 = objects[0];
  tail_start_kl_shen_2eprint_2dfreshterm_27: ;
  KLObject* t3859 = shen_string(ctx, "&&");
  KLObject* t3863 = shen_number_l(ctx, 1);
  KLObject* t3861;
  {
    KLObject* a3861[] = {t3857, t3863};
    t3861 = shen_apply_direct(ctx, "<-address", 2, a3861);
  }
  KLObject* t3864 = shen_string(ctx, "");
  KLObject* t3865 = shen_intern(ctx, "shen.a");
  KLObject* t3860;
  {
    KLObject* a3860[] = {t3861, t3864, t3865};
    t3860 = shen_apply_direct(ctx, "shen.app", 3, a3860);
  }
  KLObject* t3858;
  {
    KLObject* a3858[] = {t3859, t3860};
    t3858 = shen_tail_apply_direct(ctx, "cn", 2, a3858);
  }
    return t3858;
  }
}

static KLObject* native_kl_shen_2esearch_2duser_2ddatatypes_28 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t3866 = objects[0];
    KLObject* t3867 = objects[1];
    KLObject* t3868 = objects[2];
    KLObject* t3869 = objects[3];
    KLObject* t3870 = objects[4];
    KLObject* t3871 = objects[5];
    KLObject* t3872 = objects[6];
  tail_start_kl_shen_2esearch_2duser_2ddatatypes_28: ;
  KLObject* t3874;
  {
    KLObject* a3874[] = {t3870};
    t3874 = shen_apply_direct(ctx, "shen.unlocked?", 1, a3874);
  }
  KLObject* t3873;
  if (!shen_is_boolean(ctx, t3874))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t3874)) {
  KLObject* t3876;
  {
    KLObject* a3876[] = {t3868, t3869};
    t3876 = shen_apply_direct(ctx, "shen.lazyderef", 2, a3876);
  }
  KLObject* t3881 = shen_cons_p(ctx, t3876);
  KLObject* t3879;
  if (!shen_is_boolean(ctx, t3881))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t3881)) {
  KLObject* t3884 = shen_hd(ctx, t3876);
  KLObject* t3882;
  {
    KLObject* a3882[] = {t3884, t3869};
    t3882 = shen_apply_direct(ctx, "shen.lazyderef", 2, a3882);
  }
  KLObject* t3888 = shen_cons_p(ctx, t3882);
  KLObject* t3886;
  if (!shen_is_boolean(ctx, t3888))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t3888)) {
  KLObject* t3890 = shen_tl(ctx, t3882);
  KLObject* t3891 = shen_apply_direct(ctx, "shen.incinfs", 0, NULL);
  KLObject* t3895;
  {
    KLObject* a3895[] = {t3890, t3869};
    t3895 = shen_apply_direct(ctx, "shen.deref", 2, a3895);
  }
  KLObject* t3898;
  {
    KLObject* a3898[] = {t3866, t3869};
    t3898 = shen_apply_direct(ctx, "shen.deref", 2, a3898);
  }
  KLObject* t3894;
  {
    Vector* a3894 = shen_vector(ctx, 1);
    shen_vector_set(ctx, a3894, 0, t3898);
    t3894 = shen_apply(ctx, t3895, a3894);
  }
  KLObject* t3901;
  {
    KLObject* a3901[] = {t3867, t3869};
    t3901 = shen_apply_direct(ctx, "shen.deref", 2, a3901);
  }
  KLObject* t3893;
  {
    Vector* a3893 = shen_vector(ctx, 1);
    shen_vector_set(ctx, a3893, 0, t3901);
    t3893 = shen_apply(ctx, t3894, a3893);
  }
  KLObject* t3892;
  {
    KLObject* a3892[] = {t3893, t3869, t3870, t3871, t3872};
    t3892 = shen_apply_direct(ctx, "call", 5, a3892);
  }
    t3886 = t3892;
  } else {
  KLObject* t3908 = shen_false(ctx);
    t3886 = t3908;
  }
    t3879 = t3886;
  } else {
  KLObject* t3909 = shen_false(ctx);
    t3879 = t3909;
  }
    t3873 = t3879;
  } else {
  KLObject* t3910 = shen_false(ctx);
    t3873 = t3910;
  }
  KLObject* t3913 = shen_false(ctx);
  KLObject* t3914 = shen_eq(ctx, t3873, t3913);
  KLObject* t3911;
  if (!shen_is_boolean(ctx, t3914))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t3914)) {
  KLObject* t3916;
  {
    KLObject* a3916[] = {t3870};
    t3916 = shen_apply_direct(ctx, "shen.unlocked?", 1, a3916);
  }
  KLObject* t3915;
  if (!shen_is_boolean(ctx, t3916))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t3916)) {
  KLObject* t3918;
  {
    KLObject* a3918[] = {t3868, t3869};
    t3918 = shen_apply_direct(ctx, "shen.lazyderef", 2, a3918);
  }
  KLObject* t3923 = shen_cons_p(ctx, t3918);
  KLObject* t3921;
  if (!shen_is_boolean(ctx, t3923))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t3923)) {
  KLObject* t3925 = shen_tl(ctx, t3918);
  KLObject* t3926 = shen_apply_direct(ctx, "shen.incinfs", 0, NULL);
  {
    KLObject* n3934_0 = t3866;
    KLObject* n3934_1 = t3867;
    KLObject* n3934_2 = t3925;
    KLObject* n3934_3 = t3869;
    KLObject* n3934_4 = t3870;
    KLObject* n3934_5 = t3871;
    KLObject* n3934_6 = t3872;
    t3866 = n3934_0;
    t3867 = n3934_1;
    t3868 = n3934_2;
    t3869 = n3934_3;
    t3870 = n3934_4;
    t3871 = n3934_5;
    t3872 = n3934_6;
    goto tail_start_kl_shen_2esearch_2duser_2ddatatypes_28;
  }
  KLObject* t3934 = NULL;
    t3921 = t3934;
  } else {
  KLObject* t3935 = shen_false(ctx);
    t3921 = t3935;
  }
    t3915 = t3921;
  } else {
  KLObject* t3936 = shen_false(ctx);
    t3915 = t3936;
  }
    t3911 = t3915;
  } else {
    t3911 = t3873;
  }
    return t3911;
  }
}

static KLObject* native_kl_shen_2el_2drules_29 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t3938 = objects[0];
    KLObject* t3939 = objects[1];
    KLObject* t3940 = objects[2];
    KLObject* t3941 = objects[3];
    KLObject* t3942 = objects[4];
    KLObject* t3943 = objects[5];
    KLObject* t3944 = objects[6];
  tail_start_kl_shen_2el_2drules_29: ;
  KLObject* t3946 = shen_number_l(ctx, 1);
  KLObject* t3947 = shen_add(ctx, t3943, t3946);
  KLObject* t3949;
  {
    KLObject* a3949[] = {t3942};
    t3949 = shen_apply_direct(ctx, "shen.unlocked?", 1, a3949);
  }
  KLObject* t3948;
  if (!shen_is_boolean(ctx, t3949))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t3949)) {
  KLObject* t3951;
  {
    KLObject* a3951[] = {t3938, t3941};
    t3951 = shen_apply_direct(ctx, "shen.lazyderef", 2, a3951);
  }
  KLObject* t3956 = shen_empty_list(ctx);
  KLObject* t3957 = shen_eq(ctx, t3951, t3956);
  KLObject* t3954;
  if (!shen_is_boolean(ctx, t3957))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t3957)) {
  KLObject* t3958;
  {
    KLObject* a3958[] = {t3940, t3941};
    t3958 = shen_apply_direct(ctx, "shen.lazyderef", 2, a3958);
  }
  KLObject* t3963 = shen_true(ctx);
  KLObject* t3964 = shen_eq(ctx, t3958, t3963);
  KLObject* t3961;
  if (!shen_is_boolean(ctx, t3964))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t3964)) {
  KLObject* t3965 = shen_apply_direct(ctx, "shen.incinfs", 0, NULL);
  KLObject* t3970;
  {
    Vector* caps_93 = shen_vector(ctx, 5);
    shen_vector_set(ctx, caps_93, 0, t3939);
    shen_vector_set(ctx, caps_93, 1, t3941);
    shen_vector_set(ctx, caps_93, 2, t3942);
    shen_vector_set(ctx, caps_93, 3, t3947);
    shen_vector_set(ctx, caps_93, 4, t3944);
    t3970 = shen_native_closure(ctx, 0, &lambda_93, caps_93);
  }
  KLObject* t3966;
  {
    KLObject* a3966[] = {t3941, t3942, t3947, t3970};
    t3966 = shen_apply_direct(ctx, "shen.cut", 4, a3966);
  }
    t3961 = t3966;
  } else {
  KLObject* t3983 = shen_false(ctx);
    t3961 = t3983;
  }
    t3954 = t3961;
  } else {
  KLObject* t3984 = shen_false(ctx);
    t3954 = t3984;
  }
    t3948 = t3954;
  } else {
  KLObject* t3985 = shen_false(ctx);
    t3948 = t3985;
  }
  KLObject* t3988 = shen_false(ctx);
  KLObject* t3989 = shen_eq(ctx, t3948, t3988);
  KLObject* t3986;
  if (!shen_is_boolean(ctx, t3989))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t3989)) {
  KLObject* t3991;
  {
    KLObject* a3991[] = {t3942};
    t3991 = shen_apply_direct(ctx, "shen.unlocked?", 1, a3991);
  }
  KLObject* t3990;
  if (!shen_is_boolean(ctx, t3991))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t3991)) {
  KLObject* t3993;
  {
    KLObject* a3993[] = {t3938, t3941};
    t3993 = shen_apply_direct(ctx, "shen.lazyderef", 2, a3993);
  }
  KLObject* t3998 = shen_cons_p(ctx, t3993);
  KLObject* t3996;
  if (!shen_is_boolean(ctx, t3998))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t3998)) {
  KLObject* t4001 = shen_hd(ctx, t3993);
  KLObject* t3999;
  {
    KLObject* a3999[] = {t4001, t3941};
    t3999 = shen_apply_direct(ctx, "shen.lazyderef", 2, a3999);
  }
  KLObject* t4005 = shen_cons_p(ctx, t3999);
  KLObject* t4003;
  if (!shen_is_boolean(ctx, t4005))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t4005)) {
  KLObject* t4008 = shen_hd(ctx, t3999);
  KLObject* t4006;
  {
    KLObject* a4006[] = {t4008, t3941};
    t4006 = shen_apply_direct(ctx, "shen.lazyderef", 2, a4006);
  }
  KLObject* t4012 = shen_cons_p(ctx, t4006);
  KLObject* t4010;
  if (!shen_is_boolean(ctx, t4012))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t4012)) {
  KLObject* t4015 = shen_hd(ctx, t4006);
  KLObject* t4013;
  {
    KLObject* a4013[] = {t4015, t3941};
    t4013 = shen_apply_direct(ctx, "shen.lazyderef", 2, a4013);
  }
  KLObject* t4019 = shen_intern(ctx, "cons");
  KLObject* t4020 = shen_eq(ctx, t4013, t4019);
  KLObject* t4017;
  if (!shen_is_boolean(ctx, t4020))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t4020)) {
  KLObject* t4023 = shen_tl(ctx, t4006);
  KLObject* t4021;
  {
    KLObject* a4021[] = {t4023, t3941};
    t4021 = shen_apply_direct(ctx, "shen.lazyderef", 2, a4021);
  }
  KLObject* t4027 = shen_cons_p(ctx, t4021);
  KLObject* t4025;
  if (!shen_is_boolean(ctx, t4027))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t4027)) {
  KLObject* t4029 = shen_hd(ctx, t4021);
  KLObject* t4032 = shen_tl(ctx, t4021);
  KLObject* t4030;
  {
    KLObject* a4030[] = {t4032, t3941};
    t4030 = shen_apply_direct(ctx, "shen.lazyderef", 2, a4030);
  }
  KLObject* t4036 = shen_cons_p(ctx, t4030);
  KLObject* t4034;
  if (!shen_is_boolean(ctx, t4036))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t4036)) {
  KLObject* t4038 = shen_hd(ctx, t4030);
  KLObject* t4041 = shen_tl(ctx, t4030);
  KLObject* t4039;
  {
    KLObject* a4039[] = {t4041, t3941};
    t4039 = shen_apply_direct(ctx, "shen.lazyderef", 2, a4039);
  }
  KLObject* t4045 = shen_empty_list(ctx);
  KLObject* t4046 = shen_eq(ctx, t4039, t4045);
  KLObject* t4043;
  if (!shen_is_boolean(ctx, t4046))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t4046)) {
  KLObject* t4049 = shen_tl(ctx, t3999);
  KLObject* t4047;
  {
    KLObject* a4047[] = {t4049, t3941};
    t4047 = shen_apply_direct(ctx, "shen.lazyderef", 2, a4047);
  }
  KLObject* t4053 = shen_cons_p(ctx, t4047);
  KLObject* t4051;
  if (!shen_is_boolean(ctx, t4053))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t4053)) {
  KLObject* t4055 = shen_hd(ctx, t4047);
  KLObject* t4058 = shen_tl(ctx, t4047);
  KLObject* t4056;
  {
    KLObject* a4056[] = {t4058, t3941};
    t4056 = shen_apply_direct(ctx, "shen.lazyderef", 2, a4056);
  }
  KLObject* t4062 = shen_cons_p(ctx, t4056);
  KLObject* t4060;
  if (!shen_is_boolean(ctx, t4062))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t4062)) {
  KLObject* t4065 = shen_hd(ctx, t4056);
  KLObject* t4063;
  {
    KLObject* a4063[] = {t4065, t3941};
    t4063 = shen_apply_direct(ctx, "shen.lazyderef", 2, a4063);
  }
  KLObject* t4069 = shen_cons_p(ctx, t4063);
  KLObject* t4067;
  if (!shen_is_boolean(ctx, t4069))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t4069)) {
  KLObject* t4072 = shen_hd(ctx, t4063);
  KLObject* t4070;
  {
    KLObject* a4070[] = {t4072, t3941};
    t4070 = shen_apply_direct(ctx, "shen.lazyderef", 2, a4070);
  }
  KLObject* t4076 = shen_intern(ctx, "list");
  KLObject* t4077 = shen_eq(ctx, t4070, t4076);
  KLObject* t4074;
  if (!shen_is_boolean(ctx, t4077))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t4077)) {
  KLObject* t4080 = shen_tl(ctx, t4063);
  KLObject* t4078;
  {
    KLObject* a4078[] = {t4080, t3941};
    t4078 = shen_apply_direct(ctx, "shen.lazyderef", 2, a4078);
  }
  KLObject* t4084 = shen_cons_p(ctx, t4078);
  KLObject* t4082;
  if (!shen_is_boolean(ctx, t4084))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t4084)) {
  KLObject* t4086 = shen_hd(ctx, t4078);
  KLObject* t4089 = shen_tl(ctx, t4078);
  KLObject* t4087;
  {
    KLObject* a4087[] = {t4089, t3941};
    t4087 = shen_apply_direct(ctx, "shen.lazyderef", 2, a4087);
  }
  KLObject* t4093 = shen_empty_list(ctx);
  KLObject* t4094 = shen_eq(ctx, t4087, t4093);
  KLObject* t4091;
  if (!shen_is_boolean(ctx, t4094))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t4094)) {
  KLObject* t4097 = shen_tl(ctx, t4056);
  KLObject* t4095;
  {
    KLObject* a4095[] = {t4097, t3941};
    t4095 = shen_apply_direct(ctx, "shen.lazyderef", 2, a4095);
  }
  KLObject* t4101 = shen_empty_list(ctx);
  KLObject* t4102 = shen_eq(ctx, t4095, t4101);
  KLObject* t4099;
  if (!shen_is_boolean(ctx, t4102))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t4102)) {
  KLObject* t4104 = shen_tl(ctx, t3993);
  KLObject* t4105 = shen_apply_direct(ctx, "shen.incinfs", 0, NULL);
  KLObject* t4107;
  {
    KLObject* a4107[] = {t4055, t3941};
    t4107 = shen_apply_direct(ctx, "shen.deref", 2, a4107);
  }
  KLObject* t4111 = shen_string(ctx, ":");
  KLObject* t4110;
  {
    KLObject* a4110[] = {t4111};
    t4110 = shen_apply_direct(ctx, "intern", 1, a4110);
  }
  KLObject* t4112 = shen_eq(ctx, t4107, t4110);
  KLObject* t4116;
  {
    Vector* caps_94 = shen_vector(ctx, 10);
    shen_vector_set(ctx, caps_94, 0, t3941);
    shen_vector_set(ctx, caps_94, 1, t3942);
    shen_vector_set(ctx, caps_94, 2, t3947);
    shen_vector_set(ctx, caps_94, 3, t4029);
    shen_vector_set(ctx, caps_94, 4, t4055);
    shen_vector_set(ctx, caps_94, 5, t4086);
    shen_vector_set(ctx, caps_94, 6, t4038);
    shen_vector_set(ctx, caps_94, 7, t4104);
    shen_vector_set(ctx, caps_94, 8, t3939);
    shen_vector_set(ctx, caps_94, 9, t3944);
    t4116 = shen_native_closure(ctx, 0, &lambda_94, caps_94);
  }
  KLObject* t4106;
  {
    KLObject* a4106[] = {t4112, t3941, t3942, t3947, t4116};
    t4106 = shen_apply_direct(ctx, "when", 5, a4106);
  }
    t4099 = t4106;
  } else {
  KLObject* t4170 = shen_false(ctx);
    t4099 = t4170;
  }
    t4091 = t4099;
  } else {
  KLObject* t4171 = shen_false(ctx);
    t4091 = t4171;
  }
    t4082 = t4091;
  } else {
  KLObject* t4172 = shen_false(ctx);
    t4082 = t4172;
  }
    t4074 = t4082;
  } else {
  KLObject* t4173 = shen_false(ctx);
    t4074 = t4173;
  }
    t4067 = t4074;
  } else {
  KLObject* t4174 = shen_false(ctx);
    t4067 = t4174;
  }
    t4060 = t4067;
  } else {
  KLObject* t4175 = shen_false(ctx);
    t4060 = t4175;
  }
    t4051 = t4060;
  } else {
  KLObject* t4176 = shen_false(ctx);
    t4051 = t4176;
  }
    t4043 = t4051;
  } else {
  KLObject* t4177 = shen_false(ctx);
    t4043 = t4177;
  }
    t4034 = t4043;
  } else {
  KLObject* t4178 = shen_false(ctx);
    t4034 = t4178;
  }
    t4025 = t4034;
  } else {
  KLObject* t4179 = shen_false(ctx);
    t4025 = t4179;
  }
    t4017 = t4025;
  } else {
  KLObject* t4180 = shen_false(ctx);
    t4017 = t4180;
  }
    t4010 = t4017;
  } else {
  KLObject* t4181 = shen_false(ctx);
    t4010 = t4181;
  }
    t4003 = t4010;
  } else {
  KLObject* t4182 = shen_false(ctx);
    t4003 = t4182;
  }
    t3996 = t4003;
  } else {
  KLObject* t4183 = shen_false(ctx);
    t3996 = t4183;
  }
    t3990 = t3996;
  } else {
  KLObject* t4184 = shen_false(ctx);
    t3990 = t4184;
  }
  KLObject* t4187 = shen_false(ctx);
  KLObject* t4188 = shen_eq(ctx, t3990, t4187);
  KLObject* t4185;
  if (!shen_is_boolean(ctx, t4188))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t4188)) {
  KLObject* t4190;
  {
    KLObject* a4190[] = {t3942};
    t4190 = shen_apply_direct(ctx, "shen.unlocked?", 1, a4190);
  }
  KLObject* t4189;
  if (!shen_is_boolean(ctx, t4190))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t4190)) {
  KLObject* t4192;
  {
    KLObject* a4192[] = {t3938, t3941};
    t4192 = shen_apply_direct(ctx, "shen.lazyderef", 2, a4192);
  }
  KLObject* t4197 = shen_cons_p(ctx, t4192);
  KLObject* t4195;
  if (!shen_is_boolean(ctx, t4197))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t4197)) {
  KLObject* t4200 = shen_hd(ctx, t4192);
  KLObject* t4198;
  {
    KLObject* a4198[] = {t4200, t3941};
    t4198 = shen_apply_direct(ctx, "shen.lazyderef", 2, a4198);
  }
  KLObject* t4204 = shen_cons_p(ctx, t4198);
  KLObject* t4202;
  if (!shen_is_boolean(ctx, t4204))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t4204)) {
  KLObject* t4207 = shen_hd(ctx, t4198);
  KLObject* t4205;
  {
    KLObject* a4205[] = {t4207, t3941};
    t4205 = shen_apply_direct(ctx, "shen.lazyderef", 2, a4205);
  }
  KLObject* t4211 = shen_cons_p(ctx, t4205);
  KLObject* t4209;
  if (!shen_is_boolean(ctx, t4211))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t4211)) {
  KLObject* t4214 = shen_hd(ctx, t4205);
  KLObject* t4212;
  {
    KLObject* a4212[] = {t4214, t3941};
    t4212 = shen_apply_direct(ctx, "shen.lazyderef", 2, a4212);
  }
  KLObject* t4218 = shen_intern(ctx, "@p");
  KLObject* t4219 = shen_eq(ctx, t4212, t4218);
  KLObject* t4216;
  if (!shen_is_boolean(ctx, t4219))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t4219)) {
  KLObject* t4222 = shen_tl(ctx, t4205);
  KLObject* t4220;
  {
    KLObject* a4220[] = {t4222, t3941};
    t4220 = shen_apply_direct(ctx, "shen.lazyderef", 2, a4220);
  }
  KLObject* t4226 = shen_cons_p(ctx, t4220);
  KLObject* t4224;
  if (!shen_is_boolean(ctx, t4226))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t4226)) {
  KLObject* t4228 = shen_hd(ctx, t4220);
  KLObject* t4231 = shen_tl(ctx, t4220);
  KLObject* t4229;
  {
    KLObject* a4229[] = {t4231, t3941};
    t4229 = shen_apply_direct(ctx, "shen.lazyderef", 2, a4229);
  }
  KLObject* t4235 = shen_cons_p(ctx, t4229);
  KLObject* t4233;
  if (!shen_is_boolean(ctx, t4235))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t4235)) {
  KLObject* t4237 = shen_hd(ctx, t4229);
  KLObject* t4240 = shen_tl(ctx, t4229);
  KLObject* t4238;
  {
    KLObject* a4238[] = {t4240, t3941};
    t4238 = shen_apply_direct(ctx, "shen.lazyderef", 2, a4238);
  }
  KLObject* t4244 = shen_empty_list(ctx);
  KLObject* t4245 = shen_eq(ctx, t4238, t4244);
  KLObject* t4242;
  if (!shen_is_boolean(ctx, t4245))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t4245)) {
  KLObject* t4248 = shen_tl(ctx, t4198);
  KLObject* t4246;
  {
    KLObject* a4246[] = {t4248, t3941};
    t4246 = shen_apply_direct(ctx, "shen.lazyderef", 2, a4246);
  }
  KLObject* t4252 = shen_cons_p(ctx, t4246);
  KLObject* t4250;
  if (!shen_is_boolean(ctx, t4252))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t4252)) {
  KLObject* t4254 = shen_hd(ctx, t4246);
  KLObject* t4257 = shen_tl(ctx, t4246);
  KLObject* t4255;
  {
    KLObject* a4255[] = {t4257, t3941};
    t4255 = shen_apply_direct(ctx, "shen.lazyderef", 2, a4255);
  }
  KLObject* t4261 = shen_cons_p(ctx, t4255);
  KLObject* t4259;
  if (!shen_is_boolean(ctx, t4261))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t4261)) {
  KLObject* t4264 = shen_hd(ctx, t4255);
  KLObject* t4262;
  {
    KLObject* a4262[] = {t4264, t3941};
    t4262 = shen_apply_direct(ctx, "shen.lazyderef", 2, a4262);
  }
  KLObject* t4268 = shen_cons_p(ctx, t4262);
  KLObject* t4266;
  if (!shen_is_boolean(ctx, t4268))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t4268)) {
  KLObject* t4270 = shen_hd(ctx, t4262);
  KLObject* t4273 = shen_tl(ctx, t4262);
  KLObject* t4271;
  {
    KLObject* a4271[] = {t4273, t3941};
    t4271 = shen_apply_direct(ctx, "shen.lazyderef", 2, a4271);
  }
  KLObject* t4277 = shen_cons_p(ctx, t4271);
  KLObject* t4275;
  if (!shen_is_boolean(ctx, t4277))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t4277)) {
  KLObject* t4280 = shen_hd(ctx, t4271);
  KLObject* t4278;
  {
    KLObject* a4278[] = {t4280, t3941};
    t4278 = shen_apply_direct(ctx, "shen.lazyderef", 2, a4278);
  }
  KLObject* t4284 = shen_intern(ctx, "*");
  KLObject* t4285 = shen_eq(ctx, t4278, t4284);
  KLObject* t4282;
  if (!shen_is_boolean(ctx, t4285))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t4285)) {
  KLObject* t4288 = shen_tl(ctx, t4271);
  KLObject* t4286;
  {
    KLObject* a4286[] = {t4288, t3941};
    t4286 = shen_apply_direct(ctx, "shen.lazyderef", 2, a4286);
  }
  KLObject* t4292 = shen_cons_p(ctx, t4286);
  KLObject* t4290;
  if (!shen_is_boolean(ctx, t4292))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t4292)) {
  KLObject* t4294 = shen_hd(ctx, t4286);
  KLObject* t4297 = shen_tl(ctx, t4286);
  KLObject* t4295;
  {
    KLObject* a4295[] = {t4297, t3941};
    t4295 = shen_apply_direct(ctx, "shen.lazyderef", 2, a4295);
  }
  KLObject* t4301 = shen_empty_list(ctx);
  KLObject* t4302 = shen_eq(ctx, t4295, t4301);
  KLObject* t4299;
  if (!shen_is_boolean(ctx, t4302))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t4302)) {
  KLObject* t4305 = shen_tl(ctx, t4255);
  KLObject* t4303;
  {
    KLObject* a4303[] = {t4305, t3941};
    t4303 = shen_apply_direct(ctx, "shen.lazyderef", 2, a4303);
  }
  KLObject* t4309 = shen_empty_list(ctx);
  KLObject* t4310 = shen_eq(ctx, t4303, t4309);
  KLObject* t4307;
  if (!shen_is_boolean(ctx, t4310))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t4310)) {
  KLObject* t4312 = shen_tl(ctx, t4192);
  KLObject* t4313 = shen_apply_direct(ctx, "shen.incinfs", 0, NULL);
  KLObject* t4315;
  {
    KLObject* a4315[] = {t4254, t3941};
    t4315 = shen_apply_direct(ctx, "shen.deref", 2, a4315);
  }
  KLObject* t4319 = shen_string(ctx, ":");
  KLObject* t4318;
  {
    KLObject* a4318[] = {t4319};
    t4318 = shen_apply_direct(ctx, "intern", 1, a4318);
  }
  KLObject* t4320 = shen_eq(ctx, t4315, t4318);
  KLObject* t4324;
  {
    Vector* caps_96 = shen_vector(ctx, 11);
    shen_vector_set(ctx, caps_96, 0, t3941);
    shen_vector_set(ctx, caps_96, 1, t3942);
    shen_vector_set(ctx, caps_96, 2, t3947);
    shen_vector_set(ctx, caps_96, 3, t4228);
    shen_vector_set(ctx, caps_96, 4, t4254);
    shen_vector_set(ctx, caps_96, 5, t4270);
    shen_vector_set(ctx, caps_96, 6, t4237);
    shen_vector_set(ctx, caps_96, 7, t4294);
    shen_vector_set(ctx, caps_96, 8, t4312);
    shen_vector_set(ctx, caps_96, 9, t3939);
    shen_vector_set(ctx, caps_96, 10, t3944);
    t4324 = shen_native_closure(ctx, 0, &lambda_96, caps_96);
  }
  KLObject* t4314;
  {
    KLObject* a4314[] = {t4320, t3941, t3942, t3947, t4324};
    t4314 = shen_apply_direct(ctx, "when", 5, a4314);
  }
    t4307 = t4314;
  } else {
  KLObject* t4376 = shen_false(ctx);
    t4307 = t4376;
  }
    t4299 = t4307;
  } else {
  KLObject* t4377 = shen_false(ctx);
    t4299 = t4377;
  }
    t4290 = t4299;
  } else {
  KLObject* t4378 = shen_false(ctx);
    t4290 = t4378;
  }
    t4282 = t4290;
  } else {
  KLObject* t4379 = shen_false(ctx);
    t4282 = t4379;
  }
    t4275 = t4282;
  } else {
  KLObject* t4380 = shen_false(ctx);
    t4275 = t4380;
  }
    t4266 = t4275;
  } else {
  KLObject* t4381 = shen_false(ctx);
    t4266 = t4381;
  }
    t4259 = t4266;
  } else {
  KLObject* t4382 = shen_false(ctx);
    t4259 = t4382;
  }
    t4250 = t4259;
  } else {
  KLObject* t4383 = shen_false(ctx);
    t4250 = t4383;
  }
    t4242 = t4250;
  } else {
  KLObject* t4384 = shen_false(ctx);
    t4242 = t4384;
  }
    t4233 = t4242;
  } else {
  KLObject* t4385 = shen_false(ctx);
    t4233 = t4385;
  }
    t4224 = t4233;
  } else {
  KLObject* t4386 = shen_false(ctx);
    t4224 = t4386;
  }
    t4216 = t4224;
  } else {
  KLObject* t4387 = shen_false(ctx);
    t4216 = t4387;
  }
    t4209 = t4216;
  } else {
  KLObject* t4388 = shen_false(ctx);
    t4209 = t4388;
  }
    t4202 = t4209;
  } else {
  KLObject* t4389 = shen_false(ctx);
    t4202 = t4389;
  }
    t4195 = t4202;
  } else {
  KLObject* t4390 = shen_false(ctx);
    t4195 = t4390;
  }
    t4189 = t4195;
  } else {
  KLObject* t4391 = shen_false(ctx);
    t4189 = t4391;
  }
  KLObject* t4394 = shen_false(ctx);
  KLObject* t4395 = shen_eq(ctx, t4189, t4394);
  KLObject* t4392;
  if (!shen_is_boolean(ctx, t4395))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t4395)) {
  KLObject* t4397;
  {
    KLObject* a4397[] = {t3942};
    t4397 = shen_apply_direct(ctx, "shen.unlocked?", 1, a4397);
  }
  KLObject* t4396;
  if (!shen_is_boolean(ctx, t4397))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t4397)) {
  KLObject* t4399;
  {
    KLObject* a4399[] = {t3938, t3941};
    t4399 = shen_apply_direct(ctx, "shen.lazyderef", 2, a4399);
  }
  KLObject* t4404 = shen_cons_p(ctx, t4399);
  KLObject* t4402;
  if (!shen_is_boolean(ctx, t4404))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t4404)) {
  KLObject* t4407 = shen_hd(ctx, t4399);
  KLObject* t4405;
  {
    KLObject* a4405[] = {t4407, t3941};
    t4405 = shen_apply_direct(ctx, "shen.lazyderef", 2, a4405);
  }
  KLObject* t4411 = shen_cons_p(ctx, t4405);
  KLObject* t4409;
  if (!shen_is_boolean(ctx, t4411))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t4411)) {
  KLObject* t4414 = shen_hd(ctx, t4405);
  KLObject* t4412;
  {
    KLObject* a4412[] = {t4414, t3941};
    t4412 = shen_apply_direct(ctx, "shen.lazyderef", 2, a4412);
  }
  KLObject* t4418 = shen_cons_p(ctx, t4412);
  KLObject* t4416;
  if (!shen_is_boolean(ctx, t4418))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t4418)) {
  KLObject* t4421 = shen_hd(ctx, t4412);
  KLObject* t4419;
  {
    KLObject* a4419[] = {t4421, t3941};
    t4419 = shen_apply_direct(ctx, "shen.lazyderef", 2, a4419);
  }
  KLObject* t4425 = shen_intern(ctx, "@s");
  KLObject* t4426 = shen_eq(ctx, t4419, t4425);
  KLObject* t4423;
  if (!shen_is_boolean(ctx, t4426))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t4426)) {
  KLObject* t4429 = shen_tl(ctx, t4412);
  KLObject* t4427;
  {
    KLObject* a4427[] = {t4429, t3941};
    t4427 = shen_apply_direct(ctx, "shen.lazyderef", 2, a4427);
  }
  KLObject* t4433 = shen_cons_p(ctx, t4427);
  KLObject* t4431;
  if (!shen_is_boolean(ctx, t4433))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t4433)) {
  KLObject* t4435 = shen_hd(ctx, t4427);
  KLObject* t4438 = shen_tl(ctx, t4427);
  KLObject* t4436;
  {
    KLObject* a4436[] = {t4438, t3941};
    t4436 = shen_apply_direct(ctx, "shen.lazyderef", 2, a4436);
  }
  KLObject* t4442 = shen_cons_p(ctx, t4436);
  KLObject* t4440;
  if (!shen_is_boolean(ctx, t4442))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t4442)) {
  KLObject* t4444 = shen_hd(ctx, t4436);
  KLObject* t4447 = shen_tl(ctx, t4436);
  KLObject* t4445;
  {
    KLObject* a4445[] = {t4447, t3941};
    t4445 = shen_apply_direct(ctx, "shen.lazyderef", 2, a4445);
  }
  KLObject* t4451 = shen_empty_list(ctx);
  KLObject* t4452 = shen_eq(ctx, t4445, t4451);
  KLObject* t4449;
  if (!shen_is_boolean(ctx, t4452))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t4452)) {
  KLObject* t4455 = shen_tl(ctx, t4405);
  KLObject* t4453;
  {
    KLObject* a4453[] = {t4455, t3941};
    t4453 = shen_apply_direct(ctx, "shen.lazyderef", 2, a4453);
  }
  KLObject* t4459 = shen_cons_p(ctx, t4453);
  KLObject* t4457;
  if (!shen_is_boolean(ctx, t4459))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t4459)) {
  KLObject* t4461 = shen_hd(ctx, t4453);
  KLObject* t4464 = shen_tl(ctx, t4453);
  KLObject* t4462;
  {
    KLObject* a4462[] = {t4464, t3941};
    t4462 = shen_apply_direct(ctx, "shen.lazyderef", 2, a4462);
  }
  KLObject* t4468 = shen_cons_p(ctx, t4462);
  KLObject* t4466;
  if (!shen_is_boolean(ctx, t4468))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t4468)) {
  KLObject* t4471 = shen_hd(ctx, t4462);
  KLObject* t4469;
  {
    KLObject* a4469[] = {t4471, t3941};
    t4469 = shen_apply_direct(ctx, "shen.lazyderef", 2, a4469);
  }
  KLObject* t4475 = shen_intern(ctx, "string");
  KLObject* t4476 = shen_eq(ctx, t4469, t4475);
  KLObject* t4473;
  if (!shen_is_boolean(ctx, t4476))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t4476)) {
  KLObject* t4479 = shen_tl(ctx, t4462);
  KLObject* t4477;
  {
    KLObject* a4477[] = {t4479, t3941};
    t4477 = shen_apply_direct(ctx, "shen.lazyderef", 2, a4477);
  }
  KLObject* t4483 = shen_empty_list(ctx);
  KLObject* t4484 = shen_eq(ctx, t4477, t4483);
  KLObject* t4481;
  if (!shen_is_boolean(ctx, t4484))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t4484)) {
  KLObject* t4486 = shen_tl(ctx, t4399);
  KLObject* t4487 = shen_apply_direct(ctx, "shen.incinfs", 0, NULL);
  KLObject* t4489;
  {
    KLObject* a4489[] = {t4461, t3941};
    t4489 = shen_apply_direct(ctx, "shen.deref", 2, a4489);
  }
  KLObject* t4493 = shen_string(ctx, ":");
  KLObject* t4492;
  {
    KLObject* a4492[] = {t4493};
    t4492 = shen_apply_direct(ctx, "intern", 1, a4492);
  }
  KLObject* t4494 = shen_eq(ctx, t4489, t4492);
  KLObject* t4498;
  {
    Vector* caps_98 = shen_vector(ctx, 9);
    shen_vector_set(ctx, caps_98, 0, t3941);
    shen_vector_set(ctx, caps_98, 1, t3942);
    shen_vector_set(ctx, caps_98, 2, t3947);
    shen_vector_set(ctx, caps_98, 3, t4435);
    shen_vector_set(ctx, caps_98, 4, t4461);
    shen_vector_set(ctx, caps_98, 5, t4444);
    shen_vector_set(ctx, caps_98, 6, t4486);
    shen_vector_set(ctx, caps_98, 7, t3939);
    shen_vector_set(ctx, caps_98, 8, t3944);
    t4498 = shen_native_closure(ctx, 0, &lambda_98, caps_98);
  }
  KLObject* t4488;
  {
    KLObject* a4488[] = {t4494, t3941, t3942, t3947, t4498};
    t4488 = shen_apply_direct(ctx, "when", 5, a4488);
  }
    t4481 = t4488;
  } else {
  KLObject* t4546 = shen_false(ctx);
    t4481 = t4546;
  }
    t4473 = t4481;
  } else {
  KLObject* t4547 = shen_false(ctx);
    t4473 = t4547;
  }
    t4466 = t4473;
  } else {
  KLObject* t4548 = shen_false(ctx);
    t4466 = t4548;
  }
    t4457 = t4466;
  } else {
  KLObject* t4549 = shen_false(ctx);
    t4457 = t4549;
  }
    t4449 = t4457;
  } else {
  KLObject* t4550 = shen_false(ctx);
    t4449 = t4550;
  }
    t4440 = t4449;
  } else {
  KLObject* t4551 = shen_false(ctx);
    t4440 = t4551;
  }
    t4431 = t4440;
  } else {
  KLObject* t4552 = shen_false(ctx);
    t4431 = t4552;
  }
    t4423 = t4431;
  } else {
  KLObject* t4553 = shen_false(ctx);
    t4423 = t4553;
  }
    t4416 = t4423;
  } else {
  KLObject* t4554 = shen_false(ctx);
    t4416 = t4554;
  }
    t4409 = t4416;
  } else {
  KLObject* t4555 = shen_false(ctx);
    t4409 = t4555;
  }
    t4402 = t4409;
  } else {
  KLObject* t4556 = shen_false(ctx);
    t4402 = t4556;
  }
    t4396 = t4402;
  } else {
  KLObject* t4557 = shen_false(ctx);
    t4396 = t4557;
  }
  KLObject* t4560 = shen_false(ctx);
  KLObject* t4561 = shen_eq(ctx, t4396, t4560);
  KLObject* t4558;
  if (!shen_is_boolean(ctx, t4561))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t4561)) {
  KLObject* t4563;
  {
    KLObject* a4563[] = {t3942};
    t4563 = shen_apply_direct(ctx, "shen.unlocked?", 1, a4563);
  }
  KLObject* t4562;
  if (!shen_is_boolean(ctx, t4563))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t4563)) {
  KLObject* t4565;
  {
    KLObject* a4565[] = {t3938, t3941};
    t4565 = shen_apply_direct(ctx, "shen.lazyderef", 2, a4565);
  }
  KLObject* t4570 = shen_cons_p(ctx, t4565);
  KLObject* t4568;
  if (!shen_is_boolean(ctx, t4570))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t4570)) {
  KLObject* t4573 = shen_hd(ctx, t4565);
  KLObject* t4571;
  {
    KLObject* a4571[] = {t4573, t3941};
    t4571 = shen_apply_direct(ctx, "shen.lazyderef", 2, a4571);
  }
  KLObject* t4577 = shen_cons_p(ctx, t4571);
  KLObject* t4575;
  if (!shen_is_boolean(ctx, t4577))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t4577)) {
  KLObject* t4580 = shen_hd(ctx, t4571);
  KLObject* t4578;
  {
    KLObject* a4578[] = {t4580, t3941};
    t4578 = shen_apply_direct(ctx, "shen.lazyderef", 2, a4578);
  }
  KLObject* t4584 = shen_cons_p(ctx, t4578);
  KLObject* t4582;
  if (!shen_is_boolean(ctx, t4584))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t4584)) {
  KLObject* t4587 = shen_hd(ctx, t4578);
  KLObject* t4585;
  {
    KLObject* a4585[] = {t4587, t3941};
    t4585 = shen_apply_direct(ctx, "shen.lazyderef", 2, a4585);
  }
  KLObject* t4591 = shen_intern(ctx, "@v");
  KLObject* t4592 = shen_eq(ctx, t4585, t4591);
  KLObject* t4589;
  if (!shen_is_boolean(ctx, t4592))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t4592)) {
  KLObject* t4595 = shen_tl(ctx, t4578);
  KLObject* t4593;
  {
    KLObject* a4593[] = {t4595, t3941};
    t4593 = shen_apply_direct(ctx, "shen.lazyderef", 2, a4593);
  }
  KLObject* t4599 = shen_cons_p(ctx, t4593);
  KLObject* t4597;
  if (!shen_is_boolean(ctx, t4599))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t4599)) {
  KLObject* t4601 = shen_hd(ctx, t4593);
  KLObject* t4604 = shen_tl(ctx, t4593);
  KLObject* t4602;
  {
    KLObject* a4602[] = {t4604, t3941};
    t4602 = shen_apply_direct(ctx, "shen.lazyderef", 2, a4602);
  }
  KLObject* t4608 = shen_cons_p(ctx, t4602);
  KLObject* t4606;
  if (!shen_is_boolean(ctx, t4608))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t4608)) {
  KLObject* t4610 = shen_hd(ctx, t4602);
  KLObject* t4613 = shen_tl(ctx, t4602);
  KLObject* t4611;
  {
    KLObject* a4611[] = {t4613, t3941};
    t4611 = shen_apply_direct(ctx, "shen.lazyderef", 2, a4611);
  }
  KLObject* t4617 = shen_empty_list(ctx);
  KLObject* t4618 = shen_eq(ctx, t4611, t4617);
  KLObject* t4615;
  if (!shen_is_boolean(ctx, t4618))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t4618)) {
  KLObject* t4621 = shen_tl(ctx, t4571);
  KLObject* t4619;
  {
    KLObject* a4619[] = {t4621, t3941};
    t4619 = shen_apply_direct(ctx, "shen.lazyderef", 2, a4619);
  }
  KLObject* t4625 = shen_cons_p(ctx, t4619);
  KLObject* t4623;
  if (!shen_is_boolean(ctx, t4625))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t4625)) {
  KLObject* t4627 = shen_hd(ctx, t4619);
  KLObject* t4630 = shen_tl(ctx, t4619);
  KLObject* t4628;
  {
    KLObject* a4628[] = {t4630, t3941};
    t4628 = shen_apply_direct(ctx, "shen.lazyderef", 2, a4628);
  }
  KLObject* t4634 = shen_cons_p(ctx, t4628);
  KLObject* t4632;
  if (!shen_is_boolean(ctx, t4634))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t4634)) {
  KLObject* t4637 = shen_hd(ctx, t4628);
  KLObject* t4635;
  {
    KLObject* a4635[] = {t4637, t3941};
    t4635 = shen_apply_direct(ctx, "shen.lazyderef", 2, a4635);
  }
  KLObject* t4641 = shen_cons_p(ctx, t4635);
  KLObject* t4639;
  if (!shen_is_boolean(ctx, t4641))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t4641)) {
  KLObject* t4644 = shen_hd(ctx, t4635);
  KLObject* t4642;
  {
    KLObject* a4642[] = {t4644, t3941};
    t4642 = shen_apply_direct(ctx, "shen.lazyderef", 2, a4642);
  }
  KLObject* t4648 = shen_intern(ctx, "vector");
  KLObject* t4649 = shen_eq(ctx, t4642, t4648);
  KLObject* t4646;
  if (!shen_is_boolean(ctx, t4649))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t4649)) {
  KLObject* t4652 = shen_tl(ctx, t4635);
  KLObject* t4650;
  {
    KLObject* a4650[] = {t4652, t3941};
    t4650 = shen_apply_direct(ctx, "shen.lazyderef", 2, a4650);
  }
  KLObject* t4656 = shen_cons_p(ctx, t4650);
  KLObject* t4654;
  if (!shen_is_boolean(ctx, t4656))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t4656)) {
  KLObject* t4658 = shen_hd(ctx, t4650);
  KLObject* t4661 = shen_tl(ctx, t4650);
  KLObject* t4659;
  {
    KLObject* a4659[] = {t4661, t3941};
    t4659 = shen_apply_direct(ctx, "shen.lazyderef", 2, a4659);
  }
  KLObject* t4665 = shen_empty_list(ctx);
  KLObject* t4666 = shen_eq(ctx, t4659, t4665);
  KLObject* t4663;
  if (!shen_is_boolean(ctx, t4666))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t4666)) {
  KLObject* t4669 = shen_tl(ctx, t4628);
  KLObject* t4667;
  {
    KLObject* a4667[] = {t4669, t3941};
    t4667 = shen_apply_direct(ctx, "shen.lazyderef", 2, a4667);
  }
  KLObject* t4673 = shen_empty_list(ctx);
  KLObject* t4674 = shen_eq(ctx, t4667, t4673);
  KLObject* t4671;
  if (!shen_is_boolean(ctx, t4674))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t4674)) {
  KLObject* t4676 = shen_tl(ctx, t4565);
  KLObject* t4677 = shen_apply_direct(ctx, "shen.incinfs", 0, NULL);
  KLObject* t4679;
  {
    KLObject* a4679[] = {t4627, t3941};
    t4679 = shen_apply_direct(ctx, "shen.deref", 2, a4679);
  }
  KLObject* t4683 = shen_string(ctx, ":");
  KLObject* t4682;
  {
    KLObject* a4682[] = {t4683};
    t4682 = shen_apply_direct(ctx, "intern", 1, a4682);
  }
  KLObject* t4684 = shen_eq(ctx, t4679, t4682);
  KLObject* t4688;
  {
    Vector* caps_100 = shen_vector(ctx, 10);
    shen_vector_set(ctx, caps_100, 0, t3941);
    shen_vector_set(ctx, caps_100, 1, t3942);
    shen_vector_set(ctx, caps_100, 2, t3947);
    shen_vector_set(ctx, caps_100, 3, t4601);
    shen_vector_set(ctx, caps_100, 4, t4627);
    shen_vector_set(ctx, caps_100, 5, t4658);
    shen_vector_set(ctx, caps_100, 6, t4610);
    shen_vector_set(ctx, caps_100, 7, t4676);
    shen_vector_set(ctx, caps_100, 8, t3939);
    shen_vector_set(ctx, caps_100, 9, t3944);
    t4688 = shen_native_closure(ctx, 0, &lambda_100, caps_100);
  }
  KLObject* t4678;
  {
    KLObject* a4678[] = {t4684, t3941, t3942, t3947, t4688};
    t4678 = shen_apply_direct(ctx, "when", 5, a4678);
  }
    t4671 = t4678;
  } else {
  KLObject* t4742 = shen_false(ctx);
    t4671 = t4742;
  }
    t4663 = t4671;
  } else {
  KLObject* t4743 = shen_false(ctx);
    t4663 = t4743;
  }
    t4654 = t4663;
  } else {
  KLObject* t4744 = shen_false(ctx);
    t4654 = t4744;
  }
    t4646 = t4654;
  } else {
  KLObject* t4745 = shen_false(ctx);
    t4646 = t4745;
  }
    t4639 = t4646;
  } else {
  KLObject* t4746 = shen_false(ctx);
    t4639 = t4746;
  }
    t4632 = t4639;
  } else {
  KLObject* t4747 = shen_false(ctx);
    t4632 = t4747;
  }
    t4623 = t4632;
  } else {
  KLObject* t4748 = shen_false(ctx);
    t4623 = t4748;
  }
    t4615 = t4623;
  } else {
  KLObject* t4749 = shen_false(ctx);
    t4615 = t4749;
  }
    t4606 = t4615;
  } else {
  KLObject* t4750 = shen_false(ctx);
    t4606 = t4750;
  }
    t4597 = t4606;
  } else {
  KLObject* t4751 = shen_false(ctx);
    t4597 = t4751;
  }
    t4589 = t4597;
  } else {
  KLObject* t4752 = shen_false(ctx);
    t4589 = t4752;
  }
    t4582 = t4589;
  } else {
  KLObject* t4753 = shen_false(ctx);
    t4582 = t4753;
  }
    t4575 = t4582;
  } else {
  KLObject* t4754 = shen_false(ctx);
    t4575 = t4754;
  }
    t4568 = t4575;
  } else {
  KLObject* t4755 = shen_false(ctx);
    t4568 = t4755;
  }
    t4562 = t4568;
  } else {
  KLObject* t4756 = shen_false(ctx);
    t4562 = t4756;
  }
  KLObject* t4759 = shen_false(ctx);
  KLObject* t4760 = shen_eq(ctx, t4562, t4759);
  KLObject* t4757;
  if (!shen_is_boolean(ctx, t4760))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t4760)) {
  KLObject* t4762;
  {
    KLObject* a4762[] = {t3942};
    t4762 = shen_apply_direct(ctx, "shen.unlocked?", 1, a4762);
  }
  KLObject* t4761;
  if (!shen_is_boolean(ctx, t4762))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t4762)) {
  KLObject* t4764;
  {
    KLObject* a4764[] = {t3938, t3941};
    t4764 = shen_apply_direct(ctx, "shen.lazyderef", 2, a4764);
  }
  KLObject* t4769 = shen_cons_p(ctx, t4764);
  KLObject* t4767;
  if (!shen_is_boolean(ctx, t4769))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t4769)) {
  KLObject* t4771 = shen_hd(ctx, t4764);
  KLObject* t4773 = shen_tl(ctx, t4764);
  KLObject* t4774;
  {
    KLObject* a4774[] = {t3939, t3941};
    t4774 = shen_apply_direct(ctx, "shen.lazyderef", 2, a4774);
  }
  KLObject* t4777;
  {
    Vector* caps_102 = shen_vector(ctx, 7);
    shen_vector_set(ctx, caps_102, 0, t4771);
    shen_vector_set(ctx, caps_102, 1, t3941);
    shen_vector_set(ctx, caps_102, 2, t3942);
    shen_vector_set(ctx, caps_102, 3, t3947);
    shen_vector_set(ctx, caps_102, 4, t4773);
    shen_vector_set(ctx, caps_102, 5, t3940);
    shen_vector_set(ctx, caps_102, 6, t3944);
    t4777 = shen_native_closure(ctx, 1, &lambda_102, caps_102);
  }
  KLObject* t4821 = shen_cons_p(ctx, t4774);
  KLObject* t4819;
  if (!shen_is_boolean(ctx, t4821))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t4821)) {
  KLObject* t4823 = shen_hd(ctx, t4774);
  KLObject* t4825 = shen_tl(ctx, t4774);
  KLObject* t4827;
  {
    Vector* a4827 = shen_vector(ctx, 1);
    shen_vector_set(ctx, a4827, 0, t4823);
    t4827 = shen_apply(ctx, t4777, a4827);
  }
  KLObject* t4826;
  {
    Vector* a4826 = shen_vector(ctx, 1);
    shen_vector_set(ctx, a4826, 0, t4825);
    t4826 = shen_apply(ctx, t4827, a4826);
  }
    t4819 = t4826;
  } else {
  KLObject* t4832;
  {
    KLObject* a4832[] = {t4774};
    t4832 = shen_apply_direct(ctx, "shen.pvar?", 1, a4832);
  }
  KLObject* t4831;
  if (!shen_is_boolean(ctx, t4832))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t4832)) {
  KLObject* t4834;
  {
    KLObject* a4834[] = {t3941};
    t4834 = shen_apply_direct(ctx, "shen.newpv", 1, a4834);
  }
  KLObject* t4838;
  {
    KLObject* a4838[] = {t3941};
    t4838 = shen_apply_direct(ctx, "shen.newpv", 1, a4838);
  }
  KLObject* t4846 = shen_cons(ctx, t4834, t4838);
  KLObject* t4848;
  {
    Vector* caps_105 = shen_vector(ctx, 3);
    shen_vector_set(ctx, caps_105, 0, t4777);
    shen_vector_set(ctx, caps_105, 1, t4834);
    shen_vector_set(ctx, caps_105, 2, t4838);
    t4848 = shen_native_closure(ctx, 0, &lambda_105, caps_105);
  }
  KLObject* t4842;
  {
    KLObject* a4842[] = {t4774, t4846, t3941, t4848};
    t4842 = shen_apply_direct(ctx, "shen.bind!", 4, a4842);
  }
  KLObject* t4840;
  {
    KLObject* a4840[] = {t3941, t4842};
    t4840 = shen_apply_direct(ctx, "shen.gc", 2, a4840);
  }
  KLObject* t4836;
  {
    KLObject* a4836[] = {t3941, t4840};
    t4836 = shen_apply_direct(ctx, "shen.gc", 2, a4836);
  }
    t4831 = t4836;
  } else {
  KLObject* t4857 = shen_false(ctx);
    t4831 = t4857;
  }
    t4819 = t4831;
  }
    t4767 = t4819;
  } else {
  KLObject* t4858 = shen_false(ctx);
    t4767 = t4858;
  }
    t4761 = t4767;
  } else {
  KLObject* t4859 = shen_false(ctx);
    t4761 = t4859;
  }
  KLObject* t4862 = shen_false(ctx);
  KLObject* t4863 = shen_eq(ctx, t4761, t4862);
  KLObject* t4860;
  if (!shen_is_boolean(ctx, t4863))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t4863)) {
  KLObject* t4864;
  {
    KLObject* a4864[] = {t3942, t3947};
    t4864 = shen_tail_apply_direct(ctx, "shen.unlock", 2, a4864);
  }
    t4860 = t4864;
  } else {
    t4860 = t4761;
  }
    t4757 = t4860;
  } else {
    t4757 = t4562;
  }
    t4558 = t4757;
  } else {
    t4558 = t4396;
  }
    t4392 = t4558;
  } else {
    t4392 = t4189;
  }
    t4185 = t4392;
  } else {
    t4185 = t3990;
  }
    t3986 = t4185;
  } else {
    t3986 = t3948;
  }
    return t3986;
  }
}

static KLObject* native_kl_shen_2et_2a_30 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t4873 = objects[0];
    KLObject* t4874 = objects[1];
    KLObject* t4875 = objects[2];
    KLObject* t4876 = objects[3];
    KLObject* t4877 = objects[4];
    KLObject* t4878 = objects[5];
  tail_start_kl_shen_2et_2a_30: ;
  KLObject* t4880 = shen_number_l(ctx, 1);
  KLObject* t4881 = shen_add(ctx, t4877, t4880);
  KLObject* t4883;
  {
    KLObject* a4883[] = {t4876};
    t4883 = shen_apply_direct(ctx, "shen.unlocked?", 1, a4883);
  }
  KLObject* t4882;
  if (!shen_is_boolean(ctx, t4883))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t4883)) {
  KLObject* t4885;
  {
    KLObject* a4885[] = {t4873, t4875};
    t4885 = shen_apply_direct(ctx, "shen.lazyderef", 2, a4885);
  }
  KLObject* t4890 = shen_cons_p(ctx, t4885);
  KLObject* t4888;
  if (!shen_is_boolean(ctx, t4890))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t4890)) {
  KLObject* t4893 = shen_hd(ctx, t4885);
  KLObject* t4891;
  {
    KLObject* a4891[] = {t4893, t4875};
    t4891 = shen_apply_direct(ctx, "shen.lazyderef", 2, a4891);
  }
  KLObject* t4897 = shen_intern(ctx, "define");
  KLObject* t4898 = shen_eq(ctx, t4891, t4897);
  KLObject* t4895;
  if (!shen_is_boolean(ctx, t4898))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t4898)) {
  KLObject* t4901 = shen_tl(ctx, t4885);
  KLObject* t4899;
  {
    KLObject* a4899[] = {t4901, t4875};
    t4899 = shen_apply_direct(ctx, "shen.lazyderef", 2, a4899);
  }
  KLObject* t4905 = shen_cons_p(ctx, t4899);
  KLObject* t4903;
  if (!shen_is_boolean(ctx, t4905))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t4905)) {
  KLObject* t4907 = shen_hd(ctx, t4899);
  KLObject* t4909 = shen_tl(ctx, t4899);
  KLObject* t4910;
  {
    KLObject* a4910[] = {t4875};
    t4910 = shen_apply_direct(ctx, "shen.newpv", 1, a4910);
  }
  KLObject* t4914;
  {
    KLObject* a4914[] = {t4875};
    t4914 = shen_apply_direct(ctx, "shen.newpv", 1, a4914);
  }
  KLObject* t4918;
  {
    KLObject* a4918[] = {t4875};
    t4918 = shen_apply_direct(ctx, "shen.newpv", 1, a4918);
  }
  KLObject* t4922;
  {
    KLObject* a4922[] = {t4875};
    t4922 = shen_apply_direct(ctx, "shen.newpv", 1, a4922);
  }
  KLObject* t4926 = shen_apply_direct(ctx, "shen.incinfs", 0, NULL);
  KLObject* t4931;
  {
    Vector* caps_106 = shen_vector(ctx, 11);
    shen_vector_set(ctx, caps_106, 0, t4910);
    shen_vector_set(ctx, caps_106, 1, t4907);
    shen_vector_set(ctx, caps_106, 2, t4909);
    shen_vector_set(ctx, caps_106, 3, t4875);
    shen_vector_set(ctx, caps_106, 4, t4876);
    shen_vector_set(ctx, caps_106, 5, t4881);
    shen_vector_set(ctx, caps_106, 6, t4922);
    shen_vector_set(ctx, caps_106, 7, t4914);
    shen_vector_set(ctx, caps_106, 8, t4918);
    shen_vector_set(ctx, caps_106, 9, t4874);
    shen_vector_set(ctx, caps_106, 10, t4878);
    t4931 = shen_native_closure(ctx, 0, &lambda_106, caps_106);
  }
  KLObject* t4927;
  {
    KLObject* a4927[] = {t4875, t4876, t4881, t4931};
    t4927 = shen_apply_direct(ctx, "shen.cut", 4, a4927);
  }
  KLObject* t4924;
  {
    KLObject* a4924[] = {t4875, t4927};
    t4924 = shen_apply_direct(ctx, "shen.gc", 2, a4924);
  }
  KLObject* t4920;
  {
    KLObject* a4920[] = {t4875, t4924};
    t4920 = shen_apply_direct(ctx, "shen.gc", 2, a4920);
  }
  KLObject* t4916;
  {
    KLObject* a4916[] = {t4875, t4920};
    t4916 = shen_apply_direct(ctx, "shen.gc", 2, a4916);
  }
  KLObject* t4912;
  {
    KLObject* a4912[] = {t4875, t4916};
    t4912 = shen_apply_direct(ctx, "shen.gc", 2, a4912);
  }
    t4903 = t4912;
  } else {
  KLObject* t5043 = shen_false(ctx);
    t4903 = t5043;
  }
    t4895 = t4903;
  } else {
  KLObject* t5044 = shen_false(ctx);
    t4895 = t5044;
  }
    t4888 = t4895;
  } else {
  KLObject* t5045 = shen_false(ctx);
    t4888 = t5045;
  }
    t4882 = t4888;
  } else {
  KLObject* t5046 = shen_false(ctx);
    t4882 = t5046;
  }
  KLObject* t5049 = shen_false(ctx);
  KLObject* t5050 = shen_eq(ctx, t4882, t5049);
  KLObject* t5047;
  if (!shen_is_boolean(ctx, t5050))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t5050)) {
  KLObject* t5051;
  {
    KLObject* a5051[] = {t4876, t4881};
    t5051 = shen_tail_apply_direct(ctx, "shen.unlock", 2, a5051);
  }
    t5047 = t5051;
  } else {
    t5047 = t4882;
  }
    return t5047;
  }
}

static KLObject* native_kl_shen_2esigxrules_31 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t5055 = objects[0];
  tail_start_kl_shen_2esigxrules_31: ;
  KLObject* t5057;
  {
    Vector* caps_112 = shen_vector(ctx, 0);
    t5057 = shen_native_closure(ctx, 1, &lambda_112, caps_112);
  }
  KLObject* t5056;
  {
    KLObject* a5056[] = {t5057, t5055};
    t5056 = shen_tail_apply_direct(ctx, "compile", 2, a5056);
  }
    return t5056;
  }
}

static KLObject* native_kl_shen_2e_3csig_2arules_3e_32 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t5062 = objects[0];
  tail_start_kl_shen_2e_3csig_2arules_3e_32: ;
  KLObject* t5065 = shen_cons_p(ctx, t5062);
  KLObject* t5063;
  if (!shen_is_boolean(ctx, t5065))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t5065)) {
  KLObject* t5066;
  {
    KLObject* a5066[] = {t5062};
    t5066 = shen_apply_direct(ctx, "tail", 1, a5066);
  }
  KLObject* t5071 = shen_intern(ctx, "{");
  KLObject* t5069;
  {
    KLObject* a5069[] = {t5066, t5071};
    t5069 = shen_apply_direct(ctx, "shen.hds=?", 2, a5069);
  }
  KLObject* t5068;
  if (!shen_is_boolean(ctx, t5069))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t5069)) {
  KLObject* t5072;
  {
    KLObject* a5072[] = {t5066};
    t5072 = shen_apply_direct(ctx, "tail", 1, a5072);
  }
  KLObject* t5074;
  {
    KLObject* a5074[] = {t5072};
    t5074 = shen_apply_direct(ctx, "shen.<signature>", 1, a5074);
  }
  KLObject* t5077;
  {
    KLObject* a5077[] = {t5074};
    t5077 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a5077);
  }
  KLObject* t5076;
  if (!shen_is_boolean(ctx, t5077))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t5077)) {
  KLObject* t5079 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t5076 = t5079;
  } else {
  KLObject* t5080;
  {
    KLObject* a5080[] = {t5074};
    t5080 = shen_apply_direct(ctx, "shen.<-out", 1, a5080);
  }
  KLObject* t5082;
  {
    KLObject* a5082[] = {t5074};
    t5082 = shen_apply_direct(ctx, "shen.in->", 1, a5082);
  }
  KLObject* t5087 = shen_intern(ctx, "}");
  KLObject* t5085;
  {
    KLObject* a5085[] = {t5082, t5087};
    t5085 = shen_apply_direct(ctx, "shen.hds=?", 2, a5085);
  }
  KLObject* t5084;
  if (!shen_is_boolean(ctx, t5085))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t5085)) {
  KLObject* t5088;
  {
    KLObject* a5088[] = {t5082};
    t5088 = shen_apply_direct(ctx, "tail", 1, a5088);
  }
  KLObject* t5090;
  {
    KLObject* a5090[] = {t5088};
    t5090 = shen_apply_direct(ctx, "shen.<rules*>", 1, a5090);
  }
  KLObject* t5093;
  {
    KLObject* a5093[] = {t5090};
    t5093 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a5093);
  }
  KLObject* t5092;
  if (!shen_is_boolean(ctx, t5093))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t5093)) {
  KLObject* t5095 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t5092 = t5095;
  } else {
  KLObject* t5096;
  {
    KLObject* a5096[] = {t5090};
    t5096 = shen_apply_direct(ctx, "shen.<-out", 1, a5096);
  }
  KLObject* t5098;
  {
    KLObject* a5098[] = {t5090};
    t5098 = shen_apply_direct(ctx, "shen.in->", 1, a5098);
  }
  KLObject* t5102;
  {
    KLObject* a5102[] = {t5080};
    t5102 = shen_apply_direct(ctx, "shen.rectify-type", 1, a5102);
  }
  KLObject* t5104;
  {
    KLObject* a5104[] = {t5102, t5096};
    t5104 = shen_apply_direct(ctx, "@p", 2, a5104);
  }
  KLObject* t5100;
  {
    KLObject* a5100[] = {t5098, t5104};
    t5100 = shen_apply_direct(ctx, "shen.comb", 2, a5100);
  }
    t5092 = t5100;
  }
    t5084 = t5092;
  } else {
  KLObject* t5107 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t5084 = t5107;
  }
    t5076 = t5084;
  }
    t5068 = t5076;
  } else {
  KLObject* t5108 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t5068 = t5108;
  }
    t5063 = t5068;
  } else {
  KLObject* t5109 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t5063 = t5109;
  }
  KLObject* t5111;
  {
    KLObject* a5111[] = {t5063};
    t5111 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a5111);
  }
  KLObject* t5110;
  if (!shen_is_boolean(ctx, t5111))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t5111)) {
  KLObject* t5113 = shen_tail_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t5110 = t5113;
  } else {
    t5110 = t5063;
  }
    return t5110;
  }
}

static KLObject* native_kl_shen_2efreshen_2dsig_33 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t5115 = objects[0];
  tail_start_kl_shen_2efreshen_2dsig_33: ;
  KLObject* t5116;
  {
    KLObject* a5116[] = {t5115};
    t5116 = shen_apply_direct(ctx, "shen.extract-vars", 1, a5116);
  }
  KLObject* t5119;
  {
    Vector* caps_113 = shen_vector(ctx, 0);
    t5119 = shen_native_closure(ctx, 1, &lambda_113, caps_113);
  }
  KLObject* t5118;
  {
    KLObject* a5118[] = {t5119, t5116};
    t5118 = shen_apply_direct(ctx, "map", 2, a5118);
  }
  KLObject* t5128;
  {
    KLObject* a5128[] = {t5118, t5115};
    t5128 = shen_tail_apply_direct(ctx, "shen.freshen-type", 2, a5128);
  }
    return t5128;
  }
}

static KLObject* native_kl_shen_2efreshen_2dtype_34 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t5131 = objects[0];
    KLObject* t5132 = objects[1];
  tail_start_kl_shen_2efreshen_2dtype_34: ;
  KLObject* t5133;
  {
  KLObject* t5134 = shen_empty_list(ctx);
  KLObject* t5136 = shen_eq(ctx, t5134, t5131);
    if (!shen_is_boolean(ctx, t5136))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t5136)) {
      t5133 = t5132;
    } else {
  KLObject* t5140 = shen_cons_p(ctx, t5131);
  KLObject* t5138;
  if (!shen_is_boolean(ctx, t5140))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t5140)) {
    t5138 = t5140;
  } else {
  KLObject* t5142 = shen_hd(ctx, t5131);
  KLObject* t5143 = shen_cons_p(ctx, t5142);
    if (!shen_is_boolean(ctx, t5143))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t5138 = t5143;
  }
    if (!shen_is_boolean(ctx, t5138))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t5138)) {
  KLObject* t5145 = shen_tl(ctx, t5131);
  KLObject* t5148 = shen_hd(ctx, t5131);
  KLObject* t5149 = shen_tl(ctx, t5148);
  KLObject* t5151 = shen_hd(ctx, t5131);
  KLObject* t5152 = shen_hd(ctx, t5151);
  KLObject* t5146;
  {
    KLObject* a5146[] = {t5149, t5152, t5132};
    t5146 = shen_apply_direct(ctx, "subst", 3, a5146);
  }
  {
    KLObject* n5154_0 = t5145;
    KLObject* n5154_1 = t5146;
    t5131 = n5154_0;
    t5132 = n5154_1;
    goto tail_start_kl_shen_2efreshen_2dtype_34;
  }
  KLObject* t5154 = NULL;
      t5133 = t5154;
    } else {
  KLObject* t5155 = shen_true(ctx);
    if (!shen_is_boolean(ctx, t5155))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t5155)) {
  KLObject* t5157 = shen_string(ctx, "partial function shen.freshen-type");
  KLObject* t5156;
  {
    KLObject* a5156[] = {t5157};
    t5156 = shen_tail_apply_direct(ctx, "simple-error", 1, a5156);
  }
      t5133 = t5156;
    } else {
      shen_simple_error(ctx, "No true case found for cond");
      t5133 = shen_empty_list(ctx);
    }
    }
    }
  }
    return t5133;
  }
}

static KLObject* native_kl_shen_2e_3crules_2a_3e_35 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t5158 = objects[0];
  tail_start_kl_shen_2e_3crules_2a_3e_35: ;
  KLObject* t5159;
  {
    KLObject* a5159[] = {t5158};
    t5159 = shen_apply_direct(ctx, "shen.<rule*>", 1, a5159);
  }
  KLObject* t5162;
  {
    KLObject* a5162[] = {t5159};
    t5162 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a5162);
  }
  KLObject* t5161;
  if (!shen_is_boolean(ctx, t5162))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t5162)) {
  KLObject* t5164 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t5161 = t5164;
  } else {
  KLObject* t5165;
  {
    KLObject* a5165[] = {t5159};
    t5165 = shen_apply_direct(ctx, "shen.<-out", 1, a5165);
  }
  KLObject* t5167;
  {
    KLObject* a5167[] = {t5159};
    t5167 = shen_apply_direct(ctx, "shen.in->", 1, a5167);
  }
  KLObject* t5169;
  {
    KLObject* a5169[] = {t5167};
    t5169 = shen_apply_direct(ctx, "shen.<rules*>", 1, a5169);
  }
  KLObject* t5172;
  {
    KLObject* a5172[] = {t5169};
    t5172 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a5172);
  }
  KLObject* t5171;
  if (!shen_is_boolean(ctx, t5172))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t5172)) {
  KLObject* t5174 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t5171 = t5174;
  } else {
  KLObject* t5175;
  {
    KLObject* a5175[] = {t5169};
    t5175 = shen_apply_direct(ctx, "shen.<-out", 1, a5175);
  }
  KLObject* t5177;
  {
    KLObject* a5177[] = {t5169};
    t5177 = shen_apply_direct(ctx, "shen.in->", 1, a5177);
  }
  KLObject* t5183 = shen_cons(ctx, t5165, t5175);
  KLObject* t5179;
  {
    KLObject* a5179[] = {t5177, t5183};
    t5179 = shen_apply_direct(ctx, "shen.comb", 2, a5179);
  }
    t5171 = t5179;
  }
    t5161 = t5171;
  }
  KLObject* t5185;
  {
    KLObject* a5185[] = {t5161};
    t5185 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a5185);
  }
  KLObject* t5184;
  if (!shen_is_boolean(ctx, t5185))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t5185)) {
  KLObject* t5187;
  {
    KLObject* a5187[] = {t5158};
    t5187 = shen_apply_direct(ctx, "shen.<rule*>", 1, a5187);
  }
  KLObject* t5190;
  {
    KLObject* a5190[] = {t5187};
    t5190 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a5190);
  }
  KLObject* t5189;
  if (!shen_is_boolean(ctx, t5190))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t5190)) {
  KLObject* t5192 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t5189 = t5192;
  } else {
  KLObject* t5193;
  {
    KLObject* a5193[] = {t5187};
    t5193 = shen_apply_direct(ctx, "shen.<-out", 1, a5193);
  }
  KLObject* t5195;
  {
    KLObject* a5195[] = {t5187};
    t5195 = shen_apply_direct(ctx, "shen.in->", 1, a5195);
  }
  KLObject* t5200 = shen_empty_list(ctx);
  KLObject* t5201 = shen_cons(ctx, t5193, t5200);
  KLObject* t5197;
  {
    KLObject* a5197[] = {t5195, t5201};
    t5197 = shen_apply_direct(ctx, "shen.comb", 2, a5197);
  }
    t5189 = t5197;
  }
  KLObject* t5203;
  {
    KLObject* a5203[] = {t5189};
    t5203 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a5203);
  }
  KLObject* t5202;
  if (!shen_is_boolean(ctx, t5203))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t5203)) {
  KLObject* t5205 = shen_tail_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t5202 = t5205;
  } else {
    t5202 = t5189;
  }
    t5184 = t5202;
  } else {
    t5184 = t5161;
  }
    return t5184;
  }
}

static KLObject* native_kl_shen_2e_3crule_2a_3e_36 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t5208 = objects[0];
  tail_start_kl_shen_2e_3crule_2a_3e_36: ;
  KLObject* t5209;
  {
    KLObject* a5209[] = {t5208};
    t5209 = shen_apply_direct(ctx, "shen.<patterns>", 1, a5209);
  }
  KLObject* t5212;
  {
    KLObject* a5212[] = {t5209};
    t5212 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a5212);
  }
  KLObject* t5211;
  if (!shen_is_boolean(ctx, t5212))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t5212)) {
  KLObject* t5214 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t5211 = t5214;
  } else {
  KLObject* t5215;
  {
    KLObject* a5215[] = {t5209};
    t5215 = shen_apply_direct(ctx, "shen.<-out", 1, a5215);
  }
  KLObject* t5217;
  {
    KLObject* a5217[] = {t5209};
    t5217 = shen_apply_direct(ctx, "shen.in->", 1, a5217);
  }
  KLObject* t5222 = shen_intern(ctx, "->");
  KLObject* t5220;
  {
    KLObject* a5220[] = {t5217, t5222};
    t5220 = shen_apply_direct(ctx, "shen.hds=?", 2, a5220);
  }
  KLObject* t5219;
  if (!shen_is_boolean(ctx, t5220))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t5220)) {
  KLObject* t5223;
  {
    KLObject* a5223[] = {t5217};
    t5223 = shen_apply_direct(ctx, "tail", 1, a5223);
  }
  KLObject* t5227 = shen_cons_p(ctx, t5223);
  KLObject* t5225;
  if (!shen_is_boolean(ctx, t5227))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t5227)) {
  KLObject* t5228;
  {
    KLObject* a5228[] = {t5223};
    t5228 = shen_apply_direct(ctx, "head", 1, a5228);
  }
  KLObject* t5230;
  {
    KLObject* a5230[] = {t5223};
    t5230 = shen_apply_direct(ctx, "tail", 1, a5230);
  }
  KLObject* t5235 = shen_intern(ctx, "where");
  KLObject* t5233;
  {
    KLObject* a5233[] = {t5230, t5235};
    t5233 = shen_apply_direct(ctx, "shen.hds=?", 2, a5233);
  }
  KLObject* t5232;
  if (!shen_is_boolean(ctx, t5233))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t5233)) {
  KLObject* t5236;
  {
    KLObject* a5236[] = {t5230};
    t5236 = shen_apply_direct(ctx, "tail", 1, a5236);
  }
  KLObject* t5240 = shen_cons_p(ctx, t5236);
  KLObject* t5238;
  if (!shen_is_boolean(ctx, t5240))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t5240)) {
  KLObject* t5241;
  {
    KLObject* a5241[] = {t5236};
    t5241 = shen_apply_direct(ctx, "head", 1, a5241);
  }
  KLObject* t5243;
  {
    KLObject* a5243[] = {t5236};
    t5243 = shen_apply_direct(ctx, "tail", 1, a5243);
  }
  KLObject* t5249 = shen_intern(ctx, "where");
  KLObject* t5252 = shen_empty_list(ctx);
  KLObject* t5253 = shen_cons(ctx, t5228, t5252);
  KLObject* t5254 = shen_cons(ctx, t5241, t5253);
  KLObject* t5255 = shen_cons(ctx, t5249, t5254);
  KLObject* t5247;
  {
    KLObject* a5247[] = {t5215, t5255};
    t5247 = shen_apply_direct(ctx, "@p", 2, a5247);
  }
  KLObject* t5245;
  {
    KLObject* a5245[] = {t5243, t5247};
    t5245 = shen_apply_direct(ctx, "shen.comb", 2, a5245);
  }
    t5238 = t5245;
  } else {
  KLObject* t5256 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t5238 = t5256;
  }
    t5232 = t5238;
  } else {
  KLObject* t5257 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t5232 = t5257;
  }
    t5225 = t5232;
  } else {
  KLObject* t5258 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t5225 = t5258;
  }
    t5219 = t5225;
  } else {
  KLObject* t5259 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t5219 = t5259;
  }
    t5211 = t5219;
  }
  KLObject* t5261;
  {
    KLObject* a5261[] = {t5211};
    t5261 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a5261);
  }
  KLObject* t5260;
  if (!shen_is_boolean(ctx, t5261))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t5261)) {
  KLObject* t5263;
  {
    KLObject* a5263[] = {t5208};
    t5263 = shen_apply_direct(ctx, "shen.<patterns>", 1, a5263);
  }
  KLObject* t5266;
  {
    KLObject* a5266[] = {t5263};
    t5266 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a5266);
  }
  KLObject* t5265;
  if (!shen_is_boolean(ctx, t5266))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t5266)) {
  KLObject* t5268 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t5265 = t5268;
  } else {
  KLObject* t5269;
  {
    KLObject* a5269[] = {t5263};
    t5269 = shen_apply_direct(ctx, "shen.<-out", 1, a5269);
  }
  KLObject* t5271;
  {
    KLObject* a5271[] = {t5263};
    t5271 = shen_apply_direct(ctx, "shen.in->", 1, a5271);
  }
  KLObject* t5276 = shen_intern(ctx, "<-");
  KLObject* t5274;
  {
    KLObject* a5274[] = {t5271, t5276};
    t5274 = shen_apply_direct(ctx, "shen.hds=?", 2, a5274);
  }
  KLObject* t5273;
  if (!shen_is_boolean(ctx, t5274))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t5274)) {
  KLObject* t5277;
  {
    KLObject* a5277[] = {t5271};
    t5277 = shen_apply_direct(ctx, "tail", 1, a5277);
  }
  KLObject* t5281 = shen_cons_p(ctx, t5277);
  KLObject* t5279;
  if (!shen_is_boolean(ctx, t5281))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t5281)) {
  KLObject* t5282;
  {
    KLObject* a5282[] = {t5277};
    t5282 = shen_apply_direct(ctx, "head", 1, a5282);
  }
  KLObject* t5284;
  {
    KLObject* a5284[] = {t5277};
    t5284 = shen_apply_direct(ctx, "tail", 1, a5284);
  }
  KLObject* t5289 = shen_intern(ctx, "where");
  KLObject* t5287;
  {
    KLObject* a5287[] = {t5284, t5289};
    t5287 = shen_apply_direct(ctx, "shen.hds=?", 2, a5287);
  }
  KLObject* t5286;
  if (!shen_is_boolean(ctx, t5287))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t5287)) {
  KLObject* t5290;
  {
    KLObject* a5290[] = {t5284};
    t5290 = shen_apply_direct(ctx, "tail", 1, a5290);
  }
  KLObject* t5294 = shen_cons_p(ctx, t5290);
  KLObject* t5292;
  if (!shen_is_boolean(ctx, t5294))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t5294)) {
  KLObject* t5295;
  {
    KLObject* a5295[] = {t5290};
    t5295 = shen_apply_direct(ctx, "head", 1, a5295);
  }
  KLObject* t5297;
  {
    KLObject* a5297[] = {t5290};
    t5297 = shen_apply_direct(ctx, "tail", 1, a5297);
  }
  KLObject* t5304 = shen_intern(ctx, "where");
  KLObject* t5307 = shen_empty_list(ctx);
  KLObject* t5308 = shen_cons(ctx, t5282, t5307);
  KLObject* t5309 = shen_cons(ctx, t5295, t5308);
  KLObject* t5310 = shen_cons(ctx, t5304, t5309);
  KLObject* t5303;
  {
    KLObject* a5303[] = {t5310};
    t5303 = shen_apply_direct(ctx, "shen.correct", 1, a5303);
  }
  KLObject* t5301;
  {
    KLObject* a5301[] = {t5269, t5303};
    t5301 = shen_apply_direct(ctx, "@p", 2, a5301);
  }
  KLObject* t5299;
  {
    KLObject* a5299[] = {t5297, t5301};
    t5299 = shen_apply_direct(ctx, "shen.comb", 2, a5299);
  }
    t5292 = t5299;
  } else {
  KLObject* t5311 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t5292 = t5311;
  }
    t5286 = t5292;
  } else {
  KLObject* t5312 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t5286 = t5312;
  }
    t5279 = t5286;
  } else {
  KLObject* t5313 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t5279 = t5313;
  }
    t5273 = t5279;
  } else {
  KLObject* t5314 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t5273 = t5314;
  }
    t5265 = t5273;
  }
  KLObject* t5316;
  {
    KLObject* a5316[] = {t5265};
    t5316 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a5316);
  }
  KLObject* t5315;
  if (!shen_is_boolean(ctx, t5316))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t5316)) {
  KLObject* t5318;
  {
    KLObject* a5318[] = {t5208};
    t5318 = shen_apply_direct(ctx, "shen.<patterns>", 1, a5318);
  }
  KLObject* t5321;
  {
    KLObject* a5321[] = {t5318};
    t5321 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a5321);
  }
  KLObject* t5320;
  if (!shen_is_boolean(ctx, t5321))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t5321)) {
  KLObject* t5323 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t5320 = t5323;
  } else {
  KLObject* t5324;
  {
    KLObject* a5324[] = {t5318};
    t5324 = shen_apply_direct(ctx, "shen.<-out", 1, a5324);
  }
  KLObject* t5326;
  {
    KLObject* a5326[] = {t5318};
    t5326 = shen_apply_direct(ctx, "shen.in->", 1, a5326);
  }
  KLObject* t5331 = shen_intern(ctx, "<-");
  KLObject* t5329;
  {
    KLObject* a5329[] = {t5326, t5331};
    t5329 = shen_apply_direct(ctx, "shen.hds=?", 2, a5329);
  }
  KLObject* t5328;
  if (!shen_is_boolean(ctx, t5329))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t5329)) {
  KLObject* t5332;
  {
    KLObject* a5332[] = {t5326};
    t5332 = shen_apply_direct(ctx, "tail", 1, a5332);
  }
  KLObject* t5336 = shen_cons_p(ctx, t5332);
  KLObject* t5334;
  if (!shen_is_boolean(ctx, t5336))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t5336)) {
  KLObject* t5337;
  {
    KLObject* a5337[] = {t5332};
    t5337 = shen_apply_direct(ctx, "head", 1, a5337);
  }
  KLObject* t5339;
  {
    KLObject* a5339[] = {t5332};
    t5339 = shen_apply_direct(ctx, "tail", 1, a5339);
  }
  KLObject* t5345;
  {
    KLObject* a5345[] = {t5337};
    t5345 = shen_apply_direct(ctx, "shen.correct", 1, a5345);
  }
  KLObject* t5343;
  {
    KLObject* a5343[] = {t5324, t5345};
    t5343 = shen_apply_direct(ctx, "@p", 2, a5343);
  }
  KLObject* t5341;
  {
    KLObject* a5341[] = {t5339, t5343};
    t5341 = shen_apply_direct(ctx, "shen.comb", 2, a5341);
  }
    t5334 = t5341;
  } else {
  KLObject* t5347 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t5334 = t5347;
  }
    t5328 = t5334;
  } else {
  KLObject* t5348 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t5328 = t5348;
  }
    t5320 = t5328;
  }
  KLObject* t5350;
  {
    KLObject* a5350[] = {t5320};
    t5350 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a5350);
  }
  KLObject* t5349;
  if (!shen_is_boolean(ctx, t5350))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t5350)) {
  KLObject* t5352;
  {
    KLObject* a5352[] = {t5208};
    t5352 = shen_apply_direct(ctx, "shen.<patterns>", 1, a5352);
  }
  KLObject* t5355;
  {
    KLObject* a5355[] = {t5352};
    t5355 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a5355);
  }
  KLObject* t5354;
  if (!shen_is_boolean(ctx, t5355))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t5355)) {
  KLObject* t5357 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t5354 = t5357;
  } else {
  KLObject* t5358;
  {
    KLObject* a5358[] = {t5352};
    t5358 = shen_apply_direct(ctx, "shen.<-out", 1, a5358);
  }
  KLObject* t5360;
  {
    KLObject* a5360[] = {t5352};
    t5360 = shen_apply_direct(ctx, "shen.in->", 1, a5360);
  }
  KLObject* t5365 = shen_intern(ctx, "->");
  KLObject* t5363;
  {
    KLObject* a5363[] = {t5360, t5365};
    t5363 = shen_apply_direct(ctx, "shen.hds=?", 2, a5363);
  }
  KLObject* t5362;
  if (!shen_is_boolean(ctx, t5363))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t5363)) {
  KLObject* t5366;
  {
    KLObject* a5366[] = {t5360};
    t5366 = shen_apply_direct(ctx, "tail", 1, a5366);
  }
  KLObject* t5370 = shen_cons_p(ctx, t5366);
  KLObject* t5368;
  if (!shen_is_boolean(ctx, t5370))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t5370)) {
  KLObject* t5371;
  {
    KLObject* a5371[] = {t5366};
    t5371 = shen_apply_direct(ctx, "head", 1, a5371);
  }
  KLObject* t5373;
  {
    KLObject* a5373[] = {t5366};
    t5373 = shen_apply_direct(ctx, "tail", 1, a5373);
  }
  KLObject* t5377;
  {
    KLObject* a5377[] = {t5358, t5371};
    t5377 = shen_apply_direct(ctx, "@p", 2, a5377);
  }
  KLObject* t5375;
  {
    KLObject* a5375[] = {t5373, t5377};
    t5375 = shen_apply_direct(ctx, "shen.comb", 2, a5375);
  }
    t5368 = t5375;
  } else {
  KLObject* t5380 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t5368 = t5380;
  }
    t5362 = t5368;
  } else {
  KLObject* t5381 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t5362 = t5381;
  }
    t5354 = t5362;
  }
  KLObject* t5383;
  {
    KLObject* a5383[] = {t5354};
    t5383 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a5383);
  }
  KLObject* t5382;
  if (!shen_is_boolean(ctx, t5383))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t5383)) {
  KLObject* t5385 = shen_tail_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t5382 = t5385;
  } else {
    t5382 = t5354;
  }
    t5349 = t5382;
  } else {
    t5349 = t5320;
  }
    t5315 = t5349;
  } else {
    t5315 = t5265;
  }
    t5260 = t5315;
  } else {
    t5260 = t5211;
  }
    return t5260;
  }
}

static KLObject* native_kl_shen_2ecorrect_37 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t5390 = objects[0];
  tail_start_kl_shen_2ecorrect_37: ;
  KLObject* t5391;
  {
  KLObject* t5394 = shen_cons_p(ctx, t5390);
  KLObject* t5392;
  if (!shen_is_boolean(ctx, t5394))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t5394)) {
    t5392 = t5394;
  } else {
  KLObject* t5396 = shen_intern(ctx, "where");
  KLObject* t5398 = shen_hd(ctx, t5390);
  KLObject* t5399 = shen_eq(ctx, t5396, t5398);
  KLObject* t5395;
  if (!shen_is_boolean(ctx, t5399))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t5399)) {
    t5395 = t5399;
  } else {
  KLObject* t5402 = shen_tl(ctx, t5390);
  KLObject* t5403 = shen_cons_p(ctx, t5402);
  KLObject* t5400;
  if (!shen_is_boolean(ctx, t5403))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t5403)) {
    t5400 = t5403;
  } else {
  KLObject* t5406 = shen_tl(ctx, t5390);
  KLObject* t5407 = shen_tl(ctx, t5406);
  KLObject* t5408 = shen_cons_p(ctx, t5407);
  KLObject* t5404;
  if (!shen_is_boolean(ctx, t5408))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t5408)) {
    t5404 = t5408;
  } else {
  KLObject* t5411 = shen_tl(ctx, t5390);
  KLObject* t5412 = shen_tl(ctx, t5411);
  KLObject* t5413 = shen_hd(ctx, t5412);
  KLObject* t5414 = shen_cons_p(ctx, t5413);
  KLObject* t5409;
  if (!shen_is_boolean(ctx, t5414))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t5414)) {
    t5409 = t5414;
  } else {
  KLObject* t5416 = shen_intern(ctx, "fail-if");
  KLObject* t5418 = shen_tl(ctx, t5390);
  KLObject* t5419 = shen_tl(ctx, t5418);
  KLObject* t5420 = shen_hd(ctx, t5419);
  KLObject* t5421 = shen_hd(ctx, t5420);
  KLObject* t5422 = shen_eq(ctx, t5416, t5421);
  KLObject* t5415;
  if (!shen_is_boolean(ctx, t5422))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t5422)) {
    t5415 = t5422;
  } else {
  KLObject* t5425 = shen_tl(ctx, t5390);
  KLObject* t5426 = shen_tl(ctx, t5425);
  KLObject* t5427 = shen_hd(ctx, t5426);
  KLObject* t5428 = shen_tl(ctx, t5427);
  KLObject* t5429 = shen_cons_p(ctx, t5428);
  KLObject* t5423;
  if (!shen_is_boolean(ctx, t5429))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t5429)) {
    t5423 = t5429;
  } else {
  KLObject* t5432 = shen_tl(ctx, t5390);
  KLObject* t5433 = shen_tl(ctx, t5432);
  KLObject* t5434 = shen_hd(ctx, t5433);
  KLObject* t5435 = shen_tl(ctx, t5434);
  KLObject* t5436 = shen_tl(ctx, t5435);
  KLObject* t5437 = shen_cons_p(ctx, t5436);
  KLObject* t5430;
  if (!shen_is_boolean(ctx, t5437))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t5437)) {
    t5430 = t5437;
  } else {
  KLObject* t5439 = shen_empty_list(ctx);
  KLObject* t5441 = shen_tl(ctx, t5390);
  KLObject* t5442 = shen_tl(ctx, t5441);
  KLObject* t5443 = shen_hd(ctx, t5442);
  KLObject* t5444 = shen_tl(ctx, t5443);
  KLObject* t5445 = shen_tl(ctx, t5444);
  KLObject* t5446 = shen_tl(ctx, t5445);
  KLObject* t5447 = shen_eq(ctx, t5439, t5446);
  KLObject* t5438;
  if (!shen_is_boolean(ctx, t5447))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t5447)) {
    t5438 = t5447;
  } else {
  KLObject* t5448 = shen_empty_list(ctx);
  KLObject* t5450 = shen_tl(ctx, t5390);
  KLObject* t5451 = shen_tl(ctx, t5450);
  KLObject* t5452 = shen_tl(ctx, t5451);
  KLObject* t5453 = shen_eq(ctx, t5448, t5452);
    if (!shen_is_boolean(ctx, t5453))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t5438 = t5453;
  }
    if (!shen_is_boolean(ctx, t5438))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t5430 = t5438;
  }
    if (!shen_is_boolean(ctx, t5430))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t5423 = t5430;
  }
    if (!shen_is_boolean(ctx, t5423))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t5415 = t5423;
  }
    if (!shen_is_boolean(ctx, t5415))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t5409 = t5415;
  }
    if (!shen_is_boolean(ctx, t5409))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t5404 = t5409;
  }
    if (!shen_is_boolean(ctx, t5404))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t5400 = t5404;
  }
    if (!shen_is_boolean(ctx, t5400))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t5395 = t5400;
  }
    if (!shen_is_boolean(ctx, t5395))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t5392 = t5395;
  }
    if (!shen_is_boolean(ctx, t5392))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t5392)) {
  KLObject* t5454 = shen_intern(ctx, "where");
  KLObject* t5455 = shen_intern(ctx, "and");
  KLObject* t5457 = shen_tl(ctx, t5390);
  KLObject* t5458 = shen_hd(ctx, t5457);
  KLObject* t5459 = shen_intern(ctx, "not");
  KLObject* t5461 = shen_tl(ctx, t5390);
  KLObject* t5462 = shen_tl(ctx, t5461);
  KLObject* t5463 = shen_hd(ctx, t5462);
  KLObject* t5464 = shen_tl(ctx, t5463);
  KLObject* t5465 = shen_empty_list(ctx);
  KLObject* t5466 = shen_cons(ctx, t5464, t5465);
  KLObject* t5467 = shen_cons(ctx, t5459, t5466);
  KLObject* t5468 = shen_empty_list(ctx);
  KLObject* t5469 = shen_cons(ctx, t5467, t5468);
  KLObject* t5470 = shen_cons(ctx, t5458, t5469);
  KLObject* t5471 = shen_cons(ctx, t5455, t5470);
  KLObject* t5473 = shen_tl(ctx, t5390);
  KLObject* t5474 = shen_tl(ctx, t5473);
  KLObject* t5475 = shen_hd(ctx, t5474);
  KLObject* t5476 = shen_tl(ctx, t5475);
  KLObject* t5477 = shen_tl(ctx, t5476);
  KLObject* t5478 = shen_cons(ctx, t5471, t5477);
  KLObject* t5479 = shen_cons(ctx, t5454, t5478);
      t5391 = t5479;
    } else {
  KLObject* t5482 = shen_cons_p(ctx, t5390);
  KLObject* t5480;
  if (!shen_is_boolean(ctx, t5482))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t5482)) {
    t5480 = t5482;
  } else {
  KLObject* t5484 = shen_intern(ctx, "where");
  KLObject* t5486 = shen_hd(ctx, t5390);
  KLObject* t5487 = shen_eq(ctx, t5484, t5486);
  KLObject* t5483;
  if (!shen_is_boolean(ctx, t5487))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t5487)) {
    t5483 = t5487;
  } else {
  KLObject* t5490 = shen_tl(ctx, t5390);
  KLObject* t5491 = shen_cons_p(ctx, t5490);
  KLObject* t5488;
  if (!shen_is_boolean(ctx, t5491))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t5491)) {
    t5488 = t5491;
  } else {
  KLObject* t5494 = shen_tl(ctx, t5390);
  KLObject* t5495 = shen_tl(ctx, t5494);
  KLObject* t5496 = shen_cons_p(ctx, t5495);
  KLObject* t5492;
  if (!shen_is_boolean(ctx, t5496))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t5496)) {
    t5492 = t5496;
  } else {
  KLObject* t5497 = shen_empty_list(ctx);
  KLObject* t5499 = shen_tl(ctx, t5390);
  KLObject* t5500 = shen_tl(ctx, t5499);
  KLObject* t5501 = shen_tl(ctx, t5500);
  KLObject* t5502 = shen_eq(ctx, t5497, t5501);
    if (!shen_is_boolean(ctx, t5502))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t5492 = t5502;
  }
    if (!shen_is_boolean(ctx, t5492))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t5488 = t5492;
  }
    if (!shen_is_boolean(ctx, t5488))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t5483 = t5488;
  }
    if (!shen_is_boolean(ctx, t5483))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t5480 = t5483;
  }
    if (!shen_is_boolean(ctx, t5480))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t5480)) {
  KLObject* t5503 = shen_intern(ctx, "where");
  KLObject* t5504 = shen_intern(ctx, "and");
  KLObject* t5506 = shen_tl(ctx, t5390);
  KLObject* t5507 = shen_hd(ctx, t5506);
  KLObject* t5508 = shen_intern(ctx, "not");
  KLObject* t5509 = shen_intern(ctx, "==");
  KLObject* t5511 = shen_tl(ctx, t5390);
  KLObject* t5512 = shen_tl(ctx, t5511);
  KLObject* t5513 = shen_hd(ctx, t5512);
  KLObject* t5514 = shen_intern(ctx, "fail");
  KLObject* t5515 = shen_empty_list(ctx);
  KLObject* t5516 = shen_cons(ctx, t5514, t5515);
  KLObject* t5517 = shen_empty_list(ctx);
  KLObject* t5518 = shen_cons(ctx, t5516, t5517);
  KLObject* t5519 = shen_cons(ctx, t5513, t5518);
  KLObject* t5520 = shen_cons(ctx, t5509, t5519);
  KLObject* t5521 = shen_empty_list(ctx);
  KLObject* t5522 = shen_cons(ctx, t5520, t5521);
  KLObject* t5523 = shen_cons(ctx, t5508, t5522);
  KLObject* t5524 = shen_empty_list(ctx);
  KLObject* t5525 = shen_cons(ctx, t5523, t5524);
  KLObject* t5526 = shen_cons(ctx, t5507, t5525);
  KLObject* t5527 = shen_cons(ctx, t5504, t5526);
  KLObject* t5529 = shen_tl(ctx, t5390);
  KLObject* t5530 = shen_tl(ctx, t5529);
  KLObject* t5531 = shen_cons(ctx, t5527, t5530);
  KLObject* t5532 = shen_cons(ctx, t5503, t5531);
      t5391 = t5532;
    } else {
  KLObject* t5535 = shen_cons_p(ctx, t5390);
  KLObject* t5533;
  if (!shen_is_boolean(ctx, t5535))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t5535)) {
    t5533 = t5535;
  } else {
  KLObject* t5537 = shen_intern(ctx, "fail-if");
  KLObject* t5539 = shen_hd(ctx, t5390);
  KLObject* t5540 = shen_eq(ctx, t5537, t5539);
  KLObject* t5536;
  if (!shen_is_boolean(ctx, t5540))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t5540)) {
    t5536 = t5540;
  } else {
  KLObject* t5543 = shen_tl(ctx, t5390);
  KLObject* t5544 = shen_cons_p(ctx, t5543);
  KLObject* t5541;
  if (!shen_is_boolean(ctx, t5544))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t5544)) {
    t5541 = t5544;
  } else {
  KLObject* t5547 = shen_tl(ctx, t5390);
  KLObject* t5548 = shen_tl(ctx, t5547);
  KLObject* t5549 = shen_cons_p(ctx, t5548);
  KLObject* t5545;
  if (!shen_is_boolean(ctx, t5549))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t5549)) {
    t5545 = t5549;
  } else {
  KLObject* t5550 = shen_empty_list(ctx);
  KLObject* t5552 = shen_tl(ctx, t5390);
  KLObject* t5553 = shen_tl(ctx, t5552);
  KLObject* t5554 = shen_tl(ctx, t5553);
  KLObject* t5555 = shen_eq(ctx, t5550, t5554);
    if (!shen_is_boolean(ctx, t5555))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t5545 = t5555;
  }
    if (!shen_is_boolean(ctx, t5545))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t5541 = t5545;
  }
    if (!shen_is_boolean(ctx, t5541))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t5536 = t5541;
  }
    if (!shen_is_boolean(ctx, t5536))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t5533 = t5536;
  }
    if (!shen_is_boolean(ctx, t5533))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t5533)) {
  KLObject* t5556 = shen_intern(ctx, "where");
  KLObject* t5557 = shen_intern(ctx, "not");
  KLObject* t5559 = shen_tl(ctx, t5390);
  KLObject* t5560 = shen_empty_list(ctx);
  KLObject* t5561 = shen_cons(ctx, t5559, t5560);
  KLObject* t5562 = shen_cons(ctx, t5557, t5561);
  KLObject* t5564 = shen_tl(ctx, t5390);
  KLObject* t5565 = shen_tl(ctx, t5564);
  KLObject* t5566 = shen_cons(ctx, t5562, t5565);
  KLObject* t5567 = shen_cons(ctx, t5556, t5566);
      t5391 = t5567;
    } else {
  KLObject* t5568 = shen_true(ctx);
    if (!shen_is_boolean(ctx, t5568))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t5568)) {
  KLObject* t5569 = shen_intern(ctx, "where");
  KLObject* t5570 = shen_intern(ctx, "not");
  KLObject* t5571 = shen_intern(ctx, "==");
  KLObject* t5573 = shen_intern(ctx, "fail");
  KLObject* t5574 = shen_empty_list(ctx);
  KLObject* t5575 = shen_cons(ctx, t5573, t5574);
  KLObject* t5576 = shen_empty_list(ctx);
  KLObject* t5577 = shen_cons(ctx, t5575, t5576);
  KLObject* t5578 = shen_cons(ctx, t5390, t5577);
  KLObject* t5579 = shen_cons(ctx, t5571, t5578);
  KLObject* t5580 = shen_empty_list(ctx);
  KLObject* t5581 = shen_cons(ctx, t5579, t5580);
  KLObject* t5582 = shen_cons(ctx, t5570, t5581);
  KLObject* t5584 = shen_empty_list(ctx);
  KLObject* t5585 = shen_cons(ctx, t5390, t5584);
  KLObject* t5586 = shen_cons(ctx, t5582, t5585);
  KLObject* t5587 = shen_cons(ctx, t5569, t5586);
      t5391 = t5587;
    } else {
      shen_simple_error(ctx, "No true case found for cond");
      t5391 = shen_empty_list(ctx);
    }
    }
    }
    }
  }
    return t5391;
  }
}

static KLObject* native_kl_shen_2et_2a_2drules_38 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t5588 = objects[0];
    KLObject* t5589 = objects[1];
    KLObject* t5590 = objects[2];
    KLObject* t5591 = objects[3];
    KLObject* t5592 = objects[4];
    KLObject* t5593 = objects[5];
    KLObject* t5594 = objects[6];
    KLObject* t5595 = objects[7];
  tail_start_kl_shen_2et_2a_2drules_38: ;
  KLObject* t5597 = shen_number_l(ctx, 1);
  KLObject* t5598 = shen_add(ctx, t5594, t5597);
  KLObject* t5600;
  {
    KLObject* a5600[] = {t5593};
    t5600 = shen_apply_direct(ctx, "shen.unlocked?", 1, a5600);
  }
  KLObject* t5599;
  if (!shen_is_boolean(ctx, t5600))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t5600)) {
  KLObject* t5602;
  {
    KLObject* a5602[] = {t5589, t5592};
    t5602 = shen_apply_direct(ctx, "shen.lazyderef", 2, a5602);
  }
  KLObject* t5607 = shen_empty_list(ctx);
  KLObject* t5608 = shen_eq(ctx, t5602, t5607);
  KLObject* t5605;
  if (!shen_is_boolean(ctx, t5608))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t5608)) {
  KLObject* t5609 = shen_apply_direct(ctx, "shen.incinfs", 0, NULL);
  KLObject* t5610;
  {
    KLObject* a5610[] = {t5595};
    t5610 = shen_apply_direct(ctx, "thaw", 1, a5610);
  }
    t5605 = t5610;
  } else {
  KLObject* t5612 = shen_false(ctx);
    t5605 = t5612;
  }
    t5599 = t5605;
  } else {
  KLObject* t5613 = shen_false(ctx);
    t5599 = t5613;
  }
  KLObject* t5616 = shen_false(ctx);
  KLObject* t5617 = shen_eq(ctx, t5599, t5616);
  KLObject* t5614;
  if (!shen_is_boolean(ctx, t5617))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t5617)) {
  KLObject* t5619;
  {
    KLObject* a5619[] = {t5593};
    t5619 = shen_apply_direct(ctx, "shen.unlocked?", 1, a5619);
  }
  KLObject* t5618;
  if (!shen_is_boolean(ctx, t5619))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t5619)) {
  KLObject* t5621;
  {
    KLObject* a5621[] = {t5589, t5592};
    t5621 = shen_apply_direct(ctx, "shen.lazyderef", 2, a5621);
  }
  KLObject* t5626 = shen_cons_p(ctx, t5621);
  KLObject* t5624;
  if (!shen_is_boolean(ctx, t5626))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t5626)) {
  KLObject* t5628 = shen_hd(ctx, t5621);
  KLObject* t5630 = shen_tl(ctx, t5621);
  KLObject* t5631;
  {
    KLObject* a5631[] = {t5592};
    t5631 = shen_apply_direct(ctx, "shen.newpv", 1, a5631);
  }
  KLObject* t5635 = shen_apply_direct(ctx, "shen.incinfs", 0, NULL);
  KLObject* t5639;
  {
    KLObject* a5639[] = {t5628, t5592};
    t5639 = shen_apply_direct(ctx, "shen.deref", 2, a5639);
  }
  KLObject* t5638;
  {
    KLObject* a5638[] = {t5639};
    t5638 = shen_apply_direct(ctx, "shen.freshen-rule", 1, a5638);
  }
  KLObject* t5645;
  {
    Vector* caps_114 = shen_vector(ctx, 9);
    shen_vector_set(ctx, caps_114, 0, t5588);
    shen_vector_set(ctx, caps_114, 1, t5591);
    shen_vector_set(ctx, caps_114, 2, t5631);
    shen_vector_set(ctx, caps_114, 3, t5592);
    shen_vector_set(ctx, caps_114, 4, t5590);
    shen_vector_set(ctx, caps_114, 5, t5593);
    shen_vector_set(ctx, caps_114, 6, t5598);
    shen_vector_set(ctx, caps_114, 7, t5630);
    shen_vector_set(ctx, caps_114, 8, t5595);
    t5645 = shen_native_closure(ctx, 0, &lambda_114, caps_114);
  }
  KLObject* t5636;
  {
    KLObject* a5636[] = {t5631, t5638, t5592, t5593, t5598, t5645};
    t5636 = shen_apply_direct(ctx, "bind", 6, a5636);
  }
  KLObject* t5633;
  {
    KLObject* a5633[] = {t5592, t5636};
    t5633 = shen_apply_direct(ctx, "shen.gc", 2, a5633);
  }
    t5624 = t5633;
  } else {
  KLObject* t5703 = shen_false(ctx);
    t5624 = t5703;
  }
    t5618 = t5624;
  } else {
  KLObject* t5704 = shen_false(ctx);
    t5618 = t5704;
  }
  KLObject* t5707 = shen_false(ctx);
  KLObject* t5708 = shen_eq(ctx, t5618, t5707);
  KLObject* t5705;
  if (!shen_is_boolean(ctx, t5708))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t5708)) {
  KLObject* t5709;
  {
    KLObject* a5709[] = {t5593, t5598};
    t5709 = shen_tail_apply_direct(ctx, "shen.unlock", 2, a5709);
  }
    t5705 = t5709;
  } else {
    t5705 = t5618;
  }
    t5614 = t5705;
  } else {
    t5614 = t5599;
  }
    return t5614;
  }
}

static KLObject* native_kl_shen_2efreshen_2drule_39 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t5714 = objects[0];
  tail_start_kl_shen_2efreshen_2drule_39: ;
  KLObject* t5715;
  {
  KLObject* t5716;
  {
    KLObject* a5716[] = {t5714};
    t5716 = shen_apply_direct(ctx, "tuple?", 1, a5716);
  }
    if (!shen_is_boolean(ctx, t5716))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t5716)) {
  KLObject* t5719;
  {
    KLObject* a5719[] = {t5714};
    t5719 = shen_apply_direct(ctx, "fst", 1, a5719);
  }
  KLObject* t5718;
  {
    KLObject* a5718[] = {t5719};
    t5718 = shen_apply_direct(ctx, "shen.extract-vars", 1, a5718);
  }
  KLObject* t5722;
  {
    Vector* caps_117 = shen_vector(ctx, 0);
    t5722 = shen_native_closure(ctx, 1, &lambda_117, caps_117);
  }
  KLObject* t5721;
  {
    KLObject* a5721[] = {t5722, t5718};
    t5721 = shen_apply_direct(ctx, "map", 2, a5721);
  }
  KLObject* t5732;
  {
    KLObject* a5732[] = {t5714};
    t5732 = shen_apply_direct(ctx, "fst", 1, a5732);
  }
  KLObject* t5730;
  {
    KLObject* a5730[] = {t5721, t5732};
    t5730 = shen_apply_direct(ctx, "shen.freshen", 2, a5730);
  }
  KLObject* t5736;
  {
    KLObject* a5736[] = {t5714};
    t5736 = shen_apply_direct(ctx, "snd", 1, a5736);
  }
  KLObject* t5734;
  {
    KLObject* a5734[] = {t5721, t5736};
    t5734 = shen_apply_direct(ctx, "shen.freshen", 2, a5734);
  }
  KLObject* t5729;
  {
    KLObject* a5729[] = {t5730, t5734};
    t5729 = shen_tail_apply_direct(ctx, "@p", 2, a5729);
  }
      t5715 = t5729;
    } else {
  KLObject* t5738 = shen_true(ctx);
    if (!shen_is_boolean(ctx, t5738))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t5738)) {
  KLObject* t5740 = shen_string(ctx, "partial function shen.freshen-rule");
  KLObject* t5739;
  {
    KLObject* a5739[] = {t5740};
    t5739 = shen_tail_apply_direct(ctx, "simple-error", 1, a5739);
  }
      t5715 = t5739;
    } else {
      shen_simple_error(ctx, "No true case found for cond");
      t5715 = shen_empty_list(ctx);
    }
    }
  }
    return t5715;
  }
}

static KLObject* native_kl_shen_2efreshen_40 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t5741 = objects[0];
    KLObject* t5742 = objects[1];
  tail_start_kl_shen_2efreshen_40: ;
  KLObject* t5743;
  {
  KLObject* t5744 = shen_empty_list(ctx);
  KLObject* t5746 = shen_eq(ctx, t5744, t5741);
    if (!shen_is_boolean(ctx, t5746))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t5746)) {
      t5743 = t5742;
    } else {
  KLObject* t5750 = shen_cons_p(ctx, t5741);
  KLObject* t5748;
  if (!shen_is_boolean(ctx, t5750))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t5750)) {
    t5748 = t5750;
  } else {
  KLObject* t5752 = shen_hd(ctx, t5741);
  KLObject* t5753 = shen_cons_p(ctx, t5752);
    if (!shen_is_boolean(ctx, t5753))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t5748 = t5753;
  }
    if (!shen_is_boolean(ctx, t5748))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t5748)) {
  KLObject* t5755 = shen_tl(ctx, t5741);
  KLObject* t5758 = shen_hd(ctx, t5741);
  KLObject* t5759 = shen_hd(ctx, t5758);
  KLObject* t5761 = shen_hd(ctx, t5741);
  KLObject* t5762 = shen_tl(ctx, t5761);
  KLObject* t5756;
  {
    KLObject* a5756[] = {t5759, t5762, t5742};
    t5756 = shen_apply_direct(ctx, "shen.beta", 3, a5756);
  }
  {
    KLObject* n5764_0 = t5755;
    KLObject* n5764_1 = t5756;
    t5741 = n5764_0;
    t5742 = n5764_1;
    goto tail_start_kl_shen_2efreshen_40;
  }
  KLObject* t5764 = NULL;
      t5743 = t5764;
    } else {
  KLObject* t5765 = shen_true(ctx);
    if (!shen_is_boolean(ctx, t5765))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t5765)) {
  KLObject* t5767 = shen_string(ctx, "partial function shen.freshen");
  KLObject* t5766;
  {
    KLObject* a5766[] = {t5767};
    t5766 = shen_tail_apply_direct(ctx, "simple-error", 1, a5766);
  }
      t5743 = t5766;
    } else {
      shen_simple_error(ctx, "No true case found for cond");
      t5743 = shen_empty_list(ctx);
    }
    }
    }
  }
    return t5743;
  }
}

static KLObject* native_kl_shen_2et_2a_2drule_41 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t5768 = objects[0];
    KLObject* t5769 = objects[1];
    KLObject* t5770 = objects[2];
    KLObject* t5771 = objects[3];
    KLObject* t5772 = objects[4];
    KLObject* t5773 = objects[5];
    KLObject* t5774 = objects[6];
    KLObject* t5775 = objects[7];
    KLObject* t5776 = objects[8];
  tail_start_kl_shen_2et_2a_2drule_41: ;
  KLObject* t5778;
  {
    KLObject* a5778[] = {t5774};
    t5778 = shen_apply_direct(ctx, "shen.unlocked?", 1, a5778);
  }
  KLObject* t5777;
  if (!shen_is_boolean(ctx, t5778))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t5778)) {
  KLObject* t5780 = shen_apply_direct(ctx, "shen.incinfs", 0, NULL);
  KLObject* t5781;
  {
    KLObject* a5781[] = {t5770, t5771, t5772, t5773, t5774, t5775, t5776};
    t5781 = shen_apply_direct(ctx, "shen.t*-rule-h", 7, a5781);
  }
    t5777 = t5781;
  } else {
  KLObject* t5789 = shen_false(ctx);
    t5777 = t5789;
  }
  KLObject* t5792 = shen_false(ctx);
  KLObject* t5793 = shen_eq(ctx, t5777, t5792);
  KLObject* t5790;
  if (!shen_is_boolean(ctx, t5793))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t5793)) {
  KLObject* t5795;
  {
    KLObject* a5795[] = {t5774};
    t5795 = shen_apply_direct(ctx, "shen.unlocked?", 1, a5795);
  }
  KLObject* t5794;
  if (!shen_is_boolean(ctx, t5795))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t5795)) {
  KLObject* t5797;
  {
    KLObject* a5797[] = {t5773};
    t5797 = shen_apply_direct(ctx, "shen.newpv", 1, a5797);
  }
  KLObject* t5801 = shen_apply_direct(ctx, "shen.incinfs", 0, NULL);
  KLObject* t5806 = shen_string(ctx, "type error in rule ");
  KLObject* t5810 = shen_string(ctx, " of ");
  KLObject* t5813 = shen_string(ctx, "\n");
  KLObject* t5814 = shen_intern(ctx, "shen.a");
  KLObject* t5811;
  {
    KLObject* a5811[] = {t5768, t5813, t5814};
    t5811 = shen_apply_direct(ctx, "shen.app", 3, a5811);
  }
  KLObject* t5809;
  {
    KLObject* a5809[] = {t5810, t5811};
    t5809 = shen_apply_direct(ctx, "cn", 2, a5809);
  }
  KLObject* t5815 = shen_intern(ctx, "shen.a");
  KLObject* t5807;
  {
    KLObject* a5807[] = {t5769, t5809, t5815};
    t5807 = shen_apply_direct(ctx, "shen.app", 3, a5807);
  }
  KLObject* t5805;
  {
    KLObject* a5805[] = {t5806, t5807};
    t5805 = shen_apply_direct(ctx, "cn", 2, a5805);
  }
  KLObject* t5804;
  {
    KLObject* a5804[] = {t5805};
    t5804 = shen_apply_direct(ctx, "simple-error", 1, a5804);
  }
  KLObject* t5802;
  {
    KLObject* a5802[] = {t5797, t5804, t5773, t5774, t5775, t5776};
    t5802 = shen_apply_direct(ctx, "bind", 6, a5802);
  }
  KLObject* t5799;
  {
    KLObject* a5799[] = {t5773, t5802};
    t5799 = shen_tail_apply_direct(ctx, "shen.gc", 2, a5799);
  }
    t5794 = t5799;
  } else {
  KLObject* t5820 = shen_false(ctx);
    t5794 = t5820;
  }
    t5790 = t5794;
  } else {
    t5790 = t5777;
  }
    return t5790;
  }
}

static KLObject* native_kl_shen_2et_2a_2drule_2dh_42 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t5822 = objects[0];
    KLObject* t5823 = objects[1];
    KLObject* t5824 = objects[2];
    KLObject* t5825 = objects[3];
    KLObject* t5826 = objects[4];
    KLObject* t5827 = objects[5];
    KLObject* t5828 = objects[6];
  tail_start_kl_shen_2et_2a_2drule_2dh_42: ;
  KLObject* t5830 = shen_number_l(ctx, 1);
  KLObject* t5831 = shen_add(ctx, t5827, t5830);
  KLObject* t5833;
  {
    KLObject* a5833[] = {t5826};
    t5833 = shen_apply_direct(ctx, "shen.unlocked?", 1, a5833);
  }
  KLObject* t5832;
  if (!shen_is_boolean(ctx, t5833))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t5833)) {
  KLObject* t5835;
  {
    KLObject* a5835[] = {t5822, t5825};
    t5835 = shen_apply_direct(ctx, "shen.lazyderef", 2, a5835);
  }
  KLObject* t5840 = shen_empty_list(ctx);
  KLObject* t5841 = shen_eq(ctx, t5835, t5840);
  KLObject* t5838;
  if (!shen_is_boolean(ctx, t5841))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t5841)) {
  KLObject* t5842;
  {
    KLObject* a5842[] = {t5824, t5825};
    t5842 = shen_apply_direct(ctx, "shen.lazyderef", 2, a5842);
  }
  KLObject* t5847 = shen_cons_p(ctx, t5842);
  KLObject* t5845;
  if (!shen_is_boolean(ctx, t5847))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t5847)) {
  KLObject* t5850 = shen_hd(ctx, t5842);
  KLObject* t5848;
  {
    KLObject* a5848[] = {t5850, t5825};
    t5848 = shen_apply_direct(ctx, "shen.lazyderef", 2, a5848);
  }
  KLObject* t5854 = shen_intern(ctx, "-->");
  KLObject* t5855 = shen_eq(ctx, t5848, t5854);
  KLObject* t5852;
  if (!shen_is_boolean(ctx, t5855))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t5855)) {
  KLObject* t5858 = shen_tl(ctx, t5842);
  KLObject* t5856;
  {
    KLObject* a5856[] = {t5858, t5825};
    t5856 = shen_apply_direct(ctx, "shen.lazyderef", 2, a5856);
  }
  KLObject* t5862 = shen_cons_p(ctx, t5856);
  KLObject* t5860;
  if (!shen_is_boolean(ctx, t5862))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t5862)) {
  KLObject* t5864 = shen_hd(ctx, t5856);
  KLObject* t5867 = shen_tl(ctx, t5856);
  KLObject* t5865;
  {
    KLObject* a5865[] = {t5867, t5825};
    t5865 = shen_apply_direct(ctx, "shen.lazyderef", 2, a5865);
  }
  KLObject* t5871 = shen_empty_list(ctx);
  KLObject* t5872 = shen_eq(ctx, t5865, t5871);
  KLObject* t5869;
  if (!shen_is_boolean(ctx, t5872))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t5872)) {
  KLObject* t5873 = shen_apply_direct(ctx, "shen.incinfs", 0, NULL);
  KLObject* t5878;
  {
    Vector* caps_118 = shen_vector(ctx, 6);
    shen_vector_set(ctx, caps_118, 0, t5823);
    shen_vector_set(ctx, caps_118, 1, t5864);
    shen_vector_set(ctx, caps_118, 2, t5825);
    shen_vector_set(ctx, caps_118, 3, t5826);
    shen_vector_set(ctx, caps_118, 4, t5831);
    shen_vector_set(ctx, caps_118, 5, t5828);
    t5878 = shen_native_closure(ctx, 0, &lambda_118, caps_118);
  }
  KLObject* t5874;
  {
    KLObject* a5874[] = {t5825, t5826, t5831, t5878};
    t5874 = shen_apply_direct(ctx, "shen.cut", 4, a5874);
  }
    t5869 = t5874;
  } else {
  KLObject* t5893 = shen_false(ctx);
    t5869 = t5893;
  }
    t5860 = t5869;
  } else {
  KLObject* t5894 = shen_false(ctx);
    t5860 = t5894;
  }
    t5852 = t5860;
  } else {
  KLObject* t5895 = shen_false(ctx);
    t5852 = t5895;
  }
    t5845 = t5852;
  } else {
  KLObject* t5896 = shen_false(ctx);
    t5845 = t5896;
  }
    t5838 = t5845;
  } else {
  KLObject* t5897 = shen_false(ctx);
    t5838 = t5897;
  }
    t5832 = t5838;
  } else {
  KLObject* t5898 = shen_false(ctx);
    t5832 = t5898;
  }
  KLObject* t5901 = shen_false(ctx);
  KLObject* t5902 = shen_eq(ctx, t5832, t5901);
  KLObject* t5899;
  if (!shen_is_boolean(ctx, t5902))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t5902)) {
  KLObject* t5904;
  {
    KLObject* a5904[] = {t5826};
    t5904 = shen_apply_direct(ctx, "shen.unlocked?", 1, a5904);
  }
  KLObject* t5903;
  if (!shen_is_boolean(ctx, t5904))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t5904)) {
  KLObject* t5906;
  {
    KLObject* a5906[] = {t5825};
    t5906 = shen_apply_direct(ctx, "shen.newpv", 1, a5906);
  }
  KLObject* t5910;
  {
    KLObject* a5910[] = {t5825};
    t5910 = shen_apply_direct(ctx, "shen.newpv", 1, a5910);
  }
  KLObject* t5914;
  {
    KLObject* a5914[] = {t5825};
    t5914 = shen_apply_direct(ctx, "shen.newpv", 1, a5914);
  }
  KLObject* t5918 = shen_apply_direct(ctx, "shen.incinfs", 0, NULL);
  KLObject* t5920;
  {
    KLObject* a5920[] = {t5822};
    t5920 = shen_apply_direct(ctx, "shen.freshterms", 1, a5920);
  }
  KLObject* t5926;
  {
    Vector* caps_119 = shen_vector(ctx, 10);
    shen_vector_set(ctx, caps_119, 0, t5822);
    shen_vector_set(ctx, caps_119, 1, t5824);
    shen_vector_set(ctx, caps_119, 2, t5906);
    shen_vector_set(ctx, caps_119, 3, t5910);
    shen_vector_set(ctx, caps_119, 4, t5825);
    shen_vector_set(ctx, caps_119, 5, t5826);
    shen_vector_set(ctx, caps_119, 6, t5831);
    shen_vector_set(ctx, caps_119, 7, t5914);
    shen_vector_set(ctx, caps_119, 8, t5823);
    shen_vector_set(ctx, caps_119, 9, t5828);
    t5926 = shen_native_closure(ctx, 0, &lambda_119, caps_119);
  }
  KLObject* t5919;
  {
    KLObject* a5919[] = {t5920, t5906, t5825, t5826, t5831, t5926};
    t5919 = shen_apply_direct(ctx, "shen.p-hyps", 6, a5919);
  }
  KLObject* t5916;
  {
    KLObject* a5916[] = {t5825, t5919};
    t5916 = shen_apply_direct(ctx, "shen.gc", 2, a5916);
  }
  KLObject* t5912;
  {
    KLObject* a5912[] = {t5825, t5916};
    t5912 = shen_apply_direct(ctx, "shen.gc", 2, a5912);
  }
  KLObject* t5908;
  {
    KLObject* a5908[] = {t5825, t5912};
    t5908 = shen_apply_direct(ctx, "shen.gc", 2, a5908);
  }
    t5903 = t5908;
  } else {
  KLObject* t5992 = shen_false(ctx);
    t5903 = t5992;
  }
  KLObject* t5995 = shen_false(ctx);
  KLObject* t5996 = shen_eq(ctx, t5903, t5995);
  KLObject* t5993;
  if (!shen_is_boolean(ctx, t5996))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t5996)) {
  KLObject* t5997;
  {
    KLObject* a5997[] = {t5826, t5831};
    t5997 = shen_tail_apply_direct(ctx, "shen.unlock", 2, a5997);
  }
    t5993 = t5997;
  } else {
    t5993 = t5903;
  }
    t5899 = t5993;
  } else {
    t5899 = t5832;
  }
    return t5899;
  }
}

static KLObject* native_kl_shen_2emyassume_43 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t6002 = objects[0];
    KLObject* t6003 = objects[1];
    KLObject* t6004 = objects[2];
    KLObject* t6005 = objects[3];
    KLObject* t6006 = objects[4];
    KLObject* t6007 = objects[5];
    KLObject* t6008 = objects[6];
  tail_start_kl_shen_2emyassume_43: ;
  KLObject* t6010;
  {
    KLObject* a6010[] = {t6006};
    t6010 = shen_apply_direct(ctx, "shen.unlocked?", 1, a6010);
  }
  KLObject* t6009;
  if (!shen_is_boolean(ctx, t6010))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t6010)) {
  KLObject* t6012;
  {
    KLObject* a6012[] = {t6002, t6005};
    t6012 = shen_apply_direct(ctx, "shen.lazyderef", 2, a6012);
  }
  KLObject* t6017 = shen_empty_list(ctx);
  KLObject* t6018 = shen_eq(ctx, t6012, t6017);
  KLObject* t6015;
  if (!shen_is_boolean(ctx, t6018))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t6018)) {
  KLObject* t6019;
  {
    KLObject* a6019[] = {t6004, t6005};
    t6019 = shen_apply_direct(ctx, "shen.lazyderef", 2, a6019);
  }
  KLObject* t6022;
  {
    Vector* caps_123 = shen_vector(ctx, 1);
    shen_vector_set(ctx, caps_123, 0, t6008);
    t6022 = shen_native_closure(ctx, 0, &lambda_123, caps_123);
  }
  KLObject* t6029 = shen_empty_list(ctx);
  KLObject* t6030 = shen_eq(ctx, t6019, t6029);
  KLObject* t6027;
  if (!shen_is_boolean(ctx, t6030))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t6030)) {
  KLObject* t6031;
  {
    KLObject* a6031[] = {t6022};
    t6031 = shen_apply_direct(ctx, "thaw", 1, a6031);
  }
    t6027 = t6031;
  } else {
  KLObject* t6034;
  {
    KLObject* a6034[] = {t6019};
    t6034 = shen_apply_direct(ctx, "shen.pvar?", 1, a6034);
  }
  KLObject* t6033;
  if (!shen_is_boolean(ctx, t6034))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t6034)) {
  KLObject* t6038 = shen_empty_list(ctx);
  KLObject* t6036;
  {
    KLObject* a6036[] = {t6019, t6038, t6005, t6022};
    t6036 = shen_apply_direct(ctx, "shen.bind!", 4, a6036);
  }
    t6033 = t6036;
  } else {
  KLObject* t6041 = shen_false(ctx);
    t6033 = t6041;
  }
    t6027 = t6033;
  }
    t6015 = t6027;
  } else {
  KLObject* t6042 = shen_false(ctx);
    t6015 = t6042;
  }
    t6009 = t6015;
  } else {
  KLObject* t6043 = shen_false(ctx);
    t6009 = t6043;
  }
  KLObject* t6046 = shen_false(ctx);
  KLObject* t6047 = shen_eq(ctx, t6009, t6046);
  KLObject* t6044;
  if (!shen_is_boolean(ctx, t6047))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t6047)) {
  KLObject* t6049;
  {
    KLObject* a6049[] = {t6006};
    t6049 = shen_apply_direct(ctx, "shen.unlocked?", 1, a6049);
  }
  KLObject* t6048;
  if (!shen_is_boolean(ctx, t6049))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t6049)) {
  KLObject* t6051;
  {
    KLObject* a6051[] = {t6002, t6005};
    t6051 = shen_apply_direct(ctx, "shen.lazyderef", 2, a6051);
  }
  KLObject* t6056 = shen_cons_p(ctx, t6051);
  KLObject* t6054;
  if (!shen_is_boolean(ctx, t6056))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t6056)) {
  KLObject* t6058 = shen_hd(ctx, t6051);
  KLObject* t6060 = shen_tl(ctx, t6051);
  KLObject* t6061;
  {
    KLObject* a6061[] = {t6003, t6005};
    t6061 = shen_apply_direct(ctx, "shen.lazyderef", 2, a6061);
  }
  KLObject* t6066 = shen_cons_p(ctx, t6061);
  KLObject* t6064;
  if (!shen_is_boolean(ctx, t6066))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t6066)) {
  KLObject* t6068 = shen_hd(ctx, t6061);
  KLObject* t6071 = shen_tl(ctx, t6061);
  KLObject* t6069;
  {
    KLObject* a6069[] = {t6071, t6005};
    t6069 = shen_apply_direct(ctx, "shen.lazyderef", 2, a6069);
  }
  KLObject* t6075 = shen_cons_p(ctx, t6069);
  KLObject* t6073;
  if (!shen_is_boolean(ctx, t6075))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t6075)) {
  KLObject* t6078 = shen_hd(ctx, t6069);
  KLObject* t6076;
  {
    KLObject* a6076[] = {t6078, t6005};
    t6076 = shen_apply_direct(ctx, "shen.lazyderef", 2, a6076);
  }
  KLObject* t6082 = shen_intern(ctx, "-->");
  KLObject* t6083 = shen_eq(ctx, t6076, t6082);
  KLObject* t6080;
  if (!shen_is_boolean(ctx, t6083))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t6083)) {
  KLObject* t6086 = shen_tl(ctx, t6069);
  KLObject* t6084;
  {
    KLObject* a6084[] = {t6086, t6005};
    t6084 = shen_apply_direct(ctx, "shen.lazyderef", 2, a6084);
  }
  KLObject* t6090 = shen_cons_p(ctx, t6084);
  KLObject* t6088;
  if (!shen_is_boolean(ctx, t6090))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t6090)) {
  KLObject* t6092 = shen_hd(ctx, t6084);
  KLObject* t6095 = shen_tl(ctx, t6084);
  KLObject* t6093;
  {
    KLObject* a6093[] = {t6095, t6005};
    t6093 = shen_apply_direct(ctx, "shen.lazyderef", 2, a6093);
  }
  KLObject* t6099 = shen_empty_list(ctx);
  KLObject* t6100 = shen_eq(ctx, t6093, t6099);
  KLObject* t6097;
  if (!shen_is_boolean(ctx, t6100))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t6100)) {
  KLObject* t6101;
  {
    KLObject* a6101[] = {t6004, t6005};
    t6101 = shen_apply_direct(ctx, "shen.lazyderef", 2, a6101);
  }
  KLObject* t6104;
  {
    Vector* caps_124 = shen_vector(ctx, 8);
    shen_vector_set(ctx, caps_124, 0, t6068);
    shen_vector_set(ctx, caps_124, 1, t6005);
    shen_vector_set(ctx, caps_124, 2, t6006);
    shen_vector_set(ctx, caps_124, 3, t6007);
    shen_vector_set(ctx, caps_124, 4, t6058);
    shen_vector_set(ctx, caps_124, 5, t6060);
    shen_vector_set(ctx, caps_124, 6, t6092);
    shen_vector_set(ctx, caps_124, 7, t6008);
    t6104 = shen_native_closure(ctx, 1, &lambda_124, caps_124);
  }
  KLObject* t6208 = shen_cons_p(ctx, t6101);
  KLObject* t6206;
  if (!shen_is_boolean(ctx, t6208))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t6208)) {
  KLObject* t6211 = shen_hd(ctx, t6101);
  KLObject* t6209;
  {
    KLObject* a6209[] = {t6211, t6005};
    t6209 = shen_apply_direct(ctx, "shen.lazyderef", 2, a6209);
  }
  KLObject* t6213;
  {
    Vector* caps_131 = shen_vector(ctx, 2);
    shen_vector_set(ctx, caps_131, 0, t6101);
    shen_vector_set(ctx, caps_131, 1, t6104);
    t6213 = shen_native_closure(ctx, 1, &lambda_131, caps_131);
  }
  KLObject* t6241 = shen_cons_p(ctx, t6209);
  KLObject* t6239;
  if (!shen_is_boolean(ctx, t6241))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t6241)) {
  KLObject* t6243 = shen_hd(ctx, t6209);
  KLObject* t6246 = shen_tl(ctx, t6209);
  KLObject* t6244;
  {
    KLObject* a6244[] = {t6246, t6005};
    t6244 = shen_apply_direct(ctx, "shen.lazyderef", 2, a6244);
  }
  KLObject* t6248;
  {
    Vector* caps_134 = shen_vector(ctx, 2);
    shen_vector_set(ctx, caps_134, 0, t6213);
    shen_vector_set(ctx, caps_134, 1, t6243);
    t6248 = shen_native_closure(ctx, 1, &lambda_134, caps_134);
  }
  KLObject* t6266 = shen_cons_p(ctx, t6244);
  KLObject* t6264;
  if (!shen_is_boolean(ctx, t6266))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t6266)) {
  KLObject* t6268 = shen_hd(ctx, t6244);
  KLObject* t6271 = shen_tl(ctx, t6244);
  KLObject* t6269;
  {
    KLObject* a6269[] = {t6271, t6005};
    t6269 = shen_apply_direct(ctx, "shen.lazyderef", 2, a6269);
  }
  KLObject* t6273;
  {
    Vector* caps_136 = shen_vector(ctx, 2);
    shen_vector_set(ctx, caps_136, 0, t6248);
    shen_vector_set(ctx, caps_136, 1, t6268);
    t6273 = shen_native_closure(ctx, 1, &lambda_136, caps_136);
  }
  KLObject* t6284 = shen_cons_p(ctx, t6269);
  KLObject* t6282;
  if (!shen_is_boolean(ctx, t6284))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t6284)) {
  KLObject* t6286 = shen_hd(ctx, t6269);
  KLObject* t6289 = shen_tl(ctx, t6269);
  KLObject* t6287;
  {
    KLObject* a6287[] = {t6289, t6005};
    t6287 = shen_apply_direct(ctx, "shen.lazyderef", 2, a6287);
  }
  KLObject* t6291;
  {
    Vector* caps_137 = shen_vector(ctx, 2);
    shen_vector_set(ctx, caps_137, 0, t6273);
    shen_vector_set(ctx, caps_137, 1, t6286);
    t6291 = shen_native_closure(ctx, 0, &lambda_137, caps_137);
  }
  KLObject* t6299 = shen_empty_list(ctx);
  KLObject* t6300 = shen_eq(ctx, t6287, t6299);
  KLObject* t6297;
  if (!shen_is_boolean(ctx, t6300))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t6300)) {
  KLObject* t6301;
  {
    KLObject* a6301[] = {t6291};
    t6301 = shen_tail_apply_direct(ctx, "thaw", 1, a6301);
  }
    t6297 = t6301;
  } else {
  KLObject* t6304;
  {
    KLObject* a6304[] = {t6287};
    t6304 = shen_apply_direct(ctx, "shen.pvar?", 1, a6304);
  }
  KLObject* t6303;
  if (!shen_is_boolean(ctx, t6304))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t6304)) {
  KLObject* t6308 = shen_empty_list(ctx);
  KLObject* t6306;
  {
    KLObject* a6306[] = {t6287, t6308, t6005, t6291};
    t6306 = shen_tail_apply_direct(ctx, "shen.bind!", 4, a6306);
  }
    t6303 = t6306;
  } else {
  KLObject* t6311 = shen_false(ctx);
    t6303 = t6311;
  }
    t6297 = t6303;
  }
    t6282 = t6297;
  } else {
  KLObject* t6313;
  {
    KLObject* a6313[] = {t6269};
    t6313 = shen_apply_direct(ctx, "shen.pvar?", 1, a6313);
  }
  KLObject* t6312;
  if (!shen_is_boolean(ctx, t6313))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t6313)) {
  KLObject* t6315;
  {
    KLObject* a6315[] = {t6005};
    t6315 = shen_apply_direct(ctx, "shen.newpv", 1, a6315);
  }
  KLObject* t6322 = shen_empty_list(ctx);
  KLObject* t6323 = shen_cons(ctx, t6315, t6322);
  KLObject* t6325;
  {
    Vector* caps_138 = shen_vector(ctx, 2);
    shen_vector_set(ctx, caps_138, 0, t6273);
    shen_vector_set(ctx, caps_138, 1, t6315);
    t6325 = shen_native_closure(ctx, 0, &lambda_138, caps_138);
  }
  KLObject* t6319;
  {
    KLObject* a6319[] = {t6269, t6323, t6005, t6325};
    t6319 = shen_apply_direct(ctx, "shen.bind!", 4, a6319);
  }
  KLObject* t6317;
  {
    KLObject* a6317[] = {t6005, t6319};
    t6317 = shen_tail_apply_direct(ctx, "shen.gc", 2, a6317);
  }
    t6312 = t6317;
  } else {
  KLObject* t6331 = shen_false(ctx);
    t6312 = t6331;
  }
    t6282 = t6312;
  }
    t6264 = t6282;
  } else {
  KLObject* t6333;
  {
    KLObject* a6333[] = {t6244};
    t6333 = shen_apply_direct(ctx, "shen.pvar?", 1, a6333);
  }
  KLObject* t6332;
  if (!shen_is_boolean(ctx, t6333))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t6333)) {
  KLObject* t6335;
  {
    KLObject* a6335[] = {t6005};
    t6335 = shen_apply_direct(ctx, "shen.newpv", 1, a6335);
  }
  KLObject* t6339;
  {
    KLObject* a6339[] = {t6005};
    t6339 = shen_apply_direct(ctx, "shen.newpv", 1, a6339);
  }
  KLObject* t6347 = shen_empty_list(ctx);
  KLObject* t6348 = shen_cons(ctx, t6339, t6347);
  KLObject* t6349 = shen_cons(ctx, t6335, t6348);
  KLObject* t6351;
  {
    Vector* caps_139 = shen_vector(ctx, 3);
    shen_vector_set(ctx, caps_139, 0, t6248);
    shen_vector_set(ctx, caps_139, 1, t6335);
    shen_vector_set(ctx, caps_139, 2, t6339);
    t6351 = shen_native_closure(ctx, 0, &lambda_139, caps_139);
  }
  KLObject* t6343;
  {
    KLObject* a6343[] = {t6244, t6349, t6005, t6351};
    t6343 = shen_apply_direct(ctx, "shen.bind!", 4, a6343);
  }
  KLObject* t6341;
  {
    KLObject* a6341[] = {t6005, t6343};
    t6341 = shen_apply_direct(ctx, "shen.gc", 2, a6341);
  }
  KLObject* t6337;
  {
    KLObject* a6337[] = {t6005, t6341};
    t6337 = shen_tail_apply_direct(ctx, "shen.gc", 2, a6337);
  }
    t6332 = t6337;
  } else {
  KLObject* t6360 = shen_false(ctx);
    t6332 = t6360;
  }
    t6264 = t6332;
  }
    t6239 = t6264;
  } else {
  KLObject* t6362;
  {
    KLObject* a6362[] = {t6209};
    t6362 = shen_apply_direct(ctx, "shen.pvar?", 1, a6362);
  }
  KLObject* t6361;
  if (!shen_is_boolean(ctx, t6362))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t6362)) {
  KLObject* t6364;
  {
    KLObject* a6364[] = {t6005};
    t6364 = shen_apply_direct(ctx, "shen.newpv", 1, a6364);
  }
  KLObject* t6368;
  {
    KLObject* a6368[] = {t6005};
    t6368 = shen_apply_direct(ctx, "shen.newpv", 1, a6368);
  }
  KLObject* t6372;
  {
    KLObject* a6372[] = {t6005};
    t6372 = shen_apply_direct(ctx, "shen.newpv", 1, a6372);
  }
  KLObject* t6381 = shen_empty_list(ctx);
  KLObject* t6382 = shen_cons(ctx, t6372, t6381);
  KLObject* t6383 = shen_cons(ctx, t6368, t6382);
  KLObject* t6384 = shen_cons(ctx, t6364, t6383);
  KLObject* t6386;
  {
    Vector* caps_140 = shen_vector(ctx, 4);
    shen_vector_set(ctx, caps_140, 0, t6213);
    shen_vector_set(ctx, caps_140, 1, t6364);
    shen_vector_set(ctx, caps_140, 2, t6368);
    shen_vector_set(ctx, caps_140, 3, t6372);
    t6386 = shen_native_closure(ctx, 0, &lambda_140, caps_140);
  }
  KLObject* t6376;
  {
    KLObject* a6376[] = {t6209, t6384, t6005, t6386};
    t6376 = shen_apply_direct(ctx, "shen.bind!", 4, a6376);
  }
  KLObject* t6374;
  {
    KLObject* a6374[] = {t6005, t6376};
    t6374 = shen_apply_direct(ctx, "shen.gc", 2, a6374);
  }
  KLObject* t6370;
  {
    KLObject* a6370[] = {t6005, t6374};
    t6370 = shen_apply_direct(ctx, "shen.gc", 2, a6370);
  }
  KLObject* t6366;
  {
    KLObject* a6366[] = {t6005, t6370};
    t6366 = shen_tail_apply_direct(ctx, "shen.gc", 2, a6366);
  }
    t6361 = t6366;
  } else {
  KLObject* t6398 = shen_false(ctx);
    t6361 = t6398;
  }
    t6239 = t6361;
  }
    t6206 = t6239;
  } else {
  KLObject* t6400;
  {
    KLObject* a6400[] = {t6101};
    t6400 = shen_apply_direct(ctx, "shen.pvar?", 1, a6400);
  }
  KLObject* t6399;
  if (!shen_is_boolean(ctx, t6400))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t6400)) {
  KLObject* t6402;
  {
    KLObject* a6402[] = {t6005};
    t6402 = shen_apply_direct(ctx, "shen.newpv", 1, a6402);
  }
  KLObject* t6406;
  {
    KLObject* a6406[] = {t6005};
    t6406 = shen_apply_direct(ctx, "shen.newpv", 1, a6406);
  }
  KLObject* t6410;
  {
    KLObject* a6410[] = {t6005};
    t6410 = shen_apply_direct(ctx, "shen.newpv", 1, a6410);
  }
  KLObject* t6414;
  {
    KLObject* a6414[] = {t6005};
    t6414 = shen_apply_direct(ctx, "shen.newpv", 1, a6414);
  }
  KLObject* t6423 = shen_empty_list(ctx);
  KLObject* t6424 = shen_cons(ctx, t6410, t6423);
  KLObject* t6425 = shen_cons(ctx, t6406, t6424);
  KLObject* t6426 = shen_cons(ctx, t6402, t6425);
  KLObject* t6428 = shen_cons(ctx, t6426, t6414);
  KLObject* t6430;
  {
    Vector* caps_141 = shen_vector(ctx, 5);
    shen_vector_set(ctx, caps_141, 0, t6104);
    shen_vector_set(ctx, caps_141, 1, t6402);
    shen_vector_set(ctx, caps_141, 2, t6406);
    shen_vector_set(ctx, caps_141, 3, t6410);
    shen_vector_set(ctx, caps_141, 4, t6414);
    t6430 = shen_native_closure(ctx, 0, &lambda_141, caps_141);
  }
  KLObject* t6418;
  {
    KLObject* a6418[] = {t6101, t6428, t6005, t6430};
    t6418 = shen_apply_direct(ctx, "shen.bind!", 4, a6418);
  }
  KLObject* t6416;
  {
    KLObject* a6416[] = {t6005, t6418};
    t6416 = shen_apply_direct(ctx, "shen.gc", 2, a6416);
  }
  KLObject* t6412;
  {
    KLObject* a6412[] = {t6005, t6416};
    t6412 = shen_apply_direct(ctx, "shen.gc", 2, a6412);
  }
  KLObject* t6408;
  {
    KLObject* a6408[] = {t6005, t6412};
    t6408 = shen_apply_direct(ctx, "shen.gc", 2, a6408);
  }
  KLObject* t6404;
  {
    KLObject* a6404[] = {t6005, t6408};
    t6404 = shen_tail_apply_direct(ctx, "shen.gc", 2, a6404);
  }
    t6399 = t6404;
  } else {
  KLObject* t6445 = shen_false(ctx);
    t6399 = t6445;
  }
    t6206 = t6399;
  }
    t6097 = t6206;
  } else {
  KLObject* t6446 = shen_false(ctx);
    t6097 = t6446;
  }
    t6088 = t6097;
  } else {
  KLObject* t6447 = shen_false(ctx);
    t6088 = t6447;
  }
    t6080 = t6088;
  } else {
  KLObject* t6448 = shen_false(ctx);
    t6080 = t6448;
  }
    t6073 = t6080;
  } else {
  KLObject* t6449 = shen_false(ctx);
    t6073 = t6449;
  }
    t6064 = t6073;
  } else {
  KLObject* t6450 = shen_false(ctx);
    t6064 = t6450;
  }
    t6054 = t6064;
  } else {
  KLObject* t6451 = shen_false(ctx);
    t6054 = t6451;
  }
    t6048 = t6054;
  } else {
  KLObject* t6452 = shen_false(ctx);
    t6048 = t6452;
  }
    t6044 = t6048;
  } else {
    t6044 = t6009;
  }
    return t6044;
  }
}

static KLObject* native_kl_shen_2efreshterms_44 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t6454 = objects[0];
  tail_start_kl_shen_2efreshterms_44: ;
  KLObject* t6455;
  {
  KLObject* t6456 = shen_empty_list(ctx);
  KLObject* t6458 = shen_eq(ctx, t6456, t6454);
    if (!shen_is_boolean(ctx, t6458))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t6458)) {
  KLObject* t6459 = shen_empty_list(ctx);
      t6455 = t6459;
    } else {
  KLObject* t6462 = shen_cons_p(ctx, t6454);
  KLObject* t6460;
  if (!shen_is_boolean(ctx, t6462))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t6462)) {
    t6460 = t6462;
  } else {
  KLObject* t6464 = shen_hd(ctx, t6454);
  KLObject* t6465 = shen_cons_p(ctx, t6464);
    if (!shen_is_boolean(ctx, t6465))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t6460 = t6465;
  }
    if (!shen_is_boolean(ctx, t6460))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t6460)) {
  KLObject* t6468 = shen_hd(ctx, t6454);
  KLObject* t6470 = shen_tl(ctx, t6454);
  KLObject* t6466;
  {
    KLObject* a6466[] = {t6468, t6470};
    t6466 = shen_apply_direct(ctx, "append", 2, a6466);
  }
  {
    KLObject* n6471_0 = t6466;
    t6454 = n6471_0;
    goto tail_start_kl_shen_2efreshterms_44;
  }
  KLObject* t6471 = NULL;
      t6455 = t6471;
    } else {
  KLObject* t6474 = shen_cons_p(ctx, t6454);
  KLObject* t6472;
  if (!shen_is_boolean(ctx, t6474))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t6474)) {
    t6472 = t6474;
  } else {
  KLObject* t6477 = shen_hd(ctx, t6454);
  KLObject* t6475;
  {
    KLObject* a6475[] = {t6477};
    t6475 = shen_apply_direct(ctx, "shen.freshterm?", 1, a6475);
  }
    if (!shen_is_boolean(ctx, t6475))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t6472 = t6475;
  }
    if (!shen_is_boolean(ctx, t6472))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t6472)) {
  KLObject* t6480 = shen_hd(ctx, t6454);
  KLObject* t6483 = shen_tl(ctx, t6454);
  KLObject* t6481;
  {
    KLObject* a6481[] = {t6483};
    t6481 = shen_apply_direct(ctx, "shen.freshterms", 1, a6481);
  }
  KLObject* t6478;
  {
    KLObject* a6478[] = {t6480, t6481};
    t6478 = shen_tail_apply_direct(ctx, "adjoin", 2, a6478);
  }
      t6455 = t6478;
    } else {
  KLObject* t6485 = shen_cons_p(ctx, t6454);
    if (!shen_is_boolean(ctx, t6485))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t6485)) {
  KLObject* t6487 = shen_tl(ctx, t6454);
  {
    KLObject* n6488_0 = t6487;
    t6454 = n6488_0;
    goto tail_start_kl_shen_2efreshterms_44;
  }
  KLObject* t6488 = NULL;
      t6455 = t6488;
    } else {
  KLObject* t6489 = shen_true(ctx);
    if (!shen_is_boolean(ctx, t6489))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t6489)) {
  KLObject* t6491 = shen_string(ctx, "partial function shen.freshterms");
  KLObject* t6490;
  {
    KLObject* a6490[] = {t6491};
    t6490 = shen_tail_apply_direct(ctx, "simple-error", 1, a6490);
  }
      t6455 = t6490;
    } else {
      shen_simple_error(ctx, "No true case found for cond");
      t6455 = shen_empty_list(ctx);
    }
    }
    }
    }
    }
  }
    return t6455;
  }
}

static KLObject* native_kl_shen_2ep_2dhyps_45 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t6492 = objects[0];
    KLObject* t6493 = objects[1];
    KLObject* t6494 = objects[2];
    KLObject* t6495 = objects[3];
    KLObject* t6496 = objects[4];
    KLObject* t6497 = objects[5];
  tail_start_kl_shen_2ep_2dhyps_45: ;
  KLObject* t6499;
  {
    KLObject* a6499[] = {t6495};
    t6499 = shen_apply_direct(ctx, "shen.unlocked?", 1, a6499);
  }
  KLObject* t6498;
  if (!shen_is_boolean(ctx, t6499))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t6499)) {
  KLObject* t6501;
  {
    KLObject* a6501[] = {t6492, t6494};
    t6501 = shen_apply_direct(ctx, "shen.lazyderef", 2, a6501);
  }
  KLObject* t6506 = shen_empty_list(ctx);
  KLObject* t6507 = shen_eq(ctx, t6501, t6506);
  KLObject* t6504;
  if (!shen_is_boolean(ctx, t6507))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t6507)) {
  KLObject* t6508;
  {
    KLObject* a6508[] = {t6493, t6494};
    t6508 = shen_apply_direct(ctx, "shen.lazyderef", 2, a6508);
  }
  KLObject* t6511;
  {
    Vector* caps_142 = shen_vector(ctx, 1);
    shen_vector_set(ctx, caps_142, 0, t6497);
    t6511 = shen_native_closure(ctx, 0, &lambda_142, caps_142);
  }
  KLObject* t6518 = shen_empty_list(ctx);
  KLObject* t6519 = shen_eq(ctx, t6508, t6518);
  KLObject* t6516;
  if (!shen_is_boolean(ctx, t6519))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t6519)) {
  KLObject* t6520;
  {
    KLObject* a6520[] = {t6511};
    t6520 = shen_apply_direct(ctx, "thaw", 1, a6520);
  }
    t6516 = t6520;
  } else {
  KLObject* t6523;
  {
    KLObject* a6523[] = {t6508};
    t6523 = shen_apply_direct(ctx, "shen.pvar?", 1, a6523);
  }
  KLObject* t6522;
  if (!shen_is_boolean(ctx, t6523))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t6523)) {
  KLObject* t6527 = shen_empty_list(ctx);
  KLObject* t6525;
  {
    KLObject* a6525[] = {t6508, t6527, t6494, t6511};
    t6525 = shen_apply_direct(ctx, "shen.bind!", 4, a6525);
  }
    t6522 = t6525;
  } else {
  KLObject* t6530 = shen_false(ctx);
    t6522 = t6530;
  }
    t6516 = t6522;
  }
    t6504 = t6516;
  } else {
  KLObject* t6531 = shen_false(ctx);
    t6504 = t6531;
  }
    t6498 = t6504;
  } else {
  KLObject* t6532 = shen_false(ctx);
    t6498 = t6532;
  }
  KLObject* t6535 = shen_false(ctx);
  KLObject* t6536 = shen_eq(ctx, t6498, t6535);
  KLObject* t6533;
  if (!shen_is_boolean(ctx, t6536))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t6536)) {
  KLObject* t6538;
  {
    KLObject* a6538[] = {t6495};
    t6538 = shen_apply_direct(ctx, "shen.unlocked?", 1, a6538);
  }
  KLObject* t6537;
  if (!shen_is_boolean(ctx, t6538))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t6538)) {
  KLObject* t6540;
  {
    KLObject* a6540[] = {t6492, t6494};
    t6540 = shen_apply_direct(ctx, "shen.lazyderef", 2, a6540);
  }
  KLObject* t6545 = shen_cons_p(ctx, t6540);
  KLObject* t6543;
  if (!shen_is_boolean(ctx, t6545))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t6545)) {
  KLObject* t6547 = shen_hd(ctx, t6540);
  KLObject* t6549 = shen_tl(ctx, t6540);
  KLObject* t6550;
  {
    KLObject* a6550[] = {t6493, t6494};
    t6550 = shen_apply_direct(ctx, "shen.lazyderef", 2, a6550);
  }
  KLObject* t6553;
  {
    Vector* caps_143 = shen_vector(ctx, 6);
    shen_vector_set(ctx, caps_143, 0, t6547);
    shen_vector_set(ctx, caps_143, 1, t6494);
    shen_vector_set(ctx, caps_143, 2, t6495);
    shen_vector_set(ctx, caps_143, 3, t6496);
    shen_vector_set(ctx, caps_143, 4, t6549);
    shen_vector_set(ctx, caps_143, 5, t6497);
    t6553 = shen_native_closure(ctx, 1, &lambda_143, caps_143);
  }
  KLObject* t6628 = shen_cons_p(ctx, t6550);
  KLObject* t6626;
  if (!shen_is_boolean(ctx, t6628))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t6628)) {
  KLObject* t6631 = shen_hd(ctx, t6550);
  KLObject* t6629;
  {
    KLObject* a6629[] = {t6631, t6494};
    t6629 = shen_apply_direct(ctx, "shen.lazyderef", 2, a6629);
  }
  KLObject* t6633;
  {
    Vector* caps_149 = shen_vector(ctx, 2);
    shen_vector_set(ctx, caps_149, 0, t6550);
    shen_vector_set(ctx, caps_149, 1, t6553);
    t6633 = shen_native_closure(ctx, 1, &lambda_149, caps_149);
  }
  KLObject* t6661 = shen_cons_p(ctx, t6629);
  KLObject* t6659;
  if (!shen_is_boolean(ctx, t6661))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t6661)) {
  KLObject* t6663 = shen_hd(ctx, t6629);
  KLObject* t6666 = shen_tl(ctx, t6629);
  KLObject* t6664;
  {
    KLObject* a6664[] = {t6666, t6494};
    t6664 = shen_apply_direct(ctx, "shen.lazyderef", 2, a6664);
  }
  KLObject* t6668;
  {
    Vector* caps_152 = shen_vector(ctx, 2);
    shen_vector_set(ctx, caps_152, 0, t6633);
    shen_vector_set(ctx, caps_152, 1, t6663);
    t6668 = shen_native_closure(ctx, 1, &lambda_152, caps_152);
  }
  KLObject* t6686 = shen_cons_p(ctx, t6664);
  KLObject* t6684;
  if (!shen_is_boolean(ctx, t6686))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t6686)) {
  KLObject* t6688 = shen_hd(ctx, t6664);
  KLObject* t6691 = shen_tl(ctx, t6664);
  KLObject* t6689;
  {
    KLObject* a6689[] = {t6691, t6494};
    t6689 = shen_apply_direct(ctx, "shen.lazyderef", 2, a6689);
  }
  KLObject* t6693;
  {
    Vector* caps_154 = shen_vector(ctx, 2);
    shen_vector_set(ctx, caps_154, 0, t6668);
    shen_vector_set(ctx, caps_154, 1, t6688);
    t6693 = shen_native_closure(ctx, 1, &lambda_154, caps_154);
  }
  KLObject* t6704 = shen_cons_p(ctx, t6689);
  KLObject* t6702;
  if (!shen_is_boolean(ctx, t6704))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t6704)) {
  KLObject* t6706 = shen_hd(ctx, t6689);
  KLObject* t6709 = shen_tl(ctx, t6689);
  KLObject* t6707;
  {
    KLObject* a6707[] = {t6709, t6494};
    t6707 = shen_apply_direct(ctx, "shen.lazyderef", 2, a6707);
  }
  KLObject* t6711;
  {
    Vector* caps_155 = shen_vector(ctx, 2);
    shen_vector_set(ctx, caps_155, 0, t6693);
    shen_vector_set(ctx, caps_155, 1, t6706);
    t6711 = shen_native_closure(ctx, 0, &lambda_155, caps_155);
  }
  KLObject* t6719 = shen_empty_list(ctx);
  KLObject* t6720 = shen_eq(ctx, t6707, t6719);
  KLObject* t6717;
  if (!shen_is_boolean(ctx, t6720))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t6720)) {
  KLObject* t6721;
  {
    KLObject* a6721[] = {t6711};
    t6721 = shen_tail_apply_direct(ctx, "thaw", 1, a6721);
  }
    t6717 = t6721;
  } else {
  KLObject* t6724;
  {
    KLObject* a6724[] = {t6707};
    t6724 = shen_apply_direct(ctx, "shen.pvar?", 1, a6724);
  }
  KLObject* t6723;
  if (!shen_is_boolean(ctx, t6724))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t6724)) {
  KLObject* t6728 = shen_empty_list(ctx);
  KLObject* t6726;
  {
    KLObject* a6726[] = {t6707, t6728, t6494, t6711};
    t6726 = shen_tail_apply_direct(ctx, "shen.bind!", 4, a6726);
  }
    t6723 = t6726;
  } else {
  KLObject* t6731 = shen_false(ctx);
    t6723 = t6731;
  }
    t6717 = t6723;
  }
    t6702 = t6717;
  } else {
  KLObject* t6733;
  {
    KLObject* a6733[] = {t6689};
    t6733 = shen_apply_direct(ctx, "shen.pvar?", 1, a6733);
  }
  KLObject* t6732;
  if (!shen_is_boolean(ctx, t6733))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t6733)) {
  KLObject* t6735;
  {
    KLObject* a6735[] = {t6494};
    t6735 = shen_apply_direct(ctx, "shen.newpv", 1, a6735);
  }
  KLObject* t6742 = shen_empty_list(ctx);
  KLObject* t6743 = shen_cons(ctx, t6735, t6742);
  KLObject* t6745;
  {
    Vector* caps_156 = shen_vector(ctx, 2);
    shen_vector_set(ctx, caps_156, 0, t6693);
    shen_vector_set(ctx, caps_156, 1, t6735);
    t6745 = shen_native_closure(ctx, 0, &lambda_156, caps_156);
  }
  KLObject* t6739;
  {
    KLObject* a6739[] = {t6689, t6743, t6494, t6745};
    t6739 = shen_apply_direct(ctx, "shen.bind!", 4, a6739);
  }
  KLObject* t6737;
  {
    KLObject* a6737[] = {t6494, t6739};
    t6737 = shen_tail_apply_direct(ctx, "shen.gc", 2, a6737);
  }
    t6732 = t6737;
  } else {
  KLObject* t6751 = shen_false(ctx);
    t6732 = t6751;
  }
    t6702 = t6732;
  }
    t6684 = t6702;
  } else {
  KLObject* t6753;
  {
    KLObject* a6753[] = {t6664};
    t6753 = shen_apply_direct(ctx, "shen.pvar?", 1, a6753);
  }
  KLObject* t6752;
  if (!shen_is_boolean(ctx, t6753))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t6753)) {
  KLObject* t6755;
  {
    KLObject* a6755[] = {t6494};
    t6755 = shen_apply_direct(ctx, "shen.newpv", 1, a6755);
  }
  KLObject* t6759;
  {
    KLObject* a6759[] = {t6494};
    t6759 = shen_apply_direct(ctx, "shen.newpv", 1, a6759);
  }
  KLObject* t6767 = shen_empty_list(ctx);
  KLObject* t6768 = shen_cons(ctx, t6759, t6767);
  KLObject* t6769 = shen_cons(ctx, t6755, t6768);
  KLObject* t6771;
  {
    Vector* caps_157 = shen_vector(ctx, 3);
    shen_vector_set(ctx, caps_157, 0, t6668);
    shen_vector_set(ctx, caps_157, 1, t6755);
    shen_vector_set(ctx, caps_157, 2, t6759);
    t6771 = shen_native_closure(ctx, 0, &lambda_157, caps_157);
  }
  KLObject* t6763;
  {
    KLObject* a6763[] = {t6664, t6769, t6494, t6771};
    t6763 = shen_apply_direct(ctx, "shen.bind!", 4, a6763);
  }
  KLObject* t6761;
  {
    KLObject* a6761[] = {t6494, t6763};
    t6761 = shen_apply_direct(ctx, "shen.gc", 2, a6761);
  }
  KLObject* t6757;
  {
    KLObject* a6757[] = {t6494, t6761};
    t6757 = shen_tail_apply_direct(ctx, "shen.gc", 2, a6757);
  }
    t6752 = t6757;
  } else {
  KLObject* t6780 = shen_false(ctx);
    t6752 = t6780;
  }
    t6684 = t6752;
  }
    t6659 = t6684;
  } else {
  KLObject* t6782;
  {
    KLObject* a6782[] = {t6629};
    t6782 = shen_apply_direct(ctx, "shen.pvar?", 1, a6782);
  }
  KLObject* t6781;
  if (!shen_is_boolean(ctx, t6782))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t6782)) {
  KLObject* t6784;
  {
    KLObject* a6784[] = {t6494};
    t6784 = shen_apply_direct(ctx, "shen.newpv", 1, a6784);
  }
  KLObject* t6788;
  {
    KLObject* a6788[] = {t6494};
    t6788 = shen_apply_direct(ctx, "shen.newpv", 1, a6788);
  }
  KLObject* t6792;
  {
    KLObject* a6792[] = {t6494};
    t6792 = shen_apply_direct(ctx, "shen.newpv", 1, a6792);
  }
  KLObject* t6801 = shen_empty_list(ctx);
  KLObject* t6802 = shen_cons(ctx, t6792, t6801);
  KLObject* t6803 = shen_cons(ctx, t6788, t6802);
  KLObject* t6804 = shen_cons(ctx, t6784, t6803);
  KLObject* t6806;
  {
    Vector* caps_158 = shen_vector(ctx, 4);
    shen_vector_set(ctx, caps_158, 0, t6633);
    shen_vector_set(ctx, caps_158, 1, t6784);
    shen_vector_set(ctx, caps_158, 2, t6788);
    shen_vector_set(ctx, caps_158, 3, t6792);
    t6806 = shen_native_closure(ctx, 0, &lambda_158, caps_158);
  }
  KLObject* t6796;
  {
    KLObject* a6796[] = {t6629, t6804, t6494, t6806};
    t6796 = shen_apply_direct(ctx, "shen.bind!", 4, a6796);
  }
  KLObject* t6794;
  {
    KLObject* a6794[] = {t6494, t6796};
    t6794 = shen_apply_direct(ctx, "shen.gc", 2, a6794);
  }
  KLObject* t6790;
  {
    KLObject* a6790[] = {t6494, t6794};
    t6790 = shen_apply_direct(ctx, "shen.gc", 2, a6790);
  }
  KLObject* t6786;
  {
    KLObject* a6786[] = {t6494, t6790};
    t6786 = shen_tail_apply_direct(ctx, "shen.gc", 2, a6786);
  }
    t6781 = t6786;
  } else {
  KLObject* t6818 = shen_false(ctx);
    t6781 = t6818;
  }
    t6659 = t6781;
  }
    t6626 = t6659;
  } else {
  KLObject* t6820;
  {
    KLObject* a6820[] = {t6550};
    t6820 = shen_apply_direct(ctx, "shen.pvar?", 1, a6820);
  }
  KLObject* t6819;
  if (!shen_is_boolean(ctx, t6820))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t6820)) {
  KLObject* t6822;
  {
    KLObject* a6822[] = {t6494};
    t6822 = shen_apply_direct(ctx, "shen.newpv", 1, a6822);
  }
  KLObject* t6826;
  {
    KLObject* a6826[] = {t6494};
    t6826 = shen_apply_direct(ctx, "shen.newpv", 1, a6826);
  }
  KLObject* t6830;
  {
    KLObject* a6830[] = {t6494};
    t6830 = shen_apply_direct(ctx, "shen.newpv", 1, a6830);
  }
  KLObject* t6834;
  {
    KLObject* a6834[] = {t6494};
    t6834 = shen_apply_direct(ctx, "shen.newpv", 1, a6834);
  }
  KLObject* t6843 = shen_empty_list(ctx);
  KLObject* t6844 = shen_cons(ctx, t6830, t6843);
  KLObject* t6845 = shen_cons(ctx, t6826, t6844);
  KLObject* t6846 = shen_cons(ctx, t6822, t6845);
  KLObject* t6848 = shen_cons(ctx, t6846, t6834);
  KLObject* t6850;
  {
    Vector* caps_159 = shen_vector(ctx, 5);
    shen_vector_set(ctx, caps_159, 0, t6553);
    shen_vector_set(ctx, caps_159, 1, t6822);
    shen_vector_set(ctx, caps_159, 2, t6826);
    shen_vector_set(ctx, caps_159, 3, t6830);
    shen_vector_set(ctx, caps_159, 4, t6834);
    t6850 = shen_native_closure(ctx, 0, &lambda_159, caps_159);
  }
  KLObject* t6838;
  {
    KLObject* a6838[] = {t6550, t6848, t6494, t6850};
    t6838 = shen_apply_direct(ctx, "shen.bind!", 4, a6838);
  }
  KLObject* t6836;
  {
    KLObject* a6836[] = {t6494, t6838};
    t6836 = shen_apply_direct(ctx, "shen.gc", 2, a6836);
  }
  KLObject* t6832;
  {
    KLObject* a6832[] = {t6494, t6836};
    t6832 = shen_apply_direct(ctx, "shen.gc", 2, a6832);
  }
  KLObject* t6828;
  {
    KLObject* a6828[] = {t6494, t6832};
    t6828 = shen_apply_direct(ctx, "shen.gc", 2, a6828);
  }
  KLObject* t6824;
  {
    KLObject* a6824[] = {t6494, t6828};
    t6824 = shen_tail_apply_direct(ctx, "shen.gc", 2, a6824);
  }
    t6819 = t6824;
  } else {
  KLObject* t6865 = shen_false(ctx);
    t6819 = t6865;
  }
    t6626 = t6819;
  }
    t6543 = t6626;
  } else {
  KLObject* t6866 = shen_false(ctx);
    t6543 = t6866;
  }
    t6537 = t6543;
  } else {
  KLObject* t6867 = shen_false(ctx);
    t6537 = t6867;
  }
    t6533 = t6537;
  } else {
    t6533 = t6498;
  }
    return t6533;
  }
}

static KLObject* native_kl_shen_2et_2a_2dcorrect_46 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t6869 = objects[0];
    KLObject* t6870 = objects[1];
    KLObject* t6871 = objects[2];
    KLObject* t6872 = objects[3];
    KLObject* t6873 = objects[4];
    KLObject* t6874 = objects[5];
    KLObject* t6875 = objects[6];
  tail_start_kl_shen_2et_2a_2dcorrect_46: ;
  KLObject* t6877 = shen_number_l(ctx, 1);
  KLObject* t6878 = shen_add(ctx, t6874, t6877);
  KLObject* t6880;
  {
    KLObject* a6880[] = {t6873};
    t6880 = shen_apply_direct(ctx, "shen.unlocked?", 1, a6880);
  }
  KLObject* t6879;
  if (!shen_is_boolean(ctx, t6880))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t6880)) {
  KLObject* t6882;
  {
    KLObject* a6882[] = {t6869, t6872};
    t6882 = shen_apply_direct(ctx, "shen.lazyderef", 2, a6882);
  }
  KLObject* t6887 = shen_cons_p(ctx, t6882);
  KLObject* t6885;
  if (!shen_is_boolean(ctx, t6887))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t6887)) {
  KLObject* t6890 = shen_hd(ctx, t6882);
  KLObject* t6888;
  {
    KLObject* a6888[] = {t6890, t6872};
    t6888 = shen_apply_direct(ctx, "shen.lazyderef", 2, a6888);
  }
  KLObject* t6894 = shen_intern(ctx, "where");
  KLObject* t6895 = shen_eq(ctx, t6888, t6894);
  KLObject* t6892;
  if (!shen_is_boolean(ctx, t6895))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t6895)) {
  KLObject* t6898 = shen_tl(ctx, t6882);
  KLObject* t6896;
  {
    KLObject* a6896[] = {t6898, t6872};
    t6896 = shen_apply_direct(ctx, "shen.lazyderef", 2, a6896);
  }
  KLObject* t6902 = shen_cons_p(ctx, t6896);
  KLObject* t6900;
  if (!shen_is_boolean(ctx, t6902))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t6902)) {
  KLObject* t6904 = shen_hd(ctx, t6896);
  KLObject* t6907 = shen_tl(ctx, t6896);
  KLObject* t6905;
  {
    KLObject* a6905[] = {t6907, t6872};
    t6905 = shen_apply_direct(ctx, "shen.lazyderef", 2, a6905);
  }
  KLObject* t6911 = shen_cons_p(ctx, t6905);
  KLObject* t6909;
  if (!shen_is_boolean(ctx, t6911))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t6911)) {
  KLObject* t6913 = shen_hd(ctx, t6905);
  KLObject* t6916 = shen_tl(ctx, t6905);
  KLObject* t6914;
  {
    KLObject* a6914[] = {t6916, t6872};
    t6914 = shen_apply_direct(ctx, "shen.lazyderef", 2, a6914);
  }
  KLObject* t6920 = shen_empty_list(ctx);
  KLObject* t6921 = shen_eq(ctx, t6914, t6920);
  KLObject* t6918;
  if (!shen_is_boolean(ctx, t6921))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t6921)) {
  KLObject* t6922;
  {
    KLObject* a6922[] = {t6872};
    t6922 = shen_apply_direct(ctx, "shen.newpv", 1, a6922);
  }
  KLObject* t6926 = shen_apply_direct(ctx, "shen.incinfs", 0, NULL);
  KLObject* t6931;
  {
    Vector* caps_160 = shen_vector(ctx, 9);
    shen_vector_set(ctx, caps_160, 0, t6922);
    shen_vector_set(ctx, caps_160, 1, t6904);
    shen_vector_set(ctx, caps_160, 2, t6872);
    shen_vector_set(ctx, caps_160, 3, t6873);
    shen_vector_set(ctx, caps_160, 4, t6878);
    shen_vector_set(ctx, caps_160, 5, t6871);
    shen_vector_set(ctx, caps_160, 6, t6913);
    shen_vector_set(ctx, caps_160, 7, t6870);
    shen_vector_set(ctx, caps_160, 8, t6875);
    t6931 = shen_native_closure(ctx, 0, &lambda_160, caps_160);
  }
  KLObject* t6927;
  {
    KLObject* a6927[] = {t6872, t6873, t6878, t6931};
    t6927 = shen_apply_direct(ctx, "shen.cut", 4, a6927);
  }
  KLObject* t6924;
  {
    KLObject* a6924[] = {t6872, t6927};
    t6924 = shen_apply_direct(ctx, "shen.gc", 2, a6924);
  }
    t6918 = t6924;
  } else {
  KLObject* t7003 = shen_false(ctx);
    t6918 = t7003;
  }
    t6909 = t6918;
  } else {
  KLObject* t7004 = shen_false(ctx);
    t6909 = t7004;
  }
    t6900 = t6909;
  } else {
  KLObject* t7005 = shen_false(ctx);
    t6900 = t7005;
  }
    t6892 = t6900;
  } else {
  KLObject* t7006 = shen_false(ctx);
    t6892 = t7006;
  }
    t6885 = t6892;
  } else {
  KLObject* t7007 = shen_false(ctx);
    t6885 = t7007;
  }
    t6879 = t6885;
  } else {
  KLObject* t7008 = shen_false(ctx);
    t6879 = t7008;
  }
  KLObject* t7011 = shen_false(ctx);
  KLObject* t7012 = shen_eq(ctx, t6879, t7011);
  KLObject* t7009;
  if (!shen_is_boolean(ctx, t7012))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t7012)) {
  KLObject* t7014;
  {
    KLObject* a7014[] = {t6873};
    t7014 = shen_apply_direct(ctx, "shen.unlocked?", 1, a7014);
  }
  KLObject* t7013;
  if (!shen_is_boolean(ctx, t7014))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t7014)) {
  KLObject* t7016 = shen_apply_direct(ctx, "shen.incinfs", 0, NULL);
  KLObject* t7018;
  {
    KLObject* a7018[] = {t6869};
    t7018 = shen_apply_direct(ctx, "shen.curry", 1, a7018);
  }
  KLObject* t7017;
  {
    KLObject* a7017[] = {t7018, t6870, t6871, t6872, t6873, t6878, t6875};
    t7017 = shen_apply_direct(ctx, "shen.system-S-h", 7, a7017);
  }
    t7013 = t7017;
  } else {
  KLObject* t7026 = shen_false(ctx);
    t7013 = t7026;
  }
  KLObject* t7029 = shen_false(ctx);
  KLObject* t7030 = shen_eq(ctx, t7013, t7029);
  KLObject* t7027;
  if (!shen_is_boolean(ctx, t7030))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t7030)) {
  KLObject* t7031;
  {
    KLObject* a7031[] = {t6873, t6878};
    t7031 = shen_tail_apply_direct(ctx, "shen.unlock", 2, a7031);
  }
    t7027 = t7031;
  } else {
    t7027 = t7013;
  }
    t7009 = t7027;
  } else {
    t7009 = t6879;
  }
    return t7009;
  }
}

static KLObject* native_kl_shen_2et_2a_2dintegrity_47 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t7036 = objects[0];
    KLObject* t7037 = objects[1];
    KLObject* t7038 = objects[2];
    KLObject* t7039 = objects[3];
    KLObject* t7040 = objects[4];
    KLObject* t7041 = objects[5];
    KLObject* t7042 = objects[6];
    KLObject* t7043 = objects[7];
  tail_start_kl_shen_2et_2a_2dintegrity_47: ;
  KLObject* t7045;
  {
    KLObject* a7045[] = {t7041};
    t7045 = shen_apply_direct(ctx, "shen.unlocked?", 1, a7045);
  }
  KLObject* t7044;
  if (!shen_is_boolean(ctx, t7045))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t7045)) {
  KLObject* t7047;
  {
    KLObject* a7047[] = {t7036, t7040};
    t7047 = shen_apply_direct(ctx, "shen.lazyderef", 2, a7047);
  }
  KLObject* t7052 = shen_empty_list(ctx);
  KLObject* t7053 = shen_eq(ctx, t7047, t7052);
  KLObject* t7050;
  if (!shen_is_boolean(ctx, t7053))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t7053)) {
  KLObject* t7054 = shen_apply_direct(ctx, "shen.incinfs", 0, NULL);
  KLObject* t7055;
  {
    KLObject* a7055[] = {t7037, t7039, t7040, t7041, t7042, t7043};
    t7055 = shen_apply_direct(ctx, "is!", 6, a7055);
  }
    t7050 = t7055;
  } else {
  KLObject* t7062 = shen_false(ctx);
    t7050 = t7062;
  }
    t7044 = t7050;
  } else {
  KLObject* t7063 = shen_false(ctx);
    t7044 = t7063;
  }
  KLObject* t7066 = shen_false(ctx);
  KLObject* t7067 = shen_eq(ctx, t7044, t7066);
  KLObject* t7064;
  if (!shen_is_boolean(ctx, t7067))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t7067)) {
  KLObject* t7069;
  {
    KLObject* a7069[] = {t7041};
    t7069 = shen_apply_direct(ctx, "shen.unlocked?", 1, a7069);
  }
  KLObject* t7068;
  if (!shen_is_boolean(ctx, t7069))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t7069)) {
  KLObject* t7071;
  {
    KLObject* a7071[] = {t7036, t7040};
    t7071 = shen_apply_direct(ctx, "shen.lazyderef", 2, a7071);
  }
  KLObject* t7076 = shen_cons_p(ctx, t7071);
  KLObject* t7074;
  if (!shen_is_boolean(ctx, t7076))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t7076)) {
  KLObject* t7078 = shen_hd(ctx, t7071);
  KLObject* t7080 = shen_tl(ctx, t7071);
  KLObject* t7081;
  {
    KLObject* a7081[] = {t7037, t7040};
    t7081 = shen_apply_direct(ctx, "shen.lazyderef", 2, a7081);
  }
  KLObject* t7086 = shen_cons_p(ctx, t7081);
  KLObject* t7084;
  if (!shen_is_boolean(ctx, t7086))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t7086)) {
  KLObject* t7088 = shen_hd(ctx, t7081);
  KLObject* t7091 = shen_tl(ctx, t7081);
  KLObject* t7089;
  {
    KLObject* a7089[] = {t7091, t7040};
    t7089 = shen_apply_direct(ctx, "shen.lazyderef", 2, a7089);
  }
  KLObject* t7095 = shen_cons_p(ctx, t7089);
  KLObject* t7093;
  if (!shen_is_boolean(ctx, t7095))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t7095)) {
  KLObject* t7098 = shen_hd(ctx, t7089);
  KLObject* t7096;
  {
    KLObject* a7096[] = {t7098, t7040};
    t7096 = shen_apply_direct(ctx, "shen.lazyderef", 2, a7096);
  }
  KLObject* t7102 = shen_intern(ctx, "-->");
  KLObject* t7103 = shen_eq(ctx, t7096, t7102);
  KLObject* t7100;
  if (!shen_is_boolean(ctx, t7103))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t7103)) {
  KLObject* t7106 = shen_tl(ctx, t7089);
  KLObject* t7104;
  {
    KLObject* a7104[] = {t7106, t7040};
    t7104 = shen_apply_direct(ctx, "shen.lazyderef", 2, a7104);
  }
  KLObject* t7110 = shen_cons_p(ctx, t7104);
  KLObject* t7108;
  if (!shen_is_boolean(ctx, t7110))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t7110)) {
  KLObject* t7112 = shen_hd(ctx, t7104);
  KLObject* t7115 = shen_tl(ctx, t7104);
  KLObject* t7113;
  {
    KLObject* a7113[] = {t7115, t7040};
    t7113 = shen_apply_direct(ctx, "shen.lazyderef", 2, a7113);
  }
  KLObject* t7119 = shen_empty_list(ctx);
  KLObject* t7120 = shen_eq(ctx, t7113, t7119);
  KLObject* t7117;
  if (!shen_is_boolean(ctx, t7120))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t7120)) {
  KLObject* t7121 = shen_apply_direct(ctx, "shen.incinfs", 0, NULL);
  KLObject* t7129;
  {
    Vector* caps_164 = shen_vector(ctx, 8);
    shen_vector_set(ctx, caps_164, 0, t7080);
    shen_vector_set(ctx, caps_164, 1, t7112);
    shen_vector_set(ctx, caps_164, 2, t7038);
    shen_vector_set(ctx, caps_164, 3, t7039);
    shen_vector_set(ctx, caps_164, 4, t7040);
    shen_vector_set(ctx, caps_164, 5, t7041);
    shen_vector_set(ctx, caps_164, 6, t7042);
    shen_vector_set(ctx, caps_164, 7, t7043);
    t7129 = shen_native_closure(ctx, 0, &lambda_164, caps_164);
  }
  KLObject* t7122;
  {
    KLObject* a7122[] = {t7078, t7088, t7038, t7040, t7041, t7042, t7129};
    t7122 = shen_tail_apply_direct(ctx, "shen.system-S-h", 7, a7122);
  }
    t7117 = t7122;
  } else {
  KLObject* t7147 = shen_false(ctx);
    t7117 = t7147;
  }
    t7108 = t7117;
  } else {
  KLObject* t7148 = shen_false(ctx);
    t7108 = t7148;
  }
    t7100 = t7108;
  } else {
  KLObject* t7149 = shen_false(ctx);
    t7100 = t7149;
  }
    t7093 = t7100;
  } else {
  KLObject* t7150 = shen_false(ctx);
    t7093 = t7150;
  }
    t7084 = t7093;
  } else {
  KLObject* t7151 = shen_false(ctx);
    t7084 = t7151;
  }
    t7074 = t7084;
  } else {
  KLObject* t7152 = shen_false(ctx);
    t7074 = t7152;
  }
    t7068 = t7074;
  } else {
  KLObject* t7153 = shen_false(ctx);
    t7068 = t7153;
  }
    t7064 = t7068;
  } else {
    t7064 = t7044;
  }
    return t7064;
  }
}

static KLObject* native_kl_shen_2efreshterm_3f_48 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t7155 = objects[0];
  tail_start_kl_shen_2efreshterm_3f_48: ;
  KLObject* t7158 = shen_absvector_p(ctx, t7155);
  KLObject* t7156;
  if (!shen_is_boolean(ctx, t7158))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t7158)) {
    t7156 = t7158;
  } else {
  KLObject* t7162 = shen_string_p(ctx, t7155);
  KLObject* t7160;
  {
    KLObject* a7160[] = {t7162};
    t7160 = shen_apply_direct(ctx, "not", 1, a7160);
  }
  KLObject* t7159;
  if (!shen_is_boolean(ctx, t7160))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t7160)) {
    t7159 = t7160;
  } else {
  KLObject* t7165 = shen_number_l(ctx, 0);
  KLObject* t7163;
  {
    KLObject* a7163[] = {t7155, t7165};
    t7163 = shen_apply_direct(ctx, "<-address", 2, a7163);
  }
  KLObject* t7166 = shen_intern(ctx, "shen.print-freshterm");
  KLObject* t7167 = shen_eq(ctx, t7163, t7166);
    if (!shen_is_boolean(ctx, t7167))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t7159 = t7167;
  }
    if (!shen_is_boolean(ctx, t7159))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t7156 = t7159;
  }
    return t7156;
  }
}

void shen_kernel_aot_install_t_star (shen_context* ctx)
{
  shen_register_defun(ctx, "shen.typecheck", 2, &native_kl_shen_2etypecheck_0);
  shen_register_defun(ctx, "shen.insert-prolog-variables", 7, &native_kl_shen_2einsert_2dprolog_2dvariables_1);
  shen_register_defun(ctx, "shen.toplevel-forms", 6, &native_kl_shen_2etoplevel_2dforms_2);
  shen_register_defun(ctx, "shen.signal-def", 6, &native_kl_shen_2esignal_2ddef_3);
  shen_register_defun(ctx, "shen.rectify-type", 1, &native_kl_shen_2erectify_2dtype_4);
  shen_register_defun(ctx, "shen.demodulate", 1, &native_kl_shen_2edemodulate_5);
  shen_register_defun(ctx, "shen.curry-type", 1, &native_kl_shen_2ecurry_2dtype_6);
  shen_register_defun(ctx, "shen.curry", 1, &native_kl_shen_2ecurry_7);
  shen_register_defun(ctx, "shen.special?", 1, &native_kl_shen_2especial_3f_8);
  shen_register_defun(ctx, "shen.extraspecial?", 1, &native_kl_shen_2eextraspecial_3f_9);
  shen_register_defun(ctx, "shen.system-S", 6, &native_kl_shen_2esystem_2dS_10);
  shen_register_defun(ctx, "shen.show", 6, &native_kl_shen_2eshow_11);
  shen_register_defun(ctx, "shen.line", 0, &native_kl_shen_2eline_12);
  shen_register_defun(ctx, "shen.show-p", 1, &native_kl_shen_2eshow_2dp_13);
  shen_register_defun(ctx, "shen.prterm", 1, &native_kl_shen_2eprterm_14);
  shen_register_defun(ctx, "shen.prtl", 1, &native_kl_shen_2eprtl_15);
  shen_register_defun(ctx, "shen.show-assumptions", 2, &native_kl_shen_2eshow_2dassumptions_16);
  shen_register_defun(ctx, "shen.pause-for-user", 0, &native_kl_shen_2epause_2dfor_2duser_17);
  shen_register_defun(ctx, "shen.type-theory-enabled?", 0, &native_kl_shen_2etype_2dtheory_2denabled_3f_18);
  shen_register_defun(ctx, "shen.maxinfexceeded?", 0, &native_kl_shen_2emaxinfexceeded_3f_19);
  shen_register_defun(ctx, "shen.system-S-h", 7, &native_kl_shen_2esystem_2dS_2dh_20);
  shen_register_defun(ctx, "shen.rdecons", 1, &native_kl_shen_2erdecons_21);
  shen_register_defun(ctx, "shen.primitive", 6, &native_kl_shen_2eprimitive_22);
  shen_register_defun(ctx, "shen.by-hypothesis", 7, &native_kl_shen_2eby_2dhypothesis_23);
  shen_register_defun(ctx, "shen.lookupsig", 6, &native_kl_shen_2elookupsig_24);
  shen_register_defun(ctx, "shen.sigf", 6, &native_kl_shen_2esigf_25);
  shen_register_defun(ctx, "shen.freshterm", 1, &native_kl_shen_2efreshterm_26);
  shen_register_defun(ctx, "shen.print-freshterm", 1, &native_kl_shen_2eprint_2dfreshterm_27);
  shen_register_defun(ctx, "shen.search-user-datatypes", 7, &native_kl_shen_2esearch_2duser_2ddatatypes_28);
  shen_register_defun(ctx, "shen.l-rules", 7, &native_kl_shen_2el_2drules_29);
  shen_register_defun(ctx, "shen.t*", 6, &native_kl_shen_2et_2a_30);
  shen_register_defun(ctx, "shen.sigxrules", 1, &native_kl_shen_2esigxrules_31);
  shen_register_defun(ctx, "shen.<sig*rules>", 1, &native_kl_shen_2e_3csig_2arules_3e_32);
  shen_register_defun(ctx, "shen.freshen-sig", 1, &native_kl_shen_2efreshen_2dsig_33);
  shen_register_defun(ctx, "shen.freshen-type", 2, &native_kl_shen_2efreshen_2dtype_34);
  shen_register_defun(ctx, "shen.<rules*>", 1, &native_kl_shen_2e_3crules_2a_3e_35);
  shen_register_defun(ctx, "shen.<rule*>", 1, &native_kl_shen_2e_3crule_2a_3e_36);
  shen_register_defun(ctx, "shen.correct", 1, &native_kl_shen_2ecorrect_37);
  shen_register_defun(ctx, "shen.t*-rules", 8, &native_kl_shen_2et_2a_2drules_38);
  shen_register_defun(ctx, "shen.freshen-rule", 1, &native_kl_shen_2efreshen_2drule_39);
  shen_register_defun(ctx, "shen.freshen", 2, &native_kl_shen_2efreshen_40);
  shen_register_defun(ctx, "shen.t*-rule", 9, &native_kl_shen_2et_2a_2drule_41);
  shen_register_defun(ctx, "shen.t*-rule-h", 7, &native_kl_shen_2et_2a_2drule_2dh_42);
  shen_register_defun(ctx, "shen.myassume", 7, &native_kl_shen_2emyassume_43);
  shen_register_defun(ctx, "shen.freshterms", 1, &native_kl_shen_2efreshterms_44);
  shen_register_defun(ctx, "shen.p-hyps", 6, &native_kl_shen_2ep_2dhyps_45);
  shen_register_defun(ctx, "shen.t*-correct", 7, &native_kl_shen_2et_2a_2dcorrect_46);
  shen_register_defun(ctx, "shen.t*-integrity", 8, &native_kl_shen_2et_2a_2dintegrity_47);
  shen_register_defun(ctx, "shen.freshterm?", 1, &native_kl_shen_2efreshterm_3f_48);
}
