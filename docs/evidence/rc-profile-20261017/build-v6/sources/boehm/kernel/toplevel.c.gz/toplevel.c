#include "rc_phase_profile.h"
/* Generated always-AOT kernel module (KL defuns -> NativeFunctions).
 * Install after tree-walker boot overwrites UserFunctions.
 * Toplevel declare/set stay on the walker. Not overlay-after-load.
 * Sidecar tests stay on the tree-walker. Not a second main. Source: toplevel.kl
 */
#include "abi.h"

void shen_kernel_aot_install_toplevel (shen_context* ctx);

static KLObject* init_step_kl_shen_2eshen_0_0 (void)
{
  shen_context* ctx = &shen_root_context;
  KLObject* t0 = shen_apply_direct(ctx, "shen.credits", 0, NULL);
  return t0;
}

static KLObject* init_step_kl_shen_2eshen_0_1 (void)
{
  shen_context* ctx = &shen_root_context;
  KLObject* t1 = shen_apply_direct(ctx, "shen.loop", 0, NULL);
  return t1;
}

static KLObject* init_step_kl_shen_2eloop_1_0 (void)
{
  shen_context* ctx = &shen_root_context;
  KLObject* t3 = shen_apply_direct(ctx, "shen.initialise_environment", 0, NULL);
  return t3;
}

static KLObject* init_step_kl_shen_2eloop_1_1 (void)
{
  shen_context* ctx = &shen_root_context;
  KLObject* t4 = shen_apply_direct(ctx, "shen.prompt", 0, NULL);
  return t4;
}

static KLObject* trap_body_0 (void* data)
{
  shen_context* ctx = &shen_root_context;
  Vector* env = (Vector*)data;
  KLObject* t6 = shen_apply_direct(ctx, "shen.read-evaluate-print", 0, NULL);
  return t6;
}

static KLObject* lambda_0 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t8 = objects[0];
  KLObject* t10;
  {
    KLObject* a10[] = {t8};
    t10 = shen_apply_direct(ctx, "error-to-string", 1, a10);
  }
  KLObject* t12 = shen_apply_direct(ctx, "stoutput", 0, NULL);
  KLObject* t9;
  {
    KLObject* a9[] = {t10, t12};
    t9 = shen_apply_direct(ctx, "pr", 2, a9);
  }
  KLObject* t14 = shen_number_l(ctx, 0);
  KLObject* t13;
  {
    KLObject* a13[] = {t14};
    t13 = shen_tail_apply_direct(ctx, "nl", 1, a13);
  }
    return t13;
  }
}

static KLObject* trap_handler_0 (KLObject* exception, void* data)
{
  shen_context* ctx = &shen_root_context;
  Vector* env = (Vector*)data;
  Vector* args;
  KLObject* t7;
  {
    Vector* caps_0 = shen_vector(ctx, 0);
    t7 = shen_native_closure(ctx, 1, &lambda_0, caps_0);
  }
  args = shen_vector(ctx, 1);
  shen_vector_set(ctx, args, 0, exception);
  {
    KLObject* t15 = shen_apply(ctx, t7, args);
    return t15;
  }
}

static KLObject* init_step_kl_shen_2eloop_1_2 (void)
{
  shen_context* ctx = &shen_root_context;
  KLObject* t5;
  {
    Vector* tenv_0 = shen_vector(ctx, 0);
    t5 = shen_trap_error(ctx, trap_body_0, trap_handler_0, tenv_0);
  }
  return t5;
}

static KLObject* init_step_kl_shen_2eloop_1_3 (void)
{
  shen_context* ctx = &shen_root_context;
  KLObject* t16 = shen_apply_direct(ctx, "shen.loop", 0, NULL);
  return t16;
}

static KLObject* init_step_kl_shen_2ecredits_2_0 (void)
{
  shen_context* ctx = &shen_root_context;
  KLObject* t19 = shen_string(ctx, "\nShen, www.shenlanguage.org, copyright (C) 2010-2026, Mark Tarver\n");
  KLObject* t20 = shen_apply_direct(ctx, "stoutput", 0, NULL);
  KLObject* t18;
  {
    KLObject* a18[] = {t19, t20};
    t18 = shen_apply_direct(ctx, "pr", 2, a18);
  }
  return t18;
}

static KLObject* init_step_kl_shen_2ecredits_2_1 (void)
{
  shen_context* ctx = &shen_root_context;
  KLObject* t23 = shen_string(ctx, "version: S");
  KLObject* t26 = shen_intern(ctx, "*version*");
  KLObject* t25;
  {
    KLObject* a25[] = {t26};
    t25 = shen_apply_direct(ctx, "value", 1, a25);
  }
  KLObject* t28 = shen_string(ctx, ", language: ");
  KLObject* t31 = shen_intern(ctx, "*language*");
  KLObject* t30;
  {
    KLObject* a30[] = {t31};
    t30 = shen_apply_direct(ctx, "value", 1, a30);
  }
  KLObject* t33 = shen_string(ctx, ", platform: ");
  KLObject* t36 = shen_intern(ctx, "*implementation*");
  KLObject* t35;
  {
    KLObject* a35[] = {t36};
    t35 = shen_apply_direct(ctx, "value", 1, a35);
  }
  KLObject* t38 = shen_string(ctx, " ");
  KLObject* t41 = shen_intern(ctx, "*release*");
  KLObject* t40;
  {
    KLObject* a40[] = {t41};
    t40 = shen_apply_direct(ctx, "value", 1, a40);
  }
  KLObject* t42 = shen_string(ctx, "\n");
  KLObject* t43 = shen_intern(ctx, "shen.a");
  KLObject* t39;
  {
    KLObject* a39[] = {t40, t42, t43};
    t39 = shen_apply_direct(ctx, "shen.app", 3, a39);
  }
  KLObject* t37;
  {
    KLObject* a37[] = {t38, t39};
    t37 = shen_apply_direct(ctx, "cn", 2, a37);
  }
  KLObject* t44 = shen_intern(ctx, "shen.a");
  KLObject* t34;
  {
    KLObject* a34[] = {t35, t37, t44};
    t34 = shen_apply_direct(ctx, "shen.app", 3, a34);
  }
  KLObject* t32;
  {
    KLObject* a32[] = {t33, t34};
    t32 = shen_apply_direct(ctx, "cn", 2, a32);
  }
  KLObject* t45 = shen_intern(ctx, "shen.a");
  KLObject* t29;
  {
    KLObject* a29[] = {t30, t32, t45};
    t29 = shen_apply_direct(ctx, "shen.app", 3, a29);
  }
  KLObject* t27;
  {
    KLObject* a27[] = {t28, t29};
    t27 = shen_apply_direct(ctx, "cn", 2, a27);
  }
  KLObject* t46 = shen_intern(ctx, "shen.a");
  KLObject* t24;
  {
    KLObject* a24[] = {t25, t27, t46};
    t24 = shen_apply_direct(ctx, "shen.app", 3, a24);
  }
  KLObject* t22;
  {
    KLObject* a22[] = {t23, t24};
    t22 = shen_apply_direct(ctx, "cn", 2, a22);
  }
  KLObject* t47 = shen_apply_direct(ctx, "stoutput", 0, NULL);
  KLObject* t21;
  {
    KLObject* a21[] = {t22, t47};
    t21 = shen_apply_direct(ctx, "pr", 2, a21);
  }
  return t21;
}

static KLObject* init_step_kl_shen_2ecredits_2_2 (void)
{
  shen_context* ctx = &shen_root_context;
  KLObject* t50 = shen_string(ctx, "port ");
  KLObject* t53 = shen_intern(ctx, "*port*");
  KLObject* t52;
  {
    KLObject* a52[] = {t53};
    t52 = shen_apply_direct(ctx, "value", 1, a52);
  }
  KLObject* t55 = shen_string(ctx, ", ported by ");
  KLObject* t58 = shen_intern(ctx, "*porters*");
  KLObject* t57;
  {
    KLObject* a57[] = {t58};
    t57 = shen_apply_direct(ctx, "value", 1, a57);
  }
  KLObject* t59 = shen_string(ctx, "\n\n");
  KLObject* t60 = shen_intern(ctx, "shen.a");
  KLObject* t56;
  {
    KLObject* a56[] = {t57, t59, t60};
    t56 = shen_apply_direct(ctx, "shen.app", 3, a56);
  }
  KLObject* t54;
  {
    KLObject* a54[] = {t55, t56};
    t54 = shen_apply_direct(ctx, "cn", 2, a54);
  }
  KLObject* t61 = shen_intern(ctx, "shen.a");
  KLObject* t51;
  {
    KLObject* a51[] = {t52, t54, t61};
    t51 = shen_apply_direct(ctx, "shen.app", 3, a51);
  }
  KLObject* t49;
  {
    KLObject* a49[] = {t50, t51};
    t49 = shen_apply_direct(ctx, "cn", 2, a49);
  }
  KLObject* t62 = shen_apply_direct(ctx, "stoutput", 0, NULL);
  KLObject* t48;
  {
    KLObject* a48[] = {t49, t62};
    t48 = shen_apply_direct(ctx, "pr", 2, a48);
  }
  return t48;
}

static KLObject* init_step_kl_shen_2einitialise_5fenvironment_3_0 (void)
{
  shen_context* ctx = &shen_root_context;
  KLObject* t65 = shen_intern(ctx, "shen.*call*");
  KLObject* t66 = shen_number_l(ctx, 0);
  KLObject* t64;
  {
    KLObject* a64[] = {t65, t66};
    t64 = shen_apply_direct(ctx, "set", 2, a64);
  }
  return t64;
}

static KLObject* init_step_kl_shen_2einitialise_5fenvironment_3_1 (void)
{
  shen_context* ctx = &shen_root_context;
  KLObject* t68 = shen_intern(ctx, "shen.*infs*");
  KLObject* t69 = shen_number_l(ctx, 0);
  KLObject* t67;
  {
    KLObject* a67[] = {t68, t69};
    t67 = shen_apply_direct(ctx, "set", 2, a67);
  }
  return t67;
}

static KLObject* lambda_1 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  KLObject* t120 = shen_vector_get(ctx, caps, 0);
  KLObject* t121 = shen_vector_get(ctx, caps, 1);
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t122 = objects[0];
  KLObject* t123;
  {
    KLObject* a123[] = {t120, t121, t122};
    t123 = shen_tail_apply_direct(ctx, "shen.pui-h", 3, a123);
  }
    return t123;
  }
}

static KLObject* lambda_2 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  KLObject* t180 = shen_vector_get(ctx, caps, 0);
  KLObject* t181 = shen_vector_get(ctx, caps, 1);
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t182 = objects[0];
  KLObject* t183;
  {
    KLObject* a183[] = {t180, t181, t182};
    t183 = shen_tail_apply_direct(ctx, "shen.pui-h", 3, a183);
  }
    return t183;
  }
}

static KLObject* lambda_3 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  KLObject* t196 = shen_vector_get(ctx, caps, 0);
  KLObject* t197 = shen_vector_get(ctx, caps, 1);
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t198 = objects[0];
  KLObject* t199;
  {
    KLObject* a199[] = {t196, t197, t198};
    t199 = shen_tail_apply_direct(ctx, "shen.pui-h", 3, a199);
  }
    return t199;
  }
}

static KLObject* lambda_4 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  KLObject* t208 = shen_vector_get(ctx, caps, 0);
  KLObject* t209 = shen_vector_get(ctx, caps, 1);
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t210 = objects[0];
  KLObject* t211;
  {
    KLObject* a211[] = {t208, t209, t210};
    t211 = shen_tail_apply_direct(ctx, "shen.pui-h", 3, a211);
  }
    return t211;
  }
}

static KLObject* native_kl_shen_2eshen_0 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  (void)function_object;
  (void)arguments;
  {
  tail_start_kl_shen_2eshen_0: ;
    (void)init_step_kl_shen_2eshen_0_0();
    (void)init_step_kl_shen_2eshen_0_1();
    KLObject* t2 = shen_empty_list(ctx);
    return t2;
  }
}

static KLObject* native_kl_shen_2eloop_1 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  (void)function_object;
  (void)arguments;
  {
  tail_start_kl_shen_2eloop_1: ;
    (void)init_step_kl_shen_2eloop_1_0();
    (void)init_step_kl_shen_2eloop_1_1();
    (void)init_step_kl_shen_2eloop_1_2();
    (void)init_step_kl_shen_2eloop_1_3();
    KLObject* t17 = shen_empty_list(ctx);
    return t17;
  }
}

static KLObject* native_kl_shen_2ecredits_2 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  (void)function_object;
  (void)arguments;
  {
  tail_start_kl_shen_2ecredits_2: ;
    (void)init_step_kl_shen_2ecredits_2_0();
    (void)init_step_kl_shen_2ecredits_2_1();
    (void)init_step_kl_shen_2ecredits_2_2();
    KLObject* t63 = shen_empty_list(ctx);
    return t63;
  }
}

static KLObject* native_kl_shen_2einitialise_5fenvironment_3 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  (void)function_object;
  (void)arguments;
  {
  tail_start_kl_shen_2einitialise_5fenvironment_3: ;
    (void)init_step_kl_shen_2einitialise_5fenvironment_3_0();
    (void)init_step_kl_shen_2einitialise_5fenvironment_3_1();
    KLObject* t70 = shen_empty_list(ctx);
    return t70;
  }
}

static KLObject* native_kl_shen_2eprompt_4 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  (void)function_object;
  (void)arguments;
  {
  tail_start_kl_shen_2eprompt_4: ;
  KLObject* t73 = shen_intern(ctx, "shen.*tc*");
  KLObject* t72;
  {
    KLObject* a72[] = {t73};
    t72 = shen_apply_direct(ctx, "value", 1, a72);
  }
  KLObject* t71;
  if (!shen_is_boolean(ctx, t72))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t72)) {
  KLObject* t76 = shen_string(ctx, "\n(");
  KLObject* t80 = shen_intern(ctx, "shen.*history*");
  KLObject* t79;
  {
    KLObject* a79[] = {t80};
    t79 = shen_apply_direct(ctx, "value", 1, a79);
  }
  KLObject* t78;
  {
    KLObject* a78[] = {t79};
    t78 = shen_apply_direct(ctx, "length", 1, a78);
  }
  KLObject* t81 = shen_string(ctx, "+) ");
  KLObject* t82 = shen_intern(ctx, "shen.a");
  KLObject* t77;
  {
    KLObject* a77[] = {t78, t81, t82};
    t77 = shen_apply_direct(ctx, "shen.app", 3, a77);
  }
  KLObject* t75;
  {
    KLObject* a75[] = {t76, t77};
    t75 = shen_apply_direct(ctx, "cn", 2, a75);
  }
  KLObject* t83 = shen_apply_direct(ctx, "stoutput", 0, NULL);
  KLObject* t74;
  {
    KLObject* a74[] = {t75, t83};
    t74 = shen_tail_apply_direct(ctx, "pr", 2, a74);
  }
    t71 = t74;
  } else {
  KLObject* t86 = shen_string(ctx, "\n(");
  KLObject* t90 = shen_intern(ctx, "shen.*history*");
  KLObject* t89;
  {
    KLObject* a89[] = {t90};
    t89 = shen_apply_direct(ctx, "value", 1, a89);
  }
  KLObject* t88;
  {
    KLObject* a88[] = {t89};
    t88 = shen_apply_direct(ctx, "length", 1, a88);
  }
  KLObject* t91 = shen_string(ctx, "-) ");
  KLObject* t92 = shen_intern(ctx, "shen.a");
  KLObject* t87;
  {
    KLObject* a87[] = {t88, t91, t92};
    t87 = shen_apply_direct(ctx, "shen.app", 3, a87);
  }
  KLObject* t85;
  {
    KLObject* a85[] = {t86, t87};
    t85 = shen_apply_direct(ctx, "cn", 2, a85);
  }
  KLObject* t93 = shen_apply_direct(ctx, "stoutput", 0, NULL);
  KLObject* t84;
  {
    KLObject* a84[] = {t85, t93};
    t84 = shen_tail_apply_direct(ctx, "pr", 2, a84);
  }
    t71 = t84;
  }
    return t71;
  }
}

static KLObject* native_kl_shen_2eread_2devaluate_2dprint_5 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  (void)function_object;
  (void)arguments;
  {
  tail_start_kl_shen_2eread_2devaluate_2dprint_5: ;
  KLObject* t95 = shen_intern(ctx, "shen.*package*");
  KLObject* t94;
  {
    KLObject* a94[] = {t95};
    t94 = shen_apply_direct(ctx, "value", 1, a94);
  }
  KLObject* t99 = shen_apply_direct(ctx, "stinput", 0, NULL);
  KLObject* t98;
  {
    KLObject* a98[] = {t99};
    t98 = shen_apply_direct(ctx, "lineread", 1, a98);
  }
  KLObject* t96;
  {
    KLObject* a96[] = {t94, t98};
    t96 = shen_apply_direct(ctx, "shen.package-user-input", 2, a96);
  }
  KLObject* t100 = shen_apply_direct(ctx, "shen.update-history", 0, NULL);
  KLObject* t105 = shen_intern(ctx, "shen.*tc*");
  KLObject* t104;
  {
    KLObject* a104[] = {t105};
    t104 = shen_apply_direct(ctx, "value", 1, a104);
  }
  KLObject* t101;
  {
    KLObject* a101[] = {t96, t100, t104};
    t101 = shen_tail_apply_direct(ctx, "shen.evaluate-lineread", 3, a101);
  }
    return t101;
  }
}

static KLObject* native_kl_shen_2epackage_2duser_2dinput_6 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t106 = objects[0];
    KLObject* t107 = objects[1];
  tail_start_kl_shen_2epackage_2duser_2dinput_6: ;
  KLObject* t108;
  {
  KLObject* t109 = shen_intern(ctx, "null");
  KLObject* t111 = shen_eq(ctx, t109, t106);
    if (!shen_is_boolean(ctx, t111))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t111)) {
      t108 = t107;
    } else {
  KLObject* t113 = shen_true(ctx);
    if (!shen_is_boolean(ctx, t113))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t113)) {
  KLObject* t114;
  {
    KLObject* a114[] = {t106};
    t114 = shen_apply_direct(ctx, "str", 1, a114);
  }
  KLObject* t116;
  {
    KLObject* a116[] = {t106};
    t116 = shen_apply_direct(ctx, "external", 1, a116);
  }
  KLObject* t119;
  {
    Vector* caps_1 = shen_vector(ctx, 2);
    shen_vector_set(ctx, caps_1, 0, t114);
    shen_vector_set(ctx, caps_1, 1, t116);
    t119 = shen_native_closure(ctx, 1, &lambda_1, caps_1);
  }
  KLObject* t118;
  {
    KLObject* a118[] = {t119, t107};
    t118 = shen_tail_apply_direct(ctx, "map", 2, a118);
  }
      t108 = t118;
    } else {
      shen_simple_error(ctx, "No true case found for cond");
      t108 = shen_empty_list(ctx);
    }
    }
  }
    return t108;
  }
}

static KLObject* native_kl_shen_2epui_2dh_7 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t128 = objects[0];
    KLObject* t129 = objects[1];
    KLObject* t130 = objects[2];
  tail_start_kl_shen_2epui_2dh_7: ;
  KLObject* t131;
  {
  KLObject* t134 = shen_cons_p(ctx, t130);
  KLObject* t132;
  if (!shen_is_boolean(ctx, t134))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t134)) {
    t132 = t134;
  } else {
  KLObject* t136 = shen_intern(ctx, "fn");
  KLObject* t138 = shen_hd(ctx, t130);
  KLObject* t139 = shen_eq(ctx, t136, t138);
  KLObject* t135;
  if (!shen_is_boolean(ctx, t139))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t139)) {
    t135 = t139;
  } else {
  KLObject* t142 = shen_tl(ctx, t130);
  KLObject* t143 = shen_cons_p(ctx, t142);
  KLObject* t140;
  if (!shen_is_boolean(ctx, t143))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t143)) {
    t140 = t143;
  } else {
  KLObject* t144 = shen_empty_list(ctx);
  KLObject* t146 = shen_tl(ctx, t130);
  KLObject* t147 = shen_tl(ctx, t146);
  KLObject* t148 = shen_eq(ctx, t144, t147);
    if (!shen_is_boolean(ctx, t148))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t140 = t148;
  }
    if (!shen_is_boolean(ctx, t140))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t135 = t140;
  }
    if (!shen_is_boolean(ctx, t135))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t132 = t135;
  }
    if (!shen_is_boolean(ctx, t132))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t132)) {
  KLObject* t152 = shen_tl(ctx, t130);
  KLObject* t153 = shen_hd(ctx, t152);
  KLObject* t150;
  {
    KLObject* a150[] = {t153, t128, t129};
    t150 = shen_apply_direct(ctx, "shen.internal?", 3, a150);
  }
  KLObject* t149;
  if (!shen_is_boolean(ctx, t150))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t150)) {
  KLObject* t156 = shen_intern(ctx, "fn");
  KLObject* t160 = shen_tl(ctx, t130);
  KLObject* t161 = shen_hd(ctx, t160);
  KLObject* t157;
  {
    KLObject* a157[] = {t128, t161};
    t157 = shen_apply_direct(ctx, "shen.intern-in-package", 2, a157);
  }
  KLObject* t162 = shen_empty_list(ctx);
  KLObject* t163 = shen_cons(ctx, t157, t162);
  KLObject* t164 = shen_cons(ctx, t156, t163);
    t149 = t164;
  } else {
    t149 = t130;
  }
      t131 = t149;
    } else {
  KLObject* t167 = shen_cons_p(ctx, t130);
    if (!shen_is_boolean(ctx, t167))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t167)) {
  KLObject* t171 = shen_hd(ctx, t130);
  KLObject* t169;
  {
    KLObject* a169[] = {t171, t128, t129};
    t169 = shen_apply_direct(ctx, "shen.internal?", 3, a169);
  }
  KLObject* t168;
  if (!shen_is_boolean(ctx, t169))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t169)) {
  KLObject* t177 = shen_hd(ctx, t130);
  KLObject* t174;
  {
    KLObject* a174[] = {t128, t177};
    t174 = shen_apply_direct(ctx, "shen.intern-in-package", 2, a174);
  }
  KLObject* t179;
  {
    Vector* caps_2 = shen_vector(ctx, 2);
    shen_vector_set(ctx, caps_2, 0, t128);
    shen_vector_set(ctx, caps_2, 1, t129);
    t179 = shen_native_closure(ctx, 1, &lambda_2, caps_2);
  }
  KLObject* t188 = shen_tl(ctx, t130);
  KLObject* t178;
  {
    KLObject* a178[] = {t179, t188};
    t178 = shen_apply_direct(ctx, "map", 2, a178);
  }
  KLObject* t189 = shen_cons(ctx, t174, t178);
    t168 = t189;
  } else {
  KLObject* t192 = shen_hd(ctx, t130);
  KLObject* t193 = shen_cons_p(ctx, t192);
  KLObject* t190;
  if (!shen_is_boolean(ctx, t193))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t193)) {
  KLObject* t195;
  {
    Vector* caps_3 = shen_vector(ctx, 2);
    shen_vector_set(ctx, caps_3, 0, t128);
    shen_vector_set(ctx, caps_3, 1, t129);
    t195 = shen_native_closure(ctx, 1, &lambda_3, caps_3);
  }
  KLObject* t194;
  {
    KLObject* a194[] = {t195, t130};
    t194 = shen_tail_apply_direct(ctx, "map", 2, a194);
  }
    t190 = t194;
  } else {
  KLObject* t205 = shen_hd(ctx, t130);
  KLObject* t207;
  {
    Vector* caps_4 = shen_vector(ctx, 2);
    shen_vector_set(ctx, caps_4, 0, t128);
    shen_vector_set(ctx, caps_4, 1, t129);
    t207 = shen_native_closure(ctx, 1, &lambda_4, caps_4);
  }
  KLObject* t216 = shen_tl(ctx, t130);
  KLObject* t206;
  {
    KLObject* a206[] = {t207, t216};
    t206 = shen_apply_direct(ctx, "map", 2, a206);
  }
  KLObject* t217 = shen_cons(ctx, t205, t206);
    t190 = t217;
  }
    t168 = t190;
  }
      t131 = t168;
    } else {
  KLObject* t218 = shen_true(ctx);
    if (!shen_is_boolean(ctx, t218))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t218)) {
      t131 = t130;
    } else {
      shen_simple_error(ctx, "No true case found for cond");
      t131 = shen_empty_list(ctx);
    }
    }
    }
  }
    return t131;
  }
}

static KLObject* native_kl_shen_2eupdate_2dhistory_8 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  (void)function_object;
  (void)arguments;
  {
  tail_start_kl_shen_2eupdate_2dhistory_8: ;
  KLObject* t221 = shen_intern(ctx, "shen.*history*");
  KLObject* t223 = shen_apply_direct(ctx, "it", 0, NULL);
  KLObject* t222;
  {
    KLObject* a222[] = {t223};
    t222 = shen_apply_direct(ctx, "shen.trim-it", 1, a222);
  }
  KLObject* t225 = shen_intern(ctx, "shen.*history*");
  KLObject* t224;
  {
    KLObject* a224[] = {t225};
    t224 = shen_apply_direct(ctx, "value", 1, a224);
  }
  KLObject* t226 = shen_cons(ctx, t222, t224);
  KLObject* t220;
  {
    KLObject* a220[] = {t221, t226};
    t220 = shen_tail_apply_direct(ctx, "set", 2, a220);
  }
    return t220;
  }
}

static KLObject* native_kl_shen_2etrim_2dit_9 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t227 = objects[0];
  tail_start_kl_shen_2etrim_2dit_9: ;
  KLObject* t228;
  {
  KLObject* t230;
  {
    KLObject* a230[] = {t227};
    t230 = shen_apply_direct(ctx, "shen.+string?", 1, a230);
  }
  KLObject* t229;
  if (!shen_is_boolean(ctx, t230))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t230)) {
    t229 = t230;
  } else {
  KLObject* t234;
  {
    KLObject* a234[] = {t227};
    t234 = shen_apply_direct(ctx, "hdstr", 1, a234);
  }
  KLObject* t233;
  {
    KLObject* a233[] = {t234};
    t233 = shen_apply_direct(ctx, "string->n", 1, a233);
  }
  KLObject* t232;
  {
    KLObject* a232[] = {t233};
    t232 = shen_apply_direct(ctx, "shen.whitespace?", 1, a232);
  }
    if (!shen_is_boolean(ctx, t232))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t229 = t232;
  }
    if (!shen_is_boolean(ctx, t229))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t229)) {
  KLObject* t236;
  {
    KLObject* a236[] = {t227};
    t236 = shen_apply_direct(ctx, "tlstr", 1, a236);
  }
  {
    KLObject* n238_0 = t236;
    t227 = n238_0;
    goto tail_start_kl_shen_2etrim_2dit_9;
  }
  KLObject* t238 = NULL;
      t228 = t238;
    } else {
  KLObject* t239 = shen_true(ctx);
    if (!shen_is_boolean(ctx, t239))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t239)) {
      t228 = t227;
    } else {
      shen_simple_error(ctx, "No true case found for cond");
      t228 = shen_empty_list(ctx);
    }
    }
  }
    return t228;
  }
}

static KLObject* native_kl_shen_2eevaluate_2dlineread_10 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t241 = objects[0];
    KLObject* t242 = objects[1];
    KLObject* t243 = objects[2];
  tail_start_kl_shen_2eevaluate_2dlineread_10: ;
  KLObject* t244;
  {
  KLObject* t247 = shen_cons_p(ctx, t241);
  KLObject* t245;
  if (!shen_is_boolean(ctx, t247))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t247)) {
    t245 = t247;
  } else {
  KLObject* t249 = shen_empty_list(ctx);
  KLObject* t251 = shen_tl(ctx, t241);
  KLObject* t252 = shen_eq(ctx, t249, t251);
  KLObject* t248;
  if (!shen_is_boolean(ctx, t252))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t252)) {
    t248 = t252;
  } else {
  KLObject* t255 = shen_cons_p(ctx, t242);
  KLObject* t253;
  if (!shen_is_boolean(ctx, t255))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t255)) {
    t253 = t255;
  } else {
  KLObject* t259 = shen_hd(ctx, t242);
  KLObject* t257;
  {
    KLObject* a257[] = {t259};
    t257 = shen_apply_direct(ctx, "shen.+string?", 1, a257);
  }
  KLObject* t256;
  if (!shen_is_boolean(ctx, t257))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t257)) {
    t256 = t257;
  } else {
  KLObject* t261 = shen_string(ctx, "!");
  KLObject* t264 = shen_hd(ctx, t242);
  KLObject* t262;
  {
    KLObject* a262[] = {t264};
    t262 = shen_apply_direct(ctx, "hdstr", 1, a262);
  }
  KLObject* t265 = shen_eq(ctx, t261, t262);
  KLObject* t260;
  if (!shen_is_boolean(ctx, t265))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t265)) {
    t260 = t265;
  } else {
  KLObject* t270 = shen_hd(ctx, t242);
  KLObject* t268;
  {
    KLObject* a268[] = {t270};
    t268 = shen_apply_direct(ctx, "tlstr", 1, a268);
  }
  KLObject* t267;
  {
    KLObject* a267[] = {t268};
    t267 = shen_apply_direct(ctx, "shen.+string?", 1, a267);
  }
  KLObject* t266;
  if (!shen_is_boolean(ctx, t267))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t267)) {
    t266 = t267;
  } else {
  KLObject* t272 = shen_string(ctx, "!");
  KLObject* t276 = shen_hd(ctx, t242);
  KLObject* t274;
  {
    KLObject* a274[] = {t276};
    t274 = shen_apply_direct(ctx, "tlstr", 1, a274);
  }
  KLObject* t273;
  {
    KLObject* a273[] = {t274};
    t273 = shen_apply_direct(ctx, "hdstr", 1, a273);
  }
  KLObject* t277 = shen_eq(ctx, t272, t273);
  KLObject* t271;
  if (!shen_is_boolean(ctx, t277))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t277)) {
    t271 = t277;
  } else {
  KLObject* t279 = shen_tl(ctx, t242);
  KLObject* t280 = shen_cons_p(ctx, t279);
    if (!shen_is_boolean(ctx, t280))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t271 = t280;
  }
    if (!shen_is_boolean(ctx, t271))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t266 = t271;
  }
    if (!shen_is_boolean(ctx, t266))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t260 = t266;
  }
    if (!shen_is_boolean(ctx, t260))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t256 = t260;
  }
    if (!shen_is_boolean(ctx, t256))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t253 = t256;
  }
    if (!shen_is_boolean(ctx, t253))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t248 = t253;
  }
    if (!shen_is_boolean(ctx, t248))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t245 = t248;
  }
    if (!shen_is_boolean(ctx, t245))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t245)) {
  KLObject* t283 = shen_tl(ctx, t242);
  KLObject* t284 = shen_hd(ctx, t283);
  KLObject* t281;
  {
    KLObject* a281[] = {t284};
    t281 = shen_apply_direct(ctx, "read-from-string", 1, a281);
  }
  KLObject* t286 = shen_intern(ctx, "shen.*history*");
  KLObject* t288 = shen_tl(ctx, t242);
  KLObject* t289 = shen_hd(ctx, t288);
  KLObject* t291 = shen_tl(ctx, t242);
  KLObject* t292 = shen_cons(ctx, t289, t291);
  KLObject* t285;
  {
    KLObject* a285[] = {t286, t292};
    t285 = shen_apply_direct(ctx, "set", 2, a285);
  }
  KLObject* t296 = shen_tl(ctx, t242);
  KLObject* t297 = shen_hd(ctx, t296);
  KLObject* t298 = shen_string(ctx, "\n");
  KLObject* t299 = shen_intern(ctx, "shen.a");
  KLObject* t294;
  {
    KLObject* a294[] = {t297, t298, t299};
    t294 = shen_apply_direct(ctx, "shen.app", 3, a294);
  }
  KLObject* t300 = shen_apply_direct(ctx, "stoutput", 0, NULL);
  KLObject* t293;
  {
    KLObject* a293[] = {t294, t300};
    t293 = shen_apply_direct(ctx, "pr", 2, a293);
  }
  {
    KLObject* n304_0 = t281;
    KLObject* n304_1 = t285;
    KLObject* n304_2 = t243;
    t241 = n304_0;
    t242 = n304_1;
    t243 = n304_2;
    goto tail_start_kl_shen_2eevaluate_2dlineread_10;
  }
  KLObject* t304 = NULL;
      t244 = t304;
    } else {
  KLObject* t307 = shen_cons_p(ctx, t241);
  KLObject* t305;
  if (!shen_is_boolean(ctx, t307))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t307)) {
    t305 = t307;
  } else {
  KLObject* t309 = shen_empty_list(ctx);
  KLObject* t311 = shen_tl(ctx, t241);
  KLObject* t312 = shen_eq(ctx, t309, t311);
  KLObject* t308;
  if (!shen_is_boolean(ctx, t312))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t312)) {
    t308 = t312;
  } else {
  KLObject* t315 = shen_cons_p(ctx, t242);
  KLObject* t313;
  if (!shen_is_boolean(ctx, t315))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t315)) {
    t313 = t315;
  } else {
  KLObject* t319 = shen_hd(ctx, t242);
  KLObject* t317;
  {
    KLObject* a317[] = {t319};
    t317 = shen_apply_direct(ctx, "shen.+string?", 1, a317);
  }
  KLObject* t316;
  if (!shen_is_boolean(ctx, t317))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t317)) {
    t316 = t317;
  } else {
  KLObject* t320 = shen_string(ctx, "!");
  KLObject* t323 = shen_hd(ctx, t242);
  KLObject* t321;
  {
    KLObject* a321[] = {t323};
    t321 = shen_apply_direct(ctx, "hdstr", 1, a321);
  }
  KLObject* t324 = shen_eq(ctx, t320, t321);
    if (!shen_is_boolean(ctx, t324))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t316 = t324;
  }
    if (!shen_is_boolean(ctx, t316))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t313 = t316;
  }
    if (!shen_is_boolean(ctx, t313))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t308 = t313;
  }
    if (!shen_is_boolean(ctx, t308))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t305 = t308;
  }
    if (!shen_is_boolean(ctx, t305))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t305)) {
  KLObject* t328 = shen_hd(ctx, t242);
  KLObject* t326;
  {
    KLObject* a326[] = {t328};
    t326 = shen_apply_direct(ctx, "tlstr", 1, a326);
  }
  KLObject* t329 = shen_string(ctx, "");
  KLObject* t330 = shen_eq(ctx, t326, t329);
  KLObject* t325;
  if (!shen_is_boolean(ctx, t330))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t330)) {
  KLObject* t331 = shen_empty_list(ctx);
    t325 = t331;
  } else {
  KLObject* t335 = shen_hd(ctx, t242);
  KLObject* t333;
  {
    KLObject* a333[] = {t335};
    t333 = shen_apply_direct(ctx, "tlstr", 1, a333);
  }
  KLObject* t332;
  {
    KLObject* a332[] = {t333};
    t332 = shen_apply_direct(ctx, "read-from-string", 1, a332);
  }
  KLObject* t336 = shen_hd(ctx, t332);
    t325 = t336;
  }
  KLObject* t341 = shen_hd(ctx, t242);
  KLObject* t339;
  {
    KLObject* a339[] = {t341};
    t339 = shen_apply_direct(ctx, "tlstr", 1, a339);
  }
  KLObject* t343 = shen_tl(ctx, t242);
  KLObject* t337;
  {
    KLObject* a337[] = {t325, t339, t343};
    t337 = shen_apply_direct(ctx, "shen.use-history", 3, a337);
  }
  KLObject* t347 = shen_string(ctx, "\n");
  KLObject* t348 = shen_intern(ctx, "shen.a");
  KLObject* t345;
  {
    KLObject* a345[] = {t337, t347, t348};
    t345 = shen_apply_direct(ctx, "shen.app", 3, a345);
  }
  KLObject* t349 = shen_apply_direct(ctx, "stoutput", 0, NULL);
  KLObject* t344;
  {
    KLObject* a344[] = {t345, t349};
    t344 = shen_apply_direct(ctx, "pr", 2, a344);
  }
  KLObject* t350;
  {
    KLObject* a350[] = {t337};
    t350 = shen_apply_direct(ctx, "read-from-string", 1, a350);
  }
  KLObject* t353 = shen_intern(ctx, "shen.*history*");
  KLObject* t356 = shen_tl(ctx, t242);
  KLObject* t357 = shen_cons(ctx, t337, t356);
  KLObject* t352;
  {
    KLObject* a352[] = {t353, t357};
    t352 = shen_apply_direct(ctx, "set", 2, a352);
  }
  {
    KLObject* n361_0 = t350;
    KLObject* n361_1 = t352;
    KLObject* n361_2 = t243;
    t241 = n361_0;
    t242 = n361_1;
    t243 = n361_2;
    goto tail_start_kl_shen_2eevaluate_2dlineread_10;
  }
  KLObject* t361 = NULL;
      t244 = t361;
    } else {
  KLObject* t364 = shen_cons_p(ctx, t241);
  KLObject* t362;
  if (!shen_is_boolean(ctx, t364))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t364)) {
    t362 = t364;
  } else {
  KLObject* t366 = shen_empty_list(ctx);
  KLObject* t368 = shen_tl(ctx, t241);
  KLObject* t369 = shen_eq(ctx, t366, t368);
  KLObject* t365;
  if (!shen_is_boolean(ctx, t369))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t369)) {
    t365 = t369;
  } else {
  KLObject* t372 = shen_cons_p(ctx, t242);
  KLObject* t370;
  if (!shen_is_boolean(ctx, t372))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t372)) {
    t370 = t372;
  } else {
  KLObject* t376 = shen_hd(ctx, t242);
  KLObject* t374;
  {
    KLObject* a374[] = {t376};
    t374 = shen_apply_direct(ctx, "shen.+string?", 1, a374);
  }
  KLObject* t373;
  if (!shen_is_boolean(ctx, t374))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t374)) {
    t373 = t374;
  } else {
  KLObject* t377 = shen_string(ctx, "%");
  KLObject* t380 = shen_hd(ctx, t242);
  KLObject* t378;
  {
    KLObject* a378[] = {t380};
    t378 = shen_apply_direct(ctx, "hdstr", 1, a378);
  }
  KLObject* t381 = shen_eq(ctx, t377, t378);
    if (!shen_is_boolean(ctx, t381))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t373 = t381;
  }
    if (!shen_is_boolean(ctx, t373))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t370 = t373;
  }
    if (!shen_is_boolean(ctx, t370))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t365 = t370;
  }
    if (!shen_is_boolean(ctx, t365))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t362 = t365;
  }
    if (!shen_is_boolean(ctx, t362))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t362)) {
  KLObject* t385 = shen_hd(ctx, t242);
  KLObject* t383;
  {
    KLObject* a383[] = {t385};
    t383 = shen_apply_direct(ctx, "tlstr", 1, a383);
  }
  KLObject* t386 = shen_string(ctx, "");
  KLObject* t387 = shen_eq(ctx, t383, t386);
  KLObject* t382;
  if (!shen_is_boolean(ctx, t387))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t387)) {
  KLObject* t388 = shen_empty_list(ctx);
    t382 = t388;
  } else {
  KLObject* t392 = shen_hd(ctx, t242);
  KLObject* t390;
  {
    KLObject* a390[] = {t392};
    t390 = shen_apply_direct(ctx, "tlstr", 1, a390);
  }
  KLObject* t389;
  {
    KLObject* a389[] = {t390};
    t389 = shen_apply_direct(ctx, "read-from-string", 1, a389);
  }
  KLObject* t393 = shen_hd(ctx, t389);
    t382 = t393;
  }
  KLObject* t398 = shen_hd(ctx, t242);
  KLObject* t396;
  {
    KLObject* a396[] = {t398};
    t396 = shen_apply_direct(ctx, "tlstr", 1, a396);
  }
  KLObject* t400 = shen_tl(ctx, t242);
  KLObject* t394;
  {
    KLObject* a394[] = {t382, t396, t400};
    t394 = shen_apply_direct(ctx, "shen.peek-history", 3, a394);
  }
  KLObject* t402 = shen_intern(ctx, "shen.*history*");
  KLObject* t404 = shen_tl(ctx, t242);
  KLObject* t401;
  {
    KLObject* a401[] = {t402, t404};
    t401 = shen_apply_direct(ctx, "set", 2, a401);
  }
  KLObject* t405 = shen_tail_apply_direct(ctx, "abort", 0, NULL);
      t244 = t405;
    } else {
  KLObject* t406 = shen_true(ctx);
  KLObject* t408 = shen_eq(ctx, t406, t243);
    if (!shen_is_boolean(ctx, t408))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t408)) {
  KLObject* t409;
  {
    KLObject* a409[] = {t241};
    t409 = shen_tail_apply_direct(ctx, "shen.check-eval-and-print", 1, a409);
  }
      t244 = t409;
    } else {
  KLObject* t411 = shen_false(ctx);
  KLObject* t413 = shen_eq(ctx, t411, t243);
    if (!shen_is_boolean(ctx, t413))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t413)) {
  KLObject* t414;
  {
    KLObject* a414[] = {t241};
    t414 = shen_tail_apply_direct(ctx, "shen.eval-and-print", 1, a414);
  }
      t244 = t414;
    } else {
  KLObject* t416 = shen_true(ctx);
    if (!shen_is_boolean(ctx, t416))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t416)) {
  KLObject* t418 = shen_string(ctx, "implementation error in shen.evaluate-lineread");
  KLObject* t417;
  {
    KLObject* a417[] = {t418};
    t417 = shen_tail_apply_direct(ctx, "simple-error", 1, a417);
  }
      t244 = t417;
    } else {
      shen_simple_error(ctx, "No true case found for cond");
      t244 = shen_empty_list(ctx);
    }
    }
    }
    }
    }
    }
  }
    return t244;
  }
}

static KLObject* native_kl_shen_2euse_2dhistory_11 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t419 = objects[0];
    KLObject* t420 = objects[1];
    KLObject* t421 = objects[2];
  tail_start_kl_shen_2euse_2dhistory_11: ;
  KLObject* t423;
  {
    KLObject* a423[] = {t419};
    t423 = shen_apply_direct(ctx, "integer?", 1, a423);
  }
  KLObject* t422;
  if (!shen_is_boolean(ctx, t423))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t423)) {
  KLObject* t426 = shen_number_l(ctx, 1);
  KLObject* t428 = shen_add(ctx, t426, t419);
  KLObject* t429;
  {
    KLObject* a429[] = {t421};
    t429 = shen_apply_direct(ctx, "reverse", 1, a429);
  }
  KLObject* t425;
  {
    KLObject* a425[] = {t428, t429};
    t425 = shen_tail_apply_direct(ctx, "nth", 2, a425);
  }
    t422 = t425;
  } else {
  KLObject* t433 = shen_symbol_p(ctx, t419);
  KLObject* t431;
  if (!shen_is_boolean(ctx, t433))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t433)) {
  KLObject* t434;
  {
    KLObject* a434[] = {t420, t421};
    t434 = shen_tail_apply_direct(ctx, "shen.string-match", 2, a434);
  }
    t431 = t434;
  } else {
  KLObject* t438 = shen_string(ctx, "! expects a number or a symbol\n");
  KLObject* t437;
  {
    KLObject* a437[] = {t438};
    t437 = shen_tail_apply_direct(ctx, "simple-error", 1, a437);
  }
    t431 = t437;
  }
    t422 = t431;
  }
    return t422;
  }
}

static KLObject* native_kl_shen_2epeek_2dhistory_12 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t439 = objects[0];
    KLObject* t440 = objects[1];
    KLObject* t441 = objects[2];
  tail_start_kl_shen_2epeek_2dhistory_12: ;
  KLObject* t443;
  {
    KLObject* a443[] = {t439};
    t443 = shen_apply_direct(ctx, "integer?", 1, a443);
  }
  KLObject* t442;
  if (!shen_is_boolean(ctx, t443))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t443)) {
  KLObject* t447 = shen_string(ctx, "\n");
  KLObject* t450 = shen_number_l(ctx, 1);
  KLObject* t452 = shen_add(ctx, t450, t439);
  KLObject* t453;
  {
    KLObject* a453[] = {t441};
    t453 = shen_apply_direct(ctx, "reverse", 1, a453);
  }
  KLObject* t449;
  {
    KLObject* a449[] = {t452, t453};
    t449 = shen_apply_direct(ctx, "nth", 2, a449);
  }
  KLObject* t455 = shen_string(ctx, "");
  KLObject* t456 = shen_intern(ctx, "shen.a");
  KLObject* t448;
  {
    KLObject* a448[] = {t449, t455, t456};
    t448 = shen_apply_direct(ctx, "shen.app", 3, a448);
  }
  KLObject* t446;
  {
    KLObject* a446[] = {t447, t448};
    t446 = shen_apply_direct(ctx, "cn", 2, a446);
  }
  KLObject* t457 = shen_apply_direct(ctx, "stoutput", 0, NULL);
  KLObject* t445;
  {
    KLObject* a445[] = {t446, t457};
    t445 = shen_tail_apply_direct(ctx, "pr", 2, a445);
  }
    t442 = t445;
  } else {
  KLObject* t461 = shen_string(ctx, "");
  KLObject* t462 = shen_eq(ctx, t440, t461);
  KLObject* t459;
  if (!shen_is_boolean(ctx, t462))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (shen_boolean_value(ctx, t462)) {
    t459 = t462;
  } else {
  KLObject* t464 = shen_symbol_p(ctx, t439);
    if (!shen_is_boolean(ctx, t464))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t459 = t464;
  }
  KLObject* t458;
  if (!shen_is_boolean(ctx, t459))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t459)) {
  KLObject* t466 = shen_number_l(ctx, 0);
  KLObject* t468;
  {
    KLObject* a468[] = {t441};
    t468 = shen_apply_direct(ctx, "reverse", 1, a468);
  }
  KLObject* t465;
  {
    KLObject* a465[] = {t466, t440, t468};
    t465 = shen_tail_apply_direct(ctx, "shen.recursive-string-match", 3, a465);
  }
    t458 = t465;
  } else {
  KLObject* t471 = shen_string(ctx, "% expects a number or a symbol\n");
  KLObject* t470;
  {
    KLObject* a470[] = {t471};
    t470 = shen_tail_apply_direct(ctx, "simple-error", 1, a470);
  }
    t458 = t470;
  }
    t442 = t458;
  }
    return t442;
  }
}

static KLObject* native_kl_shen_2estring_2dmatch_13 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t472 = objects[0];
    KLObject* t473 = objects[1];
  tail_start_kl_shen_2estring_2dmatch_13: ;
  KLObject* t474;
  {
  KLObject* t475 = shen_empty_list(ctx);
  KLObject* t477 = shen_eq(ctx, t475, t473);
    if (!shen_is_boolean(ctx, t477))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t477)) {
  KLObject* t479 = shen_string(ctx, "\ninput not found");
  KLObject* t478;
  {
    KLObject* a478[] = {t479};
    t478 = shen_tail_apply_direct(ctx, "simple-error", 1, a478);
  }
      t474 = t478;
    } else {
  KLObject* t482 = shen_cons_p(ctx, t473);
  KLObject* t480;
  if (!shen_is_boolean(ctx, t482))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t482)) {
    t480 = t482;
  } else {
  KLObject* t486 = shen_hd(ctx, t473);
  KLObject* t483;
  {
    KLObject* a483[] = {t472, t486};
    t483 = shen_apply_direct(ctx, "shen.string-prefix?", 2, a483);
  }
    if (!shen_is_boolean(ctx, t483))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t480 = t483;
  }
    if (!shen_is_boolean(ctx, t480))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t480)) {
  KLObject* t488 = shen_hd(ctx, t473);
      t474 = t488;
    } else {
  KLObject* t490 = shen_cons_p(ctx, t473);
    if (!shen_is_boolean(ctx, t490))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t490)) {
  KLObject* t493 = shen_tl(ctx, t473);
  {
    KLObject* n494_0 = t472;
    KLObject* n494_1 = t493;
    t472 = n494_0;
    t473 = n494_1;
    goto tail_start_kl_shen_2estring_2dmatch_13;
  }
  KLObject* t494 = NULL;
      t474 = t494;
    } else {
  KLObject* t495 = shen_true(ctx);
    if (!shen_is_boolean(ctx, t495))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t495)) {
  KLObject* t497 = shen_string(ctx, "implementation error in shen.string-match");
  KLObject* t496;
  {
    KLObject* a496[] = {t497};
    t496 = shen_tail_apply_direct(ctx, "simple-error", 1, a496);
  }
      t474 = t496;
    } else {
      shen_simple_error(ctx, "No true case found for cond");
      t474 = shen_empty_list(ctx);
    }
    }
    }
    }
  }
    return t474;
  }
}

static KLObject* native_kl_shen_2estring_2dprefix_3f_14 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t498 = objects[0];
    KLObject* t499 = objects[1];
  tail_start_kl_shen_2estring_2dprefix_3f_14: ;
  KLObject* t500;
  {
  KLObject* t501 = shen_string(ctx, "");
  KLObject* t503 = shen_eq(ctx, t501, t498);
    if (!shen_is_boolean(ctx, t503))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t503)) {
  KLObject* t504 = shen_true(ctx);
      t500 = t504;
    } else {
  KLObject* t506;
  {
    KLObject* a506[] = {t498};
    t506 = shen_apply_direct(ctx, "shen.+string?", 1, a506);
  }
  KLObject* t505;
  if (!shen_is_boolean(ctx, t506))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t506)) {
    t505 = t506;
  } else {
  KLObject* t510;
  {
    KLObject* a510[] = {t498};
    t510 = shen_apply_direct(ctx, "hdstr", 1, a510);
  }
  KLObject* t509;
  {
    KLObject* a509[] = {t510};
    t509 = shen_apply_direct(ctx, "string->n", 1, a509);
  }
  KLObject* t508;
  {
    KLObject* a508[] = {t509};
    t508 = shen_apply_direct(ctx, "shen.whitespace?", 1, a508);
  }
    if (!shen_is_boolean(ctx, t508))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t505 = t508;
  }
    if (!shen_is_boolean(ctx, t505))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t505)) {
  KLObject* t512;
  {
    KLObject* a512[] = {t498};
    t512 = shen_apply_direct(ctx, "tlstr", 1, a512);
  }
  {
    KLObject* n515_0 = t512;
    KLObject* n515_1 = t499;
    t498 = n515_0;
    t499 = n515_1;
    goto tail_start_kl_shen_2estring_2dprefix_3f_14;
  }
  KLObject* t515 = NULL;
      t500 = t515;
    } else {
  KLObject* t517;
  {
    KLObject* a517[] = {t499};
    t517 = shen_apply_direct(ctx, "shen.+string?", 1, a517);
  }
  KLObject* t516;
  if (!shen_is_boolean(ctx, t517))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t517)) {
    t516 = t517;
  } else {
  KLObject* t521;
  {
    KLObject* a521[] = {t499};
    t521 = shen_apply_direct(ctx, "hdstr", 1, a521);
  }
  KLObject* t520;
  {
    KLObject* a520[] = {t521};
    t520 = shen_apply_direct(ctx, "string->n", 1, a520);
  }
  KLObject* t519;
  {
    KLObject* a519[] = {t520};
    t519 = shen_apply_direct(ctx, "shen.whitespace?", 1, a519);
  }
    if (!shen_is_boolean(ctx, t519))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t516 = t519;
  }
    if (!shen_is_boolean(ctx, t516))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t516)) {
  KLObject* t524;
  {
    KLObject* a524[] = {t499};
    t524 = shen_apply_direct(ctx, "tlstr", 1, a524);
  }
  {
    KLObject* n526_0 = t498;
    KLObject* n526_1 = t524;
    t498 = n526_0;
    t499 = n526_1;
    goto tail_start_kl_shen_2estring_2dprefix_3f_14;
  }
  KLObject* t526 = NULL;
      t500 = t526;
    } else {
  KLObject* t528;
  {
    KLObject* a528[] = {t499};
    t528 = shen_apply_direct(ctx, "shen.+string?", 1, a528);
  }
  KLObject* t527;
  if (!shen_is_boolean(ctx, t528))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t528)) {
    t527 = t528;
  } else {
  KLObject* t530 = shen_string(ctx, "(");
  KLObject* t531;
  {
    KLObject* a531[] = {t499};
    t531 = shen_apply_direct(ctx, "hdstr", 1, a531);
  }
  KLObject* t533 = shen_eq(ctx, t530, t531);
    if (!shen_is_boolean(ctx, t533))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t527 = t533;
  }
    if (!shen_is_boolean(ctx, t527))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t527)) {
  KLObject* t535;
  {
    KLObject* a535[] = {t499};
    t535 = shen_apply_direct(ctx, "tlstr", 1, a535);
  }
  {
    KLObject* n537_0 = t498;
    KLObject* n537_1 = t535;
    t498 = n537_0;
    t499 = n537_1;
    goto tail_start_kl_shen_2estring_2dprefix_3f_14;
  }
  KLObject* t537 = NULL;
      t500 = t537;
    } else {
  KLObject* t539;
  {
    KLObject* a539[] = {t498};
    t539 = shen_apply_direct(ctx, "shen.+string?", 1, a539);
  }
  KLObject* t538;
  if (!shen_is_boolean(ctx, t539))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t539)) {
    t538 = t539;
  } else {
  KLObject* t542;
  {
    KLObject* a542[] = {t499};
    t542 = shen_apply_direct(ctx, "shen.+string?", 1, a542);
  }
  KLObject* t541;
  if (!shen_is_boolean(ctx, t542))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t542)) {
    t541 = t542;
  } else {
  KLObject* t544;
  {
    KLObject* a544[] = {t498};
    t544 = shen_apply_direct(ctx, "hdstr", 1, a544);
  }
  KLObject* t546;
  {
    KLObject* a546[] = {t499};
    t546 = shen_apply_direct(ctx, "hdstr", 1, a546);
  }
  KLObject* t548 = shen_eq(ctx, t544, t546);
    if (!shen_is_boolean(ctx, t548))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t541 = t548;
  }
    if (!shen_is_boolean(ctx, t541))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t538 = t541;
  }
    if (!shen_is_boolean(ctx, t538))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t538)) {
  KLObject* t549;
  {
    KLObject* a549[] = {t498};
    t549 = shen_apply_direct(ctx, "tlstr", 1, a549);
  }
  KLObject* t551;
  {
    KLObject* a551[] = {t499};
    t551 = shen_apply_direct(ctx, "tlstr", 1, a551);
  }
  {
    KLObject* n553_0 = t549;
    KLObject* n553_1 = t551;
    t498 = n553_0;
    t499 = n553_1;
    goto tail_start_kl_shen_2estring_2dprefix_3f_14;
  }
  KLObject* t553 = NULL;
      t500 = t553;
    } else {
  KLObject* t554 = shen_true(ctx);
    if (!shen_is_boolean(ctx, t554))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t554)) {
  KLObject* t555 = shen_false(ctx);
      t500 = t555;
    } else {
      shen_simple_error(ctx, "No true case found for cond");
      t500 = shen_empty_list(ctx);
    }
    }
    }
    }
    }
    }
  }
    return t500;
  }
}

static KLObject* native_kl_shen_2erecursive_2dstring_2dmatch_15 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t556 = objects[0];
    KLObject* t557 = objects[1];
    KLObject* t558 = objects[2];
  tail_start_kl_shen_2erecursive_2dstring_2dmatch_15: ;
  KLObject* t559;
  {
  KLObject* t560 = shen_empty_list(ctx);
  KLObject* t562 = shen_eq(ctx, t560, t558);
    if (!shen_is_boolean(ctx, t562))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t562)) {
  KLObject* t563 = shen_intern(ctx, "shen.skip");
      t559 = t563;
    } else {
  KLObject* t565 = shen_cons_p(ctx, t558);
    if (!shen_is_boolean(ctx, t565))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t565)) {
  KLObject* t570 = shen_hd(ctx, t558);
  KLObject* t567;
  {
    KLObject* a567[] = {t557, t570};
    t567 = shen_apply_direct(ctx, "shen.string-prefix?", 2, a567);
  }
  KLObject* t566;
  if (!shen_is_boolean(ctx, t567))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t567)) {
  KLObject* t575 = shen_string(ctx, ". ");
  KLObject* t578 = shen_hd(ctx, t558);
  KLObject* t579 = shen_string(ctx, "\n");
  KLObject* t580 = shen_intern(ctx, "shen.a");
  KLObject* t576;
  {
    KLObject* a576[] = {t578, t579, t580};
    t576 = shen_apply_direct(ctx, "shen.app", 3, a576);
  }
  KLObject* t574;
  {
    KLObject* a574[] = {t575, t576};
    t574 = shen_apply_direct(ctx, "cn", 2, a574);
  }
  KLObject* t581 = shen_intern(ctx, "shen.a");
  KLObject* t572;
  {
    KLObject* a572[] = {t556, t574, t581};
    t572 = shen_apply_direct(ctx, "shen.app", 3, a572);
  }
  KLObject* t582 = shen_apply_direct(ctx, "stoutput", 0, NULL);
  KLObject* t571;
  {
    KLObject* a571[] = {t572, t582};
    t571 = shen_apply_direct(ctx, "pr", 2, a571);
  }
    t566 = t571;
  } else {
  KLObject* t583 = shen_intern(ctx, "shen.skip");
    t566 = t583;
  }
  KLObject* t585 = shen_number_l(ctx, 1);
  KLObject* t586 = shen_add(ctx, t556, t585);
  KLObject* t589 = shen_tl(ctx, t558);
  {
    KLObject* n590_0 = t586;
    KLObject* n590_1 = t557;
    KLObject* n590_2 = t589;
    t556 = n590_0;
    t557 = n590_1;
    t558 = n590_2;
    goto tail_start_kl_shen_2erecursive_2dstring_2dmatch_15;
  }
  KLObject* t590 = NULL;
      t559 = t590;
    } else {
  KLObject* t591 = shen_true(ctx);
    if (!shen_is_boolean(ctx, t591))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t591)) {
  KLObject* t593 = shen_string(ctx, "implementation error in shen.recursive-string-match");
  KLObject* t592;
  {
    KLObject* a592[] = {t593};
    t592 = shen_tail_apply_direct(ctx, "simple-error", 1, a592);
  }
      t559 = t592;
    } else {
      shen_simple_error(ctx, "No true case found for cond");
      t559 = shen_empty_list(ctx);
    }
    }
    }
  }
    return t559;
  }
}

void shen_kernel_aot_install_toplevel (shen_context* ctx)
{
  shen_register_defun(ctx, "shen.shen", 0, &native_kl_shen_2eshen_0);
  shen_register_defun(ctx, "shen.loop", 0, &native_kl_shen_2eloop_1);
  shen_register_defun(ctx, "shen.credits", 0, &native_kl_shen_2ecredits_2);
  shen_register_defun(ctx, "shen.initialise_environment", 0, &native_kl_shen_2einitialise_5fenvironment_3);
  shen_register_defun(ctx, "shen.prompt", 0, &native_kl_shen_2eprompt_4);
  shen_register_defun(ctx, "shen.read-evaluate-print", 0, &native_kl_shen_2eread_2devaluate_2dprint_5);
  shen_register_defun(ctx, "shen.package-user-input", 2, &native_kl_shen_2epackage_2duser_2dinput_6);
  shen_register_defun(ctx, "shen.pui-h", 3, &native_kl_shen_2epui_2dh_7);
  shen_register_defun(ctx, "shen.update-history", 0, &native_kl_shen_2eupdate_2dhistory_8);
  shen_register_defun(ctx, "shen.trim-it", 1, &native_kl_shen_2etrim_2dit_9);
  shen_register_defun(ctx, "shen.evaluate-lineread", 3, &native_kl_shen_2eevaluate_2dlineread_10);
  shen_register_defun(ctx, "shen.use-history", 3, &native_kl_shen_2euse_2dhistory_11);
  shen_register_defun(ctx, "shen.peek-history", 3, &native_kl_shen_2epeek_2dhistory_12);
  shen_register_defun(ctx, "shen.string-match", 2, &native_kl_shen_2estring_2dmatch_13);
  shen_register_defun(ctx, "shen.string-prefix?", 2, &native_kl_shen_2estring_2dprefix_3f_14);
  shen_register_defun(ctx, "shen.recursive-string-match", 3, &native_kl_shen_2erecursive_2dstring_2dmatch_15);
}
