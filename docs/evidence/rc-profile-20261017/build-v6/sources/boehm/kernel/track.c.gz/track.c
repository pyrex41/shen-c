#include "rc_phase_profile.h"
/* Generated always-AOT kernel module (KL defuns -> NativeFunctions).
 * Install after tree-walker boot overwrites UserFunctions.
 * Toplevel declare/set stay on the walker. Not overlay-after-load.
 * Sidecar tests stay on the tree-walker. Not a second main. Source: track.kl
 */
#include "abi.h"

void shen_kernel_aot_install_track (shen_context* ctx);

static KLObject* trap_body_0 (void* data)
{
  shen_context* ctx = &shen_root_context;
  Vector* env = (Vector*)data;
  KLObject* t490 = shen_vector_get(ctx, env, 0);
  KLObject* t492;
  {
    KLObject* a492[] = {t490};
    t492 = shen_apply_direct(ctx, "ps", 1, a492);
  }
  KLObject* t491;
  {
    KLObject* a491[] = {t492};
    t491 = shen_apply_direct(ctx, "eval", 1, a491);
  }
  return t491;
}

static KLObject* lambda_0 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  KLObject* t496 = shen_vector_get(ctx, caps, 0);
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t497 = objects[0];
    return t496;
  }
}

static KLObject* trap_handler_0 (KLObject* exception, void* data)
{
  shen_context* ctx = &shen_root_context;
  Vector* env = (Vector*)data;
  Vector* args;
  KLObject* t494 = shen_vector_get(ctx, env, 0);
  KLObject* t495;
  {
    Vector* caps_0 = shen_vector(ctx, 1);
    shen_vector_set(ctx, caps_0, 0, t494);
    t495 = shen_native_closure(ctx, 1, &lambda_0, caps_0);
  }
  args = shen_vector(ctx, 1);
  shen_vector_set(ctx, args, 0, exception);
  {
    KLObject* t499 = shen_apply(ctx, t495, args);
    return t499;
  }
}

static KLObject* trap_body_1 (void* data)
{
  shen_context* ctx = &shen_root_context;
  Vector* env = (Vector*)data;
  KLObject* t652 = shen_vector_get(ctx, env, 0);
  KLObject* t654;
  {
    KLObject* a654[] = {t652};
    t654 = shen_apply_direct(ctx, "ps", 1, a654);
  }
  KLObject* t653;
  {
    KLObject* a653[] = {t654};
    t653 = shen_apply_direct(ctx, "eval", 1, a653);
  }
  return t653;
}

static KLObject* lambda_1 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  KLObject* t658 = shen_vector_get(ctx, caps, 0);
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t659 = objects[0];
    return t658;
  }
}

static KLObject* trap_handler_1 (KLObject* exception, void* data)
{
  shen_context* ctx = &shen_root_context;
  Vector* env = (Vector*)data;
  Vector* args;
  KLObject* t656 = shen_vector_get(ctx, env, 0);
  KLObject* t657;
  {
    Vector* caps_1 = shen_vector(ctx, 1);
    shen_vector_set(ctx, caps_1, 0, t656);
    t657 = shen_native_closure(ctx, 1, &lambda_1, caps_1);
  }
  args = shen_vector(ctx, 1);
  shen_vector_set(ctx, args, 0, exception);
  {
    KLObject* t661 = shen_apply(ctx, t657, args);
    return t661;
  }
}

static KLObject* trap_body_2 (void* data)
{
  shen_context* ctx = &shen_root_context;
  Vector* env = (Vector*)data;
  KLObject* t744 = shen_vector_get(ctx, env, 0);
  KLObject* t747 = shen_intern(ctx, "profile");
  KLObject* t749 = shen_intern(ctx, "*property-vector*");
  KLObject* t748;
  {
    KLObject* a748[] = {t749};
    t748 = shen_apply_direct(ctx, "value", 1, a748);
  }
  KLObject* t745;
  {
    KLObject* a745[] = {t744, t747, t748};
    t745 = shen_apply_direct(ctx, "get", 3, a745);
  }
  return t745;
}

static KLObject* lambda_2 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t752 = objects[0];
  KLObject* t753 = shen_number_l(ctx, 0);
    return t753;
  }
}

static KLObject* trap_handler_2 (KLObject* exception, void* data)
{
  shen_context* ctx = &shen_root_context;
  Vector* env = (Vector*)data;
  Vector* args;
  KLObject* t750 = shen_vector_get(ctx, env, 0);
  KLObject* t751;
  {
    Vector* caps_2 = shen_vector(ctx, 0);
    t751 = shen_native_closure(ctx, 1, &lambda_2, caps_2);
  }
  args = shen_vector(ctx, 1);
  shen_vector_set(ctx, args, 0, exception);
  {
    KLObject* t754 = shen_apply(ctx, t751, args);
    return t754;
  }
}

static KLObject* native_kl_shen_2ef_2derror_0 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t0 = objects[0];
  tail_start_kl_shen_2ef_2derror_0: ;
  KLObject* t3 = shen_string(ctx, "partial function ");
  KLObject* t6 = shen_string(ctx, ";\n");
  KLObject* t7 = shen_intern(ctx, "shen.a");
  KLObject* t4;
  {
    KLObject* a4[] = {t0, t6, t7};
    t4 = shen_apply_direct(ctx, "shen.app", 3, a4);
  }
  KLObject* t2;
  {
    KLObject* a2[] = {t3, t4};
    t2 = shen_apply_direct(ctx, "cn", 2, a2);
  }
  KLObject* t8 = shen_apply_direct(ctx, "stoutput", 0, NULL);
  KLObject* t1;
  {
    KLObject* a1[] = {t2, t8};
    t1 = shen_apply_direct(ctx, "pr", 2, a1);
  }
  KLObject* t12;
  {
    KLObject* a12[] = {t0};
    t12 = shen_apply_direct(ctx, "shen.tracked?", 1, a12);
  }
  KLObject* t11;
  {
    KLObject* a11[] = {t12};
    t11 = shen_apply_direct(ctx, "not", 1, a11);
  }
  KLObject* t10;
  if (!shen_is_boolean(ctx, t11))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t11)) {
    t10 = t11;
  } else {
  KLObject* t16 = shen_string(ctx, "track ");
  KLObject* t19 = shen_string(ctx, "? ");
  KLObject* t20 = shen_intern(ctx, "shen.a");
  KLObject* t17;
  {
    KLObject* a17[] = {t0, t19, t20};
    t17 = shen_apply_direct(ctx, "shen.app", 3, a17);
  }
  KLObject* t15;
  {
    KLObject* a15[] = {t16, t17};
    t15 = shen_apply_direct(ctx, "cn", 2, a15);
  }
  KLObject* t14;
  {
    KLObject* a14[] = {t15};
    t14 = shen_apply_direct(ctx, "y-or-n?", 1, a14);
  }
    if (!shen_is_boolean(ctx, t14))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t10 = t14;
  }
  KLObject* t9;
  if (!shen_is_boolean(ctx, t10))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t10)) {
  KLObject* t22;
  {
    KLObject* a22[] = {t0};
    t22 = shen_apply_direct(ctx, "ps", 1, a22);
  }
  KLObject* t21;
  {
    KLObject* a21[] = {t22};
    t21 = shen_apply_direct(ctx, "shen.track-function", 1, a21);
  }
    t9 = t21;
  } else {
  KLObject* t24 = shen_intern(ctx, "shen.ok");
    t9 = t24;
  }
  KLObject* t26 = shen_string(ctx, "aborted");
  KLObject* t25;
  {
    KLObject* a25[] = {t26};
    t25 = shen_tail_apply_direct(ctx, "simple-error", 1, a25);
  }
    return t25;
  }
}

static KLObject* native_kl_shen_2etracked_3f_1 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t27 = objects[0];
  tail_start_kl_shen_2etracked_3f_1: ;
  KLObject* t31 = shen_intern(ctx, "shen.*tracking*");
  KLObject* t30;
  {
    KLObject* a30[] = {t31};
    t30 = shen_apply_direct(ctx, "value", 1, a30);
  }
  KLObject* t28;
  {
    KLObject* a28[] = {t27, t30};
    t28 = shen_tail_apply_direct(ctx, "element?", 2, a28);
  }
    return t28;
  }
}

static KLObject* native_kl_track_2 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t32 = objects[0];
  tail_start_kl_track_2: ;
  KLObject* t33;
  {
    KLObject* a33[] = {t32};
    t33 = shen_apply_direct(ctx, "ps", 1, a33);
  }
  KLObject* t35;
  {
    KLObject* a35[] = {t33};
    t35 = shen_tail_apply_direct(ctx, "shen.track-function", 1, a35);
  }
    return t35;
  }
}

static KLObject* native_kl_shen_2etrack_2dfunction_3 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t37 = objects[0];
  tail_start_kl_shen_2etrack_2dfunction_3: ;
  KLObject* t38;
  {
  KLObject* t41 = shen_cons_p(ctx, t37);
  KLObject* t39;
  if (!shen_is_boolean(ctx, t41))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t41)) {
    t39 = t41;
  } else {
  KLObject* t43 = shen_intern(ctx, "defun");
  KLObject* t45 = shen_hd(ctx, t37);
  KLObject* t46 = shen_eq(ctx, t43, t45);
  KLObject* t42;
  if (!shen_is_boolean(ctx, t46))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t46)) {
    t42 = t46;
  } else {
  KLObject* t49 = shen_tl(ctx, t37);
  KLObject* t50 = shen_cons_p(ctx, t49);
  KLObject* t47;
  if (!shen_is_boolean(ctx, t50))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t50)) {
    t47 = t50;
  } else {
  KLObject* t53 = shen_tl(ctx, t37);
  KLObject* t54 = shen_tl(ctx, t53);
  KLObject* t55 = shen_cons_p(ctx, t54);
  KLObject* t51;
  if (!shen_is_boolean(ctx, t55))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t55)) {
    t51 = t55;
  } else {
  KLObject* t58 = shen_tl(ctx, t37);
  KLObject* t59 = shen_tl(ctx, t58);
  KLObject* t60 = shen_tl(ctx, t59);
  KLObject* t61 = shen_cons_p(ctx, t60);
  KLObject* t56;
  if (!shen_is_boolean(ctx, t61))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t61)) {
    t56 = t61;
  } else {
  KLObject* t62 = shen_empty_list(ctx);
  KLObject* t64 = shen_tl(ctx, t37);
  KLObject* t65 = shen_tl(ctx, t64);
  KLObject* t66 = shen_tl(ctx, t65);
  KLObject* t67 = shen_tl(ctx, t66);
  KLObject* t68 = shen_eq(ctx, t62, t67);
    if (!shen_is_boolean(ctx, t68))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t56 = t68;
  }
    if (!shen_is_boolean(ctx, t56))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t51 = t56;
  }
    if (!shen_is_boolean(ctx, t51))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t47 = t51;
  }
    if (!shen_is_boolean(ctx, t47))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t42 = t47;
  }
    if (!shen_is_boolean(ctx, t42))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t39 = t42;
  }
    if (!shen_is_boolean(ctx, t39))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t39)) {
  KLObject* t69 = shen_intern(ctx, "defun");
  KLObject* t71 = shen_tl(ctx, t37);
  KLObject* t72 = shen_hd(ctx, t71);
  KLObject* t74 = shen_tl(ctx, t37);
  KLObject* t75 = shen_tl(ctx, t74);
  KLObject* t76 = shen_hd(ctx, t75);
  KLObject* t79 = shen_tl(ctx, t37);
  KLObject* t80 = shen_hd(ctx, t79);
  KLObject* t82 = shen_tl(ctx, t37);
  KLObject* t83 = shen_tl(ctx, t82);
  KLObject* t84 = shen_hd(ctx, t83);
  KLObject* t86 = shen_tl(ctx, t37);
  KLObject* t87 = shen_tl(ctx, t86);
  KLObject* t88 = shen_tl(ctx, t87);
  KLObject* t89 = shen_hd(ctx, t88);
  KLObject* t77;
  {
    KLObject* a77[] = {t80, t84, t89};
    t77 = shen_apply_direct(ctx, "shen.insert-tracking-code", 3, a77);
  }
  KLObject* t90 = shen_empty_list(ctx);
  KLObject* t91 = shen_cons(ctx, t77, t90);
  KLObject* t92 = shen_cons(ctx, t76, t91);
  KLObject* t93 = shen_cons(ctx, t72, t92);
  KLObject* t94 = shen_cons(ctx, t69, t93);
  KLObject* t96 = shen_eval_kl(ctx, t94);
  KLObject* t98 = shen_intern(ctx, "shen.*tracking*");
  KLObject* t101 = shen_tl(ctx, t37);
  KLObject* t102 = shen_hd(ctx, t101);
  KLObject* t104 = shen_intern(ctx, "shen.*tracking*");
  KLObject* t103;
  {
    KLObject* a103[] = {t104};
    t103 = shen_apply_direct(ctx, "value", 1, a103);
  }
  KLObject* t99;
  {
    KLObject* a99[] = {t102, t103};
    t99 = shen_apply_direct(ctx, "adjoin", 2, a99);
  }
  KLObject* t97;
  {
    KLObject* a97[] = {t98, t99};
    t97 = shen_apply_direct(ctx, "set", 2, a97);
  }
  KLObject* t106 = shen_tl(ctx, t37);
  KLObject* t107 = shen_hd(ctx, t106);
      t38 = t107;
    } else {
  KLObject* t108 = shen_true(ctx);
    if (!shen_is_boolean(ctx, t108))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t108)) {
  KLObject* t110 = shen_string(ctx, "implementation error in shen.track-function");
  KLObject* t109;
  {
    KLObject* a109[] = {t110};
    t109 = shen_tail_apply_direct(ctx, "simple-error", 1, a109);
  }
      t38 = t109;
    } else {
      shen_simple_error(ctx, "No true case found for cond");
      t38 = shen_empty_list(ctx);
    }
    }
  }
    return t38;
  }
}

static KLObject* native_kl_shen_2einsert_2dtracking_2dcode_4 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t111 = objects[0];
    KLObject* t112 = objects[1];
    KLObject* t113 = objects[2];
  tail_start_kl_shen_2einsert_2dtracking_2dcode_4: ;
  KLObject* t114 = shen_intern(ctx, "do");
  KLObject* t115 = shen_intern(ctx, "set");
  KLObject* t116 = shen_intern(ctx, "shen.*call*");
  KLObject* t117 = shen_intern(ctx, "+");
  KLObject* t118 = shen_intern(ctx, "value");
  KLObject* t119 = shen_intern(ctx, "shen.*call*");
  KLObject* t120 = shen_empty_list(ctx);
  KLObject* t121 = shen_cons(ctx, t119, t120);
  KLObject* t122 = shen_cons(ctx, t118, t121);
  KLObject* t123 = shen_number_l(ctx, 1);
  KLObject* t124 = shen_empty_list(ctx);
  KLObject* t125 = shen_cons(ctx, t123, t124);
  KLObject* t126 = shen_cons(ctx, t122, t125);
  KLObject* t127 = shen_cons(ctx, t117, t126);
  KLObject* t128 = shen_empty_list(ctx);
  KLObject* t129 = shen_cons(ctx, t127, t128);
  KLObject* t130 = shen_cons(ctx, t116, t129);
  KLObject* t131 = shen_cons(ctx, t115, t130);
  KLObject* t132 = shen_intern(ctx, "do");
  KLObject* t133 = shen_intern(ctx, "shen.input-track");
  KLObject* t134 = shen_intern(ctx, "value");
  KLObject* t135 = shen_intern(ctx, "shen.*call*");
  KLObject* t136 = shen_empty_list(ctx);
  KLObject* t137 = shen_cons(ctx, t135, t136);
  KLObject* t138 = shen_cons(ctx, t134, t137);
  KLObject* t141;
  {
    KLObject* a141[] = {t113, t112};
    t141 = shen_apply_direct(ctx, "shen.prolog-track", 2, a141);
  }
  KLObject* t140;
  {
    KLObject* a140[] = {t141};
    t140 = shen_apply_direct(ctx, "shen.cons-form", 1, a140);
  }
  KLObject* t144 = shen_empty_list(ctx);
  KLObject* t145 = shen_cons(ctx, t140, t144);
  KLObject* t146 = shen_cons(ctx, t111, t145);
  KLObject* t147 = shen_cons(ctx, t138, t146);
  KLObject* t148 = shen_cons(ctx, t133, t147);
  KLObject* t149 = shen_intern(ctx, "do");
  KLObject* t150 = shen_intern(ctx, "shen.terpri-or-read-char");
  KLObject* t151 = shen_empty_list(ctx);
  KLObject* t152 = shen_cons(ctx, t150, t151);
  KLObject* t153 = shen_intern(ctx, "let");
  KLObject* t154 = shen_intern(ctx, "Result");
  KLObject* t156 = shen_intern(ctx, "do");
  KLObject* t157 = shen_intern(ctx, "shen.output-track");
  KLObject* t158 = shen_intern(ctx, "value");
  KLObject* t159 = shen_intern(ctx, "shen.*call*");
  KLObject* t160 = shen_empty_list(ctx);
  KLObject* t161 = shen_cons(ctx, t159, t160);
  KLObject* t162 = shen_cons(ctx, t158, t161);
  KLObject* t164 = shen_intern(ctx, "Result");
  KLObject* t165 = shen_empty_list(ctx);
  KLObject* t166 = shen_cons(ctx, t164, t165);
  KLObject* t167 = shen_cons(ctx, t111, t166);
  KLObject* t168 = shen_cons(ctx, t162, t167);
  KLObject* t169 = shen_cons(ctx, t157, t168);
  KLObject* t170 = shen_intern(ctx, "do");
  KLObject* t171 = shen_intern(ctx, "set");
  KLObject* t172 = shen_intern(ctx, "shen.*call*");
  KLObject* t173 = shen_intern(ctx, "-");
  KLObject* t174 = shen_intern(ctx, "value");
  KLObject* t175 = shen_intern(ctx, "shen.*call*");
  KLObject* t176 = shen_empty_list(ctx);
  KLObject* t177 = shen_cons(ctx, t175, t176);
  KLObject* t178 = shen_cons(ctx, t174, t177);
  KLObject* t179 = shen_number_l(ctx, 1);
  KLObject* t180 = shen_empty_list(ctx);
  KLObject* t181 = shen_cons(ctx, t179, t180);
  KLObject* t182 = shen_cons(ctx, t178, t181);
  KLObject* t183 = shen_cons(ctx, t173, t182);
  KLObject* t184 = shen_empty_list(ctx);
  KLObject* t185 = shen_cons(ctx, t183, t184);
  KLObject* t186 = shen_cons(ctx, t172, t185);
  KLObject* t187 = shen_cons(ctx, t171, t186);
  KLObject* t188 = shen_intern(ctx, "do");
  KLObject* t189 = shen_intern(ctx, "shen.terpri-or-read-char");
  KLObject* t190 = shen_empty_list(ctx);
  KLObject* t191 = shen_cons(ctx, t189, t190);
  KLObject* t192 = shen_intern(ctx, "Result");
  KLObject* t193 = shen_empty_list(ctx);
  KLObject* t194 = shen_cons(ctx, t192, t193);
  KLObject* t195 = shen_cons(ctx, t191, t194);
  KLObject* t196 = shen_cons(ctx, t188, t195);
  KLObject* t197 = shen_empty_list(ctx);
  KLObject* t198 = shen_cons(ctx, t196, t197);
  KLObject* t199 = shen_cons(ctx, t187, t198);
  KLObject* t200 = shen_cons(ctx, t170, t199);
  KLObject* t201 = shen_empty_list(ctx);
  KLObject* t202 = shen_cons(ctx, t200, t201);
  KLObject* t203 = shen_cons(ctx, t169, t202);
  KLObject* t204 = shen_cons(ctx, t156, t203);
  KLObject* t205 = shen_empty_list(ctx);
  KLObject* t206 = shen_cons(ctx, t204, t205);
  KLObject* t207 = shen_cons(ctx, t113, t206);
  KLObject* t208 = shen_cons(ctx, t154, t207);
  KLObject* t209 = shen_cons(ctx, t153, t208);
  KLObject* t210 = shen_empty_list(ctx);
  KLObject* t211 = shen_cons(ctx, t209, t210);
  KLObject* t212 = shen_cons(ctx, t152, t211);
  KLObject* t213 = shen_cons(ctx, t149, t212);
  KLObject* t214 = shen_empty_list(ctx);
  KLObject* t215 = shen_cons(ctx, t213, t214);
  KLObject* t216 = shen_cons(ctx, t148, t215);
  KLObject* t217 = shen_cons(ctx, t132, t216);
  KLObject* t218 = shen_empty_list(ctx);
  KLObject* t219 = shen_cons(ctx, t217, t218);
  KLObject* t220 = shen_cons(ctx, t131, t219);
  KLObject* t221 = shen_cons(ctx, t114, t220);
    return t221;
  }
}

static KLObject* native_kl_shen_2eprolog_2dtrack_5 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t222 = objects[0];
    KLObject* t223 = objects[1];
  tail_start_kl_shen_2eprolog_2dtrack_5: ;
  KLObject* t224;
  {
  KLObject* t226 = shen_intern(ctx, "shen.incinfs");
  KLObject* t225;
  {
    KLObject* a225[] = {t226, t222};
    t225 = shen_apply_direct(ctx, "occurrences", 2, a225);
  }
  KLObject* t228 = shen_number_l(ctx, 0);
  KLObject* t229 = shen_eq(ctx, t225, t228);
    if (!shen_is_boolean(ctx, t229))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t229)) {
      t224 = t223;
    } else {
  KLObject* t231 = shen_true(ctx);
    if (!shen_is_boolean(ctx, t231))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t231)) {
  KLObject* t234;
  {
    KLObject* a234[] = {t223};
    t234 = shen_apply_direct(ctx, "shen.vector-parameter", 1, a234);
  }
  KLObject* t232;
  {
    KLObject* a232[] = {t223, t234};
    t232 = shen_tail_apply_direct(ctx, "shen.vector-dereference", 2, a232);
  }
      t224 = t232;
    } else {
      shen_simple_error(ctx, "No true case found for cond");
      t224 = shen_empty_list(ctx);
    }
    }
  }
    return t224;
  }
}

static KLObject* native_kl_shen_2evector_2dparameter_6 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t236 = objects[0];
  tail_start_kl_shen_2evector_2dparameter_6: ;
  KLObject* t237;
  {
  KLObject* t238 = shen_empty_list(ctx);
  KLObject* t240 = shen_eq(ctx, t238, t236);
    if (!shen_is_boolean(ctx, t240))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t240)) {
  KLObject* t241 = shen_empty_list(ctx);
      t237 = t241;
    } else {
  KLObject* t244 = shen_cons_p(ctx, t236);
  KLObject* t242;
  if (!shen_is_boolean(ctx, t244))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t244)) {
    t242 = t244;
  } else {
  KLObject* t247 = shen_tl(ctx, t236);
  KLObject* t248 = shen_cons_p(ctx, t247);
  KLObject* t245;
  if (!shen_is_boolean(ctx, t248))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t248)) {
    t245 = t248;
  } else {
  KLObject* t251 = shen_tl(ctx, t236);
  KLObject* t252 = shen_tl(ctx, t251);
  KLObject* t253 = shen_cons_p(ctx, t252);
  KLObject* t249;
  if (!shen_is_boolean(ctx, t253))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t253)) {
    t249 = t253;
  } else {
  KLObject* t256 = shen_tl(ctx, t236);
  KLObject* t257 = shen_tl(ctx, t256);
  KLObject* t258 = shen_tl(ctx, t257);
  KLObject* t259 = shen_cons_p(ctx, t258);
  KLObject* t254;
  if (!shen_is_boolean(ctx, t259))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t259)) {
    t254 = t259;
  } else {
  KLObject* t260 = shen_empty_list(ctx);
  KLObject* t262 = shen_tl(ctx, t236);
  KLObject* t263 = shen_tl(ctx, t262);
  KLObject* t264 = shen_tl(ctx, t263);
  KLObject* t265 = shen_tl(ctx, t264);
  KLObject* t266 = shen_eq(ctx, t260, t265);
    if (!shen_is_boolean(ctx, t266))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t254 = t266;
  }
    if (!shen_is_boolean(ctx, t254))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t249 = t254;
  }
    if (!shen_is_boolean(ctx, t249))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t245 = t249;
  }
    if (!shen_is_boolean(ctx, t245))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t242 = t245;
  }
    if (!shen_is_boolean(ctx, t242))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t242)) {
  KLObject* t268 = shen_hd(ctx, t236);
      t237 = t268;
    } else {
  KLObject* t270 = shen_cons_p(ctx, t236);
    if (!shen_is_boolean(ctx, t270))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t270)) {
  KLObject* t272 = shen_tl(ctx, t236);
  {
    KLObject* n273_0 = t272;
    t236 = n273_0;
    goto tail_start_kl_shen_2evector_2dparameter_6;
  }
  KLObject* t273 = NULL;
      t237 = t273;
    } else {
  KLObject* t274 = shen_true(ctx);
    if (!shen_is_boolean(ctx, t274))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t274)) {
  KLObject* t276 = shen_string(ctx, "partial function shen.vector-parameter");
  KLObject* t275;
  {
    KLObject* a275[] = {t276};
    t275 = shen_tail_apply_direct(ctx, "simple-error", 1, a275);
  }
      t237 = t275;
    } else {
      shen_simple_error(ctx, "No true case found for cond");
      t237 = shen_empty_list(ctx);
    }
    }
    }
    }
  }
    return t237;
  }
}

static KLObject* native_kl_shen_2evector_2ddereference_7 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t277 = objects[0];
    KLObject* t278 = objects[1];
  tail_start_kl_shen_2evector_2ddereference_7: ;
  KLObject* t279;
  {
  KLObject* t280 = shen_empty_list(ctx);
  KLObject* t282 = shen_eq(ctx, t280, t278);
    if (!shen_is_boolean(ctx, t282))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t282)) {
      t279 = t277;
    } else {
  KLObject* t286 = shen_cons_p(ctx, t277);
  KLObject* t284;
  if (!shen_is_boolean(ctx, t286))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t286)) {
    t284 = t286;
  } else {
  KLObject* t289 = shen_tl(ctx, t277);
  KLObject* t290 = shen_cons_p(ctx, t289);
  KLObject* t287;
  if (!shen_is_boolean(ctx, t290))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t290)) {
    t287 = t290;
  } else {
  KLObject* t293 = shen_tl(ctx, t277);
  KLObject* t294 = shen_tl(ctx, t293);
  KLObject* t295 = shen_cons_p(ctx, t294);
  KLObject* t291;
  if (!shen_is_boolean(ctx, t295))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t295)) {
    t291 = t295;
  } else {
  KLObject* t298 = shen_tl(ctx, t277);
  KLObject* t299 = shen_tl(ctx, t298);
  KLObject* t300 = shen_tl(ctx, t299);
  KLObject* t301 = shen_cons_p(ctx, t300);
  KLObject* t296;
  if (!shen_is_boolean(ctx, t301))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t301)) {
    t296 = t301;
  } else {
  KLObject* t302 = shen_empty_list(ctx);
  KLObject* t304 = shen_tl(ctx, t277);
  KLObject* t305 = shen_tl(ctx, t304);
  KLObject* t306 = shen_tl(ctx, t305);
  KLObject* t307 = shen_tl(ctx, t306);
  KLObject* t308 = shen_eq(ctx, t302, t307);
    if (!shen_is_boolean(ctx, t308))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t296 = t308;
  }
    if (!shen_is_boolean(ctx, t296))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t291 = t296;
  }
    if (!shen_is_boolean(ctx, t291))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t287 = t291;
  }
    if (!shen_is_boolean(ctx, t287))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t284 = t287;
  }
    if (!shen_is_boolean(ctx, t284))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t284)) {
      t279 = t277;
    } else {
  KLObject* t311 = shen_cons_p(ctx, t277);
    if (!shen_is_boolean(ctx, t311))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t311)) {
  KLObject* t312 = shen_intern(ctx, "shen.deref");
  KLObject* t314 = shen_hd(ctx, t277);
  KLObject* t316 = shen_empty_list(ctx);
  KLObject* t317 = shen_cons(ctx, t278, t316);
  KLObject* t318 = shen_cons(ctx, t314, t317);
  KLObject* t319 = shen_cons(ctx, t312, t318);
  KLObject* t322 = shen_tl(ctx, t277);
  KLObject* t320;
  {
    KLObject* a320[] = {t322, t278};
    t320 = shen_apply_direct(ctx, "shen.vector-dereference", 2, a320);
  }
  KLObject* t324 = shen_cons(ctx, t319, t320);
      t279 = t324;
    } else {
  KLObject* t325 = shen_true(ctx);
    if (!shen_is_boolean(ctx, t325))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t325)) {
  KLObject* t327 = shen_string(ctx, "partial function shen.vector-dereference");
  KLObject* t326;
  {
    KLObject* a326[] = {t327};
    t326 = shen_tail_apply_direct(ctx, "simple-error", 1, a326);
  }
      t279 = t326;
    } else {
      shen_simple_error(ctx, "No true case found for cond");
      t279 = shen_empty_list(ctx);
    }
    }
    }
    }
  }
    return t279;
  }
}

static KLObject* native_kl_step_8 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t328 = objects[0];
  tail_start_kl_step_8: ;
  KLObject* t329;
  {
  KLObject* t330 = shen_intern(ctx, "+");
  KLObject* t332 = shen_eq(ctx, t330, t328);
    if (!shen_is_boolean(ctx, t332))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t332)) {
  KLObject* t334 = shen_intern(ctx, "shen.*step*");
  KLObject* t335 = shen_true(ctx);
  KLObject* t333;
  {
    KLObject* a333[] = {t334, t335};
    t333 = shen_tail_apply_direct(ctx, "set", 2, a333);
  }
      t329 = t333;
    } else {
  KLObject* t336 = shen_intern(ctx, "-");
  KLObject* t338 = shen_eq(ctx, t336, t328);
    if (!shen_is_boolean(ctx, t338))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t338)) {
  KLObject* t340 = shen_intern(ctx, "shen.*step*");
  KLObject* t341 = shen_false(ctx);
  KLObject* t339;
  {
    KLObject* a339[] = {t340, t341};
    t339 = shen_tail_apply_direct(ctx, "set", 2, a339);
  }
      t329 = t339;
    } else {
  KLObject* t342 = shen_true(ctx);
    if (!shen_is_boolean(ctx, t342))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t342)) {
  KLObject* t344 = shen_string(ctx, "step expects a + or a -.\n");
  KLObject* t343;
  {
    KLObject* a343[] = {t344};
    t343 = shen_tail_apply_direct(ctx, "simple-error", 1, a343);
  }
      t329 = t343;
    } else {
      shen_simple_error(ctx, "No true case found for cond");
      t329 = shen_empty_list(ctx);
    }
    }
    }
  }
    return t329;
  }
}

static KLObject* native_kl_step_3f_9 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  (void)function_object;
  (void)arguments;
  {
  tail_start_kl_step_3f_9: ;
  KLObject* t346 = shen_intern(ctx, "shen.*step*");
  KLObject* t345;
  {
    KLObject* a345[] = {t346};
    t345 = shen_tail_apply_direct(ctx, "value", 1, a345);
  }
    return t345;
  }
}

static KLObject* native_kl_spy_10 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t347 = objects[0];
  tail_start_kl_spy_10: ;
  KLObject* t348;
  {
  KLObject* t349 = shen_intern(ctx, "+");
  KLObject* t351 = shen_eq(ctx, t349, t347);
    if (!shen_is_boolean(ctx, t351))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t351)) {
  KLObject* t353 = shen_intern(ctx, "shen.*spy*");
  KLObject* t354 = shen_true(ctx);
  KLObject* t352;
  {
    KLObject* a352[] = {t353, t354};
    t352 = shen_tail_apply_direct(ctx, "set", 2, a352);
  }
      t348 = t352;
    } else {
  KLObject* t355 = shen_intern(ctx, "-");
  KLObject* t357 = shen_eq(ctx, t355, t347);
    if (!shen_is_boolean(ctx, t357))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t357)) {
  KLObject* t359 = shen_intern(ctx, "shen.*spy*");
  KLObject* t360 = shen_false(ctx);
  KLObject* t358;
  {
    KLObject* a358[] = {t359, t360};
    t358 = shen_tail_apply_direct(ctx, "set", 2, a358);
  }
      t348 = t358;
    } else {
  KLObject* t361 = shen_true(ctx);
    if (!shen_is_boolean(ctx, t361))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t361)) {
  KLObject* t363 = shen_string(ctx, "spy expects a + or a -.\n");
  KLObject* t362;
  {
    KLObject* a362[] = {t363};
    t362 = shen_tail_apply_direct(ctx, "simple-error", 1, a362);
  }
      t348 = t362;
    } else {
      shen_simple_error(ctx, "No true case found for cond");
      t348 = shen_empty_list(ctx);
    }
    }
    }
  }
    return t348;
  }
}

static KLObject* native_kl_spy_3f_11 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  (void)function_object;
  (void)arguments;
  {
  tail_start_kl_spy_3f_11: ;
  KLObject* t365 = shen_intern(ctx, "shen.*spy*");
  KLObject* t364;
  {
    KLObject* a364[] = {t365};
    t364 = shen_tail_apply_direct(ctx, "value", 1, a364);
  }
    return t364;
  }
}

static KLObject* native_kl_shen_2eterpri_2dor_2dread_2dchar_12 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  (void)function_object;
  (void)arguments;
  {
  tail_start_kl_shen_2eterpri_2dor_2dread_2dchar_12: ;
  KLObject* t368 = shen_intern(ctx, "shen.*step*");
  KLObject* t367;
  {
    KLObject* a367[] = {t368};
    t367 = shen_apply_direct(ctx, "value", 1, a367);
  }
  KLObject* t366;
  if (!shen_is_boolean(ctx, t367))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t367)) {
  KLObject* t372 = shen_intern(ctx, "*stinput*");
  KLObject* t371;
  {
    KLObject* a371[] = {t372};
    t371 = shen_apply_direct(ctx, "value", 1, a371);
  }
  KLObject* t370;
  {
    KLObject* a370[] = {t371};
    t370 = shen_apply_direct(ctx, "read-byte", 1, a370);
  }
  KLObject* t369;
  {
    KLObject* a369[] = {t370};
    t369 = shen_tail_apply_direct(ctx, "shen.check-byte", 1, a369);
  }
    t366 = t369;
  } else {
  KLObject* t374 = shen_number_l(ctx, 1);
  KLObject* t373;
  {
    KLObject* a373[] = {t374};
    t373 = shen_tail_apply_direct(ctx, "nl", 1, a373);
  }
    t366 = t373;
  }
    return t366;
  }
}

static KLObject* native_kl_shen_2echeck_2dbyte_13 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t375 = objects[0];
  tail_start_kl_shen_2echeck_2dbyte_13: ;
  KLObject* t376;
  {
  KLObject* t377 = shen_number_l(ctx, 94);
  KLObject* t379 = shen_eq(ctx, t377, t375);
    if (!shen_is_boolean(ctx, t379))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t379)) {
  KLObject* t381 = shen_string(ctx, "aborted");
  KLObject* t380;
  {
    KLObject* a380[] = {t381};
    t380 = shen_tail_apply_direct(ctx, "simple-error", 1, a380);
  }
      t376 = t380;
    } else {
  KLObject* t382 = shen_true(ctx);
    if (!shen_is_boolean(ctx, t382))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t382)) {
  KLObject* t383 = shen_true(ctx);
      t376 = t383;
    } else {
      shen_simple_error(ctx, "No true case found for cond");
      t376 = shen_empty_list(ctx);
    }
    }
  }
    return t376;
  }
}

static KLObject* native_kl_shen_2einput_2dtrack_14 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t384 = objects[0];
    KLObject* t385 = objects[1];
    KLObject* t386 = objects[2];
  tail_start_kl_shen_2einput_2dtrack_14: ;
  KLObject* t389 = shen_string(ctx, "\n");
  KLObject* t391;
  {
    KLObject* a391[] = {t384};
    t391 = shen_apply_direct(ctx, "shen.spaces", 1, a391);
  }
  KLObject* t394 = shen_string(ctx, "<");
  KLObject* t398 = shen_string(ctx, "> Inputs to ");
  KLObject* t402 = shen_string(ctx, " \n");
  KLObject* t404;
  {
    KLObject* a404[] = {t384};
    t404 = shen_apply_direct(ctx, "shen.spaces", 1, a404);
  }
  KLObject* t406 = shen_string(ctx, "");
  KLObject* t407 = shen_intern(ctx, "shen.a");
  KLObject* t403;
  {
    KLObject* a403[] = {t404, t406, t407};
    t403 = shen_apply_direct(ctx, "shen.app", 3, a403);
  }
  KLObject* t401;
  {
    KLObject* a401[] = {t402, t403};
    t401 = shen_apply_direct(ctx, "cn", 2, a401);
  }
  KLObject* t408 = shen_intern(ctx, "shen.a");
  KLObject* t399;
  {
    KLObject* a399[] = {t385, t401, t408};
    t399 = shen_apply_direct(ctx, "shen.app", 3, a399);
  }
  KLObject* t397;
  {
    KLObject* a397[] = {t398, t399};
    t397 = shen_apply_direct(ctx, "cn", 2, a397);
  }
  KLObject* t409 = shen_intern(ctx, "shen.a");
  KLObject* t395;
  {
    KLObject* a395[] = {t384, t397, t409};
    t395 = shen_apply_direct(ctx, "shen.app", 3, a395);
  }
  KLObject* t393;
  {
    KLObject* a393[] = {t394, t395};
    t393 = shen_apply_direct(ctx, "cn", 2, a393);
  }
  KLObject* t410 = shen_intern(ctx, "shen.a");
  KLObject* t390;
  {
    KLObject* a390[] = {t391, t393, t410};
    t390 = shen_apply_direct(ctx, "shen.app", 3, a390);
  }
  KLObject* t388;
  {
    KLObject* a388[] = {t389, t390};
    t388 = shen_apply_direct(ctx, "cn", 2, a388);
  }
  KLObject* t411 = shen_apply_direct(ctx, "stoutput", 0, NULL);
  KLObject* t387;
  {
    KLObject* a387[] = {t388, t411};
    t387 = shen_apply_direct(ctx, "pr", 2, a387);
  }
  KLObject* t412;
  {
    KLObject* a412[] = {t386};
    t412 = shen_tail_apply_direct(ctx, "shen.recursively-print", 1, a412);
  }
    return t412;
  }
}

static KLObject* native_kl_shen_2erecursively_2dprint_15 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t414 = objects[0];
  tail_start_kl_shen_2erecursively_2dprint_15: ;
  KLObject* t415;
  {
  KLObject* t416 = shen_empty_list(ctx);
  KLObject* t418 = shen_eq(ctx, t416, t414);
    if (!shen_is_boolean(ctx, t418))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t418)) {
  KLObject* t420 = shen_string(ctx, " ==>");
  KLObject* t421 = shen_apply_direct(ctx, "stoutput", 0, NULL);
  KLObject* t419;
  {
    KLObject* a419[] = {t420, t421};
    t419 = shen_tail_apply_direct(ctx, "pr", 2, a419);
  }
      t415 = t419;
    } else {
  KLObject* t423 = shen_cons_p(ctx, t414);
    if (!shen_is_boolean(ctx, t423))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t423)) {
  KLObject* t426 = shen_hd(ctx, t414);
  KLObject* t424;
  {
    KLObject* a424[] = {t426};
    t424 = shen_apply_direct(ctx, "print", 1, a424);
  }
  KLObject* t428 = shen_string(ctx, ", ");
  KLObject* t429 = shen_apply_direct(ctx, "stoutput", 0, NULL);
  KLObject* t427;
  {
    KLObject* a427[] = {t428, t429};
    t427 = shen_apply_direct(ctx, "pr", 2, a427);
  }
  KLObject* t431 = shen_tl(ctx, t414);
  {
    KLObject* n432_0 = t431;
    t414 = n432_0;
    goto tail_start_kl_shen_2erecursively_2dprint_15;
  }
  KLObject* t432 = NULL;
      t415 = t432;
    } else {
  KLObject* t433 = shen_true(ctx);
    if (!shen_is_boolean(ctx, t433))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t433)) {
  KLObject* t435 = shen_string(ctx, "implementation error in shen.recursively-print");
  KLObject* t434;
  {
    KLObject* a434[] = {t435};
    t434 = shen_tail_apply_direct(ctx, "simple-error", 1, a434);
  }
      t415 = t434;
    } else {
      shen_simple_error(ctx, "No true case found for cond");
      t415 = shen_empty_list(ctx);
    }
    }
    }
  }
    return t415;
  }
}

static KLObject* native_kl_shen_2espaces_16 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t436 = objects[0];
  tail_start_kl_shen_2espaces_16: ;
  KLObject* t437;
  {
  KLObject* t438 = shen_number_l(ctx, 0);
  KLObject* t440 = shen_eq(ctx, t438, t436);
    if (!shen_is_boolean(ctx, t440))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t440)) {
  KLObject* t441 = shen_string(ctx, "");
      t437 = t441;
    } else {
  KLObject* t442 = shen_true(ctx);
    if (!shen_is_boolean(ctx, t442))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t442)) {
  KLObject* t444 = shen_string(ctx, " ");
  KLObject* t447 = shen_number_l(ctx, 1);
  KLObject* t448 = shen_sub(ctx, t436, t447);
  KLObject* t445;
  {
    KLObject* a445[] = {t448};
    t445 = shen_apply_direct(ctx, "shen.spaces", 1, a445);
  }
  KLObject* t443;
  {
    KLObject* a443[] = {t444, t445};
    t443 = shen_tail_apply_direct(ctx, "cn", 2, a443);
  }
      t437 = t443;
    } else {
      shen_simple_error(ctx, "No true case found for cond");
      t437 = shen_empty_list(ctx);
    }
    }
  }
    return t437;
  }
}

static KLObject* native_kl_shen_2eoutput_2dtrack_17 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t449 = objects[0];
    KLObject* t450 = objects[1];
    KLObject* t451 = objects[2];
  tail_start_kl_shen_2eoutput_2dtrack_17: ;
  KLObject* t454 = shen_string(ctx, "\n");
  KLObject* t456;
  {
    KLObject* a456[] = {t449};
    t456 = shen_apply_direct(ctx, "shen.spaces", 1, a456);
  }
  KLObject* t459 = shen_string(ctx, "<");
  KLObject* t463 = shen_string(ctx, "> Output from ");
  KLObject* t467 = shen_string(ctx, " \n");
  KLObject* t469;
  {
    KLObject* a469[] = {t449};
    t469 = shen_apply_direct(ctx, "shen.spaces", 1, a469);
  }
  KLObject* t472 = shen_string(ctx, "==> ");
  KLObject* t475 = shen_string(ctx, "");
  KLObject* t476 = shen_intern(ctx, "shen.s");
  KLObject* t473;
  {
    KLObject* a473[] = {t451, t475, t476};
    t473 = shen_apply_direct(ctx, "shen.app", 3, a473);
  }
  KLObject* t471;
  {
    KLObject* a471[] = {t472, t473};
    t471 = shen_apply_direct(ctx, "cn", 2, a471);
  }
  KLObject* t477 = shen_intern(ctx, "shen.a");
  KLObject* t468;
  {
    KLObject* a468[] = {t469, t471, t477};
    t468 = shen_apply_direct(ctx, "shen.app", 3, a468);
  }
  KLObject* t466;
  {
    KLObject* a466[] = {t467, t468};
    t466 = shen_apply_direct(ctx, "cn", 2, a466);
  }
  KLObject* t478 = shen_intern(ctx, "shen.a");
  KLObject* t464;
  {
    KLObject* a464[] = {t450, t466, t478};
    t464 = shen_apply_direct(ctx, "shen.app", 3, a464);
  }
  KLObject* t462;
  {
    KLObject* a462[] = {t463, t464};
    t462 = shen_apply_direct(ctx, "cn", 2, a462);
  }
  KLObject* t479 = shen_intern(ctx, "shen.a");
  KLObject* t460;
  {
    KLObject* a460[] = {t449, t462, t479};
    t460 = shen_apply_direct(ctx, "shen.app", 3, a460);
  }
  KLObject* t458;
  {
    KLObject* a458[] = {t459, t460};
    t458 = shen_apply_direct(ctx, "cn", 2, a458);
  }
  KLObject* t480 = shen_intern(ctx, "shen.a");
  KLObject* t455;
  {
    KLObject* a455[] = {t456, t458, t480};
    t455 = shen_apply_direct(ctx, "shen.app", 3, a455);
  }
  KLObject* t453;
  {
    KLObject* a453[] = {t454, t455};
    t453 = shen_apply_direct(ctx, "cn", 2, a453);
  }
  KLObject* t481 = shen_apply_direct(ctx, "stoutput", 0, NULL);
  KLObject* t452;
  {
    KLObject* a452[] = {t453, t481};
    t452 = shen_tail_apply_direct(ctx, "pr", 2, a452);
  }
    return t452;
  }
}

static KLObject* native_kl_untrack_18 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t482 = objects[0];
  tail_start_kl_untrack_18: ;
  KLObject* t484 = shen_intern(ctx, "shen.*tracking*");
  KLObject* t488 = shen_intern(ctx, "shen.*tracking*");
  KLObject* t487;
  {
    KLObject* a487[] = {t488};
    t487 = shen_apply_direct(ctx, "value", 1, a487);
  }
  KLObject* t485;
  {
    KLObject* a485[] = {t482, t487};
    t485 = shen_apply_direct(ctx, "remove", 2, a485);
  }
  KLObject* t483;
  {
    KLObject* a483[] = {t484, t485};
    t483 = shen_apply_direct(ctx, "set", 2, a483);
  }
  KLObject* t489;
  {
    Vector* tenv_0 = shen_vector(ctx, 1);
    shen_vector_set(ctx, tenv_0, 0, t482);
    t489 = shen_trap_error(ctx, trap_body_0, trap_handler_0, tenv_0);
  }
    return t482;
  }
}

static KLObject* native_kl_remove_19 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t501 = objects[0];
    KLObject* t502 = objects[1];
  tail_start_kl_remove_19: ;
  KLObject* t506 = shen_empty_list(ctx);
  KLObject* t503;
  {
    KLObject* a503[] = {t501, t502, t506};
    t503 = shen_tail_apply_direct(ctx, "shen.remove-h", 3, a503);
  }
    return t503;
  }
}

static KLObject* native_kl_shen_2eremove_2dh_20 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t507 = objects[0];
    KLObject* t508 = objects[1];
    KLObject* t509 = objects[2];
  tail_start_kl_shen_2eremove_2dh_20: ;
  KLObject* t510;
  {
  KLObject* t511 = shen_empty_list(ctx);
  KLObject* t513 = shen_eq(ctx, t511, t508);
    if (!shen_is_boolean(ctx, t513))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t513)) {
  KLObject* t514;
  {
    KLObject* a514[] = {t509};
    t514 = shen_tail_apply_direct(ctx, "reverse", 1, a514);
  }
      t510 = t514;
    } else {
  KLObject* t518 = shen_cons_p(ctx, t508);
  KLObject* t516;
  if (!shen_is_boolean(ctx, t518))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t518)) {
    t516 = t518;
  } else {
  KLObject* t521 = shen_hd(ctx, t508);
  KLObject* t522 = shen_eq(ctx, t507, t521);
    if (!shen_is_boolean(ctx, t522))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t516 = t522;
  }
    if (!shen_is_boolean(ctx, t516))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t516)) {
  KLObject* t524 = shen_hd(ctx, t508);
  KLObject* t526 = shen_tl(ctx, t508);
  {
    KLObject* n528_0 = t524;
    KLObject* n528_1 = t526;
    KLObject* n528_2 = t509;
    t507 = n528_0;
    t508 = n528_1;
    t509 = n528_2;
    goto tail_start_kl_shen_2eremove_2dh_20;
  }
  KLObject* t528 = NULL;
      t510 = t528;
    } else {
  KLObject* t530 = shen_cons_p(ctx, t508);
    if (!shen_is_boolean(ctx, t530))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t530)) {
  KLObject* t533 = shen_tl(ctx, t508);
  KLObject* t535 = shen_hd(ctx, t508);
  KLObject* t537 = shen_cons(ctx, t535, t509);
  {
    KLObject* n538_0 = t507;
    KLObject* n538_1 = t533;
    KLObject* n538_2 = t537;
    t507 = n538_0;
    t508 = n538_1;
    t509 = n538_2;
    goto tail_start_kl_shen_2eremove_2dh_20;
  }
  KLObject* t538 = NULL;
      t510 = t538;
    } else {
  KLObject* t539 = shen_true(ctx);
    if (!shen_is_boolean(ctx, t539))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t539)) {
  KLObject* t541 = shen_string(ctx, "implementation error in shen.remove-h");
  KLObject* t540;
  {
    KLObject* a540[] = {t541};
    t540 = shen_tail_apply_direct(ctx, "simple-error", 1, a540);
  }
      t510 = t540;
    } else {
      shen_simple_error(ctx, "No true case found for cond");
      t510 = shen_empty_list(ctx);
    }
    }
    }
    }
  }
    return t510;
  }
}

static KLObject* native_kl_profile_21 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t542 = objects[0];
  tail_start_kl_profile_21: ;
  KLObject* t544 = shen_intern(ctx, "shen.*profiled*");
  KLObject* t547 = shen_intern(ctx, "shen.*profiled*");
  KLObject* t546;
  {
    KLObject* a546[] = {t547};
    t546 = shen_apply_direct(ctx, "value", 1, a546);
  }
  KLObject* t548 = shen_cons(ctx, t542, t546);
  KLObject* t543;
  {
    KLObject* a543[] = {t544, t548};
    t543 = shen_apply_direct(ctx, "set", 2, a543);
  }
  KLObject* t550;
  {
    KLObject* a550[] = {t542};
    t550 = shen_apply_direct(ctx, "ps", 1, a550);
  }
  KLObject* t549;
  {
    KLObject* a549[] = {t550};
    t549 = shen_tail_apply_direct(ctx, "shen.profile-help", 1, a549);
  }
    return t549;
  }
}

static KLObject* native_kl_shen_2eprofile_2dhelp_22 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t552 = objects[0];
  tail_start_kl_shen_2eprofile_2dhelp_22: ;
  KLObject* t553;
  {
  KLObject* t556 = shen_cons_p(ctx, t552);
  KLObject* t554;
  if (!shen_is_boolean(ctx, t556))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t556)) {
    t554 = t556;
  } else {
  KLObject* t558 = shen_intern(ctx, "defun");
  KLObject* t560 = shen_hd(ctx, t552);
  KLObject* t561 = shen_eq(ctx, t558, t560);
  KLObject* t557;
  if (!shen_is_boolean(ctx, t561))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t561)) {
    t557 = t561;
  } else {
  KLObject* t564 = shen_tl(ctx, t552);
  KLObject* t565 = shen_cons_p(ctx, t564);
  KLObject* t562;
  if (!shen_is_boolean(ctx, t565))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t565)) {
    t562 = t565;
  } else {
  KLObject* t568 = shen_tl(ctx, t552);
  KLObject* t569 = shen_tl(ctx, t568);
  KLObject* t570 = shen_cons_p(ctx, t569);
  KLObject* t566;
  if (!shen_is_boolean(ctx, t570))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t570)) {
    t566 = t570;
  } else {
  KLObject* t573 = shen_tl(ctx, t552);
  KLObject* t574 = shen_tl(ctx, t573);
  KLObject* t575 = shen_tl(ctx, t574);
  KLObject* t576 = shen_cons_p(ctx, t575);
  KLObject* t571;
  if (!shen_is_boolean(ctx, t576))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t576)) {
    t571 = t576;
  } else {
  KLObject* t577 = shen_empty_list(ctx);
  KLObject* t579 = shen_tl(ctx, t552);
  KLObject* t580 = shen_tl(ctx, t579);
  KLObject* t581 = shen_tl(ctx, t580);
  KLObject* t582 = shen_tl(ctx, t581);
  KLObject* t583 = shen_eq(ctx, t577, t582);
    if (!shen_is_boolean(ctx, t583))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t571 = t583;
  }
    if (!shen_is_boolean(ctx, t571))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t566 = t571;
  }
    if (!shen_is_boolean(ctx, t566))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t562 = t566;
  }
    if (!shen_is_boolean(ctx, t562))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t557 = t562;
  }
    if (!shen_is_boolean(ctx, t557))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t554 = t557;
  }
    if (!shen_is_boolean(ctx, t554))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t554)) {
  KLObject* t585 = shen_intern(ctx, "shen.f");
  KLObject* t584;
  {
    KLObject* a584[] = {t585};
    t584 = shen_apply_direct(ctx, "gensym", 1, a584);
  }
  KLObject* t586 = shen_intern(ctx, "defun");
  KLObject* t588 = shen_tl(ctx, t552);
  KLObject* t589 = shen_hd(ctx, t588);
  KLObject* t591 = shen_tl(ctx, t552);
  KLObject* t592 = shen_tl(ctx, t591);
  KLObject* t593 = shen_hd(ctx, t592);
  KLObject* t596 = shen_tl(ctx, t552);
  KLObject* t597 = shen_hd(ctx, t596);
  KLObject* t599 = shen_tl(ctx, t552);
  KLObject* t600 = shen_tl(ctx, t599);
  KLObject* t601 = shen_hd(ctx, t600);
  KLObject* t604 = shen_tl(ctx, t552);
  KLObject* t605 = shen_tl(ctx, t604);
  KLObject* t606 = shen_hd(ctx, t605);
  KLObject* t607 = shen_cons(ctx, t584, t606);
  KLObject* t594;
  {
    KLObject* a594[] = {t597, t601, t607};
    t594 = shen_apply_direct(ctx, "shen.profile-func", 3, a594);
  }
  KLObject* t608 = shen_empty_list(ctx);
  KLObject* t609 = shen_cons(ctx, t594, t608);
  KLObject* t610 = shen_cons(ctx, t593, t609);
  KLObject* t611 = shen_cons(ctx, t589, t610);
  KLObject* t612 = shen_cons(ctx, t586, t611);
  KLObject* t613 = shen_intern(ctx, "defun");
  KLObject* t616 = shen_tl(ctx, t552);
  KLObject* t617 = shen_tl(ctx, t616);
  KLObject* t618 = shen_hd(ctx, t617);
  KLObject* t622 = shen_tl(ctx, t552);
  KLObject* t623 = shen_hd(ctx, t622);
  KLObject* t625 = shen_tl(ctx, t552);
  KLObject* t626 = shen_tl(ctx, t625);
  KLObject* t627 = shen_tl(ctx, t626);
  KLObject* t628 = shen_hd(ctx, t627);
  KLObject* t619;
  {
    KLObject* a619[] = {t584, t623, t628};
    t619 = shen_apply_direct(ctx, "subst", 3, a619);
  }
  KLObject* t629 = shen_empty_list(ctx);
  KLObject* t630 = shen_cons(ctx, t619, t629);
  KLObject* t631 = shen_cons(ctx, t618, t630);
  KLObject* t632 = shen_cons(ctx, t584, t631);
  KLObject* t633 = shen_cons(ctx, t613, t632);
  KLObject* t635 = shen_eval_kl(ctx, t612);
  KLObject* t637 = shen_eval_kl(ctx, t633);
  KLObject* t639 = shen_tl(ctx, t552);
  KLObject* t640 = shen_hd(ctx, t639);
      t553 = t640;
    } else {
  KLObject* t641 = shen_true(ctx);
    if (!shen_is_boolean(ctx, t641))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t641)) {
  KLObject* t643 = shen_string(ctx, "Cannot profile.\n");
  KLObject* t642;
  {
    KLObject* a642[] = {t643};
    t642 = shen_tail_apply_direct(ctx, "simple-error", 1, a642);
  }
      t553 = t642;
    } else {
      shen_simple_error(ctx, "No true case found for cond");
      t553 = shen_empty_list(ctx);
    }
    }
  }
    return t553;
  }
}

static KLObject* native_kl_unprofile_23 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t644 = objects[0];
  tail_start_kl_unprofile_23: ;
  KLObject* t646 = shen_intern(ctx, "shen.*profiled*");
  KLObject* t650 = shen_intern(ctx, "shen.*profiled*");
  KLObject* t649;
  {
    KLObject* a649[] = {t650};
    t649 = shen_apply_direct(ctx, "value", 1, a649);
  }
  KLObject* t647;
  {
    KLObject* a647[] = {t644, t649};
    t647 = shen_apply_direct(ctx, "remove", 2, a647);
  }
  KLObject* t645;
  {
    KLObject* a645[] = {t646, t647};
    t645 = shen_apply_direct(ctx, "set", 2, a645);
  }
  KLObject* t651;
  {
    Vector* tenv_1 = shen_vector(ctx, 1);
    shen_vector_set(ctx, tenv_1, 0, t644);
    t651 = shen_trap_error(ctx, trap_body_1, trap_handler_1, tenv_1);
  }
    return t651;
  }
}

static KLObject* native_kl_shen_2eprofiled_3f_24 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t662 = objects[0];
  tail_start_kl_shen_2eprofiled_3f_24: ;
  KLObject* t666 = shen_intern(ctx, "shen.*profiled*");
  KLObject* t665;
  {
    KLObject* a665[] = {t666};
    t665 = shen_apply_direct(ctx, "value", 1, a665);
  }
  KLObject* t663;
  {
    KLObject* a663[] = {t662, t665};
    t663 = shen_tail_apply_direct(ctx, "element?", 2, a663);
  }
    return t663;
  }
}

static KLObject* native_kl_shen_2eprofile_2dfunc_25 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t667 = objects[0];
    KLObject* t668 = objects[1];
    KLObject* t669 = objects[2];
  tail_start_kl_shen_2eprofile_2dfunc_25: ;
  KLObject* t670 = shen_intern(ctx, "let");
  KLObject* t671 = shen_intern(ctx, "Start");
  KLObject* t672 = shen_intern(ctx, "get-time");
  KLObject* t673 = shen_intern(ctx, "run");
  KLObject* t674 = shen_empty_list(ctx);
  KLObject* t675 = shen_cons(ctx, t673, t674);
  KLObject* t676 = shen_cons(ctx, t672, t675);
  KLObject* t677 = shen_intern(ctx, "let");
  KLObject* t678 = shen_intern(ctx, "Result");
  KLObject* t680 = shen_intern(ctx, "let");
  KLObject* t681 = shen_intern(ctx, "Finish");
  KLObject* t682 = shen_intern(ctx, "-");
  KLObject* t683 = shen_intern(ctx, "get-time");
  KLObject* t684 = shen_intern(ctx, "run");
  KLObject* t685 = shen_empty_list(ctx);
  KLObject* t686 = shen_cons(ctx, t684, t685);
  KLObject* t687 = shen_cons(ctx, t683, t686);
  KLObject* t688 = shen_intern(ctx, "Start");
  KLObject* t689 = shen_empty_list(ctx);
  KLObject* t690 = shen_cons(ctx, t688, t689);
  KLObject* t691 = shen_cons(ctx, t687, t690);
  KLObject* t692 = shen_cons(ctx, t682, t691);
  KLObject* t693 = shen_intern(ctx, "let");
  KLObject* t694 = shen_intern(ctx, "Record");
  KLObject* t695 = shen_intern(ctx, "shen.put-profile");
  KLObject* t697 = shen_intern(ctx, "+");
  KLObject* t698 = shen_intern(ctx, "shen.get-profile");
  KLObject* t700 = shen_empty_list(ctx);
  KLObject* t701 = shen_cons(ctx, t667, t700);
  KLObject* t702 = shen_cons(ctx, t698, t701);
  KLObject* t703 = shen_intern(ctx, "Finish");
  KLObject* t704 = shen_empty_list(ctx);
  KLObject* t705 = shen_cons(ctx, t703, t704);
  KLObject* t706 = shen_cons(ctx, t702, t705);
  KLObject* t707 = shen_cons(ctx, t697, t706);
  KLObject* t708 = shen_empty_list(ctx);
  KLObject* t709 = shen_cons(ctx, t707, t708);
  KLObject* t710 = shen_cons(ctx, t667, t709);
  KLObject* t711 = shen_cons(ctx, t695, t710);
  KLObject* t712 = shen_intern(ctx, "Result");
  KLObject* t713 = shen_empty_list(ctx);
  KLObject* t714 = shen_cons(ctx, t712, t713);
  KLObject* t715 = shen_cons(ctx, t711, t714);
  KLObject* t716 = shen_cons(ctx, t694, t715);
  KLObject* t717 = shen_cons(ctx, t693, t716);
  KLObject* t718 = shen_empty_list(ctx);
  KLObject* t719 = shen_cons(ctx, t717, t718);
  KLObject* t720 = shen_cons(ctx, t692, t719);
  KLObject* t721 = shen_cons(ctx, t681, t720);
  KLObject* t722 = shen_cons(ctx, t680, t721);
  KLObject* t723 = shen_empty_list(ctx);
  KLObject* t724 = shen_cons(ctx, t722, t723);
  KLObject* t725 = shen_cons(ctx, t669, t724);
  KLObject* t726 = shen_cons(ctx, t678, t725);
  KLObject* t727 = shen_cons(ctx, t677, t726);
  KLObject* t728 = shen_empty_list(ctx);
  KLObject* t729 = shen_cons(ctx, t727, t728);
  KLObject* t730 = shen_cons(ctx, t676, t729);
  KLObject* t731 = shen_cons(ctx, t671, t730);
  KLObject* t732 = shen_cons(ctx, t670, t731);
    return t732;
  }
}

static KLObject* native_kl_profile_2dresults_26 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t733 = objects[0];
  tail_start_kl_profile_2dresults_26: ;
  KLObject* t734;
  {
    KLObject* a734[] = {t733};
    t734 = shen_apply_direct(ctx, "shen.get-profile", 1, a734);
  }
  KLObject* t738 = shen_number_l(ctx, 0);
  KLObject* t736;
  {
    KLObject* a736[] = {t733, t738};
    t736 = shen_apply_direct(ctx, "shen.put-profile", 2, a736);
  }
  KLObject* t739;
  {
    KLObject* a739[] = {t733, t734};
    t739 = shen_tail_apply_direct(ctx, "@p", 2, a739);
  }
    return t739;
  }
}

static KLObject* native_kl_shen_2eget_2dprofile_27 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t742 = objects[0];
  tail_start_kl_shen_2eget_2dprofile_27: ;
  KLObject* t743;
  {
    Vector* tenv_2 = shen_vector(ctx, 1);
    shen_vector_set(ctx, tenv_2, 0, t742);
    t743 = shen_trap_error(ctx, trap_body_2, trap_handler_2, tenv_2);
  }
    return t743;
  }
}

static KLObject* native_kl_shen_2eput_2dprofile_28 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t755 = objects[0];
    KLObject* t756 = objects[1];
  tail_start_kl_shen_2eput_2dprofile_28: ;
  KLObject* t759 = shen_intern(ctx, "profile");
  KLObject* t762 = shen_intern(ctx, "*property-vector*");
  KLObject* t761;
  {
    KLObject* a761[] = {t762};
    t761 = shen_apply_direct(ctx, "value", 1, a761);
  }
  KLObject* t757;
  {
    KLObject* a757[] = {t755, t759, t756, t761};
    t757 = shen_tail_apply_direct(ctx, "put", 4, a757);
  }
    return t757;
  }
}

void shen_kernel_aot_install_track (shen_context* ctx)
{
  shen_register_defun(ctx, "shen.f-error", 1, &native_kl_shen_2ef_2derror_0);
  shen_register_defun(ctx, "shen.tracked?", 1, &native_kl_shen_2etracked_3f_1);
  shen_register_defun(ctx, "track", 1, &native_kl_track_2);
  shen_register_defun(ctx, "shen.track-function", 1, &native_kl_shen_2etrack_2dfunction_3);
  shen_register_defun(ctx, "shen.insert-tracking-code", 3, &native_kl_shen_2einsert_2dtracking_2dcode_4);
  shen_register_defun(ctx, "shen.prolog-track", 2, &native_kl_shen_2eprolog_2dtrack_5);
  shen_register_defun(ctx, "shen.vector-parameter", 1, &native_kl_shen_2evector_2dparameter_6);
  shen_register_defun(ctx, "shen.vector-dereference", 2, &native_kl_shen_2evector_2ddereference_7);
  shen_register_defun(ctx, "step", 1, &native_kl_step_8);
  shen_register_defun(ctx, "step?", 0, &native_kl_step_3f_9);
  shen_register_defun(ctx, "spy", 1, &native_kl_spy_10);
  shen_register_defun(ctx, "spy?", 0, &native_kl_spy_3f_11);
  shen_register_defun(ctx, "shen.terpri-or-read-char", 0, &native_kl_shen_2eterpri_2dor_2dread_2dchar_12);
  shen_register_defun(ctx, "shen.check-byte", 1, &native_kl_shen_2echeck_2dbyte_13);
  shen_register_defun(ctx, "shen.input-track", 3, &native_kl_shen_2einput_2dtrack_14);
  shen_register_defun(ctx, "shen.recursively-print", 1, &native_kl_shen_2erecursively_2dprint_15);
  shen_register_defun(ctx, "shen.spaces", 1, &native_kl_shen_2espaces_16);
  shen_register_defun(ctx, "shen.output-track", 3, &native_kl_shen_2eoutput_2dtrack_17);
  shen_register_defun(ctx, "untrack", 1, &native_kl_untrack_18);
  shen_register_defun(ctx, "remove", 2, &native_kl_remove_19);
  shen_register_defun(ctx, "shen.remove-h", 3, &native_kl_shen_2eremove_2dh_20);
  shen_register_defun(ctx, "profile", 1, &native_kl_profile_21);
  shen_register_defun(ctx, "shen.profile-help", 1, &native_kl_shen_2eprofile_2dhelp_22);
  shen_register_defun(ctx, "unprofile", 1, &native_kl_unprofile_23);
  shen_register_defun(ctx, "shen.profiled?", 1, &native_kl_shen_2eprofiled_3f_24);
  shen_register_defun(ctx, "shen.profile-func", 3, &native_kl_shen_2eprofile_2dfunc_25);
  shen_register_defun(ctx, "profile-results", 1, &native_kl_profile_2dresults_26);
  shen_register_defun(ctx, "shen.get-profile", 1, &native_kl_shen_2eget_2dprofile_27);
  shen_register_defun(ctx, "shen.put-profile", 2, &native_kl_shen_2eput_2dprofile_28);
}
