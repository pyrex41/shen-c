#include "rc_phase_profile.h"
/* Generated always-AOT kernel module (KL defuns -> NativeFunctions).
 * Install after tree-walker boot overwrites UserFunctions.
 * Toplevel declare/set stay on the walker. Not overlay-after-load.
 * Sidecar tests stay on the tree-walker. Not a second main. Source: types.kl
 */
#include "abi.h"

void shen_kernel_aot_install_types (shen_context* ctx);

static KLObject* lambda_3 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  KLObject* t24 = shen_vector_get(ctx, caps, 0);
  KLObject* t25 = shen_vector_get(ctx, caps, 1);
  KLObject* t26 = shen_vector_get(ctx, caps, 2);
  KLObject* t27 = shen_vector_get(ctx, caps, 3);
  KLObject* t28 = shen_vector_get(ctx, caps, 4);
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t29 = objects[0];
  KLObject* t30 = shen_apply_direct(ctx, "shen.incinfs", 0, NULL);
  KLObject* t33;
  {
    KLObject* a33[] = {t24, t25};
    t33 = shen_apply_direct(ctx, "shen.deref", 2, a33);
  }
  KLObject* t32;
  {
    KLObject* a32[] = {t33};
    t32 = shen_apply_direct(ctx, "receive", 1, a32);
  }
  KLObject* t37;
  {
    KLObject* a37[] = {t26, t25};
    t37 = shen_apply_direct(ctx, "shen.deref", 2, a37);
  }
  KLObject* t36;
  {
    KLObject* a36[] = {t37};
    t36 = shen_apply_direct(ctx, "receive", 1, a36);
  }
  KLObject* t31;
  {
    KLObject* a31[] = {t32, t36, t25, t27, t28, t29};
    t31 = shen_tail_apply_direct(ctx, "shen.variancy", 6, a31);
  }
    return t31;
  }
}

static KLObject* lambda_2 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  KLObject* t18 = shen_vector_get(ctx, caps, 0);
  KLObject* t19 = shen_vector_get(ctx, caps, 1);
  KLObject* t20 = shen_vector_get(ctx, caps, 2);
  KLObject* t21 = shen_vector_get(ctx, caps, 3);
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t22 = objects[0];
  KLObject* t23;
  {
    Vector* caps_3 = shen_vector(ctx, 5);
    shen_vector_set(ctx, caps_3, 0, t18);
    shen_vector_set(ctx, caps_3, 1, t19);
    shen_vector_set(ctx, caps_3, 2, t20);
    shen_vector_set(ctx, caps_3, 3, t21);
    shen_vector_set(ctx, caps_3, 4, t22);
    t23 = shen_native_closure(ctx, 1, &lambda_3, caps_3);
  }
    return t23;
  }
}

static KLObject* lambda_1 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  KLObject* t13 = shen_vector_get(ctx, caps, 0);
  KLObject* t14 = shen_vector_get(ctx, caps, 1);
  KLObject* t15 = shen_vector_get(ctx, caps, 2);
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t16 = objects[0];
  KLObject* t17;
  {
    Vector* caps_2 = shen_vector(ctx, 4);
    shen_vector_set(ctx, caps_2, 0, t13);
    shen_vector_set(ctx, caps_2, 1, t14);
    shen_vector_set(ctx, caps_2, 2, t15);
    shen_vector_set(ctx, caps_2, 3, t16);
    t17 = shen_native_closure(ctx, 1, &lambda_2, caps_2);
  }
    return t17;
  }
}

static KLObject* lambda_0 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  KLObject* t9 = shen_vector_get(ctx, caps, 0);
  KLObject* t10 = shen_vector_get(ctx, caps, 1);
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t11 = objects[0];
  KLObject* t12;
  {
    Vector* caps_1 = shen_vector(ctx, 3);
    shen_vector_set(ctx, caps_1, 0, t9);
    shen_vector_set(ctx, caps_1, 1, t11);
    shen_vector_set(ctx, caps_1, 2, t10);
    t12 = shen_native_closure(ctx, 1, &lambda_1, caps_1);
  }
    return t12;
  }
}

static KLObject* lambda_4 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  (void)arguments;
  KLObject* t53 = shen_true(ctx);
    return t53;
}

static KLObject* lambda_8 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  KLObject* t134 = shen_vector_get(ctx, caps, 0);
  KLObject* t135 = shen_vector_get(ctx, caps, 1);
  KLObject* t136 = shen_vector_get(ctx, caps, 2);
  KLObject* t137 = shen_vector_get(ctx, caps, 3);
  KLObject* t138 = shen_vector_get(ctx, caps, 4);
  KLObject* t139 = shen_vector_get(ctx, caps, 5);
  KLObject* t140 = shen_vector_get(ctx, caps, 6);
  (void)arguments;
  KLObject* t141;
  {
    KLObject* a141[] = {t134, t135, t136, t137, t138, t139, t140};
    t141 = shen_tail_apply_direct(ctx, "shen.variants?", 7, a141);
  }
    return t141;
}

static KLObject* lambda_7 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  KLObject* t115 = shen_vector_get(ctx, caps, 0);
  KLObject* t116 = shen_vector_get(ctx, caps, 1);
  KLObject* t117 = shen_vector_get(ctx, caps, 2);
  KLObject* t118 = shen_vector_get(ctx, caps, 3);
  KLObject* t119 = shen_vector_get(ctx, caps, 4);
  KLObject* t120 = shen_vector_get(ctx, caps, 5);
  KLObject* t121 = shen_vector_get(ctx, caps, 6);
  (void)arguments;
  KLObject* t123 = shen_intern(ctx, "fn");
  KLObject* t125 = shen_empty_list(ctx);
  KLObject* t126 = shen_cons(ctx, t115, t125);
  KLObject* t127 = shen_cons(ctx, t123, t126);
  KLObject* t129 = shen_empty_list(ctx);
  KLObject* t133;
  {
    Vector* caps_8 = shen_vector(ctx, 7);
    shen_vector_set(ctx, caps_8, 0, t115);
    shen_vector_set(ctx, caps_8, 1, t120);
    shen_vector_set(ctx, caps_8, 2, t116);
    shen_vector_set(ctx, caps_8, 3, t117);
    shen_vector_set(ctx, caps_8, 4, t118);
    shen_vector_set(ctx, caps_8, 5, t119);
    shen_vector_set(ctx, caps_8, 6, t121);
    t133 = shen_native_closure(ctx, 0, &lambda_8, caps_8);
  }
  KLObject* t122;
  {
    KLObject* a122[] = {t127, t116, t129, t117, t118, t119, t133};
    t122 = shen_tail_apply_direct(ctx, "shen.system-S-h", 7, a122);
  }
    return t122;
}

static KLObject* lambda_6 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  KLObject* t103 = shen_vector_get(ctx, caps, 0);
  KLObject* t104 = shen_vector_get(ctx, caps, 1);
  KLObject* t105 = shen_vector_get(ctx, caps, 2);
  KLObject* t106 = shen_vector_get(ctx, caps, 3);
  KLObject* t107 = shen_vector_get(ctx, caps, 4);
  KLObject* t108 = shen_vector_get(ctx, caps, 5);
  KLObject* t109 = shen_vector_get(ctx, caps, 6);
  (void)arguments;
  KLObject* t114;
  {
    Vector* caps_7 = shen_vector(ctx, 7);
    shen_vector_set(ctx, caps_7, 0, t106);
    shen_vector_set(ctx, caps_7, 1, t107);
    shen_vector_set(ctx, caps_7, 2, t103);
    shen_vector_set(ctx, caps_7, 3, t104);
    shen_vector_set(ctx, caps_7, 4, t105);
    shen_vector_set(ctx, caps_7, 5, t108);
    shen_vector_set(ctx, caps_7, 6, t109);
    t114 = shen_native_closure(ctx, 0, &lambda_7, caps_7);
  }
  KLObject* t110;
  {
    KLObject* a110[] = {t103, t104, t105, t114};
    t110 = shen_tail_apply_direct(ctx, "shen.cut", 4, a110);
  }
    return t110;
}

static KLObject* lambda_5 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  KLObject* t81 = shen_vector_get(ctx, caps, 0);
  KLObject* t82 = shen_vector_get(ctx, caps, 1);
  KLObject* t83 = shen_vector_get(ctx, caps, 2);
  KLObject* t84 = shen_vector_get(ctx, caps, 3);
  KLObject* t85 = shen_vector_get(ctx, caps, 4);
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t86 = objects[0];
  KLObject* t87;
  {
    KLObject* a87[] = {t81};
    t87 = shen_apply_direct(ctx, "shen.newpv", 1, a87);
  }
  KLObject* t91 = shen_apply_direct(ctx, "shen.incinfs", 0, NULL);
  KLObject* t94;
  {
    KLObject* a94[] = {t82, t81};
    t94 = shen_apply_direct(ctx, "shen.deref", 2, a94);
  }
  KLObject* t93;
  {
    KLObject* a93[] = {t94};
    t93 = shen_apply_direct(ctx, "arity", 1, a93);
  }
  KLObject* t97 = shen_number_l(ctx, 0);
  KLObject* t98 = shen_eq(ctx, t93, t97);
  KLObject* t102;
  {
    Vector* caps_6 = shen_vector(ctx, 7);
    shen_vector_set(ctx, caps_6, 0, t81);
    shen_vector_set(ctx, caps_6, 1, t83);
    shen_vector_set(ctx, caps_6, 2, t84);
    shen_vector_set(ctx, caps_6, 3, t82);
    shen_vector_set(ctx, caps_6, 4, t87);
    shen_vector_set(ctx, caps_6, 5, t86);
    shen_vector_set(ctx, caps_6, 6, t85);
    t102 = shen_native_closure(ctx, 0, &lambda_6, caps_6);
  }
  KLObject* t92;
  {
    KLObject* a92[] = {t98, t81, t83, t84, t102};
    t92 = shen_apply_direct(ctx, "when", 5, a92);
  }
  KLObject* t89;
  {
    KLObject* a89[] = {t81, t92};
    t89 = shen_tail_apply_direct(ctx, "shen.gc", 2, a89);
  }
    return t89;
  }
}

static KLObject* lambda_10 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  KLObject* t165 = shen_vector_get(ctx, caps, 0);
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t166 = objects[0];
  KLObject* t167;
  {
    Vector* a167 = shen_vector(ctx, 1);
    shen_vector_set(ctx, a167, 0, t166);
    t167 = shen_tail_apply(ctx, t165, a167);
  }
    return t167;
  }
}

static KLObject* lambda_11 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  KLObject* t180 = shen_vector_get(ctx, caps, 0);
  KLObject* t181 = shen_vector_get(ctx, caps, 1);
  (void)arguments;
  KLObject* t182;
  {
    Vector* a182 = shen_vector(ctx, 1);
    shen_vector_set(ctx, a182, 0, t181);
    t182 = shen_tail_apply(ctx, t180, a182);
  }
    return t182;
}

static KLObject* lambda_12 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  KLObject* t214 = shen_vector_get(ctx, caps, 0);
  KLObject* t215 = shen_vector_get(ctx, caps, 1);
  (void)arguments;
  KLObject* t216;
  {
    Vector* a216 = shen_vector(ctx, 1);
    shen_vector_set(ctx, a216, 0, t215);
    t216 = shen_tail_apply(ctx, t214, a216);
  }
    return t216;
}

static KLObject* lambda_9 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  KLObject* t157 = shen_vector_get(ctx, caps, 0);
  KLObject* t158 = shen_vector_get(ctx, caps, 1);
  KLObject* t159 = shen_vector_get(ctx, caps, 2);
  (void)arguments;
  KLObject* t162 = shen_tl(ctx, t157);
  KLObject* t160;
  {
    KLObject* a160[] = {t162, t158};
    t160 = shen_apply_direct(ctx, "shen.lazyderef", 2, a160);
  }
  KLObject* t164;
  {
    Vector* caps_10 = shen_vector(ctx, 1);
    shen_vector_set(ctx, caps_10, 0, t159);
    t164 = shen_native_closure(ctx, 1, &lambda_10, caps_10);
  }
  KLObject* t172 = shen_cons_p(ctx, t160);
  KLObject* t170;
  if (!shen_is_boolean(ctx, t172))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t172)) {
  KLObject* t174 = shen_hd(ctx, t160);
  KLObject* t177 = shen_tl(ctx, t160);
  KLObject* t175;
  {
    KLObject* a175[] = {t177, t158};
    t175 = shen_apply_direct(ctx, "shen.lazyderef", 2, a175);
  }
  KLObject* t179;
  {
    Vector* caps_11 = shen_vector(ctx, 2);
    shen_vector_set(ctx, caps_11, 0, t164);
    shen_vector_set(ctx, caps_11, 1, t174);
    t179 = shen_native_closure(ctx, 0, &lambda_11, caps_11);
  }
  KLObject* t187 = shen_empty_list(ctx);
  KLObject* t188 = shen_eq(ctx, t175, t187);
  KLObject* t185;
  if (!shen_is_boolean(ctx, t188))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t188)) {
  KLObject* t189;
  {
    KLObject* a189[] = {t179};
    t189 = shen_tail_apply_direct(ctx, "thaw", 1, a189);
  }
    t185 = t189;
  } else {
  KLObject* t192;
  {
    KLObject* a192[] = {t175};
    t192 = shen_apply_direct(ctx, "shen.pvar?", 1, a192);
  }
  KLObject* t191;
  if (!shen_is_boolean(ctx, t192))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t192)) {
  KLObject* t196 = shen_empty_list(ctx);
  KLObject* t194;
  {
    KLObject* a194[] = {t175, t196, t158, t179};
    t194 = shen_tail_apply_direct(ctx, "shen.bind!", 4, a194);
  }
    t191 = t194;
  } else {
  KLObject* t199 = shen_false(ctx);
    t191 = t199;
  }
    t185 = t191;
  }
    t170 = t185;
  } else {
  KLObject* t201;
  {
    KLObject* a201[] = {t160};
    t201 = shen_apply_direct(ctx, "shen.pvar?", 1, a201);
  }
  KLObject* t200;
  if (!shen_is_boolean(ctx, t201))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t201)) {
  KLObject* t203;
  {
    KLObject* a203[] = {t158};
    t203 = shen_apply_direct(ctx, "shen.newpv", 1, a203);
  }
  KLObject* t210 = shen_empty_list(ctx);
  KLObject* t211 = shen_cons(ctx, t203, t210);
  KLObject* t213;
  {
    Vector* caps_12 = shen_vector(ctx, 2);
    shen_vector_set(ctx, caps_12, 0, t164);
    shen_vector_set(ctx, caps_12, 1, t203);
    t213 = shen_native_closure(ctx, 0, &lambda_12, caps_12);
  }
  KLObject* t207;
  {
    KLObject* a207[] = {t160, t211, t158, t213};
    t207 = shen_apply_direct(ctx, "shen.bind!", 4, a207);
  }
  KLObject* t205;
  {
    KLObject* a205[] = {t158, t207};
    t205 = shen_tail_apply_direct(ctx, "shen.gc", 2, a205);
  }
    t200 = t205;
  } else {
  KLObject* t219 = shen_false(ctx);
    t200 = t219;
  }
    t170 = t200;
  }
    return t170;
}

static KLObject* lambda_13 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  KLObject* t251 = shen_vector_get(ctx, caps, 0);
  KLObject* t252 = shen_vector_get(ctx, caps, 1);
  (void)arguments;
  KLObject* t253;
  {
    Vector* a253 = shen_vector(ctx, 1);
    shen_vector_set(ctx, a253, 0, t252);
    t253 = shen_tail_apply(ctx, t251, a253);
  }
    return t253;
}

static KLObject* lambda_14 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  KLObject* t282 = shen_vector_get(ctx, caps, 0);
  KLObject* t283 = shen_vector_get(ctx, caps, 1);
  KLObject* t284 = shen_vector_get(ctx, caps, 2);
  KLObject* t285 = shen_vector_get(ctx, caps, 3);
  KLObject* t286 = shen_vector_get(ctx, caps, 4);
  KLObject* t287 = shen_vector_get(ctx, caps, 5);
  KLObject* t288 = shen_vector_get(ctx, caps, 6);
  (void)arguments;
  KLObject* t289;
  {
    KLObject* a289[] = {t282, t283, t284, t285, t286, t287, t288};
    t289 = shen_tail_apply_direct(ctx, "shen.variants?", 7, a289);
  }
    return t289;
}

static KLObject* native_kl_declare_0 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t0 = objects[0];
    KLObject* t1 = objects[1];
  tail_start_kl_declare_0: ;
  KLObject* t2;
  {
    KLObject* a2[] = {t1};
    t2 = shen_apply_direct(ctx, "shen.rectify-type", 1, a2);
  }
  KLObject* t8;
  {
    Vector* caps_0 = shen_vector(ctx, 2);
    shen_vector_set(ctx, caps_0, 0, t0);
    shen_vector_set(ctx, caps_0, 1, t2);
    t8 = shen_native_closure(ctx, 1, &lambda_0, caps_0);
  }
  KLObject* t44 = shen_apply_direct(ctx, "shen.prolog-vector", 0, NULL);
  KLObject* t7;
  {
    Vector* a7 = shen_vector(ctx, 1);
    shen_vector_set(ctx, a7, 0, t44);
    t7 = shen_apply(ctx, t8, a7);
  }
  KLObject* t46 = shen_true(ctx);
  KLObject* t48 = shen_number_l(ctx, 0);
  KLObject* t50 = shen_number_l(ctx, 0);
  KLObject* t49;
  {
    KLObject* a49[] = {t50};
    t49 = shen_apply_direct(ctx, "vector", 1, a49);
  }
  KLObject* t47;
  {
    KLObject* a47[] = {t48, t49};
    t47 = shen_apply_direct(ctx, "@v", 2, a47);
  }
  KLObject* t45;
  {
    KLObject* a45[] = {t46, t47};
    t45 = shen_apply_direct(ctx, "@v", 2, a45);
  }
  KLObject* t6;
  {
    Vector* a6 = shen_vector(ctx, 1);
    shen_vector_set(ctx, a6, 0, t45);
    t6 = shen_apply(ctx, t7, a6);
  }
  KLObject* t51 = shen_number_l(ctx, 0);
  KLObject* t5;
  {
    Vector* a5 = shen_vector(ctx, 1);
    shen_vector_set(ctx, a5, 0, t51);
    t5 = shen_apply(ctx, t6, a5);
  }
  KLObject* t52;
  {
    Vector* caps_4 = shen_vector(ctx, 0);
    t52 = shen_native_closure(ctx, 0, &lambda_4, caps_4);
  }
  KLObject* t4;
  {
    Vector* a4 = shen_vector(ctx, 1);
    shen_vector_set(ctx, a4, 0, t52);
    t4 = shen_apply(ctx, t5, a4);
  }
  KLObject* t54;
  {
    KLObject* a54[] = {t1};
    t54 = shen_apply_direct(ctx, "shen.prolog-abstraction", 1, a54);
  }
  KLObject* t56 = shen_eval_kl(ctx, t54);
  KLObject* t58 = shen_intern(ctx, "shen.*sigf*");
  KLObject* t63 = shen_intern(ctx, "shen.*sigf*");
  KLObject* t62;
  {
    KLObject* a62[] = {t63};
    t62 = shen_apply_direct(ctx, "value", 1, a62);
  }
  KLObject* t59;
  {
    KLObject* a59[] = {t0, t56, t62};
    t59 = shen_apply_direct(ctx, "shen.assoc->", 3, a59);
  }
  KLObject* t57;
  {
    KLObject* a57[] = {t58, t59};
    t57 = shen_apply_direct(ctx, "set", 2, a57);
  }
    return t0;
  }
}

static KLObject* native_kl_shen_2evariancy_1 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t65 = objects[0];
    KLObject* t66 = objects[1];
    KLObject* t67 = objects[2];
    KLObject* t68 = objects[3];
    KLObject* t69 = objects[4];
    KLObject* t70 = objects[5];
  tail_start_kl_shen_2evariancy_1: ;
  KLObject* t72 = shen_number_l(ctx, 1);
  KLObject* t73 = shen_add(ctx, t69, t72);
  KLObject* t75;
  {
    KLObject* a75[] = {t68};
    t75 = shen_apply_direct(ctx, "shen.unlocked?", 1, a75);
  }
  KLObject* t74;
  if (!shen_is_boolean(ctx, t75))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t75)) {
  KLObject* t77;
  {
    KLObject* a77[] = {t66, t67};
    t77 = shen_apply_direct(ctx, "shen.lazyderef", 2, a77);
  }
  KLObject* t80;
  {
    Vector* caps_5 = shen_vector(ctx, 5);
    shen_vector_set(ctx, caps_5, 0, t67);
    shen_vector_set(ctx, caps_5, 1, t65);
    shen_vector_set(ctx, caps_5, 2, t68);
    shen_vector_set(ctx, caps_5, 3, t73);
    shen_vector_set(ctx, caps_5, 4, t70);
    t80 = shen_native_closure(ctx, 1, &lambda_5, caps_5);
  }
  KLObject* t151 = shen_cons_p(ctx, t77);
  KLObject* t149;
  if (!shen_is_boolean(ctx, t151))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t151)) {
  KLObject* t154 = shen_hd(ctx, t77);
  KLObject* t152;
  {
    KLObject* a152[] = {t154, t67};
    t152 = shen_apply_direct(ctx, "shen.lazyderef", 2, a152);
  }
  KLObject* t156;
  {
    Vector* caps_9 = shen_vector(ctx, 3);
    shen_vector_set(ctx, caps_9, 0, t77);
    shen_vector_set(ctx, caps_9, 1, t67);
    shen_vector_set(ctx, caps_9, 2, t80);
    t156 = shen_native_closure(ctx, 0, &lambda_9, caps_9);
  }
  KLObject* t222 = shen_intern(ctx, "-->");
  KLObject* t223 = shen_eq(ctx, t152, t222);
  KLObject* t220;
  if (!shen_is_boolean(ctx, t223))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t223)) {
  KLObject* t224;
  {
    KLObject* a224[] = {t156};
    t224 = shen_apply_direct(ctx, "thaw", 1, a224);
  }
    t220 = t224;
  } else {
  KLObject* t227;
  {
    KLObject* a227[] = {t152};
    t227 = shen_apply_direct(ctx, "shen.pvar?", 1, a227);
  }
  KLObject* t226;
  if (!shen_is_boolean(ctx, t227))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t227)) {
  KLObject* t231 = shen_intern(ctx, "-->");
  KLObject* t229;
  {
    KLObject* a229[] = {t152, t231, t67, t156};
    t229 = shen_apply_direct(ctx, "shen.bind!", 4, a229);
  }
    t226 = t229;
  } else {
  KLObject* t234 = shen_false(ctx);
    t226 = t234;
  }
    t220 = t226;
  }
    t149 = t220;
  } else {
  KLObject* t236;
  {
    KLObject* a236[] = {t77};
    t236 = shen_apply_direct(ctx, "shen.pvar?", 1, a236);
  }
  KLObject* t235;
  if (!shen_is_boolean(ctx, t236))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t236)) {
  KLObject* t238;
  {
    KLObject* a238[] = {t67};
    t238 = shen_apply_direct(ctx, "shen.newpv", 1, a238);
  }
  KLObject* t244 = shen_intern(ctx, "-->");
  KLObject* t246 = shen_empty_list(ctx);
  KLObject* t247 = shen_cons(ctx, t238, t246);
  KLObject* t248 = shen_cons(ctx, t244, t247);
  KLObject* t250;
  {
    Vector* caps_13 = shen_vector(ctx, 2);
    shen_vector_set(ctx, caps_13, 0, t80);
    shen_vector_set(ctx, caps_13, 1, t238);
    t250 = shen_native_closure(ctx, 0, &lambda_13, caps_13);
  }
  KLObject* t242;
  {
    KLObject* a242[] = {t77, t248, t67, t250};
    t242 = shen_apply_direct(ctx, "shen.bind!", 4, a242);
  }
  KLObject* t240;
  {
    KLObject* a240[] = {t67, t242};
    t240 = shen_apply_direct(ctx, "shen.gc", 2, a240);
  }
    t235 = t240;
  } else {
  KLObject* t256 = shen_false(ctx);
    t235 = t256;
  }
    t149 = t235;
  }
    t74 = t149;
  } else {
  KLObject* t257 = shen_false(ctx);
    t74 = t257;
  }
  KLObject* t260 = shen_false(ctx);
  KLObject* t261 = shen_eq(ctx, t74, t260);
  KLObject* t258;
  if (!shen_is_boolean(ctx, t261))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t261)) {
  KLObject* t263;
  {
    KLObject* a263[] = {t68};
    t263 = shen_apply_direct(ctx, "shen.unlocked?", 1, a263);
  }
  KLObject* t262;
  if (!shen_is_boolean(ctx, t263))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t263)) {
  KLObject* t265;
  {
    KLObject* a265[] = {t67};
    t265 = shen_apply_direct(ctx, "shen.newpv", 1, a265);
  }
  KLObject* t269 = shen_apply_direct(ctx, "shen.incinfs", 0, NULL);
  KLObject* t271 = shen_intern(ctx, "fn");
  KLObject* t273 = shen_empty_list(ctx);
  KLObject* t274 = shen_cons(ctx, t65, t273);
  KLObject* t275 = shen_cons(ctx, t271, t274);
  KLObject* t277 = shen_empty_list(ctx);
  KLObject* t281;
  {
    Vector* caps_14 = shen_vector(ctx, 7);
    shen_vector_set(ctx, caps_14, 0, t65);
    shen_vector_set(ctx, caps_14, 1, t265);
    shen_vector_set(ctx, caps_14, 2, t66);
    shen_vector_set(ctx, caps_14, 3, t67);
    shen_vector_set(ctx, caps_14, 4, t68);
    shen_vector_set(ctx, caps_14, 5, t73);
    shen_vector_set(ctx, caps_14, 6, t70);
    t281 = shen_native_closure(ctx, 0, &lambda_14, caps_14);
  }
  KLObject* t270;
  {
    KLObject* a270[] = {t275, t265, t277, t67, t68, t73, t281};
    t270 = shen_apply_direct(ctx, "shen.system-S-h", 7, a270);
  }
  KLObject* t267;
  {
    KLObject* a267[] = {t67, t270};
    t267 = shen_apply_direct(ctx, "shen.gc", 2, a267);
  }
    t262 = t267;
  } else {
  KLObject* t297 = shen_false(ctx);
    t262 = t297;
  }
  KLObject* t300 = shen_false(ctx);
  KLObject* t301 = shen_eq(ctx, t262, t300);
  KLObject* t298;
  if (!shen_is_boolean(ctx, t301))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t301)) {
  KLObject* t302;
  {
    KLObject* a302[] = {t68, t73};
    t302 = shen_tail_apply_direct(ctx, "shen.unlock", 2, a302);
  }
    t298 = t302;
  } else {
    t298 = t262;
  }
    t258 = t298;
  } else {
    t258 = t74;
  }
    return t258;
  }
}

static KLObject* native_kl_shen_2evariants_3f_2 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t307 = objects[0];
    KLObject* t308 = objects[1];
    KLObject* t309 = objects[2];
    KLObject* t310 = objects[3];
    KLObject* t311 = objects[4];
    KLObject* t312 = objects[5];
    KLObject* t313 = objects[6];
  tail_start_kl_shen_2evariants_3f_2: ;
  KLObject* t315;
  {
    KLObject* a315[] = {t311};
    t315 = shen_apply_direct(ctx, "shen.unlocked?", 1, a315);
  }
  KLObject* t314;
  if (!shen_is_boolean(ctx, t315))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t315)) {
  KLObject* t317 = shen_apply_direct(ctx, "shen.incinfs", 0, NULL);
  KLObject* t318;
  {
    KLObject* a318[] = {t308, t309, t310, t311, t312, t313};
    t318 = shen_apply_direct(ctx, "is!", 6, a318);
  }
    t314 = t318;
  } else {
  KLObject* t325 = shen_false(ctx);
    t314 = t325;
  }
  KLObject* t328 = shen_false(ctx);
  KLObject* t329 = shen_eq(ctx, t314, t328);
  KLObject* t326;
  if (!shen_is_boolean(ctx, t329))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t329)) {
  KLObject* t331;
  {
    KLObject* a331[] = {t311};
    t331 = shen_apply_direct(ctx, "shen.unlocked?", 1, a331);
  }
  KLObject* t330;
  if (!shen_is_boolean(ctx, t331))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t331)) {
  KLObject* t333;
  {
    KLObject* a333[] = {t310};
    t333 = shen_apply_direct(ctx, "shen.newpv", 1, a333);
  }
  KLObject* t337 = shen_apply_direct(ctx, "shen.incinfs", 0, NULL);
  KLObject* t342 = shen_string(ctx, "warning: changing the type of ");
  KLObject* t344;
  {
    KLObject* a344[] = {t307, t310};
    t344 = shen_apply_direct(ctx, "shen.deref", 2, a344);
  }
  KLObject* t347 = shen_string(ctx, " may create errors\n");
  KLObject* t348 = shen_intern(ctx, "shen.a");
  KLObject* t343;
  {
    KLObject* a343[] = {t344, t347, t348};
    t343 = shen_apply_direct(ctx, "shen.app", 3, a343);
  }
  KLObject* t341;
  {
    KLObject* a341[] = {t342, t343};
    t341 = shen_apply_direct(ctx, "cn", 2, a341);
  }
  KLObject* t349 = shen_apply_direct(ctx, "stoutput", 0, NULL);
  KLObject* t340;
  {
    KLObject* a340[] = {t341, t349};
    t340 = shen_apply_direct(ctx, "pr", 2, a340);
  }
  KLObject* t338;
  {
    KLObject* a338[] = {t333, t340, t310, t311, t312, t313};
    t338 = shen_apply_direct(ctx, "is", 6, a338);
  }
  KLObject* t335;
  {
    KLObject* a335[] = {t310, t338};
    t335 = shen_tail_apply_direct(ctx, "shen.gc", 2, a335);
  }
    t330 = t335;
  } else {
  KLObject* t354 = shen_false(ctx);
    t330 = t354;
  }
    t326 = t330;
  } else {
    t326 = t314;
  }
    return t326;
  }
}

static KLObject* native_kl_shen_2eprolog_2dabstraction_3 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t356 = objects[0];
  tail_start_kl_shen_2eprolog_2dabstraction_3: ;
  KLObject* t358 = shen_intern(ctx, "B");
  KLObject* t357;
  {
    KLObject* a357[] = {t358};
    t357 = shen_apply_direct(ctx, "gensym", 1, a357);
  }
  KLObject* t360 = shen_intern(ctx, "L");
  KLObject* t359;
  {
    KLObject* a359[] = {t360};
    t359 = shen_apply_direct(ctx, "gensym", 1, a359);
  }
  KLObject* t362 = shen_intern(ctx, "Key");
  KLObject* t361;
  {
    KLObject* a361[] = {t362};
    t361 = shen_apply_direct(ctx, "gensym", 1, a361);
  }
  KLObject* t364 = shen_intern(ctx, "C");
  KLObject* t363;
  {
    KLObject* a363[] = {t364};
    t363 = shen_apply_direct(ctx, "gensym", 1, a363);
  }
  KLObject* t366 = shen_intern(ctx, "V");
  KLObject* t365;
  {
    KLObject* a365[] = {t366};
    t365 = shen_apply_direct(ctx, "gensym", 1, a365);
  }
  KLObject* t367;
  {
    KLObject* a367[] = {t356};
    t367 = shen_apply_direct(ctx, "shen.extract-vars", 1, a367);
  }
  KLObject* t369 = shen_intern(ctx, "lambda");
  KLObject* t371 = shen_intern(ctx, "lambda");
  KLObject* t373 = shen_intern(ctx, "lambda");
  KLObject* t375 = shen_intern(ctx, "lambda");
  KLObject* t377 = shen_intern(ctx, "lambda");
  KLObject* t381 = shen_intern(ctx, "is!");
  KLObject* t383;
  {
    KLObject* a383[] = {t356};
    t383 = shen_apply_direct(ctx, "shen.rcons_form", 1, a383);
  }
  KLObject* t389 = shen_empty_list(ctx);
  KLObject* t390 = shen_cons(ctx, t363, t389);
  KLObject* t391 = shen_cons(ctx, t361, t390);
  KLObject* t392 = shen_cons(ctx, t359, t391);
  KLObject* t393 = shen_cons(ctx, t357, t392);
  KLObject* t394 = shen_cons(ctx, t383, t393);
  KLObject* t395 = shen_cons(ctx, t365, t394);
  KLObject* t396 = shen_cons(ctx, t381, t395);
  KLObject* t379;
  {
    KLObject* a379[] = {t367, t396, t357};
    t379 = shen_apply_direct(ctx, "shen.stpart", 3, a379);
  }
  KLObject* t398 = shen_empty_list(ctx);
  KLObject* t399 = shen_cons(ctx, t379, t398);
  KLObject* t400 = shen_cons(ctx, t363, t399);
  KLObject* t401 = shen_cons(ctx, t377, t400);
  KLObject* t402 = shen_empty_list(ctx);
  KLObject* t403 = shen_cons(ctx, t401, t402);
  KLObject* t404 = shen_cons(ctx, t361, t403);
  KLObject* t405 = shen_cons(ctx, t375, t404);
  KLObject* t406 = shen_empty_list(ctx);
  KLObject* t407 = shen_cons(ctx, t405, t406);
  KLObject* t408 = shen_cons(ctx, t359, t407);
  KLObject* t409 = shen_cons(ctx, t373, t408);
  KLObject* t410 = shen_empty_list(ctx);
  KLObject* t411 = shen_cons(ctx, t409, t410);
  KLObject* t412 = shen_cons(ctx, t357, t411);
  KLObject* t413 = shen_cons(ctx, t371, t412);
  KLObject* t414 = shen_empty_list(ctx);
  KLObject* t415 = shen_cons(ctx, t413, t414);
  KLObject* t416 = shen_cons(ctx, t365, t415);
  KLObject* t417 = shen_cons(ctx, t369, t416);
    return t417;
  }
}

static KLObject* native_kl_shen_2edemod_4 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t418 = objects[0];
  tail_start_kl_shen_2edemod_4: ;
    return t418;
  }
}

void shen_kernel_aot_install_types (shen_context* ctx)
{
  shen_register_defun(ctx, "declare", 2, &native_kl_declare_0);
  shen_register_defun(ctx, "shen.variancy", 6, &native_kl_shen_2evariancy_1);
  shen_register_defun(ctx, "shen.variants?", 7, &native_kl_shen_2evariants_3f_2);
  shen_register_defun(ctx, "shen.prolog-abstraction", 1, &native_kl_shen_2eprolog_2dabstraction_3);
  shen_register_defun(ctx, "shen.demod", 1, &native_kl_shen_2edemod_4);
}
