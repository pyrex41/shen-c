#include "rc_phase_profile.h"
/* Generated always-AOT kernel module (KL defuns -> NativeFunctions).
 * Install after tree-walker boot overwrites UserFunctions.
 * Toplevel declare/set stay on the walker. Not overlay-after-load.
 * Sidecar tests stay on the tree-walker. Not a second main. Source: writer.kl
 */
#include "abi.h"

void shen_kernel_aot_install_writer (shen_context* ctx);

static KLObject* trap_body_0 (void* data)
{
  shen_context* ctx = &shen_root_context;
  Vector* env = (Vector*)data;
  KLObject* t30 = shen_vector_get(ctx, env, 0);
  KLObject* t31 = shen_vector_get(ctx, env, 1);
  KLObject* t33;
  {
    KLObject* a33[] = {t30, t31};
    t33 = shen_apply_direct(ctx, "pos", 2, a33);
  }
  KLObject* t32;
  {
    KLObject* a32[] = {t33};
    t32 = shen_apply_direct(ctx, "string->n", 1, a32);
  }
  return t32;
}

static KLObject* lambda_0 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t39 = objects[0];
  KLObject* t40 = shen_intern(ctx, "shen.eos");
    return t40;
  }
}

static KLObject* trap_handler_0 (KLObject* exception, void* data)
{
  shen_context* ctx = &shen_root_context;
  Vector* env = (Vector*)data;
  Vector* args;
  KLObject* t36 = shen_vector_get(ctx, env, 0);
  KLObject* t37 = shen_vector_get(ctx, env, 1);
  KLObject* t38;
  {
    Vector* caps_0 = shen_vector(ctx, 0);
    t38 = shen_native_closure(ctx, 1, &lambda_0, caps_0);
  }
  args = shen_vector(ctx, 1);
  shen_vector_set(ctx, args, 0, exception);
  {
    KLObject* t41 = shen_apply(ctx, t38, args);
    return t41;
  }
}

static KLObject* trap_body_1 (void* data)
{
  shen_context* ctx = &shen_root_context;
  Vector* env = (Vector*)data;
  KLObject* t764 = shen_vector_get(ctx, env, 0);
  KLObject* t765 = shen_vector_get(ctx, env, 1);
  KLObject* t766 = shen_vector_get(ctx, env, 2);
  KLObject* t767 = shen_vector_get(ctx, env, 3);
  KLObject* t768;
  {
    KLObject* a768[] = {t764, t765};
    t768 = shen_apply_direct(ctx, "<-address", 2, a768);
  }
  return t768;
}

static KLObject* lambda_1 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t776 = objects[0];
  KLObject* t777 = shen_intern(ctx, "shen.out-of-bounds");
    return t777;
  }
}

static KLObject* trap_handler_1 (KLObject* exception, void* data)
{
  shen_context* ctx = &shen_root_context;
  Vector* env = (Vector*)data;
  Vector* args;
  KLObject* t771 = shen_vector_get(ctx, env, 0);
  KLObject* t772 = shen_vector_get(ctx, env, 1);
  KLObject* t773 = shen_vector_get(ctx, env, 2);
  KLObject* t774 = shen_vector_get(ctx, env, 3);
  KLObject* t775;
  {
    Vector* caps_1 = shen_vector(ctx, 0);
    t775 = shen_native_closure(ctx, 1, &lambda_1, caps_1);
  }
  args = shen_vector(ctx, 1);
  shen_vector_set(ctx, args, 0, exception);
  {
    KLObject* t778 = shen_apply(ctx, t775, args);
    return t778;
  }
}

static KLObject* trap_body_2 (void* data)
{
  shen_context* ctx = &shen_root_context;
  Vector* env = (Vector*)data;
  KLObject* t780 = shen_vector_get(ctx, env, 0);
  KLObject* t781 = shen_vector_get(ctx, env, 1);
  KLObject* t782 = shen_vector_get(ctx, env, 2);
  KLObject* t783 = shen_vector_get(ctx, env, 3);
  KLObject* t784 = shen_vector_get(ctx, env, 4);
  KLObject* t788 = shen_number_l(ctx, 1);
  KLObject* t789 = shen_add(ctx, t781, t788);
  KLObject* t785;
  {
    KLObject* a785[] = {t780, t789};
    t785 = shen_apply_direct(ctx, "<-address", 2, a785);
  }
  return t785;
}

static KLObject* lambda_2 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t796 = objects[0];
  KLObject* t797 = shen_intern(ctx, "shen.out-of-bounds");
    return t797;
  }
}

static KLObject* trap_handler_2 (KLObject* exception, void* data)
{
  shen_context* ctx = &shen_root_context;
  Vector* env = (Vector*)data;
  Vector* args;
  KLObject* t790 = shen_vector_get(ctx, env, 0);
  KLObject* t791 = shen_vector_get(ctx, env, 1);
  KLObject* t792 = shen_vector_get(ctx, env, 2);
  KLObject* t793 = shen_vector_get(ctx, env, 3);
  KLObject* t794 = shen_vector_get(ctx, env, 4);
  KLObject* t795;
  {
    Vector* caps_2 = shen_vector(ctx, 0);
    t795 = shen_native_closure(ctx, 1, &lambda_2, caps_2);
  }
  args = shen_vector(ctx, 1);
  shen_vector_set(ctx, args, 0, exception);
  {
    KLObject* t798 = shen_apply(ctx, t795, args);
    return t798;
  }
}

static KLObject* trap_body_3 (void* data)
{
  shen_context* ctx = &shen_root_context;
  Vector* env = (Vector*)data;
  KLObject* t828 = shen_vector_get(ctx, env, 0);
  KLObject* t829;
  {
    KLObject* a829[] = {t828};
    t829 = shen_apply_direct(ctx, "str", 1, a829);
  }
  return t829;
}

static KLObject* lambda_3 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t833 = objects[0];
  KLObject* t834 = shen_tail_apply_direct(ctx, "shen.funexstring", 0, NULL);
    return t834;
  }
}

static KLObject* trap_handler_3 (KLObject* exception, void* data)
{
  shen_context* ctx = &shen_root_context;
  Vector* env = (Vector*)data;
  Vector* args;
  KLObject* t831 = shen_vector_get(ctx, env, 0);
  KLObject* t832;
  {
    Vector* caps_3 = shen_vector(ctx, 0);
    t832 = shen_native_closure(ctx, 1, &lambda_3, caps_3);
  }
  args = shen_vector(ctx, 1);
  shen_vector_set(ctx, args, 0, exception);
  {
    KLObject* t835 = shen_apply(ctx, t832, args);
    return t835;
  }
}

static KLObject* native_kl_print_0 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t0 = objects[0];
  tail_start_kl_print_0: ;
  KLObject* t3 = shen_string(ctx, "~S");
  KLObject* t1;
  {
    KLObject* a1[] = {t0, t3};
    t1 = shen_apply_direct(ctx, "shen.insert", 2, a1);
  }
  KLObject* t6 = shen_apply_direct(ctx, "stoutput", 0, NULL);
  KLObject* t4;
  {
    KLObject* a4[] = {t1, t6};
    t4 = shen_apply_direct(ctx, "pr", 2, a4);
  }
    return t0;
  }
}

static KLObject* native_kl_pr_1 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t8 = objects[0];
    KLObject* t9 = objects[1];
  tail_start_kl_pr_1: ;
  KLObject* t12 = shen_intern(ctx, "*hush*");
  KLObject* t11;
  {
    KLObject* a11[] = {t12};
    t11 = shen_apply_direct(ctx, "value", 1, a11);
  }
  KLObject* t10;
  if (!shen_is_boolean(ctx, t11))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t11)) {
    t10 = t8;
  } else {
  KLObject* t15;
  {
    KLObject* a15[] = {t9};
    t15 = shen_apply_direct(ctx, "char-stream?", 1, a15);
  }
  KLObject* t14;
  if (!shen_is_boolean(ctx, t15))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t15)) {
  KLObject* t17;
  {
    KLObject* a17[] = {t8, t9};
    t17 = shen_tail_apply_direct(ctx, "write-string", 2, a17);
  }
    t14 = t17;
  } else {
  KLObject* t25 = shen_number_l(ctx, 0);
  KLObject* t23;
  {
    KLObject* a23[] = {t8, t25};
    t23 = shen_apply_direct(ctx, "shen.string->byte", 2, a23);
  }
  KLObject* t26 = shen_number_l(ctx, 1);
  KLObject* t20;
  {
    KLObject* a20[] = {t8, t9, t23, t26};
    t20 = shen_tail_apply_direct(ctx, "shen.write-chars", 4, a20);
  }
    t14 = t20;
  }
    t10 = t14;
  }
    return t10;
  }
}

static KLObject* native_kl_shen_2estring_2d_3ebyte_2 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t27 = objects[0];
    KLObject* t28 = objects[1];
  tail_start_kl_shen_2estring_2d_3ebyte_2: ;
  KLObject* t29;
  {
    Vector* tenv_0 = shen_vector(ctx, 2);
    shen_vector_set(ctx, tenv_0, 0, t27);
    shen_vector_set(ctx, tenv_0, 1, t28);
    t29 = shen_trap_error(ctx, trap_body_0, trap_handler_0, tenv_0);
  }
    return t29;
  }
}

static KLObject* native_kl_shen_2ewrite_2dchars_3 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t42 = objects[0];
    KLObject* t43 = objects[1];
    KLObject* t44 = objects[2];
    KLObject* t45 = objects[3];
  tail_start_kl_shen_2ewrite_2dchars_3: ;
  KLObject* t46;
  {
  KLObject* t47 = shen_intern(ctx, "shen.eos");
  KLObject* t49 = shen_eq(ctx, t47, t44);
    if (!shen_is_boolean(ctx, t49))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t49)) {
      t46 = t42;
    } else {
  KLObject* t51 = shen_true(ctx);
    if (!shen_is_boolean(ctx, t51))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t51)) {
  KLObject* t54;
  {
    KLObject* a54[] = {t44, t43};
    t54 = shen_apply_direct(ctx, "write-byte", 2, a54);
  }
  KLObject* t57;
  {
    KLObject* a57[] = {t42, t45};
    t57 = shen_apply_direct(ctx, "shen.string->byte", 2, a57);
  }
  KLObject* t61 = shen_number_l(ctx, 1);
  KLObject* t62 = shen_add(ctx, t45, t61);
  {
    KLObject* n63_0 = t42;
    KLObject* n63_1 = t43;
    KLObject* n63_2 = t57;
    KLObject* n63_3 = t62;
    t42 = n63_0;
    t43 = n63_1;
    t44 = n63_2;
    t45 = n63_3;
    goto tail_start_kl_shen_2ewrite_2dchars_3;
  }
  KLObject* t63 = NULL;
      t46 = t63;
    } else {
      shen_simple_error(ctx, "No true case found for cond");
      t46 = shen_empty_list(ctx);
    }
    }
  }
    return t46;
  }
}

static KLObject* native_kl_shen_2emkstr_4 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t64 = objects[0];
    KLObject* t65 = objects[1];
  tail_start_kl_shen_2emkstr_4: ;
  KLObject* t66;
  {
  KLObject* t68 = shen_string_p(ctx, t64);
    if (!shen_is_boolean(ctx, t68))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t68)) {
  KLObject* t70;
  {
    KLObject* a70[] = {t64};
    t70 = shen_apply_direct(ctx, "shen.proc-nl", 1, a70);
  }
  KLObject* t69;
  {
    KLObject* a69[] = {t70, t65};
    t69 = shen_tail_apply_direct(ctx, "shen.mkstr-l", 2, a69);
  }
      t66 = t69;
    } else {
  KLObject* t73 = shen_true(ctx);
    if (!shen_is_boolean(ctx, t73))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t73)) {
  KLObject* t75 = shen_intern(ctx, "shen.proc-nl");
  KLObject* t77 = shen_empty_list(ctx);
  KLObject* t78 = shen_cons(ctx, t64, t77);
  KLObject* t79 = shen_cons(ctx, t75, t78);
  KLObject* t74;
  {
    KLObject* a74[] = {t79, t65};
    t74 = shen_tail_apply_direct(ctx, "shen.mkstr-r", 2, a74);
  }
      t66 = t74;
    } else {
      shen_simple_error(ctx, "No true case found for cond");
      t66 = shen_empty_list(ctx);
    }
    }
  }
    return t66;
  }
}

static KLObject* native_kl_shen_2emkstr_2dl_5 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t81 = objects[0];
    KLObject* t82 = objects[1];
  tail_start_kl_shen_2emkstr_2dl_5: ;
  KLObject* t83;
  {
  KLObject* t84 = shen_empty_list(ctx);
  KLObject* t86 = shen_eq(ctx, t84, t82);
    if (!shen_is_boolean(ctx, t86))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t86)) {
      t83 = t81;
    } else {
  KLObject* t89 = shen_cons_p(ctx, t82);
    if (!shen_is_boolean(ctx, t89))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t89)) {
  KLObject* t92 = shen_hd(ctx, t82);
  KLObject* t90;
  {
    KLObject* a90[] = {t92, t81};
    t90 = shen_apply_direct(ctx, "shen.insert-l", 2, a90);
  }
  KLObject* t95 = shen_tl(ctx, t82);
  {
    KLObject* n96_0 = t90;
    KLObject* n96_1 = t95;
    t81 = n96_0;
    t82 = n96_1;
    goto tail_start_kl_shen_2emkstr_2dl_5;
  }
  KLObject* t96 = NULL;
      t83 = t96;
    } else {
  KLObject* t97 = shen_true(ctx);
    if (!shen_is_boolean(ctx, t97))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t97)) {
  KLObject* t99 = shen_string(ctx, "implementation error in shen.mkstr-l");
  KLObject* t98;
  {
    KLObject* a98[] = {t99};
    t98 = shen_tail_apply_direct(ctx, "simple-error", 1, a98);
  }
      t83 = t98;
    } else {
      shen_simple_error(ctx, "No true case found for cond");
      t83 = shen_empty_list(ctx);
    }
    }
    }
  }
    return t83;
  }
}

static KLObject* native_kl_shen_2einsert_2dl_6 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t100 = objects[0];
    KLObject* t101 = objects[1];
  tail_start_kl_shen_2einsert_2dl_6: ;
  KLObject* t102;
  {
  KLObject* t103 = shen_string(ctx, "");
  KLObject* t105 = shen_eq(ctx, t103, t101);
    if (!shen_is_boolean(ctx, t105))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t105)) {
  KLObject* t106 = shen_string(ctx, "");
      t102 = t106;
    } else {
  KLObject* t108;
  {
    KLObject* a108[] = {t101};
    t108 = shen_apply_direct(ctx, "shen.+string?", 1, a108);
  }
  KLObject* t107;
  if (!shen_is_boolean(ctx, t108))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t108)) {
    t107 = t108;
  } else {
  KLObject* t111 = shen_string(ctx, "~");
  KLObject* t112;
  {
    KLObject* a112[] = {t101};
    t112 = shen_apply_direct(ctx, "hdstr", 1, a112);
  }
  KLObject* t114 = shen_eq(ctx, t111, t112);
  KLObject* t110;
  if (!shen_is_boolean(ctx, t114))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t114)) {
    t110 = t114;
  } else {
  KLObject* t117;
  {
    KLObject* a117[] = {t101};
    t117 = shen_apply_direct(ctx, "tlstr", 1, a117);
  }
  KLObject* t116;
  {
    KLObject* a116[] = {t117};
    t116 = shen_apply_direct(ctx, "shen.+string?", 1, a116);
  }
  KLObject* t115;
  if (!shen_is_boolean(ctx, t116))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t116)) {
    t115 = t116;
  } else {
  KLObject* t119 = shen_string(ctx, "A");
  KLObject* t121;
  {
    KLObject* a121[] = {t101};
    t121 = shen_apply_direct(ctx, "tlstr", 1, a121);
  }
  KLObject* t120;
  {
    KLObject* a120[] = {t121};
    t120 = shen_apply_direct(ctx, "hdstr", 1, a120);
  }
  KLObject* t123 = shen_eq(ctx, t119, t120);
    if (!shen_is_boolean(ctx, t123))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t115 = t123;
  }
    if (!shen_is_boolean(ctx, t115))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t110 = t115;
  }
    if (!shen_is_boolean(ctx, t110))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t107 = t110;
  }
    if (!shen_is_boolean(ctx, t107))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t107)) {
  KLObject* t124 = shen_intern(ctx, "shen.app");
  KLObject* t127;
  {
    KLObject* a127[] = {t101};
    t127 = shen_apply_direct(ctx, "tlstr", 1, a127);
  }
  KLObject* t126;
  {
    KLObject* a126[] = {t127};
    t126 = shen_apply_direct(ctx, "tlstr", 1, a126);
  }
  KLObject* t129 = shen_intern(ctx, "shen.a");
  KLObject* t130 = shen_empty_list(ctx);
  KLObject* t131 = shen_cons(ctx, t129, t130);
  KLObject* t132 = shen_cons(ctx, t126, t131);
  KLObject* t133 = shen_cons(ctx, t100, t132);
  KLObject* t134 = shen_cons(ctx, t124, t133);
      t102 = t134;
    } else {
  KLObject* t136;
  {
    KLObject* a136[] = {t101};
    t136 = shen_apply_direct(ctx, "shen.+string?", 1, a136);
  }
  KLObject* t135;
  if (!shen_is_boolean(ctx, t136))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t136)) {
    t135 = t136;
  } else {
  KLObject* t139 = shen_string(ctx, "~");
  KLObject* t140;
  {
    KLObject* a140[] = {t101};
    t140 = shen_apply_direct(ctx, "hdstr", 1, a140);
  }
  KLObject* t142 = shen_eq(ctx, t139, t140);
  KLObject* t138;
  if (!shen_is_boolean(ctx, t142))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t142)) {
    t138 = t142;
  } else {
  KLObject* t145;
  {
    KLObject* a145[] = {t101};
    t145 = shen_apply_direct(ctx, "tlstr", 1, a145);
  }
  KLObject* t144;
  {
    KLObject* a144[] = {t145};
    t144 = shen_apply_direct(ctx, "shen.+string?", 1, a144);
  }
  KLObject* t143;
  if (!shen_is_boolean(ctx, t144))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t144)) {
    t143 = t144;
  } else {
  KLObject* t147 = shen_string(ctx, "R");
  KLObject* t149;
  {
    KLObject* a149[] = {t101};
    t149 = shen_apply_direct(ctx, "tlstr", 1, a149);
  }
  KLObject* t148;
  {
    KLObject* a148[] = {t149};
    t148 = shen_apply_direct(ctx, "hdstr", 1, a148);
  }
  KLObject* t151 = shen_eq(ctx, t147, t148);
    if (!shen_is_boolean(ctx, t151))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t143 = t151;
  }
    if (!shen_is_boolean(ctx, t143))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t138 = t143;
  }
    if (!shen_is_boolean(ctx, t138))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t135 = t138;
  }
    if (!shen_is_boolean(ctx, t135))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t135)) {
  KLObject* t152 = shen_intern(ctx, "shen.app");
  KLObject* t155;
  {
    KLObject* a155[] = {t101};
    t155 = shen_apply_direct(ctx, "tlstr", 1, a155);
  }
  KLObject* t154;
  {
    KLObject* a154[] = {t155};
    t154 = shen_apply_direct(ctx, "tlstr", 1, a154);
  }
  KLObject* t157 = shen_intern(ctx, "shen.r");
  KLObject* t158 = shen_empty_list(ctx);
  KLObject* t159 = shen_cons(ctx, t157, t158);
  KLObject* t160 = shen_cons(ctx, t154, t159);
  KLObject* t161 = shen_cons(ctx, t100, t160);
  KLObject* t162 = shen_cons(ctx, t152, t161);
      t102 = t162;
    } else {
  KLObject* t164;
  {
    KLObject* a164[] = {t101};
    t164 = shen_apply_direct(ctx, "shen.+string?", 1, a164);
  }
  KLObject* t163;
  if (!shen_is_boolean(ctx, t164))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t164)) {
    t163 = t164;
  } else {
  KLObject* t167 = shen_string(ctx, "~");
  KLObject* t168;
  {
    KLObject* a168[] = {t101};
    t168 = shen_apply_direct(ctx, "hdstr", 1, a168);
  }
  KLObject* t170 = shen_eq(ctx, t167, t168);
  KLObject* t166;
  if (!shen_is_boolean(ctx, t170))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t170)) {
    t166 = t170;
  } else {
  KLObject* t173;
  {
    KLObject* a173[] = {t101};
    t173 = shen_apply_direct(ctx, "tlstr", 1, a173);
  }
  KLObject* t172;
  {
    KLObject* a172[] = {t173};
    t172 = shen_apply_direct(ctx, "shen.+string?", 1, a172);
  }
  KLObject* t171;
  if (!shen_is_boolean(ctx, t172))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t172)) {
    t171 = t172;
  } else {
  KLObject* t175 = shen_string(ctx, "S");
  KLObject* t177;
  {
    KLObject* a177[] = {t101};
    t177 = shen_apply_direct(ctx, "tlstr", 1, a177);
  }
  KLObject* t176;
  {
    KLObject* a176[] = {t177};
    t176 = shen_apply_direct(ctx, "hdstr", 1, a176);
  }
  KLObject* t179 = shen_eq(ctx, t175, t176);
    if (!shen_is_boolean(ctx, t179))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t171 = t179;
  }
    if (!shen_is_boolean(ctx, t171))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t166 = t171;
  }
    if (!shen_is_boolean(ctx, t166))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t163 = t166;
  }
    if (!shen_is_boolean(ctx, t163))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t163)) {
  KLObject* t180 = shen_intern(ctx, "shen.app");
  KLObject* t183;
  {
    KLObject* a183[] = {t101};
    t183 = shen_apply_direct(ctx, "tlstr", 1, a183);
  }
  KLObject* t182;
  {
    KLObject* a182[] = {t183};
    t182 = shen_apply_direct(ctx, "tlstr", 1, a182);
  }
  KLObject* t185 = shen_intern(ctx, "shen.s");
  KLObject* t186 = shen_empty_list(ctx);
  KLObject* t187 = shen_cons(ctx, t185, t186);
  KLObject* t188 = shen_cons(ctx, t182, t187);
  KLObject* t189 = shen_cons(ctx, t100, t188);
  KLObject* t190 = shen_cons(ctx, t180, t189);
      t102 = t190;
    } else {
  KLObject* t191;
  {
    KLObject* a191[] = {t101};
    t191 = shen_apply_direct(ctx, "shen.+string?", 1, a191);
  }
    if (!shen_is_boolean(ctx, t191))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t191)) {
  KLObject* t194 = shen_intern(ctx, "cn");
  KLObject* t195;
  {
    KLObject* a195[] = {t101};
    t195 = shen_apply_direct(ctx, "hdstr", 1, a195);
  }
  KLObject* t199;
  {
    KLObject* a199[] = {t101};
    t199 = shen_apply_direct(ctx, "tlstr", 1, a199);
  }
  KLObject* t197;
  {
    KLObject* a197[] = {t100, t199};
    t197 = shen_apply_direct(ctx, "shen.insert-l", 2, a197);
  }
  KLObject* t201 = shen_empty_list(ctx);
  KLObject* t202 = shen_cons(ctx, t197, t201);
  KLObject* t203 = shen_cons(ctx, t195, t202);
  KLObject* t204 = shen_cons(ctx, t194, t203);
  KLObject* t193;
  {
    KLObject* a193[] = {t204};
    t193 = shen_tail_apply_direct(ctx, "shen.factor-cn", 1, a193);
  }
      t102 = t193;
    } else {
  KLObject* t207 = shen_cons_p(ctx, t101);
  KLObject* t205;
  if (!shen_is_boolean(ctx, t207))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t207)) {
    t205 = t207;
  } else {
  KLObject* t209 = shen_intern(ctx, "cn");
  KLObject* t211 = shen_hd(ctx, t101);
  KLObject* t212 = shen_eq(ctx, t209, t211);
  KLObject* t208;
  if (!shen_is_boolean(ctx, t212))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t212)) {
    t208 = t212;
  } else {
  KLObject* t215 = shen_tl(ctx, t101);
  KLObject* t216 = shen_cons_p(ctx, t215);
  KLObject* t213;
  if (!shen_is_boolean(ctx, t216))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t216)) {
    t213 = t216;
  } else {
  KLObject* t219 = shen_tl(ctx, t101);
  KLObject* t220 = shen_tl(ctx, t219);
  KLObject* t221 = shen_cons_p(ctx, t220);
  KLObject* t217;
  if (!shen_is_boolean(ctx, t221))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t221)) {
    t217 = t221;
  } else {
  KLObject* t222 = shen_empty_list(ctx);
  KLObject* t224 = shen_tl(ctx, t101);
  KLObject* t225 = shen_tl(ctx, t224);
  KLObject* t226 = shen_tl(ctx, t225);
  KLObject* t227 = shen_eq(ctx, t222, t226);
    if (!shen_is_boolean(ctx, t227))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t217 = t227;
  }
    if (!shen_is_boolean(ctx, t217))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t213 = t217;
  }
    if (!shen_is_boolean(ctx, t213))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t208 = t213;
  }
    if (!shen_is_boolean(ctx, t208))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t205 = t208;
  }
    if (!shen_is_boolean(ctx, t205))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t205)) {
  KLObject* t228 = shen_intern(ctx, "cn");
  KLObject* t230 = shen_tl(ctx, t101);
  KLObject* t231 = shen_hd(ctx, t230);
  KLObject* t235 = shen_tl(ctx, t101);
  KLObject* t236 = shen_tl(ctx, t235);
  KLObject* t237 = shen_hd(ctx, t236);
  KLObject* t232;
  {
    KLObject* a232[] = {t100, t237};
    t232 = shen_apply_direct(ctx, "shen.insert-l", 2, a232);
  }
  KLObject* t238 = shen_empty_list(ctx);
  KLObject* t239 = shen_cons(ctx, t232, t238);
  KLObject* t240 = shen_cons(ctx, t231, t239);
  KLObject* t241 = shen_cons(ctx, t228, t240);
      t102 = t241;
    } else {
  KLObject* t244 = shen_cons_p(ctx, t101);
  KLObject* t242;
  if (!shen_is_boolean(ctx, t244))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t244)) {
    t242 = t244;
  } else {
  KLObject* t246 = shen_intern(ctx, "shen.app");
  KLObject* t248 = shen_hd(ctx, t101);
  KLObject* t249 = shen_eq(ctx, t246, t248);
  KLObject* t245;
  if (!shen_is_boolean(ctx, t249))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t249)) {
    t245 = t249;
  } else {
  KLObject* t252 = shen_tl(ctx, t101);
  KLObject* t253 = shen_cons_p(ctx, t252);
  KLObject* t250;
  if (!shen_is_boolean(ctx, t253))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t253)) {
    t250 = t253;
  } else {
  KLObject* t256 = shen_tl(ctx, t101);
  KLObject* t257 = shen_tl(ctx, t256);
  KLObject* t258 = shen_cons_p(ctx, t257);
  KLObject* t254;
  if (!shen_is_boolean(ctx, t258))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t258)) {
    t254 = t258;
  } else {
  KLObject* t261 = shen_tl(ctx, t101);
  KLObject* t262 = shen_tl(ctx, t261);
  KLObject* t263 = shen_tl(ctx, t262);
  KLObject* t264 = shen_cons_p(ctx, t263);
  KLObject* t259;
  if (!shen_is_boolean(ctx, t264))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t264)) {
    t259 = t264;
  } else {
  KLObject* t265 = shen_empty_list(ctx);
  KLObject* t267 = shen_tl(ctx, t101);
  KLObject* t268 = shen_tl(ctx, t267);
  KLObject* t269 = shen_tl(ctx, t268);
  KLObject* t270 = shen_tl(ctx, t269);
  KLObject* t271 = shen_eq(ctx, t265, t270);
    if (!shen_is_boolean(ctx, t271))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t259 = t271;
  }
    if (!shen_is_boolean(ctx, t259))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t254 = t259;
  }
    if (!shen_is_boolean(ctx, t254))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t250 = t254;
  }
    if (!shen_is_boolean(ctx, t250))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t245 = t250;
  }
    if (!shen_is_boolean(ctx, t245))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t242 = t245;
  }
    if (!shen_is_boolean(ctx, t242))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t242)) {
  KLObject* t272 = shen_intern(ctx, "shen.app");
  KLObject* t274 = shen_tl(ctx, t101);
  KLObject* t275 = shen_hd(ctx, t274);
  KLObject* t279 = shen_tl(ctx, t101);
  KLObject* t280 = shen_tl(ctx, t279);
  KLObject* t281 = shen_hd(ctx, t280);
  KLObject* t276;
  {
    KLObject* a276[] = {t100, t281};
    t276 = shen_apply_direct(ctx, "shen.insert-l", 2, a276);
  }
  KLObject* t283 = shen_tl(ctx, t101);
  KLObject* t284 = shen_tl(ctx, t283);
  KLObject* t285 = shen_tl(ctx, t284);
  KLObject* t286 = shen_cons(ctx, t276, t285);
  KLObject* t287 = shen_cons(ctx, t275, t286);
  KLObject* t288 = shen_cons(ctx, t272, t287);
      t102 = t288;
    } else {
  KLObject* t289 = shen_true(ctx);
    if (!shen_is_boolean(ctx, t289))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t289)) {
  KLObject* t291 = shen_string(ctx, "implementation error in shen.insert-l");
  KLObject* t290;
  {
    KLObject* a290[] = {t291};
    t290 = shen_tail_apply_direct(ctx, "simple-error", 1, a290);
  }
      t102 = t290;
    } else {
      shen_simple_error(ctx, "No true case found for cond");
      t102 = shen_empty_list(ctx);
    }
    }
    }
    }
    }
    }
    }
    }
  }
    return t102;
  }
}

static KLObject* native_kl_shen_2efactor_2dcn_7 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t292 = objects[0];
  tail_start_kl_shen_2efactor_2dcn_7: ;
  KLObject* t293;
  {
  KLObject* t296 = shen_cons_p(ctx, t292);
  KLObject* t294;
  if (!shen_is_boolean(ctx, t296))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t296)) {
    t294 = t296;
  } else {
  KLObject* t298 = shen_intern(ctx, "cn");
  KLObject* t300 = shen_hd(ctx, t292);
  KLObject* t301 = shen_eq(ctx, t298, t300);
  KLObject* t297;
  if (!shen_is_boolean(ctx, t301))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t301)) {
    t297 = t301;
  } else {
  KLObject* t304 = shen_tl(ctx, t292);
  KLObject* t305 = shen_cons_p(ctx, t304);
  KLObject* t302;
  if (!shen_is_boolean(ctx, t305))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t305)) {
    t302 = t305;
  } else {
  KLObject* t308 = shen_tl(ctx, t292);
  KLObject* t309 = shen_tl(ctx, t308);
  KLObject* t310 = shen_cons_p(ctx, t309);
  KLObject* t306;
  if (!shen_is_boolean(ctx, t310))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t310)) {
    t306 = t310;
  } else {
  KLObject* t313 = shen_tl(ctx, t292);
  KLObject* t314 = shen_tl(ctx, t313);
  KLObject* t315 = shen_hd(ctx, t314);
  KLObject* t316 = shen_cons_p(ctx, t315);
  KLObject* t311;
  if (!shen_is_boolean(ctx, t316))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t316)) {
    t311 = t316;
  } else {
  KLObject* t318 = shen_intern(ctx, "cn");
  KLObject* t320 = shen_tl(ctx, t292);
  KLObject* t321 = shen_tl(ctx, t320);
  KLObject* t322 = shen_hd(ctx, t321);
  KLObject* t323 = shen_hd(ctx, t322);
  KLObject* t324 = shen_eq(ctx, t318, t323);
  KLObject* t317;
  if (!shen_is_boolean(ctx, t324))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t324)) {
    t317 = t324;
  } else {
  KLObject* t327 = shen_tl(ctx, t292);
  KLObject* t328 = shen_tl(ctx, t327);
  KLObject* t329 = shen_hd(ctx, t328);
  KLObject* t330 = shen_tl(ctx, t329);
  KLObject* t331 = shen_cons_p(ctx, t330);
  KLObject* t325;
  if (!shen_is_boolean(ctx, t331))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t331)) {
    t325 = t331;
  } else {
  KLObject* t334 = shen_tl(ctx, t292);
  KLObject* t335 = shen_tl(ctx, t334);
  KLObject* t336 = shen_hd(ctx, t335);
  KLObject* t337 = shen_tl(ctx, t336);
  KLObject* t338 = shen_tl(ctx, t337);
  KLObject* t339 = shen_cons_p(ctx, t338);
  KLObject* t332;
  if (!shen_is_boolean(ctx, t339))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t339)) {
    t332 = t339;
  } else {
  KLObject* t341 = shen_empty_list(ctx);
  KLObject* t343 = shen_tl(ctx, t292);
  KLObject* t344 = shen_tl(ctx, t343);
  KLObject* t345 = shen_hd(ctx, t344);
  KLObject* t346 = shen_tl(ctx, t345);
  KLObject* t347 = shen_tl(ctx, t346);
  KLObject* t348 = shen_tl(ctx, t347);
  KLObject* t349 = shen_eq(ctx, t341, t348);
  KLObject* t340;
  if (!shen_is_boolean(ctx, t349))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t349)) {
    t340 = t349;
  } else {
  KLObject* t351 = shen_empty_list(ctx);
  KLObject* t353 = shen_tl(ctx, t292);
  KLObject* t354 = shen_tl(ctx, t353);
  KLObject* t355 = shen_tl(ctx, t354);
  KLObject* t356 = shen_eq(ctx, t351, t355);
  KLObject* t350;
  if (!shen_is_boolean(ctx, t356))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t356)) {
    t350 = t356;
  } else {
  KLObject* t359 = shen_tl(ctx, t292);
  KLObject* t360 = shen_hd(ctx, t359);
  KLObject* t361 = shen_string_p(ctx, t360);
  KLObject* t357;
  if (!shen_is_boolean(ctx, t361))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t361)) {
    t357 = t361;
  } else {
  KLObject* t363 = shen_tl(ctx, t292);
  KLObject* t364 = shen_tl(ctx, t363);
  KLObject* t365 = shen_hd(ctx, t364);
  KLObject* t366 = shen_tl(ctx, t365);
  KLObject* t367 = shen_hd(ctx, t366);
  KLObject* t368 = shen_string_p(ctx, t367);
    if (!shen_is_boolean(ctx, t368))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t357 = t368;
  }
    if (!shen_is_boolean(ctx, t357))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t350 = t357;
  }
    if (!shen_is_boolean(ctx, t350))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t340 = t350;
  }
    if (!shen_is_boolean(ctx, t340))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t332 = t340;
  }
    if (!shen_is_boolean(ctx, t332))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t325 = t332;
  }
    if (!shen_is_boolean(ctx, t325))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t317 = t325;
  }
    if (!shen_is_boolean(ctx, t317))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t311 = t317;
  }
    if (!shen_is_boolean(ctx, t311))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t306 = t311;
  }
    if (!shen_is_boolean(ctx, t306))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t302 = t306;
  }
    if (!shen_is_boolean(ctx, t302))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t297 = t302;
  }
    if (!shen_is_boolean(ctx, t297))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t294 = t297;
  }
    if (!shen_is_boolean(ctx, t294))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t294)) {
  KLObject* t369 = shen_intern(ctx, "cn");
  KLObject* t372 = shen_tl(ctx, t292);
  KLObject* t373 = shen_hd(ctx, t372);
  KLObject* t375 = shen_tl(ctx, t292);
  KLObject* t376 = shen_tl(ctx, t375);
  KLObject* t377 = shen_hd(ctx, t376);
  KLObject* t378 = shen_tl(ctx, t377);
  KLObject* t379 = shen_hd(ctx, t378);
  KLObject* t370;
  {
    KLObject* a370[] = {t373, t379};
    t370 = shen_apply_direct(ctx, "cn", 2, a370);
  }
  KLObject* t381 = shen_tl(ctx, t292);
  KLObject* t382 = shen_tl(ctx, t381);
  KLObject* t383 = shen_hd(ctx, t382);
  KLObject* t384 = shen_tl(ctx, t383);
  KLObject* t385 = shen_tl(ctx, t384);
  KLObject* t386 = shen_cons(ctx, t370, t385);
  KLObject* t387 = shen_cons(ctx, t369, t386);
      t293 = t387;
    } else {
  KLObject* t388 = shen_true(ctx);
    if (!shen_is_boolean(ctx, t388))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t388)) {
      t293 = t292;
    } else {
      shen_simple_error(ctx, "No true case found for cond");
      t293 = shen_empty_list(ctx);
    }
    }
  }
    return t293;
  }
}

static KLObject* native_kl_shen_2eproc_2dnl_8 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t390 = objects[0];
  tail_start_kl_shen_2eproc_2dnl_8: ;
  KLObject* t391;
  {
  KLObject* t392 = shen_string(ctx, "");
  KLObject* t394 = shen_eq(ctx, t392, t390);
    if (!shen_is_boolean(ctx, t394))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t394)) {
  KLObject* t395 = shen_string(ctx, "");
      t391 = t395;
    } else {
  KLObject* t397;
  {
    KLObject* a397[] = {t390};
    t397 = shen_apply_direct(ctx, "shen.+string?", 1, a397);
  }
  KLObject* t396;
  if (!shen_is_boolean(ctx, t397))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t397)) {
    t396 = t397;
  } else {
  KLObject* t400 = shen_string(ctx, "~");
  KLObject* t401;
  {
    KLObject* a401[] = {t390};
    t401 = shen_apply_direct(ctx, "hdstr", 1, a401);
  }
  KLObject* t403 = shen_eq(ctx, t400, t401);
  KLObject* t399;
  if (!shen_is_boolean(ctx, t403))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t403)) {
    t399 = t403;
  } else {
  KLObject* t406;
  {
    KLObject* a406[] = {t390};
    t406 = shen_apply_direct(ctx, "tlstr", 1, a406);
  }
  KLObject* t405;
  {
    KLObject* a405[] = {t406};
    t405 = shen_apply_direct(ctx, "shen.+string?", 1, a405);
  }
  KLObject* t404;
  if (!shen_is_boolean(ctx, t405))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t405)) {
    t404 = t405;
  } else {
  KLObject* t408 = shen_string(ctx, "%");
  KLObject* t410;
  {
    KLObject* a410[] = {t390};
    t410 = shen_apply_direct(ctx, "tlstr", 1, a410);
  }
  KLObject* t409;
  {
    KLObject* a409[] = {t410};
    t409 = shen_apply_direct(ctx, "hdstr", 1, a409);
  }
  KLObject* t412 = shen_eq(ctx, t408, t409);
    if (!shen_is_boolean(ctx, t412))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t404 = t412;
  }
    if (!shen_is_boolean(ctx, t404))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t399 = t404;
  }
    if (!shen_is_boolean(ctx, t399))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t396 = t399;
  }
    if (!shen_is_boolean(ctx, t396))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t396)) {
  KLObject* t415 = shen_number_l(ctx, 10);
  KLObject* t414;
  {
    KLObject* a414[] = {t415};
    t414 = shen_apply_direct(ctx, "n->string", 1, a414);
  }
  KLObject* t418;
  {
    KLObject* a418[] = {t390};
    t418 = shen_apply_direct(ctx, "tlstr", 1, a418);
  }
  KLObject* t417;
  {
    KLObject* a417[] = {t418};
    t417 = shen_apply_direct(ctx, "tlstr", 1, a417);
  }
  KLObject* t416;
  {
    KLObject* a416[] = {t417};
    t416 = shen_apply_direct(ctx, "shen.proc-nl", 1, a416);
  }
  KLObject* t413;
  {
    KLObject* a413[] = {t414, t416};
    t413 = shen_tail_apply_direct(ctx, "cn", 2, a413);
  }
      t391 = t413;
    } else {
  KLObject* t420;
  {
    KLObject* a420[] = {t390};
    t420 = shen_apply_direct(ctx, "shen.+string?", 1, a420);
  }
    if (!shen_is_boolean(ctx, t420))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t420)) {
  KLObject* t423;
  {
    KLObject* a423[] = {t390};
    t423 = shen_apply_direct(ctx, "hdstr", 1, a423);
  }
  KLObject* t426;
  {
    KLObject* a426[] = {t390};
    t426 = shen_apply_direct(ctx, "tlstr", 1, a426);
  }
  KLObject* t425;
  {
    KLObject* a425[] = {t426};
    t425 = shen_apply_direct(ctx, "shen.proc-nl", 1, a425);
  }
  KLObject* t422;
  {
    KLObject* a422[] = {t423, t425};
    t422 = shen_tail_apply_direct(ctx, "cn", 2, a422);
  }
      t391 = t422;
    } else {
  KLObject* t428 = shen_true(ctx);
    if (!shen_is_boolean(ctx, t428))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t428)) {
  KLObject* t430 = shen_string(ctx, "implementation error in shen.proc-nl");
  KLObject* t429;
  {
    KLObject* a429[] = {t430};
    t429 = shen_tail_apply_direct(ctx, "simple-error", 1, a429);
  }
      t391 = t429;
    } else {
      shen_simple_error(ctx, "No true case found for cond");
      t391 = shen_empty_list(ctx);
    }
    }
    }
    }
  }
    return t391;
  }
}

static KLObject* native_kl_shen_2emkstr_2dr_9 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t431 = objects[0];
    KLObject* t432 = objects[1];
  tail_start_kl_shen_2emkstr_2dr_9: ;
  KLObject* t433;
  {
  KLObject* t434 = shen_empty_list(ctx);
  KLObject* t436 = shen_eq(ctx, t434, t432);
    if (!shen_is_boolean(ctx, t436))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t436)) {
      t433 = t431;
    } else {
  KLObject* t439 = shen_cons_p(ctx, t432);
    if (!shen_is_boolean(ctx, t439))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t439)) {
  KLObject* t440 = shen_intern(ctx, "shen.insert");
  KLObject* t442 = shen_hd(ctx, t432);
  KLObject* t444 = shen_empty_list(ctx);
  KLObject* t445 = shen_cons(ctx, t431, t444);
  KLObject* t446 = shen_cons(ctx, t442, t445);
  KLObject* t447 = shen_cons(ctx, t440, t446);
  KLObject* t449 = shen_tl(ctx, t432);
  {
    KLObject* n450_0 = t447;
    KLObject* n450_1 = t449;
    t431 = n450_0;
    t432 = n450_1;
    goto tail_start_kl_shen_2emkstr_2dr_9;
  }
  KLObject* t450 = NULL;
      t433 = t450;
    } else {
  KLObject* t451 = shen_true(ctx);
    if (!shen_is_boolean(ctx, t451))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t451)) {
  KLObject* t453 = shen_string(ctx, "implementation error in shen.mkstr-r");
  KLObject* t452;
  {
    KLObject* a452[] = {t453};
    t452 = shen_tail_apply_direct(ctx, "simple-error", 1, a452);
  }
      t433 = t452;
    } else {
      shen_simple_error(ctx, "No true case found for cond");
      t433 = shen_empty_list(ctx);
    }
    }
    }
  }
    return t433;
  }
}

static KLObject* native_kl_shen_2einsert_10 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t454 = objects[0];
    KLObject* t455 = objects[1];
  tail_start_kl_shen_2einsert_10: ;
  KLObject* t459 = shen_string(ctx, "");
  KLObject* t456;
  {
    KLObject* a456[] = {t454, t455, t459};
    t456 = shen_tail_apply_direct(ctx, "shen.insert-h", 3, a456);
  }
    return t456;
  }
}

static KLObject* native_kl_shen_2einsert_2dh_11 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t460 = objects[0];
    KLObject* t461 = objects[1];
    KLObject* t462 = objects[2];
  tail_start_kl_shen_2einsert_2dh_11: ;
  KLObject* t463;
  {
  KLObject* t464 = shen_string(ctx, "");
  KLObject* t466 = shen_eq(ctx, t464, t461);
    if (!shen_is_boolean(ctx, t466))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t466)) {
      t463 = t462;
    } else {
  KLObject* t469;
  {
    KLObject* a469[] = {t461};
    t469 = shen_apply_direct(ctx, "shen.+string?", 1, a469);
  }
  KLObject* t468;
  if (!shen_is_boolean(ctx, t469))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t469)) {
    t468 = t469;
  } else {
  KLObject* t472 = shen_string(ctx, "~");
  KLObject* t473;
  {
    KLObject* a473[] = {t461};
    t473 = shen_apply_direct(ctx, "hdstr", 1, a473);
  }
  KLObject* t475 = shen_eq(ctx, t472, t473);
  KLObject* t471;
  if (!shen_is_boolean(ctx, t475))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t475)) {
    t471 = t475;
  } else {
  KLObject* t478;
  {
    KLObject* a478[] = {t461};
    t478 = shen_apply_direct(ctx, "tlstr", 1, a478);
  }
  KLObject* t477;
  {
    KLObject* a477[] = {t478};
    t477 = shen_apply_direct(ctx, "shen.+string?", 1, a477);
  }
  KLObject* t476;
  if (!shen_is_boolean(ctx, t477))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t477)) {
    t476 = t477;
  } else {
  KLObject* t480 = shen_string(ctx, "A");
  KLObject* t482;
  {
    KLObject* a482[] = {t461};
    t482 = shen_apply_direct(ctx, "tlstr", 1, a482);
  }
  KLObject* t481;
  {
    KLObject* a481[] = {t482};
    t481 = shen_apply_direct(ctx, "hdstr", 1, a481);
  }
  KLObject* t484 = shen_eq(ctx, t480, t481);
    if (!shen_is_boolean(ctx, t484))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t476 = t484;
  }
    if (!shen_is_boolean(ctx, t476))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t471 = t476;
  }
    if (!shen_is_boolean(ctx, t471))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t468 = t471;
  }
    if (!shen_is_boolean(ctx, t468))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t468)) {
  KLObject* t490;
  {
    KLObject* a490[] = {t461};
    t490 = shen_apply_direct(ctx, "tlstr", 1, a490);
  }
  KLObject* t489;
  {
    KLObject* a489[] = {t490};
    t489 = shen_apply_direct(ctx, "tlstr", 1, a489);
  }
  KLObject* t492 = shen_intern(ctx, "shen.a");
  KLObject* t487;
  {
    KLObject* a487[] = {t460, t489, t492};
    t487 = shen_apply_direct(ctx, "shen.app", 3, a487);
  }
  KLObject* t485;
  {
    KLObject* a485[] = {t462, t487};
    t485 = shen_tail_apply_direct(ctx, "cn", 2, a485);
  }
      t463 = t485;
    } else {
  KLObject* t494;
  {
    KLObject* a494[] = {t461};
    t494 = shen_apply_direct(ctx, "shen.+string?", 1, a494);
  }
  KLObject* t493;
  if (!shen_is_boolean(ctx, t494))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t494)) {
    t493 = t494;
  } else {
  KLObject* t497 = shen_string(ctx, "~");
  KLObject* t498;
  {
    KLObject* a498[] = {t461};
    t498 = shen_apply_direct(ctx, "hdstr", 1, a498);
  }
  KLObject* t500 = shen_eq(ctx, t497, t498);
  KLObject* t496;
  if (!shen_is_boolean(ctx, t500))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t500)) {
    t496 = t500;
  } else {
  KLObject* t503;
  {
    KLObject* a503[] = {t461};
    t503 = shen_apply_direct(ctx, "tlstr", 1, a503);
  }
  KLObject* t502;
  {
    KLObject* a502[] = {t503};
    t502 = shen_apply_direct(ctx, "shen.+string?", 1, a502);
  }
  KLObject* t501;
  if (!shen_is_boolean(ctx, t502))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t502)) {
    t501 = t502;
  } else {
  KLObject* t505 = shen_string(ctx, "R");
  KLObject* t507;
  {
    KLObject* a507[] = {t461};
    t507 = shen_apply_direct(ctx, "tlstr", 1, a507);
  }
  KLObject* t506;
  {
    KLObject* a506[] = {t507};
    t506 = shen_apply_direct(ctx, "hdstr", 1, a506);
  }
  KLObject* t509 = shen_eq(ctx, t505, t506);
    if (!shen_is_boolean(ctx, t509))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t501 = t509;
  }
    if (!shen_is_boolean(ctx, t501))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t496 = t501;
  }
    if (!shen_is_boolean(ctx, t496))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t493 = t496;
  }
    if (!shen_is_boolean(ctx, t493))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t493)) {
  KLObject* t515;
  {
    KLObject* a515[] = {t461};
    t515 = shen_apply_direct(ctx, "tlstr", 1, a515);
  }
  KLObject* t514;
  {
    KLObject* a514[] = {t515};
    t514 = shen_apply_direct(ctx, "tlstr", 1, a514);
  }
  KLObject* t517 = shen_intern(ctx, "shen.r");
  KLObject* t512;
  {
    KLObject* a512[] = {t460, t514, t517};
    t512 = shen_apply_direct(ctx, "shen.app", 3, a512);
  }
  KLObject* t510;
  {
    KLObject* a510[] = {t462, t512};
    t510 = shen_tail_apply_direct(ctx, "cn", 2, a510);
  }
      t463 = t510;
    } else {
  KLObject* t519;
  {
    KLObject* a519[] = {t461};
    t519 = shen_apply_direct(ctx, "shen.+string?", 1, a519);
  }
  KLObject* t518;
  if (!shen_is_boolean(ctx, t519))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t519)) {
    t518 = t519;
  } else {
  KLObject* t522 = shen_string(ctx, "~");
  KLObject* t523;
  {
    KLObject* a523[] = {t461};
    t523 = shen_apply_direct(ctx, "hdstr", 1, a523);
  }
  KLObject* t525 = shen_eq(ctx, t522, t523);
  KLObject* t521;
  if (!shen_is_boolean(ctx, t525))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t525)) {
    t521 = t525;
  } else {
  KLObject* t528;
  {
    KLObject* a528[] = {t461};
    t528 = shen_apply_direct(ctx, "tlstr", 1, a528);
  }
  KLObject* t527;
  {
    KLObject* a527[] = {t528};
    t527 = shen_apply_direct(ctx, "shen.+string?", 1, a527);
  }
  KLObject* t526;
  if (!shen_is_boolean(ctx, t527))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t527)) {
    t526 = t527;
  } else {
  KLObject* t530 = shen_string(ctx, "S");
  KLObject* t532;
  {
    KLObject* a532[] = {t461};
    t532 = shen_apply_direct(ctx, "tlstr", 1, a532);
  }
  KLObject* t531;
  {
    KLObject* a531[] = {t532};
    t531 = shen_apply_direct(ctx, "hdstr", 1, a531);
  }
  KLObject* t534 = shen_eq(ctx, t530, t531);
    if (!shen_is_boolean(ctx, t534))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t526 = t534;
  }
    if (!shen_is_boolean(ctx, t526))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t521 = t526;
  }
    if (!shen_is_boolean(ctx, t521))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t518 = t521;
  }
    if (!shen_is_boolean(ctx, t518))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t518)) {
  KLObject* t540;
  {
    KLObject* a540[] = {t461};
    t540 = shen_apply_direct(ctx, "tlstr", 1, a540);
  }
  KLObject* t539;
  {
    KLObject* a539[] = {t540};
    t539 = shen_apply_direct(ctx, "tlstr", 1, a539);
  }
  KLObject* t542 = shen_intern(ctx, "shen.s");
  KLObject* t537;
  {
    KLObject* a537[] = {t460, t539, t542};
    t537 = shen_apply_direct(ctx, "shen.app", 3, a537);
  }
  KLObject* t535;
  {
    KLObject* a535[] = {t462, t537};
    t535 = shen_tail_apply_direct(ctx, "cn", 2, a535);
  }
      t463 = t535;
    } else {
  KLObject* t543;
  {
    KLObject* a543[] = {t461};
    t543 = shen_apply_direct(ctx, "shen.+string?", 1, a543);
  }
    if (!shen_is_boolean(ctx, t543))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t543)) {
  KLObject* t546;
  {
    KLObject* a546[] = {t461};
    t546 = shen_apply_direct(ctx, "tlstr", 1, a546);
  }
  KLObject* t550;
  {
    KLObject* a550[] = {t461};
    t550 = shen_apply_direct(ctx, "hdstr", 1, a550);
  }
  KLObject* t548;
  {
    KLObject* a548[] = {t462, t550};
    t548 = shen_apply_direct(ctx, "cn", 2, a548);
  }
  {
    KLObject* n552_0 = t460;
    KLObject* n552_1 = t546;
    KLObject* n552_2 = t548;
    t460 = n552_0;
    t461 = n552_1;
    t462 = n552_2;
    goto tail_start_kl_shen_2einsert_2dh_11;
  }
  KLObject* t552 = NULL;
      t463 = t552;
    } else {
  KLObject* t553 = shen_true(ctx);
    if (!shen_is_boolean(ctx, t553))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t553)) {
  KLObject* t555 = shen_string(ctx, "implementation error in shen.insert-h");
  KLObject* t554;
  {
    KLObject* a554[] = {t555};
    t554 = shen_tail_apply_direct(ctx, "simple-error", 1, a554);
  }
      t463 = t554;
    } else {
      shen_simple_error(ctx, "No true case found for cond");
      t463 = shen_empty_list(ctx);
    }
    }
    }
    }
    }
    }
  }
    return t463;
  }
}

static KLObject* native_kl_shen_2eapp_12 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t556 = objects[0];
    KLObject* t557 = objects[1];
    KLObject* t558 = objects[2];
  tail_start_kl_shen_2eapp_12: ;
  KLObject* t560;
  {
    KLObject* a560[] = {t556, t558};
    t560 = shen_apply_direct(ctx, "shen.arg->str", 2, a560);
  }
  KLObject* t559;
  {
    KLObject* a559[] = {t560, t557};
    t559 = shen_tail_apply_direct(ctx, "cn", 2, a559);
  }
    return t559;
  }
}

static KLObject* native_kl_shen_2earg_2d_3estr_13 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t564 = objects[0];
    KLObject* t565 = objects[1];
  tail_start_kl_shen_2earg_2d_3estr_13: ;
  KLObject* t566;
  {
  KLObject* t568 = shen_apply_direct(ctx, "fail", 0, NULL);
  KLObject* t569 = shen_eq(ctx, t564, t568);
    if (!shen_is_boolean(ctx, t569))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t569)) {
  KLObject* t570 = shen_string(ctx, "...");
      t566 = t570;
    } else {
  KLObject* t571;
  {
    KLObject* a571[] = {t564};
    t571 = shen_apply_direct(ctx, "shen.list?", 1, a571);
  }
    if (!shen_is_boolean(ctx, t571))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t571)) {
  KLObject* t573;
  {
    KLObject* a573[] = {t564, t565};
    t573 = shen_tail_apply_direct(ctx, "shen.list->str", 2, a573);
  }
      t566 = t573;
    } else {
  KLObject* t577 = shen_string_p(ctx, t564);
    if (!shen_is_boolean(ctx, t577))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t577)) {
  KLObject* t578;
  {
    KLObject* a578[] = {t564, t565};
    t578 = shen_tail_apply_direct(ctx, "shen.str->str", 2, a578);
  }
      t566 = t578;
    } else {
  KLObject* t582 = shen_absvector_p(ctx, t564);
    if (!shen_is_boolean(ctx, t582))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t582)) {
  KLObject* t583;
  {
    KLObject* a583[] = {t564, t565};
    t583 = shen_tail_apply_direct(ctx, "shen.vector->str", 2, a583);
  }
      t566 = t583;
    } else {
  KLObject* t586 = shen_true(ctx);
    if (!shen_is_boolean(ctx, t586))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t586)) {
  KLObject* t587;
  {
    KLObject* a587[] = {t564};
    t587 = shen_tail_apply_direct(ctx, "shen.atom->str", 1, a587);
  }
      t566 = t587;
    } else {
      shen_simple_error(ctx, "No true case found for cond");
      t566 = shen_empty_list(ctx);
    }
    }
    }
    }
    }
  }
    return t566;
  }
}

static KLObject* native_kl_shen_2elist_2d_3estr_14 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t589 = objects[0];
    KLObject* t590 = objects[1];
  tail_start_kl_shen_2elist_2d_3estr_14: ;
  KLObject* t591;
  {
  KLObject* t592 = shen_intern(ctx, "shen.r");
  KLObject* t594 = shen_eq(ctx, t592, t590);
    if (!shen_is_boolean(ctx, t594))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t594)) {
  KLObject* t596 = shen_string(ctx, "(");
  KLObject* t600 = shen_intern(ctx, "shen.r");
  KLObject* t601 = shen_apply_direct(ctx, "shen.maxseq", 0, NULL);
  KLObject* t598;
  {
    KLObject* a598[] = {t589, t600, t601};
    t598 = shen_apply_direct(ctx, "shen.iter-list", 3, a598);
  }
  KLObject* t602 = shen_string(ctx, ")");
  KLObject* t597;
  {
    KLObject* a597[] = {t598, t602};
    t597 = shen_apply_direct(ctx, "@s", 2, a597);
  }
  KLObject* t595;
  {
    KLObject* a595[] = {t596, t597};
    t595 = shen_tail_apply_direct(ctx, "@s", 2, a595);
  }
      t591 = t595;
    } else {
  KLObject* t603 = shen_true(ctx);
    if (!shen_is_boolean(ctx, t603))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t603)) {
  KLObject* t605 = shen_string(ctx, "[");
  KLObject* t610 = shen_apply_direct(ctx, "shen.maxseq", 0, NULL);
  KLObject* t607;
  {
    KLObject* a607[] = {t589, t590, t610};
    t607 = shen_apply_direct(ctx, "shen.iter-list", 3, a607);
  }
  KLObject* t611 = shen_string(ctx, "]");
  KLObject* t606;
  {
    KLObject* a606[] = {t607, t611};
    t606 = shen_apply_direct(ctx, "@s", 2, a606);
  }
  KLObject* t604;
  {
    KLObject* a604[] = {t605, t606};
    t604 = shen_tail_apply_direct(ctx, "@s", 2, a604);
  }
      t591 = t604;
    } else {
      shen_simple_error(ctx, "No true case found for cond");
      t591 = shen_empty_list(ctx);
    }
    }
  }
    return t591;
  }
}

static KLObject* native_kl_shen_2emaxseq_15 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  (void)function_object;
  (void)arguments;
  {
  tail_start_kl_shen_2emaxseq_15: ;
  KLObject* t613 = shen_intern(ctx, "*maximum-print-sequence-size*");
  KLObject* t612;
  {
    KLObject* a612[] = {t613};
    t612 = shen_tail_apply_direct(ctx, "value", 1, a612);
  }
    return t612;
  }
}

static KLObject* native_kl_shen_2eiter_2dlist_16 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t614 = objects[0];
    KLObject* t615 = objects[1];
    KLObject* t616 = objects[2];
  tail_start_kl_shen_2eiter_2dlist_16: ;
  KLObject* t617;
  {
  KLObject* t618 = shen_empty_list(ctx);
  KLObject* t620 = shen_eq(ctx, t618, t614);
    if (!shen_is_boolean(ctx, t620))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t620)) {
  KLObject* t621 = shen_string(ctx, "");
      t617 = t621;
    } else {
  KLObject* t622 = shen_number_l(ctx, 0);
  KLObject* t624 = shen_eq(ctx, t622, t616);
    if (!shen_is_boolean(ctx, t624))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t624)) {
  KLObject* t625 = shen_string(ctx, "... etc");
      t617 = t625;
    } else {
  KLObject* t628 = shen_cons_p(ctx, t614);
  KLObject* t626;
  if (!shen_is_boolean(ctx, t628))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t628)) {
    t626 = t628;
  } else {
  KLObject* t629 = shen_empty_list(ctx);
  KLObject* t631 = shen_tl(ctx, t614);
  KLObject* t632 = shen_eq(ctx, t629, t631);
    if (!shen_is_boolean(ctx, t632))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t626 = t632;
  }
    if (!shen_is_boolean(ctx, t626))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t626)) {
  KLObject* t635 = shen_hd(ctx, t614);
  KLObject* t633;
  {
    KLObject* a633[] = {t635, t615};
    t633 = shen_tail_apply_direct(ctx, "shen.arg->str", 2, a633);
  }
      t617 = t633;
    } else {
  KLObject* t638 = shen_cons_p(ctx, t614);
    if (!shen_is_boolean(ctx, t638))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t638)) {
  KLObject* t642 = shen_hd(ctx, t614);
  KLObject* t640;
  {
    KLObject* a640[] = {t642, t615};
    t640 = shen_apply_direct(ctx, "shen.arg->str", 2, a640);
  }
  KLObject* t645 = shen_string(ctx, " ");
  KLObject* t648 = shen_tl(ctx, t614);
  KLObject* t651 = shen_number_l(ctx, 1);
  KLObject* t652 = shen_sub(ctx, t616, t651);
  KLObject* t646;
  {
    KLObject* a646[] = {t648, t615, t652};
    t646 = shen_apply_direct(ctx, "shen.iter-list", 3, a646);
  }
  KLObject* t644;
  {
    KLObject* a644[] = {t645, t646};
    t644 = shen_apply_direct(ctx, "@s", 2, a644);
  }
  KLObject* t639;
  {
    KLObject* a639[] = {t640, t644};
    t639 = shen_tail_apply_direct(ctx, "@s", 2, a639);
  }
      t617 = t639;
    } else {
  KLObject* t653 = shen_true(ctx);
    if (!shen_is_boolean(ctx, t653))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t653)) {
  KLObject* t655 = shen_string(ctx, "|");
  KLObject* t657 = shen_string(ctx, " ");
  KLObject* t658;
  {
    KLObject* a658[] = {t614, t615};
    t658 = shen_apply_direct(ctx, "shen.arg->str", 2, a658);
  }
  KLObject* t656;
  {
    KLObject* a656[] = {t657, t658};
    t656 = shen_apply_direct(ctx, "@s", 2, a656);
  }
  KLObject* t654;
  {
    KLObject* a654[] = {t655, t656};
    t654 = shen_tail_apply_direct(ctx, "@s", 2, a654);
  }
      t617 = t654;
    } else {
      shen_simple_error(ctx, "No true case found for cond");
      t617 = shen_empty_list(ctx);
    }
    }
    }
    }
    }
  }
    return t617;
  }
}

static KLObject* native_kl_shen_2estr_2d_3estr_17 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t661 = objects[0];
    KLObject* t662 = objects[1];
  tail_start_kl_shen_2estr_2d_3estr_17: ;
  KLObject* t663;
  {
  KLObject* t664 = shen_intern(ctx, "shen.a");
  KLObject* t666 = shen_eq(ctx, t664, t662);
    if (!shen_is_boolean(ctx, t666))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t666)) {
      t663 = t661;
    } else {
  KLObject* t668 = shen_true(ctx);
    if (!shen_is_boolean(ctx, t668))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t668)) {
  KLObject* t671 = shen_number_l(ctx, 34);
  KLObject* t670;
  {
    KLObject* a670[] = {t671};
    t670 = shen_apply_direct(ctx, "n->string", 1, a670);
  }
  KLObject* t675 = shen_number_l(ctx, 34);
  KLObject* t674;
  {
    KLObject* a674[] = {t675};
    t674 = shen_apply_direct(ctx, "n->string", 1, a674);
  }
  KLObject* t672;
  {
    KLObject* a672[] = {t661, t674};
    t672 = shen_apply_direct(ctx, "@s", 2, a672);
  }
  KLObject* t669;
  {
    KLObject* a669[] = {t670, t672};
    t669 = shen_tail_apply_direct(ctx, "@s", 2, a669);
  }
      t663 = t669;
    } else {
      shen_simple_error(ctx, "No true case found for cond");
      t663 = shen_empty_list(ctx);
    }
    }
  }
    return t663;
  }
}

static KLObject* native_kl_shen_2evector_2d_3estr_18 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t676 = objects[0];
    KLObject* t677 = objects[1];
  tail_start_kl_shen_2evector_2d_3estr_18: ;
  KLObject* t679;
  {
    KLObject* a679[] = {t676};
    t679 = shen_apply_direct(ctx, "shen.print-vector?", 1, a679);
  }
  KLObject* t678;
  if (!shen_is_boolean(ctx, t679))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t679)) {
  KLObject* t685 = shen_number_l(ctx, 0);
  KLObject* t683;
  {
    KLObject* a683[] = {t676, t685};
    t683 = shen_apply_direct(ctx, "<-address", 2, a683);
  }
  KLObject* t682;
  {
    KLObject* a682[] = {t683};
    t682 = shen_apply_direct(ctx, "fn", 1, a682);
  }
  KLObject* t681;
  {
    Vector* a681 = shen_vector(ctx, 1);
    shen_vector_set(ctx, a681, 0, t676);
    t681 = shen_tail_apply(ctx, t682, a681);
  }
    t678 = t681;
  } else {
  KLObject* t688;
  {
    KLObject* a688[] = {t676};
    t688 = shen_apply_direct(ctx, "vector?", 1, a688);
  }
  KLObject* t687;
  if (!shen_is_boolean(ctx, t688))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t688)) {
  KLObject* t691 = shen_string(ctx, "<");
  KLObject* t695 = shen_number_l(ctx, 1);
  KLObject* t697 = shen_apply_direct(ctx, "shen.maxseq", 0, NULL);
  KLObject* t693;
  {
    KLObject* a693[] = {t676, t695, t677, t697};
    t693 = shen_apply_direct(ctx, "shen.iter-vector", 4, a693);
  }
  KLObject* t698 = shen_string(ctx, ">");
  KLObject* t692;
  {
    KLObject* a692[] = {t693, t698};
    t692 = shen_apply_direct(ctx, "@s", 2, a692);
  }
  KLObject* t690;
  {
    KLObject* a690[] = {t691, t692};
    t690 = shen_tail_apply_direct(ctx, "@s", 2, a690);
  }
    t687 = t690;
  } else {
  KLObject* t700 = shen_string(ctx, "<");
  KLObject* t702 = shen_string(ctx, "<");
  KLObject* t706 = shen_number_l(ctx, 0);
  KLObject* t708 = shen_apply_direct(ctx, "shen.maxseq", 0, NULL);
  KLObject* t704;
  {
    KLObject* a704[] = {t676, t706, t677, t708};
    t704 = shen_apply_direct(ctx, "shen.iter-vector", 4, a704);
  }
  KLObject* t709 = shen_string(ctx, ">>");
  KLObject* t703;
  {
    KLObject* a703[] = {t704, t709};
    t703 = shen_apply_direct(ctx, "@s", 2, a703);
  }
  KLObject* t701;
  {
    KLObject* a701[] = {t702, t703};
    t701 = shen_apply_direct(ctx, "@s", 2, a701);
  }
  KLObject* t699;
  {
    KLObject* a699[] = {t700, t701};
    t699 = shen_tail_apply_direct(ctx, "@s", 2, a699);
  }
    t687 = t699;
  }
    t678 = t687;
  }
    return t678;
  }
}

static KLObject* native_kl_shen_2eprint_2dvector_3f_19 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t710 = objects[0];
  tail_start_kl_shen_2eprint_2dvector_3f_19: ;
  KLObject* t713 = shen_number_l(ctx, 0);
  KLObject* t711;
  {
    KLObject* a711[] = {t710, t713};
    t711 = shen_apply_direct(ctx, "<-address", 2, a711);
  }
  KLObject* t716 = shen_intern(ctx, "shen.tuple");
  KLObject* t717 = shen_eq(ctx, t711, t716);
  KLObject* t714;
  if (!shen_is_boolean(ctx, t717))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t717)) {
  KLObject* t718 = shen_true(ctx);
    t714 = t718;
  } else {
  KLObject* t721 = shen_intern(ctx, "shen.pvar");
  KLObject* t722 = shen_eq(ctx, t711, t721);
  KLObject* t719;
  if (!shen_is_boolean(ctx, t722))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t722)) {
  KLObject* t723 = shen_true(ctx);
    t719 = t723;
  } else {
  KLObject* t727 = shen_number_p(ctx, t711);
  KLObject* t725;
  {
    KLObject* a725[] = {t727};
    t725 = shen_apply_direct(ctx, "not", 1, a725);
  }
  KLObject* t724;
  if (!shen_is_boolean(ctx, t725))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t725)) {
  KLObject* t728;
  {
    KLObject* a728[] = {t711};
    t728 = shen_tail_apply_direct(ctx, "shen.fbound?", 1, a728);
  }
    t724 = t728;
  } else {
  KLObject* t730 = shen_false(ctx);
    t724 = t730;
  }
    t719 = t724;
  }
    t714 = t719;
  }
    return t714;
  }
}

static KLObject* native_kl_shen_2efbound_3f_20 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t731 = objects[0];
  tail_start_kl_shen_2efbound_3f_20: ;
  KLObject* t733;
  {
    KLObject* a733[] = {t731};
    t733 = shen_apply_direct(ctx, "arity", 1, a733);
  }
  KLObject* t735 = shen_number_l(ctx, -1);
  KLObject* t736 = shen_eq(ctx, t733, t735);
  KLObject* t732;
  {
    KLObject* a732[] = {t736};
    t732 = shen_tail_apply_direct(ctx, "not", 1, a732);
  }
    return t732;
  }
}

static KLObject* native_kl_shen_2etuple_21 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t737 = objects[0];
  tail_start_kl_shen_2etuple_21: ;
  KLObject* t739 = shen_string(ctx, "(@p ");
  KLObject* t743 = shen_number_l(ctx, 1);
  KLObject* t741;
  {
    KLObject* a741[] = {t737, t743};
    t741 = shen_apply_direct(ctx, "<-address", 2, a741);
  }
  KLObject* t745 = shen_string(ctx, " ");
  KLObject* t749 = shen_number_l(ctx, 2);
  KLObject* t747;
  {
    KLObject* a747[] = {t737, t749};
    t747 = shen_apply_direct(ctx, "<-address", 2, a747);
  }
  KLObject* t750 = shen_string(ctx, ")");
  KLObject* t751 = shen_intern(ctx, "shen.s");
  KLObject* t746;
  {
    KLObject* a746[] = {t747, t750, t751};
    t746 = shen_apply_direct(ctx, "shen.app", 3, a746);
  }
  KLObject* t744;
  {
    KLObject* a744[] = {t745, t746};
    t744 = shen_apply_direct(ctx, "cn", 2, a744);
  }
  KLObject* t752 = shen_intern(ctx, "shen.s");
  KLObject* t740;
  {
    KLObject* a740[] = {t741, t744, t752};
    t740 = shen_apply_direct(ctx, "shen.app", 3, a740);
  }
  KLObject* t738;
  {
    KLObject* a738[] = {t739, t740};
    t738 = shen_tail_apply_direct(ctx, "cn", 2, a738);
  }
    return t738;
  }
}

static KLObject* native_kl_shen_2eiter_2dvector_22 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t753 = objects[0];
    KLObject* t754 = objects[1];
    KLObject* t755 = objects[2];
    KLObject* t756 = objects[3];
  tail_start_kl_shen_2eiter_2dvector_22: ;
  KLObject* t757;
  {
  KLObject* t758 = shen_number_l(ctx, 0);
  KLObject* t760 = shen_eq(ctx, t758, t756);
    if (!shen_is_boolean(ctx, t760))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t760)) {
  KLObject* t761 = shen_string(ctx, "... etc");
      t757 = t761;
    } else {
  KLObject* t762 = shen_true(ctx);
    if (!shen_is_boolean(ctx, t762))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t762)) {
  KLObject* t763;
  {
    Vector* tenv_1 = shen_vector(ctx, 4);
    shen_vector_set(ctx, tenv_1, 0, t753);
    shen_vector_set(ctx, tenv_1, 1, t754);
    shen_vector_set(ctx, tenv_1, 2, t755);
    shen_vector_set(ctx, tenv_1, 3, t756);
    t763 = shen_trap_error(ctx, trap_body_1, trap_handler_1, tenv_1);
  }
  KLObject* t779;
  {
    Vector* tenv_2 = shen_vector(ctx, 5);
    shen_vector_set(ctx, tenv_2, 0, t753);
    shen_vector_set(ctx, tenv_2, 1, t754);
    shen_vector_set(ctx, tenv_2, 2, t755);
    shen_vector_set(ctx, tenv_2, 3, t756);
    shen_vector_set(ctx, tenv_2, 4, t763);
    t779 = shen_trap_error(ctx, trap_body_2, trap_handler_2, tenv_2);
  }
  KLObject* t801 = shen_intern(ctx, "shen.out-of-bounds");
  KLObject* t802 = shen_eq(ctx, t763, t801);
  KLObject* t799;
  if (!shen_is_boolean(ctx, t802))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t802)) {
  KLObject* t803 = shen_string(ctx, "");
    t799 = t803;
  } else {
  KLObject* t806 = shen_intern(ctx, "shen.out-of-bounds");
  KLObject* t807 = shen_eq(ctx, t779, t806);
  KLObject* t804;
  if (!shen_is_boolean(ctx, t807))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t807)) {
  KLObject* t808;
  {
    KLObject* a808[] = {t763, t755};
    t808 = shen_tail_apply_direct(ctx, "shen.arg->str", 2, a808);
  }
    t804 = t808;
  } else {
  KLObject* t812;
  {
    KLObject* a812[] = {t763, t755};
    t812 = shen_apply_direct(ctx, "shen.arg->str", 2, a812);
  }
  KLObject* t816 = shen_string(ctx, " ");
  KLObject* t820 = shen_number_l(ctx, 1);
  KLObject* t821 = shen_add(ctx, t754, t820);
  KLObject* t824 = shen_number_l(ctx, 1);
  KLObject* t825 = shen_sub(ctx, t756, t824);
  KLObject* t817;
  {
    KLObject* a817[] = {t753, t821, t755, t825};
    t817 = shen_apply_direct(ctx, "shen.iter-vector", 4, a817);
  }
  KLObject* t815;
  {
    KLObject* a815[] = {t816, t817};
    t815 = shen_apply_direct(ctx, "@s", 2, a815);
  }
  KLObject* t811;
  {
    KLObject* a811[] = {t812, t815};
    t811 = shen_tail_apply_direct(ctx, "@s", 2, a811);
  }
    t804 = t811;
  }
    t799 = t804;
  }
      t757 = t799;
    } else {
      shen_simple_error(ctx, "No true case found for cond");
      t757 = shen_empty_list(ctx);
    }
    }
  }
    return t757;
  }
}

static KLObject* native_kl_shen_2eatom_2d_3estr_23 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t826 = objects[0];
  tail_start_kl_shen_2eatom_2d_3estr_23: ;
  KLObject* t827;
  {
    Vector* tenv_3 = shen_vector(ctx, 1);
    shen_vector_set(ctx, tenv_3, 0, t826);
    t827 = shen_trap_error(ctx, trap_body_3, trap_handler_3, tenv_3);
  }
    return t827;
  }
}

static KLObject* native_kl_shen_2efunexstring_24 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  (void)function_object;
  (void)arguments;
  {
  tail_start_kl_shen_2efunexstring_24: ;
  KLObject* t837 = shen_string(ctx, "\020");
  KLObject* t839 = shen_string(ctx, "f");
  KLObject* t841 = shen_string(ctx, "u");
  KLObject* t843 = shen_string(ctx, "n");
  KLObject* t845 = shen_string(ctx, "e");
  KLObject* t850 = shen_string(ctx, "x");
  KLObject* t849;
  {
    KLObject* a849[] = {t850};
    t849 = shen_apply_direct(ctx, "intern", 1, a849);
  }
  KLObject* t848;
  {
    KLObject* a848[] = {t849};
    t848 = shen_apply_direct(ctx, "gensym", 1, a848);
  }
  KLObject* t851 = shen_intern(ctx, "shen.a");
  KLObject* t847;
  {
    KLObject* a847[] = {t848, t851};
    t847 = shen_apply_direct(ctx, "shen.arg->str", 2, a847);
  }
  KLObject* t852 = shen_string(ctx, "\021");
  KLObject* t846;
  {
    KLObject* a846[] = {t847, t852};
    t846 = shen_apply_direct(ctx, "@s", 2, a846);
  }
  KLObject* t844;
  {
    KLObject* a844[] = {t845, t846};
    t844 = shen_apply_direct(ctx, "@s", 2, a844);
  }
  KLObject* t842;
  {
    KLObject* a842[] = {t843, t844};
    t842 = shen_apply_direct(ctx, "@s", 2, a842);
  }
  KLObject* t840;
  {
    KLObject* a840[] = {t841, t842};
    t840 = shen_apply_direct(ctx, "@s", 2, a840);
  }
  KLObject* t838;
  {
    KLObject* a838[] = {t839, t840};
    t838 = shen_apply_direct(ctx, "@s", 2, a838);
  }
  KLObject* t836;
  {
    KLObject* a836[] = {t837, t838};
    t836 = shen_tail_apply_direct(ctx, "@s", 2, a836);
  }
    return t836;
  }
}

static KLObject* native_kl_shen_2elist_3f_25 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t853 = objects[0];
  tail_start_kl_shen_2elist_3f_25: ;
  KLObject* t855;
  {
    KLObject* a855[] = {t853};
    t855 = shen_apply_direct(ctx, "empty?", 1, a855);
  }
  KLObject* t854;
  if (!shen_is_boolean(ctx, t855))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (shen_boolean_value(ctx, t855)) {
    t854 = t855;
  } else {
  KLObject* t858 = shen_cons_p(ctx, t853);
    if (!shen_is_boolean(ctx, t858))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t854 = t858;
  }
    return t854;
  }
}

void shen_kernel_aot_install_writer (shen_context* ctx)
{
  shen_register_defun(ctx, "print", 1, &native_kl_print_0);
  shen_register_defun(ctx, "pr", 2, &native_kl_pr_1);
  shen_register_defun(ctx, "shen.string->byte", 2, &native_kl_shen_2estring_2d_3ebyte_2);
  shen_register_defun(ctx, "shen.write-chars", 4, &native_kl_shen_2ewrite_2dchars_3);
  shen_register_defun(ctx, "shen.mkstr", 2, &native_kl_shen_2emkstr_4);
  shen_register_defun(ctx, "shen.mkstr-l", 2, &native_kl_shen_2emkstr_2dl_5);
  shen_register_defun(ctx, "shen.insert-l", 2, &native_kl_shen_2einsert_2dl_6);
  shen_register_defun(ctx, "shen.factor-cn", 1, &native_kl_shen_2efactor_2dcn_7);
  shen_register_defun(ctx, "shen.proc-nl", 1, &native_kl_shen_2eproc_2dnl_8);
  shen_register_defun(ctx, "shen.mkstr-r", 2, &native_kl_shen_2emkstr_2dr_9);
  shen_register_defun(ctx, "shen.insert", 2, &native_kl_shen_2einsert_10);
  shen_register_defun(ctx, "shen.insert-h", 3, &native_kl_shen_2einsert_2dh_11);
  shen_register_defun(ctx, "shen.app", 3, &native_kl_shen_2eapp_12);
  shen_register_defun(ctx, "shen.arg->str", 2, &native_kl_shen_2earg_2d_3estr_13);
  shen_register_defun(ctx, "shen.list->str", 2, &native_kl_shen_2elist_2d_3estr_14);
  shen_register_defun(ctx, "shen.maxseq", 0, &native_kl_shen_2emaxseq_15);
  shen_register_defun(ctx, "shen.iter-list", 3, &native_kl_shen_2eiter_2dlist_16);
  shen_register_defun(ctx, "shen.str->str", 2, &native_kl_shen_2estr_2d_3estr_17);
  shen_register_defun(ctx, "shen.vector->str", 2, &native_kl_shen_2evector_2d_3estr_18);
  shen_register_defun(ctx, "shen.print-vector?", 1, &native_kl_shen_2eprint_2dvector_3f_19);
  shen_register_defun(ctx, "shen.fbound?", 1, &native_kl_shen_2efbound_3f_20);
  shen_register_defun(ctx, "shen.tuple", 1, &native_kl_shen_2etuple_21);
  shen_register_defun(ctx, "shen.iter-vector", 4, &native_kl_shen_2eiter_2dvector_22);
  shen_register_defun(ctx, "shen.atom->str", 1, &native_kl_shen_2eatom_2d_3estr_23);
  shen_register_defun(ctx, "shen.funexstring", 0, &native_kl_shen_2efunexstring_24);
  shen_register_defun(ctx, "shen.list?", 1, &native_kl_shen_2elist_3f_25);
}
