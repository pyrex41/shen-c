#include "rc_phase_profile.h"
/* Generated always-AOT kernel module (KL defuns -> NativeFunctions).
 * Install after tree-walker boot overwrites UserFunctions.
 * Toplevel declare/set stay on the walker. Not overlay-after-load.
 * Sidecar tests stay on the tree-walker. Not a second main. Source: yacc.kl
 */
#include "abi.h"

void shen_kernel_aot_install_yacc (shen_context* ctx);

static KLObject* lambda_0 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t96 = objects[0];
  KLObject* t97;
  {
    KLObject* a97[] = {t96};
    t97 = shen_tail_apply_direct(ctx, "shen.<yacc>", 1, a97);
  }
    return t97;
  }
}

static KLObject* lambda_1 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t459 = objects[0];
  KLObject* t460;
  {
    KLObject* a460[] = {t459};
    t460 = shen_tail_apply_direct(ctx, "shen.<non-terminal?>", 1, a460);
  }
    return t460;
  }
}

static KLObject* lambda_2 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  Vector* caps = shen_native_captures(ctx, function_object);
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t1747 = objects[0];
  KLObject* t1748;
  {
    KLObject* a1748[] = {t1747};
    t1748 = shen_tail_apply_direct(ctx, "shen.process-yacc-semantics", 1, a1748);
  }
    return t1748;
  }
}

static KLObject* native_kl_compile_0 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t0 = objects[0];
    KLObject* t1 = objects[1];
  tail_start_kl_compile_0: ;
  KLObject* t2;
  {
    Vector* a2 = shen_vector(ctx, 1);
    shen_vector_set(ctx, a2, 0, t1);
    t2 = shen_apply(ctx, t0, a2);
  }
  KLObject* t6;
  {
    KLObject* a6[] = {t2};
    t6 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a6);
  }
  KLObject* t5;
  if (!shen_is_boolean(ctx, t6))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t6)) {
  KLObject* t9 = shen_string(ctx, "parse failure\n");
  KLObject* t8;
  {
    KLObject* a8[] = {t9};
    t8 = shen_tail_apply_direct(ctx, "simple-error", 1, a8);
  }
    t5 = t8;
  } else {
  KLObject* t11;
  {
    KLObject* a11[] = {t2};
    t11 = shen_apply_direct(ctx, "shen.partial-parse-failure?", 1, a11);
  }
  KLObject* t10;
  if (!shen_is_boolean(ctx, t11))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t11)) {
  KLObject* t14 = shen_intern(ctx, "shen.*residue*");
  KLObject* t15;
  {
    KLObject* a15[] = {t2};
    t15 = shen_apply_direct(ctx, "shen.in->", 1, a15);
  }
  KLObject* t13;
  {
    KLObject* a13[] = {t14, t15};
    t13 = shen_apply_direct(ctx, "set", 2, a13);
  }
  KLObject* t19 = shen_intern(ctx, "shen.*residue*");
  KLObject* t18;
  {
    KLObject* a18[] = {t19};
    t18 = shen_apply_direct(ctx, "value", 1, a18);
  }
  KLObject* t17;
  {
    KLObject* a17[] = {t18};
    t17 = shen_tail_apply_direct(ctx, "shen.raise-syntax-error", 1, a17);
  }
    t10 = t17;
  } else {
  KLObject* t20;
  {
    KLObject* a20[] = {t2};
    t20 = shen_tail_apply_direct(ctx, "shen.<-out", 1, a20);
  }
    t10 = t20;
  }
    t5 = t10;
  }
    return t5;
  }
}

static KLObject* native_kl_shen_2eraise_2dsyntax_2derror_1 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t22 = objects[0];
  tail_start_kl_shen_2eraise_2dsyntax_2derror_1: ;
  KLObject* t26 = shen_string(ctx, "syntax error here: ");
  KLObject* t29 = shen_intern(ctx, "*maximum-print-sequence-size*");
  KLObject* t28;
  {
    KLObject* a28[] = {t29};
    t28 = shen_apply_direct(ctx, "value", 1, a28);
  }
  KLObject* t30 = shen_number_l(ctx, 0);
  KLObject* t27;
  {
    KLObject* a27[] = {t28, t30, t22};
    t27 = shen_apply_direct(ctx, "shen.syntax-error-message", 3, a27);
  }
  KLObject* t25;
  {
    KLObject* a25[] = {t26, t27};
    t25 = shen_apply_direct(ctx, "cn", 2, a25);
  }
  KLObject* t24;
  {
    KLObject* a24[] = {t25};
    t24 = shen_apply_direct(ctx, "shen.proc-nl", 1, a24);
  }
  KLObject* t23;
  {
    KLObject* a23[] = {t24};
    t23 = shen_tail_apply_direct(ctx, "simple-error", 1, a23);
  }
    return t23;
  }
}

static KLObject* native_kl_shen_2esyntax_2derror_2dmessage_2 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t32 = objects[0];
    KLObject* t33 = objects[1];
    KLObject* t34 = objects[2];
  tail_start_kl_shen_2esyntax_2derror_2dmessage_2: ;
  KLObject* t35;
  {
  KLObject* t36 = shen_empty_list(ctx);
  KLObject* t38 = shen_eq(ctx, t36, t34);
    if (!shen_is_boolean(ctx, t38))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t38)) {
  KLObject* t39 = shen_string(ctx, "\n");
      t35 = t39;
    } else {
  KLObject* t42 = shen_eq(ctx, t32, t33);
    if (!shen_is_boolean(ctx, t42))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t42)) {
  KLObject* t43 = shen_string(ctx, "...etc \n");
      t35 = t43;
    } else {
  KLObject* t45 = shen_cons_p(ctx, t34);
    if (!shen_is_boolean(ctx, t45))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t45)) {
  KLObject* t49 = shen_hd(ctx, t34);
  KLObject* t50 = shen_string(ctx, " ");
  KLObject* t51 = shen_intern(ctx, "shen.s");
  KLObject* t47;
  {
    KLObject* a47[] = {t49, t50, t51};
    t47 = shen_apply_direct(ctx, "shen.app", 3, a47);
  }
  KLObject* t55 = shen_number_l(ctx, 1);
  KLObject* t56 = shen_add(ctx, t33, t55);
  KLObject* t58 = shen_tl(ctx, t34);
  KLObject* t52;
  {
    KLObject* a52[] = {t32, t56, t58};
    t52 = shen_apply_direct(ctx, "shen.syntax-error-message", 3, a52);
  }
  KLObject* t46;
  {
    KLObject* a46[] = {t47, t52};
    t46 = shen_tail_apply_direct(ctx, "cn", 2, a46);
  }
      t35 = t46;
    } else {
  KLObject* t59 = shen_true(ctx);
    if (!shen_is_boolean(ctx, t59))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t59)) {
  KLObject* t61 = shen_string(ctx, "partial function shen.syntax-error-message");
  KLObject* t60;
  {
    KLObject* a60[] = {t61};
    t60 = shen_tail_apply_direct(ctx, "simple-error", 1, a60);
  }
      t35 = t60;
    } else {
      shen_simple_error(ctx, "No true case found for cond");
      t35 = shen_empty_list(ctx);
    }
    }
    }
    }
  }
    return t35;
  }
}

static KLObject* native_kl_shen_2eparse_2dfailure_3f_3 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t62 = objects[0];
  tail_start_kl_shen_2eparse_2dfailure_3f_3: ;
  KLObject* t64 = shen_apply_direct(ctx, "fail", 0, NULL);
  KLObject* t65 = shen_eq(ctx, t62, t64);
    return t65;
  }
}

static KLObject* native_kl_shen_2epartial_2dparse_2dfailure_3f_4 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t66 = objects[0];
  tail_start_kl_shen_2epartial_2dparse_2dfailure_3f_4: ;
  KLObject* t67;
  {
    KLObject* a67[] = {t66};
    t67 = shen_apply_direct(ctx, "shen.in->", 1, a67);
  }
  KLObject* t69 = shen_cons_p(ctx, t67);
    return t69;
  }
}

static KLObject* native_kl_shen_2eobjectcode_5 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t70 = objects[0];
  tail_start_kl_shen_2eobjectcode_5: ;
  KLObject* t71;
  {
  KLObject* t74 = shen_cons_p(ctx, t70);
  KLObject* t72;
  if (!shen_is_boolean(ctx, t74))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t74)) {
    t72 = t74;
  } else {
  KLObject* t77 = shen_tl(ctx, t70);
  KLObject* t78 = shen_cons_p(ctx, t77);
  KLObject* t75;
  if (!shen_is_boolean(ctx, t78))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t78)) {
    t75 = t78;
  } else {
  KLObject* t79 = shen_empty_list(ctx);
  KLObject* t81 = shen_tl(ctx, t70);
  KLObject* t82 = shen_tl(ctx, t81);
  KLObject* t83 = shen_eq(ctx, t79, t82);
    if (!shen_is_boolean(ctx, t83))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t75 = t83;
  }
    if (!shen_is_boolean(ctx, t75))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t72 = t75;
  }
    if (!shen_is_boolean(ctx, t72))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t72)) {
  KLObject* t85 = shen_tl(ctx, t70);
  KLObject* t86 = shen_hd(ctx, t85);
      t71 = t86;
    } else {
  KLObject* t87 = shen_true(ctx);
    if (!shen_is_boolean(ctx, t87))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t87)) {
  KLObject* t91 = shen_string(ctx, " is not a YACC stream\n");
  KLObject* t92 = shen_intern(ctx, "shen.s");
  KLObject* t89;
  {
    KLObject* a89[] = {t70, t91, t92};
    t89 = shen_apply_direct(ctx, "shen.app", 3, a89);
  }
  KLObject* t88;
  {
    KLObject* a88[] = {t89};
    t88 = shen_tail_apply_direct(ctx, "simple-error", 1, a88);
  }
      t71 = t88;
    } else {
      shen_simple_error(ctx, "No true case found for cond");
      t71 = shen_empty_list(ctx);
    }
    }
  }
    return t71;
  }
}

static KLObject* native_kl_shen_2eyacc_2d_3eshen_6 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t93 = objects[0];
  tail_start_kl_shen_2eyacc_2d_3eshen_6: ;
  KLObject* t95;
  {
    Vector* caps_0 = shen_vector(ctx, 0);
    t95 = shen_native_closure(ctx, 1, &lambda_0, caps_0);
  }
  KLObject* t94;
  {
    KLObject* a94[] = {t95, t93};
    t94 = shen_tail_apply_direct(ctx, "compile", 2, a94);
  }
    return t94;
  }
}

static KLObject* native_kl_shen_2e_3cyacc_3e_7 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t100 = objects[0];
  tail_start_kl_shen_2e_3cyacc_3e_7: ;
  KLObject* t103 = shen_cons_p(ctx, t100);
  KLObject* t101;
  if (!shen_is_boolean(ctx, t103))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t103)) {
  KLObject* t104;
  {
    KLObject* a104[] = {t100};
    t104 = shen_apply_direct(ctx, "head", 1, a104);
  }
  KLObject* t106;
  {
    KLObject* a106[] = {t100};
    t106 = shen_apply_direct(ctx, "tail", 1, a106);
  }
  KLObject* t108;
  {
    KLObject* a108[] = {t106};
    t108 = shen_apply_direct(ctx, "shen.<yaccsig>", 1, a108);
  }
  KLObject* t111;
  {
    KLObject* a111[] = {t108};
    t111 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a111);
  }
  KLObject* t110;
  if (!shen_is_boolean(ctx, t111))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t111)) {
  KLObject* t113 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t110 = t113;
  } else {
  KLObject* t114;
  {
    KLObject* a114[] = {t108};
    t114 = shen_apply_direct(ctx, "shen.<-out", 1, a114);
  }
  KLObject* t116;
  {
    KLObject* a116[] = {t108};
    t116 = shen_apply_direct(ctx, "shen.in->", 1, a116);
  }
  KLObject* t118;
  {
    KLObject* a118[] = {t116};
    t118 = shen_apply_direct(ctx, "shen.<c-rules>", 1, a118);
  }
  KLObject* t121;
  {
    KLObject* a121[] = {t118};
    t121 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a121);
  }
  KLObject* t120;
  if (!shen_is_boolean(ctx, t121))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t121)) {
  KLObject* t123 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t120 = t123;
  } else {
  KLObject* t124;
  {
    KLObject* a124[] = {t118};
    t124 = shen_apply_direct(ctx, "shen.<-out", 1, a124);
  }
  KLObject* t126;
  {
    KLObject* a126[] = {t118};
    t126 = shen_apply_direct(ctx, "shen.in->", 1, a126);
  }
  KLObject* t131 = shen_intern(ctx, "S");
  KLObject* t130;
  {
    KLObject* a130[] = {t131};
    t130 = shen_apply_direct(ctx, "gensym", 1, a130);
  }
  KLObject* t133 = shen_intern(ctx, "define");
  KLObject* t135 = shen_empty_list(ctx);
  KLObject* t136 = shen_cons(ctx, t104, t135);
  KLObject* t137 = shen_cons(ctx, t133, t136);
  KLObject* t141 = shen_intern(ctx, "->");
  KLObject* t142;
  {
    KLObject* a142[] = {t114, t130, t124};
    t142 = shen_apply_direct(ctx, "shen.c-rules->shen", 3, a142);
  }
  KLObject* t146 = shen_empty_list(ctx);
  KLObject* t147 = shen_cons(ctx, t142, t146);
  KLObject* t148 = shen_cons(ctx, t141, t147);
  KLObject* t149 = shen_cons(ctx, t130, t148);
  KLObject* t138;
  {
    KLObject* a138[] = {t114, t149};
    t138 = shen_apply_direct(ctx, "append", 2, a138);
  }
  KLObject* t132;
  {
    KLObject* a132[] = {t137, t138};
    t132 = shen_apply_direct(ctx, "append", 2, a132);
  }
  KLObject* t128;
  {
    KLObject* a128[] = {t126, t132};
    t128 = shen_apply_direct(ctx, "shen.comb", 2, a128);
  }
    t120 = t128;
  }
    t110 = t120;
  }
    t101 = t110;
  } else {
  KLObject* t151 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t101 = t151;
  }
  KLObject* t153;
  {
    KLObject* a153[] = {t101};
    t153 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a153);
  }
  KLObject* t152;
  if (!shen_is_boolean(ctx, t153))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t153)) {
  KLObject* t155 = shen_tail_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t152 = t155;
  } else {
    t152 = t101;
  }
    return t152;
  }
}

static KLObject* native_kl_shen_2e_3cyaccsig_3e_8 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t157 = objects[0];
  tail_start_kl_shen_2e_3cyaccsig_3e_8: ;
  KLObject* t160 = shen_cons_p(ctx, t157);
  KLObject* t158;
  if (!shen_is_boolean(ctx, t160))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t160)) {
  KLObject* t161;
  {
    KLObject* a161[] = {t157};
    t161 = shen_apply_direct(ctx, "head", 1, a161);
  }
  KLObject* t163;
  {
    KLObject* a163[] = {t157};
    t163 = shen_apply_direct(ctx, "tail", 1, a163);
  }
  KLObject* t166;
  {
    KLObject* a166[] = {t163};
    t166 = shen_apply_direct(ctx, "shen.ccons?", 1, a166);
  }
  KLObject* t165;
  if (!shen_is_boolean(ctx, t166))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t166)) {
  KLObject* t168;
  {
    KLObject* a168[] = {t163};
    t168 = shen_apply_direct(ctx, "head", 1, a168);
  }
  KLObject* t170;
  {
    KLObject* a170[] = {t163};
    t170 = shen_apply_direct(ctx, "tail", 1, a170);
  }
  KLObject* t175 = shen_intern(ctx, "list");
  KLObject* t173;
  {
    KLObject* a173[] = {t168, t175};
    t173 = shen_apply_direct(ctx, "shen.hds=?", 2, a173);
  }
  KLObject* t172;
  if (!shen_is_boolean(ctx, t173))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t173)) {
  KLObject* t176;
  {
    KLObject* a176[] = {t168};
    t176 = shen_apply_direct(ctx, "tail", 1, a176);
  }
  KLObject* t180 = shen_cons_p(ctx, t176);
  KLObject* t178;
  if (!shen_is_boolean(ctx, t180))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t180)) {
  KLObject* t181;
  {
    KLObject* a181[] = {t176};
    t181 = shen_apply_direct(ctx, "head", 1, a181);
  }
  KLObject* t183;
  {
    KLObject* a183[] = {t176};
    t183 = shen_apply_direct(ctx, "tail", 1, a183);
  }
  KLObject* t185;
  {
    KLObject* a185[] = {t183};
    t185 = shen_apply_direct(ctx, "<end>", 1, a185);
  }
  KLObject* t188;
  {
    KLObject* a188[] = {t185};
    t188 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a188);
  }
  KLObject* t187;
  if (!shen_is_boolean(ctx, t188))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t188)) {
  KLObject* t190 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t187 = t190;
  } else {
  KLObject* t191;
  {
    KLObject* a191[] = {t185};
    t191 = shen_apply_direct(ctx, "shen.in->", 1, a191);
  }
  KLObject* t196 = shen_intern(ctx, "==>");
  KLObject* t194;
  {
    KLObject* a194[] = {t170, t196};
    t194 = shen_apply_direct(ctx, "shen.hds=?", 2, a194);
  }
  KLObject* t193;
  if (!shen_is_boolean(ctx, t194))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t194)) {
  KLObject* t197;
  {
    KLObject* a197[] = {t170};
    t197 = shen_apply_direct(ctx, "tail", 1, a197);
  }
  KLObject* t201 = shen_cons_p(ctx, t197);
  KLObject* t199;
  if (!shen_is_boolean(ctx, t201))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t201)) {
  KLObject* t202;
  {
    KLObject* a202[] = {t197};
    t202 = shen_apply_direct(ctx, "head", 1, a202);
  }
  KLObject* t204;
  {
    KLObject* a204[] = {t197};
    t204 = shen_apply_direct(ctx, "tail", 1, a204);
  }
  KLObject* t208 = shen_cons_p(ctx, t204);
  KLObject* t206;
  if (!shen_is_boolean(ctx, t208))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t208)) {
  KLObject* t209;
  {
    KLObject* a209[] = {t204};
    t209 = shen_apply_direct(ctx, "head", 1, a209);
  }
  KLObject* t211;
  {
    KLObject* a211[] = {t204};
    t211 = shen_apply_direct(ctx, "tail", 1, a211);
  }
  KLObject* t215 = shen_intern(ctx, "{");
  KLObject* t217 = shen_eq(ctx, t215, t161);
  KLObject* t214;
  if (!shen_is_boolean(ctx, t217))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t217)) {
    t214 = t217;
  } else {
  KLObject* t218 = shen_intern(ctx, "}");
  KLObject* t220 = shen_eq(ctx, t218, t209);
    if (!shen_is_boolean(ctx, t220))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t214 = t220;
  }
  KLObject* t213;
  if (!shen_is_boolean(ctx, t214))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t214)) {
  KLObject* t223 = shen_intern(ctx, "{");
  KLObject* t224 = shen_intern(ctx, "list");
  KLObject* t226 = shen_empty_list(ctx);
  KLObject* t227 = shen_cons(ctx, t181, t226);
  KLObject* t228 = shen_cons(ctx, t224, t227);
  KLObject* t229 = shen_intern(ctx, "-->");
  KLObject* t230 = shen_intern(ctx, "str");
  KLObject* t231 = shen_intern(ctx, "list");
  KLObject* t233 = shen_empty_list(ctx);
  KLObject* t234 = shen_cons(ctx, t181, t233);
  KLObject* t235 = shen_cons(ctx, t231, t234);
  KLObject* t237 = shen_empty_list(ctx);
  KLObject* t238 = shen_cons(ctx, t202, t237);
  KLObject* t239 = shen_cons(ctx, t235, t238);
  KLObject* t240 = shen_cons(ctx, t230, t239);
  KLObject* t241 = shen_intern(ctx, "}");
  KLObject* t242 = shen_empty_list(ctx);
  KLObject* t243 = shen_cons(ctx, t241, t242);
  KLObject* t244 = shen_cons(ctx, t240, t243);
  KLObject* t245 = shen_cons(ctx, t229, t244);
  KLObject* t246 = shen_cons(ctx, t228, t245);
  KLObject* t247 = shen_cons(ctx, t223, t246);
  KLObject* t221;
  {
    KLObject* a221[] = {t211, t247};
    t221 = shen_apply_direct(ctx, "shen.comb", 2, a221);
  }
    t213 = t221;
  } else {
  KLObject* t248 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t213 = t248;
  }
    t206 = t213;
  } else {
  KLObject* t249 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t206 = t249;
  }
    t199 = t206;
  } else {
  KLObject* t250 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t199 = t250;
  }
    t193 = t199;
  } else {
  KLObject* t251 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t193 = t251;
  }
    t187 = t193;
  }
    t178 = t187;
  } else {
  KLObject* t252 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t178 = t252;
  }
    t172 = t178;
  } else {
  KLObject* t253 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t172 = t253;
  }
    t165 = t172;
  } else {
  KLObject* t254 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t165 = t254;
  }
    t158 = t165;
  } else {
  KLObject* t255 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t158 = t255;
  }
  KLObject* t257;
  {
    KLObject* a257[] = {t158};
    t257 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a257);
  }
  KLObject* t256;
  if (!shen_is_boolean(ctx, t257))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t257)) {
  KLObject* t259;
  {
    KLObject* a259[] = {t157};
    t259 = shen_apply_direct(ctx, "<e>", 1, a259);
  }
  KLObject* t262;
  {
    KLObject* a262[] = {t259};
    t262 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a262);
  }
  KLObject* t261;
  if (!shen_is_boolean(ctx, t262))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t262)) {
  KLObject* t264 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t261 = t264;
  } else {
  KLObject* t265;
  {
    KLObject* a265[] = {t259};
    t265 = shen_apply_direct(ctx, "shen.in->", 1, a265);
  }
  KLObject* t269 = shen_empty_list(ctx);
  KLObject* t267;
  {
    KLObject* a267[] = {t265, t269};
    t267 = shen_apply_direct(ctx, "shen.comb", 2, a267);
  }
    t261 = t267;
  }
  KLObject* t271;
  {
    KLObject* a271[] = {t261};
    t271 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a271);
  }
  KLObject* t270;
  if (!shen_is_boolean(ctx, t271))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t271)) {
  KLObject* t273 = shen_tail_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t270 = t273;
  } else {
    t270 = t261;
  }
    t256 = t270;
  } else {
    t256 = t158;
  }
    return t256;
  }
}

static KLObject* native_kl_shen_2e_3cc_2drules_3e_9 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t276 = objects[0];
  tail_start_kl_shen_2e_3cc_2drules_3e_9: ;
  KLObject* t277;
  {
    KLObject* a277[] = {t276};
    t277 = shen_apply_direct(ctx, "shen.<c-rule>", 1, a277);
  }
  KLObject* t280;
  {
    KLObject* a280[] = {t277};
    t280 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a280);
  }
  KLObject* t279;
  if (!shen_is_boolean(ctx, t280))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t280)) {
  KLObject* t282 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t279 = t282;
  } else {
  KLObject* t283;
  {
    KLObject* a283[] = {t277};
    t283 = shen_apply_direct(ctx, "shen.<-out", 1, a283);
  }
  KLObject* t285;
  {
    KLObject* a285[] = {t277};
    t285 = shen_apply_direct(ctx, "shen.in->", 1, a285);
  }
  KLObject* t287;
  {
    KLObject* a287[] = {t285};
    t287 = shen_apply_direct(ctx, "shen.<c-rules>", 1, a287);
  }
  KLObject* t290;
  {
    KLObject* a290[] = {t287};
    t290 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a290);
  }
  KLObject* t289;
  if (!shen_is_boolean(ctx, t290))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t290)) {
  KLObject* t292 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t289 = t292;
  } else {
  KLObject* t293;
  {
    KLObject* a293[] = {t287};
    t293 = shen_apply_direct(ctx, "shen.<-out", 1, a293);
  }
  KLObject* t295;
  {
    KLObject* a295[] = {t287};
    t295 = shen_apply_direct(ctx, "shen.in->", 1, a295);
  }
  KLObject* t301 = shen_cons(ctx, t283, t293);
  KLObject* t297;
  {
    KLObject* a297[] = {t295, t301};
    t297 = shen_apply_direct(ctx, "shen.comb", 2, a297);
  }
    t289 = t297;
  }
    t279 = t289;
  }
  KLObject* t303;
  {
    KLObject* a303[] = {t279};
    t303 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a303);
  }
  KLObject* t302;
  if (!shen_is_boolean(ctx, t303))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t303)) {
  KLObject* t305;
  {
    KLObject* a305[] = {t276};
    t305 = shen_apply_direct(ctx, "<!>", 1, a305);
  }
  KLObject* t308;
  {
    KLObject* a308[] = {t305};
    t308 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a308);
  }
  KLObject* t307;
  if (!shen_is_boolean(ctx, t308))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t308)) {
  KLObject* t310 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t307 = t310;
  } else {
  KLObject* t311;
  {
    KLObject* a311[] = {t305};
    t311 = shen_apply_direct(ctx, "shen.<-out", 1, a311);
  }
  KLObject* t313;
  {
    KLObject* a313[] = {t305};
    t313 = shen_apply_direct(ctx, "shen.in->", 1, a313);
  }
  KLObject* t318;
  {
    KLObject* a318[] = {t311};
    t318 = shen_apply_direct(ctx, "empty?", 1, a318);
  }
  KLObject* t317;
  if (!shen_is_boolean(ctx, t318))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t318)) {
  KLObject* t320 = shen_empty_list(ctx);
    t317 = t320;
  } else {
  KLObject* t323 = shen_string(ctx, "YACC syntax error here:\n ");
  KLObject* t326 = shen_string(ctx, "\n ...");
  KLObject* t327 = shen_intern(ctx, "shen.r");
  KLObject* t324;
  {
    KLObject* a324[] = {t311, t326, t327};
    t324 = shen_apply_direct(ctx, "shen.app", 3, a324);
  }
  KLObject* t322;
  {
    KLObject* a322[] = {t323, t324};
    t322 = shen_apply_direct(ctx, "cn", 2, a322);
  }
  KLObject* t321;
  {
    KLObject* a321[] = {t322};
    t321 = shen_apply_direct(ctx, "simple-error", 1, a321);
  }
    t317 = t321;
  }
  KLObject* t315;
  {
    KLObject* a315[] = {t313, t317};
    t315 = shen_apply_direct(ctx, "shen.comb", 2, a315);
  }
    t307 = t315;
  }
  KLObject* t329;
  {
    KLObject* a329[] = {t307};
    t329 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a329);
  }
  KLObject* t328;
  if (!shen_is_boolean(ctx, t329))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t329)) {
  KLObject* t331 = shen_tail_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t328 = t331;
  } else {
    t328 = t307;
  }
    t302 = t328;
  } else {
    t302 = t279;
  }
    return t302;
  }
}

static KLObject* native_kl_shen_2e_3cc_2drule_3e_10 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t334 = objects[0];
  tail_start_kl_shen_2e_3cc_2drule_3e_10: ;
  KLObject* t335;
  {
    KLObject* a335[] = {t334};
    t335 = shen_apply_direct(ctx, "shen.<syntax>", 1, a335);
  }
  KLObject* t338;
  {
    KLObject* a338[] = {t335};
    t338 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a338);
  }
  KLObject* t337;
  if (!shen_is_boolean(ctx, t338))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t338)) {
  KLObject* t340 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t337 = t340;
  } else {
  KLObject* t341;
  {
    KLObject* a341[] = {t335};
    t341 = shen_apply_direct(ctx, "shen.<-out", 1, a341);
  }
  KLObject* t343;
  {
    KLObject* a343[] = {t335};
    t343 = shen_apply_direct(ctx, "shen.in->", 1, a343);
  }
  KLObject* t345;
  {
    KLObject* a345[] = {t343};
    t345 = shen_apply_direct(ctx, "shen.<semantics>", 1, a345);
  }
  KLObject* t348;
  {
    KLObject* a348[] = {t345};
    t348 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a348);
  }
  KLObject* t347;
  if (!shen_is_boolean(ctx, t348))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t348)) {
  KLObject* t350 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t347 = t350;
  } else {
  KLObject* t351;
  {
    KLObject* a351[] = {t345};
    t351 = shen_apply_direct(ctx, "shen.<-out", 1, a351);
  }
  KLObject* t353;
  {
    KLObject* a353[] = {t345};
    t353 = shen_apply_direct(ctx, "shen.in->", 1, a353);
  }
  KLObject* t355;
  {
    KLObject* a355[] = {t353};
    t355 = shen_apply_direct(ctx, "shen.<sc>", 1, a355);
  }
  KLObject* t358;
  {
    KLObject* a358[] = {t355};
    t358 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a358);
  }
  KLObject* t357;
  if (!shen_is_boolean(ctx, t358))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t358)) {
  KLObject* t360 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t357 = t360;
  } else {
  KLObject* t361;
  {
    KLObject* a361[] = {t355};
    t361 = shen_apply_direct(ctx, "shen.in->", 1, a361);
  }
  KLObject* t367 = shen_empty_list(ctx);
  KLObject* t368 = shen_cons(ctx, t351, t367);
  KLObject* t369 = shen_cons(ctx, t341, t368);
  KLObject* t363;
  {
    KLObject* a363[] = {t361, t369};
    t363 = shen_apply_direct(ctx, "shen.comb", 2, a363);
  }
    t357 = t363;
  }
    t347 = t357;
  }
    t337 = t347;
  }
  KLObject* t371;
  {
    KLObject* a371[] = {t337};
    t371 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a371);
  }
  KLObject* t370;
  if (!shen_is_boolean(ctx, t371))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t371)) {
  KLObject* t373;
  {
    KLObject* a373[] = {t334};
    t373 = shen_apply_direct(ctx, "shen.<syntax>", 1, a373);
  }
  KLObject* t376;
  {
    KLObject* a376[] = {t373};
    t376 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a376);
  }
  KLObject* t375;
  if (!shen_is_boolean(ctx, t376))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t376)) {
  KLObject* t378 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t375 = t378;
  } else {
  KLObject* t379;
  {
    KLObject* a379[] = {t373};
    t379 = shen_apply_direct(ctx, "shen.<-out", 1, a379);
  }
  KLObject* t381;
  {
    KLObject* a381[] = {t373};
    t381 = shen_apply_direct(ctx, "shen.in->", 1, a381);
  }
  KLObject* t383;
  {
    KLObject* a383[] = {t381};
    t383 = shen_apply_direct(ctx, "shen.<sc>", 1, a383);
  }
  KLObject* t386;
  {
    KLObject* a386[] = {t383};
    t386 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a386);
  }
  KLObject* t385;
  if (!shen_is_boolean(ctx, t386))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t386)) {
  KLObject* t388 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t385 = t388;
  } else {
  KLObject* t389;
  {
    KLObject* a389[] = {t383};
    t389 = shen_apply_direct(ctx, "shen.in->", 1, a389);
  }
  KLObject* t394;
  {
    KLObject* a394[] = {t379};
    t394 = shen_apply_direct(ctx, "shen.autocomplete", 1, a394);
  }
  KLObject* t396 = shen_empty_list(ctx);
  KLObject* t397 = shen_cons(ctx, t394, t396);
  KLObject* t398 = shen_cons(ctx, t379, t397);
  KLObject* t391;
  {
    KLObject* a391[] = {t389, t398};
    t391 = shen_apply_direct(ctx, "shen.comb", 2, a391);
  }
    t385 = t391;
  }
    t375 = t385;
  }
  KLObject* t400;
  {
    KLObject* a400[] = {t375};
    t400 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a400);
  }
  KLObject* t399;
  if (!shen_is_boolean(ctx, t400))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t400)) {
  KLObject* t402 = shen_tail_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t399 = t402;
  } else {
    t399 = t375;
  }
    t370 = t399;
  } else {
    t370 = t337;
  }
    return t370;
  }
}

static KLObject* native_kl_shen_2eautocomplete_11 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t405 = objects[0];
  tail_start_kl_shen_2eautocomplete_11: ;
  KLObject* t406;
  {
  KLObject* t409 = shen_cons_p(ctx, t405);
  KLObject* t407;
  if (!shen_is_boolean(ctx, t409))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t409)) {
    t407 = t409;
  } else {
  KLObject* t411 = shen_empty_list(ctx);
  KLObject* t413 = shen_tl(ctx, t405);
  KLObject* t414 = shen_eq(ctx, t411, t413);
  KLObject* t410;
  if (!shen_is_boolean(ctx, t414))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t414)) {
    t410 = t414;
  } else {
  KLObject* t417 = shen_hd(ctx, t405);
  KLObject* t415;
  {
    KLObject* a415[] = {t417};
    t415 = shen_apply_direct(ctx, "shen.non-terminal?", 1, a415);
  }
    if (!shen_is_boolean(ctx, t415))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t410 = t415;
  }
    if (!shen_is_boolean(ctx, t410))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t407 = t410;
  }
    if (!shen_is_boolean(ctx, t407))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t407)) {
  KLObject* t419 = shen_hd(ctx, t405);
      t406 = t419;
    } else {
  KLObject* t422 = shen_cons_p(ctx, t405);
  KLObject* t420;
  if (!shen_is_boolean(ctx, t422))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t422)) {
    t420 = t422;
  } else {
  KLObject* t425 = shen_hd(ctx, t405);
  KLObject* t423;
  {
    KLObject* a423[] = {t425};
    t423 = shen_apply_direct(ctx, "shen.non-terminal?", 1, a423);
  }
    if (!shen_is_boolean(ctx, t423))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t420 = t423;
  }
    if (!shen_is_boolean(ctx, t420))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t420)) {
  KLObject* t426 = shen_intern(ctx, "append");
  KLObject* t428 = shen_hd(ctx, t405);
  KLObject* t431 = shen_tl(ctx, t405);
  KLObject* t429;
  {
    KLObject* a429[] = {t431};
    t429 = shen_apply_direct(ctx, "shen.autocomplete", 1, a429);
  }
  KLObject* t432 = shen_empty_list(ctx);
  KLObject* t433 = shen_cons(ctx, t429, t432);
  KLObject* t434 = shen_cons(ctx, t428, t433);
  KLObject* t435 = shen_cons(ctx, t426, t434);
      t406 = t435;
    } else {
  KLObject* t437 = shen_cons_p(ctx, t405);
    if (!shen_is_boolean(ctx, t437))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t437)) {
  KLObject* t438 = shen_intern(ctx, "cons");
  KLObject* t441 = shen_hd(ctx, t405);
  KLObject* t439;
  {
    KLObject* a439[] = {t441};
    t439 = shen_apply_direct(ctx, "shen.autocomplete", 1, a439);
  }
  KLObject* t444 = shen_tl(ctx, t405);
  KLObject* t442;
  {
    KLObject* a442[] = {t444};
    t442 = shen_apply_direct(ctx, "shen.autocomplete", 1, a442);
  }
  KLObject* t445 = shen_empty_list(ctx);
  KLObject* t446 = shen_cons(ctx, t442, t445);
  KLObject* t447 = shen_cons(ctx, t439, t446);
  KLObject* t448 = shen_cons(ctx, t438, t447);
      t406 = t448;
    } else {
  KLObject* t449 = shen_true(ctx);
    if (!shen_is_boolean(ctx, t449))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t449)) {
      t406 = t405;
    } else {
      shen_simple_error(ctx, "No true case found for cond");
      t406 = shen_empty_list(ctx);
    }
    }
    }
    }
  }
    return t406;
  }
}

static KLObject* native_kl_shen_2enon_2dterminal_3f_12 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t451 = objects[0];
  tail_start_kl_shen_2enon_2dterminal_3f_12: ;
  KLObject* t454 = shen_symbol_p(ctx, t451);
  KLObject* t452;
  if (!shen_is_boolean(ctx, t454))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t454)) {
    t452 = t454;
  } else {
  KLObject* t455;
  {
    KLObject* a455[] = {t451};
    t455 = shen_apply_direct(ctx, "explode", 1, a455);
  }
  KLObject* t458;
  {
    Vector* caps_1 = shen_vector(ctx, 0);
    t458 = shen_native_closure(ctx, 1, &lambda_1, caps_1);
  }
  KLObject* t457;
  {
    KLObject* a457[] = {t458, t455};
    t457 = shen_apply_direct(ctx, "compile", 2, a457);
  }
    if (!shen_is_boolean(ctx, t457))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t452 = t457;
  }
    return t452;
  }
}

static KLObject* native_kl_shen_2e_3cnon_2dterminal_3f_3e_13 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t463 = objects[0];
  tail_start_kl_shen_2e_3cnon_2dterminal_3f_3e_13: ;
  KLObject* t464;
  {
    KLObject* a464[] = {t463};
    t464 = shen_apply_direct(ctx, "shen.<packagenames>", 1, a464);
  }
  KLObject* t467;
  {
    KLObject* a467[] = {t464};
    t467 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a467);
  }
  KLObject* t466;
  if (!shen_is_boolean(ctx, t467))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t467)) {
  KLObject* t469 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t466 = t469;
  } else {
  KLObject* t470;
  {
    KLObject* a470[] = {t464};
    t470 = shen_apply_direct(ctx, "shen.in->", 1, a470);
  }
  KLObject* t472;
  {
    KLObject* a472[] = {t470};
    t472 = shen_apply_direct(ctx, "shen.<non-terminal-name>", 1, a472);
  }
  KLObject* t475;
  {
    KLObject* a475[] = {t472};
    t475 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a475);
  }
  KLObject* t474;
  if (!shen_is_boolean(ctx, t475))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t475)) {
  KLObject* t477 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t474 = t477;
  } else {
  KLObject* t478;
  {
    KLObject* a478[] = {t472};
    t478 = shen_apply_direct(ctx, "shen.in->", 1, a478);
  }
  KLObject* t482 = shen_true(ctx);
  KLObject* t480;
  {
    KLObject* a480[] = {t478, t482};
    t480 = shen_apply_direct(ctx, "shen.comb", 2, a480);
  }
    t474 = t480;
  }
    t466 = t474;
  }
  KLObject* t484;
  {
    KLObject* a484[] = {t466};
    t484 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a484);
  }
  KLObject* t483;
  if (!shen_is_boolean(ctx, t484))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t484)) {
  KLObject* t486;
  {
    KLObject* a486[] = {t463};
    t486 = shen_apply_direct(ctx, "shen.<non-terminal-name>", 1, a486);
  }
  KLObject* t489;
  {
    KLObject* a489[] = {t486};
    t489 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a489);
  }
  KLObject* t488;
  if (!shen_is_boolean(ctx, t489))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t489)) {
  KLObject* t491 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t488 = t491;
  } else {
  KLObject* t492;
  {
    KLObject* a492[] = {t486};
    t492 = shen_apply_direct(ctx, "shen.in->", 1, a492);
  }
  KLObject* t496 = shen_true(ctx);
  KLObject* t494;
  {
    KLObject* a494[] = {t492, t496};
    t494 = shen_apply_direct(ctx, "shen.comb", 2, a494);
  }
    t488 = t494;
  }
  KLObject* t498;
  {
    KLObject* a498[] = {t488};
    t498 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a498);
  }
  KLObject* t497;
  if (!shen_is_boolean(ctx, t498))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t498)) {
  KLObject* t500;
  {
    KLObject* a500[] = {t463};
    t500 = shen_apply_direct(ctx, "<!>", 1, a500);
  }
  KLObject* t503;
  {
    KLObject* a503[] = {t500};
    t503 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a503);
  }
  KLObject* t502;
  if (!shen_is_boolean(ctx, t503))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t503)) {
  KLObject* t505 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t502 = t505;
  } else {
  KLObject* t506;
  {
    KLObject* a506[] = {t500};
    t506 = shen_apply_direct(ctx, "shen.in->", 1, a506);
  }
  KLObject* t510 = shen_false(ctx);
  KLObject* t508;
  {
    KLObject* a508[] = {t506, t510};
    t508 = shen_apply_direct(ctx, "shen.comb", 2, a508);
  }
    t502 = t508;
  }
  KLObject* t512;
  {
    KLObject* a512[] = {t502};
    t512 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a512);
  }
  KLObject* t511;
  if (!shen_is_boolean(ctx, t512))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t512)) {
  KLObject* t514 = shen_tail_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t511 = t514;
  } else {
    t511 = t502;
  }
    t497 = t511;
  } else {
    t497 = t488;
  }
    t483 = t497;
  } else {
    t483 = t466;
  }
    return t483;
  }
}

static KLObject* native_kl_shen_2e_3cpackagenames_3e_14 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t518 = objects[0];
  tail_start_kl_shen_2e_3cpackagenames_3e_14: ;
  KLObject* t519;
  {
    KLObject* a519[] = {t518};
    t519 = shen_apply_direct(ctx, "shen.<packagename>", 1, a519);
  }
  KLObject* t522;
  {
    KLObject* a522[] = {t519};
    t522 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a522);
  }
  KLObject* t521;
  if (!shen_is_boolean(ctx, t522))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t522)) {
  KLObject* t524 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t521 = t524;
  } else {
  KLObject* t525;
  {
    KLObject* a525[] = {t519};
    t525 = shen_apply_direct(ctx, "shen.in->", 1, a525);
  }
  KLObject* t530 = shen_string(ctx, ".");
  KLObject* t528;
  {
    KLObject* a528[] = {t525, t530};
    t528 = shen_apply_direct(ctx, "shen.hds=?", 2, a528);
  }
  KLObject* t527;
  if (!shen_is_boolean(ctx, t528))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t528)) {
  KLObject* t531;
  {
    KLObject* a531[] = {t525};
    t531 = shen_apply_direct(ctx, "tail", 1, a531);
  }
  KLObject* t533;
  {
    KLObject* a533[] = {t531};
    t533 = shen_apply_direct(ctx, "shen.<packagenames>", 1, a533);
  }
  KLObject* t536;
  {
    KLObject* a536[] = {t533};
    t536 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a536);
  }
  KLObject* t535;
  if (!shen_is_boolean(ctx, t536))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t536)) {
  KLObject* t538 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t535 = t538;
  } else {
  KLObject* t539;
  {
    KLObject* a539[] = {t533};
    t539 = shen_apply_direct(ctx, "shen.in->", 1, a539);
  }
  KLObject* t543 = shen_intern(ctx, "shen.skip");
  KLObject* t541;
  {
    KLObject* a541[] = {t539, t543};
    t541 = shen_apply_direct(ctx, "shen.comb", 2, a541);
  }
    t535 = t541;
  }
    t527 = t535;
  } else {
  KLObject* t544 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t527 = t544;
  }
    t521 = t527;
  }
  KLObject* t546;
  {
    KLObject* a546[] = {t521};
    t546 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a546);
  }
  KLObject* t545;
  if (!shen_is_boolean(ctx, t546))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t546)) {
  KLObject* t548;
  {
    KLObject* a548[] = {t518};
    t548 = shen_apply_direct(ctx, "shen.<packagename>", 1, a548);
  }
  KLObject* t551;
  {
    KLObject* a551[] = {t548};
    t551 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a551);
  }
  KLObject* t550;
  if (!shen_is_boolean(ctx, t551))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t551)) {
  KLObject* t553 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t550 = t553;
  } else {
  KLObject* t554;
  {
    KLObject* a554[] = {t548};
    t554 = shen_apply_direct(ctx, "shen.in->", 1, a554);
  }
  KLObject* t559 = shen_string(ctx, ".");
  KLObject* t557;
  {
    KLObject* a557[] = {t554, t559};
    t557 = shen_apply_direct(ctx, "shen.hds=?", 2, a557);
  }
  KLObject* t556;
  if (!shen_is_boolean(ctx, t557))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t557)) {
  KLObject* t560;
  {
    KLObject* a560[] = {t554};
    t560 = shen_apply_direct(ctx, "tail", 1, a560);
  }
  KLObject* t564 = shen_intern(ctx, "shen.skip");
  KLObject* t562;
  {
    KLObject* a562[] = {t560, t564};
    t562 = shen_apply_direct(ctx, "shen.comb", 2, a562);
  }
    t556 = t562;
  } else {
  KLObject* t565 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t556 = t565;
  }
    t550 = t556;
  }
  KLObject* t567;
  {
    KLObject* a567[] = {t550};
    t567 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a567);
  }
  KLObject* t566;
  if (!shen_is_boolean(ctx, t567))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t567)) {
  KLObject* t569 = shen_tail_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t566 = t569;
  } else {
    t566 = t550;
  }
    t545 = t566;
  } else {
    t545 = t521;
  }
    return t545;
  }
}

static KLObject* native_kl_shen_2e_3cpackagename_3e_15 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t572 = objects[0];
  tail_start_kl_shen_2e_3cpackagename_3e_15: ;
  KLObject* t573;
  {
    KLObject* a573[] = {t572};
    t573 = shen_apply_direct(ctx, "shen.<packagechar>", 1, a573);
  }
  KLObject* t576;
  {
    KLObject* a576[] = {t573};
    t576 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a576);
  }
  KLObject* t575;
  if (!shen_is_boolean(ctx, t576))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t576)) {
  KLObject* t578 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t575 = t578;
  } else {
  KLObject* t579;
  {
    KLObject* a579[] = {t573};
    t579 = shen_apply_direct(ctx, "shen.in->", 1, a579);
  }
  KLObject* t581;
  {
    KLObject* a581[] = {t579};
    t581 = shen_apply_direct(ctx, "shen.<packagename>", 1, a581);
  }
  KLObject* t584;
  {
    KLObject* a584[] = {t581};
    t584 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a584);
  }
  KLObject* t583;
  if (!shen_is_boolean(ctx, t584))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t584)) {
  KLObject* t586 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t583 = t586;
  } else {
  KLObject* t587;
  {
    KLObject* a587[] = {t581};
    t587 = shen_apply_direct(ctx, "shen.in->", 1, a587);
  }
  KLObject* t591 = shen_intern(ctx, "shen.skip");
  KLObject* t589;
  {
    KLObject* a589[] = {t587, t591};
    t589 = shen_apply_direct(ctx, "shen.comb", 2, a589);
  }
    t583 = t589;
  }
    t575 = t583;
  }
  KLObject* t593;
  {
    KLObject* a593[] = {t575};
    t593 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a593);
  }
  KLObject* t592;
  if (!shen_is_boolean(ctx, t593))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t593)) {
  KLObject* t595;
  {
    KLObject* a595[] = {t572};
    t595 = shen_apply_direct(ctx, "<e>", 1, a595);
  }
  KLObject* t598;
  {
    KLObject* a598[] = {t595};
    t598 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a598);
  }
  KLObject* t597;
  if (!shen_is_boolean(ctx, t598))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t598)) {
  KLObject* t600 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t597 = t600;
  } else {
  KLObject* t601;
  {
    KLObject* a601[] = {t595};
    t601 = shen_apply_direct(ctx, "shen.in->", 1, a601);
  }
  KLObject* t605 = shen_intern(ctx, "shen.skip");
  KLObject* t603;
  {
    KLObject* a603[] = {t601, t605};
    t603 = shen_apply_direct(ctx, "shen.comb", 2, a603);
  }
    t597 = t603;
  }
  KLObject* t607;
  {
    KLObject* a607[] = {t597};
    t607 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a607);
  }
  KLObject* t606;
  if (!shen_is_boolean(ctx, t607))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t607)) {
  KLObject* t609 = shen_tail_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t606 = t609;
  } else {
    t606 = t597;
  }
    t592 = t606;
  } else {
    t592 = t575;
  }
    return t592;
  }
}

static KLObject* native_kl_shen_2e_3cpackagechar_3e_16 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t612 = objects[0];
  tail_start_kl_shen_2e_3cpackagechar_3e_16: ;
  KLObject* t615 = shen_cons_p(ctx, t612);
  KLObject* t613;
  if (!shen_is_boolean(ctx, t615))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t615)) {
  KLObject* t616;
  {
    KLObject* a616[] = {t612};
    t616 = shen_apply_direct(ctx, "head", 1, a616);
  }
  KLObject* t618;
  {
    KLObject* a618[] = {t612};
    t618 = shen_apply_direct(ctx, "tail", 1, a618);
  }
  KLObject* t623 = shen_string(ctx, ".");
  KLObject* t624 = shen_eq(ctx, t616, t623);
  KLObject* t621;
  {
    KLObject* a621[] = {t624};
    t621 = shen_apply_direct(ctx, "not", 1, a621);
  }
  KLObject* t620;
  if (!shen_is_boolean(ctx, t621))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t621)) {
  KLObject* t627 = shen_intern(ctx, "shen.skip");
  KLObject* t625;
  {
    KLObject* a625[] = {t618, t627};
    t625 = shen_apply_direct(ctx, "shen.comb", 2, a625);
  }
    t620 = t625;
  } else {
  KLObject* t628 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t620 = t628;
  }
    t613 = t620;
  } else {
  KLObject* t629 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t613 = t629;
  }
  KLObject* t631;
  {
    KLObject* a631[] = {t613};
    t631 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a631);
  }
  KLObject* t630;
  if (!shen_is_boolean(ctx, t631))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t631)) {
  KLObject* t633 = shen_tail_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t630 = t633;
  } else {
    t630 = t613;
  }
    return t630;
  }
}

static KLObject* native_kl_shen_2e_3cnon_2dterminal_2dname_3e_17 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t635 = objects[0];
  tail_start_kl_shen_2e_3cnon_2dterminal_2dname_3e_17: ;
  KLObject* t639 = shen_string(ctx, "<");
  KLObject* t637;
  {
    KLObject* a637[] = {t635, t639};
    t637 = shen_apply_direct(ctx, "shen.hds=?", 2, a637);
  }
  KLObject* t636;
  if (!shen_is_boolean(ctx, t637))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t637)) {
  KLObject* t640;
  {
    KLObject* a640[] = {t635};
    t640 = shen_apply_direct(ctx, "tail", 1, a640);
  }
  KLObject* t642;
  {
    KLObject* a642[] = {t640};
    t642 = shen_apply_direct(ctx, "<!>", 1, a642);
  }
  KLObject* t645;
  {
    KLObject* a645[] = {t642};
    t645 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a645);
  }
  KLObject* t644;
  if (!shen_is_boolean(ctx, t645))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t645)) {
  KLObject* t647 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t644 = t647;
  } else {
  KLObject* t648;
  {
    KLObject* a648[] = {t642};
    t648 = shen_apply_direct(ctx, "shen.<-out", 1, a648);
  }
  KLObject* t650;
  {
    KLObject* a650[] = {t642};
    t650 = shen_apply_direct(ctx, "shen.in->", 1, a650);
  }
  KLObject* t653;
  {
    KLObject* a653[] = {t648};
    t653 = shen_apply_direct(ctx, "reverse", 1, a653);
  }
  KLObject* t657 = shen_cons_p(ctx, t653);
  KLObject* t655;
  if (!shen_is_boolean(ctx, t657))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t657)) {
    t655 = t657;
  } else {
  KLObject* t659 = shen_hd(ctx, t653);
  KLObject* t660 = shen_string(ctx, ">");
  KLObject* t661 = shen_eq(ctx, t659, t660);
    if (!shen_is_boolean(ctx, t661))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t655 = t661;
  }
  KLObject* t652;
  if (!shen_is_boolean(ctx, t655))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t655)) {
  KLObject* t664 = shen_intern(ctx, "shen.skip");
  KLObject* t662;
  {
    KLObject* a662[] = {t650, t664};
    t662 = shen_apply_direct(ctx, "shen.comb", 2, a662);
  }
    t652 = t662;
  } else {
  KLObject* t665 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t652 = t665;
  }
    t644 = t652;
  }
    t636 = t644;
  } else {
  KLObject* t666 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t636 = t666;
  }
  KLObject* t668;
  {
    KLObject* a668[] = {t636};
    t668 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a668);
  }
  KLObject* t667;
  if (!shen_is_boolean(ctx, t668))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t668)) {
  KLObject* t670 = shen_tail_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t667 = t670;
  } else {
    t667 = t636;
  }
    return t667;
  }
}

static KLObject* native_kl_shen_2esemicolon_3f_18 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t672 = objects[0];
  tail_start_kl_shen_2esemicolon_3f_18: ;
  KLObject* t675 = shen_string(ctx, ";");
  KLObject* t674;
  {
    KLObject* a674[] = {t675};
    t674 = shen_apply_direct(ctx, "intern", 1, a674);
  }
  KLObject* t676 = shen_eq(ctx, t672, t674);
    return t676;
  }
}

static KLObject* native_kl_shen_2e_3ccolon_2dequal_3e_19 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t677 = objects[0];
  tail_start_kl_shen_2e_3ccolon_2dequal_3e_19: ;
  KLObject* t680 = shen_cons_p(ctx, t677);
  KLObject* t678;
  if (!shen_is_boolean(ctx, t680))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t680)) {
  KLObject* t681;
  {
    KLObject* a681[] = {t677};
    t681 = shen_apply_direct(ctx, "head", 1, a681);
  }
  KLObject* t683;
  {
    KLObject* a683[] = {t677};
    t683 = shen_apply_direct(ctx, "tail", 1, a683);
  }
  KLObject* t686;
  {
    KLObject* a686[] = {t681};
    t686 = shen_apply_direct(ctx, "shen.colon-equal?", 1, a686);
  }
  KLObject* t685;
  if (!shen_is_boolean(ctx, t686))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t686)) {
  KLObject* t690 = shen_intern(ctx, "shen.skip");
  KLObject* t688;
  {
    KLObject* a688[] = {t683, t690};
    t688 = shen_apply_direct(ctx, "shen.comb", 2, a688);
  }
    t685 = t688;
  } else {
  KLObject* t691 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t685 = t691;
  }
    t678 = t685;
  } else {
  KLObject* t692 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t678 = t692;
  }
  KLObject* t694;
  {
    KLObject* a694[] = {t678};
    t694 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a694);
  }
  KLObject* t693;
  if (!shen_is_boolean(ctx, t694))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t694)) {
  KLObject* t696 = shen_tail_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t693 = t696;
  } else {
    t693 = t678;
  }
    return t693;
  }
}

static KLObject* native_kl_shen_2ecolon_2dequal_3f_20 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t698 = objects[0];
  tail_start_kl_shen_2ecolon_2dequal_3f_20: ;
  KLObject* t700 = shen_string(ctx, ":=");
  KLObject* t699;
  {
    KLObject* a699[] = {t700};
    t699 = shen_apply_direct(ctx, "intern", 1, a699);
  }
  KLObject* t702 = shen_eq(ctx, t699, t698);
    return t702;
  }
}

static KLObject* native_kl_shen_2e_3csyntax_3e_21 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t703 = objects[0];
  tail_start_kl_shen_2e_3csyntax_3e_21: ;
  KLObject* t704;
  {
    KLObject* a704[] = {t703};
    t704 = shen_apply_direct(ctx, "shen.<syntax-item>", 1, a704);
  }
  KLObject* t707;
  {
    KLObject* a707[] = {t704};
    t707 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a707);
  }
  KLObject* t706;
  if (!shen_is_boolean(ctx, t707))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t707)) {
  KLObject* t709 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t706 = t709;
  } else {
  KLObject* t710;
  {
    KLObject* a710[] = {t704};
    t710 = shen_apply_direct(ctx, "shen.<-out", 1, a710);
  }
  KLObject* t712;
  {
    KLObject* a712[] = {t704};
    t712 = shen_apply_direct(ctx, "shen.in->", 1, a712);
  }
  KLObject* t714;
  {
    KLObject* a714[] = {t712};
    t714 = shen_apply_direct(ctx, "shen.<syntax>", 1, a714);
  }
  KLObject* t717;
  {
    KLObject* a717[] = {t714};
    t717 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a717);
  }
  KLObject* t716;
  if (!shen_is_boolean(ctx, t717))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t717)) {
  KLObject* t719 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t716 = t719;
  } else {
  KLObject* t720;
  {
    KLObject* a720[] = {t714};
    t720 = shen_apply_direct(ctx, "shen.<-out", 1, a720);
  }
  KLObject* t722;
  {
    KLObject* a722[] = {t714};
    t722 = shen_apply_direct(ctx, "shen.in->", 1, a722);
  }
  KLObject* t728 = shen_cons(ctx, t710, t720);
  KLObject* t724;
  {
    KLObject* a724[] = {t722, t728};
    t724 = shen_apply_direct(ctx, "shen.comb", 2, a724);
  }
    t716 = t724;
  }
    t706 = t716;
  }
  KLObject* t730;
  {
    KLObject* a730[] = {t706};
    t730 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a730);
  }
  KLObject* t729;
  if (!shen_is_boolean(ctx, t730))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t730)) {
  KLObject* t732;
  {
    KLObject* a732[] = {t703};
    t732 = shen_apply_direct(ctx, "shen.<syntax-item>", 1, a732);
  }
  KLObject* t735;
  {
    KLObject* a735[] = {t732};
    t735 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a735);
  }
  KLObject* t734;
  if (!shen_is_boolean(ctx, t735))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t735)) {
  KLObject* t737 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t734 = t737;
  } else {
  KLObject* t738;
  {
    KLObject* a738[] = {t732};
    t738 = shen_apply_direct(ctx, "shen.<-out", 1, a738);
  }
  KLObject* t740;
  {
    KLObject* a740[] = {t732};
    t740 = shen_apply_direct(ctx, "shen.in->", 1, a740);
  }
  KLObject* t745 = shen_empty_list(ctx);
  KLObject* t746 = shen_cons(ctx, t738, t745);
  KLObject* t742;
  {
    KLObject* a742[] = {t740, t746};
    t742 = shen_apply_direct(ctx, "shen.comb", 2, a742);
  }
    t734 = t742;
  }
  KLObject* t748;
  {
    KLObject* a748[] = {t734};
    t748 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a748);
  }
  KLObject* t747;
  if (!shen_is_boolean(ctx, t748))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t748)) {
  KLObject* t750 = shen_tail_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t747 = t750;
  } else {
    t747 = t734;
  }
    t729 = t747;
  } else {
    t729 = t706;
  }
    return t729;
  }
}

static KLObject* native_kl_shen_2e_3csyntax_2ditem_3e_22 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t753 = objects[0];
  tail_start_kl_shen_2e_3csyntax_2ditem_3e_22: ;
  KLObject* t756 = shen_cons_p(ctx, t753);
  KLObject* t754;
  if (!shen_is_boolean(ctx, t756))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t756)) {
  KLObject* t757;
  {
    KLObject* a757[] = {t753};
    t757 = shen_apply_direct(ctx, "head", 1, a757);
  }
  KLObject* t759;
  {
    KLObject* a759[] = {t753};
    t759 = shen_apply_direct(ctx, "tail", 1, a759);
  }
  KLObject* t762;
  {
    KLObject* a762[] = {t757};
    t762 = shen_apply_direct(ctx, "shen.syntax-item?", 1, a762);
  }
  KLObject* t761;
  if (!shen_is_boolean(ctx, t762))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t762)) {
  KLObject* t764;
  {
    KLObject* a764[] = {t759, t757};
    t764 = shen_apply_direct(ctx, "shen.comb", 2, a764);
  }
    t761 = t764;
  } else {
  KLObject* t767 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t761 = t767;
  }
    t754 = t761;
  } else {
  KLObject* t768 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t754 = t768;
  }
  KLObject* t770;
  {
    KLObject* a770[] = {t754};
    t770 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a770);
  }
  KLObject* t769;
  if (!shen_is_boolean(ctx, t770))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t770)) {
  KLObject* t772 = shen_tail_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t769 = t772;
  } else {
    t769 = t754;
  }
    return t769;
  }
}

static KLObject* native_kl_shen_2esyntax_2ditem_3f_23 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t774 = objects[0];
  tail_start_kl_shen_2esyntax_2ditem_3f_23: ;
  KLObject* t775;
  {
  KLObject* t776;
  {
    KLObject* a776[] = {t774};
    t776 = shen_apply_direct(ctx, "shen.colon-equal?", 1, a776);
  }
    if (!shen_is_boolean(ctx, t776))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t776)) {
  KLObject* t778 = shen_false(ctx);
      t775 = t778;
    } else {
  KLObject* t779;
  {
    KLObject* a779[] = {t774};
    t779 = shen_apply_direct(ctx, "shen.semicolon?", 1, a779);
  }
    if (!shen_is_boolean(ctx, t779))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t779)) {
  KLObject* t781 = shen_false(ctx);
      t775 = t781;
    } else {
  KLObject* t782;
  {
    KLObject* a782[] = {t774};
    t782 = shen_apply_direct(ctx, "atom?", 1, a782);
  }
    if (!shen_is_boolean(ctx, t782))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t782)) {
  KLObject* t784 = shen_true(ctx);
      t775 = t784;
    } else {
  KLObject* t787 = shen_cons_p(ctx, t774);
  KLObject* t785;
  if (!shen_is_boolean(ctx, t787))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t787)) {
    t785 = t787;
  } else {
  KLObject* t789 = shen_intern(ctx, "cons");
  KLObject* t791 = shen_hd(ctx, t774);
  KLObject* t792 = shen_eq(ctx, t789, t791);
  KLObject* t788;
  if (!shen_is_boolean(ctx, t792))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t792)) {
    t788 = t792;
  } else {
  KLObject* t795 = shen_tl(ctx, t774);
  KLObject* t796 = shen_cons_p(ctx, t795);
  KLObject* t793;
  if (!shen_is_boolean(ctx, t796))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t796)) {
    t793 = t796;
  } else {
  KLObject* t799 = shen_tl(ctx, t774);
  KLObject* t800 = shen_tl(ctx, t799);
  KLObject* t801 = shen_cons_p(ctx, t800);
  KLObject* t797;
  if (!shen_is_boolean(ctx, t801))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t801)) {
    t797 = t801;
  } else {
  KLObject* t802 = shen_empty_list(ctx);
  KLObject* t804 = shen_tl(ctx, t774);
  KLObject* t805 = shen_tl(ctx, t804);
  KLObject* t806 = shen_tl(ctx, t805);
  KLObject* t807 = shen_eq(ctx, t802, t806);
    if (!shen_is_boolean(ctx, t807))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t797 = t807;
  }
    if (!shen_is_boolean(ctx, t797))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t793 = t797;
  }
    if (!shen_is_boolean(ctx, t793))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t788 = t793;
  }
    if (!shen_is_boolean(ctx, t788))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t785 = t788;
  }
    if (!shen_is_boolean(ctx, t785))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t785)) {
  KLObject* t811 = shen_tl(ctx, t774);
  KLObject* t812 = shen_hd(ctx, t811);
  KLObject* t809;
  {
    KLObject* a809[] = {t812};
    t809 = shen_apply_direct(ctx, "shen.syntax-item?", 1, a809);
  }
  KLObject* t808;
  if (!shen_is_boolean(ctx, t809))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t809)) {
    t808 = t809;
  } else {
  KLObject* t815 = shen_tl(ctx, t774);
  KLObject* t816 = shen_tl(ctx, t815);
  KLObject* t817 = shen_hd(ctx, t816);
  KLObject* t813;
  {
    KLObject* a813[] = {t817};
    t813 = shen_apply_direct(ctx, "shen.syntax-item?", 1, a813);
  }
    if (!shen_is_boolean(ctx, t813))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t808 = t813;
  }
      t775 = t808;
    } else {
  KLObject* t818 = shen_true(ctx);
    if (!shen_is_boolean(ctx, t818))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t818)) {
  KLObject* t819 = shen_false(ctx);
      t775 = t819;
    } else {
      shen_simple_error(ctx, "No true case found for cond");
      t775 = shen_empty_list(ctx);
    }
    }
    }
    }
    }
  }
    return t775;
  }
}

static KLObject* native_kl_shen_2e_3csemantics_3e_24 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t820 = objects[0];
  tail_start_kl_shen_2e_3csemantics_3e_24: ;
  KLObject* t821;
  {
    KLObject* a821[] = {t820};
    t821 = shen_apply_direct(ctx, "shen.<colon-equal>", 1, a821);
  }
  KLObject* t824;
  {
    KLObject* a824[] = {t821};
    t824 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a824);
  }
  KLObject* t823;
  if (!shen_is_boolean(ctx, t824))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t824)) {
  KLObject* t826 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t823 = t826;
  } else {
  KLObject* t827;
  {
    KLObject* a827[] = {t821};
    t827 = shen_apply_direct(ctx, "shen.in->", 1, a827);
  }
  KLObject* t831 = shen_cons_p(ctx, t827);
  KLObject* t829;
  if (!shen_is_boolean(ctx, t831))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t831)) {
  KLObject* t832;
  {
    KLObject* a832[] = {t827};
    t832 = shen_apply_direct(ctx, "head", 1, a832);
  }
  KLObject* t834;
  {
    KLObject* a834[] = {t827};
    t834 = shen_apply_direct(ctx, "tail", 1, a834);
  }
  KLObject* t839 = shen_intern(ctx, "where");
  KLObject* t837;
  {
    KLObject* a837[] = {t834, t839};
    t837 = shen_apply_direct(ctx, "shen.hds=?", 2, a837);
  }
  KLObject* t836;
  if (!shen_is_boolean(ctx, t837))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t837)) {
  KLObject* t840;
  {
    KLObject* a840[] = {t834};
    t840 = shen_apply_direct(ctx, "tail", 1, a840);
  }
  KLObject* t844 = shen_cons_p(ctx, t840);
  KLObject* t842;
  if (!shen_is_boolean(ctx, t844))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t844)) {
  KLObject* t845;
  {
    KLObject* a845[] = {t840};
    t845 = shen_apply_direct(ctx, "head", 1, a845);
  }
  KLObject* t847;
  {
    KLObject* a847[] = {t840};
    t847 = shen_apply_direct(ctx, "tail", 1, a847);
  }
  KLObject* t851;
  {
    KLObject* a851[] = {t832};
    t851 = shen_apply_direct(ctx, "shen.semicolon?", 1, a851);
  }
  KLObject* t850;
  {
    KLObject* a850[] = {t851};
    t850 = shen_apply_direct(ctx, "not", 1, a850);
  }
  KLObject* t849;
  if (!shen_is_boolean(ctx, t850))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t850)) {
  KLObject* t855 = shen_intern(ctx, "where");
  KLObject* t858 = shen_empty_list(ctx);
  KLObject* t859 = shen_cons(ctx, t832, t858);
  KLObject* t860 = shen_cons(ctx, t845, t859);
  KLObject* t861 = shen_cons(ctx, t855, t860);
  KLObject* t853;
  {
    KLObject* a853[] = {t847, t861};
    t853 = shen_apply_direct(ctx, "shen.comb", 2, a853);
  }
    t849 = t853;
  } else {
  KLObject* t862 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t849 = t862;
  }
    t842 = t849;
  } else {
  KLObject* t863 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t842 = t863;
  }
    t836 = t842;
  } else {
  KLObject* t864 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t836 = t864;
  }
    t829 = t836;
  } else {
  KLObject* t865 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t829 = t865;
  }
    t823 = t829;
  }
  KLObject* t867;
  {
    KLObject* a867[] = {t823};
    t867 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a867);
  }
  KLObject* t866;
  if (!shen_is_boolean(ctx, t867))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t867)) {
  KLObject* t869;
  {
    KLObject* a869[] = {t820};
    t869 = shen_apply_direct(ctx, "shen.<colon-equal>", 1, a869);
  }
  KLObject* t872;
  {
    KLObject* a872[] = {t869};
    t872 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a872);
  }
  KLObject* t871;
  if (!shen_is_boolean(ctx, t872))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t872)) {
  KLObject* t874 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t871 = t874;
  } else {
  KLObject* t875;
  {
    KLObject* a875[] = {t869};
    t875 = shen_apply_direct(ctx, "shen.in->", 1, a875);
  }
  KLObject* t879 = shen_cons_p(ctx, t875);
  KLObject* t877;
  if (!shen_is_boolean(ctx, t879))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t879)) {
  KLObject* t880;
  {
    KLObject* a880[] = {t875};
    t880 = shen_apply_direct(ctx, "head", 1, a880);
  }
  KLObject* t882;
  {
    KLObject* a882[] = {t875};
    t882 = shen_apply_direct(ctx, "tail", 1, a882);
  }
  KLObject* t886;
  {
    KLObject* a886[] = {t880};
    t886 = shen_apply_direct(ctx, "shen.semicolon?", 1, a886);
  }
  KLObject* t885;
  {
    KLObject* a885[] = {t886};
    t885 = shen_apply_direct(ctx, "not", 1, a885);
  }
  KLObject* t884;
  if (!shen_is_boolean(ctx, t885))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t885)) {
  KLObject* t888;
  {
    KLObject* a888[] = {t882, t880};
    t888 = shen_apply_direct(ctx, "shen.comb", 2, a888);
  }
    t884 = t888;
  } else {
  KLObject* t891 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t884 = t891;
  }
    t877 = t884;
  } else {
  KLObject* t892 = shen_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t877 = t892;
  }
    t871 = t877;
  }
  KLObject* t894;
  {
    KLObject* a894[] = {t871};
    t894 = shen_apply_direct(ctx, "shen.parse-failure?", 1, a894);
  }
  KLObject* t893;
  if (!shen_is_boolean(ctx, t894))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t894)) {
  KLObject* t896 = shen_tail_apply_direct(ctx, "shen.parse-failure", 0, NULL);
    t893 = t896;
  } else {
    t893 = t871;
  }
    t866 = t893;
  } else {
    t866 = t823;
  }
    return t866;
  }
}

static KLObject* native_kl_shen_2ec_2drules_2d_3eshen_25 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t899 = objects[0];
    KLObject* t900 = objects[1];
    KLObject* t901 = objects[2];
  tail_start_kl_shen_2ec_2drules_2d_3eshen_25: ;
  KLObject* t902;
  {
  KLObject* t903 = shen_empty_list(ctx);
  KLObject* t905 = shen_eq(ctx, t903, t901);
    if (!shen_is_boolean(ctx, t905))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t905)) {
  KLObject* t906 = shen_intern(ctx, "shen.parse-failure");
  KLObject* t907 = shen_empty_list(ctx);
  KLObject* t908 = shen_cons(ctx, t906, t907);
      t902 = t908;
    } else {
  KLObject* t910 = shen_cons_p(ctx, t901);
    if (!shen_is_boolean(ctx, t910))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t910)) {
  KLObject* t915 = shen_hd(ctx, t901);
  KLObject* t912;
  {
    KLObject* a912[] = {t899, t915, t900};
    t912 = shen_apply_direct(ctx, "shen.c-rule->shen", 3, a912);
  }
  KLObject* t921 = shen_tl(ctx, t901);
  KLObject* t917;
  {
    KLObject* a917[] = {t899, t900, t921};
    t917 = shen_apply_direct(ctx, "shen.c-rules->shen", 3, a917);
  }
  KLObject* t911;
  {
    KLObject* a911[] = {t912, t917};
    t911 = shen_tail_apply_direct(ctx, "shen.combine-c-code", 2, a911);
  }
      t902 = t911;
    } else {
  KLObject* t922 = shen_true(ctx);
    if (!shen_is_boolean(ctx, t922))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t922)) {
  KLObject* t924 = shen_string(ctx, "implementation error in shen.c-rules->shen\n");
  KLObject* t923;
  {
    KLObject* a923[] = {t924};
    t923 = shen_tail_apply_direct(ctx, "simple-error", 1, a923);
  }
      t902 = t923;
    } else {
      shen_simple_error(ctx, "No true case found for cond");
      t902 = shen_empty_list(ctx);
    }
    }
    }
  }
    return t902;
  }
}

static KLObject* native_kl_shen_2eparse_2dfailure_26 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  (void)function_object;
  (void)arguments;
  {
  tail_start_kl_shen_2eparse_2dfailure_26: ;
  KLObject* t925 = shen_tail_apply_direct(ctx, "fail", 0, NULL);
    return t925;
  }
}

static KLObject* native_kl_shen_2ecombine_2dc_2dcode_27 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t926 = objects[0];
    KLObject* t927 = objects[1];
  tail_start_kl_shen_2ecombine_2dc_2dcode_27: ;
  KLObject* t928 = shen_intern(ctx, "let");
  KLObject* t929 = shen_intern(ctx, "Result");
  KLObject* t931 = shen_intern(ctx, "if");
  KLObject* t932 = shen_intern(ctx, "shen.parse-failure?");
  KLObject* t933 = shen_intern(ctx, "Result");
  KLObject* t934 = shen_empty_list(ctx);
  KLObject* t935 = shen_cons(ctx, t933, t934);
  KLObject* t936 = shen_cons(ctx, t932, t935);
  KLObject* t938 = shen_intern(ctx, "Result");
  KLObject* t939 = shen_empty_list(ctx);
  KLObject* t940 = shen_cons(ctx, t938, t939);
  KLObject* t941 = shen_cons(ctx, t927, t940);
  KLObject* t942 = shen_cons(ctx, t936, t941);
  KLObject* t943 = shen_cons(ctx, t931, t942);
  KLObject* t944 = shen_empty_list(ctx);
  KLObject* t945 = shen_cons(ctx, t943, t944);
  KLObject* t946 = shen_cons(ctx, t926, t945);
  KLObject* t947 = shen_cons(ctx, t929, t946);
  KLObject* t948 = shen_cons(ctx, t928, t947);
    return t948;
  }
}

static KLObject* native_kl_shen_2ec_2drule_2d_3eshen_28 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t949 = objects[0];
    KLObject* t950 = objects[1];
    KLObject* t951 = objects[2];
  tail_start_kl_shen_2ec_2drule_2d_3eshen_28: ;
  KLObject* t952;
  {
  KLObject* t955 = shen_cons_p(ctx, t950);
  KLObject* t953;
  if (!shen_is_boolean(ctx, t955))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t955)) {
    t953 = t955;
  } else {
  KLObject* t958 = shen_tl(ctx, t950);
  KLObject* t959 = shen_cons_p(ctx, t958);
  KLObject* t956;
  if (!shen_is_boolean(ctx, t959))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t959)) {
    t956 = t959;
  } else {
  KLObject* t960 = shen_empty_list(ctx);
  KLObject* t962 = shen_tl(ctx, t950);
  KLObject* t963 = shen_tl(ctx, t962);
  KLObject* t964 = shen_eq(ctx, t960, t963);
    if (!shen_is_boolean(ctx, t964))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t956 = t964;
  }
    if (!shen_is_boolean(ctx, t956))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t953 = t956;
  }
    if (!shen_is_boolean(ctx, t953))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t953)) {
  KLObject* t969 = shen_hd(ctx, t950);
  KLObject* t971 = shen_tl(ctx, t950);
  KLObject* t972 = shen_hd(ctx, t971);
  KLObject* t965;
  {
    KLObject* a965[] = {t949, t951, t969, t972};
    t965 = shen_tail_apply_direct(ctx, "shen.yacc-syntax", 4, a965);
  }
      t952 = t965;
    } else {
  KLObject* t973 = shen_true(ctx);
    if (!shen_is_boolean(ctx, t973))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t973)) {
  KLObject* t975 = shen_string(ctx, "implementation error in shen.c-rule->shen\n");
  KLObject* t974;
  {
    KLObject* a974[] = {t975};
    t974 = shen_tail_apply_direct(ctx, "simple-error", 1, a974);
  }
      t952 = t974;
    } else {
      shen_simple_error(ctx, "No true case found for cond");
      t952 = shen_empty_list(ctx);
    }
    }
  }
    return t952;
  }
}

static KLObject* native_kl_shen_2eyacc_2dsyntax_29 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t976 = objects[0];
    KLObject* t977 = objects[1];
    KLObject* t978 = objects[2];
    KLObject* t979 = objects[3];
  tail_start_kl_shen_2eyacc_2dsyntax_29: ;
  KLObject* t980;
  {
  KLObject* t982 = shen_empty_list(ctx);
  KLObject* t984 = shen_eq(ctx, t982, t978);
  KLObject* t981;
  if (!shen_is_boolean(ctx, t984))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t984)) {
    t981 = t984;
  } else {
  KLObject* t987 = shen_cons_p(ctx, t979);
  KLObject* t985;
  if (!shen_is_boolean(ctx, t987))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t987)) {
    t985 = t987;
  } else {
  KLObject* t989 = shen_intern(ctx, "where");
  KLObject* t991 = shen_hd(ctx, t979);
  KLObject* t992 = shen_eq(ctx, t989, t991);
  KLObject* t988;
  if (!shen_is_boolean(ctx, t992))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t992)) {
    t988 = t992;
  } else {
  KLObject* t995 = shen_tl(ctx, t979);
  KLObject* t996 = shen_cons_p(ctx, t995);
  KLObject* t993;
  if (!shen_is_boolean(ctx, t996))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t996)) {
    t993 = t996;
  } else {
  KLObject* t999 = shen_tl(ctx, t979);
  KLObject* t1000 = shen_tl(ctx, t999);
  KLObject* t1001 = shen_cons_p(ctx, t1000);
  KLObject* t997;
  if (!shen_is_boolean(ctx, t1001))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t1001)) {
    t997 = t1001;
  } else {
  KLObject* t1002 = shen_empty_list(ctx);
  KLObject* t1004 = shen_tl(ctx, t979);
  KLObject* t1005 = shen_tl(ctx, t1004);
  KLObject* t1006 = shen_tl(ctx, t1005);
  KLObject* t1007 = shen_eq(ctx, t1002, t1006);
    if (!shen_is_boolean(ctx, t1007))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t997 = t1007;
  }
    if (!shen_is_boolean(ctx, t997))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t993 = t997;
  }
    if (!shen_is_boolean(ctx, t993))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t988 = t993;
  }
    if (!shen_is_boolean(ctx, t988))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t985 = t988;
  }
    if (!shen_is_boolean(ctx, t985))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t981 = t985;
  }
    if (!shen_is_boolean(ctx, t981))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t981)) {
  KLObject* t1008 = shen_intern(ctx, "if");
  KLObject* t1011 = shen_tl(ctx, t979);
  KLObject* t1012 = shen_hd(ctx, t1011);
  KLObject* t1009;
  {
    KLObject* a1009[] = {t1012};
    t1009 = shen_apply_direct(ctx, "shen.process-yacc-semantics", 1, a1009);
  }
  KLObject* t1016 = shen_empty_list(ctx);
  KLObject* t1018 = shen_tl(ctx, t979);
  KLObject* t1019 = shen_tl(ctx, t1018);
  KLObject* t1020 = shen_hd(ctx, t1019);
  KLObject* t1013;
  {
    KLObject* a1013[] = {t976, t977, t1016, t1020};
    t1013 = shen_apply_direct(ctx, "shen.yacc-syntax", 4, a1013);
  }
  KLObject* t1021 = shen_intern(ctx, "shen.parse-failure");
  KLObject* t1022 = shen_empty_list(ctx);
  KLObject* t1023 = shen_cons(ctx, t1021, t1022);
  KLObject* t1024 = shen_empty_list(ctx);
  KLObject* t1025 = shen_cons(ctx, t1023, t1024);
  KLObject* t1026 = shen_cons(ctx, t1013, t1025);
  KLObject* t1027 = shen_cons(ctx, t1009, t1026);
  KLObject* t1028 = shen_cons(ctx, t1008, t1027);
      t980 = t1028;
    } else {
  KLObject* t1029 = shen_empty_list(ctx);
  KLObject* t1031 = shen_eq(ctx, t1029, t978);
    if (!shen_is_boolean(ctx, t1031))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t1031)) {
  KLObject* t1032;
  {
    KLObject* a1032[] = {t976, t977, t979};
    t1032 = shen_tail_apply_direct(ctx, "shen.yacc-semantics", 3, a1032);
  }
      t980 = t1032;
    } else {
  KLObject* t1037 = shen_cons_p(ctx, t978);
    if (!shen_is_boolean(ctx, t1037))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t1037)) {
  KLObject* t1041 = shen_hd(ctx, t978);
  KLObject* t1039;
  {
    KLObject* a1039[] = {t1041};
    t1039 = shen_apply_direct(ctx, "shen.non-terminal?", 1, a1039);
  }
  KLObject* t1038;
  if (!shen_is_boolean(ctx, t1039))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1039)) {
  KLObject* t1046 = shen_hd(ctx, t978);
  KLObject* t1048 = shen_tl(ctx, t978);
  KLObject* t1042;
  {
    KLObject* a1042[] = {t976, t977, t1046, t1048, t979};
    t1042 = shen_tail_apply_direct(ctx, "shen.non-terminalcode", 5, a1042);
  }
    t1038 = t1042;
  } else {
  KLObject* t1053 = shen_hd(ctx, t978);
  KLObject* t1051;
  {
    KLObject* a1051[] = {t1053};
    t1051 = shen_apply_direct(ctx, "variable?", 1, a1051);
  }
  KLObject* t1050;
  if (!shen_is_boolean(ctx, t1051))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1051)) {
  KLObject* t1058 = shen_hd(ctx, t978);
  KLObject* t1060 = shen_tl(ctx, t978);
  KLObject* t1054;
  {
    KLObject* a1054[] = {t976, t977, t1058, t1060, t979};
    t1054 = shen_tail_apply_direct(ctx, "shen.variablecode", 5, a1054);
  }
    t1050 = t1054;
  } else {
  KLObject* t1063 = shen_intern(ctx, "_");
  KLObject* t1065 = shen_hd(ctx, t978);
  KLObject* t1066 = shen_eq(ctx, t1063, t1065);
  KLObject* t1062;
  if (!shen_is_boolean(ctx, t1066))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1066)) {
  KLObject* t1071 = shen_hd(ctx, t978);
  KLObject* t1073 = shen_tl(ctx, t978);
  KLObject* t1067;
  {
    KLObject* a1067[] = {t976, t977, t1071, t1073, t979};
    t1067 = shen_tail_apply_direct(ctx, "shen.wildcardcode", 5, a1067);
  }
    t1062 = t1067;
  } else {
  KLObject* t1078 = shen_hd(ctx, t978);
  KLObject* t1076;
  {
    KLObject* a1076[] = {t1078};
    t1076 = shen_apply_direct(ctx, "atom?", 1, a1076);
  }
  KLObject* t1075;
  if (!shen_is_boolean(ctx, t1076))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1076)) {
  KLObject* t1083 = shen_hd(ctx, t978);
  KLObject* t1085 = shen_tl(ctx, t978);
  KLObject* t1079;
  {
    KLObject* a1079[] = {t976, t977, t1083, t1085, t979};
    t1079 = shen_tail_apply_direct(ctx, "shen.terminalcode", 5, a1079);
  }
    t1075 = t1079;
  } else {
  KLObject* t1089 = shen_hd(ctx, t978);
  KLObject* t1090 = shen_cons_p(ctx, t1089);
  KLObject* t1087;
  if (!shen_is_boolean(ctx, t1090))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1090)) {
  KLObject* t1095 = shen_hd(ctx, t978);
  KLObject* t1097 = shen_tl(ctx, t978);
  KLObject* t1091;
  {
    KLObject* a1091[] = {t976, t977, t1095, t1097, t979};
    t1091 = shen_tail_apply_direct(ctx, "shen.conscode", 5, a1091);
  }
    t1087 = t1091;
  } else {
  KLObject* t1100 = shen_string(ctx, "implementation error in shen.yacc-syntax\n");
  KLObject* t1099;
  {
    KLObject* a1099[] = {t1100};
    t1099 = shen_tail_apply_direct(ctx, "simple-error", 1, a1099);
  }
    t1087 = t1099;
  }
    t1075 = t1087;
  }
    t1062 = t1075;
  }
    t1050 = t1062;
  }
    t1038 = t1050;
  }
      t980 = t1038;
    } else {
  KLObject* t1101 = shen_true(ctx);
    if (!shen_is_boolean(ctx, t1101))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t1101)) {
  KLObject* t1103 = shen_string(ctx, "implementation error in shen.yacc-syntax\n");
  KLObject* t1102;
  {
    KLObject* a1102[] = {t1103};
    t1102 = shen_tail_apply_direct(ctx, "simple-error", 1, a1102);
  }
      t980 = t1102;
    } else {
      shen_simple_error(ctx, "No true case found for cond");
      t980 = shen_empty_list(ctx);
    }
    }
    }
    }
  }
    return t980;
  }
}

static KLObject* native_kl_shen_2enon_2dterminalcode_30 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t1104 = objects[0];
    KLObject* t1105 = objects[1];
    KLObject* t1106 = objects[2];
    KLObject* t1107 = objects[3];
    KLObject* t1108 = objects[4];
  tail_start_kl_shen_2enon_2dterminalcode_30: ;
  KLObject* t1110 = shen_intern(ctx, "Parse");
  KLObject* t1109;
  {
    KLObject* a1109[] = {t1110, t1106};
    t1109 = shen_apply_direct(ctx, "concat", 2, a1109);
  }
  KLObject* t1113 = shen_intern(ctx, "Action");
  KLObject* t1112;
  {
    KLObject* a1112[] = {t1113, t1106};
    t1112 = shen_apply_direct(ctx, "concat", 2, a1112);
  }
  KLObject* t1116 = shen_intern(ctx, "Remainder");
  KLObject* t1115;
  {
    KLObject* a1115[] = {t1116, t1106};
    t1115 = shen_apply_direct(ctx, "concat", 2, a1115);
  }
  KLObject* t1118 = shen_intern(ctx, "let");
  KLObject* t1122 = shen_empty_list(ctx);
  KLObject* t1123 = shen_cons(ctx, t1105, t1122);
  KLObject* t1124 = shen_cons(ctx, t1106, t1123);
  KLObject* t1125 = shen_intern(ctx, "if");
  KLObject* t1126 = shen_intern(ctx, "shen.parse-failure?");
  KLObject* t1128 = shen_empty_list(ctx);
  KLObject* t1129 = shen_cons(ctx, t1109, t1128);
  KLObject* t1130 = shen_cons(ctx, t1126, t1129);
  KLObject* t1131 = shen_intern(ctx, "shen.parse-failure");
  KLObject* t1132 = shen_empty_list(ctx);
  KLObject* t1133 = shen_cons(ctx, t1131, t1132);
  KLObject* t1134 = shen_intern(ctx, "let");
  KLObject* t1136 = shen_intern(ctx, "shen.in->");
  KLObject* t1138 = shen_empty_list(ctx);
  KLObject* t1139 = shen_cons(ctx, t1109, t1138);
  KLObject* t1140 = shen_cons(ctx, t1136, t1139);
  KLObject* t1141;
  {
    KLObject* a1141[] = {t1104, t1115, t1107, t1108};
    t1141 = shen_apply_direct(ctx, "shen.yacc-syntax", 4, a1141);
  }
  KLObject* t1146 = shen_empty_list(ctx);
  KLObject* t1147 = shen_cons(ctx, t1141, t1146);
  KLObject* t1148 = shen_cons(ctx, t1140, t1147);
  KLObject* t1149 = shen_cons(ctx, t1115, t1148);
  KLObject* t1150 = shen_cons(ctx, t1134, t1149);
  KLObject* t1153;
  {
    KLObject* a1153[] = {t1106, t1108};
    t1153 = shen_apply_direct(ctx, "shen.occurs-check?", 2, a1153);
  }
  KLObject* t1152;
  if (!shen_is_boolean(ctx, t1153))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (shen_boolean_value(ctx, t1153)) {
    t1152 = t1153;
  } else {
  KLObject* t1156;
  {
    KLObject* a1156[] = {t1112, t1108};
    t1156 = shen_apply_direct(ctx, "shen.occurs-check?", 2, a1156);
  }
    if (!shen_is_boolean(ctx, t1156))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t1152 = t1156;
  }
  KLObject* t1151;
  if (!shen_is_boolean(ctx, t1152))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1152)) {
  KLObject* t1159 = shen_intern(ctx, "let");
  KLObject* t1161 = shen_intern(ctx, "shen.<-out");
  KLObject* t1163 = shen_empty_list(ctx);
  KLObject* t1164 = shen_cons(ctx, t1109, t1163);
  KLObject* t1165 = shen_cons(ctx, t1161, t1164);
  KLObject* t1167 = shen_empty_list(ctx);
  KLObject* t1168 = shen_cons(ctx, t1150, t1167);
  KLObject* t1169 = shen_cons(ctx, t1165, t1168);
  KLObject* t1170 = shen_cons(ctx, t1112, t1169);
  KLObject* t1171 = shen_cons(ctx, t1159, t1170);
    t1151 = t1171;
  } else {
    t1151 = t1150;
  }
  KLObject* t1173 = shen_empty_list(ctx);
  KLObject* t1174 = shen_cons(ctx, t1151, t1173);
  KLObject* t1175 = shen_cons(ctx, t1133, t1174);
  KLObject* t1176 = shen_cons(ctx, t1130, t1175);
  KLObject* t1177 = shen_cons(ctx, t1125, t1176);
  KLObject* t1178 = shen_empty_list(ctx);
  KLObject* t1179 = shen_cons(ctx, t1177, t1178);
  KLObject* t1180 = shen_cons(ctx, t1124, t1179);
  KLObject* t1181 = shen_cons(ctx, t1109, t1180);
  KLObject* t1182 = shen_cons(ctx, t1118, t1181);
    return t1182;
  }
}

static KLObject* native_kl_shen_2evariablecode_31 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t1183 = objects[0];
    KLObject* t1184 = objects[1];
    KLObject* t1185 = objects[2];
    KLObject* t1186 = objects[3];
    KLObject* t1187 = objects[4];
  tail_start_kl_shen_2evariablecode_31: ;
  KLObject* t1189 = shen_intern(ctx, "Remainder");
  KLObject* t1188;
  {
    KLObject* a1188[] = {t1189};
    t1188 = shen_apply_direct(ctx, "gensym", 1, a1188);
  }
  KLObject* t1190 = shen_intern(ctx, "if");
  KLObject* t1191 = shen_intern(ctx, "cons?");
  KLObject* t1193 = shen_empty_list(ctx);
  KLObject* t1194 = shen_cons(ctx, t1184, t1193);
  KLObject* t1195 = shen_cons(ctx, t1191, t1194);
  KLObject* t1196 = shen_intern(ctx, "let");
  KLObject* t1198 = shen_intern(ctx, "tail");
  KLObject* t1200 = shen_empty_list(ctx);
  KLObject* t1201 = shen_cons(ctx, t1184, t1200);
  KLObject* t1202 = shen_cons(ctx, t1198, t1201);
  KLObject* t1203;
  {
    KLObject* a1203[] = {t1183, t1188, t1186, t1187};
    t1203 = shen_apply_direct(ctx, "shen.yacc-syntax", 4, a1203);
  }
  KLObject* t1208 = shen_empty_list(ctx);
  KLObject* t1209 = shen_cons(ctx, t1203, t1208);
  KLObject* t1210 = shen_cons(ctx, t1202, t1209);
  KLObject* t1211 = shen_cons(ctx, t1188, t1210);
  KLObject* t1212 = shen_cons(ctx, t1196, t1211);
  KLObject* t1214;
  {
    KLObject* a1214[] = {t1185, t1187};
    t1214 = shen_apply_direct(ctx, "shen.occurs-check?", 2, a1214);
  }
  KLObject* t1213;
  if (!shen_is_boolean(ctx, t1214))
    shen_simple_error(ctx, "Test should be a boolean value");
  if (shen_boolean_value(ctx, t1214)) {
  KLObject* t1217 = shen_intern(ctx, "let");
  KLObject* t1219 = shen_intern(ctx, "head");
  KLObject* t1221 = shen_empty_list(ctx);
  KLObject* t1222 = shen_cons(ctx, t1184, t1221);
  KLObject* t1223 = shen_cons(ctx, t1219, t1222);
  KLObject* t1225 = shen_empty_list(ctx);
  KLObject* t1226 = shen_cons(ctx, t1212, t1225);
  KLObject* t1227 = shen_cons(ctx, t1223, t1226);
  KLObject* t1228 = shen_cons(ctx, t1185, t1227);
  KLObject* t1229 = shen_cons(ctx, t1217, t1228);
    t1213 = t1229;
  } else {
    t1213 = t1212;
  }
  KLObject* t1231 = shen_intern(ctx, "shen.parse-failure");
  KLObject* t1232 = shen_empty_list(ctx);
  KLObject* t1233 = shen_cons(ctx, t1231, t1232);
  KLObject* t1234 = shen_empty_list(ctx);
  KLObject* t1235 = shen_cons(ctx, t1233, t1234);
  KLObject* t1236 = shen_cons(ctx, t1213, t1235);
  KLObject* t1237 = shen_cons(ctx, t1195, t1236);
  KLObject* t1238 = shen_cons(ctx, t1190, t1237);
    return t1238;
  }
}

static KLObject* native_kl_shen_2ewildcardcode_32 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t1239 = objects[0];
    KLObject* t1240 = objects[1];
    KLObject* t1241 = objects[2];
    KLObject* t1242 = objects[3];
    KLObject* t1243 = objects[4];
  tail_start_kl_shen_2ewildcardcode_32: ;
  KLObject* t1245 = shen_intern(ctx, "Remainder");
  KLObject* t1244;
  {
    KLObject* a1244[] = {t1245};
    t1244 = shen_apply_direct(ctx, "gensym", 1, a1244);
  }
  KLObject* t1246 = shen_intern(ctx, "if");
  KLObject* t1247 = shen_intern(ctx, "cons?");
  KLObject* t1249 = shen_empty_list(ctx);
  KLObject* t1250 = shen_cons(ctx, t1240, t1249);
  KLObject* t1251 = shen_cons(ctx, t1247, t1250);
  KLObject* t1252 = shen_intern(ctx, "let");
  KLObject* t1254 = shen_intern(ctx, "tail");
  KLObject* t1256 = shen_empty_list(ctx);
  KLObject* t1257 = shen_cons(ctx, t1240, t1256);
  KLObject* t1258 = shen_cons(ctx, t1254, t1257);
  KLObject* t1259;
  {
    KLObject* a1259[] = {t1239, t1244, t1242, t1243};
    t1259 = shen_apply_direct(ctx, "shen.yacc-syntax", 4, a1259);
  }
  KLObject* t1264 = shen_empty_list(ctx);
  KLObject* t1265 = shen_cons(ctx, t1259, t1264);
  KLObject* t1266 = shen_cons(ctx, t1258, t1265);
  KLObject* t1267 = shen_cons(ctx, t1244, t1266);
  KLObject* t1268 = shen_cons(ctx, t1252, t1267);
  KLObject* t1269 = shen_intern(ctx, "shen.parse-failure");
  KLObject* t1270 = shen_empty_list(ctx);
  KLObject* t1271 = shen_cons(ctx, t1269, t1270);
  KLObject* t1272 = shen_empty_list(ctx);
  KLObject* t1273 = shen_cons(ctx, t1271, t1272);
  KLObject* t1274 = shen_cons(ctx, t1268, t1273);
  KLObject* t1275 = shen_cons(ctx, t1251, t1274);
  KLObject* t1276 = shen_cons(ctx, t1246, t1275);
    return t1276;
  }
}

static KLObject* native_kl_shen_2eterminalcode_33 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t1277 = objects[0];
    KLObject* t1278 = objects[1];
    KLObject* t1279 = objects[2];
    KLObject* t1280 = objects[3];
    KLObject* t1281 = objects[4];
  tail_start_kl_shen_2eterminalcode_33: ;
  KLObject* t1283 = shen_intern(ctx, "Remainder");
  KLObject* t1282;
  {
    KLObject* a1282[] = {t1283};
    t1282 = shen_apply_direct(ctx, "gensym", 1, a1282);
  }
  KLObject* t1284 = shen_intern(ctx, "if");
  KLObject* t1285 = shen_intern(ctx, "shen.hds=?");
  KLObject* t1288 = shen_empty_list(ctx);
  KLObject* t1289 = shen_cons(ctx, t1279, t1288);
  KLObject* t1290 = shen_cons(ctx, t1278, t1289);
  KLObject* t1291 = shen_cons(ctx, t1285, t1290);
  KLObject* t1292 = shen_intern(ctx, "let");
  KLObject* t1294 = shen_intern(ctx, "tail");
  KLObject* t1296 = shen_empty_list(ctx);
  KLObject* t1297 = shen_cons(ctx, t1278, t1296);
  KLObject* t1298 = shen_cons(ctx, t1294, t1297);
  KLObject* t1299;
  {
    KLObject* a1299[] = {t1277, t1282, t1280, t1281};
    t1299 = shen_apply_direct(ctx, "shen.yacc-syntax", 4, a1299);
  }
  KLObject* t1304 = shen_empty_list(ctx);
  KLObject* t1305 = shen_cons(ctx, t1299, t1304);
  KLObject* t1306 = shen_cons(ctx, t1298, t1305);
  KLObject* t1307 = shen_cons(ctx, t1282, t1306);
  KLObject* t1308 = shen_cons(ctx, t1292, t1307);
  KLObject* t1309 = shen_intern(ctx, "shen.parse-failure");
  KLObject* t1310 = shen_empty_list(ctx);
  KLObject* t1311 = shen_cons(ctx, t1309, t1310);
  KLObject* t1312 = shen_empty_list(ctx);
  KLObject* t1313 = shen_cons(ctx, t1311, t1312);
  KLObject* t1314 = shen_cons(ctx, t1308, t1313);
  KLObject* t1315 = shen_cons(ctx, t1291, t1314);
  KLObject* t1316 = shen_cons(ctx, t1284, t1315);
    return t1316;
  }
}

static KLObject* native_kl_shen_2ehds_3d_3f_34 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t1317 = objects[0];
    KLObject* t1318 = objects[1];
  tail_start_kl_shen_2ehds_3d_3f_34: ;
  KLObject* t1319;
  {
  KLObject* t1322 = shen_cons_p(ctx, t1317);
  KLObject* t1320;
  if (!shen_is_boolean(ctx, t1322))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t1322)) {
    t1320 = t1322;
  } else {
  KLObject* t1324 = shen_hd(ctx, t1317);
  KLObject* t1326 = shen_eq(ctx, t1324, t1318);
    if (!shen_is_boolean(ctx, t1326))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t1320 = t1326;
  }
    if (!shen_is_boolean(ctx, t1320))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t1320)) {
  KLObject* t1327 = shen_true(ctx);
      t1319 = t1327;
    } else {
  KLObject* t1328 = shen_true(ctx);
    if (!shen_is_boolean(ctx, t1328))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t1328)) {
  KLObject* t1329 = shen_false(ctx);
      t1319 = t1329;
    } else {
      shen_simple_error(ctx, "No true case found for cond");
      t1319 = shen_empty_list(ctx);
    }
    }
  }
    return t1319;
  }
}

static KLObject* native_kl_shen_2econscode_35 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t1330 = objects[0];
    KLObject* t1331 = objects[1];
    KLObject* t1332 = objects[2];
    KLObject* t1333 = objects[3];
    KLObject* t1334 = objects[4];
  tail_start_kl_shen_2econscode_35: ;
  KLObject* t1336 = shen_intern(ctx, "Remainder");
  KLObject* t1335;
  {
    KLObject* a1335[] = {t1336};
    t1335 = shen_apply_direct(ctx, "gensym", 1, a1335);
  }
  KLObject* t1338 = shen_intern(ctx, "Hd");
  KLObject* t1337;
  {
    KLObject* a1337[] = {t1338};
    t1337 = shen_apply_direct(ctx, "gensym", 1, a1337);
  }
  KLObject* t1340 = shen_intern(ctx, "Tl");
  KLObject* t1339;
  {
    KLObject* a1339[] = {t1340};
    t1339 = shen_apply_direct(ctx, "gensym", 1, a1339);
  }
  KLObject* t1341 = shen_intern(ctx, "if");
  KLObject* t1342 = shen_intern(ctx, "shen.ccons?");
  KLObject* t1344 = shen_empty_list(ctx);
  KLObject* t1345 = shen_cons(ctx, t1331, t1344);
  KLObject* t1346 = shen_cons(ctx, t1342, t1345);
  KLObject* t1347 = shen_intern(ctx, "let");
  KLObject* t1349 = shen_intern(ctx, "head");
  KLObject* t1351 = shen_empty_list(ctx);
  KLObject* t1352 = shen_cons(ctx, t1331, t1351);
  KLObject* t1353 = shen_cons(ctx, t1349, t1352);
  KLObject* t1355 = shen_intern(ctx, "tail");
  KLObject* t1357 = shen_empty_list(ctx);
  KLObject* t1358 = shen_cons(ctx, t1331, t1357);
  KLObject* t1359 = shen_cons(ctx, t1355, t1358);
  KLObject* t1364;
  {
    KLObject* a1364[] = {t1332};
    t1364 = shen_apply_direct(ctx, "shen.decons", 1, a1364);
  }
  KLObject* t1366 = shen_intern(ctx, "<end>");
  KLObject* t1367 = shen_empty_list(ctx);
  KLObject* t1368 = shen_cons(ctx, t1366, t1367);
  KLObject* t1363;
  {
    KLObject* a1363[] = {t1364, t1368};
    t1363 = shen_apply_direct(ctx, "append", 2, a1363);
  }
  KLObject* t1369 = shen_intern(ctx, "shen.processed");
  KLObject* t1370;
  {
    KLObject* a1370[] = {t1330, t1339, t1333, t1334};
    t1370 = shen_apply_direct(ctx, "shen.yacc-syntax", 4, a1370);
  }
  KLObject* t1375 = shen_empty_list(ctx);
  KLObject* t1376 = shen_cons(ctx, t1370, t1375);
  KLObject* t1377 = shen_cons(ctx, t1369, t1376);
  KLObject* t1360;
  {
    KLObject* a1360[] = {t1330, t1337, t1363, t1377};
    t1360 = shen_apply_direct(ctx, "shen.yacc-syntax", 4, a1360);
  }
  KLObject* t1378 = shen_empty_list(ctx);
  KLObject* t1379 = shen_cons(ctx, t1360, t1378);
  KLObject* t1380 = shen_cons(ctx, t1359, t1379);
  KLObject* t1381 = shen_cons(ctx, t1339, t1380);
  KLObject* t1382 = shen_cons(ctx, t1353, t1381);
  KLObject* t1383 = shen_cons(ctx, t1337, t1382);
  KLObject* t1384 = shen_cons(ctx, t1347, t1383);
  KLObject* t1385 = shen_intern(ctx, "shen.parse-failure");
  KLObject* t1386 = shen_empty_list(ctx);
  KLObject* t1387 = shen_cons(ctx, t1385, t1386);
  KLObject* t1388 = shen_empty_list(ctx);
  KLObject* t1389 = shen_cons(ctx, t1387, t1388);
  KLObject* t1390 = shen_cons(ctx, t1384, t1389);
  KLObject* t1391 = shen_cons(ctx, t1346, t1390);
  KLObject* t1392 = shen_cons(ctx, t1341, t1391);
    return t1392;
  }
}

static KLObject* native_kl_shen_2eccons_3f_36 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t1393 = objects[0];
  tail_start_kl_shen_2eccons_3f_36: ;
  KLObject* t1394;
  {
  KLObject* t1397 = shen_cons_p(ctx, t1393);
  KLObject* t1395;
  if (!shen_is_boolean(ctx, t1397))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t1397)) {
    t1395 = t1397;
  } else {
  KLObject* t1399 = shen_hd(ctx, t1393);
  KLObject* t1400 = shen_cons_p(ctx, t1399);
    if (!shen_is_boolean(ctx, t1400))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t1395 = t1400;
  }
    if (!shen_is_boolean(ctx, t1395))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t1395)) {
  KLObject* t1401 = shen_true(ctx);
      t1394 = t1401;
    } else {
  KLObject* t1404 = shen_cons_p(ctx, t1393);
  KLObject* t1402;
  if (!shen_is_boolean(ctx, t1404))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t1404)) {
    t1402 = t1404;
  } else {
  KLObject* t1405 = shen_empty_list(ctx);
  KLObject* t1407 = shen_hd(ctx, t1393);
  KLObject* t1408 = shen_eq(ctx, t1405, t1407);
    if (!shen_is_boolean(ctx, t1408))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t1402 = t1408;
  }
    if (!shen_is_boolean(ctx, t1402))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t1402)) {
  KLObject* t1409 = shen_true(ctx);
      t1394 = t1409;
    } else {
  KLObject* t1410 = shen_true(ctx);
    if (!shen_is_boolean(ctx, t1410))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t1410)) {
  KLObject* t1411 = shen_false(ctx);
      t1394 = t1411;
    } else {
      shen_simple_error(ctx, "No true case found for cond");
      t1394 = shen_empty_list(ctx);
    }
    }
    }
  }
    return t1394;
  }
}

static KLObject* native_kl_shen_2edecons_37 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t1412 = objects[0];
  tail_start_kl_shen_2edecons_37: ;
  KLObject* t1413;
  {
  KLObject* t1416 = shen_cons_p(ctx, t1412);
  KLObject* t1414;
  if (!shen_is_boolean(ctx, t1416))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t1416)) {
    t1414 = t1416;
  } else {
  KLObject* t1418 = shen_intern(ctx, "cons");
  KLObject* t1420 = shen_hd(ctx, t1412);
  KLObject* t1421 = shen_eq(ctx, t1418, t1420);
  KLObject* t1417;
  if (!shen_is_boolean(ctx, t1421))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t1421)) {
    t1417 = t1421;
  } else {
  KLObject* t1424 = shen_tl(ctx, t1412);
  KLObject* t1425 = shen_cons_p(ctx, t1424);
  KLObject* t1422;
  if (!shen_is_boolean(ctx, t1425))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t1425)) {
    t1422 = t1425;
  } else {
  KLObject* t1428 = shen_tl(ctx, t1412);
  KLObject* t1429 = shen_tl(ctx, t1428);
  KLObject* t1430 = shen_cons_p(ctx, t1429);
  KLObject* t1426;
  if (!shen_is_boolean(ctx, t1430))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t1430)) {
    t1426 = t1430;
  } else {
  KLObject* t1431 = shen_empty_list(ctx);
  KLObject* t1433 = shen_tl(ctx, t1412);
  KLObject* t1434 = shen_tl(ctx, t1433);
  KLObject* t1435 = shen_tl(ctx, t1434);
  KLObject* t1436 = shen_eq(ctx, t1431, t1435);
    if (!shen_is_boolean(ctx, t1436))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t1426 = t1436;
  }
    if (!shen_is_boolean(ctx, t1426))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t1422 = t1426;
  }
    if (!shen_is_boolean(ctx, t1422))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t1417 = t1422;
  }
    if (!shen_is_boolean(ctx, t1417))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t1414 = t1417;
  }
    if (!shen_is_boolean(ctx, t1414))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t1414)) {
  KLObject* t1438 = shen_tl(ctx, t1412);
  KLObject* t1439 = shen_hd(ctx, t1438);
  KLObject* t1442 = shen_tl(ctx, t1412);
  KLObject* t1443 = shen_tl(ctx, t1442);
  KLObject* t1444 = shen_hd(ctx, t1443);
  KLObject* t1440;
  {
    KLObject* a1440[] = {t1444};
    t1440 = shen_apply_direct(ctx, "shen.decons", 1, a1440);
  }
  KLObject* t1445 = shen_cons(ctx, t1439, t1440);
      t1413 = t1445;
    } else {
  KLObject* t1446 = shen_true(ctx);
    if (!shen_is_boolean(ctx, t1446))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t1446)) {
      t1413 = t1412;
    } else {
      shen_simple_error(ctx, "No true case found for cond");
      t1413 = shen_empty_list(ctx);
    }
    }
  }
    return t1413;
  }
}

static KLObject* native_kl_shen_2ecomb_38 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t1448 = objects[0];
    KLObject* t1449 = objects[1];
  tail_start_kl_shen_2ecomb_38: ;
  KLObject* t1452 = shen_empty_list(ctx);
  KLObject* t1453 = shen_cons(ctx, t1449, t1452);
  KLObject* t1454 = shen_cons(ctx, t1448, t1453);
    return t1454;
  }
}

static KLObject* native_kl_shen_2eyacc_2dsemantics_39 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t1455 = objects[0];
    KLObject* t1456 = objects[1];
    KLObject* t1457 = objects[2];
  tail_start_kl_shen_2eyacc_2dsemantics_39: ;
  KLObject* t1458;
  {
  KLObject* t1461 = shen_cons_p(ctx, t1457);
  KLObject* t1459;
  if (!shen_is_boolean(ctx, t1461))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t1461)) {
    t1459 = t1461;
  } else {
  KLObject* t1463 = shen_intern(ctx, "shen.processed");
  KLObject* t1465 = shen_hd(ctx, t1457);
  KLObject* t1466 = shen_eq(ctx, t1463, t1465);
  KLObject* t1462;
  if (!shen_is_boolean(ctx, t1466))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t1466)) {
    t1462 = t1466;
  } else {
  KLObject* t1469 = shen_tl(ctx, t1457);
  KLObject* t1470 = shen_cons_p(ctx, t1469);
  KLObject* t1467;
  if (!shen_is_boolean(ctx, t1470))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t1470)) {
    t1467 = t1470;
  } else {
  KLObject* t1471 = shen_empty_list(ctx);
  KLObject* t1473 = shen_tl(ctx, t1457);
  KLObject* t1474 = shen_tl(ctx, t1473);
  KLObject* t1475 = shen_eq(ctx, t1471, t1474);
    if (!shen_is_boolean(ctx, t1475))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t1467 = t1475;
  }
    if (!shen_is_boolean(ctx, t1467))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t1462 = t1467;
  }
    if (!shen_is_boolean(ctx, t1462))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t1459 = t1462;
  }
    if (!shen_is_boolean(ctx, t1459))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t1459)) {
  KLObject* t1477 = shen_tl(ctx, t1457);
  KLObject* t1478 = shen_hd(ctx, t1477);
      t1458 = t1478;
    } else {
  KLObject* t1479 = shen_true(ctx);
    if (!shen_is_boolean(ctx, t1479))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t1479)) {
  KLObject* t1480;
  {
    KLObject* a1480[] = {t1457};
    t1480 = shen_apply_direct(ctx, "shen.process-yacc-semantics", 1, a1480);
  }
  KLObject* t1482;
  {
    KLObject* a1482[] = {t1455, t1480};
    t1482 = shen_apply_direct(ctx, "shen.use-type-info", 2, a1482);
  }
  KLObject* t1485 = shen_intern(ctx, "shen.comb");
  KLObject* t1488 = shen_empty_list(ctx);
  KLObject* t1489 = shen_cons(ctx, t1482, t1488);
  KLObject* t1490 = shen_cons(ctx, t1456, t1489);
  KLObject* t1491 = shen_cons(ctx, t1485, t1490);
      t1458 = t1491;
    } else {
      shen_simple_error(ctx, "No true case found for cond");
      t1458 = shen_empty_list(ctx);
    }
    }
  }
    return t1458;
  }
}

static KLObject* native_kl_shen_2euse_2dtype_2dinfo_40 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t1492 = objects[0];
    KLObject* t1493 = objects[1];
  tail_start_kl_shen_2euse_2dtype_2dinfo_40: ;
  KLObject* t1494;
  {
  KLObject* t1497 = shen_cons_p(ctx, t1492);
  KLObject* t1495;
  if (!shen_is_boolean(ctx, t1497))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t1497)) {
    t1495 = t1497;
  } else {
  KLObject* t1499 = shen_intern(ctx, "{");
  KLObject* t1501 = shen_hd(ctx, t1492);
  KLObject* t1502 = shen_eq(ctx, t1499, t1501);
  KLObject* t1498;
  if (!shen_is_boolean(ctx, t1502))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t1502)) {
    t1498 = t1502;
  } else {
  KLObject* t1505 = shen_tl(ctx, t1492);
  KLObject* t1506 = shen_cons_p(ctx, t1505);
  KLObject* t1503;
  if (!shen_is_boolean(ctx, t1506))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t1506)) {
    t1503 = t1506;
  } else {
  KLObject* t1509 = shen_tl(ctx, t1492);
  KLObject* t1510 = shen_hd(ctx, t1509);
  KLObject* t1511 = shen_cons_p(ctx, t1510);
  KLObject* t1507;
  if (!shen_is_boolean(ctx, t1511))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t1511)) {
    t1507 = t1511;
  } else {
  KLObject* t1513 = shen_intern(ctx, "list");
  KLObject* t1515 = shen_tl(ctx, t1492);
  KLObject* t1516 = shen_hd(ctx, t1515);
  KLObject* t1517 = shen_hd(ctx, t1516);
  KLObject* t1518 = shen_eq(ctx, t1513, t1517);
  KLObject* t1512;
  if (!shen_is_boolean(ctx, t1518))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t1518)) {
    t1512 = t1518;
  } else {
  KLObject* t1521 = shen_tl(ctx, t1492);
  KLObject* t1522 = shen_hd(ctx, t1521);
  KLObject* t1523 = shen_tl(ctx, t1522);
  KLObject* t1524 = shen_cons_p(ctx, t1523);
  KLObject* t1519;
  if (!shen_is_boolean(ctx, t1524))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t1524)) {
    t1519 = t1524;
  } else {
  KLObject* t1526 = shen_empty_list(ctx);
  KLObject* t1528 = shen_tl(ctx, t1492);
  KLObject* t1529 = shen_hd(ctx, t1528);
  KLObject* t1530 = shen_tl(ctx, t1529);
  KLObject* t1531 = shen_tl(ctx, t1530);
  KLObject* t1532 = shen_eq(ctx, t1526, t1531);
  KLObject* t1525;
  if (!shen_is_boolean(ctx, t1532))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t1532)) {
    t1525 = t1532;
  } else {
  KLObject* t1535 = shen_tl(ctx, t1492);
  KLObject* t1536 = shen_tl(ctx, t1535);
  KLObject* t1537 = shen_cons_p(ctx, t1536);
  KLObject* t1533;
  if (!shen_is_boolean(ctx, t1537))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t1537)) {
    t1533 = t1537;
  } else {
  KLObject* t1539 = shen_intern(ctx, "-->");
  KLObject* t1541 = shen_tl(ctx, t1492);
  KLObject* t1542 = shen_tl(ctx, t1541);
  KLObject* t1543 = shen_hd(ctx, t1542);
  KLObject* t1544 = shen_eq(ctx, t1539, t1543);
  KLObject* t1538;
  if (!shen_is_boolean(ctx, t1544))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t1544)) {
    t1538 = t1544;
  } else {
  KLObject* t1547 = shen_tl(ctx, t1492);
  KLObject* t1548 = shen_tl(ctx, t1547);
  KLObject* t1549 = shen_tl(ctx, t1548);
  KLObject* t1550 = shen_cons_p(ctx, t1549);
  KLObject* t1545;
  if (!shen_is_boolean(ctx, t1550))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t1550)) {
    t1545 = t1550;
  } else {
  KLObject* t1553 = shen_tl(ctx, t1492);
  KLObject* t1554 = shen_tl(ctx, t1553);
  KLObject* t1555 = shen_tl(ctx, t1554);
  KLObject* t1556 = shen_hd(ctx, t1555);
  KLObject* t1557 = shen_cons_p(ctx, t1556);
  KLObject* t1551;
  if (!shen_is_boolean(ctx, t1557))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t1557)) {
    t1551 = t1557;
  } else {
  KLObject* t1559 = shen_intern(ctx, "str");
  KLObject* t1561 = shen_tl(ctx, t1492);
  KLObject* t1562 = shen_tl(ctx, t1561);
  KLObject* t1563 = shen_tl(ctx, t1562);
  KLObject* t1564 = shen_hd(ctx, t1563);
  KLObject* t1565 = shen_hd(ctx, t1564);
  KLObject* t1566 = shen_eq(ctx, t1559, t1565);
  KLObject* t1558;
  if (!shen_is_boolean(ctx, t1566))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t1566)) {
    t1558 = t1566;
  } else {
  KLObject* t1569 = shen_tl(ctx, t1492);
  KLObject* t1570 = shen_tl(ctx, t1569);
  KLObject* t1571 = shen_tl(ctx, t1570);
  KLObject* t1572 = shen_hd(ctx, t1571);
  KLObject* t1573 = shen_tl(ctx, t1572);
  KLObject* t1574 = shen_cons_p(ctx, t1573);
  KLObject* t1567;
  if (!shen_is_boolean(ctx, t1574))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t1574)) {
    t1567 = t1574;
  } else {
  KLObject* t1577 = shen_tl(ctx, t1492);
  KLObject* t1578 = shen_tl(ctx, t1577);
  KLObject* t1579 = shen_tl(ctx, t1578);
  KLObject* t1580 = shen_hd(ctx, t1579);
  KLObject* t1581 = shen_tl(ctx, t1580);
  KLObject* t1582 = shen_hd(ctx, t1581);
  KLObject* t1583 = shen_cons_p(ctx, t1582);
  KLObject* t1575;
  if (!shen_is_boolean(ctx, t1583))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t1583)) {
    t1575 = t1583;
  } else {
  KLObject* t1585 = shen_intern(ctx, "list");
  KLObject* t1587 = shen_tl(ctx, t1492);
  KLObject* t1588 = shen_tl(ctx, t1587);
  KLObject* t1589 = shen_tl(ctx, t1588);
  KLObject* t1590 = shen_hd(ctx, t1589);
  KLObject* t1591 = shen_tl(ctx, t1590);
  KLObject* t1592 = shen_hd(ctx, t1591);
  KLObject* t1593 = shen_hd(ctx, t1592);
  KLObject* t1594 = shen_eq(ctx, t1585, t1593);
  KLObject* t1584;
  if (!shen_is_boolean(ctx, t1594))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t1594)) {
    t1584 = t1594;
  } else {
  KLObject* t1597 = shen_tl(ctx, t1492);
  KLObject* t1598 = shen_tl(ctx, t1597);
  KLObject* t1599 = shen_tl(ctx, t1598);
  KLObject* t1600 = shen_hd(ctx, t1599);
  KLObject* t1601 = shen_tl(ctx, t1600);
  KLObject* t1602 = shen_hd(ctx, t1601);
  KLObject* t1603 = shen_tl(ctx, t1602);
  KLObject* t1604 = shen_cons_p(ctx, t1603);
  KLObject* t1595;
  if (!shen_is_boolean(ctx, t1604))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t1604)) {
    t1595 = t1604;
  } else {
  KLObject* t1606 = shen_empty_list(ctx);
  KLObject* t1608 = shen_tl(ctx, t1492);
  KLObject* t1609 = shen_tl(ctx, t1608);
  KLObject* t1610 = shen_tl(ctx, t1609);
  KLObject* t1611 = shen_hd(ctx, t1610);
  KLObject* t1612 = shen_tl(ctx, t1611);
  KLObject* t1613 = shen_hd(ctx, t1612);
  KLObject* t1614 = shen_tl(ctx, t1613);
  KLObject* t1615 = shen_tl(ctx, t1614);
  KLObject* t1616 = shen_eq(ctx, t1606, t1615);
  KLObject* t1605;
  if (!shen_is_boolean(ctx, t1616))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t1616)) {
    t1605 = t1616;
  } else {
  KLObject* t1619 = shen_tl(ctx, t1492);
  KLObject* t1620 = shen_tl(ctx, t1619);
  KLObject* t1621 = shen_tl(ctx, t1620);
  KLObject* t1622 = shen_hd(ctx, t1621);
  KLObject* t1623 = shen_tl(ctx, t1622);
  KLObject* t1624 = shen_tl(ctx, t1623);
  KLObject* t1625 = shen_cons_p(ctx, t1624);
  KLObject* t1617;
  if (!shen_is_boolean(ctx, t1625))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t1625)) {
    t1617 = t1625;
  } else {
  KLObject* t1627 = shen_empty_list(ctx);
  KLObject* t1629 = shen_tl(ctx, t1492);
  KLObject* t1630 = shen_tl(ctx, t1629);
  KLObject* t1631 = shen_tl(ctx, t1630);
  KLObject* t1632 = shen_hd(ctx, t1631);
  KLObject* t1633 = shen_tl(ctx, t1632);
  KLObject* t1634 = shen_tl(ctx, t1633);
  KLObject* t1635 = shen_tl(ctx, t1634);
  KLObject* t1636 = shen_eq(ctx, t1627, t1635);
  KLObject* t1626;
  if (!shen_is_boolean(ctx, t1636))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t1636)) {
    t1626 = t1636;
  } else {
  KLObject* t1639 = shen_tl(ctx, t1492);
  KLObject* t1640 = shen_tl(ctx, t1639);
  KLObject* t1641 = shen_tl(ctx, t1640);
  KLObject* t1642 = shen_tl(ctx, t1641);
  KLObject* t1643 = shen_cons_p(ctx, t1642);
  KLObject* t1637;
  if (!shen_is_boolean(ctx, t1643))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t1643)) {
    t1637 = t1643;
  } else {
  KLObject* t1645 = shen_intern(ctx, "}");
  KLObject* t1647 = shen_tl(ctx, t1492);
  KLObject* t1648 = shen_tl(ctx, t1647);
  KLObject* t1649 = shen_tl(ctx, t1648);
  KLObject* t1650 = shen_tl(ctx, t1649);
  KLObject* t1651 = shen_hd(ctx, t1650);
  KLObject* t1652 = shen_eq(ctx, t1645, t1651);
  KLObject* t1644;
  if (!shen_is_boolean(ctx, t1652))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t1652)) {
    t1644 = t1652;
  } else {
  KLObject* t1654 = shen_empty_list(ctx);
  KLObject* t1656 = shen_tl(ctx, t1492);
  KLObject* t1657 = shen_tl(ctx, t1656);
  KLObject* t1658 = shen_tl(ctx, t1657);
  KLObject* t1659 = shen_tl(ctx, t1658);
  KLObject* t1660 = shen_tl(ctx, t1659);
  KLObject* t1661 = shen_eq(ctx, t1654, t1660);
  KLObject* t1653;
  if (!shen_is_boolean(ctx, t1661))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t1661)) {
    t1653 = t1661;
  } else {
  KLObject* t1664 = shen_tl(ctx, t1492);
  KLObject* t1665 = shen_hd(ctx, t1664);
  KLObject* t1666 = shen_tl(ctx, t1665);
  KLObject* t1667 = shen_hd(ctx, t1666);
  KLObject* t1669 = shen_tl(ctx, t1492);
  KLObject* t1670 = shen_tl(ctx, t1669);
  KLObject* t1671 = shen_tl(ctx, t1670);
  KLObject* t1672 = shen_hd(ctx, t1671);
  KLObject* t1673 = shen_tl(ctx, t1672);
  KLObject* t1674 = shen_hd(ctx, t1673);
  KLObject* t1675 = shen_tl(ctx, t1674);
  KLObject* t1676 = shen_hd(ctx, t1675);
  KLObject* t1677 = shen_eq(ctx, t1667, t1676);
  KLObject* t1662;
  if (!shen_is_boolean(ctx, t1677))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t1677)) {
    t1662 = t1677;
  } else {
  KLObject* t1680 = shen_tl(ctx, t1492);
  KLObject* t1681 = shen_tl(ctx, t1680);
  KLObject* t1682 = shen_tl(ctx, t1681);
  KLObject* t1683 = shen_hd(ctx, t1682);
  KLObject* t1684 = shen_tl(ctx, t1683);
  KLObject* t1685 = shen_tl(ctx, t1684);
  KLObject* t1686 = shen_hd(ctx, t1685);
  KLObject* t1678;
  {
    KLObject* a1678[] = {t1686};
    t1678 = shen_apply_direct(ctx, "shen.monomorphic?", 1, a1678);
  }
    if (!shen_is_boolean(ctx, t1678))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t1662 = t1678;
  }
    if (!shen_is_boolean(ctx, t1662))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t1653 = t1662;
  }
    if (!shen_is_boolean(ctx, t1653))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t1644 = t1653;
  }
    if (!shen_is_boolean(ctx, t1644))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t1637 = t1644;
  }
    if (!shen_is_boolean(ctx, t1637))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t1626 = t1637;
  }
    if (!shen_is_boolean(ctx, t1626))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t1617 = t1626;
  }
    if (!shen_is_boolean(ctx, t1617))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t1605 = t1617;
  }
    if (!shen_is_boolean(ctx, t1605))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t1595 = t1605;
  }
    if (!shen_is_boolean(ctx, t1595))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t1584 = t1595;
  }
    if (!shen_is_boolean(ctx, t1584))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t1575 = t1584;
  }
    if (!shen_is_boolean(ctx, t1575))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t1567 = t1575;
  }
    if (!shen_is_boolean(ctx, t1567))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t1558 = t1567;
  }
    if (!shen_is_boolean(ctx, t1558))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t1551 = t1558;
  }
    if (!shen_is_boolean(ctx, t1551))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t1545 = t1551;
  }
    if (!shen_is_boolean(ctx, t1545))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t1538 = t1545;
  }
    if (!shen_is_boolean(ctx, t1538))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t1533 = t1538;
  }
    if (!shen_is_boolean(ctx, t1533))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t1525 = t1533;
  }
    if (!shen_is_boolean(ctx, t1525))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t1519 = t1525;
  }
    if (!shen_is_boolean(ctx, t1519))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t1512 = t1519;
  }
    if (!shen_is_boolean(ctx, t1512))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t1507 = t1512;
  }
    if (!shen_is_boolean(ctx, t1507))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t1503 = t1507;
  }
    if (!shen_is_boolean(ctx, t1503))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t1498 = t1503;
  }
    if (!shen_is_boolean(ctx, t1498))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t1495 = t1498;
  }
    if (!shen_is_boolean(ctx, t1495))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t1495)) {
  KLObject* t1687 = shen_intern(ctx, "type");
  KLObject* t1690 = shen_tl(ctx, t1492);
  KLObject* t1691 = shen_tl(ctx, t1690);
  KLObject* t1692 = shen_tl(ctx, t1691);
  KLObject* t1693 = shen_hd(ctx, t1692);
  KLObject* t1694 = shen_tl(ctx, t1693);
  KLObject* t1695 = shen_tl(ctx, t1694);
  KLObject* t1696 = shen_cons(ctx, t1493, t1695);
  KLObject* t1697 = shen_cons(ctx, t1687, t1696);
      t1494 = t1697;
    } else {
  KLObject* t1698 = shen_true(ctx);
    if (!shen_is_boolean(ctx, t1698))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t1698)) {
      t1494 = t1493;
    } else {
      shen_simple_error(ctx, "No true case found for cond");
      t1494 = shen_empty_list(ctx);
    }
    }
  }
    return t1494;
  }
}

static KLObject* native_kl_shen_2emonomorphic_3f_41 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t1700 = objects[0];
  tail_start_kl_shen_2emonomorphic_3f_41: ;
  KLObject* t1701;
  {
  KLObject* t1702;
  {
    KLObject* a1702[] = {t1700};
    t1702 = shen_apply_direct(ctx, "variable?", 1, a1702);
  }
    if (!shen_is_boolean(ctx, t1702))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t1702)) {
  KLObject* t1704 = shen_false(ctx);
      t1701 = t1704;
    } else {
  KLObject* t1706 = shen_cons_p(ctx, t1700);
    if (!shen_is_boolean(ctx, t1706))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t1706)) {
  KLObject* t1710 = shen_hd(ctx, t1700);
  KLObject* t1708;
  {
    KLObject* a1708[] = {t1710};
    t1708 = shen_apply_direct(ctx, "shen.monomorphic?", 1, a1708);
  }
  KLObject* t1707;
  if (!shen_is_boolean(ctx, t1708))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t1708)) {
    t1707 = t1708;
  } else {
  KLObject* t1713 = shen_tl(ctx, t1700);
  KLObject* t1711;
  {
    KLObject* a1711[] = {t1713};
    t1711 = shen_apply_direct(ctx, "shen.monomorphic?", 1, a1711);
  }
    if (!shen_is_boolean(ctx, t1711))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t1707 = t1711;
  }
      t1701 = t1707;
    } else {
  KLObject* t1714 = shen_true(ctx);
    if (!shen_is_boolean(ctx, t1714))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t1714)) {
  KLObject* t1715 = shen_true(ctx);
      t1701 = t1715;
    } else {
      shen_simple_error(ctx, "No true case found for cond");
      t1701 = shen_empty_list(ctx);
    }
    }
    }
  }
    return t1701;
  }
}

static KLObject* native_kl_shen_2eprocess_2dyacc_2dsemantics_42 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t1716 = objects[0];
  tail_start_kl_shen_2eprocess_2dyacc_2dsemantics_42: ;
  KLObject* t1717;
  {
  KLObject* t1720 = shen_cons_p(ctx, t1716);
  KLObject* t1718;
  if (!shen_is_boolean(ctx, t1720))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t1720)) {
    t1718 = t1720;
  } else {
  KLObject* t1722 = shen_intern(ctx, "protect");
  KLObject* t1724 = shen_hd(ctx, t1716);
  KLObject* t1725 = shen_eq(ctx, t1722, t1724);
  KLObject* t1721;
  if (!shen_is_boolean(ctx, t1725))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t1725)) {
    t1721 = t1725;
  } else {
  KLObject* t1728 = shen_tl(ctx, t1716);
  KLObject* t1729 = shen_cons_p(ctx, t1728);
  KLObject* t1726;
  if (!shen_is_boolean(ctx, t1729))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t1729)) {
    t1726 = t1729;
  } else {
  KLObject* t1731 = shen_empty_list(ctx);
  KLObject* t1733 = shen_tl(ctx, t1716);
  KLObject* t1734 = shen_tl(ctx, t1733);
  KLObject* t1735 = shen_eq(ctx, t1731, t1734);
  KLObject* t1730;
  if (!shen_is_boolean(ctx, t1735))
    shen_simple_error(ctx, "Arguments should be boolean values");
  if (!shen_boolean_value(ctx, t1735)) {
    t1730 = t1735;
  } else {
  KLObject* t1738 = shen_tl(ctx, t1716);
  KLObject* t1739 = shen_hd(ctx, t1738);
  KLObject* t1736;
  {
    KLObject* a1736[] = {t1739};
    t1736 = shen_apply_direct(ctx, "shen.non-terminal?", 1, a1736);
  }
    if (!shen_is_boolean(ctx, t1736))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t1730 = t1736;
  }
    if (!shen_is_boolean(ctx, t1730))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t1726 = t1730;
  }
    if (!shen_is_boolean(ctx, t1726))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t1721 = t1726;
  }
    if (!shen_is_boolean(ctx, t1721))
      shen_simple_error(ctx, "Arguments should be boolean values");
    t1718 = t1721;
  }
    if (!shen_is_boolean(ctx, t1718))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t1718)) {
  KLObject* t1741 = shen_tl(ctx, t1716);
  KLObject* t1742 = shen_hd(ctx, t1741);
      t1717 = t1742;
    } else {
  KLObject* t1744 = shen_cons_p(ctx, t1716);
    if (!shen_is_boolean(ctx, t1744))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t1744)) {
  KLObject* t1746;
  {
    Vector* caps_2 = shen_vector(ctx, 0);
    t1746 = shen_native_closure(ctx, 1, &lambda_2, caps_2);
  }
  KLObject* t1745;
  {
    KLObject* a1745[] = {t1746, t1716};
    t1745 = shen_tail_apply_direct(ctx, "map", 2, a1745);
  }
      t1717 = t1745;
    } else {
  KLObject* t1751;
  {
    KLObject* a1751[] = {t1716};
    t1751 = shen_apply_direct(ctx, "shen.non-terminal?", 1, a1751);
  }
    if (!shen_is_boolean(ctx, t1751))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t1751)) {
  KLObject* t1754 = shen_intern(ctx, "Action");
  KLObject* t1753;
  {
    KLObject* a1753[] = {t1754, t1716};
    t1753 = shen_tail_apply_direct(ctx, "concat", 2, a1753);
  }
      t1717 = t1753;
    } else {
  KLObject* t1756 = shen_true(ctx);
    if (!shen_is_boolean(ctx, t1756))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t1756)) {
      t1717 = t1716;
    } else {
      shen_simple_error(ctx, "No true case found for cond");
      t1717 = shen_empty_list(ctx);
    }
    }
    }
    }
  }
    return t1717;
  }
}

static KLObject* native_kl_shen_2e_3c_2dout_43 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t1758 = objects[0];
  tail_start_kl_shen_2e_3c_2dout_43: ;
  KLObject* t1760 = shen_tl(ctx, t1758);
  KLObject* t1761 = shen_hd(ctx, t1760);
    return t1761;
  }
}

static KLObject* native_kl_shen_2ein_2d_3e_44 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t1762 = objects[0];
  tail_start_kl_shen_2ein_2d_3e_44: ;
  KLObject* t1764 = shen_hd(ctx, t1762);
    return t1764;
  }
}

static KLObject* native_kl__3c_21_3e_45 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t1765 = objects[0];
  tail_start_kl__3c_21_3e_45: ;
  KLObject* t1766 = shen_empty_list(ctx);
  KLObject* t1768 = shen_empty_list(ctx);
  KLObject* t1769 = shen_cons(ctx, t1765, t1768);
  KLObject* t1770 = shen_cons(ctx, t1766, t1769);
    return t1770;
  }
}

static KLObject* native_kl__3ce_3e_46 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t1771 = objects[0];
  tail_start_kl__3ce_3e_46: ;
  KLObject* t1773 = shen_empty_list(ctx);
  KLObject* t1774 = shen_empty_list(ctx);
  KLObject* t1775 = shen_cons(ctx, t1773, t1774);
  KLObject* t1776 = shen_cons(ctx, t1771, t1775);
    return t1776;
  }
}

static KLObject* native_kl__3cend_3e_47 (KLObject* function_object, Vector* arguments, Environment* function_environment, Environment* variable_environment)
{
  shen_context* ctx = &shen_root_context;
  (void)function_environment;
  (void)variable_environment;
  {
    KLObject** objects = shen_arguments(ctx, function_object, arguments);
    KLObject* t1777 = objects[0];
  tail_start_kl__3cend_3e_47: ;
  KLObject* t1778;
  {
  KLObject* t1779 = shen_empty_list(ctx);
  KLObject* t1781 = shen_eq(ctx, t1779, t1777);
    if (!shen_is_boolean(ctx, t1781))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t1781)) {
  KLObject* t1782 = shen_empty_list(ctx);
  KLObject* t1783 = shen_empty_list(ctx);
  KLObject* t1784 = shen_empty_list(ctx);
  KLObject* t1785 = shen_cons(ctx, t1783, t1784);
  KLObject* t1786 = shen_cons(ctx, t1782, t1785);
      t1778 = t1786;
    } else {
  KLObject* t1787 = shen_true(ctx);
    if (!shen_is_boolean(ctx, t1787))
      shen_simple_error(ctx, "Case test should be a boolean value");
    if (shen_boolean_value(ctx, t1787)) {
  KLObject* t1788 = shen_tail_apply_direct(ctx, "shen.parse-failure", 0, NULL);
      t1778 = t1788;
    } else {
      shen_simple_error(ctx, "No true case found for cond");
      t1778 = shen_empty_list(ctx);
    }
    }
  }
    return t1778;
  }
}

void shen_kernel_aot_install_yacc (shen_context* ctx)
{
  shen_register_defun(ctx, "compile", 2, &native_kl_compile_0);
  shen_register_defun(ctx, "shen.raise-syntax-error", 1, &native_kl_shen_2eraise_2dsyntax_2derror_1);
  shen_register_defun(ctx, "shen.syntax-error-message", 3, &native_kl_shen_2esyntax_2derror_2dmessage_2);
  shen_register_defun(ctx, "shen.parse-failure?", 1, &native_kl_shen_2eparse_2dfailure_3f_3);
  shen_register_defun(ctx, "shen.partial-parse-failure?", 1, &native_kl_shen_2epartial_2dparse_2dfailure_3f_4);
  shen_register_defun(ctx, "shen.objectcode", 1, &native_kl_shen_2eobjectcode_5);
  shen_register_defun(ctx, "shen.yacc->shen", 1, &native_kl_shen_2eyacc_2d_3eshen_6);
  shen_register_defun(ctx, "shen.<yacc>", 1, &native_kl_shen_2e_3cyacc_3e_7);
  shen_register_defun(ctx, "shen.<yaccsig>", 1, &native_kl_shen_2e_3cyaccsig_3e_8);
  shen_register_defun(ctx, "shen.<c-rules>", 1, &native_kl_shen_2e_3cc_2drules_3e_9);
  shen_register_defun(ctx, "shen.<c-rule>", 1, &native_kl_shen_2e_3cc_2drule_3e_10);
  shen_register_defun(ctx, "shen.autocomplete", 1, &native_kl_shen_2eautocomplete_11);
  shen_register_defun(ctx, "shen.non-terminal?", 1, &native_kl_shen_2enon_2dterminal_3f_12);
  shen_register_defun(ctx, "shen.<non-terminal?>", 1, &native_kl_shen_2e_3cnon_2dterminal_3f_3e_13);
  shen_register_defun(ctx, "shen.<packagenames>", 1, &native_kl_shen_2e_3cpackagenames_3e_14);
  shen_register_defun(ctx, "shen.<packagename>", 1, &native_kl_shen_2e_3cpackagename_3e_15);
  shen_register_defun(ctx, "shen.<packagechar>", 1, &native_kl_shen_2e_3cpackagechar_3e_16);
  shen_register_defun(ctx, "shen.<non-terminal-name>", 1, &native_kl_shen_2e_3cnon_2dterminal_2dname_3e_17);
  shen_register_defun(ctx, "shen.semicolon?", 1, &native_kl_shen_2esemicolon_3f_18);
  shen_register_defun(ctx, "shen.<colon-equal>", 1, &native_kl_shen_2e_3ccolon_2dequal_3e_19);
  shen_register_defun(ctx, "shen.colon-equal?", 1, &native_kl_shen_2ecolon_2dequal_3f_20);
  shen_register_defun(ctx, "shen.<syntax>", 1, &native_kl_shen_2e_3csyntax_3e_21);
  shen_register_defun(ctx, "shen.<syntax-item>", 1, &native_kl_shen_2e_3csyntax_2ditem_3e_22);
  shen_register_defun(ctx, "shen.syntax-item?", 1, &native_kl_shen_2esyntax_2ditem_3f_23);
  shen_register_defun(ctx, "shen.<semantics>", 1, &native_kl_shen_2e_3csemantics_3e_24);
  shen_register_defun(ctx, "shen.c-rules->shen", 3, &native_kl_shen_2ec_2drules_2d_3eshen_25);
  shen_register_defun(ctx, "shen.parse-failure", 0, &native_kl_shen_2eparse_2dfailure_26);
  shen_register_defun(ctx, "shen.combine-c-code", 2, &native_kl_shen_2ecombine_2dc_2dcode_27);
  shen_register_defun(ctx, "shen.c-rule->shen", 3, &native_kl_shen_2ec_2drule_2d_3eshen_28);
  shen_register_defun(ctx, "shen.yacc-syntax", 4, &native_kl_shen_2eyacc_2dsyntax_29);
  shen_register_defun(ctx, "shen.non-terminalcode", 5, &native_kl_shen_2enon_2dterminalcode_30);
  shen_register_defun(ctx, "shen.variablecode", 5, &native_kl_shen_2evariablecode_31);
  shen_register_defun(ctx, "shen.wildcardcode", 5, &native_kl_shen_2ewildcardcode_32);
  shen_register_defun(ctx, "shen.terminalcode", 5, &native_kl_shen_2eterminalcode_33);
  shen_register_defun(ctx, "shen.hds=?", 2, &native_kl_shen_2ehds_3d_3f_34);
  shen_register_defun(ctx, "shen.conscode", 5, &native_kl_shen_2econscode_35);
  shen_register_defun(ctx, "shen.ccons?", 1, &native_kl_shen_2eccons_3f_36);
  shen_register_defun(ctx, "shen.decons", 1, &native_kl_shen_2edecons_37);
  shen_register_defun(ctx, "shen.comb", 2, &native_kl_shen_2ecomb_38);
  shen_register_defun(ctx, "shen.yacc-semantics", 3, &native_kl_shen_2eyacc_2dsemantics_39);
  shen_register_defun(ctx, "shen.use-type-info", 2, &native_kl_shen_2euse_2dtype_2dinfo_40);
  shen_register_defun(ctx, "shen.monomorphic?", 1, &native_kl_shen_2emonomorphic_3f_41);
  shen_register_defun(ctx, "shen.process-yacc-semantics", 1, &native_kl_shen_2eprocess_2dyacc_2dsemantics_42);
  shen_register_defun(ctx, "shen.<-out", 1, &native_kl_shen_2e_3c_2dout_43);
  shen_register_defun(ctx, "shen.in->", 1, &native_kl_shen_2ein_2d_3e_44);
  shen_register_defun(ctx, "<!>", 1, &native_kl__3c_21_3e_45);
  shen_register_defun(ctx, "<e>", 1, &native_kl__3ce_3e_46);
  shen_register_defun(ctx, "<end>", 1, &native_kl__3cend_3e_47);
}
