#!/usr/bin/env python3
"""Diagnostic A/B: remove only two telemetry increments from a source snapshot.

The public runtime and its RcStats contract stay unchanged. This counter-disabled
executable is an experiment, not a production candidate or acceptance result.
"""
import argparse
import json
from pathlib import Path
import shutil
import subprocess
from release_manifest import digest

p=argparse.ArgumentParser(description=__doc__)
p.add_argument('--checkpoint',type=Path,required=True)
p.add_argument('--out',type=Path,required=True)
a=p.parse_args();root=a.checkpoint.resolve();out=a.out.resolve();out.mkdir(parents=True,exist_ok=False)
sources=out/'sources';sources.mkdir();inputs={};commands=[]
for src in (root/'src/rc').glob('*.[ch]'):
    inputs[str(src)]=digest(src);shutil.copy2(src,sources/src.name)
source=sources/'rc.c';text=source.read_text()
for statement in ('v->ctx->stats.retain_calls++;','v->ctx->stats.release_calls++;'):
    if text.count(statement)!=1:raise ValueError('changed counter template')
    text=text.replace(statement,'/* Diagnostic control: '+statement+' omitted. */')
source.write_text(text)
flags=['-O3','-g','-flto=thin','-std=c17','-Wall','-Wextra','-Wpedantic','-I'+str(sources)]
def run(argv):
    commands.append(argv)
    with (out/'build.log').open('ab') as log:subprocess.run(argv,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=180)
obj=out/'rc.o';run(['/usr/bin/cc']+flags+['-c',str(source),'-o',str(obj)])
objects=[]
for name in ('main','kernel','primitives','eval','read'):
    path=root/'obj/rc'/(name+'.o');inputs[str(path)]=digest(path);objects.append(str(path))
binary=out/'shen-counter-control'
run(['/usr/bin/cc']+flags+objects+[str(obj),'-lm','-o',str(binary)])
baseline=out/'shen-checkpoint';shutil.copy2(root/'bin/shen-rc',baseline)
inputs[str(root/'bin/shen-rc')]=digest(baseline)
inputs[str(root/'obj/rc/kernel.c')]=digest(root/'obj/rc/kernel.c')
record={'scope':__doc__,'inputs':inputs,'commands':commands,'source_sha256':digest(source),
        'binaries':{str(p):digest(p) for p in (binary,baseline)}}
(out/'build.json').write_text(json.dumps(record,indent=2)+'\n')
config={'repetitions':5,'source_identity':{'counter_control_receipt_sha256':digest(out/'build.json')},
        'cases':[{'label':label,'argv':[str(b),'script','runme.shen'],'env':{},
                  'dependency_sha256':{str(out/'build.json'):digest(out/'build.json')}}
                 for label,b in [('checkpoint',baseline),('counter_control',binary)]]}
(out/'benchmark.json').write_text(json.dumps(config,indent=2)+'\n')
