__attribute__((used)) volatile int GC_auditor_control = 1; int main(void) { return GC_auditor_control - 1; }
