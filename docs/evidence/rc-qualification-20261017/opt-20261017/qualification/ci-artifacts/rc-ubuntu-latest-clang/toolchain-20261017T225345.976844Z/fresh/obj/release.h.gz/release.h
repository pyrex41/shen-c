/* Generated from the checked release manifest. */
#define SHEN_KERNEL_VERSION "43.1"
#define SHEN_KERNEL_MODULES {"sys","writer","core","reader","declarations","toplevel","macros","load","prolog","sequent","track","t-star","yacc","types"}
