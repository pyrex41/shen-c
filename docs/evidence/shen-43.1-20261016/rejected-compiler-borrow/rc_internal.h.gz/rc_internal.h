#ifndef SHEN_RC_INTERNAL_H
#define SHEN_RC_INTERNAL_H
#include "rc.h"
/* Runtime/primitive implementation contract. The installer alone registers
 * freshly created original builtins; this is not an embedding API. */
typedef enum {
 RC_BUILTIN_HD, RC_BUILTIN_TL, RC_BUILTIN_CONSP, RC_BUILTIN_NUMBERP,
 RC_BUILTIN_STRINGP, RC_BUILTIN_EQ, RC_BUILTIN_ADD, RC_BUILTIN_SUB,
 RC_BUILTIN_MUL, RC_BUILTIN_DIV, RC_BUILTIN_GT, RC_BUILTIN_LT,
 RC_BUILTIN_GE, RC_BUILTIN_LE, RC_BUILTIN_CONS, RC_BUILTIN_COUNT
} RcBuiltinSlot;
void rc_builtin_cache_set(RcContext *, RcBuiltinSlot, RcValue *);
bool rc_builtin_identity_matches(RcContext *, RcBuiltinSlot, RcValue *);
bool rc_builtin_call_matches(RcContext *, RcBuiltinSlot, RcValue *, size_t,
                              RcValue *const *);
/* Validated exact canonical call slot, or -1. Includes every argument check;
 * callers may enter the shared private tiny body without rechecking guards. */
int rc_builtin_call_slot(RcContext *, RcValue *, size_t, RcValue *const *);
/* Private compiler borrow summary: exact canonical scalar/projection leaves
 * only read args and return an owned result. Generic fallback acquires all
 * needed roots before callbacks; caller retains its live argument owners. */
RcValue *rc_primitive_borrowed(RcContext *,RcValue *,RcBuiltinSlot,
                              RcValue *const *,bool tail);
/* The caller roots list. Only immutable pair-spine metadata is cached; no
 * callbacks, allocation or collection occurs. out is written only on OK. */
typedef enum { RC_LIST_LENGTH_OK, RC_LIST_LENGTH_IMPROPER,
               RC_LIST_LENGTH_OVERFLOW } RcListLengthStatus;
RcListLengthStatus rc_list_length_cached(RcValue *list,size_t *out);
/* Consumes an owned evaluator argument result. Same-context values pass;
 * tail requests acquire a deferred context check without forcing recursion.
 * Completion preserves the generic owned-call operand error diagnostic. */
RcValue *rc_eval_require_argument_context(RcContext *,RcValue *);
/* Private interpreted callback layout: [body, environment, parameter keys...].
 * Validates context, callback identity, original arity and exact capture count.
 * The returned span is borrowed; the active runtime call must keep self rooted
 * until callback return. Partial closures preserve the original capture shape. */
RcValue *const *rc_eval_captures(RcContext *, RcValue *, RcNative, size_t arity);
/* Only dynamic_call may use this trusted entry: make_function has validated
 * immutable parameter keys/captured parent, and runtime dispatch has checked
 * every argv value against ctx. Still checks the exact callback/capture layout
 * and storage multiplication bounds. Returns owned ENV and borrowed body while
 * the active self remains rooted. The public rc_env_frame keeps all validation. */
RcValue *rc_eval_env_frame(RcContext *, RcValue *, RcNative, size_t arity,
                           RcValue *const *argv, RcValue **body);
#endif
