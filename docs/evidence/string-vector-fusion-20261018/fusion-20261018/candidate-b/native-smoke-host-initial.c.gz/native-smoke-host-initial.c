#define SHEN_RC_NO_MAIN
#include "native-smoke-v2/app.c"
#include <assert.h>
#include "rc_internal.h"
int main(void) {
 RcContext *ctx=rc_context_new(); assert(ctx);
 assert(rc_bootstrap_kernel(ctx));
 assert(run_top(ctx,rc_native_0,0));
 RcValue *result=rc_native_1865(ctx,NULL,0,NULL);
 if(!result) { fprintf(stderr,"%s\n",rc_error_message(ctx)); abort(); }
 RcStats before=rc_stats(ctx);
 rc_collect(ctx);
 RcStats after=rc_stats(ctx);
 assert(after.cycle_objects_freed >= before.cycle_objects_freed+2);
 assert(rc_type(result)==RC_STRING && rc_text_length(result)==255);
 const char *source="abcdefghijklmnopqrstuvwxyz012345";
 for(size_t i=0;i<255;i++) assert(rc_text(result)[i]==source[(i+1)%32]);
 assert(rc_text(result)[255]=='\0');
 RcFusionStats f=rc_fusion_stats(ctx);
 assert(f.counts[RC_FUSION_STRING_VIEWS]>0);
 printf("{\"status\":\"PASS\",\"cycle_freed_delta\":%zu,\"escaped_suffix_length\":255,\"string_views\":%zu}\n",after.cycle_objects_freed-before.cycle_objects_freed,f.counts[RC_FUSION_STRING_VIEWS]);
 rc_release(result); rc_collect(ctx); rc_context_free(ctx); return 0;
}
